import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/controlPlane/EvidenceLineagePanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { BadgeCheck, Database, FileCheck2, Gauge, GitCommitHorizontal, Lightbulb, ShieldCheck } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { Badge } from "/src/components/ui/badge.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Card } from "/src/components/ui/card.tsx";
const icons = {
  evidence: Database,
  claims: BadgeCheck,
  recommendation: Lightbulb,
  approval: ShieldCheck,
  implementation: GitCommitHorizontal,
  verification: FileCheck2,
  measurement: Gauge
};
const statusTone = {
  COMPLETE: "border-emerald-500/30 bg-emerald-500/10 text-emerald-200",
  NOT_REQUIRED: "border-sky-500/30 bg-sky-500/10 text-sky-200",
  PENDING: "border-amber-500/30 bg-amber-500/10 text-amber-200",
  MISSING: "border-red-500/30 bg-red-500/10 text-red-200"
};
export function EvidenceLineagePanel({
  stages,
  onNavigate
}) {
  _s();
  const [selectedId, setSelectedId] = useState(stages[0]?.id ?? null);
  useEffect(() => {
    if (!stages.some((stage) => stage.id === selectedId)) setSelectedId(stages[0]?.id ?? null);
  }, [selectedId, stages]);
  const selected = stages.find((stage) => stage.id === selectedId) ?? stages[0];
  return /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-start justify-between gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-foreground", children: "Continuous evidence lineage" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
          lineNumber: 70,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: "Research through measurement, derived from durable run records. Missing links remain visible." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
          lineNumber: 71,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
        lineNumber: 69,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: [
        stages.filter((stage) => stage.status === "COMPLETE").length,
        "/",
        stages.length,
        " complete"
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
        lineNumber: 75,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
      lineNumber: 68,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("ol", { "aria-label": "Continuous evidence lineage", className: "mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-7", children: stages.map((stage, index) => {
      const Icon = icons[stage.id];
      const selectedStage = stage.id === selected?.id;
      return /* @__PURE__ */ jsxDEV("li", { className: "relative min-w-0", children: /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          "aria-current": selectedStage ? "step" : void 0,
          onClick: () => setSelectedId(stage.id),
          className: `h-full w-full rounded-lg border p-3 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${selectedStage ? "border-registry-accent/60 bg-registry-accent-soft" : "border-[var(--panel-line)] bg-background/30 hover:bg-background/60"}`,
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-2", children: [
              /* @__PURE__ */ jsxDEV(Icon, { className: "h-4 w-4 text-muted-foreground", "aria-hidden": "true" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
                lineNumber: 93,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-muted-foreground", children: index + 1 }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
                lineNumber: 94,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
              lineNumber: 92,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-3 truncate text-xs font-medium text-foreground", children: stage.label }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
              lineNumber: 96,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-2 flex flex-wrap items-center gap-1.5", children: [
              /* @__PURE__ */ jsxDEV("span", { className: `rounded border px-1.5 py-0.5 text-[9px] font-medium tracking-wide ${statusTone[stage.status]}`, children: stage.status.replace("_", " ") }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
                lineNumber: 98,
                columnNumber: 19
              }, this),
              stage.count > 0 ? /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-muted-foreground", children: stage.count }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
                lineNumber: 101,
                columnNumber: 38
              }, this) : null
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
              lineNumber: 97,
              columnNumber: 17
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
          lineNumber: 84,
          columnNumber: 15
        },
        this
      ) }, stage.id, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
        lineNumber: 83,
        columnNumber: 13
      }, this);
    }) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
      lineNumber: 78,
      columnNumber: 7
    }, this),
    selected ? /* @__PURE__ */ jsxDEV("div", { className: "mt-4 rounded-lg border border-[var(--panel-line)] bg-background/30 p-4", "aria-live": "polite", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-start justify-between gap-3", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-foreground", children: selected.label }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
            lineNumber: 113,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-muted-foreground", children: selected.summary }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
            lineNumber: 114,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
          lineNumber: 112,
          columnNumber: 13
        }, this),
        onNavigate ? /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => onNavigate(selected.target), children: "Inspect records" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
          lineNumber: 117,
          columnNumber: 11
        }, this) : null
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
        lineNumber: 111,
        columnNumber: 11
      }, this),
      selected.details.length > 0 ? /* @__PURE__ */ jsxDEV("ul", { className: "mt-3 space-y-1.5 text-xs text-muted-foreground", children: selected.details.map((detail, index) => /* @__PURE__ */ jsxDEV("li", { children: [
        "• ",
        detail
      ] }, `${detail}-${index}`, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
        lineNumber: 124,
        columnNumber: 56
      }, this)) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
        lineNumber: 123,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-xs text-muted-foreground", children: "No supporting detail is recorded for this stage." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
        lineNumber: 127,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
      lineNumber: 110,
      columnNumber: 7
    }, this) : null
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx",
    lineNumber: 67,
    columnNumber: 5
  }, this);
}
_s(EvidenceLineagePanel, "RAX/CsJkoUL9zBLCX1kXFCxjITk=");
_c = EvidenceLineagePanel;
var _c;
$RefreshReg$(_c, "EvidenceLineagePanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/EvidenceLineagePanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0RVOzs7Ozs7Ozs7Ozs7Ozs7OztBQWxEVixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsWUFBWUMsVUFBVUMsWUFBWUMsT0FBT0MscUJBQXFCQyxXQUFXQyxtQkFBbUI7QUFDckcsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLFlBQVk7QUFZckIsTUFBTUMsUUFBUTtBQUFBLEVBQ1pDLFVBQVVWO0FBQUFBLEVBQ1ZXLFFBQVFaO0FBQUFBLEVBQ1JhLGdCQUFnQlI7QUFBQUEsRUFDaEJTLFVBQVVSO0FBQUFBLEVBQ1ZTLGdCQUFnQlg7QUFBQUEsRUFDaEJZLGNBQWNkO0FBQUFBLEVBQ2RlLGFBQWFkO0FBQ2Y7QUFFQSxNQUFNZSxhQUFhO0FBQUEsRUFDakJDLFVBQVU7QUFBQSxFQUNWQyxjQUFjO0FBQUEsRUFDZEMsU0FBUztBQUFBLEVBQ1RDLFNBQVM7QUFDWDtBQUVPLGdCQUFTQyxxQkFBcUI7QUFBQSxFQUNuQ0M7QUFBQUEsRUFDQUM7QUFJRixHQUFHO0FBQUFDLEtBQUE7QUFDRCxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSTdCLFNBQTRDeUIsT0FBTyxDQUFDLEdBQUdLLE1BQU0sSUFBSTtBQUNyRy9CLFlBQVUsTUFBTTtBQUNkLFFBQUksQ0FBQzBCLE9BQU9NLEtBQUssQ0FBQ0MsVUFBVUEsTUFBTUYsT0FBT0YsVUFBVSxFQUFHQyxlQUFjSixPQUFPLENBQUMsR0FBR0ssTUFBTSxJQUFJO0FBQUEsRUFDM0YsR0FBRyxDQUFDRixZQUFZSCxNQUFNLENBQUM7QUFDdkIsUUFBTVEsV0FBV1IsT0FBT1MsS0FBSyxDQUFDRixVQUFVQSxNQUFNRixPQUFPRixVQUFVLEtBQUtILE9BQU8sQ0FBQztBQUU1RSxTQUNFLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsMkJBQUMsU0FBSSxXQUFVLG9EQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFNBQUksV0FBVSx1Q0FBc0MsMkNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Y7QUFBQSxRQUNoRix1QkFBQyxTQUFJLFdBQVUsc0NBQW9DLDZHQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBTSxTQUFRLFdBQVdBO0FBQUFBLGVBQU9VLE9BQU8sQ0FBQ0gsVUFBVUEsTUFBTUksV0FBVyxVQUFVLEVBQUVDO0FBQUFBLFFBQU87QUFBQSxRQUFFWixPQUFPWTtBQUFBQSxRQUFPO0FBQUEsV0FBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnSDtBQUFBLFNBUGxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBRUEsdUJBQUMsUUFBRyxjQUFXLCtCQUE4QixXQUFVLGlEQUNwRFosaUJBQU9hLElBQUksQ0FBQ04sT0FBT08sVUFBVTtBQUM1QixZQUFNQyxPQUFPN0IsTUFBTXFCLE1BQU1GLEVBQUU7QUFDM0IsWUFBTVcsZ0JBQWdCVCxNQUFNRixPQUFPRyxVQUFVSDtBQUM3QyxhQUNFLHVCQUFDLFFBQWtCLFdBQVUsb0JBQzNCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxnQkFBY1csZ0JBQWdCLFNBQVNDO0FBQUFBLFVBQ3ZDLFNBQVMsTUFBTWIsY0FBY0csTUFBTUYsRUFBRTtBQUFBLFVBQ3JDLFdBQVcsMklBQ1RXLGdCQUFnQixzREFBc0Qsb0VBQW9FO0FBQUEsVUFHNUk7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxRQUFLLFdBQVUsaUNBQWdDLGVBQVksVUFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0U7QUFBQSxjQUNsRSx1QkFBQyxVQUFLLFdBQVUscUNBQXFDRixrQkFBUSxLQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErRDtBQUFBLGlCQUZqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscURBQXFEUCxnQkFBTVcsU0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Y7QUFBQSxZQUNoRix1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVcscUVBQXFFeEIsV0FBV2EsTUFBTUksTUFBTSxDQUFDLElBQzNHSixnQkFBTUksT0FBT1EsUUFBUSxLQUFLLEdBQUcsS0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0NaLE1BQU1hLFFBQVEsSUFBSSx1QkFBQyxVQUFLLFdBQVUscUNBQXFDYixnQkFBTWEsU0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUUsSUFBVTtBQUFBLGlCQUpoRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUE7QUFBQTtBQUFBLFFBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQW1CQSxLQXBCT2IsTUFBTUYsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUJBO0FBQUEsSUFFSixDQUFDLEtBNUJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2QkE7QUFBQSxJQUVDRyxXQUNDLHVCQUFDLFNBQUksV0FBVSwwRUFBeUUsYUFBVSxVQUNoRztBQUFBLDZCQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsdUNBQXVDQSxtQkFBU1UsU0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUU7QUFBQSxVQUNyRSx1QkFBQyxPQUFFLFdBQVUsc0NBQXNDVixtQkFBU2EsV0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0U7QUFBQSxhQUZ0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNDcEIsYUFDQyx1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFRLFdBQVUsU0FBUyxNQUFNQSxXQUFXTyxTQUFTYyxNQUFNLEdBQUUsK0JBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUNFO0FBQUEsV0FUTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNDZCxTQUFTZSxRQUFRWCxTQUFTLElBQ3pCLHVCQUFDLFFBQUcsV0FBVSxrREFDWEosbUJBQVNlLFFBQVFWLElBQUksQ0FBQ1csUUFBUVYsVUFBVSx1QkFBQyxRQUE4QjtBQUFBO0FBQUEsUUFBR1U7QUFBQUEsV0FBekIsR0FBR0EsTUFBTSxJQUFJVixLQUFLLElBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUMsQ0FBSyxLQUR6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsSUFFQSx1QkFBQyxPQUFFLFdBQVUsc0NBQXFDLGdFQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtHO0FBQUEsU0FqQnRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQkEsSUFDRTtBQUFBLE9BL0ROO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnRUE7QUFFSjtBQUFDWixHQWhGZUgsc0JBQW9CO0FBQUEsS0FBcEJBO0FBQW9CLElBQUEwQjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkJhZGdlQ2hlY2siLCJEYXRhYmFzZSIsIkZpbGVDaGVjazIiLCJHYXVnZSIsIkdpdENvbW1pdEhvcml6b250YWwiLCJMaWdodGJ1bGIiLCJTaGllbGRDaGVjayIsIkJhZGdlIiwiQnV0dG9uIiwiQ2FyZCIsImljb25zIiwiZXZpZGVuY2UiLCJjbGFpbXMiLCJyZWNvbW1lbmRhdGlvbiIsImFwcHJvdmFsIiwiaW1wbGVtZW50YXRpb24iLCJ2ZXJpZmljYXRpb24iLCJtZWFzdXJlbWVudCIsInN0YXR1c1RvbmUiLCJDT01QTEVURSIsIk5PVF9SRVFVSVJFRCIsIlBFTkRJTkciLCJNSVNTSU5HIiwiRXZpZGVuY2VMaW5lYWdlUGFuZWwiLCJzdGFnZXMiLCJvbk5hdmlnYXRlIiwiX3MiLCJzZWxlY3RlZElkIiwic2V0U2VsZWN0ZWRJZCIsImlkIiwic29tZSIsInN0YWdlIiwic2VsZWN0ZWQiLCJmaW5kIiwiZmlsdGVyIiwic3RhdHVzIiwibGVuZ3RoIiwibWFwIiwiaW5kZXgiLCJJY29uIiwic2VsZWN0ZWRTdGFnZSIsInVuZGVmaW5lZCIsImxhYmVsIiwicmVwbGFjZSIsImNvdW50Iiwic3VtbWFyeSIsInRhcmdldCIsImRldGFpbHMiLCJkZXRhaWwiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJFdmlkZW5jZUxpbmVhZ2VQYW5lbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgQmFkZ2VDaGVjaywgRGF0YWJhc2UsIEZpbGVDaGVjazIsIEdhdWdlLCBHaXRDb21taXRIb3Jpem9udGFsLCBMaWdodGJ1bGIsIFNoaWVsZENoZWNrIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgQmFkZ2UgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2JhZGdlXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuaW1wb3J0IHsgQ2FyZCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvY2FyZFwiO1xuXG5leHBvcnQgdHlwZSBFdmlkZW5jZUxpbmVhZ2VTdGFnZSA9IHtcbiAgaWQ6IFwiZXZpZGVuY2VcIiB8IFwiY2xhaW1zXCIgfCBcInJlY29tbWVuZGF0aW9uXCIgfCBcImFwcHJvdmFsXCIgfCBcImltcGxlbWVudGF0aW9uXCIgfCBcInZlcmlmaWNhdGlvblwiIHwgXCJtZWFzdXJlbWVudFwiO1xuICBsYWJlbDogc3RyaW5nO1xuICBzdGF0dXM6IFwiQ09NUExFVEVcIiB8IFwiTUlTU0lOR1wiIHwgXCJOT1RfUkVRVUlSRURcIiB8IFwiUEVORElOR1wiO1xuICBjb3VudDogbnVtYmVyO1xuICBzdW1tYXJ5OiBzdHJpbmc7XG4gIGRldGFpbHM6IHN0cmluZ1tdO1xuICB0YXJnZXQ6IFwidGltZWxpbmVcIiB8IFwiZmlsZXNcIiB8IFwiYXJ0aWZhY3RzXCIgfCBcInJlY2VpcHRzXCI7XG59O1xuXG5jb25zdCBpY29ucyA9IHtcbiAgZXZpZGVuY2U6IERhdGFiYXNlLFxuICBjbGFpbXM6IEJhZGdlQ2hlY2ssXG4gIHJlY29tbWVuZGF0aW9uOiBMaWdodGJ1bGIsXG4gIGFwcHJvdmFsOiBTaGllbGRDaGVjayxcbiAgaW1wbGVtZW50YXRpb246IEdpdENvbW1pdEhvcml6b250YWwsXG4gIHZlcmlmaWNhdGlvbjogRmlsZUNoZWNrMixcbiAgbWVhc3VyZW1lbnQ6IEdhdWdlLFxufTtcblxuY29uc3Qgc3RhdHVzVG9uZSA9IHtcbiAgQ09NUExFVEU6IFwiYm9yZGVyLWVtZXJhbGQtNTAwLzMwIGJnLWVtZXJhbGQtNTAwLzEwIHRleHQtZW1lcmFsZC0yMDBcIixcbiAgTk9UX1JFUVVJUkVEOiBcImJvcmRlci1za3ktNTAwLzMwIGJnLXNreS01MDAvMTAgdGV4dC1za3ktMjAwXCIsXG4gIFBFTkRJTkc6IFwiYm9yZGVyLWFtYmVyLTUwMC8zMCBiZy1hbWJlci01MDAvMTAgdGV4dC1hbWJlci0yMDBcIixcbiAgTUlTU0lORzogXCJib3JkZXItcmVkLTUwMC8zMCBiZy1yZWQtNTAwLzEwIHRleHQtcmVkLTIwMFwiLFxufTtcblxuZXhwb3J0IGZ1bmN0aW9uIEV2aWRlbmNlTGluZWFnZVBhbmVsKHtcbiAgc3RhZ2VzLFxuICBvbk5hdmlnYXRlLFxufToge1xuICBzdGFnZXM6IEV2aWRlbmNlTGluZWFnZVN0YWdlW107XG4gIG9uTmF2aWdhdGU/OiAodGFyZ2V0OiBFdmlkZW5jZUxpbmVhZ2VTdGFnZVtcInRhcmdldFwiXSkgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgW3NlbGVjdGVkSWQsIHNldFNlbGVjdGVkSWRdID0gdXNlU3RhdGU8RXZpZGVuY2VMaW5lYWdlU3RhZ2VbXCJpZFwiXSB8IG51bGw+KHN0YWdlc1swXT8uaWQgPz8gbnVsbCk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFzdGFnZXMuc29tZSgoc3RhZ2UpID0+IHN0YWdlLmlkID09PSBzZWxlY3RlZElkKSkgc2V0U2VsZWN0ZWRJZChzdGFnZXNbMF0/LmlkID8/IG51bGwpO1xuICB9LCBbc2VsZWN0ZWRJZCwgc3RhZ2VzXSk7XG4gIGNvbnN0IHNlbGVjdGVkID0gc3RhZ2VzLmZpbmQoKHN0YWdlKSA9PiBzdGFnZS5pZCA9PT0gc2VsZWN0ZWRJZCkgPz8gc3RhZ2VzWzBdO1xuXG4gIHJldHVybiAoXG4gICAgPENhcmQgY2xhc3NOYW1lPVwicC00XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmRcIj5Db250aW51b3VzIGV2aWRlbmNlIGxpbmVhZ2U8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgIFJlc2VhcmNoIHRocm91Z2ggbWVhc3VyZW1lbnQsIGRlcml2ZWQgZnJvbSBkdXJhYmxlIHJ1biByZWNvcmRzLiBNaXNzaW5nIGxpbmtzIHJlbWFpbiB2aXNpYmxlLlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCI+e3N0YWdlcy5maWx0ZXIoKHN0YWdlKSA9PiBzdGFnZS5zdGF0dXMgPT09IFwiQ09NUExFVEVcIikubGVuZ3RofS97c3RhZ2VzLmxlbmd0aH0gY29tcGxldGU8L0JhZGdlPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxvbCBhcmlhLWxhYmVsPVwiQ29udGludW91cyBldmlkZW5jZSBsaW5lYWdlXCIgY2xhc3NOYW1lPVwibXQtNCBncmlkIGdhcC0yIHNtOmdyaWQtY29scy0yIHhsOmdyaWQtY29scy03XCI+XG4gICAgICAgIHtzdGFnZXMubWFwKChzdGFnZSwgaW5kZXgpID0+IHtcbiAgICAgICAgICBjb25zdCBJY29uID0gaWNvbnNbc3RhZ2UuaWRdO1xuICAgICAgICAgIGNvbnN0IHNlbGVjdGVkU3RhZ2UgPSBzdGFnZS5pZCA9PT0gc2VsZWN0ZWQ/LmlkO1xuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8bGkga2V5PXtzdGFnZS5pZH0gY2xhc3NOYW1lPVwicmVsYXRpdmUgbWluLXctMFwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgYXJpYS1jdXJyZW50PXtzZWxlY3RlZFN0YWdlID8gXCJzdGVwXCIgOiB1bmRlZmluZWR9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRJZChzdGFnZS5pZCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaC1mdWxsIHctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBwLTMgdGV4dC1sZWZ0IHRyYW5zaXRpb24tY29sb3JzIGZvY3VzLXZpc2libGU6b3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy1yaW5nICR7XG4gICAgICAgICAgICAgICAgICBzZWxlY3RlZFN0YWdlID8gXCJib3JkZXItcmVnaXN0cnktYWNjZW50LzYwIGJnLXJlZ2lzdHJ5LWFjY2VudC1zb2Z0XCIgOiBcImJvcmRlci1bdmFyKC0tcGFuZWwtbGluZSldIGJnLWJhY2tncm91bmQvMzAgaG92ZXI6YmctYmFja2dyb3VuZC82MFwiXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e2luZGV4ICsgMX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHRydW5jYXRlIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1mb3JlZ3JvdW5kXCI+e3N0YWdlLmxhYmVsfTwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcm91bmRlZCBib3JkZXIgcHgtMS41IHB5LTAuNSB0ZXh0LVs5cHhdIGZvbnQtbWVkaXVtIHRyYWNraW5nLXdpZGUgJHtzdGF0dXNUb25lW3N0YWdlLnN0YXR1c119YH0+XG4gICAgICAgICAgICAgICAgICAgIHtzdGFnZS5zdGF0dXMucmVwbGFjZShcIl9cIiwgXCIgXCIpfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAge3N0YWdlLmNvdW50ID4gMCA/IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntzdGFnZS5jb3VudH08L3NwYW4+IDogbnVsbH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICk7XG4gICAgICAgIH0pfVxuICAgICAgPC9vbD5cblxuICAgICAge3NlbGVjdGVkID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLVt2YXIoLS1wYW5lbC1saW5lKV0gYmctYmFja2dyb3VuZC8zMCBwLTRcIiBhcmlhLWxpdmU9XCJwb2xpdGVcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZm9yZWdyb3VuZFwiPntzZWxlY3RlZC5sYWJlbH08L2Rpdj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntzZWxlY3RlZC5zdW1tYXJ5fTwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAge29uTmF2aWdhdGUgPyAoXG4gICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cIm91dGxpbmVcIiBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKHNlbGVjdGVkLnRhcmdldCl9PlxuICAgICAgICAgICAgICAgIEluc3BlY3QgcmVjb3Jkc1xuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHtzZWxlY3RlZC5kZXRhaWxzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwibXQtMyBzcGFjZS15LTEuNSB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICB7c2VsZWN0ZWQuZGV0YWlscy5tYXAoKGRldGFpbCwgaW5kZXgpID0+IDxsaSBrZXk9e2Ake2RldGFpbH0tJHtpbmRleH1gfT7igKIge2RldGFpbH08L2xpPil9XG4gICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+Tm8gc3VwcG9ydGluZyBkZXRhaWwgaXMgcmVjb3JkZWQgZm9yIHRoaXMgc3RhZ2UuPC9wPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IG51bGx9XG4gICAgPC9DYXJkPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvY29udHJvbFBsYW5lL0V2aWRlbmNlTGluZWFnZVBhbmVsLnRzeCJ9