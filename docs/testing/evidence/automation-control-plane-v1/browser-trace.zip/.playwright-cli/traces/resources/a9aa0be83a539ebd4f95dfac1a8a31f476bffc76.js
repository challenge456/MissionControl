import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/factory/MetricBlock.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/MetricBlock.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { cn } from "/src/lib/utils.ts";
export function MetricBlock({
  label,
  value,
  detail,
  adornment,
  className
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: cn("flex min-w-0 flex-col gap-1.5", className), children: [
    /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] font-medium text-ink-secondary", children: label }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/MetricBlock.tsx",
      lineNumber: 43,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-[20px] font-semibold leading-none text-ink", children: value }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/MetricBlock.tsx",
        lineNumber: 45,
        columnNumber: 9
      }, this),
      adornment
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/MetricBlock.tsx",
      lineNumber: 44,
      columnNumber: 7
    }, this),
    detail && /* @__PURE__ */ jsxDEV("div", { className: "text-[12px] text-ink-muted", children: detail }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/MetricBlock.tsx",
      lineNumber: 48,
      columnNumber: 18
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/MetricBlock.tsx",
    lineNumber: 42,
    columnNumber: 5
  }, this);
}
_c = MetricBlock;
export function MetricRow({ children, className }) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: cn(
        "grid grid-cols-1 gap-6 border-b border-line pb-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4",
        className
      ),
      children
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/MetricBlock.tsx",
      lineNumber: 55,
      columnNumber: 5
    },
    this
  );
}
_c2 = MetricRow;
var _c, _c2;
$RefreshReg$(_c, "MetricBlock");
$RefreshReg$(_c2, "MetricRow");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/MetricBlock.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/MetricBlock.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJNOzs7Ozs7Ozs7Ozs7Ozs7O0FBdEJOLFNBQVNBLFVBQVU7QUFhWixnQkFBU0MsWUFBWTtBQUFBLEVBQzFCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNnQixHQUFnQjtBQUNoQyxTQUNFLHVCQUFDLFNBQUksV0FBV04sR0FBRyxpQ0FBaUNNLFNBQVMsR0FDM0Q7QUFBQSwyQkFBQyxTQUFJLFdBQVUsZ0RBQWdESixtQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRTtBQUFBLElBQ3JFLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxtREFBbURDLG1CQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdFO0FBQUEsTUFDdkVFO0FBQUFBLFNBRkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQ0QsVUFBVSx1QkFBQyxTQUFJLFdBQVUsOEJBQThCQSxvQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRDtBQUFBLE9BTmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FPQTtBQUVKO0FBQUNHLEtBakJlTjtBQW1CVCxnQkFBU08sVUFBVSxFQUFFQyxVQUFVSCxVQUF1RCxHQUFnQjtBQUMzRyxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxXQUFXTjtBQUFBQSxRQUNUO0FBQUEsUUFDQU07QUFBQUEsTUFDRjtBQUFBLE1BRUNHO0FBQUFBO0FBQUFBLElBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0E7QUFFSjtBQUFDQyxNQVhlRjtBQUFTLElBQUFELElBQUFHO0FBQUEsYUFBQUgsSUFBQTtBQUFBLGFBQUFHLEtBQUEiLCJuYW1lcyI6WyJjbiIsIk1ldHJpY0Jsb2NrIiwibGFiZWwiLCJ2YWx1ZSIsImRldGFpbCIsImFkb3JubWVudCIsImNsYXNzTmFtZSIsIl9jIiwiTWV0cmljUm93IiwiY2hpbGRyZW4iLCJfYzIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTWV0cmljQmxvY2sudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCIuLi8uLi9saWIvdXRpbHNcIjtcblxuZXhwb3J0IGludGVyZmFjZSBNZXRyaWNCbG9ja1Byb3BzIHtcbiAgbGFiZWw6IHN0cmluZztcbiAgdmFsdWU6IFJlYWN0Tm9kZTtcbiAgLyoqIFNtYWxsIGxpbmUgdW5kZXIgdGhlIHZhbHVlLCBlLmcuIFwiQXZlcmFnZSBzY29yZSBhY3Jvc3MgMyBldmFsIHNjZW5hcmlvc1wiICovXG4gIGRldGFpbD86IHN0cmluZztcbiAgLyoqIFJpZ2h0LWFsaWduZWQgYWRvcm5tZW50IG5leHQgdG8gdGhlIHZhbHVlIChUcmVuZEJhZGdlLCBzdGF0dXMgdGV4dCwg4oCmKSAqL1xuICBhZG9ybm1lbnQ/OiBSZWFjdE5vZGU7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbn1cblxuLyoqIEhlYWRlciBtZXRyaWMgY2VsbCB1c2VkIGluIGRldGFpbC1wYWdlIG1ldHJpYyByb3dzIGFuZCBvdmVydmlldyBncmlkcy4gKi9cbmV4cG9ydCBmdW5jdGlvbiBNZXRyaWNCbG9jayh7XG4gIGxhYmVsLFxuICB2YWx1ZSxcbiAgZGV0YWlsLFxuICBhZG9ybm1lbnQsXG4gIGNsYXNzTmFtZSxcbn06IE1ldHJpY0Jsb2NrUHJvcHMpOiBKU1guRWxlbWVudCB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2NuKFwiZmxleCBtaW4tdy0wIGZsZXgtY29sIGdhcC0xLjVcIiwgY2xhc3NOYW1lKX0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEyLjVweF0gZm9udC1tZWRpdW0gdGV4dC1pbmstc2Vjb25kYXJ5XCI+e2xhYmVsfTwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzIwcHhdIGZvbnQtc2VtaWJvbGQgbGVhZGluZy1ub25lIHRleHQtaW5rXCI+e3ZhbHVlfTwvZGl2PlxuICAgICAgICB7YWRvcm5tZW50fVxuICAgICAgPC9kaXY+XG4gICAgICB7ZGV0YWlsICYmIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1pbmstbXV0ZWRcIj57ZGV0YWlsfTwvZGl2Pn1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIE1ldHJpY1Jvdyh7IGNoaWxkcmVuLCBjbGFzc05hbWUgfTogeyBjaGlsZHJlbjogUmVhY3ROb2RlOyBjbGFzc05hbWU/OiBzdHJpbmcgfSk6IEpTWC5FbGVtZW50IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTYgYm9yZGVyLWIgYm9yZGVyLWxpbmUgcGItNSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyB4bDpncmlkLWNvbHMtNFwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvY29tcG9uZW50cy9mYWN0b3J5L01ldHJpY0Jsb2NrLnRzeCJ9