import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/AlertRulesModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { useQuery, useMutation } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle
} from "/src/components/ui/dialog.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { Bell, Trash2 } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
export function AlertRulesModal({ projectId, onClose }) {
  _s();
  const rules = useQuery(api.alertRules.list, { projectId: projectId ?? void 0 });
  const createRule = useMutation(api.alertRules.create);
  const updateRule = useMutation(api.alertRules.update);
  const removeRule = useMutation(api.alertRules.remove);
  const [threshold, setThreshold] = useState("");
  const [adding, setAdding] = useState(false);
  const handleAdd = async () => {
    const value = Number(threshold);
    if (!Number.isFinite(value) || value <= 0) return;
    setAdding(true);
    try {
      await createRule({
        projectId: projectId ?? void 0,
        type: "daily_cost_exceeded",
        threshold: value,
        enabled: true
      });
      setThreshold("");
    } finally {
      setAdding(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(Dialog, { open: true, onOpenChange: (open) => !open && onClose(), children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "max-w-md", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(Bell, { className: "h-4 w-4" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
          lineNumber: 72,
          columnNumber: 13
        }, this),
        "Alert rules"
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
        lineNumber: 71,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Get notified when daily API cost exceeds a threshold. Rules are evaluated hourly." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
        lineNumber: 75,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
      lineNumber: 70,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 pt-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV(Label, { htmlFor: "threshold", className: "text-xs text-muted-foreground", children: "Notify if daily cost exceeds ($)" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
            lineNumber: 83,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              id: "threshold",
              type: "number",
              min: 0,
              step: 1,
              placeholder: "e.g. 50",
              value: threshold,
              onChange: (e) => setThreshold(e.target.value),
              onKeyDown: (e) => e.key === "Enter" && handleAdd(),
              className: "mt-1"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
              lineNumber: 86,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
          lineNumber: 82,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            type: "button",
            size: "sm",
            className: "mt-6",
            disabled: adding || !threshold || Number(threshold) <= 0,
            onClick: handleAdd,
            children: "Add"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
            lineNumber: 98,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
        lineNumber: 81,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-medium text-muted-foreground mb-2", children: "Active rules" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
          lineNumber: 110,
          columnNumber: 13
        }, this),
        rules === void 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-muted-foreground", children: "Loading…" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
          lineNumber: 112,
          columnNumber: 13
        }, this) : rules.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-muted-foreground rounded-lg border border-dashed border-border p-4 text-center", children: "No alert rules. Add one above." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
          lineNumber: 114,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2", children: rules.map(
          (rule) => /* @__PURE__ */ jsxDEV(
            "li",
            {
              className: "flex items-center justify-between rounded-lg border border-border bg-muted/20 px-3 py-2 text-sm",
              children: [
                /* @__PURE__ */ jsxDEV("span", { children: [
                  "Daily cost > $",
                  rule.threshold.toFixed(0),
                  rule.projectId ? " (this project)" : " (all)"
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
                  lineNumber: 124,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      type: "button",
                      variant: "ghost",
                      size: "sm",
                      className: "h-7 text-xs",
                      onClick: () => updateRule({ id: rule._id, enabled: !rule.enabled }),
                      children: rule.enabled ? "Disable" : "Enable"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
                      lineNumber: 129,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      type: "button",
                      variant: "ghost",
                      size: "sm",
                      className: "h-7 text-destructive hover:text-destructive",
                      onClick: () => removeRule({ id: rule._id }),
                      "aria-label": "Delete rule",
                      children: /* @__PURE__ */ jsxDEV(Trash2, { className: "h-3.5 w-3.5" }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
                        lineNumber: 148,
                        columnNumber: 25
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
                      lineNumber: 140,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
                  lineNumber: 128,
                  columnNumber: 21
                }, this)
              ]
            },
            rule._id,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
              lineNumber: 120,
              columnNumber: 15
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
          lineNumber: 118,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
        lineNumber: 109,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
      lineNumber: 80,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
    lineNumber: 69,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx",
    lineNumber: 68,
    columnNumber: 5
  }, this);
}
_s(AlertRulesModal, "rzGRUXKCcNl9WQnm8NMWY7fPhaM=", false, function() {
  return [useQuery, useMutation, useMutation, useMutation];
});
_c = AlertRulesModal;
var _c;
$RefreshReg$(_c, "AlertRulesModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AlertRulesModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0RZOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBEWixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsVUFBVUMsbUJBQW1CO0FBQ3RDLFNBQVNDLFdBQVc7QUFFcEI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsTUFBTUMsY0FBYztBQU90QixnQkFBU0MsZ0JBQWdCLEVBQUVDLFdBQVdDLFFBQThCLEdBQUc7QUFBQUMsS0FBQTtBQUM1RSxRQUFNQyxRQUFRakIsU0FBU0UsSUFBSWdCLFdBQVdDLE1BQU0sRUFBRUwsV0FBV0EsYUFBYU0sT0FBVSxDQUFDO0FBQ2pGLFFBQU1DLGFBQWFwQixZQUFZQyxJQUFJZ0IsV0FBV0ksTUFBTTtBQUNwRCxRQUFNQyxhQUFhdEIsWUFBWUMsSUFBSWdCLFdBQVdNLE1BQU07QUFDcEQsUUFBTUMsYUFBYXhCLFlBQVlDLElBQUlnQixXQUFXUSxNQUFNO0FBRXBELFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJN0IsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQzhCLFFBQVFDLFNBQVMsSUFBSS9CLFNBQVMsS0FBSztBQUUxQyxRQUFNZ0MsWUFBWSxZQUFZO0FBQzVCLFVBQU1DLFFBQVFDLE9BQU9OLFNBQVM7QUFDOUIsUUFBSSxDQUFDTSxPQUFPQyxTQUFTRixLQUFLLEtBQUtBLFNBQVMsRUFBRztBQUMzQ0YsY0FBVSxJQUFJO0FBQ2QsUUFBSTtBQUNGLFlBQU1ULFdBQVc7QUFBQSxRQUNmUCxXQUFXQSxhQUFhTTtBQUFBQSxRQUN4QmUsTUFBTTtBQUFBLFFBQ05SLFdBQVdLO0FBQUFBLFFBQ1hJLFNBQVM7QUFBQSxNQUNYLENBQUM7QUFDRFIsbUJBQWEsRUFBRTtBQUFBLElBQ2pCLFVBQUM7QUFDQ0UsZ0JBQVUsS0FBSztBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsVUFBTyxNQUFJLE1BQUMsY0FBYyxDQUFDTyxTQUFTLENBQUNBLFFBQVF0QixRQUFRLEdBQ3BELGlDQUFDLGlCQUFjLFdBQVUsWUFDdkI7QUFBQSwyQkFBQyxnQkFDQztBQUFBLDZCQUFDLGVBQVksV0FBVSwyQkFDckI7QUFBQSwrQkFBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QjtBQUFBO0FBQUEsV0FEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxxQkFBaUIsaUdBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsaUNBQUMsU0FBTSxTQUFRLGFBQVksV0FBVSxpQ0FBK0IsZ0RBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxJQUFHO0FBQUEsY0FDSCxNQUFLO0FBQUEsY0FDTCxLQUFLO0FBQUEsY0FDTCxNQUFNO0FBQUEsY0FDTixhQUFZO0FBQUEsY0FDWixPQUFPWTtBQUFBQSxjQUNQLFVBQVUsQ0FBQ1csTUFBTVYsYUFBYVUsRUFBRUMsT0FBT1AsS0FBSztBQUFBLGNBQzVDLFdBQVcsQ0FBQ00sTUFBTUEsRUFBRUUsUUFBUSxXQUFXVCxVQUFVO0FBQUEsY0FDakQsV0FBVTtBQUFBO0FBQUEsWUFUWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTa0I7QUFBQSxhQWJwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxNQUFLO0FBQUEsWUFDTCxXQUFVO0FBQUEsWUFDVixVQUFVRixVQUFVLENBQUNGLGFBQWFNLE9BQU9OLFNBQVMsS0FBSztBQUFBLFlBQ3ZELFNBQVNJO0FBQUFBLFlBQVU7QUFBQTtBQUFBLFVBTHJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFBO0FBQUEsV0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBCQTtBQUFBLE1BRUEsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFNBQUksV0FBVSxrREFBaUQsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEU7QUFBQSxRQUMzRWQsVUFBVUcsU0FDVCx1QkFBQyxTQUFJLFdBQVUsaUNBQWdDLHdCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVELElBQ3JESCxNQUFNd0IsV0FBVyxJQUNuQix1QkFBQyxTQUFJLFdBQVUsK0ZBQTZGLDhDQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFFQSx1QkFBQyxRQUFHLFdBQVUsYUFDWHhCLGdCQUFNeUI7QUFBQUEsVUFBSSxDQUFDQyxTQUNWO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFVBQUk7QUFBQTtBQUFBLGtCQUNlQSxLQUFLaEIsVUFBVWlCLFFBQVEsQ0FBQztBQUFBLGtCQUN6Q0QsS0FBSzdCLFlBQVksb0JBQW9CO0FBQUEscUJBRnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBUTtBQUFBLHNCQUNSLE1BQUs7QUFBQSxzQkFDTCxXQUFVO0FBQUEsc0JBQ1YsU0FBUyxNQUNQUyxXQUFXLEVBQUVzQixJQUFJRixLQUFLRyxLQUFLVixTQUFTLENBQUNPLEtBQUtQLFFBQVEsQ0FBQztBQUFBLHNCQUdwRE8sZUFBS1AsVUFBVSxZQUFZO0FBQUE7QUFBQSxvQkFUOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVE7QUFBQSxzQkFDUixNQUFLO0FBQUEsc0JBQ0wsV0FBVTtBQUFBLHNCQUNWLFNBQVMsTUFBTVgsV0FBVyxFQUFFb0IsSUFBSUYsS0FBS0csSUFBSSxDQUFDO0FBQUEsc0JBQzFDLGNBQVc7QUFBQSxzQkFFWCxpQ0FBQyxVQUFPLFdBQVUsaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQStCO0FBQUE7QUFBQSxvQkFSakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVNBO0FBQUEscUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBc0JBO0FBQUE7QUFBQTtBQUFBLFlBN0JLSCxLQUFLRztBQUFBQSxZQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUErQkE7QUFBQSxRQUNELEtBbENIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQ0E7QUFBQSxXQTVDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOENBO0FBQUEsU0EzRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRFQTtBQUFBLE9BdkZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3RkEsS0F6RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBGQTtBQUVKO0FBQUM5QixHQXZIZUgsaUJBQWU7QUFBQSxVQUNmYixVQUNLQyxhQUNBQSxhQUNBQSxXQUFXO0FBQUE7QUFBQSxLQUpoQlk7QUFBZSxJQUFBa0M7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VRdWVyeSIsInVzZU11dGF0aW9uIiwiYXBpIiwiRGlhbG9nIiwiRGlhbG9nQ29udGVudCIsIkRpYWxvZ0Rlc2NyaXB0aW9uIiwiRGlhbG9nSGVhZGVyIiwiRGlhbG9nVGl0bGUiLCJCdXR0b24iLCJJbnB1dCIsIkxhYmVsIiwiQmVsbCIsIlRyYXNoMiIsIkFsZXJ0UnVsZXNNb2RhbCIsInByb2plY3RJZCIsIm9uQ2xvc2UiLCJfcyIsInJ1bGVzIiwiYWxlcnRSdWxlcyIsImxpc3QiLCJ1bmRlZmluZWQiLCJjcmVhdGVSdWxlIiwiY3JlYXRlIiwidXBkYXRlUnVsZSIsInVwZGF0ZSIsInJlbW92ZVJ1bGUiLCJyZW1vdmUiLCJ0aHJlc2hvbGQiLCJzZXRUaHJlc2hvbGQiLCJhZGRpbmciLCJzZXRBZGRpbmciLCJoYW5kbGVBZGQiLCJ2YWx1ZSIsIk51bWJlciIsImlzRmluaXRlIiwidHlwZSIsImVuYWJsZWQiLCJvcGVuIiwiZSIsInRhcmdldCIsImtleSIsImxlbmd0aCIsIm1hcCIsInJ1bGUiLCJ0b0ZpeGVkIiwiaWQiLCJfaWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBbGVydFJ1bGVzTW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VRdWVyeSwgdXNlTXV0YXRpb24gfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHtcbiAgRGlhbG9nLFxuICBEaWFsb2dDb250ZW50LFxuICBEaWFsb2dEZXNjcmlwdGlvbixcbiAgRGlhbG9nSGVhZGVyLFxuICBEaWFsb2dUaXRsZSxcbn0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9kaWFsb2dcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvaW5wdXRcIjtcbmltcG9ydCB7IExhYmVsIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9sYWJlbFwiO1xuaW1wb3J0IHsgQmVsbCwgVHJhc2gyIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuXG5pbnRlcmZhY2UgQWxlcnRSdWxlc01vZGFsUHJvcHMge1xuICBwcm9qZWN0SWQ6IElkPFwicHJvamVjdHNcIj4gfCBudWxsO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQWxlcnRSdWxlc01vZGFsKHsgcHJvamVjdElkLCBvbkNsb3NlIH06IEFsZXJ0UnVsZXNNb2RhbFByb3BzKSB7XG4gIGNvbnN0IHJ1bGVzID0gdXNlUXVlcnkoYXBpLmFsZXJ0UnVsZXMubGlzdCwgeyBwcm9qZWN0SWQ6IHByb2plY3RJZCA/PyB1bmRlZmluZWQgfSk7XG4gIGNvbnN0IGNyZWF0ZVJ1bGUgPSB1c2VNdXRhdGlvbihhcGkuYWxlcnRSdWxlcy5jcmVhdGUpO1xuICBjb25zdCB1cGRhdGVSdWxlID0gdXNlTXV0YXRpb24oYXBpLmFsZXJ0UnVsZXMudXBkYXRlKTtcbiAgY29uc3QgcmVtb3ZlUnVsZSA9IHVzZU11dGF0aW9uKGFwaS5hbGVydFJ1bGVzLnJlbW92ZSk7XG5cbiAgY29uc3QgW3RocmVzaG9sZCwgc2V0VGhyZXNob2xkXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbYWRkaW5nLCBzZXRBZGRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IGhhbmRsZUFkZCA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB2YWx1ZSA9IE51bWJlcih0aHJlc2hvbGQpO1xuICAgIGlmICghTnVtYmVyLmlzRmluaXRlKHZhbHVlKSB8fCB2YWx1ZSA8PSAwKSByZXR1cm47XG4gICAgc2V0QWRkaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBjcmVhdGVSdWxlKHtcbiAgICAgICAgcHJvamVjdElkOiBwcm9qZWN0SWQgPz8gdW5kZWZpbmVkLFxuICAgICAgICB0eXBlOiBcImRhaWx5X2Nvc3RfZXhjZWVkZWRcIixcbiAgICAgICAgdGhyZXNob2xkOiB2YWx1ZSxcbiAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgIH0pO1xuICAgICAgc2V0VGhyZXNob2xkKFwiXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRBZGRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxEaWFsb2cgb3BlbiBvbk9wZW5DaGFuZ2U9eyhvcGVuKSA9PiAhb3BlbiAmJiBvbkNsb3NlKCl9PlxuICAgICAgPERpYWxvZ0NvbnRlbnQgY2xhc3NOYW1lPVwibWF4LXctbWRcIj5cbiAgICAgICAgPERpYWxvZ0hlYWRlcj5cbiAgICAgICAgICA8RGlhbG9nVGl0bGUgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxCZWxsIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgQWxlcnQgcnVsZXNcbiAgICAgICAgICA8L0RpYWxvZ1RpdGxlPlxuICAgICAgICAgIDxEaWFsb2dEZXNjcmlwdGlvbj5cbiAgICAgICAgICAgIEdldCBub3RpZmllZCB3aGVuIGRhaWx5IEFQSSBjb3N0IGV4Y2VlZHMgYSB0aHJlc2hvbGQuIFJ1bGVzIGFyZSBldmFsdWF0ZWQgaG91cmx5LlxuICAgICAgICAgIDwvRGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgIDwvRGlhbG9nSGVhZGVyPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00IHB0LTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XG4gICAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwidGhyZXNob2xkXCIgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICBOb3RpZnkgaWYgZGFpbHkgY29zdCBleGNlZWRzICgkKVxuICAgICAgICAgICAgICA8L0xhYmVsPlxuICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICBpZD1cInRocmVzaG9sZFwiXG4gICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgbWluPXswfVxuICAgICAgICAgICAgICAgIHN0ZXA9ezF9XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIDUwXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17dGhyZXNob2xkfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGhyZXNob2xkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBvbktleURvd249eyhlKSA9PiBlLmtleSA9PT0gXCJFbnRlclwiICYmIGhhbmRsZUFkZCgpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTFcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC02XCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2FkZGluZyB8fCAhdGhyZXNob2xkIHx8IE51bWJlcih0aHJlc2hvbGQpIDw9IDB9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUFkZH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgQWRkXG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIG1iLTJcIj5BY3RpdmUgcnVsZXM8L2Rpdj5cbiAgICAgICAgICAgIHtydWxlcyA9PT0gdW5kZWZpbmVkID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+TG9hZGluZ+KApjwvZGl2PlxuICAgICAgICAgICAgKSA6IHJ1bGVzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZGFzaGVkIGJvcmRlci1ib3JkZXIgcC00IHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgTm8gYWxlcnQgcnVsZXMuIEFkZCBvbmUgYWJvdmUuXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgIHtydWxlcy5tYXAoKHJ1bGUpID0+IChcbiAgICAgICAgICAgICAgICAgIDxsaVxuICAgICAgICAgICAgICAgICAgICBrZXk9e3J1bGUuX2lkfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1tdXRlZC8yMCBweC0zIHB5LTIgdGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIERhaWx5IGNvc3QgJmd0OyAke3J1bGUudGhyZXNob2xkLnRvRml4ZWQoMCl9XG4gICAgICAgICAgICAgICAgICAgICAge3J1bGUucHJvamVjdElkID8gXCIgKHRoaXMgcHJvamVjdClcIiA6IFwiIChhbGwpXCJ9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTcgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVSdWxlKHsgaWQ6IHJ1bGUuX2lkLCBlbmFibGVkOiAhcnVsZS5lbmFibGVkIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAge3J1bGUuZW5hYmxlZCA/IFwiRGlzYWJsZVwiIDogXCJFbmFibGVcIn1cbiAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC03IHRleHQtZGVzdHJ1Y3RpdmUgaG92ZXI6dGV4dC1kZXN0cnVjdGl2ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiByZW1vdmVSdWxlKHsgaWQ6IHJ1bGUuX2lkIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkRlbGV0ZSBydWxlXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0RpYWxvZ0NvbnRlbnQ+XG4gICAgPC9EaWFsb2c+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9BbGVydFJ1bGVzTW9kYWwudHN4In0=