import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/controlPlane/WorkOrdersView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$(), _s7 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { Badge } from "/src/components/ui/badge.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Card } from "/src/components/ui/card.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "/src/components/ui/dialog.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
import { Textarea } from "/src/components/ui/textarea.tsx";
import { PageHeader } from "/src/components/PageHeader.tsx";
import { ArrowLeft, ClipboardList, ExternalLink, PlayCircle, Plus, ShieldCheck, Sparkles, TriangleAlert } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import {
  countByQuickFilter,
  DEFAULT_WORK_ORDER_FILTERS,
  deriveNextAction,
  filterWorkOrders,
  summarizeRequiredAttention
} from "/src/controlPlane/workOrdersModel.ts";
import { ExecutionRunInspector } from "/src/controlPlane/ExecutionRunInspector.tsx";
import { splitCurrentAndHistoricalRevisions, summarizeRevisionEffects } from "/src/controlPlane/workOrderLifecycleModel.ts";
const RISK_STYLES = {
  LOW: "border-emerald-500/30 text-emerald-300",
  MEDIUM: "border-registry-accent/30 text-registry-accent",
  HIGH: "border-amber-500/30 text-amber-300",
  CRITICAL: "border-red-500/30 text-red-300"
};
const STATE_STYLES = {
  DRAFT: "border-border text-muted-foreground",
  READY: "border-registry-accent/30 text-registry-accent",
  DISPATCHED: "border-registry-accent/30 text-registry-accent",
  IN_PROGRESS: "border-primary/30 text-primary",
  BLOCKED: "border-red-500/30 text-red-300",
  AWAITING_APPROVAL: "border-amber-500/30 text-amber-300",
  AWAITING_VERIFICATION: "border-amber-500/30 text-amber-300",
  REOPENED: "border-purple-500/30 text-purple-200",
  DONE: "border-emerald-500/30 text-emerald-300",
  CANCELED: "border-border text-muted-foreground",
  SUPERSEDED: "border-slate-500/30 text-slate-300"
};
const QUICK_FILTERS = [
  { id: "all", label: "All" },
  { id: "needs_attention", label: "Needs attention" },
  { id: "blocked", label: "Blocked" },
  { id: "awaiting_approval", label: "Awaiting approval" },
  { id: "ready_to_dispatch", label: "Ready to dispatch" }
];
function prettyLabel(value) {
  if (!value) return "—";
  return value.replace(/_/g, " ");
}
function criteriaFromText(value, existingCriteria = []) {
  return value.split("\n").map((line) => line.trim()).filter(Boolean).map((title, index) => {
    const existing = existingCriteria[index];
    return {
      id: existing?.id ?? `ac-${index + 1}`,
      title,
      description: existing?.description,
      verificationMethod: existing?.verificationMethod ?? "MANUAL",
      status: "PENDING"
    };
  });
}
function latestByCriterion(receipts) {
  const latest = /* @__PURE__ */ new Map();
  [...receipts].sort((a, b) => b.recordedAt - a.recordedAt).forEach((receipt) => {
    if (!latest.has(receipt.acceptanceCriterionId)) latest.set(receipt.acceptanceCriterionId, receipt);
  });
  return latest;
}
export function WorkOrdersView({ projectId }) {
  _s();
  const [filters, setFilters] = useState(DEFAULT_WORK_ORDER_FILTERS);
  const [selectedId, setSelectedId] = useState(null);
  const [mobileDetailOpen, setMobileDetailOpen] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [approvalOpen, setApprovalOpen] = useState(false);
  const [receiptOpen, setReceiptOpen] = useState(false);
  const [revisionOpen, setRevisionOpen] = useState(false);
  const [reopenOpen, setReopenOpen] = useState(false);
  const [supersedeOpen, setSupersedeOpen] = useState(false);
  const [createRequestKey, setCreateRequestKey] = useState(null);
  const [dispatchingId, setDispatchingId] = useState(null);
  const [acceptingId, setAcceptingId] = useState(null);
  const [revisingId, setRevisingId] = useState(null);
  const [reopeningId, setReopeningId] = useState(null);
  const [supersedingId, setSupersedingId] = useState(null);
  const [inspectorRunId, setInspectorRunId] = useState(null);
  const [inspectorReceiptId, setInspectorReceiptId] = useState(null);
  const [inspectorCriterionId, setInspectorCriterionId] = useState(null);
  const [dispatchError, setDispatchError] = useState(null);
  const [governanceError, setGovernanceError] = useState(null);
  const [creating, setCreating] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [error, setError] = useState(null);
  const workOrders = useQuery(api.workOrders.list, projectId ? { projectId } : {});
  const selected = useQuery(
    api.workOrders.get,
    selectedId ? { workOrderId: selectedId } : "skip"
  );
  const createWorkOrder = useMutation(api.workOrders.create);
  const dispatchWorkOrder = useMutation(api.workOrders.dispatch);
  const requestApprovalDecision = useMutation(api.workOrders.requestApprovalDecision);
  const recordVerificationReceipt = useMutation(api.workOrders.recordVerificationReceipt);
  const acceptWorkOrder = useMutation(api.workOrders.accept);
  const requestWorkOrderRevision = useMutation(api.workOrders.requestWorkOrderRevision);
  const approveWorkOrderRevision = useMutation(api.workOrders.approveWorkOrderRevision);
  const reopenWorkOrder = useMutation(api.workOrders.reopenWorkOrder);
  const supersedeWorkOrder = useMutation(api.workOrders.supersedeWorkOrder);
  const expireGovernanceRecords = useMutation(api.workOrders.expireGovernanceRecords);
  const seedDemo = useMutation(api.workOrders.seedDemo);
  const filtered = useMemo(() => filterWorkOrders(workOrders ?? [], filters), [workOrders, filters]);
  useEffect(() => {
    if (filtered.length === 0) {
      setSelectedId(null);
      setMobileDetailOpen(false);
      return;
    }
    if (!selectedId && filtered.length > 0) {
      setSelectedId(filtered[0]._id);
    }
    if (selectedId && filtered.length > 0 && !filtered.some((item) => item._id === selectedId)) {
      setSelectedId(filtered[0]._id);
    }
  }, [filtered, selectedId]);
  const repositories = useMemo(
    () => Array.from(new Set((workOrders ?? []).map((item) => item.repository).filter(Boolean))).sort(),
    [workOrders]
  );
  const assignedAgents = useMemo(
    () => Array.from(new Set((workOrders ?? []).map((item) => item.assignedAgent).filter(Boolean))).sort(),
    [workOrders]
  );
  const requestors = useMemo(
    () => Array.from(new Set((workOrders ?? []).map((item) => item.requestedBy).filter(Boolean))).sort(),
    [workOrders]
  );
  const counts = useMemo(() => {
    const rows = workOrders ?? [];
    return {
      total: rows.length,
      active: rows.filter((row) => ["READY", "DISPATCHED", "IN_PROGRESS", "AWAITING_APPROVAL", "AWAITING_VERIFICATION", "REOPENED"].includes(row.state)).length,
      blocked: rows.filter((row) => row.state === "BLOCKED").length,
      attention: rows.filter((row) => !!row.requiredHumanAction || ["PENDING", "REVISION_REQUESTED"].includes(row.approvalStatus) || ["FAIL", "STALE"].includes(row.verificationStatus)).length
    };
  }, [workOrders]);
  const quickFilterCounts = useMemo(() => {
    const rows = workOrders ?? [];
    return Object.fromEntries(
      QUICK_FILTERS.map((filter) => [filter.id, filter.id === "all" ? rows.length : countByQuickFilter(rows, filter.id)])
    );
  }, [workOrders]);
  async function handleSeed() {
    setSeeding(true);
    try {
      await seedDemo({});
    } finally {
      setSeeding(false);
    }
  }
  const canDispatchSelected = !!selected && ["READY", "BLOCKED", "DISPATCHED", "IN_PROGRESS", "REOPENED", "AWAITING_APPROVAL", "AWAITING_VERIFICATION"].includes(selected.workOrder.state) && !!selected.workOrder.workflowId && (selected.workOrder.approvalStatus === "APPROVED" || selected.workOrder.approvalStatus === "CONDITIONAL" || selected.workOrder.approvalStatus === "NOT_REQUIRED") && !selected.executionRuns.some((run) => ["PENDING", "RUNNING", "PAUSED"].includes(run.status));
  const canAcceptSelected = !!selected && !["DONE", "SUPERSEDED", "CANCELED"].includes(selected.workOrder.state) && !selected.executionRuns.some((run) => ["PENDING", "RUNNING", "PAUSED"].includes(run.status)) && selected.executionRuns[0]?.status === "COMPLETED" && selected.acceptanceSummary?.eligible;
  const latestReceiptMap = useMemo(
    () => latestByCriterion((selected?.verificationReceipts ?? []).map((receipt) => ({
      ...receipt,
      recordedAt: receipt.recordedAt ?? receipt._creationTime ?? 0
    }))),
    [selected]
  );
  const revisionSplit = useMemo(
    () => splitCurrentAndHistoricalRevisions(selected?.revisions ?? [], selected?.workOrder.currentRevisionId),
    [selected]
  );
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-full min-h-0 flex-col overflow-hidden", children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        eyebrow: "Software factory",
        title: "Work Orders",
        description: "Requested outcomes, acceptance criteria, and governed execution in one queue.",
        icon: /* @__PURE__ */ jsxDEV(ClipboardList, { className: "h-5 w-5" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 244,
          columnNumber: 15
        }, this),
        actions: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "outline", size: "sm", onClick: handleSeed, disabled: seeding, children: [
            /* @__PURE__ */ jsxDEV(Sparkles, { className: "mr-1.5 h-3.5 w-3.5" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 248,
              columnNumber: 15
            }, this),
            seeding ? "Seeding…" : "Seed demo"
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 247,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "sm", onClick: () => {
            setCreateRequestKey(globalThis.crypto?.randomUUID?.() ?? `work-order-${Date.now()}`);
            setCreateOpen(true);
          }, children: [
            /* @__PURE__ */ jsxDEV(Plus, { className: "mr-1.5 h-3.5 w-3.5" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 255,
              columnNumber: 15
            }, this),
            "New WorkOrder"
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 251,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 246,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 240,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "min-h-0 flex-1 overflow-y-auto p-5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3 lg:grid-cols-4", children: [
        /* @__PURE__ */ jsxDEV(StatCard, { label: "WorkOrders", value: counts.total }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 264,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(StatCard, { label: "Active", value: counts.active }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 265,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(StatCard, { label: "Blocked", value: counts.blocked, tone: counts.blocked > 0 ? "bad" : "default" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 266,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(StatCard, { label: "Needs attention", value: counts.attention, tone: counts.attention > 0 ? "warn" : "good" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 267,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 263,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex flex-wrap gap-2", children: QUICK_FILTERS.map((filter) => {
        const active = filters.quickFilter === filter.id;
        return /* @__PURE__ */ jsxDEV(
          Button,
          {
            size: "sm",
            variant: active ? "default" : "outline",
            onClick: () => setFilters((current) => ({ ...current, quickFilter: filter.id })),
            className: "gap-2",
            children: [
              filter.label,
              /* @__PURE__ */ jsxDEV("span", { className: "rounded-full bg-background/20 px-1.5 py-0.5 text-[11px] leading-none", children: quickFilterCounts[filter.id] ?? 0 }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 282,
                columnNumber: 17
              }, this)
            ]
          },
          filter.id,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 274,
            columnNumber: 15
          },
          this
        );
      }) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 270,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 grid gap-3 rounded-xl border border-[var(--panel-line)] bg-card/40 p-4 lg:grid-cols-6", children: [
        /* @__PURE__ */ jsxDEV(FilterSelect, { label: "Repository", value: filters.repository, onChange: (value) => setFilters((current) => ({ ...current, repository: value })), options: repositories }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 291,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(FilterSelect, { label: "State", value: filters.state, onChange: (value) => setFilters((current) => ({ ...current, state: value })), options: ["READY", "DISPATCHED", "IN_PROGRESS", "BLOCKED", "AWAITING_APPROVAL", "AWAITING_VERIFICATION", "REOPENED", "DONE", "SUPERSEDED"] }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 292,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(FilterSelect, { label: "Risk", value: filters.riskLevel, onChange: (value) => setFilters((current) => ({ ...current, riskLevel: value })), options: ["LOW", "MEDIUM", "HIGH", "CRITICAL"] }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 293,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(FilterSelect, { label: "Assigned", value: filters.assignedAgent, onChange: (value) => setFilters((current) => ({ ...current, assignedAgent: value })), options: assignedAgents }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 294,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(FilterSelect, { label: "Requested by", value: filters.requestedBy, onChange: (value) => setFilters((current) => ({ ...current, requestedBy: value })), options: requestors }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 295,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(FilterSelect, { label: "Verification", value: filters.verificationStatus, onChange: (value) => setFilters((current) => ({ ...current, verificationStatus: value })), options: ["PENDING", "PASS", "FAIL", "WAIVED", "STALE"] }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 296,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 290,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 grid gap-4 xl:grid-cols-[minmax(0,0.95fr)_minmax(360px,1.05fr)]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: `${mobileDetailOpen ? "hidden xl:block" : "block"} space-y-3`, children: filtered.length === 0 ? /* @__PURE__ */ jsxDEV(Card, { className: "p-8 text-center text-sm text-muted-foreground", children: "No work orders match the current filters." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 302,
          columnNumber: 13
        }, this) : filtered.map((item) => {
          const selectedRow = item._id === selectedId;
          return /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => {
                setSelectedId(item._id);
                setMobileDetailOpen(true);
              },
              "aria-label": `${item.title} — next action: ${deriveNextAction(item)}`,
              className: `w-full rounded-xl border p-4 text-left transition-colors ${selectedRow ? "border-registry-accent/40 bg-registry-accent-soft" : "border-[var(--panel-line)] bg-card/40 hover:border-registry-accent/20"}`,
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-foreground", children: item.title }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 321,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground line-clamp-2", children: item.desiredOutcome }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 322,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 320,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", className: RISK_STYLES[item.riskLevel] ?? "", children: item.riskLevel }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 324,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 319,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex flex-wrap gap-2", children: [
                  /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", className: STATE_STYLES[item.state] ?? "", children: prettyLabel(item.state) }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 328,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: item.repository ?? "No repo" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 329,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: [
                    "Workflow: ",
                    item.workflowId ?? "—"
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 330,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: [
                    "Verification: ",
                    item.verificationStatus
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 331,
                    columnNumber: 23
                  }, this),
                  item.metadata?.automationDefinitionId ? /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", className: "border-registry-accent/30 text-registry-accent", children: "Automation review gate" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 332,
                    columnNumber: 64
                  }, this) : null,
                  item.latestExecutionRun ? /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: [
                    "Run: ",
                    item.latestExecutionRun.status,
                    " · ",
                    item.latestExecutionRun.workflowId
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 334,
                    columnNumber: 21
                  }, this) : null
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 327,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-3 grid gap-2 text-xs text-muted-foreground md:grid-cols-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/80", children: "Assigned:" }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 342,
                      columnNumber: 25
                    }, this),
                    " ",
                    item.assignedAgent ?? item.assignedSquad ?? "Unassigned"
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 341,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/80", children: "Requestor:" }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 345,
                      columnNumber: 25
                    }, this),
                    " ",
                    item.requestedBy ?? "Unknown"
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 344,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/80", children: "Next action:" }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 348,
                      columnNumber: 25
                    }, this),
                    " ",
                    deriveNextAction(item)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 347,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2 truncate", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/80", children: "Attention:" }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 351,
                      columnNumber: 25
                    }, this),
                    " ",
                    summarizeRequiredAttention(item)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 350,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 340,
                  columnNumber: 21
                }, this)
              ]
            },
            item._id,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 309,
              columnNumber: 17
            },
            this
          );
        }) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 300,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: `${mobileDetailOpen ? "block" : "hidden xl:block"} min-h-[420px] p-5`, children: !selected ? /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-muted-foreground", children: "Select a work order to inspect requested outcome, criteria, and linked execution." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 362,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-5", children: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "sm",
              variant: "outline",
              className: "xl:hidden",
              onClick: () => setMobileDetailOpen(false),
              children: [
                /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "mr-1.5 h-3.5 w-3.5" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 371,
                  columnNumber: 19
                }, this),
                "Back to work orders"
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 365,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-start justify-between gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-semibold text-foreground", children: selected.workOrder.title }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 377,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-sm text-muted-foreground", children: selected.workOrder.repository ?? "No repository declared" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 378,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 376,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: [
                /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", className: RISK_STYLES[selected.workOrder.riskLevel] ?? "", children: selected.workOrder.riskLevel }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 381,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", className: STATE_STYLES[selected.workOrder.state] ?? "", children: prettyLabel(selected.workOrder.state) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 382,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 380,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 375,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex flex-wrap gap-2", children: [
              /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => {
                setGovernanceError(null);
                setRevisionOpen(true);
              }, children: "Request revision" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 386,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => {
                setGovernanceError(null);
                setReopenOpen(true);
              }, disabled: ["SUPERSEDED", "CANCELED"].includes(selected.workOrder.state), children: "Reopen" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 387,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", onClick: async () => {
                try {
                  setGovernanceError(null);
                  await expireGovernanceRecords({ workOrderId: selected.workOrder._id });
                } catch (err) {
                  setGovernanceError(err instanceof Error ? err.message : "Failed to expire governance records");
                }
              }, children: "Refresh governance" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 388,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => {
                setGovernanceError(null);
                setSupersedeOpen(true);
              }, disabled: selected.workOrder.state === "SUPERSEDED", children: "Supersede" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 396,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 385,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 374,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Section, { title: "Outcome", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm leading-relaxed text-foreground/85", children: selected.workOrder.desiredOutcome }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 401,
              columnNumber: 19
            }, this),
            selected.workOrder.context ? /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-sm leading-relaxed text-muted-foreground", children: selected.workOrder.context }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 403,
              columnNumber: 17
            }, this) : null
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 400,
            columnNumber: 17
          }, this),
          selected.workOrder.metadata?.automationDefinitionId ? /* @__PURE__ */ jsxDEV(Section, { title: "Automation lineage", children: [
            /* @__PURE__ */ jsxDEV("dl", { className: "grid gap-3 text-sm md:grid-cols-2", children: [
              /* @__PURE__ */ jsxDEV(MetaRow, { label: "Automation", value: selected.workOrder.metadata.automationDefinitionId }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 410,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(MetaRow, { label: "Workflow version", value: selected.workOrder.metadata.automationWorkflowVersion }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 411,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(MetaRow, { label: "Cadence", value: selected.workOrder.metadata.automationCadence?.cron }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 412,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(MetaRow, { label: "Scope", value: selected.workOrder.metadata.automationScope }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 413,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 409,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-xs text-muted-foreground", children: "This read-only WorkOrder requires normal approval and explicit dispatch. The originating Automation cannot approve it." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 415,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 408,
            columnNumber: 15
          }, this) : null,
          /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 md:grid-cols-2", children: [
            /* @__PURE__ */ jsxDEV(Section, { title: "Execution setup", children: /* @__PURE__ */ jsxDEV("dl", { className: "space-y-2 text-sm", children: [
              /* @__PURE__ */ jsxDEV(MetaRow, { label: "Branch / worktree strategy", value: selected.workOrder.branchStrategy }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 424,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(MetaRow, { label: "Workflow", value: selected.workOrder.workflowId }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 425,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(MetaRow, { label: "Assigned", value: selected.workOrder.assignedAgent ?? selected.workOrder.assignedSquad }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 426,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(MetaRow, { label: "Requested by", value: selected.workOrder.requestedBy }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 427,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(MetaRow, { label: "Approval", value: selected.workOrder.approvalStatus }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 428,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(MetaRow, { label: "Verification", value: selected.workOrder.verificationStatus }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 429,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 423,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 422,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Section, { title: "Required attention", children: [
              selected.workOrder.requiredHumanAction ? /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-amber-100", children: selected.workOrder.requiredHumanAction }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 434,
                columnNumber: 19
              }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "No active human action recorded." }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 436,
                columnNumber: 19
              }, this),
              selected.workOrder.blockingIssue ? /* @__PURE__ */ jsxDEV("div", { className: "mt-3 rounded-lg border border-red-500/20 bg-red-500/5 px-3 py-2 text-sm text-red-200", children: [
                /* @__PURE__ */ jsxDEV(TriangleAlert, { className: "mr-2 inline h-4 w-4" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 440,
                  columnNumber: 25
                }, this),
                selected.workOrder.blockingIssue
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 439,
                columnNumber: 19
              }, this) : null
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 432,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 421,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Section, { title: "Acceptance readiness", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "grid gap-3 md:grid-cols-2 xl:grid-cols-4", children: [
              /* @__PURE__ */ jsxDEV(Card, { className: "p-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground", children: "Approval status" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 450,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-lg font-semibold text-foreground", children: selected.workOrder.approvalStatus }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 451,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 449,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Card, { className: "p-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground", children: "Verification status" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 454,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-lg font-semibold text-foreground", children: selected.workOrder.verificationStatus }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 455,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 453,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Card, { className: "p-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground", children: "Missing approvals" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 458,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-lg font-semibold text-amber-300", children: selected.acceptanceSummary?.missingApprovalTypes?.length ?? 0 }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 459,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 457,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Card, { className: "p-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground", children: "Criteria blocked" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 462,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-lg font-semibold text-red-300", children: (selected.acceptanceSummary?.failedCriteriaIds?.length ?? 0) + (selected.acceptanceSummary?.staleCriteriaIds?.length ?? 0) + (selected.acceptanceSummary?.missingCriteriaIds?.length ?? 0) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 463,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 461,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 448,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-3 rounded-xl border border-[var(--panel-line)] bg-background/40 p-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "mb-2 flex items-center justify-between gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-foreground", children: "Why this WorkOrder is blocked from acceptance" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 469,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: [
                  /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => {
                    setGovernanceError(null);
                    setApprovalOpen(true);
                  }, children: [
                    /* @__PURE__ */ jsxDEV(ShieldCheck, { className: "mr-1.5 h-3.5 w-3.5" }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 472,
                      columnNumber: 27
                    }, this),
                    "Request approval"
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 471,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => {
                    setGovernanceError(null);
                    setReceiptOpen(true);
                  }, children: "Record receipt" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 475,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      size: "sm",
                      onClick: async () => {
                        try {
                          setGovernanceError(null);
                          setAcceptingId(selected.workOrder._id);
                          await acceptWorkOrder({
                            workOrderId: selected.workOrder._id,
                            actorType: "HUMAN",
                            actorId: "operator",
                            idempotencyKey: `ui-accept:${selected.workOrder._id}:${selected.workOrder.updatedAt}`
                          });
                        } catch (err) {
                          setGovernanceError(err instanceof Error ? err.message : "Acceptance failed");
                        } finally {
                          setAcceptingId(null);
                        }
                      },
                      disabled: !canAcceptSelected || acceptingId === selected.workOrder._id,
                      children: acceptingId === selected.workOrder._id ? "Accepting…" : "Accept WorkOrder"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 478,
                      columnNumber: 25
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 470,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 468,
                columnNumber: 21
              }, this),
              governanceError ? /* @__PURE__ */ jsxDEV("div", { className: "mb-3 text-xs text-red-300", children: governanceError }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 502,
                columnNumber: 40
              }, this) : null,
              (selected.acceptanceSummary?.blockingReasons?.length ?? 0) > 0 ? /* @__PURE__ */ jsxDEV("ul", { className: "list-disc space-y-1 pl-5 text-sm text-muted-foreground", children: selected.acceptanceSummary.blockingReasons.map(
                (reason, index) => /* @__PURE__ */ jsxDEV("li", { children: reason }, `${selected.workOrder._id}-blocker-${index}`, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 506,
                  columnNumber: 21
                }, this)
              ) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 504,
                columnNumber: 19
              }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-emerald-300", children: "All required approvals and verification receipts are present. Explicit acceptance is now allowed." }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 510,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 467,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 447,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Section, { title: "Approval decisions", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: selected.approvalDecisions?.length ? selected.approvalDecisions.map(
            (approval) => /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-[var(--panel-line)] bg-background/30 px-3 py-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-foreground", children: approval.approvalType }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 521,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: approval.requestedAction }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 522,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 520,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: approval.status }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 524,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 519,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-2 grid gap-2 text-xs text-muted-foreground md:grid-cols-2", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  "Risk: ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: approval.riskLevel }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 527,
                    columnNumber: 38
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 527,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  "Requested by: ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: approval.requestedBy ?? "—" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 528,
                    columnNumber: 46
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 528,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  "Approver: ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: approval.approver ?? "—" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 529,
                    columnNumber: 42
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 529,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  "Decided: ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: approval.decidedAt ? new Date(approval.decidedAt).toLocaleString() : "—" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 530,
                    columnNumber: 41
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 530,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 526,
                columnNumber: 25
              }, this),
              approval.reason ? /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-xs text-muted-foreground", children: [
                "Reason: ",
                approval.reason
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 532,
                columnNumber: 44
              }, this) : null,
              approval.conditions?.length ? /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-xs text-registry-accent", children: [
                "Conditions: ",
                approval.conditions.join("; ")
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 533,
                columnNumber: 56
              }, this) : null
            ] }, approval._id, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 518,
              columnNumber: 19
            }, this)
          ) : /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "No approval decisions recorded yet." }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 536,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 516,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 515,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Section, { title: "Governance status", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "grid gap-3 md:grid-cols-2 xl:grid-cols-4", children: [
              /* @__PURE__ */ jsxDEV(Card, { className: "p-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground", children: "Current revision" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 544,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-lg font-semibold text-foreground", children: [
                  "r",
                  selected.workOrder.currentRevisionNumber ?? 1
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 545,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 543,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Card, { className: "p-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground", children: "Expiring approvals" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 548,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-lg font-semibold text-amber-300", children: selected.governanceStatus?.expiringApprovals?.length ?? 0 }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 549,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 547,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Card, { className: "p-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground", children: "Expired approvals" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 552,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-lg font-semibold text-red-300", children: selected.governanceStatus?.expiredApprovals?.length ?? 0 }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 553,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 551,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Card, { className: "p-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground", children: "Stale receipts" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 556,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-lg font-semibold text-red-300", children: selected.governanceStatus?.staleReceipts?.length ?? 0 }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 557,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 555,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 542,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-3 rounded-xl border border-[var(--panel-line)] bg-background/30 p-4 text-sm text-muted-foreground", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                "Required reapproval: ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: selected.governanceStatus?.requiredReapproval ? "Yes" : "No" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 561,
                  columnNumber: 47
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 561,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-1", children: [
                "Required reverification: ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: selected.governanceStatus?.requiredReverification ? "Yes" : "No" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 562,
                  columnNumber: 68
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 562,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-1", children: [
                "Latest accepted revision: ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: selected.governanceStatus?.acceptedRevisionNumber ? `r${selected.governanceStatus.acceptedRevisionNumber}` : "—" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 563,
                  columnNumber: 69
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 563,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: [
                "Blocking reason: ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: selected.governanceStatus?.blockingReasons?.[0] ?? "—" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 564,
                  columnNumber: 60
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 564,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 560,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 541,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Section, { title: "Revision history", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            revisionSplit.current ? /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-registry-accent/30 bg-registry-accent-soft px-3 py-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-foreground", children: [
                    "Current revision r",
                    revisionSplit.current.revisionNumber
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 574,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: revisionSplit.current.changeSummary }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 575,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 573,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: revisionSplit.current.status }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 578,
                    columnNumber: 29
                  }, this),
                  revisionSplit.current.status === "PENDING_APPROVAL" ? /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      size: "sm",
                      variant: "outline",
                      onClick: async () => {
                        try {
                          setGovernanceError(null);
                          setRevisingId(revisionSplit.current._id);
                          await approveWorkOrderRevision({ workOrderRevisionId: revisionSplit.current._id, approvedBy: "operator" });
                        } catch (err) {
                          setGovernanceError(err instanceof Error ? err.message : "Failed to approve revision");
                        } finally {
                          setRevisingId(null);
                        }
                      },
                      disabled: revisingId === revisionSplit.current._id,
                      children: revisingId === revisionSplit.current._id ? "Applying…" : "Approve & apply"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 580,
                      columnNumber: 25
                    },
                    this
                  ) : null
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 577,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 572,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-xs text-muted-foreground", children: summarizeRevisionEffects(revisionSplit.current) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 601,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 571,
              columnNumber: 19
            }, this) : null,
            revisionSplit.historical.length ? revisionSplit.historical.map(
              (revision) => /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-[var(--panel-line)] bg-background/30 px-3 py-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-foreground", children: [
                      "Historical revision r",
                      revision.revisionNumber
                    ] }, void 0, true, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 608,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: revision.changeSummary }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 609,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 607,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: revision.status }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 612,
                      columnNumber: 29
                    }, this),
                    revision.status === "PENDING_APPROVAL" ? /* @__PURE__ */ jsxDEV(
                      Button,
                      {
                        size: "sm",
                        variant: "outline",
                        onClick: async () => {
                          try {
                            setGovernanceError(null);
                            setRevisingId(revision._id);
                            await approveWorkOrderRevision({ workOrderRevisionId: revision._id, approvedBy: "operator" });
                          } catch (err) {
                            setGovernanceError(err instanceof Error ? err.message : "Failed to approve revision");
                          } finally {
                            setRevisingId(null);
                          }
                        },
                        disabled: revisingId === revision._id,
                        children: revisingId === revision._id ? "Applying…" : "Approve & apply"
                      },
                      void 0,
                      false,
                      {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                        lineNumber: 614,
                        columnNumber: 25
                      },
                      this
                    ) : null
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 611,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 606,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-xs text-muted-foreground", children: [
                  "Changed: ",
                  revision.changedFields.join(", ") || "—"
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 635,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: [
                  "Impact: ",
                  summarizeRevisionEffects(revision)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 636,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: [
                  "Actor: ",
                  revision.approvedBy ?? revision.requestedBy ?? "—",
                  " · ",
                  revision.effectiveAt ? new Date(revision.effectiveAt).toLocaleString() : new Date(revision.createdAt).toLocaleString()
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 637,
                  columnNumber: 25
                }, this)
              ] }, revision._id, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 605,
                columnNumber: 19
              }, this)
            ) : /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "No historical revisions yet." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 640,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 569,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 568,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Section, { title: "Reopen and replacement lineage", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 text-sm text-muted-foreground", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              "Prior accepted revision: ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: selected.governanceStatus?.latestAcceptedRevision ? `r${selected.governanceStatus.latestAcceptedRevision.revisionNumber}` : "—" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 647,
                columnNumber: 51
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 647,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              "Reopen reason: ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: selected.reopenDecisions?.[0]?.reason ?? "—" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 648,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 648,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              "Source defect / issue: ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: selected.reopenDecisions?.[0]?.sourceIssueOrDefect ?? "—" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 649,
                columnNumber: 49
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 649,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              "Invalidated evidence: ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: selected.reopenDecisions?.[0]?.invalidatedReceiptIds?.length ?? 0 }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 650,
                columnNumber: 48
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 650,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              "Replacement WorkOrder: ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: selected.supersession?.replacementWorkOrderId ?? selected.workOrder.supersededByWorkOrderId ?? "—" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 651,
                columnNumber: 49
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 651,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 646,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 645,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Section, { title: "Verification traceability matrix", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: selected.workOrder.acceptanceCriteria.map((criterion) => {
            const receipt = latestReceiptMap.get(criterion.id);
            const blockingReason = receipt?.status === "FAILED" ? "Latest receipt failed" : receipt?.status === "STALE" ? "Superseded by newer execution evidence" : receipt?.status === "WAIVED" && !receipt.waiverApprovalDecisionId ? "Waiver approval missing" : !receipt ? "Missing verification receipt" : "—";
            return /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-[var(--panel-line)] bg-background/30 px-3 py-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-foreground", children: criterion.title }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 672,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: [
                    "Method: ",
                    criterion.verificationMethod ?? "MANUAL"
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 673,
                    columnNumber: 31
                  }, this),
                  criterion.description ? /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: criterion.description }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 674,
                    columnNumber: 56
                  }, this) : null
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 671,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: receipt?.status ?? "MISSING" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 676,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 670,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-3 grid gap-2 text-xs text-muted-foreground md:grid-cols-2 xl:grid-cols-4", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  "Evidence: ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: receipt?.evidenceLocation ?? receipt?.artifactReference ?? "—" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 679,
                    columnNumber: 44
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 679,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  "Run: ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: selected.executionRuns.find((run) => run._id === receipt?.workflowRunId)?.runId ?? "—" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 680,
                    columnNumber: 39
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 680,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  "Verifier: ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: receipt?.verifier ?? "—" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 681,
                    columnNumber: 44
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 681,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  "Timestamp: ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: receipt?.recordedAt ? new Date(receipt.recordedAt).toLocaleString() : "—" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 682,
                    columnNumber: 45
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 682,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 678,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-2 grid gap-2 text-xs text-muted-foreground md:grid-cols-2", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  "Waiver / exception: ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: receipt?.exceptionOrWaiver ?? "—" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 685,
                    columnNumber: 54
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 685,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  "Blocking reason: ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: blockingReason }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 686,
                    columnNumber: 51
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 686,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 684,
                columnNumber: 27
              }, this),
              receipt?.commandOrCheck ? /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-xs text-muted-foreground", children: [
                "Check: ",
                receipt.commandOrCheck
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 688,
                columnNumber: 54
              }, this) : null,
              receipt?.result ? /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: [
                "Result: ",
                receipt.result
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 689,
                columnNumber: 46
              }, this) : null,
              /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex flex-wrap gap-2", children: /* @__PURE__ */ jsxDEV(
                Button,
                {
                  size: "sm",
                  variant: "outline",
                  disabled: !receipt?.workflowRunId,
                  onClick: () => {
                    setInspectorRunId(receipt?.workflowRunId ?? null);
                    setInspectorReceiptId(receipt?._id ?? null);
                    setInspectorCriterionId(receipt?.acceptanceCriterionId ?? criterion.id);
                  },
                  children: "Inspect evidence"
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 691,
                  columnNumber: 29
                },
                this
              ) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 690,
                columnNumber: 27
              }, this)
            ] }, criterion.id, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 669,
              columnNumber: 23
            }, this);
          }) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 656,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 655,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Section, { title: "Source of truth", children: selected.workOrder.sourceOfTruthRefs?.length ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: selected.workOrder.sourceOfTruthRefs.map(
            (ref) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-3 rounded-lg border border-[var(--panel-line)] px-3 py-2 text-sm", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-foreground", children: ref.label }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 716,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-muted-foreground", children: [
                  ref.kind,
                  " · ",
                  ref.location
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 717,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 715,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(ExternalLink, { className: "h-3.5 w-3.5 text-muted-foreground" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 719,
                columnNumber: 27
              }, this)
            ] }, `${ref.kind}-${ref.location}`, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 714,
              columnNumber: 19
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 712,
            columnNumber: 17
          }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "No source-of-truth references declared." }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 724,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 710,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Section, { title: "Linked execution runs", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex justify-end", children: /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "sm",
                onClick: async () => {
                  try {
                    setDispatchError(null);
                    setDispatchingId(selected.workOrder._id);
                    const result = await dispatchWorkOrder({
                      workOrderId: selected.workOrder._id,
                      workflowId: selected.workOrder.workflowId,
                      actorType: "HUMAN",
                      actorId: "operator",
                      idempotencyKey: `ui-dispatch:${selected.workOrder._id}:${selected.workOrder.updatedAt}`,
                      runtime: "Mission Control UI"
                    });
                    if (result.reason === "routing-exhausted") {
                      throw new Error("Dispatch blocked: no safe model route satisfies this Work Order.");
                    }
                  } catch (err) {
                    setDispatchError(err instanceof Error ? err.message : "Dispatch failed");
                  } finally {
                    setDispatchingId(null);
                  }
                },
                disabled: !canDispatchSelected || dispatchingId === selected.workOrder._id,
                children: dispatchingId === selected.workOrder._id ? "Dispatching…" : "Dispatch"
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 730,
                columnNumber: 21
              },
              this
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 729,
              columnNumber: 19
            }, this),
            dispatchError ? /* @__PURE__ */ jsxDEV("div", { className: "mb-3 rounded-md border border-red-500/20 bg-red-500/5 px-3 py-2 text-xs text-red-200", children: dispatchError }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 759,
              columnNumber: 17
            }, this) : null,
            selected.executionRuns.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "No execution runs linked yet." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 764,
              columnNumber: 17
            }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: selected.executionRuns.map(
              (run) => /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-[var(--panel-line)] bg-background/30 p-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV(PlayCircle, { className: "h-4 w-4 text-registry-accent" }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 771,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-foreground", children: run.workflowId }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 772,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: run.status }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 773,
                      columnNumber: 31
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 770,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-muted-foreground", children: run.runId }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 776,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Button,
                      {
                        size: "sm",
                        variant: "outline",
                        onClick: () => {
                          setInspectorRunId(run._id);
                          setInspectorReceiptId(null);
                          setInspectorCriterionId(null);
                        },
                        children: "Inspect run"
                      },
                      void 0,
                      false,
                      {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                        lineNumber: 777,
                        columnNumber: 31
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 775,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 769,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-2 grid gap-2 text-xs text-muted-foreground md:grid-cols-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    "Runtime: ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: run.runtime ?? "—" }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 791,
                      columnNumber: 43
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 791,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    "Model: ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: run.model ?? "—" }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 792,
                      columnNumber: 41
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 792,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    "Worktree: ",
                    /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-foreground/85", children: run.worktree ?? "—" }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 793,
                      columnNumber: 44
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 793,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    "Current step: ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: run.currentStepLabel ?? "—" }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 794,
                      columnNumber: 48
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 794,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    "Retries: ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: run.retryCount }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 795,
                      columnNumber: 43
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 795,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    "Human interventions: ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/85", children: run.humanInterventions }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                      lineNumber: 796,
                      columnNumber: 55
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                    lineNumber: 796,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 790,
                  columnNumber: 27
                }, this),
                run.failureReason ? /* @__PURE__ */ jsxDEV("div", { className: "mt-3 rounded-md border border-red-500/20 bg-red-500/5 px-3 py-2 text-xs text-red-200", children: run.failureReason }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 799,
                  columnNumber: 21
                }, this) : null
              ] }, run._id, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 768,
                columnNumber: 19
              }, this)
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 766,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 728,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Section, { title: "Lifecycle events", children: selected.events?.length ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: selected.events.slice(0, 6).map(
            (event) => /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-[var(--panel-line)] px-3 py-2 text-sm", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-foreground", children: event.summary }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 815,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: event.eventType }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 816,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 814,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: [
                event.fromState ? `${prettyLabel(event.fromState)} → ` : "",
                event.toState ? prettyLabel(event.toState) : ""
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 818,
                columnNumber: 27
              }, this)
            ] }, event._id, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 813,
              columnNumber: 19
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 811,
            columnNumber: 17
          }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "No lifecycle events recorded yet." }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 825,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 809,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 364,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 360,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 299,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 262,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      CreateWorkOrderDialog,
      {
        open: createOpen,
        error,
        creating,
        onClose: () => {
          setCreateOpen(false);
          setCreateRequestKey(null);
          setError(null);
        },
        onCreate: async (payload) => {
          setCreating(true);
          setError(null);
          try {
            const result = await createWorkOrder({
              projectId: projectId ?? void 0,
              title: payload.title,
              desiredOutcome: payload.desiredOutcome,
              context: payload.context || void 0,
              workflowId: payload.workflowId || void 0,
              repository: payload.repository || void 0,
              branchStrategy: payload.branchStrategy || void 0,
              priority: Number(payload.priority),
              riskLevel: payload.riskLevel,
              requestedBy: payload.requestedBy || void 0,
              assignedAgent: payload.assignedAgent || void 0,
              acceptanceCriteria: criteriaFromText(payload.acceptanceCriteria),
              sourceOfTruthRefs: payload.repository ? [{ kind: "REPO", label: payload.repository, location: `github.com/${payload.repository}` }] : void 0,
              idempotencyKey: createRequestKey ?? void 0
            });
            setSelectedId(result.workOrder?._id ?? null);
            setMobileDetailOpen(true);
            setCreateOpen(false);
          } catch (err) {
            setError(err instanceof Error ? err.message : "Failed to create work order");
          } finally {
            setCreating(false);
          }
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 834,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      RequestApprovalDialog,
      {
        open: approvalOpen,
        workOrder: selected?.workOrder ?? null,
        creating,
        onClose: () => setApprovalOpen(false),
        onCreate: async (payload) => {
          if (!selected) return;
          setCreating(true);
          setGovernanceError(null);
          try {
            await requestApprovalDecision({
              workOrderId: selected.workOrder._id,
              workflowRunId: payload.workflowRunId ? payload.workflowRunId : void 0,
              approvalType: payload.approvalType,
              requestedAction: payload.requestedAction,
              requestedBy: payload.requestedBy || void 0,
              riskLevel: selected.workOrder.riskLevel,
              idempotencyKey: `ui-approval:${selected.workOrder._id}:${payload.approvalType}:${payload.requestedAction}`
            });
            setApprovalOpen(false);
          } catch (err) {
            setGovernanceError(err instanceof Error ? err.message : "Failed to request approval");
          } finally {
            setCreating(false);
          }
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 876,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      RecordVerificationReceiptDialog,
      {
        open: receiptOpen,
        workOrder: selected?.workOrder ?? null,
        executionRuns: selected?.executionRuns ?? [],
        approvalDecisions: selected?.approvalDecisions ?? [],
        creating,
        onClose: () => setReceiptOpen(false),
        onCreate: async (payload) => {
          if (!selected) return;
          setCreating(true);
          setGovernanceError(null);
          try {
            await recordVerificationReceipt({
              workOrderId: selected.workOrder._id,
              workflowRunId: payload.workflowRunId,
              acceptanceCriterionId: payload.acceptanceCriterionId,
              verificationMethod: payload.verificationMethod,
              commandOrCheck: payload.commandOrCheck || void 0,
              result: payload.result || void 0,
              evidenceLocation: payload.evidenceLocation || void 0,
              artifactReference: payload.artifactReference || void 0,
              verifier: payload.verifier || void 0,
              status: payload.status,
              exceptionOrWaiver: payload.exceptionOrWaiver || void 0,
              waiverApprovalDecisionId: payload.waiverApprovalDecisionId ? payload.waiverApprovalDecisionId : void 0,
              idempotencyKey: `ui-receipt:${selected.workOrder._id}:${payload.acceptanceCriterionId}:${payload.workflowRunId}:${payload.status}`
            });
            setReceiptOpen(false);
          } catch (err) {
            setGovernanceError(err instanceof Error ? err.message : "Failed to record verification receipt");
          } finally {
            setCreating(false);
          }
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 904,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      RequestRevisionDialog,
      {
        open: revisionOpen,
        workOrder: selected?.workOrder ?? null,
        creating,
        onClose: () => setRevisionOpen(false),
        onCreate: async (payload) => {
          if (!selected) return;
          setCreating(true);
          setGovernanceError(null);
          try {
            await requestWorkOrderRevision({
              workOrderId: selected.workOrder._id,
              idempotencyKey: `ui-revision:${selected.workOrder._id}:${Date.now()}`,
              changeSummary: payload.changeSummary,
              reason: payload.reason,
              requestedBy: payload.requestedBy || void 0,
              patch: {
                desiredOutcome: payload.desiredOutcome || void 0,
                workflowId: payload.workflowId || void 0,
                repository: payload.repository || void 0,
                riskLevel: payload.riskLevel,
                requiredApprovals: payload.requiredApprovals,
                acceptanceCriteria: criteriaFromText(payload.acceptanceCriteria, selected.workOrder.acceptanceCriteria)
              }
            });
            setRevisionOpen(false);
          } catch (err) {
            setGovernanceError(err instanceof Error ? err.message : "Failed to request revision");
          } finally {
            setCreating(false);
          }
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 940,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      ReopenWorkOrderDialog,
      {
        open: reopenOpen,
        workOrder: selected?.workOrder ?? null,
        creating,
        onClose: () => setReopenOpen(false),
        onCreate: async (payload) => {
          if (!selected) return;
          setCreating(true);
          setGovernanceError(null);
          try {
            await reopenWorkOrder({
              workOrderId: selected.workOrder._id,
              idempotencyKey: `ui-reopen:${selected.workOrder._id}:${Date.now()}`,
              reason: payload.reason,
              sourceIssueOrDefect: payload.sourceIssueOrDefect || void 0,
              requestedBy: payload.requestedBy || void 0,
              approvedBy: payload.approvedBy || void 0,
              reopenScope: payload.reopenScope,
              acceptanceCriteriaImpacted: payload.acceptanceCriteriaImpacted,
              newRequiredActions: payload.newRequiredActions
            });
            setReopenOpen(false);
          } catch (err) {
            setGovernanceError(err instanceof Error ? err.message : "Failed to reopen WorkOrder");
          } finally {
            setCreating(false);
          }
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 974,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      SupersedeWorkOrderDialog,
      {
        open: supersedeOpen,
        workOrders: workOrders ?? [],
        currentWorkOrderId: selected?.workOrder._id ?? null,
        creating,
        onClose: () => setSupersedeOpen(false),
        onCreate: async (payload) => {
          if (!selected) return;
          setCreating(true);
          setGovernanceError(null);
          try {
            await supersedeWorkOrder({
              workOrderId: selected.workOrder._id,
              replacementWorkOrderId: payload.replacementWorkOrderId,
              idempotencyKey: `ui-supersede:${selected.workOrder._id}:${payload.replacementWorkOrderId}`,
              reason: payload.reason,
              actorType: "HUMAN",
              actorId: payload.actorId || void 0
            });
            setSupersedeOpen(false);
          } catch (err) {
            setGovernanceError(err instanceof Error ? err.message : "Failed to supersede WorkOrder");
          } finally {
            setCreating(false);
          }
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1004,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      ExecutionRunInspector,
      {
        open: !!inspectorRunId,
        workflowRunId: inspectorRunId,
        verificationReceiptId: inspectorReceiptId,
        acceptanceCriterionId: inspectorCriterionId,
        retrying: !!selected && dispatchingId === selected.workOrder._id,
        onRetryFailedRun: selected ? async ({ workflowRunId, reason, runtime, model, worktree }) => {
          setDispatchError(null);
          setDispatchingId(selected.workOrder._id);
          try {
            const result = await dispatchWorkOrder({
              workOrderId: selected.workOrder._id,
              workflowId: selected.workOrder.workflowId,
              actorType: "HUMAN",
              actorId: "operator",
              idempotencyKey: `ui-retry:${workflowRunId}:${globalThis.crypto?.randomUUID?.() ?? Date.now()}`,
              runtime: runtime ?? "Mission Control UI",
              model,
              worktree,
              retryOfWorkflowRunId: workflowRunId,
              retryReason: reason
            });
            if (result.reason === "routing-exhausted") {
              throw new Error("Retry blocked: no safe model route satisfies this Work Order.");
            }
          } finally {
            setDispatchingId(null);
          }
        } : void 0,
        onClose: () => {
          setInspectorRunId(null);
          setInspectorReceiptId(null);
          setInspectorCriterionId(null);
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1032,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
    lineNumber: 239,
    columnNumber: 5
  }, this);
}
_s(WorkOrdersView, "CEK6pvJYiikCJIEw6KmDNv3/+TQ=", false, function() {
  return [useQuery, useQuery, useMutation, useMutation, useMutation, useMutation, useMutation, useMutation, useMutation, useMutation, useMutation, useMutation, useMutation];
});
_c = WorkOrdersView;
function FilterSelect({
  label,
  value,
  onChange,
  options
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
    /* @__PURE__ */ jsxDEV(Label, { className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground", children: label }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1086,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Select, { value, onValueChange: onChange, children: [
      /* @__PURE__ */ jsxDEV(SelectTrigger, { "aria-label": `${label} filter`, children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1089,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1088,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(SelectContent, { children: [
        /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1092,
          columnNumber: 11
        }, this),
        options.map(
          (option) => /* @__PURE__ */ jsxDEV(SelectItem, { value: option, children: option }, option, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1094,
            columnNumber: 11
          }, this)
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1091,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1087,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
    lineNumber: 1085,
    columnNumber: 5
  }, this);
}
_c2 = FilterSelect;
function Section({ title, children }) {
  return /* @__PURE__ */ jsxDEV("section", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-foreground", children: title }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1105,
      columnNumber: 7
    }, this),
    children
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
    lineNumber: 1104,
    columnNumber: 5
  }, this);
}
_c3 = Section;
function MetaRow({ label, value }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-3", children: [
    /* @__PURE__ */ jsxDEV("dt", { className: "text-muted-foreground", children: label }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1114,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("dd", { className: "text-right text-foreground/85", children: value ?? "—" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1115,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
    lineNumber: 1113,
    columnNumber: 5
  }, this);
}
_c4 = MetaRow;
function StatCard({ label, value, tone = "default" }) {
  return /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground", children: label }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1123,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `mt-2 text-2xl font-semibold ${tone === "good" ? "text-emerald-300" : tone === "warn" ? "text-amber-300" : tone === "bad" ? "text-red-300" : "text-foreground"}`, children: value }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1124,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
    lineNumber: 1122,
    columnNumber: 5
  }, this);
}
_c5 = StatCard;
function RequestApprovalDialog({
  open,
  workOrder,
  creating,
  onClose,
  onCreate
}) {
  _s2();
  const defaultType = workOrder?.requiredApprovals?.[0] ?? (["HIGH", "CRITICAL"].includes(workOrder?.riskLevel) ? "RISK_REVIEW" : "OPERATOR_REVIEW");
  const [approvalType, setApprovalType] = useState(defaultType);
  const [requestedAction, setRequestedAction] = useState("Approve protected dispatch or acceptance action");
  const [requestedBy, setRequestedBy] = useState("operator");
  const [workflowRunId, setWorkflowRunId] = useState("");
  useEffect(() => {
    setApprovalType(defaultType);
  }, [defaultType, open]);
  return /* @__PURE__ */ jsxDEV(Dialog, { open, onOpenChange: (next) => !next && onClose(), children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "sm:max-w-[560px]", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Request approval" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1158,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Create an auditable ApprovalDecision linked to this WorkOrder." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1159,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1157,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Approval type" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1162,
          columnNumber: 40
        }, this),
        /* @__PURE__ */ jsxDEV(Input, { value: approvalType, onChange: (event) => setApprovalType(event.target.value) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1162,
          columnNumber: 68
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1162,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Requested action" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1163,
          columnNumber: 40
        }, this),
        /* @__PURE__ */ jsxDEV(Textarea, { value: requestedAction, onChange: (event) => setRequestedAction(event.target.value), rows: 3 }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1163,
          columnNumber: 71
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1163,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-3 md:grid-cols-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Requested by" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1165,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: requestedBy, onChange: (event) => setRequestedBy(event.target.value) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1165,
            columnNumber: 69
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1165,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Execution run ID (optional)" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1166,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: workflowRunId, onChange: (event) => setWorkflowRunId(event.target.value), placeholder: "w57..." }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1166,
            columnNumber: 84
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1166,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1164,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1161,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Cancel" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1170,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { onClick: () => onCreate({ approvalType, requestedAction, requestedBy, workflowRunId }), disabled: creating || !approvalType.trim() || !requestedAction.trim(), children: creating ? "Requesting…" : "Request approval" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1171,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1169,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
    lineNumber: 1156,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
    lineNumber: 1155,
    columnNumber: 5
  }, this);
}
_s2(RequestApprovalDialog, "acuWpMCuVVbMb8s0Ix9tC/LcxmY=");
_c6 = RequestApprovalDialog;
function RecordVerificationReceiptDialog({
  open,
  workOrder,
  executionRuns,
  approvalDecisions,
  creating,
  onClose,
  onCreate
}) {
  _s3();
  const [acceptanceCriterionId, setAcceptanceCriterionId] = useState("");
  const [workflowRunId, setWorkflowRunId] = useState("");
  const [verificationMethod, setVerificationMethod] = useState("MANUAL");
  const [commandOrCheck, setCommandOrCheck] = useState("");
  const [result, setResult] = useState("");
  const [evidenceLocation, setEvidenceLocation] = useState("");
  const [artifactReference, setArtifactReference] = useState("");
  const [verifier, setVerifier] = useState("operator");
  const [status, setStatus] = useState("PASSED");
  const [exceptionOrWaiver, setExceptionOrWaiver] = useState("");
  const [waiverApprovalDecisionId, setWaiverApprovalDecisionId] = useState("");
  useEffect(() => {
    setAcceptanceCriterionId(workOrder?.acceptanceCriteria?.[0]?.id ?? "");
    setWorkflowRunId(executionRuns?.[0]?._id ?? "");
  }, [workOrder, executionRuns, open]);
  const waiverOptions = approvalDecisions.filter((approval) => approval.status === "APPROVED" || approval.status === "CONDITIONAL");
  return /* @__PURE__ */ jsxDEV(Dialog, { open, onOpenChange: (next) => !next && onClose(), children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "sm:max-w-[720px]", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Record verification receipt" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1230,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Attach evidence to one acceptance criterion and mark whether it passed, failed, or was waived." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1231,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1229,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 md:grid-cols-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Acceptance criterion" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1236,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Select, { value: acceptanceCriterionId, onValueChange: setAcceptanceCriterionId, children: [
            /* @__PURE__ */ jsxDEV(SelectTrigger, { children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1238,
              columnNumber: 32
            }, this) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1238,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(SelectContent, { children: (workOrder?.acceptanceCriteria ?? []).map((criterion) => /* @__PURE__ */ jsxDEV(SelectItem, { value: criterion.id, children: criterion.title }, criterion.id, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1240,
              columnNumber: 82
            }, this)) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1239,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1237,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1235,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Execution run" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1245,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Select, { value: workflowRunId, onValueChange: setWorkflowRunId, children: [
            /* @__PURE__ */ jsxDEV(SelectTrigger, { children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1247,
              columnNumber: 32
            }, this) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1247,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(SelectContent, { children: executionRuns.map((run) => /* @__PURE__ */ jsxDEV(SelectItem, { value: run._id, children: [
              run.runId,
              " · ",
              run.status
            ] }, run._id, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1249,
              columnNumber: 47
            }, this)) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1248,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1246,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1244,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid gap-3 md:grid-cols-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV(Label, { children: "Method" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1255,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Select, { value: verificationMethod, onValueChange: setVerificationMethod, children: [
              /* @__PURE__ */ jsxDEV(SelectTrigger, { children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 1257,
                columnNumber: 34
              }, this) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 1257,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(SelectContent, { children: ["MANUAL", "COMMAND", "TEST", "CHECKLIST"].map((option) => /* @__PURE__ */ jsxDEV(SelectItem, { value: option, children: option }, option, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 1259,
                columnNumber: 81
              }, this)) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 1258,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1256,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1254,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV(Label, { children: "Status" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1264,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Select, { value: status, onValueChange: setStatus, children: [
              /* @__PURE__ */ jsxDEV(SelectTrigger, { children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 1266,
                columnNumber: 34
              }, this) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 1266,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(SelectContent, { children: ["PASSED", "FAILED", "WAIVED", "PENDING"].map((option) => /* @__PURE__ */ jsxDEV(SelectItem, { value: option, children: option }, option, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 1268,
                columnNumber: 80
              }, this)) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 1267,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1265,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1263,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1253,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Verifier" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1273,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: verifier, onChange: (event) => setVerifier(event.target.value) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1273,
            columnNumber: 65
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1273,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1234,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Command or check" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1277,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: commandOrCheck, onChange: (event) => setCommandOrCheck(event.target.value), placeholder: "pnpm --filter mission-control-ui build" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1277,
            columnNumber: 73
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1277,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Result" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1278,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Textarea, { value: result, onChange: (event) => setResult(event.target.value), rows: 3, placeholder: "Build completed successfully" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1278,
            columnNumber: 63
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1278,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Evidence location" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1279,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: evidenceLocation, onChange: (event) => setEvidenceLocation(event.target.value), placeholder: "docs/software-factory/verification-receipt.md" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1279,
            columnNumber: 74
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1279,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Artifact reference" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1280,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: artifactReference, onChange: (event) => setArtifactReference(event.target.value), placeholder: "tmp/screenshot.png or PR URL" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1280,
            columnNumber: 75
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1280,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Exception / waiver note" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1281,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: exceptionOrWaiver, onChange: (event) => setExceptionOrWaiver(event.target.value), placeholder: "Why a waiver is acceptable" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1281,
            columnNumber: 80
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1281,
          columnNumber: 13
        }, this),
        status === "WAIVED" ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Waiver approval" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1284,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Select, { value: waiverApprovalDecisionId, onValueChange: setWaiverApprovalDecisionId, children: [
            /* @__PURE__ */ jsxDEV(SelectTrigger, { children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select approved decision" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1286,
              columnNumber: 34
            }, this) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1286,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(SelectContent, { children: waiverOptions.map((approval) => /* @__PURE__ */ jsxDEV(SelectItem, { value: approval._id, children: [
              approval.approvalType,
              " · ",
              approval.status
            ] }, approval._id, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1288,
              columnNumber: 54
            }, this)) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1287,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1285,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1283,
          columnNumber: 13
        }, this) : null
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1276,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1233,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Cancel" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1296,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { onClick: () => onCreate({ acceptanceCriterionId, workflowRunId, verificationMethod, commandOrCheck, result, evidenceLocation, artifactReference, verifier, status, exceptionOrWaiver, waiverApprovalDecisionId }), disabled: creating || !acceptanceCriterionId || !workflowRunId, children: creating ? "Recording…" : "Record receipt" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1297,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1295,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
    lineNumber: 1228,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
    lineNumber: 1227,
    columnNumber: 5
  }, this);
}
_s3(RecordVerificationReceiptDialog, "qsW4aQ0N4nNrhZaQOBrt/bACY5w=");
_c7 = RecordVerificationReceiptDialog;
function RequestRevisionDialog({
  open,
  workOrder,
  creating,
  onClose,
  onCreate
}) {
  _s4();
  const [changeSummary, setChangeSummary] = useState("Clarify or revise WorkOrder scope");
  const [reason, setReason] = useState("");
  const [requestedBy, setRequestedBy] = useState("operator");
  const [desiredOutcome, setDesiredOutcome] = useState("");
  const [workflowId, setWorkflowId] = useState("");
  const [repository, setRepository] = useState("");
  const [riskLevel, setRiskLevel] = useState("MEDIUM");
  const [requiredApprovalsText, setRequiredApprovalsText] = useState("");
  const [acceptanceCriteria, setAcceptanceCriteria] = useState("");
  useEffect(() => {
    if (!open || !workOrder) return;
    setDesiredOutcome(workOrder.desiredOutcome ?? "");
    setWorkflowId(workOrder.workflowId ?? "");
    setRepository(workOrder.repository ?? "");
    setRiskLevel(workOrder.riskLevel ?? "MEDIUM");
    setRequiredApprovalsText((workOrder.requiredApprovals ?? []).join("\n"));
    setAcceptanceCriteria((workOrder.acceptanceCriteria ?? []).map((criterion) => criterion.title).join("\n"));
  }, [open, workOrder]);
  return /* @__PURE__ */ jsxDEV(Dialog, { open, onOpenChange: (next) => !next && onClose(), children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "sm:max-w-[760px]", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Request WorkOrder revision" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1351,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Version a controlled revision. Accepted work stays immutable until a revision is explicitly applied." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1352,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1350,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 md:grid-cols-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Change summary" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1356,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: changeSummary, onChange: (event) => setChangeSummary(event.target.value) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1356,
            columnNumber: 71
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1356,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Reason" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1357,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Textarea, { value: reason, onChange: (event) => setReason(event.target.value), rows: 4, placeholder: "Why does this revision need to happen?" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1357,
            columnNumber: 63
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1357,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Requested by" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1358,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: requestedBy, onChange: (event) => setRequestedBy(event.target.value) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1358,
            columnNumber: 69
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1358,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Desired outcome" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1359,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Textarea, { value: desiredOutcome, onChange: (event) => setDesiredOutcome(event.target.value), rows: 4 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1359,
            columnNumber: 72
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1359,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1355,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid gap-3 md:grid-cols-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV(Label, { children: "Workflow" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1363,
              columnNumber: 44
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { value: workflowId, onChange: (event) => setWorkflowId(event.target.value) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1363,
              columnNumber: 67
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1363,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV(Label, { children: "Repository" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1364,
              columnNumber: 44
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { value: repository, onChange: (event) => setRepository(event.target.value) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1364,
              columnNumber: 69
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1364,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1362,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Risk level" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1367,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Select, { value: riskLevel, onValueChange: setRiskLevel, children: [
            /* @__PURE__ */ jsxDEV(SelectTrigger, { children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1369,
              columnNumber: 32
            }, this) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1369,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(SelectContent, { children: ["LOW", "MEDIUM", "HIGH", "CRITICAL"].map((option) => /* @__PURE__ */ jsxDEV(SelectItem, { value: option, children: option }, option, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1370,
              columnNumber: 87
            }, this)) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1370,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1368,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1366,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Required approvals" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1373,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Textarea, { value: requiredApprovalsText, onChange: (event) => setRequiredApprovalsText(event.target.value), rows: 3, placeholder: "One per line" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1373,
            columnNumber: 75
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1373,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Acceptance criteria" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1374,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Textarea, { value: acceptanceCriteria, onChange: (event) => setAcceptanceCriteria(event.target.value), rows: 5, placeholder: "One criterion per line" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1374,
            columnNumber: 76
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1374,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1361,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1354,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Cancel" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1378,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { onClick: () => onCreate({
        changeSummary,
        reason,
        requestedBy,
        desiredOutcome,
        workflowId,
        repository,
        riskLevel,
        requiredApprovals: requiredApprovalsText.split("\n").map((line) => line.trim()).filter(Boolean),
        acceptanceCriteria
      }), disabled: creating || !changeSummary.trim() || !reason.trim(), children: creating ? "Saving…" : "Request revision" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1379,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1377,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
    lineNumber: 1349,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
    lineNumber: 1348,
    columnNumber: 5
  }, this);
}
_s4(RequestRevisionDialog, "qYBhlhpHSwYp+erahB1+pUhAs9A=");
_c8 = RequestRevisionDialog;
function ReopenWorkOrderDialog({
  open,
  workOrder,
  creating,
  onClose,
  onCreate
}) {
  _s5();
  const [reason, setReason] = useState("");
  const [sourceIssueOrDefect, setSourceIssueOrDefect] = useState("");
  const [requestedBy, setRequestedBy] = useState("operator");
  const [approvedBy, setApprovedBy] = useState("operator");
  const [reopenScope, setReopenScope] = useState("full-workorder");
  const [acceptanceCriteriaImpactedText, setAcceptanceCriteriaImpactedText] = useState("");
  const [newRequiredActionsText, setNewRequiredActionsText] = useState("Review defect\nRecord replacement evidence\nRedispatch if implementation must change");
  useEffect(() => {
    if (!open || !workOrder) return;
    setAcceptanceCriteriaImpactedText((workOrder.acceptanceCriteria ?? []).map((criterion) => criterion.id).join("\n"));
  }, [open, workOrder]);
  return /* @__PURE__ */ jsxDEV(Dialog, { open, onOpenChange: (next) => !next && onClose(), children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "sm:max-w-[720px]", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Reopen WorkOrder" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1434,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Preserve prior evidence and explicitly mark what became invalid and what must happen next." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1435,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1433,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Reason" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1438,
          columnNumber: 40
        }, this),
        /* @__PURE__ */ jsxDEV(Textarea, { value: reason, onChange: (event) => setReason(event.target.value), rows: 3, placeholder: "Defect discovered, evidence invalidated, reviewer requested correction…" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1438,
          columnNumber: 61
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1438,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Source issue or defect" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1439,
          columnNumber: 40
        }, this),
        /* @__PURE__ */ jsxDEV(Input, { value: sourceIssueOrDefect, onChange: (event) => setSourceIssueOrDefect(event.target.value), placeholder: "Issue / defect / incident reference" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1439,
          columnNumber: 77
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1439,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-3 md:grid-cols-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Requested by" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1441,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: requestedBy, onChange: (event) => setRequestedBy(event.target.value) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1441,
            columnNumber: 69
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1441,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Approved by" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1442,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: approvedBy, onChange: (event) => setApprovedBy(event.target.value) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1442,
            columnNumber: 68
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1442,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Reopen scope" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1443,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: reopenScope, onChange: (event) => setReopenScope(event.target.value) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1443,
            columnNumber: 69
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1443,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1440,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-3 md:grid-cols-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Impacted criteria IDs" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1446,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Textarea, { value: acceptanceCriteriaImpactedText, onChange: (event) => setAcceptanceCriteriaImpactedText(event.target.value), rows: 4 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1446,
            columnNumber: 78
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1446,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "New required actions" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1447,
            columnNumber: 42
          }, this),
          /* @__PURE__ */ jsxDEV(Textarea, { value: newRequiredActionsText, onChange: (event) => setNewRequiredActionsText(event.target.value), rows: 4 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1447,
            columnNumber: 77
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1447,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1445,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1437,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Cancel" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1451,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { onClick: () => onCreate({
        reason,
        sourceIssueOrDefect,
        requestedBy,
        approvedBy,
        reopenScope,
        acceptanceCriteriaImpacted: acceptanceCriteriaImpactedText.split("\n").map((line) => line.trim()).filter(Boolean),
        newRequiredActions: newRequiredActionsText.split("\n").map((line) => line.trim()).filter(Boolean)
      }), disabled: creating || !reason.trim(), children: creating ? "Reopening…" : "Reopen WorkOrder" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1452,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1450,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
    lineNumber: 1432,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
    lineNumber: 1431,
    columnNumber: 5
  }, this);
}
_s5(ReopenWorkOrderDialog, "kPDKG3BNj3UCExHWvyJFc9j9ReI=");
_c9 = ReopenWorkOrderDialog;
function SupersedeWorkOrderDialog({
  open,
  workOrders,
  currentWorkOrderId,
  creating,
  onClose,
  onCreate
}) {
  _s6();
  const [replacementWorkOrderId, setReplacementWorkOrderId] = useState("");
  const [reason, setReason] = useState("");
  const [actorId, setActorId] = useState("operator");
  const options = (workOrders ?? []).filter((item) => item._id !== currentWorkOrderId);
  useEffect(() => {
    if (!open) return;
    setReplacementWorkOrderId(options[0]?._id ?? "");
  }, [open, currentWorkOrderId]);
  return /* @__PURE__ */ jsxDEV(Dialog, { open, onOpenChange: (next) => !next && onClose(), children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "sm:max-w-[620px]", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Supersede WorkOrder" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1497,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Link this WorkOrder to its authoritative replacement without losing unresolved obligations or evidence history." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1498,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1496,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Replacement WorkOrder" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1502,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Select, { value: replacementWorkOrderId, onValueChange: setReplacementWorkOrderId, children: [
          /* @__PURE__ */ jsxDEV(SelectTrigger, { children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1504,
            columnNumber: 30
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1504,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(SelectContent, { children: options.map((option) => /* @__PURE__ */ jsxDEV(SelectItem, { value: option._id, children: option.title }, option._id, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1506,
            columnNumber: 42
          }, this)) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1505,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1503,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1501,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Reason" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1510,
          columnNumber: 40
        }, this),
        /* @__PURE__ */ jsxDEV(Textarea, { value: reason, onChange: (event) => setReason(event.target.value), rows: 3 }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1510,
          columnNumber: 61
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1510,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Actor" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1511,
          columnNumber: 40
        }, this),
        /* @__PURE__ */ jsxDEV(Input, { value: actorId, onChange: (event) => setActorId(event.target.value) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1511,
          columnNumber: 60
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1511,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1500,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Cancel" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1514,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { onClick: () => onCreate({ replacementWorkOrderId, reason, actorId }), disabled: creating || !replacementWorkOrderId || !reason.trim(), children: creating ? "Superseding…" : "Supersede WorkOrder" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1515,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1513,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
    lineNumber: 1495,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
    lineNumber: 1494,
    columnNumber: 5
  }, this);
}
_s6(SupersedeWorkOrderDialog, "a9fkaT8LrfYwZd7QzMAAbgPAtQA=");
_c0 = SupersedeWorkOrderDialog;
function CreateWorkOrderDialog({
  open,
  creating,
  error,
  onClose,
  onCreate
}) {
  _s7();
  const [title, setTitle] = useState("");
  const [desiredOutcome, setDesiredOutcome] = useState("");
  const [context, setContext] = useState("");
  const [workflowId, setWorkflowId] = useState("feature-dev");
  const [repository, setRepository] = useState("jaydubya818/MissionControl");
  const [branchStrategy, setBranchStrategy] = useState("isolated feature branch and worktree");
  const [priority, setPriority] = useState("2");
  const [riskLevel, setRiskLevel] = useState("MEDIUM");
  const [requestedBy, setRequestedBy] = useState("Hermes");
  const [assignedAgent, setAssignedAgent] = useState("Pi");
  const [acceptanceCriteria, setAcceptanceCriteria] = useState("");
  return /* @__PURE__ */ jsxDEV(Dialog, { open, onOpenChange: (next) => !next && onClose(), children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "sm:max-w-[720px]", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Create WorkOrder" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1563,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Define value in terms of outcome, repository context, and acceptance criteria." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1564,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1562,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 md:grid-cols-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Title" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1570,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: title, onChange: (event) => setTitle(event.target.value), placeholder: "Work order title" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1571,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1569,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Desired outcome" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1574,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Textarea, { value: desiredOutcome, onChange: (event) => setDesiredOutcome(event.target.value), rows: 4, placeholder: "What value should be delivered?" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1575,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1573,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Context" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1578,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Textarea, { value: context, onChange: (event) => setContext(event.target.value), rows: 4, placeholder: "Business or engineering context" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1579,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1577,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1568,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Workflow" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1585,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: workflowId, onChange: (event) => setWorkflowId(event.target.value), placeholder: "feature-dev" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1586,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1584,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Repository" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1589,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: repository, onChange: (event) => setRepository(event.target.value), placeholder: "owner/repo" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1590,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1588,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Branch strategy" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1593,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: branchStrategy, onChange: (event) => setBranchStrategy(event.target.value) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1594,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1592,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV(Label, { children: "Priority" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1598,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Select, { value: priority, onValueChange: setPriority, children: [
              /* @__PURE__ */ jsxDEV(SelectTrigger, { children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 1600,
                columnNumber: 34
              }, this) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 1600,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "1", children: "Critical" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 1602,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "2", children: "High" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 1603,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "3", children: "Normal" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 1604,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "4", children: "Low" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 1605,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 1601,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1599,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1597,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV(Label, { children: "Risk" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1610,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Select, { value: riskLevel, onValueChange: setRiskLevel, children: [
              /* @__PURE__ */ jsxDEV(SelectTrigger, { children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 1612,
                columnNumber: 34
              }, this) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 1612,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "LOW", children: "Low" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 1614,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "MEDIUM", children: "Medium" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 1615,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "HIGH", children: "High" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 1616,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "CRITICAL", children: "Critical" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                  lineNumber: 1617,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
                lineNumber: 1613,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1611,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1609,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1596,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV(Label, { children: "Requested by" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1624,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { value: requestedBy, onChange: (event) => setRequestedBy(event.target.value) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1625,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1623,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV(Label, { children: "Assigned agent" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1628,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { value: assignedAgent, onChange: (event) => setAssignedAgent(event.target.value) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
              lineNumber: 1629,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1627,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1622,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Acceptance criteria" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1633,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Textarea, { value: acceptanceCriteria, onChange: (event) => setAcceptanceCriteria(event.target.value), rows: 6, placeholder: "One criterion per line\nBuild passes\nQueue renders\nLinked run is visible" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
            lineNumber: 1634,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1632,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1583,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1567,
      columnNumber: 9
    }, this),
    error ? /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-red-300", children: error }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1639,
      columnNumber: 18
    }, this) : null,
    /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, children: "Cancel" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
        lineNumber: 1642,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          onClick: () => onCreate({ title, desiredOutcome, context, workflowId, repository, branchStrategy, priority, riskLevel, requestedBy, assignedAgent, acceptanceCriteria }),
          disabled: creating || !title.trim() || !desiredOutcome.trim() || !acceptanceCriteria.trim(),
          children: creating ? "Creating…" : "Create WorkOrder"
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
          lineNumber: 1643,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
      lineNumber: 1641,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
    lineNumber: 1561,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx",
    lineNumber: 1560,
    columnNumber: 5
  }, this);
}
_s7(CreateWorkOrderDialog, "JxYBPf+V9lU8rAuer4PwxH4ISqo=");
_c1 = CreateWorkOrderDialog;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0, _c1;
$RefreshReg$(_c, "WorkOrdersView");
$RefreshReg$(_c2, "FilterSelect");
$RefreshReg$(_c3, "Section");
$RefreshReg$(_c4, "MetaRow");
$RefreshReg$(_c5, "StatCard");
$RefreshReg$(_c6, "RequestApprovalDialog");
$RefreshReg$(_c7, "RecordVerificationReceiptDialog");
$RefreshReg$(_c8, "RequestRevisionDialog");
$RefreshReg$(_c9, "ReopenWorkOrderDialog");
$RefreshReg$(_c0, "SupersedeWorkOrderDialog");
$RefreshReg$(_c1, "CreateWorkOrderDialog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrdersView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ09jOzs7Ozs7Ozs7Ozs7Ozs7OztBQWhPZCxTQUFTQSxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFDN0MsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLFdBQVc7QUFFcEIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLFlBQVk7QUFDckI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxhQUFhO0FBQ3RCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsV0FBV0MsZUFBZUMsY0FBY0MsWUFBWUMsTUFBTUMsYUFBYUMsVUFBVUMscUJBQXFCO0FBQy9HO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FHSztBQUNQLFNBQVNDLDZCQUE2QjtBQUN0QyxTQUFTQyxvQ0FBb0NDLGdDQUFnQztBQUU3RSxNQUFNQyxjQUFzQztBQUFBLEVBQzFDQyxLQUFLO0FBQUEsRUFDTEMsUUFBUTtBQUFBLEVBQ1JDLE1BQU07QUFBQSxFQUNOQyxVQUFVO0FBQ1o7QUFFQSxNQUFNQyxlQUF1QztBQUFBLEVBQzNDQyxPQUFPO0FBQUEsRUFDUEMsT0FBTztBQUFBLEVBQ1BDLFlBQVk7QUFBQSxFQUNaQyxhQUFhO0FBQUEsRUFDYkMsU0FBUztBQUFBLEVBQ1RDLG1CQUFtQjtBQUFBLEVBQ25CQyx1QkFBdUI7QUFBQSxFQUN2QkMsVUFBVTtBQUFBLEVBQ1ZDLE1BQU07QUFBQSxFQUNOQyxVQUFVO0FBQUEsRUFDVkMsWUFBWTtBQUNkO0FBRUEsTUFBTUMsZ0JBQW9FO0FBQUEsRUFDeEUsRUFBRUMsSUFBSSxPQUFPQyxPQUFPLE1BQU07QUFBQSxFQUMxQixFQUFFRCxJQUFJLG1CQUFtQkMsT0FBTyxrQkFBa0I7QUFBQSxFQUNsRCxFQUFFRCxJQUFJLFdBQVdDLE9BQU8sVUFBVTtBQUFBLEVBQ2xDLEVBQUVELElBQUkscUJBQXFCQyxPQUFPLG9CQUFvQjtBQUFBLEVBQ3RELEVBQUVELElBQUkscUJBQXFCQyxPQUFPLG9CQUFvQjtBQUFDO0FBR3pELFNBQVNDLFlBQVlDLE9BQWtDO0FBQ3JELE1BQUksQ0FBQ0EsTUFBTyxRQUFPO0FBQ25CLFNBQU9BLE1BQU1DLFFBQVEsTUFBTSxHQUFHO0FBQ2hDO0FBRUEsU0FBU0MsaUJBQWlCRixPQUFlRyxtQkFBNEcsSUFBSTtBQUN2SixTQUFPSCxNQUNKSSxNQUFNLElBQUksRUFDVkMsSUFBSSxDQUFDQyxTQUFTQSxLQUFLQyxLQUFLLENBQUMsRUFDekJDLE9BQU9DLE9BQU8sRUFDZEosSUFBSSxDQUFDSyxPQUFPQyxVQUFVO0FBQ3JCLFVBQU1DLFdBQVdULGlCQUFpQlEsS0FBSztBQUN2QyxXQUFPO0FBQUEsTUFDTGQsSUFBSWUsVUFBVWYsTUFBTSxNQUFNYyxRQUFRLENBQUM7QUFBQSxNQUNuQ0Q7QUFBQUEsTUFDQUcsYUFBYUQsVUFBVUM7QUFBQUEsTUFDdkJDLG9CQUFxQkYsVUFBVUUsc0JBQWtGO0FBQUEsTUFDakhDLFFBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRixDQUFDO0FBQ0w7QUFFQSxTQUFTQyxrQkFBbUZDLFVBQWU7QUFDekcsUUFBTUMsU0FBUyxvQkFBSUMsSUFBZTtBQUNsQyxHQUFDLEdBQUdGLFFBQVEsRUFBRUcsS0FBSyxDQUFDQyxHQUFHQyxNQUFNQSxFQUFFQyxhQUFhRixFQUFFRSxVQUFVLEVBQUVDLFFBQVEsQ0FBQ0MsWUFBWTtBQUM3RSxRQUFJLENBQUNQLE9BQU9RLElBQUlELFFBQVFFLHFCQUFxQixFQUFHVCxRQUFPVSxJQUFJSCxRQUFRRSx1QkFBdUJGLE9BQU87QUFBQSxFQUNuRyxDQUFDO0FBQ0QsU0FBT1A7QUFDVDtBQUVPLGdCQUFTVyxlQUFlLEVBQUVDLFVBQWdELEdBQUc7QUFBQUMsS0FBQTtBQUNsRixRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSTVGLFNBQWdDK0IsMEJBQTBCO0FBQ3hGLFFBQU0sQ0FBQzhELFlBQVlDLGFBQWEsSUFBSTlGLFNBQXdCLElBQUk7QUFDaEUsUUFBTSxDQUFDK0Ysa0JBQWtCQyxtQkFBbUIsSUFBSWhHLFNBQVMsS0FBSztBQUM5RCxRQUFNLENBQUNpRyxZQUFZQyxhQUFhLElBQUlsRyxTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDbUcsY0FBY0MsZUFBZSxJQUFJcEcsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQ3FHLGFBQWFDLGNBQWMsSUFBSXRHLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUN1RyxjQUFjQyxlQUFlLElBQUl4RyxTQUFTLEtBQUs7QUFDdEQsUUFBTSxDQUFDeUcsWUFBWUMsYUFBYSxJQUFJMUcsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQzJHLGVBQWVDLGdCQUFnQixJQUFJNUcsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQzZHLGtCQUFrQkMsbUJBQW1CLElBQUk5RyxTQUF3QixJQUFJO0FBQzVFLFFBQU0sQ0FBQytHLGVBQWVDLGdCQUFnQixJQUFJaEgsU0FBd0IsSUFBSTtBQUN0RSxRQUFNLENBQUNpSCxhQUFhQyxjQUFjLElBQUlsSCxTQUF3QixJQUFJO0FBQ2xFLFFBQU0sQ0FBQ21ILFlBQVlDLGFBQWEsSUFBSXBILFNBQXdCLElBQUk7QUFDaEUsUUFBTSxDQUFDcUgsYUFBYUMsY0FBYyxJQUFJdEgsU0FBd0IsSUFBSTtBQUNsRSxRQUFNLENBQUN1SCxlQUFlQyxnQkFBZ0IsSUFBSXhILFNBQXdCLElBQUk7QUFDdEUsUUFBTSxDQUFDeUgsZ0JBQWdCQyxpQkFBaUIsSUFBSTFILFNBQW9DLElBQUk7QUFDcEYsUUFBTSxDQUFDMkgsb0JBQW9CQyxxQkFBcUIsSUFBSTVILFNBQTRDLElBQUk7QUFDcEcsUUFBTSxDQUFDNkgsc0JBQXNCQyx1QkFBdUIsSUFBSTlILFNBQXdCLElBQUk7QUFDcEYsUUFBTSxDQUFDK0gsZUFBZUMsZ0JBQWdCLElBQUloSSxTQUF3QixJQUFJO0FBQ3RFLFFBQU0sQ0FBQ2lJLGlCQUFpQkMsa0JBQWtCLElBQUlsSSxTQUF3QixJQUFJO0FBQzFFLFFBQU0sQ0FBQ21JLFVBQVVDLFdBQVcsSUFBSXBJLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUNxSSxTQUFTQyxVQUFVLElBQUl0SSxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDdUksT0FBT0MsUUFBUSxJQUFJeEksU0FBd0IsSUFBSTtBQUV0RCxRQUFNeUksYUFBYXZJLFNBQVNDLElBQUlzSSxXQUFXQyxNQUFNakQsWUFBWSxFQUFFQSxVQUFVLElBQUksQ0FBQyxDQUFDO0FBQy9FLFFBQU1rRCxXQUFXekk7QUFBQUEsSUFDZkMsSUFBSXNJLFdBQVdHO0FBQUFBLElBQ2YvQyxhQUFhLEVBQUVnRCxhQUFhaEQsV0FBK0IsSUFBSTtBQUFBLEVBQ2pFO0FBQ0EsUUFBTWlELGtCQUFrQjdJLFlBQVlFLElBQUlzSSxXQUFXTSxNQUFNO0FBQ3pELFFBQU1DLG9CQUFvQi9JLFlBQVlFLElBQUlzSSxXQUFXUSxRQUFRO0FBQzdELFFBQU1DLDBCQUEwQmpKLFlBQVlFLElBQUlzSSxXQUFXUyx1QkFBdUI7QUFDbEYsUUFBTUMsNEJBQTRCbEosWUFBWUUsSUFBSXNJLFdBQVdVLHlCQUF5QjtBQUN0RixRQUFNQyxrQkFBa0JuSixZQUFZRSxJQUFJc0ksV0FBV1ksTUFBTTtBQUN6RCxRQUFNQywyQkFBMkJySixZQUFZRSxJQUFJc0ksV0FBV2Esd0JBQXdCO0FBQ3BGLFFBQU1DLDJCQUEyQnRKLFlBQVlFLElBQUlzSSxXQUFXYyx3QkFBd0I7QUFDcEYsUUFBTUMsa0JBQWtCdkosWUFBWUUsSUFBSXNJLFdBQVdlLGVBQWU7QUFDbEUsUUFBTUMscUJBQXFCeEosWUFBWUUsSUFBSXNJLFdBQVdnQixrQkFBa0I7QUFDeEUsUUFBTUMsMEJBQTBCekosWUFBWUUsSUFBSXNJLFdBQVdpQix1QkFBdUI7QUFDbEYsUUFBTUMsV0FBVzFKLFlBQVlFLElBQUlzSSxXQUFXa0IsUUFBUTtBQUVwRCxRQUFNQyxXQUFXN0osUUFBUSxNQUFNa0MsaUJBQWlCd0csY0FBYyxJQUFJOUMsT0FBTyxHQUFHLENBQUM4QyxZQUFZOUMsT0FBTyxDQUFDO0FBRWpHN0YsWUFBVSxNQUFNO0FBQ2QsUUFBSThKLFNBQVNDLFdBQVcsR0FBRztBQUN6Qi9ELG9CQUFjLElBQUk7QUFDbEJFLDBCQUFvQixLQUFLO0FBQ3pCO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQ0gsY0FBYytELFNBQVNDLFNBQVMsR0FBRztBQUN0Qy9ELG9CQUFjOEQsU0FBUyxDQUFDLEVBQUVFLEdBQUc7QUFBQSxJQUMvQjtBQUNBLFFBQUlqRSxjQUFjK0QsU0FBU0MsU0FBUyxLQUFLLENBQUNELFNBQVNHLEtBQUssQ0FBQ0MsU0FBU0EsS0FBS0YsUUFBUWpFLFVBQVUsR0FBRztBQUMxRkMsb0JBQWM4RCxTQUFTLENBQUMsRUFBRUUsR0FBRztBQUFBLElBQy9CO0FBQUEsRUFDRixHQUFHLENBQUNGLFVBQVUvRCxVQUFVLENBQUM7QUFFekIsUUFBTW9FLGVBQWVsSztBQUFBQSxJQUNuQixNQUFNbUssTUFBTUMsS0FBSyxJQUFJQyxLQUFLM0IsY0FBYyxJQUFJekUsSUFBSSxDQUFDZ0csU0FBU0EsS0FBS0ssVUFBVSxFQUFFbEcsT0FBT0MsT0FBTyxDQUFDLENBQUMsRUFBRVcsS0FBSztBQUFBLElBQ2xHLENBQUMwRCxVQUFVO0FBQUEsRUFDYjtBQUNBLFFBQU02QixpQkFBaUJ2SztBQUFBQSxJQUNyQixNQUFNbUssTUFBTUMsS0FBSyxJQUFJQyxLQUFLM0IsY0FBYyxJQUFJekUsSUFBSSxDQUFDZ0csU0FBU0EsS0FBS08sYUFBYSxFQUFFcEcsT0FBT0MsT0FBTyxDQUFDLENBQUMsRUFBRVcsS0FBSztBQUFBLElBQ3JHLENBQUMwRCxVQUFVO0FBQUEsRUFDYjtBQUNBLFFBQU0rQixhQUFheks7QUFBQUEsSUFDakIsTUFBTW1LLE1BQU1DLEtBQUssSUFBSUMsS0FBSzNCLGNBQWMsSUFBSXpFLElBQUksQ0FBQ2dHLFNBQVNBLEtBQUtTLFdBQVcsRUFBRXRHLE9BQU9DLE9BQU8sQ0FBQyxDQUFDLEVBQUVXLEtBQUs7QUFBQSxJQUNuRyxDQUFDMEQsVUFBVTtBQUFBLEVBQ2I7QUFFQSxRQUFNaUMsU0FBUzNLLFFBQVEsTUFBTTtBQUMzQixVQUFNNEssT0FBT2xDLGNBQWM7QUFDM0IsV0FBTztBQUFBLE1BQ0xtQyxPQUFPRCxLQUFLZDtBQUFBQSxNQUNaZ0IsUUFBUUYsS0FBS3hHLE9BQU8sQ0FBQzJHLFFBQVEsQ0FBQyxTQUFTLGNBQWMsZUFBZSxxQkFBcUIseUJBQXlCLFVBQVUsRUFBRUMsU0FBU0QsSUFBSUUsS0FBSyxDQUFDLEVBQUVuQjtBQUFBQSxNQUNuSm9CLFNBQVNOLEtBQUt4RyxPQUFPLENBQUMyRyxRQUFRQSxJQUFJRSxVQUFVLFNBQVMsRUFBRW5CO0FBQUFBLE1BQ3ZEcUIsV0FBV1AsS0FBS3hHLE9BQU8sQ0FBQzJHLFFBQVEsQ0FBQyxDQUFDQSxJQUFJSyx1QkFBdUIsQ0FBQyxXQUFXLG9CQUFvQixFQUFFSixTQUFTRCxJQUFJTSxjQUFjLEtBQUssQ0FBQyxRQUFRLE9BQU8sRUFBRUwsU0FBU0QsSUFBSU8sa0JBQWtCLENBQUMsRUFBRXhCO0FBQUFBLElBQ3JMO0FBQUEsRUFDRixHQUFHLENBQUNwQixVQUFVLENBQUM7QUFFZixRQUFNNkMsb0JBQW9CdkwsUUFBUSxNQUFNO0FBQ3RDLFVBQU00SyxPQUFPbEMsY0FBYztBQUMzQixXQUFPOEMsT0FBT0M7QUFBQUEsTUFDWmpJLGNBQWNTLElBQUksQ0FBQ0csV0FBVyxDQUFDQSxPQUFPWCxJQUFJVyxPQUFPWCxPQUFPLFFBQVFtSCxLQUFLZCxTQUFTL0gsbUJBQW1CNkksTUFBTXhHLE9BQU9YLEVBQUUsQ0FBQyxDQUFDO0FBQUEsSUFDcEg7QUFBQSxFQUNGLEdBQUcsQ0FBQ2lGLFVBQVUsQ0FBQztBQUVmLGlCQUFlZ0QsYUFBYTtBQUMxQm5ELGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixZQUFNcUIsU0FBUyxDQUFDLENBQUM7QUFBQSxJQUNuQixVQUFDO0FBQ0NyQixpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsUUFBTW9ELHNCQUFzQixDQUFDLENBQUMvQyxZQUFZLENBQUMsU0FBUyxXQUFXLGNBQWMsZUFBZSxZQUFZLHFCQUFxQix1QkFBdUIsRUFBRW9DLFNBQVNwQyxTQUFTZ0QsVUFBVVgsS0FBSyxLQUNsTCxDQUFDLENBQUNyQyxTQUFTZ0QsVUFBVUMsZUFDcEJqRCxTQUFTZ0QsVUFBVVAsbUJBQW1CLGNBQWN6QyxTQUFTZ0QsVUFBVVAsbUJBQW1CLGlCQUFpQnpDLFNBQVNnRCxVQUFVUCxtQkFBbUIsbUJBQ2xKLENBQUN6QyxTQUFTa0QsY0FBYzlCLEtBQUssQ0FBQytCLFFBQVEsQ0FBQyxXQUFXLFdBQVcsUUFBUSxFQUFFZixTQUFTZSxJQUFJcEgsTUFBTSxDQUFDO0FBRWhHLFFBQU1xSCxvQkFBb0IsQ0FBQyxDQUFDcEQsWUFDdkIsQ0FBQyxDQUFDLFFBQVEsY0FBYyxVQUFVLEVBQUVvQyxTQUFTcEMsU0FBU2dELFVBQVVYLEtBQUssS0FDckUsQ0FBQ3JDLFNBQVNrRCxjQUFjOUIsS0FBSyxDQUFDK0IsUUFBUSxDQUFDLFdBQVcsV0FBVyxRQUFRLEVBQUVmLFNBQVNlLElBQUlwSCxNQUFNLENBQUMsS0FDM0ZpRSxTQUFTa0QsY0FBYyxDQUFDLEdBQUduSCxXQUFXLGVBQ3RDaUUsU0FBU3FELG1CQUFtQkM7QUFFakMsUUFBTUMsbUJBQW1Cbk07QUFBQUEsSUFDdkIsTUFBTTRFLG1CQUFtQmdFLFVBQVV3RCx3QkFBd0IsSUFBSW5JLElBQUksQ0FBQ29CLGFBQWE7QUFBQSxNQUMvRSxHQUFHQTtBQUFBQSxNQUNIRixZQUFZRSxRQUFRRixjQUFjRSxRQUFRZ0gsaUJBQWlCO0FBQUEsSUFDN0QsRUFBRSxDQUFDO0FBQUEsSUFDSCxDQUFDekQsUUFBUTtBQUFBLEVBQ1g7QUFDQSxRQUFNMEQsZ0JBQWdCdE07QUFBQUEsSUFDcEIsTUFBTXFDLG1DQUFvQ3VHLFVBQVUyRCxhQUFhLElBQWMzRCxVQUFVZ0QsVUFBVVksaUJBQWlCO0FBQUEsSUFDcEgsQ0FBQzVELFFBQVE7QUFBQSxFQUNYO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsU0FBUTtBQUFBLFFBQ1IsT0FBTTtBQUFBLFFBQ04sYUFBWTtBQUFBLFFBQ1osTUFBTSx1QkFBQyxpQkFBYyxXQUFVLGFBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0M7QUFBQSxRQUN4QyxTQUNFLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlDQUFDLFVBQU8sU0FBUSxXQUFVLE1BQUssTUFBSyxTQUFTOEMsWUFBWSxVQUFVcEQsU0FDakU7QUFBQSxtQ0FBQyxZQUFTLFdBQVUsd0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdDO0FBQUEsWUFDdkNBLFVBQVUsYUFBYTtBQUFBLGVBRjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVMsTUFBTTtBQUMvQnZCLGdDQUFvQjBGLFdBQVdDLFFBQVFDLGFBQWEsS0FBSyxjQUFjQyxLQUFLQyxJQUFJLENBQUMsRUFBRTtBQUNuRjFHLDBCQUFjLElBQUk7QUFBQSxVQUNwQixHQUNFO0FBQUEsbUNBQUMsUUFBSyxXQUFVLHdCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBO0FBQUEsZUFKdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLGFBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUE7QUFBQSxNQWxCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFtQkc7QUFBQSxJQUdILHVCQUFDLFNBQUksV0FBVSxzQ0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLCtCQUFDLFlBQVMsT0FBTSxjQUFhLE9BQU93RSxPQUFPRSxTQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlEO0FBQUEsUUFDakQsdUJBQUMsWUFBUyxPQUFNLFVBQVMsT0FBT0YsT0FBT0csVUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QztBQUFBLFFBQzlDLHVCQUFDLFlBQVMsT0FBTSxXQUFVLE9BQU9ILE9BQU9PLFNBQVMsTUFBTVAsT0FBT08sVUFBVSxJQUFJLFFBQVEsYUFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RjtBQUFBLFFBQzlGLHVCQUFDLFlBQVMsT0FBTSxtQkFBa0IsT0FBT1AsT0FBT1EsV0FBVyxNQUFNUixPQUFPUSxZQUFZLElBQUksU0FBUyxVQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdHO0FBQUEsV0FKMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1ozSCx3QkFBY1MsSUFBSSxDQUFDRyxXQUFXO0FBQzdCLGNBQU0wRyxTQUFTbEYsUUFBUWtILGdCQUFnQjFJLE9BQU9YO0FBQzlDLGVBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLE1BQUs7QUFBQSxZQUNMLFNBQVNxSCxTQUFTLFlBQVk7QUFBQSxZQUM5QixTQUFTLE1BQU1qRixXQUFXLENBQUNrSCxhQUFhLEVBQUUsR0FBR0EsU0FBU0QsYUFBYTFJLE9BQU9YLEdBQUcsRUFBRTtBQUFBLFlBQy9FLFdBQVU7QUFBQSxZQUVUVztBQUFBQSxxQkFBT1Y7QUFBQUEsY0FDUix1QkFBQyxVQUFLLFdBQVUsd0VBQ2I2SCw0QkFBa0JuSCxPQUFPWCxFQUFFLEtBQUssS0FEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBO0FBQUE7QUFBQSxVQVRLVyxPQUFPWDtBQUFBQSxVQURkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFXQTtBQUFBLE1BRUosQ0FBQyxLQWpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsOEZBQ2I7QUFBQSwrQkFBQyxnQkFBYSxPQUFNLGNBQWEsT0FBT21DLFFBQVEwRSxZQUFZLFVBQVUsQ0FBQzFHLFVBQVVpQyxXQUFXLENBQUNrSCxhQUFhLEVBQUUsR0FBR0EsU0FBU3pDLFlBQVkxRyxNQUFNLEVBQUUsR0FBRyxTQUFTc0csZ0JBQXhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUs7QUFBQSxRQUNySyx1QkFBQyxnQkFBYSxPQUFNLFNBQVEsT0FBT3RFLFFBQVFxRixPQUFPLFVBQVUsQ0FBQ3JILFVBQVVpQyxXQUFXLENBQUNrSCxhQUFhLEVBQUUsR0FBR0EsU0FBUzlCLE9BQU9ySCxNQUFNLEVBQUUsR0FBRyxTQUFTLENBQUMsU0FBUyxjQUFjLGVBQWUsV0FBVyxxQkFBcUIseUJBQXlCLFlBQVksUUFBUSxZQUFZLEtBQXpRO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMlE7QUFBQSxRQUMzUSx1QkFBQyxnQkFBYSxPQUFNLFFBQU8sT0FBT2dDLFFBQVFvSCxXQUFXLFVBQVUsQ0FBQ3BKLFVBQVVpQyxXQUFXLENBQUNrSCxhQUFhLEVBQUUsR0FBR0EsU0FBU0MsV0FBV3BKLE1BQU0sRUFBRSxHQUFHLFNBQVMsQ0FBQyxPQUFPLFVBQVUsUUFBUSxVQUFVLEtBQXBMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0w7QUFBQSxRQUN0TCx1QkFBQyxnQkFBYSxPQUFNLFlBQVcsT0FBT2dDLFFBQVE0RSxlQUFlLFVBQVUsQ0FBQzVHLFVBQVVpQyxXQUFXLENBQUNrSCxhQUFhLEVBQUUsR0FBR0EsU0FBU3ZDLGVBQWU1RyxNQUFNLEVBQUUsR0FBRyxTQUFTMkcsa0JBQTVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMks7QUFBQSxRQUMzSyx1QkFBQyxnQkFBYSxPQUFNLGdCQUFlLE9BQU8zRSxRQUFROEUsYUFBYSxVQUFVLENBQUM5RyxVQUFVaUMsV0FBVyxDQUFDa0gsYUFBYSxFQUFFLEdBQUdBLFNBQVNyQyxhQUFhOUcsTUFBTSxFQUFFLEdBQUcsU0FBUzZHLGNBQTVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUs7QUFBQSxRQUN2Syx1QkFBQyxnQkFBYSxPQUFNLGdCQUFlLE9BQU83RSxRQUFRMEYsb0JBQW9CLFVBQVUsQ0FBQzFILFVBQVVpQyxXQUFXLENBQUNrSCxhQUFhLEVBQUUsR0FBR0EsU0FBU3pCLG9CQUFvQjFILE1BQU0sRUFBRSxHQUFHLFNBQVMsQ0FBQyxXQUFXLFFBQVEsUUFBUSxVQUFVLE9BQU8sS0FBdk47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5TjtBQUFBLFdBTjNOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHdFQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFXLEdBQUdvQyxtQkFBbUIsb0JBQW9CLE9BQU8sY0FDOUQ2RCxtQkFBU0MsV0FBVyxJQUNuQix1QkFBQyxRQUFLLFdBQVUsaURBQStDLHlEQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFFQUQsU0FBUzVGLElBQUksQ0FBQ2dHLFNBQVM7QUFDckIsZ0JBQU1nRCxjQUFjaEQsS0FBS0YsUUFBUWpFO0FBQ2pDLGlCQUNFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU07QUFDYkMsOEJBQWNrRSxLQUFLRixHQUFHO0FBQ3RCOUQsb0NBQW9CLElBQUk7QUFBQSxjQUMxQjtBQUFBLGNBQ0EsY0FBWSxHQUFHZ0UsS0FBSzNGLEtBQUssbUJBQW1CckMsaUJBQWlCZ0ksSUFBSSxDQUFDO0FBQUEsY0FDbEUsV0FBVyw0REFBNERnRCxjQUFjLHNEQUFzRCx1RUFBdUU7QUFBQSxjQUVsTjtBQUFBLHVDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLHVDQUF1Q2hELGVBQUszRixTQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpRTtBQUFBLG9CQUNqRSx1QkFBQyxTQUFJLFdBQVUsbURBQW1EMkYsZUFBS2lELGtCQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFzRjtBQUFBLHVCQUZ4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBTSxTQUFRLFdBQVUsV0FBVzNLLFlBQVkwSCxLQUFLK0MsU0FBUyxLQUFLLElBQUsvQyxlQUFLK0MsYUFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUY7QUFBQSxxQkFMekY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLHlDQUFDLFNBQU0sU0FBUSxXQUFVLFdBQVdwSyxhQUFhcUgsS0FBS2dCLEtBQUssS0FBSyxJQUFLdEgsc0JBQVlzRyxLQUFLZ0IsS0FBSyxLQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2RjtBQUFBLGtCQUM3Rix1QkFBQyxTQUFNLFNBQVEsV0FBV2hCLGVBQUtLLGNBQWMsYUFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUQ7QUFBQSxrQkFDdkQsdUJBQUMsU0FBTSxTQUFRLFdBQVU7QUFBQTtBQUFBLG9CQUFXTCxLQUFLNEIsY0FBYztBQUFBLHVCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyRDtBQUFBLGtCQUMzRCx1QkFBQyxTQUFNLFNBQVEsV0FBVTtBQUFBO0FBQUEsb0JBQWU1QixLQUFLcUI7QUFBQUEsdUJBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdFO0FBQUEsa0JBQy9EckIsS0FBS2tELFVBQVVDLHlCQUF5Qix1QkFBQyxTQUFNLFNBQVEsV0FBVSxXQUFVLGtEQUFpRCxzQ0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEcsSUFBVztBQUFBLGtCQUM3Sm5ELEtBQUtvRCxxQkFDSix1QkFBQyxTQUFNLFNBQVEsV0FBUztBQUFBO0FBQUEsb0JBQ2hCcEQsS0FBS29ELG1CQUFtQjFJO0FBQUFBLG9CQUFPO0FBQUEsb0JBQUlzRixLQUFLb0QsbUJBQW1CeEI7QUFBQUEsdUJBRG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUEsSUFDRTtBQUFBLHFCQVZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0E7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsZ0VBQ2I7QUFBQSx5Q0FBQyxTQUNDO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHNCQUFxQix5QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEM7QUFBQSxvQkFBTztBQUFBLG9CQUFFNUIsS0FBS08saUJBQWlCUCxLQUFLcUQsaUJBQWlCO0FBQUEsdUJBRHJHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxTQUNDO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHNCQUFxQiwwQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0M7QUFBQSxvQkFBTztBQUFBLG9CQUFFckQsS0FBS1MsZUFBZTtBQUFBLHVCQUQ5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFVBQUssV0FBVSxzQkFBcUIsNEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlEO0FBQUEsb0JBQU87QUFBQSxvQkFBRXpJLGlCQUFpQmdJLElBQUk7QUFBQSx1QkFEakY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSxzQkFBcUIsMEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStDO0FBQUEsb0JBQU87QUFBQSxvQkFBRTlILDJCQUEyQjhILElBQUk7QUFBQSx1QkFEekY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBYUE7QUFBQTtBQUFBO0FBQUEsWUEzQ0tBLEtBQUtGO0FBQUFBLFlBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQTZDQTtBQUFBLFFBRUosQ0FBQyxLQXhETDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMERBO0FBQUEsUUFFQSx1QkFBQyxRQUFLLFdBQVcsR0FBRy9ELG1CQUFtQixVQUFVLGlCQUFpQixzQkFDL0QsV0FBQzRDLFdBQ0EsdUJBQUMsU0FBSSxXQUFVLGlDQUFnQyxpR0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnSSxJQUVoSSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFRO0FBQUEsY0FDUixXQUFVO0FBQUEsY0FDVixTQUFTLE1BQU0zQyxvQkFBb0IsS0FBSztBQUFBLGNBRXhDO0FBQUEsdUNBQUMsYUFBVSxXQUFVLHdCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5QztBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLG9EQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFNBQUksV0FBVSx5Q0FBeUMyQyxtQkFBU2dELFVBQVV0SCxTQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRjtBQUFBLGdCQUNqRix1QkFBQyxTQUFJLFdBQVUsc0NBQXNDc0UsbUJBQVNnRCxVQUFVdEIsY0FBYyw0QkFBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0c7QUFBQSxtQkFGakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsdUNBQUMsU0FBTSxTQUFRLFdBQVUsV0FBVy9ILFlBQVlxRyxTQUFTZ0QsVUFBVW9CLFNBQVMsS0FBSyxJQUFLcEUsbUJBQVNnRCxVQUFVb0IsYUFBekc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUg7QUFBQSxnQkFDbkgsdUJBQUMsU0FBTSxTQUFRLFdBQVUsV0FBV3BLLGFBQWFnRyxTQUFTZ0QsVUFBVVgsS0FBSyxLQUFLLElBQUt0SCxzQkFBWWlGLFNBQVNnRCxVQUFVWCxLQUFLLEtBQXZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlIO0FBQUEsbUJBRjNIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxxQ0FBQyxVQUFPLE1BQUssTUFBSyxTQUFRLFdBQVUsU0FBUyxNQUFNO0FBQUU5QyxtQ0FBbUIsSUFBSTtBQUFHMUIsZ0NBQWdCLElBQUk7QUFBQSxjQUFHLEdBQUcsZ0NBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlIO0FBQUEsY0FDekgsdUJBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxXQUFVLFNBQVMsTUFBTTtBQUFFMEIsbUNBQW1CLElBQUk7QUFBR3hCLDhCQUFjLElBQUk7QUFBQSxjQUFHLEdBQUcsVUFBVSxDQUFDLGNBQWMsVUFBVSxFQUFFcUUsU0FBU3BDLFNBQVNnRCxVQUFVWCxLQUFLLEdBQUcsc0JBQWhMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNMO0FBQUEsY0FDdEwsdUJBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxXQUFVLFNBQVMsWUFBWTtBQUN2RCxvQkFBSTtBQUNGOUMscUNBQW1CLElBQUk7QUFDdkIsd0JBQU13Qix3QkFBd0IsRUFBRWIsYUFBYUYsU0FBU2dELFVBQVU3QixJQUFJLENBQUM7QUFBQSxnQkFDdkUsU0FBU3dELEtBQUs7QUFDWnBGLHFDQUFtQm9GLGVBQWVDLFFBQVFELElBQUlFLFVBQVUscUNBQXFDO0FBQUEsZ0JBQy9GO0FBQUEsY0FDRixHQUFHLGtDQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT3FCO0FBQUEsY0FDckIsdUJBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxXQUFVLFNBQVMsTUFBTTtBQUFFdEYsbUNBQW1CLElBQUk7QUFBR3RCLGlDQUFpQixJQUFJO0FBQUEsY0FBRyxHQUFHLFVBQVUrQixTQUFTZ0QsVUFBVVgsVUFBVSxjQUFjLHlCQUEvSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3SztBQUFBLGlCQVgxSztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsZUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQSxVQUVBLHVCQUFDLFdBQVEsT0FBTSxXQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLDhDQUE4Q3JDLG1CQUFTZ0QsVUFBVXNCLGtCQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RjtBQUFBLFlBQzVGdEUsU0FBU2dELFVBQVU4QixVQUNsQix1QkFBQyxPQUFFLFdBQVUsc0RBQXNEOUUsbUJBQVNnRCxVQUFVOEIsV0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEYsSUFDNUY7QUFBQSxlQUpOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUVDOUUsU0FBU2dELFVBQVV1QixVQUFVQyx5QkFDNUIsdUJBQUMsV0FBUSxPQUFNLHNCQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLHFDQUNaO0FBQUEscUNBQUMsV0FBUSxPQUFNLGNBQWEsT0FBT3hFLFNBQVNnRCxVQUFVdUIsU0FBU0MsMEJBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNGO0FBQUEsY0FDdEYsdUJBQUMsV0FBUSxPQUFNLG9CQUFtQixPQUFPeEUsU0FBU2dELFVBQVV1QixTQUFTUSw2QkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0Y7QUFBQSxjQUMvRix1QkFBQyxXQUFRLE9BQU0sV0FBVSxPQUFPL0UsU0FBU2dELFVBQVV1QixTQUFTUyxtQkFBbUJDLFFBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9GO0FBQUEsY0FDcEYsdUJBQUMsV0FBUSxPQUFNLFNBQVEsT0FBT2pGLFNBQVNnRCxVQUFVdUIsU0FBU1csbUJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBFO0FBQUEsaUJBSjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSxzQ0FBb0Msc0lBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUEsSUFDRTtBQUFBLFVBRUosdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsbUNBQUMsV0FBUSxPQUFNLG1CQUNiLGlDQUFDLFFBQUcsV0FBVSxxQkFDWjtBQUFBLHFDQUFDLFdBQVEsT0FBTSw4QkFBNkIsT0FBT2xGLFNBQVNnRCxVQUFVbUMsa0JBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFGO0FBQUEsY0FDckYsdUJBQUMsV0FBUSxPQUFNLFlBQVcsT0FBT25GLFNBQVNnRCxVQUFVQyxjQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErRDtBQUFBLGNBQy9ELHVCQUFDLFdBQVEsT0FBTSxZQUFXLE9BQU9qRCxTQUFTZ0QsVUFBVXBCLGlCQUFpQjVCLFNBQVNnRCxVQUFVMEIsaUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNHO0FBQUEsY0FDdEcsdUJBQUMsV0FBUSxPQUFNLGdCQUFlLE9BQU8xRSxTQUFTZ0QsVUFBVWxCLGVBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9FO0FBQUEsY0FDcEUsdUJBQUMsV0FBUSxPQUFNLFlBQVcsT0FBTzlCLFNBQVNnRCxVQUFVUCxrQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUU7QUFBQSxjQUNuRSx1QkFBQyxXQUFRLE9BQU0sZ0JBQWUsT0FBT3pDLFNBQVNnRCxVQUFVTixzQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkU7QUFBQSxpQkFON0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxZQUNBLHVCQUFDLFdBQVEsT0FBTSxzQkFDWjFDO0FBQUFBLHVCQUFTZ0QsVUFBVVIsc0JBQ2xCLHVCQUFDLE9BQUUsV0FBVSwwQkFBMEJ4QyxtQkFBU2dELFVBQVVSLHVCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4RSxJQUU5RSx1QkFBQyxPQUFFLFdBQVUsaUNBQWdDLGdEQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RTtBQUFBLGNBRTlFeEMsU0FBU2dELFVBQVVvQyxnQkFDbEIsdUJBQUMsU0FBSSxXQUFVLHdGQUNiO0FBQUEsdUNBQUMsaUJBQWMsV0FBVSx5QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEM7QUFBQSxnQkFDN0NwRixTQUFTZ0QsVUFBVW9DO0FBQUFBLG1CQUZ0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBLElBQ0U7QUFBQSxpQkFYTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsZUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQSxVQUVBLHVCQUFDLFdBQVEsT0FBTSx3QkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLHFDQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGlFQUFnRSwrQkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEY7QUFBQSxnQkFDOUYsdUJBQUMsU0FBSSxXQUFVLDhDQUE4Q3BGLG1CQUFTZ0QsVUFBVVAsa0JBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStGO0FBQUEsbUJBRmpHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGlFQUFnRSxtQ0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0c7QUFBQSxnQkFDbEcsdUJBQUMsU0FBSSxXQUFVLDhDQUE4Q3pDLG1CQUFTZ0QsVUFBVU4sc0JBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1HO0FBQUEsbUJBRnJHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGlFQUFnRSxpQ0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0c7QUFBQSxnQkFDaEcsdUJBQUMsU0FBSSxXQUFVLDZDQUE2QzFDLG1CQUFTcUQsbUJBQW1CZ0Msc0JBQXNCbkUsVUFBVSxLQUF4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwSDtBQUFBLG1CQUY1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLHVDQUFDLFNBQUksV0FBVSxpRUFBZ0UsZ0NBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStGO0FBQUEsZ0JBQy9GLHVCQUFDLFNBQUksV0FBVSwyQ0FBNENsQixvQkFBU3FELG1CQUFtQmlDLG1CQUFtQnBFLFVBQVUsTUFBTWxCLFNBQVNxRCxtQkFBbUJrQyxrQkFBa0JyRSxVQUFVLE1BQU1sQixTQUFTcUQsbUJBQW1CbUMsb0JBQW9CdEUsVUFBVSxNQUFsUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxUDtBQUFBLG1CQUZ2UDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMEVBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsdUNBQXNDLDZEQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRztBQUFBLGdCQUNsRyx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSx5Q0FBQyxVQUFPLE1BQUssTUFBSyxTQUFRLFdBQVUsU0FBUyxNQUFNO0FBQUUzQix1Q0FBbUIsSUFBSTtBQUFHOUIsb0NBQWdCLElBQUk7QUFBQSxrQkFBRyxHQUNwRztBQUFBLDJDQUFDLGVBQVksV0FBVSx3QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkM7QUFBQTtBQUFBLHVCQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxXQUFVLFNBQVMsTUFBTTtBQUFFOEIsdUNBQW1CLElBQUk7QUFBRzVCLG1DQUFlLElBQUk7QUFBQSxrQkFBRyxHQUFFLDhCQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVMsWUFBWTtBQUNuQiw0QkFBSTtBQUNGNEIsNkNBQW1CLElBQUk7QUFDdkJoQix5Q0FBZXlCLFNBQVNnRCxVQUFVN0IsR0FBRztBQUNyQyxnQ0FBTVYsZ0JBQWdCO0FBQUEsNEJBQ3BCUCxhQUFhRixTQUFTZ0QsVUFBVTdCO0FBQUFBLDRCQUNoQ3NFLFdBQVc7QUFBQSw0QkFDWEMsU0FBUztBQUFBLDRCQUNUQyxnQkFBZ0IsYUFBYTNGLFNBQVNnRCxVQUFVN0IsR0FBRyxJQUFJbkIsU0FBU2dELFVBQVU0QyxTQUFTO0FBQUEsMEJBQ3JGLENBQUM7QUFBQSx3QkFDSCxTQUFTakIsS0FBSztBQUNacEYsNkNBQW1Cb0YsZUFBZUMsUUFBUUQsSUFBSUUsVUFBVSxtQkFBbUI7QUFBQSx3QkFDN0UsVUFBQztBQUNDdEcseUNBQWUsSUFBSTtBQUFBLHdCQUNyQjtBQUFBLHNCQUNGO0FBQUEsc0JBQ0EsVUFBVSxDQUFDNkUscUJBQXFCOUUsZ0JBQWdCMEIsU0FBU2dELFVBQVU3QjtBQUFBQSxzQkFFbEU3QywwQkFBZ0IwQixTQUFTZ0QsVUFBVTdCLE1BQU0sZUFBZTtBQUFBO0FBQUEsb0JBcEIzRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBcUJBO0FBQUEscUJBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBOEJBO0FBQUEsbUJBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUNBO0FBQUEsY0FDQzdCLGtCQUFrQix1QkFBQyxTQUFJLFdBQVUsNkJBQTZCQSw2QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEQsSUFBUztBQUFBLGVBQ3RGVSxTQUFTcUQsbUJBQW1Cd0MsaUJBQWlCM0UsVUFBVSxLQUFLLElBQzVELHVCQUFDLFFBQUcsV0FBVSwwREFDWGxCLG1CQUFTcUQsa0JBQWtCd0MsZ0JBQWdCeEs7QUFBQUEsZ0JBQUksQ0FBQ3lLLFFBQVFuSyxVQUN2RCx1QkFBQyxRQUF1RG1LLG9CQUEvQyxHQUFHOUYsU0FBU2dELFVBQVU3QixHQUFHLFlBQVl4RixLQUFLLElBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStEO0FBQUEsY0FDaEUsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBLElBRUEsdUJBQUMsT0FBRSxXQUFVLDRCQUEyQixpSEFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUk7QUFBQSxpQkEzQzdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkNBO0FBQUEsZUFqRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrRUE7QUFBQSxVQUVBLHVCQUFDLFdBQVEsT0FBTSxzQkFDYixpQ0FBQyxTQUFJLFdBQVUsYUFDWnFFLG1CQUFTK0YsbUJBQW1CN0UsU0FBU2xCLFNBQVMrRixrQkFBa0IxSztBQUFBQSxZQUFJLENBQUMySyxhQUNwRSx1QkFBQyxTQUF1QixXQUFVLDJFQUNoQztBQUFBLHFDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHVDQUFDLFNBQ0M7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsdUNBQXVDQSxtQkFBU0MsZ0JBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTRFO0FBQUEsa0JBQzVFLHVCQUFDLFNBQUksV0FBVSxzQ0FBc0NELG1CQUFTRSxtQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEU7QUFBQSxxQkFGaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLFNBQU0sU0FBUSxXQUFXRixtQkFBU2pLLFVBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBDO0FBQUEsbUJBTDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxnRUFDYjtBQUFBLHVDQUFDLFNBQUk7QUFBQTtBQUFBLGtCQUFNLHVCQUFDLFVBQUssV0FBVSxzQkFBc0JpSyxtQkFBUzVCLGFBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlEO0FBQUEscUJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJFO0FBQUEsZ0JBQzNFLHVCQUFDLFNBQUk7QUFBQTtBQUFBLGtCQUFjLHVCQUFDLFVBQUssV0FBVSxzQkFBc0I0QixtQkFBU2xFLGVBQWUsT0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0U7QUFBQSxxQkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEY7QUFBQSxnQkFDNUYsdUJBQUMsU0FBSTtBQUFBO0FBQUEsa0JBQVUsdUJBQUMsVUFBSyxXQUFVLHNCQUFzQmtFLG1CQUFTRyxZQUFZLE9BQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStEO0FBQUEscUJBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFGO0FBQUEsZ0JBQ3JGLHVCQUFDLFNBQUk7QUFBQTtBQUFBLGtCQUFTLHVCQUFDLFVBQUssV0FBVSxzQkFBc0JILG1CQUFTSSxZQUFZLElBQUlwQyxLQUFLZ0MsU0FBU0ksU0FBUyxFQUFFQyxlQUFlLElBQUksT0FBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0c7QUFBQSxxQkFBN0g7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0k7QUFBQSxtQkFKdEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0NMLFNBQVNGLFNBQVMsdUJBQUMsU0FBSSxXQUFVLHNDQUFxQztBQUFBO0FBQUEsZ0JBQVNFLFNBQVNGO0FBQUFBLG1CQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RSxJQUFTO0FBQUEsY0FDeEdFLFNBQVNNLFlBQVlwRixTQUFTLHVCQUFDLFNBQUksV0FBVSxxQ0FBb0M7QUFBQTtBQUFBLGdCQUFhOEUsU0FBU00sV0FBV0MsS0FBSyxJQUFJO0FBQUEsbUJBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStGLElBQVM7QUFBQSxpQkFmL0hQLFNBQVM3RSxLQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdCQTtBQUFBLFVBQ0QsSUFDQyx1QkFBQyxPQUFFLFdBQVUsaUNBQWdDLG1EQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRixLQXBCcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkEsS0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQSxVQUVBLHVCQUFDLFdBQVEsT0FBTSxxQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLHFDQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGlFQUFnRSxnQ0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0Y7QUFBQSxnQkFDL0YsdUJBQUMsU0FBSSxXQUFVLDhDQUE2QztBQUFBO0FBQUEsa0JBQUVuQixTQUFTZ0QsVUFBVXdELHlCQUF5QjtBQUFBLHFCQUExRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0RztBQUFBLG1CQUY5RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLHVDQUFDLFNBQUksV0FBVSxpRUFBZ0Usa0NBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlHO0FBQUEsZ0JBQ2pHLHVCQUFDLFNBQUksV0FBVSw2Q0FBNkN4RyxtQkFBU3lHLGtCQUFrQkMsbUJBQW1CeEYsVUFBVSxLQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzSDtBQUFBLG1CQUZ4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLHVDQUFDLFNBQUksV0FBVSxpRUFBZ0UsaUNBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdHO0FBQUEsZ0JBQ2hHLHVCQUFDLFNBQUksV0FBVSwyQ0FBMkNsQixtQkFBU3lHLGtCQUFrQkUsa0JBQWtCekYsVUFBVSxLQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtSDtBQUFBLG1CQUZySDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLHVDQUFDLFNBQUksV0FBVSxpRUFBZ0UsOEJBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZGO0FBQUEsZ0JBQzdGLHVCQUFDLFNBQUksV0FBVSwyQ0FBMkNsQixtQkFBU3lHLGtCQUFrQkcsZUFBZTFGLFVBQVUsS0FBOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0g7QUFBQSxtQkFGbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHdHQUNiO0FBQUEscUNBQUMsU0FBSTtBQUFBO0FBQUEsZ0JBQXFCLHVCQUFDLFVBQUssV0FBVSxzQkFBc0JsQixtQkFBU3lHLGtCQUFrQkkscUJBQXFCLFFBQVEsUUFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUc7QUFBQSxtQkFBN0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0k7QUFBQSxjQUNwSSx1QkFBQyxTQUFJLFdBQVUsUUFBTztBQUFBO0FBQUEsZ0JBQXlCLHVCQUFDLFVBQUssV0FBVSxzQkFBc0I3RyxtQkFBU3lHLGtCQUFrQksseUJBQXlCLFFBQVEsUUFBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUc7QUFBQSxtQkFBdEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNko7QUFBQSxjQUM3Six1QkFBQyxTQUFJLFdBQVUsUUFBTztBQUFBO0FBQUEsZ0JBQTBCLHVCQUFDLFVBQUssV0FBVSxzQkFBc0I5RyxtQkFBU3lHLGtCQUFrQk0seUJBQXlCLElBQUkvRyxTQUFTeUcsaUJBQWlCTSxzQkFBc0IsS0FBSyxPQUFuSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1SjtBQUFBLG1CQUF2TTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4TTtBQUFBLGNBQzlNLHVCQUFDLFNBQUksV0FBVSxRQUFPO0FBQUE7QUFBQSxnQkFBaUIsdUJBQUMsVUFBSyxXQUFVLHNCQUFzQi9HLG1CQUFTeUcsa0JBQWtCWixrQkFBa0IsQ0FBQyxLQUFLLE9BQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZGO0FBQUEsbUJBQXBJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJJO0FBQUEsaUJBSjdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlCQTtBQUFBLFVBRUEsdUJBQUMsV0FBUSxPQUFNLG9CQUNiLGlDQUFDLFNBQUksV0FBVSxhQUNabkM7QUFBQUEsMEJBQWNTLFVBQ2IsdUJBQUMsU0FBSSxXQUFVLGlGQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsdUNBQUMsU0FDQztBQUFBLHlDQUFDLFNBQUksV0FBVSx1Q0FBc0M7QUFBQTtBQUFBLG9CQUFtQlQsY0FBY1MsUUFBUTZDO0FBQUFBLHVCQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2RztBQUFBLGtCQUM3Ryx1QkFBQyxTQUFJLFdBQVUsc0NBQXNDdEQsd0JBQWNTLFFBQVE4QyxpQkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUY7QUFBQSxxQkFGM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHlDQUFDLFNBQU0sU0FBUSxXQUFXdkQsd0JBQWNTLFFBQVFwSSxVQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RDtBQUFBLGtCQUN0RDJILGNBQWNTLFFBQVFwSSxXQUFXLHFCQUNoQztBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBUTtBQUFBLHNCQUNSLFNBQVMsWUFBWTtBQUNuQiw0QkFBSTtBQUNGd0QsNkNBQW1CLElBQUk7QUFDdkJkLHdDQUFjaUYsY0FBY1MsUUFBUWhELEdBQUc7QUFDdkMsZ0NBQU1QLHlCQUF5QixFQUFFc0cscUJBQXFCeEQsY0FBY1MsUUFBUWhELEtBQWlDZ0csWUFBWSxXQUFXLENBQUM7QUFBQSx3QkFDdkksU0FBU3hDLEtBQUs7QUFDWnBGLDZDQUFtQm9GLGVBQWVDLFFBQVFELElBQUlFLFVBQVUsNEJBQTRCO0FBQUEsd0JBQ3RGLFVBQUM7QUFDQ3BHLHdDQUFjLElBQUk7QUFBQSx3QkFDcEI7QUFBQSxzQkFDRjtBQUFBLHNCQUNBLFVBQVVELGVBQWVrRixjQUFjUyxRQUFRaEQ7QUFBQUEsc0JBRTlDM0MseUJBQWVrRixjQUFjUyxRQUFRaEQsTUFBTSxjQUFjO0FBQUE7QUFBQSxvQkFoQjVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFpQkEsSUFDRTtBQUFBLHFCQXJCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXNCQTtBQUFBLG1CQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTRCQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHNDQUFzQ3pILG1DQUF5QmdLLGNBQWNTLE9BQU8sS0FBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUc7QUFBQSxpQkE5QnZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0JBLElBQ0U7QUFBQSxZQUNIVCxjQUFjMEQsV0FBV2xHLFNBQVN3QyxjQUFjMEQsV0FBVy9MO0FBQUFBLGNBQUksQ0FBQ2dNLGFBQy9ELHVCQUFDLFNBQXVCLFdBQVUsMkVBQ2hDO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEseUNBQUMsU0FDQztBQUFBLDJDQUFDLFNBQUksV0FBVSx1Q0FBc0M7QUFBQTtBQUFBLHNCQUFzQkEsU0FBU0w7QUFBQUEseUJBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1HO0FBQUEsb0JBQ25HLHVCQUFDLFNBQUksV0FBVSxzQ0FBc0NLLG1CQUFTSixpQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNEU7QUFBQSx1QkFGOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDJDQUFDLFNBQU0sU0FBUSxXQUFXSSxtQkFBU3RMLFVBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTBDO0FBQUEsb0JBQ3pDc0wsU0FBU3RMLFdBQVcscUJBQ25CO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxTQUFRO0FBQUEsd0JBQ1IsU0FBUyxZQUFZO0FBQ25CLDhCQUFJO0FBQ0Z3RCwrQ0FBbUIsSUFBSTtBQUN2QmQsMENBQWM0SSxTQUFTbEcsR0FBRztBQUMxQixrQ0FBTVAseUJBQXlCLEVBQUVzRyxxQkFBcUJHLFNBQVNsRyxLQUFpQ2dHLFlBQVksV0FBVyxDQUFDO0FBQUEsMEJBQzFILFNBQVN4QyxLQUFLO0FBQ1pwRiwrQ0FBbUJvRixlQUFlQyxRQUFRRCxJQUFJRSxVQUFVLDRCQUE0QjtBQUFBLDBCQUN0RixVQUFDO0FBQ0NwRywwQ0FBYyxJQUFJO0FBQUEsMEJBQ3BCO0FBQUEsd0JBQ0Y7QUFBQSx3QkFDQSxVQUFVRCxlQUFlNkksU0FBU2xHO0FBQUFBLHdCQUVqQzNDLHlCQUFlNkksU0FBU2xHLE1BQU0sY0FBYztBQUFBO0FBQUEsc0JBaEIvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBaUJBLElBQ0U7QUFBQSx1QkFyQk47QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFzQkE7QUFBQSxxQkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE0QkE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsc0NBQXFDO0FBQUE7QUFBQSxrQkFBVWtHLFNBQVNDLGNBQWNmLEtBQUssSUFBSSxLQUFLO0FBQUEscUJBQW5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVHO0FBQUEsZ0JBQ3ZHLHVCQUFDLFNBQUksV0FBVSxzQ0FBcUM7QUFBQTtBQUFBLGtCQUFTN00seUJBQXlCMk4sUUFBUTtBQUFBLHFCQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnRztBQUFBLGdCQUNoRyx1QkFBQyxTQUFJLFdBQVUsc0NBQXFDO0FBQUE7QUFBQSxrQkFBUUEsU0FBU0YsY0FBY0UsU0FBU3ZGLGVBQWU7QUFBQSxrQkFBSTtBQUFBLGtCQUFJdUYsU0FBU0UsY0FBYyxJQUFJdkQsS0FBS3FELFNBQVNFLFdBQVcsRUFBRWxCLGVBQWUsSUFBSSxJQUFJckMsS0FBS3FELFNBQVNHLFNBQVMsRUFBRW5CLGVBQWU7QUFBQSxxQkFBeE87QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBME87QUFBQSxtQkFoQ2xPZ0IsU0FBU2xHLEtBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUNBO0FBQUEsWUFDRCxJQUNDLHVCQUFDLE9BQUUsV0FBVSxpQ0FBZ0MsNENBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlFO0FBQUEsZUF2RTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUVBLEtBMUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMkVBO0FBQUEsVUFFQSx1QkFBQyxXQUFRLE9BQU0sa0NBQ2IsaUNBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsbUNBQUMsU0FBSTtBQUFBO0FBQUEsY0FBeUIsdUJBQUMsVUFBSyxXQUFVLHNCQUFzQm5CLG1CQUFTeUcsa0JBQWtCZ0IseUJBQXlCLElBQUl6SCxTQUFTeUcsaUJBQWlCZ0IsdUJBQXVCVCxjQUFjLEtBQUssT0FBbEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0s7QUFBQSxpQkFBcE07QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMk07QUFBQSxZQUMzTSx1QkFBQyxTQUFJO0FBQUE7QUFBQSxjQUFlLHVCQUFDLFVBQUssV0FBVSxzQkFBc0JoSCxtQkFBUzBILGtCQUFrQixDQUFDLEdBQUc1QixVQUFVLE9BQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1GO0FBQUEsaUJBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThHO0FBQUEsWUFDOUcsdUJBQUMsU0FBSTtBQUFBO0FBQUEsY0FBdUIsdUJBQUMsVUFBSyxXQUFVLHNCQUFzQjlGLG1CQUFTMEgsa0JBQWtCLENBQUMsR0FBR0MsdUJBQXVCLE9BQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdHO0FBQUEsaUJBQTVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1JO0FBQUEsWUFDbkksdUJBQUMsU0FBSTtBQUFBO0FBQUEsY0FBc0IsdUJBQUMsVUFBSyxXQUFVLHNCQUFzQjNILG1CQUFTMEgsa0JBQWtCLENBQUMsR0FBR0UsdUJBQXVCMUcsVUFBVSxLQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RztBQUFBLGlCQUFuSTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwSTtBQUFBLFlBQzFJLHVCQUFDLFNBQUk7QUFBQTtBQUFBLGNBQXVCLHVCQUFDLFVBQUssV0FBVSxzQkFBc0JsQixtQkFBUzZILGNBQWNDLDBCQUEwQjlILFNBQVNnRCxVQUFVK0UsMkJBQTJCLE9BQXJJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlJO0FBQUEsaUJBQXJLO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRLO0FBQUEsZUFMOUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxVQUVBLHVCQUFDLFdBQVEsT0FBTSxvQ0FDYixpQ0FBQyxTQUFJLFdBQVUsYUFDWi9ILG1CQUFTZ0QsVUFBVWdGLG1CQUFtQjNNLElBQUksQ0FBQzRNLGNBQWM7QUFDeEQsa0JBQU14TCxVQUFVOEcsaUJBQWlCdEQsSUFBSWdJLFVBQVVwTixFQUFFO0FBQ2pELGtCQUFNcU4saUJBQWlCekwsU0FBU1YsV0FBVyxXQUN2QywwQkFDQVUsU0FBU1YsV0FBVyxVQUNsQiwyQ0FDQVUsU0FBU1YsV0FBVyxZQUFZLENBQUNVLFFBQVEwTCwyQkFDdkMsNEJBQ0EsQ0FBQzFMLFVBQ0MsaUNBQ0E7QUFDVixtQkFDRSx1QkFBQyxTQUF1QixXQUFVLDJFQUNoQztBQUFBLHFDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHVDQUFDLFNBQ0M7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsdUNBQXVDd0wsb0JBQVV2TSxTQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzRTtBQUFBLGtCQUN0RSx1QkFBQyxTQUFJLFdBQVUsc0NBQXFDO0FBQUE7QUFBQSxvQkFBU3VNLFVBQVVuTSxzQkFBc0I7QUFBQSx1QkFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0c7QUFBQSxrQkFDckdtTSxVQUFVcE0sY0FBYyx1QkFBQyxTQUFJLFdBQVUsc0NBQXNDb00sb0JBQVVwTSxlQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyRSxJQUFTO0FBQUEscUJBSC9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFNLFNBQVEsV0FBV1ksbUJBQVNWLFVBQVUsYUFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUQ7QUFBQSxtQkFOekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLCtFQUNiO0FBQUEsdUNBQUMsU0FBSTtBQUFBO0FBQUEsa0JBQVUsdUJBQUMsVUFBSyxXQUFVLHNCQUFzQlUsbUJBQVMyTCxvQkFBb0IzTCxTQUFTNEwscUJBQXFCLE9BQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFHO0FBQUEscUJBQXBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJIO0FBQUEsZ0JBQzNILHVCQUFDLFNBQUk7QUFBQTtBQUFBLGtCQUFLLHVCQUFDLFVBQUssV0FBVSxzQkFBc0JySSxtQkFBU2tELGNBQWNvRixLQUFLLENBQUNuRixRQUFRQSxJQUFJaEMsUUFBUTFFLFNBQVM4TCxhQUFhLEdBQUdDLFNBQVMsT0FBekg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkg7QUFBQSxxQkFBdkk7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEk7QUFBQSxnQkFDOUksdUJBQUMsU0FBSTtBQUFBO0FBQUEsa0JBQVUsdUJBQUMsVUFBSyxXQUFVLHNCQUFzQi9MLG1CQUFTZ00sWUFBWSxPQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErRDtBQUFBLHFCQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRjtBQUFBLGdCQUNyRix1QkFBQyxTQUFJO0FBQUE7QUFBQSxrQkFBVyx1QkFBQyxVQUFLLFdBQVUsc0JBQXNCaE0sbUJBQVNGLGFBQWEsSUFBSXlILEtBQUt2SCxRQUFRRixVQUFVLEVBQUU4SixlQUFlLElBQUksT0FBNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0g7QUFBQSxxQkFBaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUk7QUFBQSxtQkFKekk7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGdFQUNiO0FBQUEsdUNBQUMsU0FBSTtBQUFBO0FBQUEsa0JBQW9CLHVCQUFDLFVBQUssV0FBVSxzQkFBc0I1SixtQkFBU2lNLHFCQUFxQixPQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RTtBQUFBLHFCQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RztBQUFBLGdCQUN4Ryx1QkFBQyxTQUFJO0FBQUE7QUFBQSxrQkFBaUIsdUJBQUMsVUFBSyxXQUFVLHNCQUFzQlIsNEJBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFEO0FBQUEscUJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtGO0FBQUEsbUJBRnBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNDekwsU0FBU2tNLGlCQUFpQix1QkFBQyxTQUFJLFdBQVUsc0NBQXFDO0FBQUE7QUFBQSxnQkFBUWxNLFFBQVFrTTtBQUFBQSxtQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUYsSUFBUztBQUFBLGNBQ3RIbE0sU0FBU21NLFNBQVMsdUJBQUMsU0FBSSxXQUFVLHNDQUFxQztBQUFBO0FBQUEsZ0JBQVNuTSxRQUFRbU07QUFBQUEsbUJBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRFLElBQVM7QUFBQSxjQUN4Ryx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVE7QUFBQSxrQkFDUixVQUFVLENBQUNuTSxTQUFTOEw7QUFBQUEsa0JBQ3BCLFNBQVMsTUFBTTtBQUNieEosc0NBQW1CdEMsU0FBUzhMLGlCQUFpQixJQUFrQztBQUMvRXRKLDBDQUF1QnhDLFNBQVMwRSxPQUFPLElBQTBDO0FBQ2pGaEMsNENBQXdCMUMsU0FBU0UseUJBQXlCc0wsVUFBVXBOLEVBQUU7QUFBQSxrQkFDeEU7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsaUJBbENRb04sVUFBVXBOLElBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUNBO0FBQUEsVUFFSixDQUFDLEtBbERIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbURBLEtBcERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcURBO0FBQUEsVUFFQSx1QkFBQyxXQUFRLE9BQU0sbUJBQ1ptRixtQkFBU2dELFVBQVU2RixtQkFBbUIzSCxTQUNyQyx1QkFBQyxTQUFJLFdBQVUsYUFDWmxCLG1CQUFTZ0QsVUFBVTZGLGtCQUFrQnhOO0FBQUFBLFlBQUksQ0FBQ3lOLFFBQ3pDLHVCQUFDLFNBQXdDLFdBQVUsMEdBQ2pEO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFNBQUksV0FBVSxtQkFBbUJBLGNBQUloTyxTQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0QztBQUFBLGdCQUM1Qyx1QkFBQyxTQUFJLFdBQVUsaUNBQWlDZ087QUFBQUEsc0JBQUlDO0FBQUFBLGtCQUFLO0FBQUEsa0JBQUlELElBQUlFO0FBQUFBLHFCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwRTtBQUFBLG1CQUY1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxnQkFBYSxXQUFVLHVDQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRDtBQUFBLGlCQUxuRCxHQUFHRixJQUFJQyxJQUFJLElBQUlELElBQUlFLFFBQVEsSUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLFVBQ0QsS0FUSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBLElBRUEsdUJBQUMsT0FBRSxXQUFVLGlDQUFnQyx1REFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0YsS0FkeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUVBLHVCQUFDLFdBQVEsT0FBTSx5QkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLFlBQVk7QUFDbkIsc0JBQUk7QUFDRjNKLHFDQUFpQixJQUFJO0FBQ3JCaEIscUNBQWlCMkIsU0FBU2dELFVBQVU3QixHQUFHO0FBQ3ZDLDBCQUFNeUgsU0FBUyxNQUFNdkksa0JBQWtCO0FBQUEsc0JBQ3JDSCxhQUFhRixTQUFTZ0QsVUFBVTdCO0FBQUFBLHNCQUNoQzhCLFlBQVlqRCxTQUFTZ0QsVUFBVUM7QUFBQUEsc0JBQy9Cd0MsV0FBVztBQUFBLHNCQUNYQyxTQUFTO0FBQUEsc0JBQ1RDLGdCQUFnQixlQUFlM0YsU0FBU2dELFVBQVU3QixHQUFHLElBQUluQixTQUFTZ0QsVUFBVTRDLFNBQVM7QUFBQSxzQkFDckZxRCxTQUFTO0FBQUEsb0JBQ1gsQ0FBQztBQUNELHdCQUFJTCxPQUFPOUMsV0FBVyxxQkFBcUI7QUFDekMsNEJBQU0sSUFBSWxCLE1BQU0sa0VBQWtFO0FBQUEsb0JBQ3BGO0FBQUEsa0JBQ0YsU0FBU0QsS0FBSztBQUNadEYscUNBQWlCc0YsZUFBZUMsUUFBUUQsSUFBSUUsVUFBVSxpQkFBaUI7QUFBQSxrQkFDekUsVUFBQztBQUNDeEcscUNBQWlCLElBQUk7QUFBQSxrQkFDdkI7QUFBQSxnQkFDRjtBQUFBLGdCQUNBLFVBQVUsQ0FBQzBFLHVCQUF1QjNFLGtCQUFrQjRCLFNBQVNnRCxVQUFVN0I7QUFBQUEsZ0JBRXRFL0MsNEJBQWtCNEIsU0FBU2dELFVBQVU3QixNQUFNLGlCQUFpQjtBQUFBO0FBQUEsY0F6Qi9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQTBCQSxLQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRCQTtBQUFBLFlBQ0MvQixnQkFDQyx1QkFBQyxTQUFJLFdBQVUsd0ZBQ1pBLDJCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsSUFDRTtBQUFBLFlBQ0hZLFNBQVNrRCxjQUFjaEMsV0FBVyxJQUNqQyx1QkFBQyxPQUFFLFdBQVUsaUNBQWdDLDZDQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRSxJQUUxRSx1QkFBQyxTQUFJLFdBQVUsYUFDWmxCLG1CQUFTa0QsY0FBYzdIO0FBQUFBLGNBQUksQ0FBQzhILFFBQzNCLHVCQUFDLFNBQWtCLFdBQVUscUVBQzNCO0FBQUEsdUNBQUMsU0FBSSxXQUFVLHFEQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsMkNBQUMsY0FBVyxXQUFVLGtDQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFvRDtBQUFBLG9CQUNwRCx1QkFBQyxVQUFLLFdBQVUsdUNBQXVDQSxjQUFJRixjQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFzRTtBQUFBLG9CQUN0RSx1QkFBQyxTQUFNLFNBQVEsV0FBV0UsY0FBSXBILFVBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXFDO0FBQUEsdUJBSHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsaUNBQWlDb0gsY0FBSXFGLFNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTBEO0FBQUEsb0JBQzFEO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxTQUFRO0FBQUEsd0JBQ1IsU0FBUyxNQUFNO0FBQ2J6Siw0Q0FBa0JvRSxJQUFJaEMsR0FBRztBQUN6QmxDLGdEQUFzQixJQUFJO0FBQzFCRSxrREFBd0IsSUFBSTtBQUFBLHdCQUM5QjtBQUFBLHdCQUFFO0FBQUE7QUFBQSxzQkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBVUE7QUFBQSx1QkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWFBO0FBQUEscUJBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBb0JBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGdFQUNiO0FBQUEseUNBQUMsU0FBSTtBQUFBO0FBQUEsb0JBQVMsdUJBQUMsVUFBSyxXQUFVLHNCQUFzQmdFLGNBQUk4RixXQUFXLE9BQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlEO0FBQUEsdUJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThFO0FBQUEsa0JBQzlFLHVCQUFDLFNBQUk7QUFBQTtBQUFBLG9CQUFPLHVCQUFDLFVBQUssV0FBVSxzQkFBc0I5RixjQUFJK0YsU0FBUyxPQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1RDtBQUFBLHVCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwRTtBQUFBLGtCQUMxRSx1QkFBQyxTQUFJO0FBQUE7QUFBQSxvQkFBVSx1QkFBQyxVQUFLLFdBQVUsZ0NBQWdDL0YsY0FBSWdHLFlBQVksT0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0U7QUFBQSx1QkFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEY7QUFBQSxrQkFDMUYsdUJBQUMsU0FBSTtBQUFBO0FBQUEsb0JBQWMsdUJBQUMsVUFBSyxXQUFVLHNCQUFzQmhHLGNBQUlpRyxvQkFBb0IsT0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0U7QUFBQSx1QkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEY7QUFBQSxrQkFDNUYsdUJBQUMsU0FBSTtBQUFBO0FBQUEsb0JBQVMsdUJBQUMsVUFBSyxXQUFVLHNCQUFzQmpHLGNBQUlrRyxjQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFxRDtBQUFBLHVCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwRTtBQUFBLGtCQUMxRSx1QkFBQyxTQUFJO0FBQUE7QUFBQSxvQkFBcUIsdUJBQUMsVUFBSyxXQUFVLHNCQUFzQmxHLGNBQUltRyxzQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkQ7QUFBQSx1QkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEY7QUFBQSxxQkFOaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBLGdCQUNDbkcsSUFBSW9HLGdCQUNILHVCQUFDLFNBQUksV0FBVSx3RkFDWnBHLGNBQUlvRyxpQkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLElBQ0U7QUFBQSxtQkFsQ0lwRyxJQUFJaEMsS0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1DQTtBQUFBLFlBQ0QsS0F0Q0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1Q0E7QUFBQSxlQTdFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQStFQTtBQUFBLFVBRUEsdUJBQUMsV0FBUSxPQUFNLG9CQUNabkIsbUJBQVN3SixRQUFRdEksU0FDaEIsdUJBQUMsU0FBSSxXQUFVLGFBQ1psQixtQkFBU3dKLE9BQU9DLE1BQU0sR0FBRyxDQUFDLEVBQUVwTztBQUFBQSxZQUFJLENBQUNxTyxVQUNoQyx1QkFBQyxTQUFvQixXQUFVLGtFQUM3QjtBQUFBLHFDQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxtQkFBbUJBLGdCQUFNQyxXQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnRDtBQUFBLGdCQUNoRCx1QkFBQyxTQUFNLFNBQVEsV0FBV0QsZ0JBQU1FLGFBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBDO0FBQUEsbUJBRjVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxzQ0FDWkY7QUFBQUEsc0JBQU1HLFlBQVksR0FBRzlPLFlBQVkyTyxNQUFNRyxTQUFTLENBQUMsUUFBUTtBQUFBLGdCQUFJSCxNQUFNSSxVQUFVL08sWUFBWTJPLE1BQU1JLE9BQU8sSUFBSTtBQUFBLG1CQUQ3RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBUFFKLE1BQU12SSxLQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsVUFDRCxLQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUEsSUFFQSx1QkFBQyxPQUFFLFdBQVUsaUNBQWdDLGlEQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RSxLQWhCbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxhQS9jRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ2RBLEtBcGRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzZEE7QUFBQSxXQW5oQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9oQkE7QUFBQSxTQXpqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBqQkE7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNN0Q7QUFBQUEsUUFDTjtBQUFBLFFBQ0E7QUFBQSxRQUNBLFNBQVMsTUFBTTtBQUNiQyx3QkFBYyxLQUFLO0FBQ25CWSw4QkFBb0IsSUFBSTtBQUN4QjBCLG1CQUFTLElBQUk7QUFBQSxRQUNmO0FBQUEsUUFDQSxVQUFVLE9BQU9rSyxZQUFZO0FBQzNCdEssc0JBQVksSUFBSTtBQUNoQkksbUJBQVMsSUFBSTtBQUNiLGNBQUk7QUFDRixrQkFBTStJLFNBQVMsTUFBTXpJLGdCQUFnQjtBQUFBLGNBQ25DckQsV0FBV0EsYUFBYWtOO0FBQUFBLGNBQ3hCdE8sT0FBT3FPLFFBQVFyTztBQUFBQSxjQUNmNEksZ0JBQWdCeUYsUUFBUXpGO0FBQUFBLGNBQ3hCUSxTQUFTaUYsUUFBUWpGLFdBQVdrRjtBQUFBQSxjQUM1Qi9HLFlBQVk4RyxRQUFROUcsY0FBYytHO0FBQUFBLGNBQ2xDdEksWUFBWXFJLFFBQVFySSxjQUFjc0k7QUFBQUEsY0FDbEM3RSxnQkFBZ0I0RSxRQUFRNUUsa0JBQWtCNkU7QUFBQUEsY0FDMUNDLFVBQVVDLE9BQU9ILFFBQVFFLFFBQVE7QUFBQSxjQUNqQzdGLFdBQVcyRixRQUFRM0Y7QUFBQUEsY0FDbkJ0QyxhQUFhaUksUUFBUWpJLGVBQWVrSTtBQUFBQSxjQUNwQ3BJLGVBQWVtSSxRQUFRbkksaUJBQWlCb0k7QUFBQUEsY0FDeENoQyxvQkFBb0I5TSxpQkFBaUI2TyxRQUFRL0Isa0JBQWtCO0FBQUEsY0FDL0RhLG1CQUFtQmtCLFFBQVFySSxhQUN2QixDQUFDLEVBQUVxSCxNQUFNLFFBQVFqTyxPQUFPaVAsUUFBUXJJLFlBQVlzSCxVQUFVLGNBQWNlLFFBQVFySSxVQUFVLEdBQUcsQ0FBQyxJQUMxRnNJO0FBQUFBLGNBQ0pyRSxnQkFBZ0J6SCxvQkFBb0I4TDtBQUFBQSxZQUN0QyxDQUFDO0FBQ0Q3TSwwQkFBY3lMLE9BQU81RixXQUFXN0IsT0FBTyxJQUFJO0FBQzNDOUQsZ0NBQW9CLElBQUk7QUFDeEJFLDBCQUFjLEtBQUs7QUFBQSxVQUNyQixTQUFTb0gsS0FBSztBQUNaOUUscUJBQVM4RSxlQUFlQyxRQUFRRCxJQUFJRSxVQUFVLDZCQUE2QjtBQUFBLFVBQzdFLFVBQUM7QUFDQ3BGLHdCQUFZLEtBQUs7QUFBQSxVQUNuQjtBQUFBLFFBQ0Y7QUFBQTtBQUFBLE1BdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXVDSTtBQUFBLElBR0o7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU1qQztBQUFBQSxRQUNOLFdBQVd3QyxVQUFVZ0QsYUFBYTtBQUFBLFFBQ2xDO0FBQUEsUUFDQSxTQUFTLE1BQU12RixnQkFBZ0IsS0FBSztBQUFBLFFBQ3BDLFVBQVUsT0FBT3NNLFlBQVk7QUFDM0IsY0FBSSxDQUFDL0osU0FBVTtBQUNmUCxzQkFBWSxJQUFJO0FBQ2hCRiw2QkFBbUIsSUFBSTtBQUN2QixjQUFJO0FBQ0Ysa0JBQU1nQix3QkFBd0I7QUFBQSxjQUM1QkwsYUFBYUYsU0FBU2dELFVBQVU3QjtBQUFBQSxjQUNoQ29ILGVBQWV3QixRQUFReEIsZ0JBQWdCd0IsUUFBUXhCLGdCQUFzQ3lCO0FBQUFBLGNBQ3JGL0QsY0FBYzhELFFBQVE5RDtBQUFBQSxjQUN0QkMsaUJBQWlCNkQsUUFBUTdEO0FBQUFBLGNBQ3pCcEUsYUFBYWlJLFFBQVFqSSxlQUFla0k7QUFBQUEsY0FDcEM1RixXQUFXcEUsU0FBU2dELFVBQVVvQjtBQUFBQSxjQUM5QnVCLGdCQUFnQixlQUFlM0YsU0FBU2dELFVBQVU3QixHQUFHLElBQUk0SSxRQUFROUQsWUFBWSxJQUFJOEQsUUFBUTdELGVBQWU7QUFBQSxZQUMxRyxDQUFDO0FBQ0R6SSw0QkFBZ0IsS0FBSztBQUFBLFVBQ3ZCLFNBQVNrSCxLQUFLO0FBQ1pwRiwrQkFBbUJvRixlQUFlQyxRQUFRRCxJQUFJRSxVQUFVLDRCQUE0QjtBQUFBLFVBQ3RGLFVBQUM7QUFDQ3BGLHdCQUFZLEtBQUs7QUFBQSxVQUNuQjtBQUFBLFFBQ0Y7QUFBQTtBQUFBLE1BekJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXlCSTtBQUFBLElBR0o7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU0vQjtBQUFBQSxRQUNOLFdBQVdzQyxVQUFVZ0QsYUFBYTtBQUFBLFFBQ2xDLGVBQWVoRCxVQUFVa0QsaUJBQWlCO0FBQUEsUUFDMUMsbUJBQW1CbEQsVUFBVStGLHFCQUFxQjtBQUFBLFFBQ2xEO0FBQUEsUUFDQSxTQUFTLE1BQU1wSSxlQUFlLEtBQUs7QUFBQSxRQUNuQyxVQUFVLE9BQU9vTSxZQUFZO0FBQzNCLGNBQUksQ0FBQy9KLFNBQVU7QUFDZlAsc0JBQVksSUFBSTtBQUNoQkYsNkJBQW1CLElBQUk7QUFDdkIsY0FBSTtBQUNGLGtCQUFNaUIsMEJBQTBCO0FBQUEsY0FDOUJOLGFBQWFGLFNBQVNnRCxVQUFVN0I7QUFBQUEsY0FDaENvSCxlQUFld0IsUUFBUXhCO0FBQUFBLGNBQ3ZCNUwsdUJBQXVCb04sUUFBUXBOO0FBQUFBLGNBQy9CYixvQkFBb0JpTyxRQUFRak87QUFBQUEsY0FDNUI2TSxnQkFBZ0JvQixRQUFRcEIsa0JBQWtCcUI7QUFBQUEsY0FDMUNwQixRQUFRbUIsUUFBUW5CLFVBQVVvQjtBQUFBQSxjQUMxQjVCLGtCQUFrQjJCLFFBQVEzQixvQkFBb0I0QjtBQUFBQSxjQUM5QzNCLG1CQUFtQjBCLFFBQVExQixxQkFBcUIyQjtBQUFBQSxjQUNoRHZCLFVBQVVzQixRQUFRdEIsWUFBWXVCO0FBQUFBLGNBQzlCak8sUUFBUWdPLFFBQVFoTztBQUFBQSxjQUNoQjJNLG1CQUFtQnFCLFFBQVFyQixxQkFBcUJzQjtBQUFBQSxjQUNoRDdCLDBCQUEwQjRCLFFBQVE1QiwyQkFBMkI0QixRQUFRNUIsMkJBQXNENkI7QUFBQUEsY0FDM0hyRSxnQkFBZ0IsY0FBYzNGLFNBQVNnRCxVQUFVN0IsR0FBRyxJQUFJNEksUUFBUXBOLHFCQUFxQixJQUFJb04sUUFBUXhCLGFBQWEsSUFBSXdCLFFBQVFoTyxNQUFNO0FBQUEsWUFDbEksQ0FBQztBQUNENEIsMkJBQWUsS0FBSztBQUFBLFVBQ3RCLFNBQVNnSCxLQUFLO0FBQ1pwRiwrQkFBbUJvRixlQUFlQyxRQUFRRCxJQUFJRSxVQUFVLHVDQUF1QztBQUFBLFVBQ2pHLFVBQUM7QUFDQ3BGLHdCQUFZLEtBQUs7QUFBQSxVQUNuQjtBQUFBLFFBQ0Y7QUFBQTtBQUFBLE1BakNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWlDSTtBQUFBLElBR0o7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU03QjtBQUFBQSxRQUNOLFdBQVdvQyxVQUFVZ0QsYUFBYTtBQUFBLFFBQ2xDO0FBQUEsUUFDQSxTQUFTLE1BQU1uRixnQkFBZ0IsS0FBSztBQUFBLFFBQ3BDLFVBQVUsT0FBT2tNLFlBQVk7QUFDM0IsY0FBSSxDQUFDL0osU0FBVTtBQUNmUCxzQkFBWSxJQUFJO0FBQ2hCRiw2QkFBbUIsSUFBSTtBQUN2QixjQUFJO0FBQ0Ysa0JBQU1vQix5QkFBeUI7QUFBQSxjQUM3QlQsYUFBYUYsU0FBU2dELFVBQVU3QjtBQUFBQSxjQUNoQ3dFLGdCQUFnQixlQUFlM0YsU0FBU2dELFVBQVU3QixHQUFHLElBQUk2QyxLQUFLQyxJQUFJLENBQUM7QUFBQSxjQUNuRWdELGVBQWU4QyxRQUFROUM7QUFBQUEsY0FDdkJuQixRQUFRaUUsUUFBUWpFO0FBQUFBLGNBQ2hCaEUsYUFBYWlJLFFBQVFqSSxlQUFla0k7QUFBQUEsY0FDcENHLE9BQU87QUFBQSxnQkFDTDdGLGdCQUFnQnlGLFFBQVF6RixrQkFBa0IwRjtBQUFBQSxnQkFDMUMvRyxZQUFZOEcsUUFBUTlHLGNBQWMrRztBQUFBQSxnQkFDbEN0SSxZQUFZcUksUUFBUXJJLGNBQWNzSTtBQUFBQSxnQkFDbEM1RixXQUFXMkYsUUFBUTNGO0FBQUFBLGdCQUNuQmdHLG1CQUFtQkwsUUFBUUs7QUFBQUEsZ0JBQzNCcEMsb0JBQW9COU0saUJBQWlCNk8sUUFBUS9CLG9CQUFvQmhJLFNBQVNnRCxVQUFVZ0Ysa0JBQXlCO0FBQUEsY0FDL0c7QUFBQSxZQUNGLENBQUM7QUFDRG5LLDRCQUFnQixLQUFLO0FBQUEsVUFDdkIsU0FBUzhHLEtBQUs7QUFDWnBGLCtCQUFtQm9GLGVBQWVDLFFBQVFELElBQUlFLFVBQVUsNEJBQTRCO0FBQUEsVUFDdEYsVUFBQztBQUNDcEYsd0JBQVksS0FBSztBQUFBLFVBQ25CO0FBQUEsUUFDRjtBQUFBO0FBQUEsTUEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBK0JJO0FBQUEsSUFHSjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTTNCO0FBQUFBLFFBQ04sV0FBV2tDLFVBQVVnRCxhQUFhO0FBQUEsUUFDbEM7QUFBQSxRQUNBLFNBQVMsTUFBTWpGLGNBQWMsS0FBSztBQUFBLFFBQ2xDLFVBQVUsT0FBT2dNLFlBQVk7QUFDM0IsY0FBSSxDQUFDL0osU0FBVTtBQUNmUCxzQkFBWSxJQUFJO0FBQ2hCRiw2QkFBbUIsSUFBSTtBQUN2QixjQUFJO0FBQ0Ysa0JBQU1zQixnQkFBZ0I7QUFBQSxjQUNwQlgsYUFBYUYsU0FBU2dELFVBQVU3QjtBQUFBQSxjQUNoQ3dFLGdCQUFnQixhQUFhM0YsU0FBU2dELFVBQVU3QixHQUFHLElBQUk2QyxLQUFLQyxJQUFJLENBQUM7QUFBQSxjQUNqRTZCLFFBQVFpRSxRQUFRakU7QUFBQUEsY0FDaEI2QixxQkFBcUJvQyxRQUFRcEMsdUJBQXVCcUM7QUFBQUEsY0FDcERsSSxhQUFhaUksUUFBUWpJLGVBQWVrSTtBQUFBQSxjQUNwQzdDLFlBQVk0QyxRQUFRNUMsY0FBYzZDO0FBQUFBLGNBQ2xDSyxhQUFhTixRQUFRTTtBQUFBQSxjQUNyQkMsNEJBQTRCUCxRQUFRTztBQUFBQSxjQUNwQ0Msb0JBQW9CUixRQUFRUTtBQUFBQSxZQUM5QixDQUFDO0FBQ0R4TSwwQkFBYyxLQUFLO0FBQUEsVUFDckIsU0FBUzRHLEtBQUs7QUFDWnBGLCtCQUFtQm9GLGVBQWVDLFFBQVFELElBQUlFLFVBQVUsNEJBQTRCO0FBQUEsVUFDdEYsVUFBQztBQUNDcEYsd0JBQVksS0FBSztBQUFBLFVBQ25CO0FBQUEsUUFDRjtBQUFBO0FBQUEsTUEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBMkJJO0FBQUEsSUFHSjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTXpCO0FBQUFBLFFBQ04sWUFBWThCLGNBQWM7QUFBQSxRQUMxQixvQkFBb0JFLFVBQVVnRCxVQUFVN0IsT0FBTztBQUFBLFFBQy9DO0FBQUEsUUFDQSxTQUFTLE1BQU1sRCxpQkFBaUIsS0FBSztBQUFBLFFBQ3JDLFVBQVUsT0FBTzhMLFlBQVk7QUFDM0IsY0FBSSxDQUFDL0osU0FBVTtBQUNmUCxzQkFBWSxJQUFJO0FBQ2hCRiw2QkFBbUIsSUFBSTtBQUN2QixjQUFJO0FBQ0Ysa0JBQU11QixtQkFBbUI7QUFBQSxjQUN2QlosYUFBYUYsU0FBU2dELFVBQVU3QjtBQUFBQSxjQUNoQzJHLHdCQUF3QmlDLFFBQVFqQztBQUFBQSxjQUNoQ25DLGdCQUFnQixnQkFBZ0IzRixTQUFTZ0QsVUFBVTdCLEdBQUcsSUFBSTRJLFFBQVFqQyxzQkFBc0I7QUFBQSxjQUN4RmhDLFFBQVFpRSxRQUFRakU7QUFBQUEsY0FDaEJMLFdBQVc7QUFBQSxjQUNYQyxTQUFTcUUsUUFBUXJFLFdBQVdzRTtBQUFBQSxZQUM5QixDQUFDO0FBQ0QvTCw2QkFBaUIsS0FBSztBQUFBLFVBQ3hCLFNBQVMwRyxLQUFLO0FBQ1pwRiwrQkFBbUJvRixlQUFlQyxRQUFRRCxJQUFJRSxVQUFVLCtCQUErQjtBQUFBLFVBQ3pGLFVBQUM7QUFDQ3BGLHdCQUFZLEtBQUs7QUFBQSxVQUNuQjtBQUFBLFFBQ0Y7QUFBQTtBQUFBLE1BekJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXlCSTtBQUFBLElBR0o7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU0sQ0FBQyxDQUFDWDtBQUFBQSxRQUNSLGVBQWVBO0FBQUFBLFFBQ2YsdUJBQXVCRTtBQUFBQSxRQUN2Qix1QkFBdUJFO0FBQUFBLFFBQ3ZCLFVBQVUsQ0FBQyxDQUFDYyxZQUFZNUIsa0JBQWtCNEIsU0FBU2dELFVBQVU3QjtBQUFBQSxRQUM3RCxrQkFBa0JuQixXQUNkLE9BQU8sRUFBRXVJLGVBQWV6QyxRQUFRbUQsU0FBU0MsT0FBT0MsU0FBUyxNQUFNO0FBQzdEOUosMkJBQWlCLElBQUk7QUFDckJoQiwyQkFBaUIyQixTQUFTZ0QsVUFBVTdCLEdBQUc7QUFDdkMsY0FBSTtBQUNGLGtCQUFNeUgsU0FBUyxNQUFNdkksa0JBQWtCO0FBQUEsY0FDckNILGFBQWFGLFNBQVNnRCxVQUFVN0I7QUFBQUEsY0FDaEM4QixZQUFZakQsU0FBU2dELFVBQVVDO0FBQUFBLGNBQy9Cd0MsV0FBVztBQUFBLGNBQ1hDLFNBQVM7QUFBQSxjQUNUQyxnQkFBZ0IsWUFBWTRDLGFBQWEsSUFBSTFFLFdBQVdDLFFBQVFDLGFBQWEsS0FBS0MsS0FBS0MsSUFBSSxDQUFDO0FBQUEsY0FDNUZnRixTQUFTQSxXQUFXO0FBQUEsY0FDcEJDO0FBQUFBLGNBQ0FDO0FBQUFBLGNBQ0FxQixzQkFBc0JqQztBQUFBQSxjQUN0QmtDLGFBQWEzRTtBQUFBQSxZQUNmLENBQUM7QUFDRCxnQkFBSThDLE9BQU85QyxXQUFXLHFCQUFxQjtBQUN6QyxvQkFBTSxJQUFJbEIsTUFBTSwrREFBK0Q7QUFBQSxZQUNqRjtBQUFBLFVBQ0YsVUFBQztBQUNDdkcsNkJBQWlCLElBQUk7QUFBQSxVQUN2QjtBQUFBLFFBQ0YsSUFDQTJMO0FBQUFBLFFBQ0osU0FBUyxNQUFNO0FBQ2JqTCw0QkFBa0IsSUFBSTtBQUN0QkUsZ0NBQXNCLElBQUk7QUFDMUJFLGtDQUF3QixJQUFJO0FBQUEsUUFDOUI7QUFBQTtBQUFBLE1BbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQW1DSTtBQUFBLE9BNXpCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOHpCQTtBQUVKO0FBQUNwQyxHQXo3QmVGLGdCQUFjO0FBQUEsVUF5QlR0RixVQUNGQSxVQUlPRCxhQUNFQSxhQUNNQSxhQUNFQSxhQUNWQSxhQUNTQSxhQUNBQSxhQUNUQSxhQUNHQSxhQUNLQSxhQUNmQSxXQUFXO0FBQUE7QUFBQSxLQXhDZHVGO0FBMjdCaEIsU0FBUzZOLGFBQWE7QUFBQSxFQUNwQjVQO0FBQUFBLEVBQ0FFO0FBQUFBLEVBQ0EyUDtBQUFBQSxFQUNBQztBQU1GLEdBQUc7QUFDRCxTQUNFLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsMkJBQUMsU0FBTSxXQUFVLGlFQUFpRTlQLG1CQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdGO0FBQUEsSUFDeEYsdUJBQUMsVUFBTyxPQUFjLGVBQWU2UCxVQUNuQztBQUFBLDZCQUFDLGlCQUFjLGNBQVksR0FBRzdQLEtBQUssV0FDakMsaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFZLEtBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxpQkFDQztBQUFBLCtCQUFDLGNBQVcsT0FBTSxPQUFNLG1CQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCO0FBQUEsUUFDMUI4UCxRQUFRdlA7QUFBQUEsVUFBSSxDQUFDd1AsV0FDWix1QkFBQyxjQUF3QixPQUFPQSxRQUFTQSxvQkFBeEJBLFFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdEO0FBQUEsUUFDakQ7QUFBQSxXQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLFNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsT0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBYUE7QUFFSjtBQUFDQyxNQTNCUUo7QUE2QlQsU0FBU0ssUUFBUSxFQUFFclAsT0FBT3NQLFNBQXVELEdBQUc7QUFDbEYsU0FDRSx1QkFBQyxhQUNDO0FBQUEsMkJBQUMsU0FBSSxXQUFVLG9GQUFvRnRQLG1CQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlHO0FBQUEsSUFDeEdzUDtBQUFBQSxPQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQTtBQUVKO0FBQUNDLE1BUFFGO0FBU1QsU0FBU0csUUFBUSxFQUFFcFEsT0FBT0UsTUFBZ0QsR0FBRztBQUMzRSxTQUNFLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLDJCQUFDLFFBQUcsV0FBVSx5QkFBeUJGLG1CQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZDO0FBQUEsSUFDN0MsdUJBQUMsUUFBRyxXQUFVLGlDQUFpQ0UsbUJBQVMsT0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0RDtBQUFBLE9BRjlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQTtBQUVKO0FBQUNtUSxNQVBRRDtBQVNULFNBQVNFLFNBQVMsRUFBRXRRLE9BQU9FLE9BQU9xUSxPQUFPLFVBQXdGLEdBQUc7QUFDbEksU0FDRSx1QkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLDJCQUFDLFNBQUksV0FBVSxpRUFBaUV2USxtQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRjtBQUFBLElBQ3RGLHVCQUFDLFNBQUksV0FBVywrQkFBK0J1USxTQUFTLFNBQVMscUJBQXFCQSxTQUFTLFNBQVMsbUJBQW1CQSxTQUFTLFFBQVEsaUJBQWlCLGlCQUFpQixJQUMzS3JRLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtBO0FBRUo7QUFBQ3NRLE1BVFFGO0FBV1QsU0FBU0csc0JBQXNCO0FBQUEsRUFDN0JDO0FBQUFBLEVBQ0F4STtBQUFBQSxFQUNBeEQ7QUFBQUEsRUFDQWlNO0FBQUFBLEVBQ0FDO0FBT0YsR0FBRztBQUFBQyxNQUFBO0FBQ0QsUUFBTUMsY0FBYzVJLFdBQVdvSCxvQkFBb0IsQ0FBQyxNQUFNLENBQUMsUUFBUSxVQUFVLEVBQUVoSSxTQUFTWSxXQUFXb0IsU0FBUyxJQUFJLGdCQUFnQjtBQUNoSSxRQUFNLENBQUM2QixjQUFjNEYsZUFBZSxJQUFJeFUsU0FBU3VVLFdBQVc7QUFDNUQsUUFBTSxDQUFDMUYsaUJBQWlCNEYsa0JBQWtCLElBQUl6VSxTQUFTLGlEQUFpRDtBQUN4RyxRQUFNLENBQUN5SyxhQUFhaUssY0FBYyxJQUFJMVUsU0FBUyxVQUFVO0FBQ3pELFFBQU0sQ0FBQ2tSLGVBQWV5RCxnQkFBZ0IsSUFBSTNVLFNBQVMsRUFBRTtBQUVyREYsWUFBVSxNQUFNO0FBQ2QwVSxvQkFBZ0JELFdBQVc7QUFBQSxFQUM3QixHQUFHLENBQUNBLGFBQWFKLElBQUksQ0FBQztBQUV0QixTQUNFLHVCQUFDLFVBQU8sTUFBWSxjQUFjLENBQUNTLFNBQVMsQ0FBQ0EsUUFBUVIsUUFBUSxHQUMzRCxpQ0FBQyxpQkFBYyxXQUFVLG9CQUN2QjtBQUFBLDJCQUFDLGdCQUNDO0FBQUEsNkJBQUMsZUFBWSxnQ0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZCO0FBQUEsTUFDN0IsdUJBQUMscUJBQWtCLDhFQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlGO0FBQUEsU0FGbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUEsK0JBQUMsU0FBTSw2QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9CO0FBQUEsUUFBUSx1QkFBQyxTQUFNLE9BQU94RixjQUFjLFVBQVUsQ0FBQ3lELFVBQVVtQyxnQkFBZ0JuQyxNQUFNd0MsT0FBT2xSLEtBQUssS0FBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRjtBQUFBLFdBQTlJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUo7QUFBQSxNQUNqSix1QkFBQyxTQUFJLFdBQVUsZUFBYztBQUFBLCtCQUFDLFNBQU0sZ0NBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QjtBQUFBLFFBQVEsdUJBQUMsWUFBUyxPQUFPa0wsaUJBQWlCLFVBQVUsQ0FBQ3dELFVBQVVvQyxtQkFBbUJwQyxNQUFNd0MsT0FBT2xSLEtBQUssR0FBRyxNQUFNLEtBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUc7QUFBQSxXQUFuSztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNLO0FBQUEsTUFDdEssdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGVBQWM7QUFBQSxpQ0FBQyxTQUFNLDRCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1CO0FBQUEsVUFBUSx1QkFBQyxTQUFNLE9BQU84RyxhQUFhLFVBQVUsQ0FBQzRILFVBQVVxQyxlQUFlckMsTUFBTXdDLE9BQU9sUixLQUFLLEtBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1GO0FBQUEsYUFBM0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4STtBQUFBLFFBQzlJLHVCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUEsaUNBQUMsU0FBTSwyQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQztBQUFBLFVBQVEsdUJBQUMsU0FBTSxPQUFPdU4sZUFBZSxVQUFVLENBQUNtQixVQUFVc0MsaUJBQWlCdEMsTUFBTXdDLE9BQU9sUixLQUFLLEdBQUcsYUFBWSxZQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RztBQUFBLGFBQW5MO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0w7QUFBQSxXQUZ4TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBQ0EsdUJBQUMsZ0JBQ0M7QUFBQSw2QkFBQyxVQUFPLFNBQVEsU0FBUSxTQUFTeVEsU0FBUyxzQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRDtBQUFBLE1BQ2hELHVCQUFDLFVBQU8sU0FBUyxNQUFNQyxTQUFTLEVBQUV6RixjQUFjQyxpQkFBaUJwRSxhQUFheUcsY0FBYyxDQUFDLEdBQUcsVUFBVS9JLFlBQVksQ0FBQ3lHLGFBQWExSyxLQUFLLEtBQUssQ0FBQzJLLGdCQUFnQjNLLEtBQUssR0FBSWlFLHFCQUFXLGdCQUFnQixzQkFBbk07QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzTjtBQUFBLFNBRnhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLE9BaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1CQTtBQUVKO0FBQUNtTSxJQTdDUUosdUJBQXFCO0FBQUEsTUFBckJBO0FBK0NULFNBQVNZLGdDQUFnQztBQUFBLEVBQ3ZDWDtBQUFBQSxFQUNBeEk7QUFBQUEsRUFDQUU7QUFBQUEsRUFDQTZDO0FBQUFBLEVBQ0F2RztBQUFBQSxFQUNBaU07QUFBQUEsRUFDQUM7QUFxQkYsR0FBRztBQUFBVSxNQUFBO0FBQ0QsUUFBTSxDQUFDelAsdUJBQXVCMFAsd0JBQXdCLElBQUloVixTQUFTLEVBQUU7QUFDckUsUUFBTSxDQUFDa1IsZUFBZXlELGdCQUFnQixJQUFJM1UsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ3lFLG9CQUFvQndRLHFCQUFxQixJQUFJalYsU0FBUyxRQUFRO0FBQ3JFLFFBQU0sQ0FBQ3NSLGdCQUFnQjRELGlCQUFpQixJQUFJbFYsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ3VSLFFBQVE0RCxTQUFTLElBQUluVixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDK1Esa0JBQWtCcUUsbUJBQW1CLElBQUlwVixTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDZ1IsbUJBQW1CcUUsb0JBQW9CLElBQUlyVixTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDb1IsVUFBVWtFLFdBQVcsSUFBSXRWLFNBQVMsVUFBVTtBQUNuRCxRQUFNLENBQUMwRSxRQUFRNlEsU0FBUyxJQUFJdlYsU0FBUyxRQUFRO0FBQzdDLFFBQU0sQ0FBQ3FSLG1CQUFtQm1FLG9CQUFvQixJQUFJeFYsU0FBUyxFQUFFO0FBQzdELFFBQU0sQ0FBQzhRLDBCQUEwQjJFLDJCQUEyQixJQUFJelYsU0FBUyxFQUFFO0FBRTNFRixZQUFVLE1BQU07QUFDZGtWLDZCQUF5QnJKLFdBQVdnRixxQkFBcUIsQ0FBQyxHQUFHbk4sTUFBTSxFQUFFO0FBQ3JFbVIscUJBQWtCOUksZ0JBQWdCLENBQUMsR0FBRy9CLE9BQThCLEVBQUU7QUFBQSxFQUN4RSxHQUFHLENBQUM2QixXQUFXRSxlQUFlc0ksSUFBSSxDQUFDO0FBRW5DLFFBQU11QixnQkFBZ0JoSCxrQkFBa0J2SyxPQUFPLENBQUN3SyxhQUFhQSxTQUFTakssV0FBVyxjQUFjaUssU0FBU2pLLFdBQVcsYUFBYTtBQUVoSSxTQUNFLHVCQUFDLFVBQU8sTUFBWSxjQUFjLENBQUNrUSxTQUFTLENBQUNBLFFBQVFSLFFBQVEsR0FDM0QsaUNBQUMsaUJBQWMsV0FBVSxvQkFDdkI7QUFBQSwyQkFBQyxnQkFDQztBQUFBLDZCQUFDLGVBQVksMkNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QztBQUFBLE1BQ3hDLHVCQUFDLHFCQUFrQiw4R0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpSDtBQUFBLFNBRm5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLGlDQUFDLFNBQU0sb0NBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQSxVQUMzQix1QkFBQyxVQUFPLE9BQU85Tyx1QkFBdUIsZUFBZTBQLDBCQUNuRDtBQUFBLG1DQUFDLGlCQUFjLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVksS0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEI7QUFBQSxZQUM5Qix1QkFBQyxpQkFDR3JKLHNCQUFXZ0Ysc0JBQXNCLElBQUkzTSxJQUFJLENBQUM0TSxjQUFtQix1QkFBQyxjQUE4QixPQUFPQSxVQUFVcE4sSUFBS29OLG9CQUFVdk0sU0FBOUN1TSxVQUFVcE4sSUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUUsQ0FBYSxLQURuSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsaUNBQUMsU0FBTSw2QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQjtBQUFBLFVBQ3BCLHVCQUFDLFVBQU8sT0FBTzBOLGVBQWUsZUFBZXlELGtCQUMzQztBQUFBLG1DQUFDLGlCQUFjLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVksS0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEI7QUFBQSxZQUM5Qix1QkFBQyxpQkFDRTlJLHdCQUFjN0gsSUFBSSxDQUFDOEgsUUFBUSx1QkFBQyxjQUF5QixPQUFPQSxJQUFJaEMsS0FBTWdDO0FBQUFBLGtCQUFJcUY7QUFBQUEsY0FBTTtBQUFBLGNBQUlyRixJQUFJcEg7QUFBQUEsaUJBQTVDb0gsSUFBSWhDLEtBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FLENBQWEsS0FEL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLGFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLG1DQUFDLFNBQU0sc0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBYTtBQUFBLFlBQ2IsdUJBQUMsVUFBTyxPQUFPckYsb0JBQW9CLGVBQWV3USx1QkFDaEQ7QUFBQSxxQ0FBQyxpQkFBYyxpQ0FBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFZLEtBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThCO0FBQUEsY0FDOUIsdUJBQUMsaUJBQ0UsV0FBQyxVQUFVLFdBQVcsUUFBUSxXQUFXLEVBQUVqUixJQUFJLENBQUN3UCxXQUFXLHVCQUFDLGNBQXdCLE9BQU9BLFFBQVNBLG9CQUF4QkEsUUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0QsQ0FBYSxLQUQzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLGVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxtQ0FBQyxTQUFNLHNCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWE7QUFBQSxZQUNiLHVCQUFDLFVBQU8sT0FBTzlPLFFBQVEsZUFBZTZRLFdBQ3BDO0FBQUEscUNBQUMsaUJBQWMsaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBWSxLQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QjtBQUFBLGNBQzlCLHVCQUFDLGlCQUNFLFdBQUMsVUFBVSxVQUFVLFVBQVUsU0FBUyxFQUFFdlIsSUFBSSxDQUFDd1AsV0FBVyx1QkFBQyxjQUF3QixPQUFPQSxRQUFTQSxvQkFBeEJBLFFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdELENBQWEsS0FEMUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxhQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFBYztBQUFBLGlDQUFDLFNBQU0sd0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZTtBQUFBLFVBQVEsdUJBQUMsU0FBTSxPQUFPcEMsVUFBVSxVQUFVLENBQUNpQixVQUFVaUQsWUFBWWpELE1BQU13QyxPQUFPbFIsS0FBSyxLQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RTtBQUFBLGFBQWpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0k7QUFBQSxXQXZDdEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdDQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsZUFBYztBQUFBLGlDQUFDLFNBQU0sZ0NBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUI7QUFBQSxVQUFRLHVCQUFDLFNBQU0sT0FBTzJOLGdCQUFnQixVQUFVLENBQUNlLFVBQVU2QyxrQkFBa0I3QyxNQUFNd0MsT0FBT2xSLEtBQUssR0FBRyxhQUFZLDRDQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4STtBQUFBLGFBQTFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNk07QUFBQSxRQUM3TSx1QkFBQyxTQUFJLFdBQVUsZUFBYztBQUFBLGlDQUFDLFNBQU0sc0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYTtBQUFBLFVBQVEsdUJBQUMsWUFBUyxPQUFPNE4sUUFBUSxVQUFVLENBQUNjLFVBQVU4QyxVQUFVOUMsTUFBTXdDLE9BQU9sUixLQUFLLEdBQUcsTUFBTSxHQUFHLGFBQVksa0NBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdJO0FBQUEsYUFBbEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxTDtBQUFBLFFBQ3JMLHVCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUEsaUNBQUMsU0FBTSxpQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QjtBQUFBLFVBQVEsdUJBQUMsU0FBTSxPQUFPb04sa0JBQWtCLFVBQVUsQ0FBQ3NCLFVBQVUrQyxvQkFBb0IvQyxNQUFNd0MsT0FBT2xSLEtBQUssR0FBRyxhQUFZLG1EQUExRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5SjtBQUFBLGFBQXROO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeU47QUFBQSxRQUN6Tix1QkFBQyxTQUFJLFdBQVUsZUFBYztBQUFBLGlDQUFDLFNBQU0sa0NBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUI7QUFBQSxVQUFRLHVCQUFDLFNBQU0sT0FBT3FOLG1CQUFtQixVQUFVLENBQUNxQixVQUFVZ0QscUJBQXFCaEQsTUFBTXdDLE9BQU9sUixLQUFLLEdBQUcsYUFBWSxrQ0FBNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEk7QUFBQSxhQUF4TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJNO0FBQUEsUUFDM00sdUJBQUMsU0FBSSxXQUFVLGVBQWM7QUFBQSxpQ0FBQyxTQUFNLHVDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsVUFBUSx1QkFBQyxTQUFNLE9BQU8wTixtQkFBbUIsVUFBVSxDQUFDZ0IsVUFBVW1ELHFCQUFxQm5ELE1BQU13QyxPQUFPbFIsS0FBSyxHQUFHLGFBQVksZ0NBQTVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdJO0FBQUEsYUFBM007QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4TTtBQUFBLFFBQzdNZSxXQUFXLFdBQ1YsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxpQ0FBQyxTQUFNLCtCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNCO0FBQUEsVUFDdEIsdUJBQUMsVUFBTyxPQUFPb00sMEJBQTBCLGVBQWUyRSw2QkFDdEQ7QUFBQSxtQ0FBQyxpQkFBYyxpQ0FBQyxlQUFZLGFBQVksOEJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1ELEtBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFO0FBQUEsWUFDckUsdUJBQUMsaUJBQ0VDLHdCQUFjMVIsSUFBSSxDQUFDMkssYUFBYSx1QkFBQyxjQUE4QixPQUFPQSxTQUFTN0UsS0FBTTZFO0FBQUFBLHVCQUFTQztBQUFBQSxjQUFhO0FBQUEsY0FBSUQsU0FBU2pLO0FBQUFBLGlCQUF2RWlLLFNBQVM3RSxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRixDQUFhLEtBRC9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQSxJQUNFO0FBQUEsV0FoQk47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlCQTtBQUFBLFNBNURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2REE7QUFBQSxJQUNBLHVCQUFDLGdCQUNDO0FBQUEsNkJBQUMsVUFBTyxTQUFRLFNBQVEsU0FBU3NLLFNBQVMsc0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0Q7QUFBQSxNQUNoRCx1QkFBQyxVQUFPLFNBQVMsTUFBTUMsU0FBUyxFQUFFL08sdUJBQXVCNEwsZUFBZXpNLG9CQUFvQjZNLGdCQUFnQkMsUUFBUVIsa0JBQWtCQyxtQkFBbUJJLFVBQVUxTSxRQUFRMk0sbUJBQW1CUCx5QkFBeUIsQ0FBQyxHQUFHLFVBQVUzSSxZQUFZLENBQUM3Qyx5QkFBeUIsQ0FBQzRMLGVBQWdCL0kscUJBQVcsZUFBZSxvQkFBdFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1VTtBQUFBLFNBRnpVO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLE9BdEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1RUEsS0F4RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlFQTtBQUVKO0FBQUM0TSxJQTVIUUQsaUNBQStCO0FBQUEsTUFBL0JBO0FBOEhULFNBQVNhLHNCQUFzQjtBQUFBLEVBQzdCeEI7QUFBQUEsRUFDQXhJO0FBQUFBLEVBQ0F4RDtBQUFBQSxFQUNBaU07QUFBQUEsRUFDQUM7QUFpQkYsR0FBRztBQUFBdUIsTUFBQTtBQUNELFFBQU0sQ0FBQ2hHLGVBQWVpRyxnQkFBZ0IsSUFBSTdWLFNBQVMsbUNBQW1DO0FBQ3RGLFFBQU0sQ0FBQ3lPLFFBQVFxSCxTQUFTLElBQUk5VixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDeUssYUFBYWlLLGNBQWMsSUFBSTFVLFNBQVMsVUFBVTtBQUN6RCxRQUFNLENBQUNpTixnQkFBZ0I4SSxpQkFBaUIsSUFBSS9WLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUM0TCxZQUFZb0ssYUFBYSxJQUFJaFcsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3FLLFlBQVk0TCxhQUFhLElBQUlqVyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDK00sV0FBV21KLFlBQVksSUFBSWxXLFNBQVMsUUFBUTtBQUNuRCxRQUFNLENBQUNtVyx1QkFBdUJDLHdCQUF3QixJQUFJcFcsU0FBUyxFQUFFO0FBQ3JFLFFBQU0sQ0FBQzJRLG9CQUFvQjBGLHFCQUFxQixJQUFJclcsU0FBUyxFQUFFO0FBRS9ERixZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNxVSxRQUFRLENBQUN4SSxVQUFXO0FBQ3pCb0ssc0JBQWtCcEssVUFBVXNCLGtCQUFrQixFQUFFO0FBQ2hEK0ksa0JBQWNySyxVQUFVQyxjQUFjLEVBQUU7QUFDeENxSyxrQkFBY3RLLFVBQVV0QixjQUFjLEVBQUU7QUFDeEM2TCxpQkFBYXZLLFVBQVVvQixhQUFhLFFBQVE7QUFDNUNxSiw4QkFBMEJ6SyxVQUFVb0gscUJBQXFCLElBQUk3RCxLQUFLLElBQUksQ0FBQztBQUN2RW1ILDJCQUF1QjFLLFVBQVVnRixzQkFBc0IsSUFBSTNNLElBQUksQ0FBQzRNLGNBQW1CQSxVQUFVdk0sS0FBSyxFQUFFNkssS0FBSyxJQUFJLENBQUM7QUFBQSxFQUNoSCxHQUFHLENBQUNpRixNQUFNeEksU0FBUyxDQUFDO0FBRXBCLFNBQ0UsdUJBQUMsVUFBTyxNQUFZLGNBQWMsQ0FBQ2lKLFNBQVMsQ0FBQ0EsUUFBUVIsUUFBUSxHQUMzRCxpQ0FBQyxpQkFBYyxXQUFVLG9CQUN2QjtBQUFBLDJCQUFDLGdCQUNDO0FBQUEsNkJBQUMsZUFBWSwwQ0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVDO0FBQUEsTUFDdkMsdUJBQUMscUJBQWtCLG9IQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVIO0FBQUEsU0FGekg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUEsaUNBQUMsU0FBTSw4QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQjtBQUFBLFVBQVEsdUJBQUMsU0FBTSxPQUFPeEUsZUFBZSxVQUFVLENBQUN5QyxVQUFVd0QsaUJBQWlCeEQsTUFBTXdDLE9BQU9sUixLQUFLLEtBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVGO0FBQUEsYUFBako7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvSjtBQUFBLFFBQ3BKLHVCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUEsaUNBQUMsU0FBTSxzQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFhO0FBQUEsVUFBUSx1QkFBQyxZQUFTLE9BQU84SyxRQUFRLFVBQVUsQ0FBQzRELFVBQVV5RCxVQUFVekQsTUFBTXdDLE9BQU9sUixLQUFLLEdBQUcsTUFBTSxHQUFHLGFBQVksNENBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBJO0FBQUEsYUFBNUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErTDtBQUFBLFFBQy9MLHVCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUEsaUNBQUMsU0FBTSw0QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtQjtBQUFBLFVBQVEsdUJBQUMsU0FBTSxPQUFPOEcsYUFBYSxVQUFVLENBQUM0SCxVQUFVcUMsZUFBZXJDLE1BQU13QyxPQUFPbFIsS0FBSyxLQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLGFBQTNJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEk7QUFBQSxRQUM5SSx1QkFBQyxTQUFJLFdBQVUsZUFBYztBQUFBLGlDQUFDLFNBQU0sK0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0I7QUFBQSxVQUFRLHVCQUFDLFlBQVMsT0FBT3NKLGdCQUFnQixVQUFVLENBQUNvRixVQUFVMEQsa0JBQWtCMUQsTUFBTXdDLE9BQU9sUixLQUFLLEdBQUcsTUFBTSxLQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRztBQUFBLGFBQWhLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUs7QUFBQSxXQUpySztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGVBQWM7QUFBQSxtQ0FBQyxTQUFNLHdCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWU7QUFBQSxZQUFRLHVCQUFDLFNBQU0sT0FBT2lJLFlBQVksVUFBVSxDQUFDeUcsVUFBVTJELGNBQWMzRCxNQUFNd0MsT0FBT2xSLEtBQUssS0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUY7QUFBQSxlQUFySTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3STtBQUFBLFVBQ3hJLHVCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUEsbUNBQUMsU0FBTSwwQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQjtBQUFBLFlBQVEsdUJBQUMsU0FBTSxPQUFPMEcsWUFBWSxVQUFVLENBQUNnSSxVQUFVNEQsY0FBYzVELE1BQU13QyxPQUFPbFIsS0FBSyxLQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRjtBQUFBLGVBQXZJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBJO0FBQUEsYUFGNUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLGlDQUFDLFNBQU0sMEJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUI7QUFBQSxVQUNqQix1QkFBQyxVQUFPLE9BQU9vSixXQUFXLGVBQWVtSixjQUN2QztBQUFBLG1DQUFDLGlCQUFjLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVksS0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEI7QUFBQSxZQUM5Qix1QkFBQyxpQkFBZSxXQUFDLE9BQU8sVUFBVSxRQUFRLFVBQVUsRUFBRWxTLElBQUksQ0FBQ3dQLFdBQVcsdUJBQUMsY0FBd0IsT0FBT0EsUUFBU0Esb0JBQXhCQSxRQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRCxDQUFhLEtBQW5JO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFJO0FBQUEsZUFGdkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFBYztBQUFBLGlDQUFDLFNBQU0sa0NBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUI7QUFBQSxVQUFRLHVCQUFDLFlBQVMsT0FBTzJDLHVCQUF1QixVQUFVLENBQUM5RCxVQUFVK0QseUJBQXlCL0QsTUFBTXdDLE9BQU9sUixLQUFLLEdBQUcsTUFBTSxHQUFHLGFBQVksa0JBQWhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThJO0FBQUEsYUFBNU07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErTTtBQUFBLFFBQy9NLHVCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUEsaUNBQUMsU0FBTSxtQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQjtBQUFBLFVBQVEsdUJBQUMsWUFBUyxPQUFPZ04sb0JBQW9CLFVBQVUsQ0FBQzBCLFVBQVVnRSxzQkFBc0JoRSxNQUFNd0MsT0FBT2xSLEtBQUssR0FBRyxNQUFNLEdBQUcsYUFBWSw0QkFBMUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0o7QUFBQSxhQUFqTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9OO0FBQUEsV0FidE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsU0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNCQTtBQUFBLElBQ0EsdUJBQUMsZ0JBQ0M7QUFBQSw2QkFBQyxVQUFPLFNBQVEsU0FBUSxTQUFTeVEsU0FBUyxzQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRDtBQUFBLE1BQ2hELHVCQUFDLFVBQU8sU0FBUyxNQUFNQyxTQUFTO0FBQUEsUUFDOUJ6RTtBQUFBQSxRQUNBbkI7QUFBQUEsUUFDQWhFO0FBQUFBLFFBQ0F3QztBQUFBQSxRQUNBckI7QUFBQUEsUUFDQXZCO0FBQUFBLFFBQ0EwQztBQUFBQSxRQUNBZ0csbUJBQW1Cb0Qsc0JBQXNCcFMsTUFBTSxJQUFJLEVBQUVDLElBQUksQ0FBQ0MsU0FBU0EsS0FBS0MsS0FBSyxDQUFDLEVBQUVDLE9BQU9DLE9BQU87QUFBQSxRQUM5RnVNO0FBQUFBLE1BQ0YsQ0FBQyxHQUFHLFVBQVV4SSxZQUFZLENBQUN5SCxjQUFjMUwsS0FBSyxLQUFLLENBQUN1SyxPQUFPdkssS0FBSyxHQUFJaUUscUJBQVcsWUFBWSxzQkFWM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVU4RztBQUFBLFNBWmhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLE9BekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwQ0EsS0EzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRDQTtBQUVKO0FBQUN5TixJQTFGUUQsdUJBQXFCO0FBQUEsTUFBckJBO0FBNEZULFNBQVNXLHNCQUFzQjtBQUFBLEVBQzdCbkM7QUFBQUEsRUFDQXhJO0FBQUFBLEVBQ0F4RDtBQUFBQSxFQUNBaU07QUFBQUEsRUFDQUM7QUFlRixHQUFHO0FBQUFrQyxNQUFBO0FBQ0QsUUFBTSxDQUFDOUgsUUFBUXFILFNBQVMsSUFBSTlWLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNzUSxxQkFBcUJrRyxzQkFBc0IsSUFBSXhXLFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUN5SyxhQUFhaUssY0FBYyxJQUFJMVUsU0FBUyxVQUFVO0FBQ3pELFFBQU0sQ0FBQzhQLFlBQVkyRyxhQUFhLElBQUl6VyxTQUFTLFVBQVU7QUFDdkQsUUFBTSxDQUFDZ1QsYUFBYTBELGNBQWMsSUFBSTFXLFNBQVMsZ0JBQWdCO0FBQy9ELFFBQU0sQ0FBQzJXLGdDQUFnQ0MsaUNBQWlDLElBQUk1VyxTQUFTLEVBQUU7QUFDdkYsUUFBTSxDQUFDNlcsd0JBQXdCQyx5QkFBeUIsSUFBSTlXLFNBQVMsc0ZBQXNGO0FBRTNKRixZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNxVSxRQUFRLENBQUN4SSxVQUFXO0FBQ3pCaUwsdUNBQW1DakwsVUFBVWdGLHNCQUFzQixJQUFJM00sSUFBSSxDQUFDNE0sY0FBbUJBLFVBQVVwTixFQUFFLEVBQUUwTCxLQUFLLElBQUksQ0FBQztBQUFBLEVBQ3pILEdBQUcsQ0FBQ2lGLE1BQU14SSxTQUFTLENBQUM7QUFFcEIsU0FDRSx1QkFBQyxVQUFPLE1BQVksY0FBYyxDQUFDaUosU0FBUyxDQUFDQSxRQUFRUixRQUFRLEdBQzNELGlDQUFDLGlCQUFjLFdBQVUsb0JBQ3ZCO0FBQUEsMkJBQUMsZ0JBQ0M7QUFBQSw2QkFBQyxlQUFZLGdDQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkI7QUFBQSxNQUM3Qix1QkFBQyxxQkFBa0IsMEdBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkc7QUFBQSxTQUYvRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGVBQWM7QUFBQSwrQkFBQyxTQUFNLHNCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYTtBQUFBLFFBQVEsdUJBQUMsWUFBUyxPQUFPM0YsUUFBUSxVQUFVLENBQUM0RCxVQUFVeUQsVUFBVXpELE1BQU13QyxPQUFPbFIsS0FBSyxHQUFHLE1BQU0sR0FBRyxhQUFZLDZFQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJLO0FBQUEsV0FBN047QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnTztBQUFBLE1BQ2hPLHVCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUEsK0JBQUMsU0FBTSxzQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZCO0FBQUEsUUFBUSx1QkFBQyxTQUFNLE9BQU8yTSxxQkFBcUIsVUFBVSxDQUFDK0IsVUFBVW1FLHVCQUF1Qm5FLE1BQU13QyxPQUFPbFIsS0FBSyxHQUFHLGFBQVkseUNBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUo7QUFBQSxXQUF2TjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBOO0FBQUEsTUFDMU4sdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGVBQWM7QUFBQSxpQ0FBQyxTQUFNLDRCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1CO0FBQUEsVUFBUSx1QkFBQyxTQUFNLE9BQU84RyxhQUFhLFVBQVUsQ0FBQzRILFVBQVVxQyxlQUFlckMsTUFBTXdDLE9BQU9sUixLQUFLLEtBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1GO0FBQUEsYUFBM0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4STtBQUFBLFFBQzlJLHVCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUEsaUNBQUMsU0FBTSwyQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQjtBQUFBLFVBQVEsdUJBQUMsU0FBTSxPQUFPbU0sWUFBWSxVQUFVLENBQUN1QyxVQUFVb0UsY0FBY3BFLE1BQU13QyxPQUFPbFIsS0FBSyxLQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRjtBQUFBLGFBQXhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkk7QUFBQSxRQUMzSSx1QkFBQyxTQUFJLFdBQVUsZUFBYztBQUFBLGlDQUFDLFNBQU0sNEJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUI7QUFBQSxVQUFRLHVCQUFDLFNBQU0sT0FBT3FQLGFBQWEsVUFBVSxDQUFDWCxVQUFVcUUsZUFBZXJFLE1BQU13QyxPQUFPbFIsS0FBSyxLQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLGFBQTNJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEk7QUFBQSxXQUhoSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUEsaUNBQUMsU0FBTSxxQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QjtBQUFBLFVBQVEsdUJBQUMsWUFBUyxPQUFPZ1QsZ0NBQWdDLFVBQVUsQ0FBQ3RFLFVBQVV1RSxrQ0FBa0N2RSxNQUFNd0MsT0FBT2xSLEtBQUssR0FBRyxNQUFNLEtBQW5JO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFJO0FBQUEsYUFBdE07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5TTtBQUFBLFFBQ3pNLHVCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUEsaUNBQUMsU0FBTSxvQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQjtBQUFBLFVBQVEsdUJBQUMsWUFBUyxPQUFPa1Qsd0JBQXdCLFVBQVUsQ0FBQ3hFLFVBQVV5RSwwQkFBMEJ6RSxNQUFNd0MsT0FBT2xSLEtBQUssR0FBRyxNQUFNLEtBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFIO0FBQUEsYUFBckw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3TDtBQUFBLFdBRjFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsSUFDQSx1QkFBQyxnQkFDQztBQUFBLDZCQUFDLFVBQU8sU0FBUSxTQUFRLFNBQVN5USxTQUFTLHNCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdEO0FBQUEsTUFDaEQsdUJBQUMsVUFBTyxTQUFTLE1BQU1DLFNBQVM7QUFBQSxRQUM5QjVGO0FBQUFBLFFBQ0E2QjtBQUFBQSxRQUNBN0Y7QUFBQUEsUUFDQXFGO0FBQUFBLFFBQ0FrRDtBQUFBQSxRQUNBQyw0QkFBNEIwRCwrQkFBK0I1UyxNQUFNLElBQUksRUFBRUMsSUFBSSxDQUFDQyxTQUFTQSxLQUFLQyxLQUFLLENBQUMsRUFBRUMsT0FBT0MsT0FBTztBQUFBLFFBQ2hIOE8sb0JBQW9CMkQsdUJBQXVCOVMsTUFBTSxJQUFJLEVBQUVDLElBQUksQ0FBQ0MsU0FBU0EsS0FBS0MsS0FBSyxDQUFDLEVBQUVDLE9BQU9DLE9BQU87QUFBQSxNQUNsRyxDQUFDLEdBQUcsVUFBVStELFlBQVksQ0FBQ3NHLE9BQU92SyxLQUFLLEdBQUlpRSxxQkFBVyxlQUFlLHNCQVJyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUXdGO0FBQUEsU0FWMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsT0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThCQSxLQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0NBO0FBRUo7QUFBQ29PLElBckVRRCx1QkFBcUI7QUFBQSxNQUFyQkE7QUF1RVQsU0FBU1MseUJBQXlCO0FBQUEsRUFDaEM1QztBQUFBQSxFQUNBMUw7QUFBQUEsRUFDQXVPO0FBQUFBLEVBQ0E3TztBQUFBQSxFQUNBaU07QUFBQUEsRUFDQUM7QUFRRixHQUFHO0FBQUE0QyxNQUFBO0FBQ0QsUUFBTSxDQUFDeEcsd0JBQXdCeUcseUJBQXlCLElBQUlsWCxTQUFTLEVBQUU7QUFDdkUsUUFBTSxDQUFDeU8sUUFBUXFILFNBQVMsSUFBSTlWLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNxTyxTQUFTOEksVUFBVSxJQUFJblgsU0FBUyxVQUFVO0FBRWpELFFBQU11VCxXQUFXOUssY0FBYyxJQUFJdEUsT0FBTyxDQUFDNkYsU0FBU0EsS0FBS0YsUUFBUWtOLGtCQUFrQjtBQUVuRmxYLFlBQVUsTUFBTTtBQUNkLFFBQUksQ0FBQ3FVLEtBQU07QUFDWCtDLDhCQUEwQjNELFFBQVEsQ0FBQyxHQUFHekosT0FBTyxFQUFFO0FBQUEsRUFDakQsR0FBRyxDQUFDcUssTUFBTTZDLGtCQUFrQixDQUFDO0FBRTdCLFNBQ0UsdUJBQUMsVUFBTyxNQUFZLGNBQWMsQ0FBQ3BDLFNBQVMsQ0FBQ0EsUUFBUVIsUUFBUSxHQUMzRCxpQ0FBQyxpQkFBYyxXQUFVLG9CQUN2QjtBQUFBLDJCQUFDLGdCQUNDO0FBQUEsNkJBQUMsZUFBWSxtQ0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdDO0FBQUEsTUFDaEMsdUJBQUMscUJBQWtCLCtIQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtJO0FBQUEsU0FGcEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsK0JBQUMsU0FBTSxxQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsUUFDNUIsdUJBQUMsVUFBTyxPQUFPM0Qsd0JBQXdCLGVBQWV5RywyQkFDcEQ7QUFBQSxpQ0FBQyxpQkFBYyxpQ0FBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFZLEtBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsVUFDOUIsdUJBQUMsaUJBQ0UzRCxrQkFBUXZQLElBQUksQ0FBQ3dQLFdBQVcsdUJBQUMsY0FBNEIsT0FBT0EsT0FBTzFKLEtBQU0wSixpQkFBT25QLFNBQXZDbVAsT0FBTzFKLEtBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThELENBQWEsS0FEdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUEsK0JBQUMsU0FBTSxzQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWE7QUFBQSxRQUFRLHVCQUFDLFlBQVMsT0FBTzJFLFFBQVEsVUFBVSxDQUFDNEQsVUFBVXlELFVBQVV6RCxNQUFNd0MsT0FBT2xSLEtBQUssR0FBRyxNQUFNLEtBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUY7QUFBQSxXQUF2STtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBJO0FBQUEsTUFDMUksdUJBQUMsU0FBSSxXQUFVLGVBQWM7QUFBQSwrQkFBQyxTQUFNLHFCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWTtBQUFBLFFBQVEsdUJBQUMsU0FBTSxPQUFPMEssU0FBUyxVQUFVLENBQUNnRSxVQUFVOEUsV0FBVzlFLE1BQU13QyxPQUFPbFIsS0FBSyxLQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJFO0FBQUEsV0FBNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErSDtBQUFBLFNBWGpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBQ0EsdUJBQUMsZ0JBQ0M7QUFBQSw2QkFBQyxVQUFPLFNBQVEsU0FBUSxTQUFTeVEsU0FBUyxzQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRDtBQUFBLE1BQ2hELHVCQUFDLFVBQU8sU0FBUyxNQUFNQyxTQUFTLEVBQUU1RCx3QkFBd0JoQyxRQUFRSixRQUFRLENBQUMsR0FBRyxVQUFVbEcsWUFBWSxDQUFDc0ksMEJBQTBCLENBQUNoQyxPQUFPdkssS0FBSyxHQUFJaUUscUJBQVcsaUJBQWlCLHlCQUE1SztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtNO0FBQUEsU0FGcE07QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsT0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNCQSxLQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0JBO0FBRUo7QUFBQzhPLElBckRRRiwwQkFBd0I7QUFBQSxNQUF4QkE7QUF1RFQsU0FBU0ssc0JBQXNCO0FBQUEsRUFDN0JqRDtBQUFBQSxFQUNBaE07QUFBQUEsRUFDQUk7QUFBQUEsRUFDQTZMO0FBQUFBLEVBQ0FDO0FBbUJGLEdBQUc7QUFBQWdELE1BQUE7QUFDRCxRQUFNLENBQUNoVCxPQUFPaVQsUUFBUSxJQUFJdFgsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ2lOLGdCQUFnQjhJLGlCQUFpQixJQUFJL1YsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ3lOLFNBQVM4SixVQUFVLElBQUl2WCxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDNEwsWUFBWW9LLGFBQWEsSUFBSWhXLFNBQVMsYUFBYTtBQUMxRCxRQUFNLENBQUNxSyxZQUFZNEwsYUFBYSxJQUFJalcsU0FBUyw0QkFBNEI7QUFDekUsUUFBTSxDQUFDOE4sZ0JBQWdCMEosaUJBQWlCLElBQUl4WCxTQUFTLHNDQUFzQztBQUMzRixRQUFNLENBQUM0UyxVQUFVNkUsV0FBVyxJQUFJelgsU0FBUyxHQUFHO0FBQzVDLFFBQU0sQ0FBQytNLFdBQVdtSixZQUFZLElBQUlsVyxTQUFTLFFBQVE7QUFDbkQsUUFBTSxDQUFDeUssYUFBYWlLLGNBQWMsSUFBSTFVLFNBQVMsUUFBUTtBQUN2RCxRQUFNLENBQUN1SyxlQUFlbU4sZ0JBQWdCLElBQUkxWCxTQUFTLElBQUk7QUFDdkQsUUFBTSxDQUFDMlEsb0JBQW9CMEYscUJBQXFCLElBQUlyVyxTQUFTLEVBQUU7QUFFL0QsU0FDRSx1QkFBQyxVQUFPLE1BQVksY0FBYyxDQUFDNFUsU0FBUyxDQUFDQSxRQUFRUixRQUFRLEdBQzNELGlDQUFDLGlCQUFjLFdBQVUsb0JBQ3ZCO0FBQUEsMkJBQUMsZ0JBQ0M7QUFBQSw2QkFBQyxlQUFZLGdDQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkI7QUFBQSxNQUM3Qix1QkFBQyxxQkFBa0IsOEZBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUc7QUFBQSxTQUZuRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxpQ0FBQyxTQUFNLHFCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVk7QUFBQSxVQUNaLHVCQUFDLFNBQU0sT0FBTy9QLE9BQU8sVUFBVSxDQUFDZ08sVUFBVWlGLFNBQVNqRixNQUFNd0MsT0FBT2xSLEtBQUssR0FBRyxhQUFZLHNCQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRztBQUFBLGFBRnhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxpQ0FBQyxTQUFNLCtCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNCO0FBQUEsVUFDdEIsdUJBQUMsWUFBUyxPQUFPc0osZ0JBQWdCLFVBQVUsQ0FBQ29GLFVBQVUwRCxrQkFBa0IxRCxNQUFNd0MsT0FBT2xSLEtBQUssR0FBRyxNQUFNLEdBQUcsYUFBWSxxQ0FBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUo7QUFBQSxhQUZySjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsaUNBQUMsU0FBTSx1QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFjO0FBQUEsVUFDZCx1QkFBQyxZQUFTLE9BQU84SixTQUFTLFVBQVUsQ0FBQzRFLFVBQVVrRixXQUFXbEYsTUFBTXdDLE9BQU9sUixLQUFLLEdBQUcsTUFBTSxHQUFHLGFBQVkscUNBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFJO0FBQUEsYUFGdkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxpQ0FBQyxTQUFNLHdCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWU7QUFBQSxVQUNmLHVCQUFDLFNBQU0sT0FBT2lJLFlBQVksVUFBVSxDQUFDeUcsVUFBVTJELGNBQWMzRCxNQUFNd0MsT0FBT2xSLEtBQUssR0FBRyxhQUFZLGlCQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRztBQUFBLGFBRjdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxpQ0FBQyxTQUFNLDBCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlCO0FBQUEsVUFDakIsdUJBQUMsU0FBTSxPQUFPMEcsWUFBWSxVQUFVLENBQUNnSSxVQUFVNEQsY0FBYzVELE1BQU13QyxPQUFPbFIsS0FBSyxHQUFHLGFBQVksZ0JBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBHO0FBQUEsYUFGNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLGlDQUFDLFNBQU0sK0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0I7QUFBQSxVQUN0Qix1QkFBQyxTQUFNLE9BQU9tSyxnQkFBZ0IsVUFBVSxDQUFDdUUsVUFBVW1GLGtCQUFrQm5GLE1BQU13QyxPQUFPbFIsS0FBSyxLQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RjtBQUFBLGFBRjNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxtQ0FBQyxTQUFNLHdCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWU7QUFBQSxZQUNmLHVCQUFDLFVBQU8sT0FBT2lQLFVBQVUsZUFBZTZFLGFBQ3RDO0FBQUEscUNBQUMsaUJBQWMsaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBWSxLQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QjtBQUFBLGNBQzlCLHVCQUFDLGlCQUNDO0FBQUEsdUNBQUMsY0FBVyxPQUFNLEtBQUksd0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThCO0FBQUEsZ0JBQzlCLHVCQUFDLGNBQVcsT0FBTSxLQUFJLG9CQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQjtBQUFBLGdCQUMxQix1QkFBQyxjQUFXLE9BQU0sS0FBSSxzQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEI7QUFBQSxnQkFDNUIsdUJBQUMsY0FBVyxPQUFNLEtBQUksbUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlCO0FBQUEsbUJBSjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLG1DQUFDLFNBQU0sb0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBVztBQUFBLFlBQ1gsdUJBQUMsVUFBTyxPQUFPMUssV0FBVyxlQUFlbUosY0FDdkM7QUFBQSxxQ0FBQyxpQkFBYyxpQ0FBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFZLEtBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThCO0FBQUEsY0FDOUIsdUJBQUMsaUJBQ0M7QUFBQSx1Q0FBQyxjQUFXLE9BQU0sT0FBTSxtQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkI7QUFBQSxnQkFDM0IsdUJBQUMsY0FBVyxPQUFNLFVBQVMsc0JBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlDO0FBQUEsZ0JBQ2pDLHVCQUFDLGNBQVcsT0FBTSxRQUFPLG9CQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QjtBQUFBLGdCQUM3Qix1QkFBQyxjQUFXLE9BQU0sWUFBVyx3QkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUM7QUFBQSxtQkFKdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxhQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUJBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLG1DQUFDLFNBQU0sNEJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUI7QUFBQSxZQUNuQix1QkFBQyxTQUFNLE9BQU96TCxhQUFhLFVBQVUsQ0FBQzRILFVBQVVxQyxlQUFlckMsTUFBTXdDLE9BQU9sUixLQUFLLEtBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1GO0FBQUEsZUFGckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxtQ0FBQyxTQUFNLDhCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFCO0FBQUEsWUFDckIsdUJBQUMsU0FBTSxPQUFPNEcsZUFBZSxVQUFVLENBQUM4SCxVQUFVcUYsaUJBQWlCckYsTUFBTXdDLE9BQU9sUixLQUFLLEtBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVGO0FBQUEsZUFGekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLGlDQUFDLFNBQU0sbUNBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEI7QUFBQSxVQUMxQix1QkFBQyxZQUFTLE9BQU9nTixvQkFBb0IsVUFBVSxDQUFDMEIsVUFBVWdFLHNCQUFzQmhFLE1BQU13QyxPQUFPbFIsS0FBSyxHQUFHLE1BQU0sR0FBRyxhQUFhLGdGQUEzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3TTtBQUFBLGFBRjFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBcERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxREE7QUFBQSxTQXJFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0VBO0FBQUEsSUFFQzRFLFFBQVEsdUJBQUMsU0FBSSxXQUFVLHdCQUF3QkEsbUJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkMsSUFBUztBQUFBLElBRS9ELHVCQUFDLGdCQUNDO0FBQUEsNkJBQUMsVUFBTyxTQUFRLFNBQVEsU0FBUzZMLFNBQVMsc0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0Q7QUFBQSxNQUNoRDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUyxNQUFNQyxTQUFTLEVBQUVoUSxPQUFPNEksZ0JBQWdCUSxTQUFTN0IsWUFBWXZCLFlBQVl5RCxnQkFBZ0I4RSxVQUFVN0YsV0FBV3RDLGFBQWFGLGVBQWVvRyxtQkFBbUIsQ0FBQztBQUFBLFVBQ3ZLLFVBQVV4SSxZQUFZLENBQUM5RCxNQUFNSCxLQUFLLEtBQUssQ0FBQytJLGVBQWUvSSxLQUFLLEtBQUssQ0FBQ3lNLG1CQUFtQnpNLEtBQUs7QUFBQSxVQUV6RmlFLHFCQUFXLGNBQWM7QUFBQTtBQUFBLFFBSjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsU0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxPQXhGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUZBLEtBMUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyRkE7QUFFSjtBQUFDa1AsSUFuSVFELHVCQUFxQjtBQUFBLE1BQXJCQTtBQUFxQixJQUFBTyxJQUFBbEUsS0FBQUcsS0FBQUUsS0FBQUcsS0FBQTJELEtBQUFDLEtBQUFDLEtBQUFDLEtBQUFDLEtBQUFDO0FBQUEsYUFBQU4sSUFBQTtBQUFBLGFBQUFsRSxLQUFBO0FBQUEsYUFBQUcsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBRyxLQUFBO0FBQUEsYUFBQTJELEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJhcGkiLCJCYWRnZSIsIkJ1dHRvbiIsIkNhcmQiLCJEaWFsb2ciLCJEaWFsb2dDb250ZW50IiwiRGlhbG9nRGVzY3JpcHRpb24iLCJEaWFsb2dGb290ZXIiLCJEaWFsb2dIZWFkZXIiLCJEaWFsb2dUaXRsZSIsIklucHV0IiwiTGFiZWwiLCJTZWxlY3QiLCJTZWxlY3RDb250ZW50IiwiU2VsZWN0SXRlbSIsIlNlbGVjdFRyaWdnZXIiLCJTZWxlY3RWYWx1ZSIsIlRleHRhcmVhIiwiUGFnZUhlYWRlciIsIkFycm93TGVmdCIsIkNsaXBib2FyZExpc3QiLCJFeHRlcm5hbExpbmsiLCJQbGF5Q2lyY2xlIiwiUGx1cyIsIlNoaWVsZENoZWNrIiwiU3BhcmtsZXMiLCJUcmlhbmdsZUFsZXJ0IiwiY291bnRCeVF1aWNrRmlsdGVyIiwiREVGQVVMVF9XT1JLX09SREVSX0ZJTFRFUlMiLCJkZXJpdmVOZXh0QWN0aW9uIiwiZmlsdGVyV29ya09yZGVycyIsInN1bW1hcml6ZVJlcXVpcmVkQXR0ZW50aW9uIiwiRXhlY3V0aW9uUnVuSW5zcGVjdG9yIiwic3BsaXRDdXJyZW50QW5kSGlzdG9yaWNhbFJldmlzaW9ucyIsInN1bW1hcml6ZVJldmlzaW9uRWZmZWN0cyIsIlJJU0tfU1RZTEVTIiwiTE9XIiwiTUVESVVNIiwiSElHSCIsIkNSSVRJQ0FMIiwiU1RBVEVfU1RZTEVTIiwiRFJBRlQiLCJSRUFEWSIsIkRJU1BBVENIRUQiLCJJTl9QUk9HUkVTUyIsIkJMT0NLRUQiLCJBV0FJVElOR19BUFBST1ZBTCIsIkFXQUlUSU5HX1ZFUklGSUNBVElPTiIsIlJFT1BFTkVEIiwiRE9ORSIsIkNBTkNFTEVEIiwiU1VQRVJTRURFRCIsIlFVSUNLX0ZJTFRFUlMiLCJpZCIsImxhYmVsIiwicHJldHR5TGFiZWwiLCJ2YWx1ZSIsInJlcGxhY2UiLCJjcml0ZXJpYUZyb21UZXh0IiwiZXhpc3RpbmdDcml0ZXJpYSIsInNwbGl0IiwibWFwIiwibGluZSIsInRyaW0iLCJmaWx0ZXIiLCJCb29sZWFuIiwidGl0bGUiLCJpbmRleCIsImV4aXN0aW5nIiwiZGVzY3JpcHRpb24iLCJ2ZXJpZmljYXRpb25NZXRob2QiLCJzdGF0dXMiLCJsYXRlc3RCeUNyaXRlcmlvbiIsInJlY2VpcHRzIiwibGF0ZXN0IiwiTWFwIiwic29ydCIsImEiLCJiIiwicmVjb3JkZWRBdCIsImZvckVhY2giLCJyZWNlaXB0IiwiaGFzIiwiYWNjZXB0YW5jZUNyaXRlcmlvbklkIiwic2V0IiwiV29ya09yZGVyc1ZpZXciLCJwcm9qZWN0SWQiLCJfcyIsImZpbHRlcnMiLCJzZXRGaWx0ZXJzIiwic2VsZWN0ZWRJZCIsInNldFNlbGVjdGVkSWQiLCJtb2JpbGVEZXRhaWxPcGVuIiwic2V0TW9iaWxlRGV0YWlsT3BlbiIsImNyZWF0ZU9wZW4iLCJzZXRDcmVhdGVPcGVuIiwiYXBwcm92YWxPcGVuIiwic2V0QXBwcm92YWxPcGVuIiwicmVjZWlwdE9wZW4iLCJzZXRSZWNlaXB0T3BlbiIsInJldmlzaW9uT3BlbiIsInNldFJldmlzaW9uT3BlbiIsInJlb3Blbk9wZW4iLCJzZXRSZW9wZW5PcGVuIiwic3VwZXJzZWRlT3BlbiIsInNldFN1cGVyc2VkZU9wZW4iLCJjcmVhdGVSZXF1ZXN0S2V5Iiwic2V0Q3JlYXRlUmVxdWVzdEtleSIsImRpc3BhdGNoaW5nSWQiLCJzZXREaXNwYXRjaGluZ0lkIiwiYWNjZXB0aW5nSWQiLCJzZXRBY2NlcHRpbmdJZCIsInJldmlzaW5nSWQiLCJzZXRSZXZpc2luZ0lkIiwicmVvcGVuaW5nSWQiLCJzZXRSZW9wZW5pbmdJZCIsInN1cGVyc2VkaW5nSWQiLCJzZXRTdXBlcnNlZGluZ0lkIiwiaW5zcGVjdG9yUnVuSWQiLCJzZXRJbnNwZWN0b3JSdW5JZCIsImluc3BlY3RvclJlY2VpcHRJZCIsInNldEluc3BlY3RvclJlY2VpcHRJZCIsImluc3BlY3RvckNyaXRlcmlvbklkIiwic2V0SW5zcGVjdG9yQ3JpdGVyaW9uSWQiLCJkaXNwYXRjaEVycm9yIiwic2V0RGlzcGF0Y2hFcnJvciIsImdvdmVybmFuY2VFcnJvciIsInNldEdvdmVybmFuY2VFcnJvciIsImNyZWF0aW5nIiwic2V0Q3JlYXRpbmciLCJzZWVkaW5nIiwic2V0U2VlZGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJ3b3JrT3JkZXJzIiwibGlzdCIsInNlbGVjdGVkIiwiZ2V0Iiwid29ya09yZGVySWQiLCJjcmVhdGVXb3JrT3JkZXIiLCJjcmVhdGUiLCJkaXNwYXRjaFdvcmtPcmRlciIsImRpc3BhdGNoIiwicmVxdWVzdEFwcHJvdmFsRGVjaXNpb24iLCJyZWNvcmRWZXJpZmljYXRpb25SZWNlaXB0IiwiYWNjZXB0V29ya09yZGVyIiwiYWNjZXB0IiwicmVxdWVzdFdvcmtPcmRlclJldmlzaW9uIiwiYXBwcm92ZVdvcmtPcmRlclJldmlzaW9uIiwicmVvcGVuV29ya09yZGVyIiwic3VwZXJzZWRlV29ya09yZGVyIiwiZXhwaXJlR292ZXJuYW5jZVJlY29yZHMiLCJzZWVkRGVtbyIsImZpbHRlcmVkIiwibGVuZ3RoIiwiX2lkIiwic29tZSIsIml0ZW0iLCJyZXBvc2l0b3JpZXMiLCJBcnJheSIsImZyb20iLCJTZXQiLCJyZXBvc2l0b3J5IiwiYXNzaWduZWRBZ2VudHMiLCJhc3NpZ25lZEFnZW50IiwicmVxdWVzdG9ycyIsInJlcXVlc3RlZEJ5IiwiY291bnRzIiwicm93cyIsInRvdGFsIiwiYWN0aXZlIiwicm93IiwiaW5jbHVkZXMiLCJzdGF0ZSIsImJsb2NrZWQiLCJhdHRlbnRpb24iLCJyZXF1aXJlZEh1bWFuQWN0aW9uIiwiYXBwcm92YWxTdGF0dXMiLCJ2ZXJpZmljYXRpb25TdGF0dXMiLCJxdWlja0ZpbHRlckNvdW50cyIsIk9iamVjdCIsImZyb21FbnRyaWVzIiwiaGFuZGxlU2VlZCIsImNhbkRpc3BhdGNoU2VsZWN0ZWQiLCJ3b3JrT3JkZXIiLCJ3b3JrZmxvd0lkIiwiZXhlY3V0aW9uUnVucyIsInJ1biIsImNhbkFjY2VwdFNlbGVjdGVkIiwiYWNjZXB0YW5jZVN1bW1hcnkiLCJlbGlnaWJsZSIsImxhdGVzdFJlY2VpcHRNYXAiLCJ2ZXJpZmljYXRpb25SZWNlaXB0cyIsIl9jcmVhdGlvblRpbWUiLCJyZXZpc2lvblNwbGl0IiwicmV2aXNpb25zIiwiY3VycmVudFJldmlzaW9uSWQiLCJnbG9iYWxUaGlzIiwiY3J5cHRvIiwicmFuZG9tVVVJRCIsIkRhdGUiLCJub3ciLCJxdWlja0ZpbHRlciIsImN1cnJlbnQiLCJyaXNrTGV2ZWwiLCJzZWxlY3RlZFJvdyIsImRlc2lyZWRPdXRjb21lIiwibWV0YWRhdGEiLCJhdXRvbWF0aW9uRGVmaW5pdGlvbklkIiwibGF0ZXN0RXhlY3V0aW9uUnVuIiwiYXNzaWduZWRTcXVhZCIsImVyciIsIkVycm9yIiwibWVzc2FnZSIsImNvbnRleHQiLCJhdXRvbWF0aW9uV29ya2Zsb3dWZXJzaW9uIiwiYXV0b21hdGlvbkNhZGVuY2UiLCJjcm9uIiwiYXV0b21hdGlvblNjb3BlIiwiYnJhbmNoU3RyYXRlZ3kiLCJibG9ja2luZ0lzc3VlIiwibWlzc2luZ0FwcHJvdmFsVHlwZXMiLCJmYWlsZWRDcml0ZXJpYUlkcyIsInN0YWxlQ3JpdGVyaWFJZHMiLCJtaXNzaW5nQ3JpdGVyaWFJZHMiLCJhY3RvclR5cGUiLCJhY3RvcklkIiwiaWRlbXBvdGVuY3lLZXkiLCJ1cGRhdGVkQXQiLCJibG9ja2luZ1JlYXNvbnMiLCJyZWFzb24iLCJhcHByb3ZhbERlY2lzaW9ucyIsImFwcHJvdmFsIiwiYXBwcm92YWxUeXBlIiwicmVxdWVzdGVkQWN0aW9uIiwiYXBwcm92ZXIiLCJkZWNpZGVkQXQiLCJ0b0xvY2FsZVN0cmluZyIsImNvbmRpdGlvbnMiLCJqb2luIiwiY3VycmVudFJldmlzaW9uTnVtYmVyIiwiZ292ZXJuYW5jZVN0YXR1cyIsImV4cGlyaW5nQXBwcm92YWxzIiwiZXhwaXJlZEFwcHJvdmFscyIsInN0YWxlUmVjZWlwdHMiLCJyZXF1aXJlZFJlYXBwcm92YWwiLCJyZXF1aXJlZFJldmVyaWZpY2F0aW9uIiwiYWNjZXB0ZWRSZXZpc2lvbk51bWJlciIsInJldmlzaW9uTnVtYmVyIiwiY2hhbmdlU3VtbWFyeSIsIndvcmtPcmRlclJldmlzaW9uSWQiLCJhcHByb3ZlZEJ5IiwiaGlzdG9yaWNhbCIsInJldmlzaW9uIiwiY2hhbmdlZEZpZWxkcyIsImVmZmVjdGl2ZUF0IiwiY3JlYXRlZEF0IiwibGF0ZXN0QWNjZXB0ZWRSZXZpc2lvbiIsInJlb3BlbkRlY2lzaW9ucyIsInNvdXJjZUlzc3VlT3JEZWZlY3QiLCJpbnZhbGlkYXRlZFJlY2VpcHRJZHMiLCJzdXBlcnNlc3Npb24iLCJyZXBsYWNlbWVudFdvcmtPcmRlcklkIiwic3VwZXJzZWRlZEJ5V29ya09yZGVySWQiLCJhY2NlcHRhbmNlQ3JpdGVyaWEiLCJjcml0ZXJpb24iLCJibG9ja2luZ1JlYXNvbiIsIndhaXZlckFwcHJvdmFsRGVjaXNpb25JZCIsImV2aWRlbmNlTG9jYXRpb24iLCJhcnRpZmFjdFJlZmVyZW5jZSIsImZpbmQiLCJ3b3JrZmxvd1J1bklkIiwicnVuSWQiLCJ2ZXJpZmllciIsImV4Y2VwdGlvbk9yV2FpdmVyIiwiY29tbWFuZE9yQ2hlY2siLCJyZXN1bHQiLCJzb3VyY2VPZlRydXRoUmVmcyIsInJlZiIsImtpbmQiLCJsb2NhdGlvbiIsInJ1bnRpbWUiLCJtb2RlbCIsIndvcmt0cmVlIiwiY3VycmVudFN0ZXBMYWJlbCIsInJldHJ5Q291bnQiLCJodW1hbkludGVydmVudGlvbnMiLCJmYWlsdXJlUmVhc29uIiwiZXZlbnRzIiwic2xpY2UiLCJldmVudCIsInN1bW1hcnkiLCJldmVudFR5cGUiLCJmcm9tU3RhdGUiLCJ0b1N0YXRlIiwicGF5bG9hZCIsInVuZGVmaW5lZCIsInByaW9yaXR5IiwiTnVtYmVyIiwicGF0Y2giLCJyZXF1aXJlZEFwcHJvdmFscyIsInJlb3BlblNjb3BlIiwiYWNjZXB0YW5jZUNyaXRlcmlhSW1wYWN0ZWQiLCJuZXdSZXF1aXJlZEFjdGlvbnMiLCJyZXRyeU9mV29ya2Zsb3dSdW5JZCIsInJldHJ5UmVhc29uIiwiRmlsdGVyU2VsZWN0Iiwib25DaGFuZ2UiLCJvcHRpb25zIiwib3B0aW9uIiwiX2MyIiwiU2VjdGlvbiIsImNoaWxkcmVuIiwiX2MzIiwiTWV0YVJvdyIsIl9jNCIsIlN0YXRDYXJkIiwidG9uZSIsIl9jNSIsIlJlcXVlc3RBcHByb3ZhbERpYWxvZyIsIm9wZW4iLCJvbkNsb3NlIiwib25DcmVhdGUiLCJfczIiLCJkZWZhdWx0VHlwZSIsInNldEFwcHJvdmFsVHlwZSIsInNldFJlcXVlc3RlZEFjdGlvbiIsInNldFJlcXVlc3RlZEJ5Iiwic2V0V29ya2Zsb3dSdW5JZCIsIm5leHQiLCJ0YXJnZXQiLCJSZWNvcmRWZXJpZmljYXRpb25SZWNlaXB0RGlhbG9nIiwiX3MzIiwic2V0QWNjZXB0YW5jZUNyaXRlcmlvbklkIiwic2V0VmVyaWZpY2F0aW9uTWV0aG9kIiwic2V0Q29tbWFuZE9yQ2hlY2siLCJzZXRSZXN1bHQiLCJzZXRFdmlkZW5jZUxvY2F0aW9uIiwic2V0QXJ0aWZhY3RSZWZlcmVuY2UiLCJzZXRWZXJpZmllciIsInNldFN0YXR1cyIsInNldEV4Y2VwdGlvbk9yV2FpdmVyIiwic2V0V2FpdmVyQXBwcm92YWxEZWNpc2lvbklkIiwid2FpdmVyT3B0aW9ucyIsIlJlcXVlc3RSZXZpc2lvbkRpYWxvZyIsIl9zNCIsInNldENoYW5nZVN1bW1hcnkiLCJzZXRSZWFzb24iLCJzZXREZXNpcmVkT3V0Y29tZSIsInNldFdvcmtmbG93SWQiLCJzZXRSZXBvc2l0b3J5Iiwic2V0Umlza0xldmVsIiwicmVxdWlyZWRBcHByb3ZhbHNUZXh0Iiwic2V0UmVxdWlyZWRBcHByb3ZhbHNUZXh0Iiwic2V0QWNjZXB0YW5jZUNyaXRlcmlhIiwiUmVvcGVuV29ya09yZGVyRGlhbG9nIiwiX3M1Iiwic2V0U291cmNlSXNzdWVPckRlZmVjdCIsInNldEFwcHJvdmVkQnkiLCJzZXRSZW9wZW5TY29wZSIsImFjY2VwdGFuY2VDcml0ZXJpYUltcGFjdGVkVGV4dCIsInNldEFjY2VwdGFuY2VDcml0ZXJpYUltcGFjdGVkVGV4dCIsIm5ld1JlcXVpcmVkQWN0aW9uc1RleHQiLCJzZXROZXdSZXF1aXJlZEFjdGlvbnNUZXh0IiwiU3VwZXJzZWRlV29ya09yZGVyRGlhbG9nIiwiY3VycmVudFdvcmtPcmRlcklkIiwiX3M2Iiwic2V0UmVwbGFjZW1lbnRXb3JrT3JkZXJJZCIsInNldEFjdG9ySWQiLCJDcmVhdGVXb3JrT3JkZXJEaWFsb2ciLCJfczciLCJzZXRUaXRsZSIsInNldENvbnRleHQiLCJzZXRCcmFuY2hTdHJhdGVneSIsInNldFByaW9yaXR5Iiwic2V0QXNzaWduZWRBZ2VudCIsIl9jIiwiX2M2IiwiX2M3IiwiX2M4IiwiX2M5IiwiX2MwIiwiX2MxIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIldvcmtPcmRlcnNWaWV3LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnkgfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgQmFkZ2UgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2JhZGdlXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuaW1wb3J0IHsgQ2FyZCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvY2FyZFwiO1xuaW1wb3J0IHtcbiAgRGlhbG9nLFxuICBEaWFsb2dDb250ZW50LFxuICBEaWFsb2dEZXNjcmlwdGlvbixcbiAgRGlhbG9nRm9vdGVyLFxuICBEaWFsb2dIZWFkZXIsXG4gIERpYWxvZ1RpdGxlLFxufSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2RpYWxvZ1wiO1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2lucHV0XCI7XG5pbXBvcnQgeyBMYWJlbCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvbGFiZWxcIjtcbmltcG9ydCB7XG4gIFNlbGVjdCxcbiAgU2VsZWN0Q29udGVudCxcbiAgU2VsZWN0SXRlbSxcbiAgU2VsZWN0VHJpZ2dlcixcbiAgU2VsZWN0VmFsdWUsXG59IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvc2VsZWN0XCI7XG5pbXBvcnQgeyBUZXh0YXJlYSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvdGV4dGFyZWFcIjtcbmltcG9ydCB7IFBhZ2VIZWFkZXIgfSBmcm9tIFwiQC9jb21wb25lbnRzL1BhZ2VIZWFkZXJcIjtcbmltcG9ydCB7IEFycm93TGVmdCwgQ2xpcGJvYXJkTGlzdCwgRXh0ZXJuYWxMaW5rLCBQbGF5Q2lyY2xlLCBQbHVzLCBTaGllbGRDaGVjaywgU3BhcmtsZXMsIFRyaWFuZ2xlQWxlcnQgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQge1xuICBjb3VudEJ5UXVpY2tGaWx0ZXIsXG4gIERFRkFVTFRfV09SS19PUkRFUl9GSUxURVJTLFxuICBkZXJpdmVOZXh0QWN0aW9uLFxuICBmaWx0ZXJXb3JrT3JkZXJzLFxuICBzdW1tYXJpemVSZXF1aXJlZEF0dGVudGlvbixcbiAgdHlwZSBXb3JrT3JkZXJRdWV1ZUZpbHRlcnMsXG4gIHR5cGUgV29ya09yZGVyUXVpY2tGaWx0ZXIsXG59IGZyb20gXCIuL3dvcmtPcmRlcnNNb2RlbFwiO1xuaW1wb3J0IHsgRXhlY3V0aW9uUnVuSW5zcGVjdG9yIH0gZnJvbSBcIi4vRXhlY3V0aW9uUnVuSW5zcGVjdG9yXCI7XG5pbXBvcnQgeyBzcGxpdEN1cnJlbnRBbmRIaXN0b3JpY2FsUmV2aXNpb25zLCBzdW1tYXJpemVSZXZpc2lvbkVmZmVjdHMgfSBmcm9tIFwiLi93b3JrT3JkZXJMaWZlY3ljbGVNb2RlbFwiO1xuXG5jb25zdCBSSVNLX1NUWUxFUzogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcbiAgTE9XOiBcImJvcmRlci1lbWVyYWxkLTUwMC8zMCB0ZXh0LWVtZXJhbGQtMzAwXCIsXG4gIE1FRElVTTogXCJib3JkZXItcmVnaXN0cnktYWNjZW50LzMwIHRleHQtcmVnaXN0cnktYWNjZW50XCIsXG4gIEhJR0g6IFwiYm9yZGVyLWFtYmVyLTUwMC8zMCB0ZXh0LWFtYmVyLTMwMFwiLFxuICBDUklUSUNBTDogXCJib3JkZXItcmVkLTUwMC8zMCB0ZXh0LXJlZC0zMDBcIixcbn07XG5cbmNvbnN0IFNUQVRFX1NUWUxFUzogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcbiAgRFJBRlQ6IFwiYm9yZGVyLWJvcmRlciB0ZXh0LW11dGVkLWZvcmVncm91bmRcIixcbiAgUkVBRFk6IFwiYm9yZGVyLXJlZ2lzdHJ5LWFjY2VudC8zMCB0ZXh0LXJlZ2lzdHJ5LWFjY2VudFwiLFxuICBESVNQQVRDSEVEOiBcImJvcmRlci1yZWdpc3RyeS1hY2NlbnQvMzAgdGV4dC1yZWdpc3RyeS1hY2NlbnRcIixcbiAgSU5fUFJPR1JFU1M6IFwiYm9yZGVyLXByaW1hcnkvMzAgdGV4dC1wcmltYXJ5XCIsXG4gIEJMT0NLRUQ6IFwiYm9yZGVyLXJlZC01MDAvMzAgdGV4dC1yZWQtMzAwXCIsXG4gIEFXQUlUSU5HX0FQUFJPVkFMOiBcImJvcmRlci1hbWJlci01MDAvMzAgdGV4dC1hbWJlci0zMDBcIixcbiAgQVdBSVRJTkdfVkVSSUZJQ0FUSU9OOiBcImJvcmRlci1hbWJlci01MDAvMzAgdGV4dC1hbWJlci0zMDBcIixcbiAgUkVPUEVORUQ6IFwiYm9yZGVyLXB1cnBsZS01MDAvMzAgdGV4dC1wdXJwbGUtMjAwXCIsXG4gIERPTkU6IFwiYm9yZGVyLWVtZXJhbGQtNTAwLzMwIHRleHQtZW1lcmFsZC0zMDBcIixcbiAgQ0FOQ0VMRUQ6IFwiYm9yZGVyLWJvcmRlciB0ZXh0LW11dGVkLWZvcmVncm91bmRcIixcbiAgU1VQRVJTRURFRDogXCJib3JkZXItc2xhdGUtNTAwLzMwIHRleHQtc2xhdGUtMzAwXCIsXG59O1xuXG5jb25zdCBRVUlDS19GSUxURVJTOiBBcnJheTx7IGlkOiBXb3JrT3JkZXJRdWlja0ZpbHRlcjsgbGFiZWw6IHN0cmluZyB9PiA9IFtcbiAgeyBpZDogXCJhbGxcIiwgbGFiZWw6IFwiQWxsXCIgfSxcbiAgeyBpZDogXCJuZWVkc19hdHRlbnRpb25cIiwgbGFiZWw6IFwiTmVlZHMgYXR0ZW50aW9uXCIgfSxcbiAgeyBpZDogXCJibG9ja2VkXCIsIGxhYmVsOiBcIkJsb2NrZWRcIiB9LFxuICB7IGlkOiBcImF3YWl0aW5nX2FwcHJvdmFsXCIsIGxhYmVsOiBcIkF3YWl0aW5nIGFwcHJvdmFsXCIgfSxcbiAgeyBpZDogXCJyZWFkeV90b19kaXNwYXRjaFwiLCBsYWJlbDogXCJSZWFkeSB0byBkaXNwYXRjaFwiIH0sXG5dO1xuXG5mdW5jdGlvbiBwcmV0dHlMYWJlbCh2YWx1ZTogc3RyaW5nIHwgdW5kZWZpbmVkIHwgbnVsbCkge1xuICBpZiAoIXZhbHVlKSByZXR1cm4gXCLigJRcIjtcbiAgcmV0dXJuIHZhbHVlLnJlcGxhY2UoL18vZywgXCIgXCIpO1xufVxuXG5mdW5jdGlvbiBjcml0ZXJpYUZyb21UZXh0KHZhbHVlOiBzdHJpbmcsIGV4aXN0aW5nQ3JpdGVyaWE6IEFycmF5PHsgaWQ6IHN0cmluZzsgdGl0bGU6IHN0cmluZzsgZGVzY3JpcHRpb24/OiBzdHJpbmc7IHZlcmlmaWNhdGlvbk1ldGhvZD86IHN0cmluZyB9PiA9IFtdKSB7XG4gIHJldHVybiB2YWx1ZVxuICAgIC5zcGxpdChcIlxcblwiKVxuICAgIC5tYXAoKGxpbmUpID0+IGxpbmUudHJpbSgpKVxuICAgIC5maWx0ZXIoQm9vbGVhbilcbiAgICAubWFwKCh0aXRsZSwgaW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IGV4aXN0aW5nID0gZXhpc3RpbmdDcml0ZXJpYVtpbmRleF07XG4gICAgICByZXR1cm4ge1xuICAgICAgICBpZDogZXhpc3Rpbmc/LmlkID8/IGBhYy0ke2luZGV4ICsgMX1gLFxuICAgICAgICB0aXRsZSxcbiAgICAgICAgZGVzY3JpcHRpb246IGV4aXN0aW5nPy5kZXNjcmlwdGlvbixcbiAgICAgICAgdmVyaWZpY2F0aW9uTWV0aG9kOiAoZXhpc3Rpbmc/LnZlcmlmaWNhdGlvbk1ldGhvZCBhcyBcIk1BTlVBTFwiIHwgXCJDT01NQU5EXCIgfCBcIlRFU1RcIiB8IFwiQ0hFQ0tMSVNUXCIgfCB1bmRlZmluZWQpID8/IFwiTUFOVUFMXCIsXG4gICAgICAgIHN0YXR1czogXCJQRU5ESU5HXCIgYXMgY29uc3QsXG4gICAgICB9O1xuICAgIH0pO1xufVxuXG5mdW5jdGlvbiBsYXRlc3RCeUNyaXRlcmlvbjxUIGV4dGVuZHMgeyBhY2NlcHRhbmNlQ3JpdGVyaW9uSWQ6IHN0cmluZzsgcmVjb3JkZWRBdDogbnVtYmVyIH0+KHJlY2VpcHRzOiBUW10pIHtcbiAgY29uc3QgbGF0ZXN0ID0gbmV3IE1hcDxzdHJpbmcsIFQ+KCk7XG4gIFsuLi5yZWNlaXB0c10uc29ydCgoYSwgYikgPT4gYi5yZWNvcmRlZEF0IC0gYS5yZWNvcmRlZEF0KS5mb3JFYWNoKChyZWNlaXB0KSA9PiB7XG4gICAgaWYgKCFsYXRlc3QuaGFzKHJlY2VpcHQuYWNjZXB0YW5jZUNyaXRlcmlvbklkKSkgbGF0ZXN0LnNldChyZWNlaXB0LmFjY2VwdGFuY2VDcml0ZXJpb25JZCwgcmVjZWlwdCk7XG4gIH0pO1xuICByZXR1cm4gbGF0ZXN0O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gV29ya09yZGVyc1ZpZXcoeyBwcm9qZWN0SWQgfTogeyBwcm9qZWN0SWQ6IElkPFwicHJvamVjdHNcIj4gfCBudWxsIH0pIHtcbiAgY29uc3QgW2ZpbHRlcnMsIHNldEZpbHRlcnNdID0gdXNlU3RhdGU8V29ya09yZGVyUXVldWVGaWx0ZXJzPihERUZBVUxUX1dPUktfT1JERVJfRklMVEVSUyk7XG4gIGNvbnN0IFtzZWxlY3RlZElkLCBzZXRTZWxlY3RlZElkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbbW9iaWxlRGV0YWlsT3Blbiwgc2V0TW9iaWxlRGV0YWlsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtjcmVhdGVPcGVuLCBzZXRDcmVhdGVPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2FwcHJvdmFsT3Blbiwgc2V0QXBwcm92YWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3JlY2VpcHRPcGVuLCBzZXRSZWNlaXB0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtyZXZpc2lvbk9wZW4sIHNldFJldmlzaW9uT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtyZW9wZW5PcGVuLCBzZXRSZW9wZW5PcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3N1cGVyc2VkZU9wZW4sIHNldFN1cGVyc2VkZU9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbY3JlYXRlUmVxdWVzdEtleSwgc2V0Q3JlYXRlUmVxdWVzdEtleV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2Rpc3BhdGNoaW5nSWQsIHNldERpc3BhdGNoaW5nSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFthY2NlcHRpbmdJZCwgc2V0QWNjZXB0aW5nSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtyZXZpc2luZ0lkLCBzZXRSZXZpc2luZ0lkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbcmVvcGVuaW5nSWQsIHNldFJlb3BlbmluZ0lkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbc3VwZXJzZWRpbmdJZCwgc2V0U3VwZXJzZWRpbmdJZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2luc3BlY3RvclJ1bklkLCBzZXRJbnNwZWN0b3JSdW5JZF0gPSB1c2VTdGF0ZTxJZDxcIndvcmtmbG93UnVuc1wiPiB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbaW5zcGVjdG9yUmVjZWlwdElkLCBzZXRJbnNwZWN0b3JSZWNlaXB0SWRdID0gdXNlU3RhdGU8SWQ8XCJ2ZXJpZmljYXRpb25SZWNlaXB0c1wiPiB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbaW5zcGVjdG9yQ3JpdGVyaW9uSWQsIHNldEluc3BlY3RvckNyaXRlcmlvbklkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbZGlzcGF0Y2hFcnJvciwgc2V0RGlzcGF0Y2hFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2dvdmVybmFuY2VFcnJvciwgc2V0R292ZXJuYW5jZUVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbY3JlYXRpbmcsIHNldENyZWF0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3NlZWRpbmcsIHNldFNlZWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IHdvcmtPcmRlcnMgPSB1c2VRdWVyeShhcGkud29ya09yZGVycy5saXN0LCBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCB9IDoge30pO1xuICBjb25zdCBzZWxlY3RlZCA9IHVzZVF1ZXJ5KFxuICAgIGFwaS53b3JrT3JkZXJzLmdldCxcbiAgICBzZWxlY3RlZElkID8geyB3b3JrT3JkZXJJZDogc2VsZWN0ZWRJZCBhcyBJZDxcIndvcmtPcmRlcnNcIj4gfSA6IFwic2tpcFwiXG4gICk7XG4gIGNvbnN0IGNyZWF0ZVdvcmtPcmRlciA9IHVzZU11dGF0aW9uKGFwaS53b3JrT3JkZXJzLmNyZWF0ZSk7XG4gIGNvbnN0IGRpc3BhdGNoV29ya09yZGVyID0gdXNlTXV0YXRpb24oYXBpLndvcmtPcmRlcnMuZGlzcGF0Y2gpO1xuICBjb25zdCByZXF1ZXN0QXBwcm92YWxEZWNpc2lvbiA9IHVzZU11dGF0aW9uKGFwaS53b3JrT3JkZXJzLnJlcXVlc3RBcHByb3ZhbERlY2lzaW9uKTtcbiAgY29uc3QgcmVjb3JkVmVyaWZpY2F0aW9uUmVjZWlwdCA9IHVzZU11dGF0aW9uKGFwaS53b3JrT3JkZXJzLnJlY29yZFZlcmlmaWNhdGlvblJlY2VpcHQpO1xuICBjb25zdCBhY2NlcHRXb3JrT3JkZXIgPSB1c2VNdXRhdGlvbihhcGkud29ya09yZGVycy5hY2NlcHQpO1xuICBjb25zdCByZXF1ZXN0V29ya09yZGVyUmV2aXNpb24gPSB1c2VNdXRhdGlvbihhcGkud29ya09yZGVycy5yZXF1ZXN0V29ya09yZGVyUmV2aXNpb24pO1xuICBjb25zdCBhcHByb3ZlV29ya09yZGVyUmV2aXNpb24gPSB1c2VNdXRhdGlvbihhcGkud29ya09yZGVycy5hcHByb3ZlV29ya09yZGVyUmV2aXNpb24pO1xuICBjb25zdCByZW9wZW5Xb3JrT3JkZXIgPSB1c2VNdXRhdGlvbihhcGkud29ya09yZGVycy5yZW9wZW5Xb3JrT3JkZXIpO1xuICBjb25zdCBzdXBlcnNlZGVXb3JrT3JkZXIgPSB1c2VNdXRhdGlvbihhcGkud29ya09yZGVycy5zdXBlcnNlZGVXb3JrT3JkZXIpO1xuICBjb25zdCBleHBpcmVHb3Zlcm5hbmNlUmVjb3JkcyA9IHVzZU11dGF0aW9uKGFwaS53b3JrT3JkZXJzLmV4cGlyZUdvdmVybmFuY2VSZWNvcmRzKTtcbiAgY29uc3Qgc2VlZERlbW8gPSB1c2VNdXRhdGlvbihhcGkud29ya09yZGVycy5zZWVkRGVtbyk7XG5cbiAgY29uc3QgZmlsdGVyZWQgPSB1c2VNZW1vKCgpID0+IGZpbHRlcldvcmtPcmRlcnMod29ya09yZGVycyA/PyBbXSwgZmlsdGVycyksIFt3b3JrT3JkZXJzLCBmaWx0ZXJzXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoZmlsdGVyZWQubGVuZ3RoID09PSAwKSB7XG4gICAgICBzZXRTZWxlY3RlZElkKG51bGwpO1xuICAgICAgc2V0TW9iaWxlRGV0YWlsT3BlbihmYWxzZSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICghc2VsZWN0ZWRJZCAmJiBmaWx0ZXJlZC5sZW5ndGggPiAwKSB7XG4gICAgICBzZXRTZWxlY3RlZElkKGZpbHRlcmVkWzBdLl9pZCk7XG4gICAgfVxuICAgIGlmIChzZWxlY3RlZElkICYmIGZpbHRlcmVkLmxlbmd0aCA+IDAgJiYgIWZpbHRlcmVkLnNvbWUoKGl0ZW0pID0+IGl0ZW0uX2lkID09PSBzZWxlY3RlZElkKSkge1xuICAgICAgc2V0U2VsZWN0ZWRJZChmaWx0ZXJlZFswXS5faWQpO1xuICAgIH1cbiAgfSwgW2ZpbHRlcmVkLCBzZWxlY3RlZElkXSk7XG5cbiAgY29uc3QgcmVwb3NpdG9yaWVzID0gdXNlTWVtbyhcbiAgICAoKSA9PiBBcnJheS5mcm9tKG5ldyBTZXQoKHdvcmtPcmRlcnMgPz8gW10pLm1hcCgoaXRlbSkgPT4gaXRlbS5yZXBvc2l0b3J5KS5maWx0ZXIoQm9vbGVhbikpKS5zb3J0KCksXG4gICAgW3dvcmtPcmRlcnNdXG4gICk7XG4gIGNvbnN0IGFzc2lnbmVkQWdlbnRzID0gdXNlTWVtbyhcbiAgICAoKSA9PiBBcnJheS5mcm9tKG5ldyBTZXQoKHdvcmtPcmRlcnMgPz8gW10pLm1hcCgoaXRlbSkgPT4gaXRlbS5hc3NpZ25lZEFnZW50KS5maWx0ZXIoQm9vbGVhbikpKS5zb3J0KCksXG4gICAgW3dvcmtPcmRlcnNdXG4gICk7XG4gIGNvbnN0IHJlcXVlc3RvcnMgPSB1c2VNZW1vKFxuICAgICgpID0+IEFycmF5LmZyb20obmV3IFNldCgod29ya09yZGVycyA/PyBbXSkubWFwKChpdGVtKSA9PiBpdGVtLnJlcXVlc3RlZEJ5KS5maWx0ZXIoQm9vbGVhbikpKS5zb3J0KCksXG4gICAgW3dvcmtPcmRlcnNdXG4gICk7XG5cbiAgY29uc3QgY291bnRzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgY29uc3Qgcm93cyA9IHdvcmtPcmRlcnMgPz8gW107XG4gICAgcmV0dXJuIHtcbiAgICAgIHRvdGFsOiByb3dzLmxlbmd0aCxcbiAgICAgIGFjdGl2ZTogcm93cy5maWx0ZXIoKHJvdykgPT4gW1wiUkVBRFlcIiwgXCJESVNQQVRDSEVEXCIsIFwiSU5fUFJPR1JFU1NcIiwgXCJBV0FJVElOR19BUFBST1ZBTFwiLCBcIkFXQUlUSU5HX1ZFUklGSUNBVElPTlwiLCBcIlJFT1BFTkVEXCJdLmluY2x1ZGVzKHJvdy5zdGF0ZSkpLmxlbmd0aCxcbiAgICAgIGJsb2NrZWQ6IHJvd3MuZmlsdGVyKChyb3cpID0+IHJvdy5zdGF0ZSA9PT0gXCJCTE9DS0VEXCIpLmxlbmd0aCxcbiAgICAgIGF0dGVudGlvbjogcm93cy5maWx0ZXIoKHJvdykgPT4gISFyb3cucmVxdWlyZWRIdW1hbkFjdGlvbiB8fCBbXCJQRU5ESU5HXCIsIFwiUkVWSVNJT05fUkVRVUVTVEVEXCJdLmluY2x1ZGVzKHJvdy5hcHByb3ZhbFN0YXR1cykgfHwgW1wiRkFJTFwiLCBcIlNUQUxFXCJdLmluY2x1ZGVzKHJvdy52ZXJpZmljYXRpb25TdGF0dXMpKS5sZW5ndGgsXG4gICAgfTtcbiAgfSwgW3dvcmtPcmRlcnNdKTtcblxuICBjb25zdCBxdWlja0ZpbHRlckNvdW50cyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGNvbnN0IHJvd3MgPSB3b3JrT3JkZXJzID8/IFtdO1xuICAgIHJldHVybiBPYmplY3QuZnJvbUVudHJpZXMoXG4gICAgICBRVUlDS19GSUxURVJTLm1hcCgoZmlsdGVyKSA9PiBbZmlsdGVyLmlkLCBmaWx0ZXIuaWQgPT09IFwiYWxsXCIgPyByb3dzLmxlbmd0aCA6IGNvdW50QnlRdWlja0ZpbHRlcihyb3dzLCBmaWx0ZXIuaWQpXSlcbiAgICApIGFzIFJlY29yZDxXb3JrT3JkZXJRdWlja0ZpbHRlciwgbnVtYmVyPjtcbiAgfSwgW3dvcmtPcmRlcnNdKTtcblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVTZWVkKCkge1xuICAgIHNldFNlZWRpbmcodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHNlZWREZW1vKHt9KTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0U2VlZGluZyhmYWxzZSk7XG4gICAgfVxuICB9XG5cbiAgY29uc3QgY2FuRGlzcGF0Y2hTZWxlY3RlZCA9ICEhc2VsZWN0ZWQgJiYgW1wiUkVBRFlcIiwgXCJCTE9DS0VEXCIsIFwiRElTUEFUQ0hFRFwiLCBcIklOX1BST0dSRVNTXCIsIFwiUkVPUEVORURcIiwgXCJBV0FJVElOR19BUFBST1ZBTFwiLCBcIkFXQUlUSU5HX1ZFUklGSUNBVElPTlwiXS5pbmNsdWRlcyhzZWxlY3RlZC53b3JrT3JkZXIuc3RhdGUpXG4gICAgJiYgISFzZWxlY3RlZC53b3JrT3JkZXIud29ya2Zsb3dJZFxuICAgICYmIChzZWxlY3RlZC53b3JrT3JkZXIuYXBwcm92YWxTdGF0dXMgPT09IFwiQVBQUk9WRURcIiB8fCBzZWxlY3RlZC53b3JrT3JkZXIuYXBwcm92YWxTdGF0dXMgPT09IFwiQ09ORElUSU9OQUxcIiB8fCBzZWxlY3RlZC53b3JrT3JkZXIuYXBwcm92YWxTdGF0dXMgPT09IFwiTk9UX1JFUVVJUkVEXCIpXG4gICAgJiYgIXNlbGVjdGVkLmV4ZWN1dGlvblJ1bnMuc29tZSgocnVuKSA9PiBbXCJQRU5ESU5HXCIsIFwiUlVOTklOR1wiLCBcIlBBVVNFRFwiXS5pbmNsdWRlcyhydW4uc3RhdHVzKSk7XG5cbiAgY29uc3QgY2FuQWNjZXB0U2VsZWN0ZWQgPSAhIXNlbGVjdGVkXG4gICAgJiYgIVtcIkRPTkVcIiwgXCJTVVBFUlNFREVEXCIsIFwiQ0FOQ0VMRURcIl0uaW5jbHVkZXMoc2VsZWN0ZWQud29ya09yZGVyLnN0YXRlKVxuICAgICYmICFzZWxlY3RlZC5leGVjdXRpb25SdW5zLnNvbWUoKHJ1bikgPT4gW1wiUEVORElOR1wiLCBcIlJVTk5JTkdcIiwgXCJQQVVTRURcIl0uaW5jbHVkZXMocnVuLnN0YXR1cykpXG4gICAgJiYgc2VsZWN0ZWQuZXhlY3V0aW9uUnVuc1swXT8uc3RhdHVzID09PSBcIkNPTVBMRVRFRFwiXG4gICAgJiYgc2VsZWN0ZWQuYWNjZXB0YW5jZVN1bW1hcnk/LmVsaWdpYmxlO1xuXG4gIGNvbnN0IGxhdGVzdFJlY2VpcHRNYXAgPSB1c2VNZW1vKFxuICAgICgpID0+IGxhdGVzdEJ5Q3JpdGVyaW9uKChzZWxlY3RlZD8udmVyaWZpY2F0aW9uUmVjZWlwdHMgPz8gW10pLm1hcCgocmVjZWlwdCkgPT4gKHtcbiAgICAgIC4uLnJlY2VpcHQsXG4gICAgICByZWNvcmRlZEF0OiByZWNlaXB0LnJlY29yZGVkQXQgPz8gcmVjZWlwdC5fY3JlYXRpb25UaW1lID8/IDAsXG4gICAgfSkpKSxcbiAgICBbc2VsZWN0ZWRdXG4gICk7XG4gIGNvbnN0IHJldmlzaW9uU3BsaXQgPSB1c2VNZW1vKFxuICAgICgpID0+IHNwbGl0Q3VycmVudEFuZEhpc3RvcmljYWxSZXZpc2lvbnMoKHNlbGVjdGVkPy5yZXZpc2lvbnMgPz8gW10pIGFzIGFueVtdLCBzZWxlY3RlZD8ud29ya09yZGVyLmN1cnJlbnRSZXZpc2lvbklkKSxcbiAgICBbc2VsZWN0ZWRdXG4gICk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1mdWxsIG1pbi1oLTAgZmxleC1jb2wgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICA8UGFnZUhlYWRlclxuICAgICAgICBleWVicm93PVwiU29mdHdhcmUgZmFjdG9yeVwiXG4gICAgICAgIHRpdGxlPVwiV29yayBPcmRlcnNcIlxuICAgICAgICBkZXNjcmlwdGlvbj1cIlJlcXVlc3RlZCBvdXRjb21lcywgYWNjZXB0YW5jZSBjcml0ZXJpYSwgYW5kIGdvdmVybmVkIGV4ZWN1dGlvbiBpbiBvbmUgcXVldWUuXCJcbiAgICAgICAgaWNvbj17PENsaXBib2FyZExpc3QgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+fVxuICAgICAgICBhY3Rpb25zPXtcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgc2l6ZT1cInNtXCIgb25DbGljaz17aGFuZGxlU2VlZH0gZGlzYWJsZWQ9e3NlZWRpbmd9PlxuICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwibXItMS41IGgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgICAge3NlZWRpbmcgPyBcIlNlZWRpbmfigKZcIiA6IFwiU2VlZCBkZW1vXCJ9XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICBzZXRDcmVhdGVSZXF1ZXN0S2V5KGdsb2JhbFRoaXMuY3J5cHRvPy5yYW5kb21VVUlEPy4oKSA/PyBgd29yay1vcmRlci0ke0RhdGUubm93KCl9YCk7XG4gICAgICAgICAgICAgIHNldENyZWF0ZU9wZW4odHJ1ZSk7XG4gICAgICAgICAgICB9fT5cbiAgICAgICAgICAgICAgPFBsdXMgY2xhc3NOYW1lPVwibXItMS41IGgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgICAgTmV3IFdvcmtPcmRlclxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICAgIC8+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtMCBmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHAtNVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTMgbGc6Z3JpZC1jb2xzLTRcIj5cbiAgICAgICAgICA8U3RhdENhcmQgbGFiZWw9XCJXb3JrT3JkZXJzXCIgdmFsdWU9e2NvdW50cy50b3RhbH0gLz5cbiAgICAgICAgICA8U3RhdENhcmQgbGFiZWw9XCJBY3RpdmVcIiB2YWx1ZT17Y291bnRzLmFjdGl2ZX0gLz5cbiAgICAgICAgICA8U3RhdENhcmQgbGFiZWw9XCJCbG9ja2VkXCIgdmFsdWU9e2NvdW50cy5ibG9ja2VkfSB0b25lPXtjb3VudHMuYmxvY2tlZCA+IDAgPyBcImJhZFwiIDogXCJkZWZhdWx0XCJ9IC8+XG4gICAgICAgICAgPFN0YXRDYXJkIGxhYmVsPVwiTmVlZHMgYXR0ZW50aW9uXCIgdmFsdWU9e2NvdW50cy5hdHRlbnRpb259IHRvbmU9e2NvdW50cy5hdHRlbnRpb24gPiAwID8gXCJ3YXJuXCIgOiBcImdvb2RcIn0gLz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IGZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAge1FVSUNLX0ZJTFRFUlMubWFwKChmaWx0ZXIpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZSA9IGZpbHRlcnMucXVpY2tGaWx0ZXIgPT09IGZpbHRlci5pZDtcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICBrZXk9e2ZpbHRlci5pZH1cbiAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9e2FjdGl2ZSA/IFwiZGVmYXVsdFwiIDogXCJvdXRsaW5lXCJ9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RmlsdGVycygoY3VycmVudCkgPT4gKHsgLi4uY3VycmVudCwgcXVpY2tGaWx0ZXI6IGZpbHRlci5pZCB9KSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2FwLTJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge2ZpbHRlci5sYWJlbH1cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctYmFja2dyb3VuZC8yMCBweC0xLjUgcHktMC41IHRleHQtWzExcHhdIGxlYWRpbmctbm9uZVwiPlxuICAgICAgICAgICAgICAgICAge3F1aWNrRmlsdGVyQ291bnRzW2ZpbHRlci5pZF0gPz8gMH1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9KX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IGdyaWQgZ2FwLTMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLVt2YXIoLS1wYW5lbC1saW5lKV0gYmctY2FyZC80MCBwLTQgbGc6Z3JpZC1jb2xzLTZcIj5cbiAgICAgICAgICA8RmlsdGVyU2VsZWN0IGxhYmVsPVwiUmVwb3NpdG9yeVwiIHZhbHVlPXtmaWx0ZXJzLnJlcG9zaXRvcnl9IG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEZpbHRlcnMoKGN1cnJlbnQpID0+ICh7IC4uLmN1cnJlbnQsIHJlcG9zaXRvcnk6IHZhbHVlIH0pKX0gb3B0aW9ucz17cmVwb3NpdG9yaWVzfSAvPlxuICAgICAgICAgIDxGaWx0ZXJTZWxlY3QgbGFiZWw9XCJTdGF0ZVwiIHZhbHVlPXtmaWx0ZXJzLnN0YXRlfSBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRGaWx0ZXJzKChjdXJyZW50KSA9PiAoeyAuLi5jdXJyZW50LCBzdGF0ZTogdmFsdWUgfSkpfSBvcHRpb25zPXtbXCJSRUFEWVwiLCBcIkRJU1BBVENIRURcIiwgXCJJTl9QUk9HUkVTU1wiLCBcIkJMT0NLRURcIiwgXCJBV0FJVElOR19BUFBST1ZBTFwiLCBcIkFXQUlUSU5HX1ZFUklGSUNBVElPTlwiLCBcIlJFT1BFTkVEXCIsIFwiRE9ORVwiLCBcIlNVUEVSU0VERURcIl19IC8+XG4gICAgICAgICAgPEZpbHRlclNlbGVjdCBsYWJlbD1cIlJpc2tcIiB2YWx1ZT17ZmlsdGVycy5yaXNrTGV2ZWx9IG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEZpbHRlcnMoKGN1cnJlbnQpID0+ICh7IC4uLmN1cnJlbnQsIHJpc2tMZXZlbDogdmFsdWUgfSkpfSBvcHRpb25zPXtbXCJMT1dcIiwgXCJNRURJVU1cIiwgXCJISUdIXCIsIFwiQ1JJVElDQUxcIl19IC8+XG4gICAgICAgICAgPEZpbHRlclNlbGVjdCBsYWJlbD1cIkFzc2lnbmVkXCIgdmFsdWU9e2ZpbHRlcnMuYXNzaWduZWRBZ2VudH0gb25DaGFuZ2U9eyh2YWx1ZSkgPT4gc2V0RmlsdGVycygoY3VycmVudCkgPT4gKHsgLi4uY3VycmVudCwgYXNzaWduZWRBZ2VudDogdmFsdWUgfSkpfSBvcHRpb25zPXthc3NpZ25lZEFnZW50c30gLz5cbiAgICAgICAgICA8RmlsdGVyU2VsZWN0IGxhYmVsPVwiUmVxdWVzdGVkIGJ5XCIgdmFsdWU9e2ZpbHRlcnMucmVxdWVzdGVkQnl9IG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEZpbHRlcnMoKGN1cnJlbnQpID0+ICh7IC4uLmN1cnJlbnQsIHJlcXVlc3RlZEJ5OiB2YWx1ZSB9KSl9IG9wdGlvbnM9e3JlcXVlc3RvcnN9IC8+XG4gICAgICAgICAgPEZpbHRlclNlbGVjdCBsYWJlbD1cIlZlcmlmaWNhdGlvblwiIHZhbHVlPXtmaWx0ZXJzLnZlcmlmaWNhdGlvblN0YXR1c30gb25DaGFuZ2U9eyh2YWx1ZSkgPT4gc2V0RmlsdGVycygoY3VycmVudCkgPT4gKHsgLi4uY3VycmVudCwgdmVyaWZpY2F0aW9uU3RhdHVzOiB2YWx1ZSB9KSl9IG9wdGlvbnM9e1tcIlBFTkRJTkdcIiwgXCJQQVNTXCIsIFwiRkFJTFwiLCBcIldBSVZFRFwiLCBcIlNUQUxFXCJdfSAvPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZ3JpZCBnYXAtNCB4bDpncmlkLWNvbHMtW21pbm1heCgwLDAuOTVmcilfbWlubWF4KDM2MHB4LDEuMDVmcildXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Ake21vYmlsZURldGFpbE9wZW4gPyBcImhpZGRlbiB4bDpibG9ja1wiIDogXCJibG9ja1wifSBzcGFjZS15LTNgfT5cbiAgICAgICAgICAgIHtmaWx0ZXJlZC5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtOCB0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgIE5vIHdvcmsgb3JkZXJzIG1hdGNoIHRoZSBjdXJyZW50IGZpbHRlcnMuXG4gICAgICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIGZpbHRlcmVkLm1hcCgoaXRlbSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHNlbGVjdGVkUm93ID0gaXRlbS5faWQgPT09IHNlbGVjdGVkSWQ7XG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLl9pZH1cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZElkKGl0ZW0uX2lkKTtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRNb2JpbGVEZXRhaWxPcGVuKHRydWUpO1xuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgJHtpdGVtLnRpdGxlfSDigJQgbmV4dCBhY3Rpb246ICR7ZGVyaXZlTmV4dEFjdGlvbihpdGVtKX1gfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgcC00IHRleHQtbGVmdCB0cmFuc2l0aW9uLWNvbG9ycyAke3NlbGVjdGVkUm93ID8gXCJib3JkZXItcmVnaXN0cnktYWNjZW50LzQwIGJnLXJlZ2lzdHJ5LWFjY2VudC1zb2Z0XCIgOiBcImJvcmRlci1bdmFyKC0tcGFuZWwtbGluZSldIGJnLWNhcmQvNDAgaG92ZXI6Ym9yZGVyLXJlZ2lzdHJ5LWFjY2VudC8yMFwifWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmRcIj57aXRlbS50aXRsZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBsaW5lLWNsYW1wLTJcIj57aXRlbS5kZXNpcmVkT3V0Y29tZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cIm91dGxpbmVcIiBjbGFzc05hbWU9e1JJU0tfU1RZTEVTW2l0ZW0ucmlza0xldmVsXSA/PyBcIlwifT57aXRlbS5yaXNrTGV2ZWx9PC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCIgY2xhc3NOYW1lPXtTVEFURV9TVFlMRVNbaXRlbS5zdGF0ZV0gPz8gXCJcIn0+e3ByZXR0eUxhYmVsKGl0ZW0uc3RhdGUpfTwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCI+e2l0ZW0ucmVwb3NpdG9yeSA/PyBcIk5vIHJlcG9cIn08L0JhZGdlPlxuICAgICAgICAgICAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwib3V0bGluZVwiPldvcmtmbG93OiB7aXRlbS53b3JrZmxvd0lkID8/IFwi4oCUXCJ9PC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cIm91dGxpbmVcIj5WZXJpZmljYXRpb246IHtpdGVtLnZlcmlmaWNhdGlvblN0YXR1c308L0JhZGdlPlxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLm1ldGFkYXRhPy5hdXRvbWF0aW9uRGVmaW5pdGlvbklkID8gPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCIgY2xhc3NOYW1lPVwiYm9yZGVyLXJlZ2lzdHJ5LWFjY2VudC8zMCB0ZXh0LXJlZ2lzdHJ5LWFjY2VudFwiPkF1dG9tYXRpb24gcmV2aWV3IGdhdGU8L0JhZGdlPiA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubGF0ZXN0RXhlY3V0aW9uUnVuID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIFJ1bjoge2l0ZW0ubGF0ZXN0RXhlY3V0aW9uUnVuLnN0YXR1c30gwrcge2l0ZW0ubGF0ZXN0RXhlY3V0aW9uUnVuLndvcmtmbG93SWR9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgICAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZ3JpZCBnYXAtMiB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtZDpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWZvcmVncm91bmQvODBcIj5Bc3NpZ25lZDo8L3NwYW4+IHtpdGVtLmFzc2lnbmVkQWdlbnQgPz8gaXRlbS5hc3NpZ25lZFNxdWFkID8/IFwiVW5hc3NpZ25lZFwifVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWZvcmVncm91bmQvODBcIj5SZXF1ZXN0b3I6PC9zcGFuPiB7aXRlbS5yZXF1ZXN0ZWRCeSA/PyBcIlVua25vd25cIn1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1mb3JlZ3JvdW5kLzgwXCI+TmV4dCBhY3Rpb246PC9zcGFuPiB7ZGVyaXZlTmV4dEFjdGlvbihpdGVtKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTIgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZC84MFwiPkF0dGVudGlvbjo8L3NwYW4+IHtzdW1tYXJpemVSZXF1aXJlZEF0dGVudGlvbihpdGVtKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT17YCR7bW9iaWxlRGV0YWlsT3BlbiA/IFwiYmxvY2tcIiA6IFwiaGlkZGVuIHhsOmJsb2NrXCJ9IG1pbi1oLVs0MjBweF0gcC01YH0+XG4gICAgICAgICAgICB7IXNlbGVjdGVkID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+U2VsZWN0IGEgd29yayBvcmRlciB0byBpbnNwZWN0IHJlcXVlc3RlZCBvdXRjb21lLCBjcml0ZXJpYSwgYW5kIGxpbmtlZCBleGVjdXRpb24uPC9kaXY+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNVwiPlxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ4bDpoaWRkZW5cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TW9iaWxlRGV0YWlsT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPEFycm93TGVmdCBjbGFzc05hbWU9XCJtci0xLjUgaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgQmFjayB0byB3b3JrIG9yZGVyc1xuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRleHQtZm9yZWdyb3VuZFwiPntzZWxlY3RlZC53b3JrT3JkZXIudGl0bGV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e3NlbGVjdGVkLndvcmtPcmRlci5yZXBvc2l0b3J5ID8/IFwiTm8gcmVwb3NpdG9yeSBkZWNsYXJlZFwifTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwib3V0bGluZVwiIGNsYXNzTmFtZT17UklTS19TVFlMRVNbc2VsZWN0ZWQud29ya09yZGVyLnJpc2tMZXZlbF0gPz8gXCJcIn0+e3NlbGVjdGVkLndvcmtPcmRlci5yaXNrTGV2ZWx9PC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cIm91dGxpbmVcIiBjbGFzc05hbWU9e1NUQVRFX1NUWUxFU1tzZWxlY3RlZC53b3JrT3JkZXIuc3RhdGVdID8/IFwiXCJ9PntwcmV0dHlMYWJlbChzZWxlY3RlZC53b3JrT3JkZXIuc3RhdGUpfTwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9eygpID0+IHsgc2V0R292ZXJuYW5jZUVycm9yKG51bGwpOyBzZXRSZXZpc2lvbk9wZW4odHJ1ZSk7IH19PlJlcXVlc3QgcmV2aXNpb248L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9eygpID0+IHsgc2V0R292ZXJuYW5jZUVycm9yKG51bGwpOyBzZXRSZW9wZW5PcGVuKHRydWUpOyB9fSBkaXNhYmxlZD17W1wiU1VQRVJTRURFRFwiLCBcIkNBTkNFTEVEXCJdLmluY2x1ZGVzKHNlbGVjdGVkLndvcmtPcmRlci5zdGF0ZSl9PlJlb3BlbjwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17YXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRHb3Zlcm5hbmNlRXJyb3IobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBhd2FpdCBleHBpcmVHb3Zlcm5hbmNlUmVjb3Jkcyh7IHdvcmtPcmRlcklkOiBzZWxlY3RlZC53b3JrT3JkZXIuX2lkIH0pO1xuICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0R292ZXJuYW5jZUVycm9yKGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBcIkZhaWxlZCB0byBleHBpcmUgZ292ZXJuYW5jZSByZWNvcmRzXCIpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfX0+UmVmcmVzaCBnb3Zlcm5hbmNlPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cIm91dGxpbmVcIiBvbkNsaWNrPXsoKSA9PiB7IHNldEdvdmVybmFuY2VFcnJvcihudWxsKTsgc2V0U3VwZXJzZWRlT3Blbih0cnVlKTsgfX0gZGlzYWJsZWQ9e3NlbGVjdGVkLndvcmtPcmRlci5zdGF0ZSA9PT0gXCJTVVBFUlNFREVEXCJ9PlN1cGVyc2VkZTwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8U2VjdGlvbiB0aXRsZT1cIk91dGNvbWVcIj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtZm9yZWdyb3VuZC84NVwiPntzZWxlY3RlZC53b3JrT3JkZXIuZGVzaXJlZE91dGNvbWV9PC9wPlxuICAgICAgICAgICAgICAgICAge3NlbGVjdGVkLndvcmtPcmRlci5jb250ZXh0ID8gKFxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntzZWxlY3RlZC53b3JrT3JkZXIuY29udGV4dH08L3A+XG4gICAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgICAgICA8L1NlY3Rpb24+XG5cbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWQud29ya09yZGVyLm1ldGFkYXRhPy5hdXRvbWF0aW9uRGVmaW5pdGlvbklkID8gKFxuICAgICAgICAgICAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJBdXRvbWF0aW9uIGxpbmVhZ2VcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRsIGNsYXNzTmFtZT1cImdyaWQgZ2FwLTMgdGV4dC1zbSBtZDpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxNZXRhUm93IGxhYmVsPVwiQXV0b21hdGlvblwiIHZhbHVlPXtzZWxlY3RlZC53b3JrT3JkZXIubWV0YWRhdGEuYXV0b21hdGlvbkRlZmluaXRpb25JZH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8TWV0YVJvdyBsYWJlbD1cIldvcmtmbG93IHZlcnNpb25cIiB2YWx1ZT17c2VsZWN0ZWQud29ya09yZGVyLm1ldGFkYXRhLmF1dG9tYXRpb25Xb3JrZmxvd1ZlcnNpb259IC8+XG4gICAgICAgICAgICAgICAgICAgICAgPE1ldGFSb3cgbGFiZWw9XCJDYWRlbmNlXCIgdmFsdWU9e3NlbGVjdGVkLndvcmtPcmRlci5tZXRhZGF0YS5hdXRvbWF0aW9uQ2FkZW5jZT8uY3Jvbn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8TWV0YVJvdyBsYWJlbD1cIlNjb3BlXCIgdmFsdWU9e3NlbGVjdGVkLndvcmtPcmRlci5tZXRhZGF0YS5hdXRvbWF0aW9uU2NvcGV9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGw+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICBUaGlzIHJlYWQtb25seSBXb3JrT3JkZXIgcmVxdWlyZXMgbm9ybWFsIGFwcHJvdmFsIGFuZCBleHBsaWNpdCBkaXNwYXRjaC4gVGhlIG9yaWdpbmF0aW5nIEF1dG9tYXRpb24gY2Fubm90IGFwcHJvdmUgaXQuXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvU2VjdGlvbj5cbiAgICAgICAgICAgICAgICApIDogbnVsbH1cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNCBtZDpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgICAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJFeGVjdXRpb24gc2V0dXBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRsIGNsYXNzTmFtZT1cInNwYWNlLXktMiB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPE1ldGFSb3cgbGFiZWw9XCJCcmFuY2ggLyB3b3JrdHJlZSBzdHJhdGVneVwiIHZhbHVlPXtzZWxlY3RlZC53b3JrT3JkZXIuYnJhbmNoU3RyYXRlZ3l9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgPE1ldGFSb3cgbGFiZWw9XCJXb3JrZmxvd1wiIHZhbHVlPXtzZWxlY3RlZC53b3JrT3JkZXIud29ya2Zsb3dJZH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8TWV0YVJvdyBsYWJlbD1cIkFzc2lnbmVkXCIgdmFsdWU9e3NlbGVjdGVkLndvcmtPcmRlci5hc3NpZ25lZEFnZW50ID8/IHNlbGVjdGVkLndvcmtPcmRlci5hc3NpZ25lZFNxdWFkfSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxNZXRhUm93IGxhYmVsPVwiUmVxdWVzdGVkIGJ5XCIgdmFsdWU9e3NlbGVjdGVkLndvcmtPcmRlci5yZXF1ZXN0ZWRCeX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8TWV0YVJvdyBsYWJlbD1cIkFwcHJvdmFsXCIgdmFsdWU9e3NlbGVjdGVkLndvcmtPcmRlci5hcHByb3ZhbFN0YXR1c30gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8TWV0YVJvdyBsYWJlbD1cIlZlcmlmaWNhdGlvblwiIHZhbHVlPXtzZWxlY3RlZC53b3JrT3JkZXIudmVyaWZpY2F0aW9uU3RhdHVzfSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2RsPlxuICAgICAgICAgICAgICAgICAgPC9TZWN0aW9uPlxuICAgICAgICAgICAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJSZXF1aXJlZCBhdHRlbnRpb25cIj5cbiAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkLndvcmtPcmRlci5yZXF1aXJlZEh1bWFuQWN0aW9uID8gKFxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1hbWJlci0xMDBcIj57c2VsZWN0ZWQud29ya09yZGVyLnJlcXVpcmVkSHVtYW5BY3Rpb259PC9wPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+Tm8gYWN0aXZlIGh1bWFuIGFjdGlvbiByZWNvcmRlZC48L3A+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZC53b3JrT3JkZXIuYmxvY2tpbmdJc3N1ZSA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXJlZC01MDAvMjAgYmctcmVkLTUwMC81IHB4LTMgcHktMiB0ZXh0LXNtIHRleHQtcmVkLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFRyaWFuZ2xlQWxlcnQgY2xhc3NOYW1lPVwibXItMiBpbmxpbmUgaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWQud29ya09yZGVyLmJsb2NraW5nSXNzdWV9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgICAgICAgPC9TZWN0aW9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJBY2NlcHRhbmNlIHJlYWRpbmVzc1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0zIG1kOmdyaWQtY29scy0yIHhsOmdyaWQtY29scy00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjE0ZW1dIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPkFwcHJvdmFsIHN0YXR1czwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+e3NlbGVjdGVkLndvcmtPcmRlci5hcHByb3ZhbFN0YXR1c308L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHVwcGVyY2FzZSB0cmFja2luZy1bMC4xNGVtXSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5WZXJpZmljYXRpb24gc3RhdHVzPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIHRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWZvcmVncm91bmRcIj57c2VsZWN0ZWQud29ya09yZGVyLnZlcmlmaWNhdGlvblN0YXR1c308L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHVwcGVyY2FzZSB0cmFja2luZy1bMC4xNGVtXSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5NaXNzaW5nIGFwcHJvdmFsczwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1hbWJlci0zMDBcIj57c2VsZWN0ZWQuYWNjZXB0YW5jZVN1bW1hcnk/Lm1pc3NpbmdBcHByb3ZhbFR5cGVzPy5sZW5ndGggPz8gMH08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHVwcGVyY2FzZSB0cmFja2luZy1bMC4xNGVtXSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5Dcml0ZXJpYSBibG9ja2VkPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIHRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXJlZC0zMDBcIj57KHNlbGVjdGVkLmFjY2VwdGFuY2VTdW1tYXJ5Py5mYWlsZWRDcml0ZXJpYUlkcz8ubGVuZ3RoID8/IDApICsgKHNlbGVjdGVkLmFjY2VwdGFuY2VTdW1tYXJ5Py5zdGFsZUNyaXRlcmlhSWRzPy5sZW5ndGggPz8gMCkgKyAoc2VsZWN0ZWQuYWNjZXB0YW5jZVN1bW1hcnk/Lm1pc3NpbmdDcml0ZXJpYUlkcz8ubGVuZ3RoID8/IDApfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1bdmFyKC0tcGFuZWwtbGluZSldIGJnLWJhY2tncm91bmQvNDAgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mb3JlZ3JvdW5kXCI+V2h5IHRoaXMgV29ya09yZGVyIGlzIGJsb2NrZWQgZnJvbSBhY2NlcHRhbmNlPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9eygpID0+IHsgc2V0R292ZXJuYW5jZUVycm9yKG51bGwpOyBzZXRBcHByb3ZhbE9wZW4odHJ1ZSk7IH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwibXItMS41IGgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgUmVxdWVzdCBhcHByb3ZhbFxuICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17KCkgPT4geyBzZXRHb3Zlcm5hbmNlRXJyb3IobnVsbCk7IHNldFJlY2VpcHRPcGVuKHRydWUpOyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgUmVjb3JkIHJlY2VpcHRcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXthc3luYyAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEdvdmVybmFuY2VFcnJvcihudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjY2VwdGluZ0lkKHNlbGVjdGVkLndvcmtPcmRlci5faWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXdhaXQgYWNjZXB0V29ya09yZGVyKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd29ya09yZGVySWQ6IHNlbGVjdGVkLndvcmtPcmRlci5faWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdG9yVHlwZTogXCJIVU1BTlwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3RvcklkOiBcIm9wZXJhdG9yXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkZW1wb3RlbmN5S2V5OiBgdWktYWNjZXB0OiR7c2VsZWN0ZWQud29ya09yZGVyLl9pZH06JHtzZWxlY3RlZC53b3JrT3JkZXIudXBkYXRlZEF0fWAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEdvdmVybmFuY2VFcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogXCJBY2NlcHRhbmNlIGZhaWxlZFwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QWNjZXB0aW5nSWQobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWNhbkFjY2VwdFNlbGVjdGVkIHx8IGFjY2VwdGluZ0lkID09PSBzZWxlY3RlZC53b3JrT3JkZXIuX2lkfVxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7YWNjZXB0aW5nSWQgPT09IHNlbGVjdGVkLndvcmtPcmRlci5faWQgPyBcIkFjY2VwdGluZ+KAplwiIDogXCJBY2NlcHQgV29ya09yZGVyXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHtnb3Zlcm5hbmNlRXJyb3IgPyA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgdGV4dC14cyB0ZXh0LXJlZC0zMDBcIj57Z292ZXJuYW5jZUVycm9yfTwvZGl2PiA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgIHsoc2VsZWN0ZWQuYWNjZXB0YW5jZVN1bW1hcnk/LmJsb2NraW5nUmVhc29ucz8ubGVuZ3RoID8/IDApID4gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwibGlzdC1kaXNjIHNwYWNlLXktMSBwbC01IHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWQuYWNjZXB0YW5jZVN1bW1hcnkuYmxvY2tpbmdSZWFzb25zLm1hcCgocmVhc29uLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtgJHtzZWxlY3RlZC53b3JrT3JkZXIuX2lkfS1ibG9ja2VyLSR7aW5kZXh9YH0+e3JlYXNvbn08L2xpPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZW1lcmFsZC0zMDBcIj5BbGwgcmVxdWlyZWQgYXBwcm92YWxzIGFuZCB2ZXJpZmljYXRpb24gcmVjZWlwdHMgYXJlIHByZXNlbnQuIEV4cGxpY2l0IGFjY2VwdGFuY2UgaXMgbm93IGFsbG93ZWQuPC9wPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9TZWN0aW9uPlxuXG4gICAgICAgICAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJBcHByb3ZhbCBkZWNpc2lvbnNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZC5hcHByb3ZhbERlY2lzaW9ucz8ubGVuZ3RoID8gc2VsZWN0ZWQuYXBwcm92YWxEZWNpc2lvbnMubWFwKChhcHByb3ZhbCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXthcHByb3ZhbC5faWR9IGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1bdmFyKC0tcGFuZWwtbGluZSldIGJnLWJhY2tncm91bmQvMzAgcHgtMyBweS0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZm9yZWdyb3VuZFwiPnthcHByb3ZhbC5hcHByb3ZhbFR5cGV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e2FwcHJvdmFsLnJlcXVlc3RlZEFjdGlvbn08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwib3V0bGluZVwiPnthcHByb3ZhbC5zdGF0dXN9PC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIGdyaWQgZ2FwLTIgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmQgbWQ6Z3JpZC1jb2xzLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5SaXNrOiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWZvcmVncm91bmQvODVcIj57YXBwcm92YWwucmlza0xldmVsfTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5SZXF1ZXN0ZWQgYnk6IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZC84NVwiPnthcHByb3ZhbC5yZXF1ZXN0ZWRCeSA/PyBcIuKAlFwifTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5BcHByb3ZlcjogPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1mb3JlZ3JvdW5kLzg1XCI+e2FwcHJvdmFsLmFwcHJvdmVyID8/IFwi4oCUXCJ9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PkRlY2lkZWQ6IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZC84NVwiPnthcHByb3ZhbC5kZWNpZGVkQXQgPyBuZXcgRGF0ZShhcHByb3ZhbC5kZWNpZGVkQXQpLnRvTG9jYWxlU3RyaW5nKCkgOiBcIuKAlFwifTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAge2FwcHJvdmFsLnJlYXNvbiA/IDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlJlYXNvbjoge2FwcHJvdmFsLnJlYXNvbn08L2Rpdj4gOiBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAge2FwcHJvdmFsLmNvbmRpdGlvbnM/Lmxlbmd0aCA/IDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXhzIHRleHQtcmVnaXN0cnktYWNjZW50XCI+Q29uZGl0aW9uczoge2FwcHJvdmFsLmNvbmRpdGlvbnMuam9pbihcIjsgXCIpfTwvZGl2PiA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkpIDogKFxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+Tm8gYXBwcm92YWwgZGVjaXNpb25zIHJlY29yZGVkIHlldC48L3A+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L1NlY3Rpb24+XG5cbiAgICAgICAgICAgICAgICA8U2VjdGlvbiB0aXRsZT1cIkdvdmVybmFuY2Ugc3RhdHVzXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTMgbWQ6Z3JpZC1jb2xzLTIgeGw6Z3JpZC1jb2xzLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMTRlbV0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+Q3VycmVudCByZXZpc2lvbjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+cntzZWxlY3RlZC53b3JrT3JkZXIuY3VycmVudFJldmlzaW9uTnVtYmVyID8/IDF9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMTRlbV0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+RXhwaXJpbmcgYXBwcm92YWxzPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIHRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWFtYmVyLTMwMFwiPntzZWxlY3RlZC5nb3Zlcm5hbmNlU3RhdHVzPy5leHBpcmluZ0FwcHJvdmFscz8ubGVuZ3RoID8/IDB9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMTRlbV0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+RXhwaXJlZCBhcHByb3ZhbHM8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtcmVkLTMwMFwiPntzZWxlY3RlZC5nb3Zlcm5hbmNlU3RhdHVzPy5leHBpcmVkQXBwcm92YWxzPy5sZW5ndGggPz8gMH08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHVwcGVyY2FzZSB0cmFja2luZy1bMC4xNGVtXSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5TdGFsZSByZWNlaXB0czwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1yZWQtMzAwXCI+e3NlbGVjdGVkLmdvdmVybmFuY2VTdGF0dXM/LnN0YWxlUmVjZWlwdHM/Lmxlbmd0aCA/PyAwfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItW3ZhcigtLXBhbmVsLWxpbmUpXSBiZy1iYWNrZ3JvdW5kLzMwIHAtNCB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlJlcXVpcmVkIHJlYXBwcm92YWw6IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZC84NVwiPntzZWxlY3RlZC5nb3Zlcm5hbmNlU3RhdHVzPy5yZXF1aXJlZFJlYXBwcm92YWwgPyBcIlllc1wiIDogXCJOb1wifTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xXCI+UmVxdWlyZWQgcmV2ZXJpZmljYXRpb246IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZC84NVwiPntzZWxlY3RlZC5nb3Zlcm5hbmNlU3RhdHVzPy5yZXF1aXJlZFJldmVyaWZpY2F0aW9uID8gXCJZZXNcIiA6IFwiTm9cIn08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMVwiPkxhdGVzdCBhY2NlcHRlZCByZXZpc2lvbjogPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1mb3JlZ3JvdW5kLzg1XCI+e3NlbGVjdGVkLmdvdmVybmFuY2VTdGF0dXM/LmFjY2VwdGVkUmV2aXNpb25OdW1iZXIgPyBgciR7c2VsZWN0ZWQuZ292ZXJuYW5jZVN0YXR1cy5hY2NlcHRlZFJldmlzaW9uTnVtYmVyfWAgOiBcIuKAlFwifTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yXCI+QmxvY2tpbmcgcmVhc29uOiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWZvcmVncm91bmQvODVcIj57c2VsZWN0ZWQuZ292ZXJuYW5jZVN0YXR1cz8uYmxvY2tpbmdSZWFzb25zPy5bMF0gPz8gXCLigJRcIn08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L1NlY3Rpb24+XG5cbiAgICAgICAgICAgICAgICA8U2VjdGlvbiB0aXRsZT1cIlJldmlzaW9uIGhpc3RvcnlcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgIHtyZXZpc2lvblNwbGl0LmN1cnJlbnQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItcmVnaXN0cnktYWNjZW50LzMwIGJnLXJlZ2lzdHJ5LWFjY2VudC1zb2Z0IHB4LTMgcHktM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mb3JlZ3JvdW5kXCI+Q3VycmVudCByZXZpc2lvbiBye3JldmlzaW9uU3BsaXQuY3VycmVudC5yZXZpc2lvbk51bWJlcn08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57cmV2aXNpb25TcGxpdC5jdXJyZW50LmNoYW5nZVN1bW1hcnl9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCI+e3JldmlzaW9uU3BsaXQuY3VycmVudC5zdGF0dXN9PC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmV2aXNpb25TcGxpdC5jdXJyZW50LnN0YXR1cyA9PT0gXCJQRU5ESU5HX0FQUFJPVkFMXCIgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17YXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRHb3Zlcm5hbmNlRXJyb3IobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRSZXZpc2luZ0lkKHJldmlzaW9uU3BsaXQuY3VycmVudC5faWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXdhaXQgYXBwcm92ZVdvcmtPcmRlclJldmlzaW9uKHsgd29ya09yZGVyUmV2aXNpb25JZDogcmV2aXNpb25TcGxpdC5jdXJyZW50Ll9pZCBhcyBJZDxcIndvcmtPcmRlclJldmlzaW9uc1wiPiwgYXBwcm92ZWRCeTogXCJvcGVyYXRvclwiIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0R292ZXJuYW5jZUVycm9yKGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBcIkZhaWxlZCB0byBhcHByb3ZlIHJldmlzaW9uXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRSZXZpc2luZ0lkKG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3JldmlzaW5nSWQgPT09IHJldmlzaW9uU3BsaXQuY3VycmVudC5faWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZXZpc2luZ0lkID09PSByZXZpc2lvblNwbGl0LmN1cnJlbnQuX2lkID8gXCJBcHBseWluZ+KAplwiIDogXCJBcHByb3ZlICYgYXBwbHlcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e3N1bW1hcml6ZVJldmlzaW9uRWZmZWN0cyhyZXZpc2lvblNwbGl0LmN1cnJlbnQpfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgICAgICAgICAge3JldmlzaW9uU3BsaXQuaGlzdG9yaWNhbC5sZW5ndGggPyByZXZpc2lvblNwbGl0Lmhpc3RvcmljYWwubWFwKChyZXZpc2lvbjogYW55KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e3JldmlzaW9uLl9pZH0gY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLVt2YXIoLS1wYW5lbC1saW5lKV0gYmctYmFja2dyb3VuZC8zMCBweC0zIHB5LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZm9yZWdyb3VuZFwiPkhpc3RvcmljYWwgcmV2aXNpb24gcntyZXZpc2lvbi5yZXZpc2lvbk51bWJlcn08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57cmV2aXNpb24uY2hhbmdlU3VtbWFyeX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cIm91dGxpbmVcIj57cmV2aXNpb24uc3RhdHVzfTwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3JldmlzaW9uLnN0YXR1cyA9PT0gXCJQRU5ESU5HX0FQUFJPVkFMXCIgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17YXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRHb3Zlcm5hbmNlRXJyb3IobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRSZXZpc2luZ0lkKHJldmlzaW9uLl9pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhd2FpdCBhcHByb3ZlV29ya09yZGVyUmV2aXNpb24oeyB3b3JrT3JkZXJSZXZpc2lvbklkOiByZXZpc2lvbi5faWQgYXMgSWQ8XCJ3b3JrT3JkZXJSZXZpc2lvbnNcIj4sIGFwcHJvdmVkQnk6IFwib3BlcmF0b3JcIiB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEdvdmVybmFuY2VFcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogXCJGYWlsZWQgdG8gYXBwcm92ZSByZXZpc2lvblwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UmV2aXNpbmdJZChudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtyZXZpc2luZ0lkID09PSByZXZpc2lvbi5faWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZXZpc2luZ0lkID09PSByZXZpc2lvbi5faWQgPyBcIkFwcGx5aW5n4oCmXCIgOiBcIkFwcHJvdmUgJiBhcHBseVwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5DaGFuZ2VkOiB7cmV2aXNpb24uY2hhbmdlZEZpZWxkcy5qb2luKFwiLCBcIikgfHwgXCLigJRcIn08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPkltcGFjdDoge3N1bW1hcml6ZVJldmlzaW9uRWZmZWN0cyhyZXZpc2lvbil9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5BY3Rvcjoge3JldmlzaW9uLmFwcHJvdmVkQnkgPz8gcmV2aXNpb24ucmVxdWVzdGVkQnkgPz8gXCLigJRcIn0gwrcge3JldmlzaW9uLmVmZmVjdGl2ZUF0ID8gbmV3IERhdGUocmV2aXNpb24uZWZmZWN0aXZlQXQpLnRvTG9jYWxlU3RyaW5nKCkgOiBuZXcgRGF0ZShyZXZpc2lvbi5jcmVhdGVkQXQpLnRvTG9jYWxlU3RyaW5nKCl9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkpIDogKFxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+Tm8gaGlzdG9yaWNhbCByZXZpc2lvbnMgeWV0LjwvcD5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvU2VjdGlvbj5cblxuICAgICAgICAgICAgICAgIDxTZWN0aW9uIHRpdGxlPVwiUmVvcGVuIGFuZCByZXBsYWNlbWVudCBsaW5lYWdlXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlByaW9yIGFjY2VwdGVkIHJldmlzaW9uOiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWZvcmVncm91bmQvODVcIj57c2VsZWN0ZWQuZ292ZXJuYW5jZVN0YXR1cz8ubGF0ZXN0QWNjZXB0ZWRSZXZpc2lvbiA/IGByJHtzZWxlY3RlZC5nb3Zlcm5hbmNlU3RhdHVzLmxhdGVzdEFjY2VwdGVkUmV2aXNpb24ucmV2aXNpb25OdW1iZXJ9YCA6IFwi4oCUXCJ9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlJlb3BlbiByZWFzb246IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZC84NVwiPntzZWxlY3RlZC5yZW9wZW5EZWNpc2lvbnM/LlswXT8ucmVhc29uID8/IFwi4oCUXCJ9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlNvdXJjZSBkZWZlY3QgLyBpc3N1ZTogPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1mb3JlZ3JvdW5kLzg1XCI+e3NlbGVjdGVkLnJlb3BlbkRlY2lzaW9ucz8uWzBdPy5zb3VyY2VJc3N1ZU9yRGVmZWN0ID8/IFwi4oCUXCJ9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PkludmFsaWRhdGVkIGV2aWRlbmNlOiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWZvcmVncm91bmQvODVcIj57c2VsZWN0ZWQucmVvcGVuRGVjaXNpb25zPy5bMF0/LmludmFsaWRhdGVkUmVjZWlwdElkcz8ubGVuZ3RoID8/IDB9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlJlcGxhY2VtZW50IFdvcmtPcmRlcjogPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1mb3JlZ3JvdW5kLzg1XCI+e3NlbGVjdGVkLnN1cGVyc2Vzc2lvbj8ucmVwbGFjZW1lbnRXb3JrT3JkZXJJZCA/PyBzZWxlY3RlZC53b3JrT3JkZXIuc3VwZXJzZWRlZEJ5V29ya09yZGVySWQgPz8gXCLigJRcIn08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L1NlY3Rpb24+XG5cbiAgICAgICAgICAgICAgICA8U2VjdGlvbiB0aXRsZT1cIlZlcmlmaWNhdGlvbiB0cmFjZWFiaWxpdHkgbWF0cml4XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWQud29ya09yZGVyLmFjY2VwdGFuY2VDcml0ZXJpYS5tYXAoKGNyaXRlcmlvbikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlY2VpcHQgPSBsYXRlc3RSZWNlaXB0TWFwLmdldChjcml0ZXJpb24uaWQpIGFzIGFueTtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBibG9ja2luZ1JlYXNvbiA9IHJlY2VpcHQ/LnN0YXR1cyA9PT0gXCJGQUlMRURcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcIkxhdGVzdCByZWNlaXB0IGZhaWxlZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHJlY2VpcHQ/LnN0YXR1cyA9PT0gXCJTVEFMRVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJTdXBlcnNlZGVkIGJ5IG5ld2VyIGV4ZWN1dGlvbiBldmlkZW5jZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogcmVjZWlwdD8uc3RhdHVzID09PSBcIldBSVZFRFwiICYmICFyZWNlaXB0LndhaXZlckFwcHJvdmFsRGVjaXNpb25JZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJXYWl2ZXIgYXBwcm92YWwgbWlzc2luZ1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAhcmVjZWlwdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIk1pc3NpbmcgdmVyaWZpY2F0aW9uIHJlY2VpcHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIuKAlFwiO1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17Y3JpdGVyaW9uLmlkfSBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItW3ZhcigtLXBhbmVsLWxpbmUpXSBiZy1iYWNrZ3JvdW5kLzMwIHB4LTMgcHktM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmRcIj57Y3JpdGVyaW9uLnRpdGxlfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+TWV0aG9kOiB7Y3JpdGVyaW9uLnZlcmlmaWNhdGlvbk1ldGhvZCA/PyBcIk1BTlVBTFwifTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NyaXRlcmlvbi5kZXNjcmlwdGlvbiA/IDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntjcml0ZXJpb24uZGVzY3JpcHRpb259PC9kaXY+IDogbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cIm91dGxpbmVcIj57cmVjZWlwdD8uc3RhdHVzID8/IFwiTUlTU0lOR1wifTwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZ3JpZCBnYXAtMiB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtZDpncmlkLWNvbHMtMiB4bDpncmlkLWNvbHMtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+RXZpZGVuY2U6IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZC84NVwiPntyZWNlaXB0Py5ldmlkZW5jZUxvY2F0aW9uID8/IHJlY2VpcHQ/LmFydGlmYWN0UmVmZXJlbmNlID8/IFwi4oCUXCJ9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+UnVuOiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWZvcmVncm91bmQvODVcIj57c2VsZWN0ZWQuZXhlY3V0aW9uUnVucy5maW5kKChydW4pID0+IHJ1bi5faWQgPT09IHJlY2VpcHQ/LndvcmtmbG93UnVuSWQpPy5ydW5JZCA/PyBcIuKAlFwifTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlZlcmlmaWVyOiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWZvcmVncm91bmQvODVcIj57cmVjZWlwdD8udmVyaWZpZXIgPz8gXCLigJRcIn08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5UaW1lc3RhbXA6IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZC84NVwiPntyZWNlaXB0Py5yZWNvcmRlZEF0ID8gbmV3IERhdGUocmVjZWlwdC5yZWNvcmRlZEF0KS50b0xvY2FsZVN0cmluZygpIDogXCLigJRcIn08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgZ3JpZCBnYXAtMiB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtZDpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+V2FpdmVyIC8gZXhjZXB0aW9uOiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWZvcmVncm91bmQvODVcIj57cmVjZWlwdD8uZXhjZXB0aW9uT3JXYWl2ZXIgPz8gXCLigJRcIn08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5CbG9ja2luZyByZWFzb246IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZC84NVwiPntibG9ja2luZ1JlYXNvbn08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVjZWlwdD8uY29tbWFuZE9yQ2hlY2sgPyA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5DaGVjazoge3JlY2VpcHQuY29tbWFuZE9yQ2hlY2t9PC9kaXY+IDogbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3JlY2VpcHQ/LnJlc3VsdCA/IDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlJlc3VsdDoge3JlY2VpcHQucmVzdWx0fTwvZGl2PiA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXJlY2VpcHQ/LndvcmtmbG93UnVuSWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEluc3BlY3RvclJ1bklkKChyZWNlaXB0Py53b3JrZmxvd1J1bklkID8/IG51bGwpIGFzIElkPFwid29ya2Zsb3dSdW5zXCI+IHwgbnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEluc3BlY3RvclJlY2VpcHRJZCgocmVjZWlwdD8uX2lkID8/IG51bGwpIGFzIElkPFwidmVyaWZpY2F0aW9uUmVjZWlwdHNcIj4gfCBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0SW5zcGVjdG9yQ3JpdGVyaW9uSWQocmVjZWlwdD8uYWNjZXB0YW5jZUNyaXRlcmlvbklkID8/IGNyaXRlcmlvbi5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEluc3BlY3QgZXZpZGVuY2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvU2VjdGlvbj5cblxuICAgICAgICAgICAgICAgIDxTZWN0aW9uIHRpdGxlPVwiU291cmNlIG9mIHRydXRoXCI+XG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWQud29ya09yZGVyLnNvdXJjZU9mVHJ1dGhSZWZzPy5sZW5ndGggPyAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkLndvcmtPcmRlci5zb3VyY2VPZlRydXRoUmVmcy5tYXAoKHJlZikgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2Ake3JlZi5raW5kfS0ke3JlZi5sb2NhdGlvbn1gfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLVt2YXIoLS1wYW5lbC1saW5lKV0gcHgtMyBweS0yIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZFwiPntyZWYubGFiZWx9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntyZWYua2luZH0gwrcge3JlZi5sb2NhdGlvbn08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxFeHRlcm5hbExpbmsgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+Tm8gc291cmNlLW9mLXRydXRoIHJlZmVyZW5jZXMgZGVjbGFyZWQuPC9wPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L1NlY3Rpb24+XG5cbiAgICAgICAgICAgICAgICA8U2VjdGlvbiB0aXRsZT1cIkxpbmtlZCBleGVjdXRpb24gcnVuc1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXgganVzdGlmeS1lbmRcIj5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17YXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RGlzcGF0Y2hFcnJvcihudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RGlzcGF0Y2hpbmdJZChzZWxlY3RlZC53b3JrT3JkZXIuX2lkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZGlzcGF0Y2hXb3JrT3JkZXIoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdvcmtPcmRlcklkOiBzZWxlY3RlZC53b3JrT3JkZXIuX2lkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdvcmtmbG93SWQ6IHNlbGVjdGVkLndvcmtPcmRlci53b3JrZmxvd0lkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdG9yVHlwZTogXCJIVU1BTlwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdG9ySWQ6IFwib3BlcmF0b3JcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZGVtcG90ZW5jeUtleTogYHVpLWRpc3BhdGNoOiR7c2VsZWN0ZWQud29ya09yZGVyLl9pZH06JHtzZWxlY3RlZC53b3JrT3JkZXIudXBkYXRlZEF0fWAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcnVudGltZTogXCJNaXNzaW9uIENvbnRyb2wgVUlcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQucmVhc29uID09PSBcInJvdXRpbmctZXhoYXVzdGVkXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJEaXNwYXRjaCBibG9ja2VkOiBubyBzYWZlIG1vZGVsIHJvdXRlIHNhdGlzZmllcyB0aGlzIFdvcmsgT3JkZXIuXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RGlzcGF0Y2hFcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogXCJEaXNwYXRjaCBmYWlsZWRcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXREaXNwYXRjaGluZ0lkKG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFjYW5EaXNwYXRjaFNlbGVjdGVkIHx8IGRpc3BhdGNoaW5nSWQgPT09IHNlbGVjdGVkLndvcmtPcmRlci5faWR9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7ZGlzcGF0Y2hpbmdJZCA9PT0gc2VsZWN0ZWQud29ya09yZGVyLl9pZCA/IFwiRGlzcGF0Y2hpbmfigKZcIiA6IFwiRGlzcGF0Y2hcIn1cbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIHtkaXNwYXRjaEVycm9yID8gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXJlZC01MDAvMjAgYmctcmVkLTUwMC81IHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtcmVkLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtkaXNwYXRjaEVycm9yfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgICAgICAge3NlbGVjdGVkLmV4ZWN1dGlvblJ1bnMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPk5vIGV4ZWN1dGlvbiBydW5zIGxpbmtlZCB5ZXQuPC9wPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWQuZXhlY3V0aW9uUnVucy5tYXAoKHJ1bikgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e3J1bi5faWR9IGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1bdmFyKC0tcGFuZWwtbGluZSldIGJnLWJhY2tncm91bmQvMzAgcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQbGF5Q2lyY2xlIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1yZWdpc3RyeS1hY2NlbnRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmRcIj57cnVuLndvcmtmbG93SWR9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCI+e3J1bi5zdGF0dXN9PC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e3J1bi5ydW5JZH08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0SW5zcGVjdG9yUnVuSWQocnVuLl9pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0SW5zcGVjdG9yUmVjZWlwdElkKG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEluc3BlY3RvckNyaXRlcmlvbklkKG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBJbnNwZWN0IHJ1blxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgZ3JpZCBnYXAtMiB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtZDpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+UnVudGltZTogPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1mb3JlZ3JvdW5kLzg1XCI+e3J1bi5ydW50aW1lID8/IFwi4oCUXCJ9PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+TW9kZWw6IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZC84NVwiPntydW4ubW9kZWwgPz8gXCLigJRcIn08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5Xb3JrdHJlZTogPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtZm9yZWdyb3VuZC84NVwiPntydW4ud29ya3RyZWUgPz8gXCLigJRcIn08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5DdXJyZW50IHN0ZXA6IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZC84NVwiPntydW4uY3VycmVudFN0ZXBMYWJlbCA/PyBcIuKAlFwifTwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlJldHJpZXM6IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZC84NVwiPntydW4ucmV0cnlDb3VudH08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5IdW1hbiBpbnRlcnZlbnRpb25zOiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWZvcmVncm91bmQvODVcIj57cnVuLmh1bWFuSW50ZXJ2ZW50aW9uc308L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cnVuLmZhaWx1cmVSZWFzb24gPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1yZWQtNTAwLzIwIGJnLXJlZC01MDAvNSBweC0zIHB5LTIgdGV4dC14cyB0ZXh0LXJlZC0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtydW4uZmFpbHVyZVJlYXNvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvU2VjdGlvbj5cblxuICAgICAgICAgICAgICAgIDxTZWN0aW9uIHRpdGxlPVwiTGlmZWN5Y2xlIGV2ZW50c1wiPlxuICAgICAgICAgICAgICAgICAge3NlbGVjdGVkLmV2ZW50cz8ubGVuZ3RoID8gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZC5ldmVudHMuc2xpY2UoMCwgNikubWFwKChldmVudCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2V2ZW50Ll9pZH0gY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLVt2YXIoLS1wYW5lbC1saW5lKV0gcHgtMyBweS0yIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZFwiPntldmVudC5zdW1tYXJ5fTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwib3V0bGluZVwiPntldmVudC5ldmVudFR5cGV9PC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtldmVudC5mcm9tU3RhdGUgPyBgJHtwcmV0dHlMYWJlbChldmVudC5mcm9tU3RhdGUpfSDihpIgYCA6IFwiXCJ9e2V2ZW50LnRvU3RhdGUgPyBwcmV0dHlMYWJlbChldmVudC50b1N0YXRlKSA6IFwiXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5ObyBsaWZlY3ljbGUgZXZlbnRzIHJlY29yZGVkIHlldC48L3A+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvU2VjdGlvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPENyZWF0ZVdvcmtPcmRlckRpYWxvZ1xuICAgICAgICBvcGVuPXtjcmVhdGVPcGVufVxuICAgICAgICBlcnJvcj17ZXJyb3J9XG4gICAgICAgIGNyZWF0aW5nPXtjcmVhdGluZ31cbiAgICAgICAgb25DbG9zZT17KCkgPT4ge1xuICAgICAgICAgIHNldENyZWF0ZU9wZW4oZmFsc2UpO1xuICAgICAgICAgIHNldENyZWF0ZVJlcXVlc3RLZXkobnVsbCk7XG4gICAgICAgICAgc2V0RXJyb3IobnVsbCk7XG4gICAgICAgIH19XG4gICAgICAgIG9uQ3JlYXRlPXthc3luYyAocGF5bG9hZCkgPT4ge1xuICAgICAgICAgIHNldENyZWF0aW5nKHRydWUpO1xuICAgICAgICAgIHNldEVycm9yKG51bGwpO1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjcmVhdGVXb3JrT3JkZXIoe1xuICAgICAgICAgICAgICBwcm9qZWN0SWQ6IHByb2plY3RJZCA/PyB1bmRlZmluZWQsXG4gICAgICAgICAgICAgIHRpdGxlOiBwYXlsb2FkLnRpdGxlLFxuICAgICAgICAgICAgICBkZXNpcmVkT3V0Y29tZTogcGF5bG9hZC5kZXNpcmVkT3V0Y29tZSxcbiAgICAgICAgICAgICAgY29udGV4dDogcGF5bG9hZC5jb250ZXh0IHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgd29ya2Zsb3dJZDogcGF5bG9hZC53b3JrZmxvd0lkIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgcmVwb3NpdG9yeTogcGF5bG9hZC5yZXBvc2l0b3J5IHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgYnJhbmNoU3RyYXRlZ3k6IHBheWxvYWQuYnJhbmNoU3RyYXRlZ3kgfHwgdW5kZWZpbmVkLFxuICAgICAgICAgICAgICBwcmlvcml0eTogTnVtYmVyKHBheWxvYWQucHJpb3JpdHkpIGFzIDEgfCAyIHwgMyB8IDQsXG4gICAgICAgICAgICAgIHJpc2tMZXZlbDogcGF5bG9hZC5yaXNrTGV2ZWwgYXMgXCJMT1dcIiB8IFwiTUVESVVNXCIgfCBcIkhJR0hcIiB8IFwiQ1JJVElDQUxcIixcbiAgICAgICAgICAgICAgcmVxdWVzdGVkQnk6IHBheWxvYWQucmVxdWVzdGVkQnkgfHwgdW5kZWZpbmVkLFxuICAgICAgICAgICAgICBhc3NpZ25lZEFnZW50OiBwYXlsb2FkLmFzc2lnbmVkQWdlbnQgfHwgdW5kZWZpbmVkLFxuICAgICAgICAgICAgICBhY2NlcHRhbmNlQ3JpdGVyaWE6IGNyaXRlcmlhRnJvbVRleHQocGF5bG9hZC5hY2NlcHRhbmNlQ3JpdGVyaWEpLFxuICAgICAgICAgICAgICBzb3VyY2VPZlRydXRoUmVmczogcGF5bG9hZC5yZXBvc2l0b3J5XG4gICAgICAgICAgICAgICAgPyBbeyBraW5kOiBcIlJFUE9cIiwgbGFiZWw6IHBheWxvYWQucmVwb3NpdG9yeSwgbG9jYXRpb246IGBnaXRodWIuY29tLyR7cGF5bG9hZC5yZXBvc2l0b3J5fWAgfV1cbiAgICAgICAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgaWRlbXBvdGVuY3lLZXk6IGNyZWF0ZVJlcXVlc3RLZXkgPz8gdW5kZWZpbmVkLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBzZXRTZWxlY3RlZElkKHJlc3VsdC53b3JrT3JkZXI/Ll9pZCA/PyBudWxsKTtcbiAgICAgICAgICAgIHNldE1vYmlsZURldGFpbE9wZW4odHJ1ZSk7XG4gICAgICAgICAgICBzZXRDcmVhdGVPcGVuKGZhbHNlKTtcbiAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIHNldEVycm9yKGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBcIkZhaWxlZCB0byBjcmVhdGUgd29yayBvcmRlclwiKTtcbiAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0Q3JlYXRpbmcoZmFsc2UpO1xuICAgICAgICAgIH1cbiAgICAgICAgfX1cbiAgICAgIC8+XG5cbiAgICAgIDxSZXF1ZXN0QXBwcm92YWxEaWFsb2dcbiAgICAgICAgb3Blbj17YXBwcm92YWxPcGVufVxuICAgICAgICB3b3JrT3JkZXI9e3NlbGVjdGVkPy53b3JrT3JkZXIgPz8gbnVsbH1cbiAgICAgICAgY3JlYXRpbmc9e2NyZWF0aW5nfVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRBcHByb3ZhbE9wZW4oZmFsc2UpfVxuICAgICAgICBvbkNyZWF0ZT17YXN5bmMgKHBheWxvYWQpID0+IHtcbiAgICAgICAgICBpZiAoIXNlbGVjdGVkKSByZXR1cm47XG4gICAgICAgICAgc2V0Q3JlYXRpbmcodHJ1ZSk7XG4gICAgICAgICAgc2V0R292ZXJuYW5jZUVycm9yKG51bGwpO1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCByZXF1ZXN0QXBwcm92YWxEZWNpc2lvbih7XG4gICAgICAgICAgICAgIHdvcmtPcmRlcklkOiBzZWxlY3RlZC53b3JrT3JkZXIuX2lkLFxuICAgICAgICAgICAgICB3b3JrZmxvd1J1bklkOiBwYXlsb2FkLndvcmtmbG93UnVuSWQgPyBwYXlsb2FkLndvcmtmbG93UnVuSWQgYXMgSWQ8XCJ3b3JrZmxvd1J1bnNcIj4gOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgIGFwcHJvdmFsVHlwZTogcGF5bG9hZC5hcHByb3ZhbFR5cGUsXG4gICAgICAgICAgICAgIHJlcXVlc3RlZEFjdGlvbjogcGF5bG9hZC5yZXF1ZXN0ZWRBY3Rpb24sXG4gICAgICAgICAgICAgIHJlcXVlc3RlZEJ5OiBwYXlsb2FkLnJlcXVlc3RlZEJ5IHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgcmlza0xldmVsOiBzZWxlY3RlZC53b3JrT3JkZXIucmlza0xldmVsLFxuICAgICAgICAgICAgICBpZGVtcG90ZW5jeUtleTogYHVpLWFwcHJvdmFsOiR7c2VsZWN0ZWQud29ya09yZGVyLl9pZH06JHtwYXlsb2FkLmFwcHJvdmFsVHlwZX06JHtwYXlsb2FkLnJlcXVlc3RlZEFjdGlvbn1gLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBzZXRBcHByb3ZhbE9wZW4oZmFsc2UpO1xuICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgc2V0R292ZXJuYW5jZUVycm9yKGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBcIkZhaWxlZCB0byByZXF1ZXN0IGFwcHJvdmFsXCIpO1xuICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRDcmVhdGluZyhmYWxzZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9fVxuICAgICAgLz5cblxuICAgICAgPFJlY29yZFZlcmlmaWNhdGlvblJlY2VpcHREaWFsb2dcbiAgICAgICAgb3Blbj17cmVjZWlwdE9wZW59XG4gICAgICAgIHdvcmtPcmRlcj17c2VsZWN0ZWQ/LndvcmtPcmRlciA/PyBudWxsfVxuICAgICAgICBleGVjdXRpb25SdW5zPXtzZWxlY3RlZD8uZXhlY3V0aW9uUnVucyA/PyBbXX1cbiAgICAgICAgYXBwcm92YWxEZWNpc2lvbnM9e3NlbGVjdGVkPy5hcHByb3ZhbERlY2lzaW9ucyA/PyBbXX1cbiAgICAgICAgY3JlYXRpbmc9e2NyZWF0aW5nfVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRSZWNlaXB0T3BlbihmYWxzZSl9XG4gICAgICAgIG9uQ3JlYXRlPXthc3luYyAocGF5bG9hZCkgPT4ge1xuICAgICAgICAgIGlmICghc2VsZWN0ZWQpIHJldHVybjtcbiAgICAgICAgICBzZXRDcmVhdGluZyh0cnVlKTtcbiAgICAgICAgICBzZXRHb3Zlcm5hbmNlRXJyb3IobnVsbCk7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IHJlY29yZFZlcmlmaWNhdGlvblJlY2VpcHQoe1xuICAgICAgICAgICAgICB3b3JrT3JkZXJJZDogc2VsZWN0ZWQud29ya09yZGVyLl9pZCxcbiAgICAgICAgICAgICAgd29ya2Zsb3dSdW5JZDogcGF5bG9hZC53b3JrZmxvd1J1bklkIGFzIElkPFwid29ya2Zsb3dSdW5zXCI+LFxuICAgICAgICAgICAgICBhY2NlcHRhbmNlQ3JpdGVyaW9uSWQ6IHBheWxvYWQuYWNjZXB0YW5jZUNyaXRlcmlvbklkLFxuICAgICAgICAgICAgICB2ZXJpZmljYXRpb25NZXRob2Q6IHBheWxvYWQudmVyaWZpY2F0aW9uTWV0aG9kIGFzIFwiTUFOVUFMXCIgfCBcIkNPTU1BTkRcIiB8IFwiVEVTVFwiIHwgXCJDSEVDS0xJU1RcIixcbiAgICAgICAgICAgICAgY29tbWFuZE9yQ2hlY2s6IHBheWxvYWQuY29tbWFuZE9yQ2hlY2sgfHwgdW5kZWZpbmVkLFxuICAgICAgICAgICAgICByZXN1bHQ6IHBheWxvYWQucmVzdWx0IHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgZXZpZGVuY2VMb2NhdGlvbjogcGF5bG9hZC5ldmlkZW5jZUxvY2F0aW9uIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgYXJ0aWZhY3RSZWZlcmVuY2U6IHBheWxvYWQuYXJ0aWZhY3RSZWZlcmVuY2UgfHwgdW5kZWZpbmVkLFxuICAgICAgICAgICAgICB2ZXJpZmllcjogcGF5bG9hZC52ZXJpZmllciB8fCB1bmRlZmluZWQsXG4gICAgICAgICAgICAgIHN0YXR1czogcGF5bG9hZC5zdGF0dXMgYXMgXCJQRU5ESU5HXCIgfCBcIlBBU1NFRFwiIHwgXCJGQUlMRURcIiB8IFwiV0FJVkVEXCIgfCBcIlNUQUxFXCIsXG4gICAgICAgICAgICAgIGV4Y2VwdGlvbk9yV2FpdmVyOiBwYXlsb2FkLmV4Y2VwdGlvbk9yV2FpdmVyIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgd2FpdmVyQXBwcm92YWxEZWNpc2lvbklkOiBwYXlsb2FkLndhaXZlckFwcHJvdmFsRGVjaXNpb25JZCA/IHBheWxvYWQud2FpdmVyQXBwcm92YWxEZWNpc2lvbklkIGFzIElkPFwiYXBwcm92YWxEZWNpc2lvbnNcIj4gOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgIGlkZW1wb3RlbmN5S2V5OiBgdWktcmVjZWlwdDoke3NlbGVjdGVkLndvcmtPcmRlci5faWR9OiR7cGF5bG9hZC5hY2NlcHRhbmNlQ3JpdGVyaW9uSWR9OiR7cGF5bG9hZC53b3JrZmxvd1J1bklkfToke3BheWxvYWQuc3RhdHVzfWAsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHNldFJlY2VpcHRPcGVuKGZhbHNlKTtcbiAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIHNldEdvdmVybmFuY2VFcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogXCJGYWlsZWQgdG8gcmVjb3JkIHZlcmlmaWNhdGlvbiByZWNlaXB0XCIpO1xuICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRDcmVhdGluZyhmYWxzZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9fVxuICAgICAgLz5cblxuICAgICAgPFJlcXVlc3RSZXZpc2lvbkRpYWxvZ1xuICAgICAgICBvcGVuPXtyZXZpc2lvbk9wZW59XG4gICAgICAgIHdvcmtPcmRlcj17c2VsZWN0ZWQ/LndvcmtPcmRlciA/PyBudWxsfVxuICAgICAgICBjcmVhdGluZz17Y3JlYXRpbmd9XG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFJldmlzaW9uT3BlbihmYWxzZSl9XG4gICAgICAgIG9uQ3JlYXRlPXthc3luYyAocGF5bG9hZCkgPT4ge1xuICAgICAgICAgIGlmICghc2VsZWN0ZWQpIHJldHVybjtcbiAgICAgICAgICBzZXRDcmVhdGluZyh0cnVlKTtcbiAgICAgICAgICBzZXRHb3Zlcm5hbmNlRXJyb3IobnVsbCk7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IHJlcXVlc3RXb3JrT3JkZXJSZXZpc2lvbih7XG4gICAgICAgICAgICAgIHdvcmtPcmRlcklkOiBzZWxlY3RlZC53b3JrT3JkZXIuX2lkLFxuICAgICAgICAgICAgICBpZGVtcG90ZW5jeUtleTogYHVpLXJldmlzaW9uOiR7c2VsZWN0ZWQud29ya09yZGVyLl9pZH06JHtEYXRlLm5vdygpfWAsXG4gICAgICAgICAgICAgIGNoYW5nZVN1bW1hcnk6IHBheWxvYWQuY2hhbmdlU3VtbWFyeSxcbiAgICAgICAgICAgICAgcmVhc29uOiBwYXlsb2FkLnJlYXNvbixcbiAgICAgICAgICAgICAgcmVxdWVzdGVkQnk6IHBheWxvYWQucmVxdWVzdGVkQnkgfHwgdW5kZWZpbmVkLFxuICAgICAgICAgICAgICBwYXRjaDoge1xuICAgICAgICAgICAgICAgIGRlc2lyZWRPdXRjb21lOiBwYXlsb2FkLmRlc2lyZWRPdXRjb21lIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICB3b3JrZmxvd0lkOiBwYXlsb2FkLndvcmtmbG93SWQgfHwgdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIHJlcG9zaXRvcnk6IHBheWxvYWQucmVwb3NpdG9yeSB8fCB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgcmlza0xldmVsOiBwYXlsb2FkLnJpc2tMZXZlbCBhcyBhbnksXG4gICAgICAgICAgICAgICAgcmVxdWlyZWRBcHByb3ZhbHM6IHBheWxvYWQucmVxdWlyZWRBcHByb3ZhbHMsXG4gICAgICAgICAgICAgICAgYWNjZXB0YW5jZUNyaXRlcmlhOiBjcml0ZXJpYUZyb21UZXh0KHBheWxvYWQuYWNjZXB0YW5jZUNyaXRlcmlhLCBzZWxlY3RlZC53b3JrT3JkZXIuYWNjZXB0YW5jZUNyaXRlcmlhIGFzIGFueSksXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHNldFJldmlzaW9uT3BlbihmYWxzZSk7XG4gICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBzZXRHb3Zlcm5hbmNlRXJyb3IoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6IFwiRmFpbGVkIHRvIHJlcXVlc3QgcmV2aXNpb25cIik7XG4gICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldENyZWF0aW5nKGZhbHNlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH19XG4gICAgICAvPlxuXG4gICAgICA8UmVvcGVuV29ya09yZGVyRGlhbG9nXG4gICAgICAgIG9wZW49e3Jlb3Blbk9wZW59XG4gICAgICAgIHdvcmtPcmRlcj17c2VsZWN0ZWQ/LndvcmtPcmRlciA/PyBudWxsfVxuICAgICAgICBjcmVhdGluZz17Y3JlYXRpbmd9XG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFJlb3Blbk9wZW4oZmFsc2UpfVxuICAgICAgICBvbkNyZWF0ZT17YXN5bmMgKHBheWxvYWQpID0+IHtcbiAgICAgICAgICBpZiAoIXNlbGVjdGVkKSByZXR1cm47XG4gICAgICAgICAgc2V0Q3JlYXRpbmcodHJ1ZSk7XG4gICAgICAgICAgc2V0R292ZXJuYW5jZUVycm9yKG51bGwpO1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCByZW9wZW5Xb3JrT3JkZXIoe1xuICAgICAgICAgICAgICB3b3JrT3JkZXJJZDogc2VsZWN0ZWQud29ya09yZGVyLl9pZCxcbiAgICAgICAgICAgICAgaWRlbXBvdGVuY3lLZXk6IGB1aS1yZW9wZW46JHtzZWxlY3RlZC53b3JrT3JkZXIuX2lkfToke0RhdGUubm93KCl9YCxcbiAgICAgICAgICAgICAgcmVhc29uOiBwYXlsb2FkLnJlYXNvbixcbiAgICAgICAgICAgICAgc291cmNlSXNzdWVPckRlZmVjdDogcGF5bG9hZC5zb3VyY2VJc3N1ZU9yRGVmZWN0IHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgcmVxdWVzdGVkQnk6IHBheWxvYWQucmVxdWVzdGVkQnkgfHwgdW5kZWZpbmVkLFxuICAgICAgICAgICAgICBhcHByb3ZlZEJ5OiBwYXlsb2FkLmFwcHJvdmVkQnkgfHwgdW5kZWZpbmVkLFxuICAgICAgICAgICAgICByZW9wZW5TY29wZTogcGF5bG9hZC5yZW9wZW5TY29wZSxcbiAgICAgICAgICAgICAgYWNjZXB0YW5jZUNyaXRlcmlhSW1wYWN0ZWQ6IHBheWxvYWQuYWNjZXB0YW5jZUNyaXRlcmlhSW1wYWN0ZWQsXG4gICAgICAgICAgICAgIG5ld1JlcXVpcmVkQWN0aW9uczogcGF5bG9hZC5uZXdSZXF1aXJlZEFjdGlvbnMsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHNldFJlb3Blbk9wZW4oZmFsc2UpO1xuICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgc2V0R292ZXJuYW5jZUVycm9yKGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBcIkZhaWxlZCB0byByZW9wZW4gV29ya09yZGVyXCIpO1xuICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRDcmVhdGluZyhmYWxzZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9fVxuICAgICAgLz5cblxuICAgICAgPFN1cGVyc2VkZVdvcmtPcmRlckRpYWxvZ1xuICAgICAgICBvcGVuPXtzdXBlcnNlZGVPcGVufVxuICAgICAgICB3b3JrT3JkZXJzPXt3b3JrT3JkZXJzID8/IFtdfVxuICAgICAgICBjdXJyZW50V29ya09yZGVySWQ9e3NlbGVjdGVkPy53b3JrT3JkZXIuX2lkID8/IG51bGx9XG4gICAgICAgIGNyZWF0aW5nPXtjcmVhdGluZ31cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U3VwZXJzZWRlT3BlbihmYWxzZSl9XG4gICAgICAgIG9uQ3JlYXRlPXthc3luYyAocGF5bG9hZCkgPT4ge1xuICAgICAgICAgIGlmICghc2VsZWN0ZWQpIHJldHVybjtcbiAgICAgICAgICBzZXRDcmVhdGluZyh0cnVlKTtcbiAgICAgICAgICBzZXRHb3Zlcm5hbmNlRXJyb3IobnVsbCk7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IHN1cGVyc2VkZVdvcmtPcmRlcih7XG4gICAgICAgICAgICAgIHdvcmtPcmRlcklkOiBzZWxlY3RlZC53b3JrT3JkZXIuX2lkLFxuICAgICAgICAgICAgICByZXBsYWNlbWVudFdvcmtPcmRlcklkOiBwYXlsb2FkLnJlcGxhY2VtZW50V29ya09yZGVySWQgYXMgSWQ8XCJ3b3JrT3JkZXJzXCI+LFxuICAgICAgICAgICAgICBpZGVtcG90ZW5jeUtleTogYHVpLXN1cGVyc2VkZToke3NlbGVjdGVkLndvcmtPcmRlci5faWR9OiR7cGF5bG9hZC5yZXBsYWNlbWVudFdvcmtPcmRlcklkfWAsXG4gICAgICAgICAgICAgIHJlYXNvbjogcGF5bG9hZC5yZWFzb24sXG4gICAgICAgICAgICAgIGFjdG9yVHlwZTogXCJIVU1BTlwiLFxuICAgICAgICAgICAgICBhY3RvcklkOiBwYXlsb2FkLmFjdG9ySWQgfHwgdW5kZWZpbmVkLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBzZXRTdXBlcnNlZGVPcGVuKGZhbHNlKTtcbiAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIHNldEdvdmVybmFuY2VFcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogXCJGYWlsZWQgdG8gc3VwZXJzZWRlIFdvcmtPcmRlclwiKTtcbiAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0Q3JlYXRpbmcoZmFsc2UpO1xuICAgICAgICAgIH1cbiAgICAgICAgfX1cbiAgICAgIC8+XG5cbiAgICAgIDxFeGVjdXRpb25SdW5JbnNwZWN0b3JcbiAgICAgICAgb3Blbj17ISFpbnNwZWN0b3JSdW5JZH1cbiAgICAgICAgd29ya2Zsb3dSdW5JZD17aW5zcGVjdG9yUnVuSWR9XG4gICAgICAgIHZlcmlmaWNhdGlvblJlY2VpcHRJZD17aW5zcGVjdG9yUmVjZWlwdElkfVxuICAgICAgICBhY2NlcHRhbmNlQ3JpdGVyaW9uSWQ9e2luc3BlY3RvckNyaXRlcmlvbklkfVxuICAgICAgICByZXRyeWluZz17ISFzZWxlY3RlZCAmJiBkaXNwYXRjaGluZ0lkID09PSBzZWxlY3RlZC53b3JrT3JkZXIuX2lkfVxuICAgICAgICBvblJldHJ5RmFpbGVkUnVuPXtzZWxlY3RlZFxuICAgICAgICAgID8gYXN5bmMgKHsgd29ya2Zsb3dSdW5JZCwgcmVhc29uLCBydW50aW1lLCBtb2RlbCwgd29ya3RyZWUgfSkgPT4ge1xuICAgICAgICAgICAgICBzZXREaXNwYXRjaEVycm9yKG51bGwpO1xuICAgICAgICAgICAgICBzZXREaXNwYXRjaGluZ0lkKHNlbGVjdGVkLndvcmtPcmRlci5faWQpO1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGRpc3BhdGNoV29ya09yZGVyKHtcbiAgICAgICAgICAgICAgICAgIHdvcmtPcmRlcklkOiBzZWxlY3RlZC53b3JrT3JkZXIuX2lkLFxuICAgICAgICAgICAgICAgICAgd29ya2Zsb3dJZDogc2VsZWN0ZWQud29ya09yZGVyLndvcmtmbG93SWQsXG4gICAgICAgICAgICAgICAgICBhY3RvclR5cGU6IFwiSFVNQU5cIixcbiAgICAgICAgICAgICAgICAgIGFjdG9ySWQ6IFwib3BlcmF0b3JcIixcbiAgICAgICAgICAgICAgICAgIGlkZW1wb3RlbmN5S2V5OiBgdWktcmV0cnk6JHt3b3JrZmxvd1J1bklkfToke2dsb2JhbFRoaXMuY3J5cHRvPy5yYW5kb21VVUlEPy4oKSA/PyBEYXRlLm5vdygpfWAsXG4gICAgICAgICAgICAgICAgICBydW50aW1lOiBydW50aW1lID8/IFwiTWlzc2lvbiBDb250cm9sIFVJXCIsXG4gICAgICAgICAgICAgICAgICBtb2RlbCxcbiAgICAgICAgICAgICAgICAgIHdvcmt0cmVlLFxuICAgICAgICAgICAgICAgICAgcmV0cnlPZldvcmtmbG93UnVuSWQ6IHdvcmtmbG93UnVuSWQsXG4gICAgICAgICAgICAgICAgICByZXRyeVJlYXNvbjogcmVhc29uLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGlmIChyZXN1bHQucmVhc29uID09PSBcInJvdXRpbmctZXhoYXVzdGVkXCIpIHtcbiAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIlJldHJ5IGJsb2NrZWQ6IG5vIHNhZmUgbW9kZWwgcm91dGUgc2F0aXNmaWVzIHRoaXMgV29yayBPcmRlci5cIik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICAgIHNldERpc3BhdGNoaW5nSWQobnVsbCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICA6IHVuZGVmaW5lZH1cbiAgICAgICAgb25DbG9zZT17KCkgPT4ge1xuICAgICAgICAgIHNldEluc3BlY3RvclJ1bklkKG51bGwpO1xuICAgICAgICAgIHNldEluc3BlY3RvclJlY2VpcHRJZChudWxsKTtcbiAgICAgICAgICBzZXRJbnNwZWN0b3JDcml0ZXJpb25JZChudWxsKTtcbiAgICAgICAgfX1cbiAgICAgIC8+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmZ1bmN0aW9uIEZpbHRlclNlbGVjdCh7XG4gIGxhYmVsLFxuICB2YWx1ZSxcbiAgb25DaGFuZ2UsXG4gIG9wdGlvbnMsXG59OiB7XG4gIGxhYmVsOiBzdHJpbmc7XG4gIHZhbHVlOiBzdHJpbmc7XG4gIG9uQ2hhbmdlOiAodmFsdWU6IHN0cmluZykgPT4gdm9pZDtcbiAgb3B0aW9uczogc3RyaW5nW107XG59KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgPExhYmVsIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHVwcGVyY2FzZSB0cmFja2luZy1bMC4xNGVtXSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57bGFiZWx9PC9MYWJlbD5cbiAgICAgIDxTZWxlY3QgdmFsdWU9e3ZhbHVlfSBvblZhbHVlQ2hhbmdlPXtvbkNoYW5nZX0+XG4gICAgICAgIDxTZWxlY3RUcmlnZ2VyIGFyaWEtbGFiZWw9e2Ake2xhYmVsfSBmaWx0ZXJgfT5cbiAgICAgICAgICA8U2VsZWN0VmFsdWUgLz5cbiAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cImFsbFwiPkFsbDwvU2VsZWN0SXRlbT5cbiAgICAgICAgICB7b3B0aW9ucy5tYXAoKG9wdGlvbikgPT4gKFxuICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXtvcHRpb259IHZhbHVlPXtvcHRpb259PntvcHRpb259PC9TZWxlY3RJdGVtPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XG4gICAgICA8L1NlbGVjdD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gU2VjdGlvbih7IHRpdGxlLCBjaGlsZHJlbiB9OiB7IHRpdGxlOiBzdHJpbmc7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGUgfSkge1xuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLVswLjE2ZW1dIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPnt0aXRsZX08L2Rpdj5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG5cbmZ1bmN0aW9uIE1ldGFSb3coeyBsYWJlbCwgdmFsdWUgfTogeyBsYWJlbDogc3RyaW5nOyB2YWx1ZT86IHN0cmluZyB8IG51bGwgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57bGFiZWx9PC9kdD5cbiAgICAgIDxkZCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0IHRleHQtZm9yZWdyb3VuZC84NVwiPnt2YWx1ZSA/PyBcIuKAlFwifTwvZGQ+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmZ1bmN0aW9uIFN0YXRDYXJkKHsgbGFiZWwsIHZhbHVlLCB0b25lID0gXCJkZWZhdWx0XCIgfTogeyBsYWJlbDogc3RyaW5nOyB2YWx1ZTogbnVtYmVyOyB0b25lPzogXCJkZWZhdWx0XCIgfCBcImdvb2RcIiB8IFwid2FyblwiIHwgXCJiYWRcIiB9KSB7XG4gIHJldHVybiAoXG4gICAgPENhcmQgY2xhc3NOYW1lPVwicC00XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHVwcGVyY2FzZSB0cmFja2luZy1bMC4xNGVtXSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57bGFiZWx9PC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT17YG10LTIgdGV4dC0yeGwgZm9udC1zZW1pYm9sZCAke3RvbmUgPT09IFwiZ29vZFwiID8gXCJ0ZXh0LWVtZXJhbGQtMzAwXCIgOiB0b25lID09PSBcIndhcm5cIiA/IFwidGV4dC1hbWJlci0zMDBcIiA6IHRvbmUgPT09IFwiYmFkXCIgPyBcInRleHQtcmVkLTMwMFwiIDogXCJ0ZXh0LWZvcmVncm91bmRcIn1gfT5cbiAgICAgICAge3ZhbHVlfVxuICAgICAgPC9kaXY+XG4gICAgPC9DYXJkPlxuICApO1xufVxuXG5mdW5jdGlvbiBSZXF1ZXN0QXBwcm92YWxEaWFsb2coe1xuICBvcGVuLFxuICB3b3JrT3JkZXIsXG4gIGNyZWF0aW5nLFxuICBvbkNsb3NlLFxuICBvbkNyZWF0ZSxcbn06IHtcbiAgb3BlbjogYm9vbGVhbjtcbiAgd29ya09yZGVyOiBhbnk7XG4gIGNyZWF0aW5nOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBvbkNyZWF0ZTogKHBheWxvYWQ6IHsgYXBwcm92YWxUeXBlOiBzdHJpbmc7IHJlcXVlc3RlZEFjdGlvbjogc3RyaW5nOyByZXF1ZXN0ZWRCeTogc3RyaW5nOyB3b3JrZmxvd1J1bklkOiBzdHJpbmcgfSkgPT4gUHJvbWlzZTx2b2lkPjtcbn0pIHtcbiAgY29uc3QgZGVmYXVsdFR5cGUgPSB3b3JrT3JkZXI/LnJlcXVpcmVkQXBwcm92YWxzPy5bMF0gPz8gKFtcIkhJR0hcIiwgXCJDUklUSUNBTFwiXS5pbmNsdWRlcyh3b3JrT3JkZXI/LnJpc2tMZXZlbCkgPyBcIlJJU0tfUkVWSUVXXCIgOiBcIk9QRVJBVE9SX1JFVklFV1wiKTtcbiAgY29uc3QgW2FwcHJvdmFsVHlwZSwgc2V0QXBwcm92YWxUeXBlXSA9IHVzZVN0YXRlKGRlZmF1bHRUeXBlKTtcbiAgY29uc3QgW3JlcXVlc3RlZEFjdGlvbiwgc2V0UmVxdWVzdGVkQWN0aW9uXSA9IHVzZVN0YXRlKFwiQXBwcm92ZSBwcm90ZWN0ZWQgZGlzcGF0Y2ggb3IgYWNjZXB0YW5jZSBhY3Rpb25cIik7XG4gIGNvbnN0IFtyZXF1ZXN0ZWRCeSwgc2V0UmVxdWVzdGVkQnldID0gdXNlU3RhdGUoXCJvcGVyYXRvclwiKTtcbiAgY29uc3QgW3dvcmtmbG93UnVuSWQsIHNldFdvcmtmbG93UnVuSWRdID0gdXNlU3RhdGUoXCJcIik7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXRBcHByb3ZhbFR5cGUoZGVmYXVsdFR5cGUpO1xuICB9LCBbZGVmYXVsdFR5cGUsIG9wZW5dKTtcblxuICByZXR1cm4gKFxuICAgIDxEaWFsb2cgb3Blbj17b3Blbn0gb25PcGVuQ2hhbmdlPXsobmV4dCkgPT4gIW5leHQgJiYgb25DbG9zZSgpfT5cbiAgICAgIDxEaWFsb2dDb250ZW50IGNsYXNzTmFtZT1cInNtOm1heC13LVs1NjBweF1cIj5cbiAgICAgICAgPERpYWxvZ0hlYWRlcj5cbiAgICAgICAgICA8RGlhbG9nVGl0bGU+UmVxdWVzdCBhcHByb3ZhbDwvRGlhbG9nVGl0bGU+XG4gICAgICAgICAgPERpYWxvZ0Rlc2NyaXB0aW9uPkNyZWF0ZSBhbiBhdWRpdGFibGUgQXBwcm92YWxEZWNpc2lvbiBsaW5rZWQgdG8gdGhpcyBXb3JrT3JkZXIuPC9EaWFsb2dEZXNjcmlwdGlvbj5cbiAgICAgICAgPC9EaWFsb2dIZWFkZXI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPjxMYWJlbD5BcHByb3ZhbCB0eXBlPC9MYWJlbD48SW5wdXQgdmFsdWU9e2FwcHJvdmFsVHlwZX0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0QXBwcm92YWxUeXBlKGV2ZW50LnRhcmdldC52YWx1ZSl9IC8+PC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPjxMYWJlbD5SZXF1ZXN0ZWQgYWN0aW9uPC9MYWJlbD48VGV4dGFyZWEgdmFsdWU9e3JlcXVlc3RlZEFjdGlvbn0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0UmVxdWVzdGVkQWN0aW9uKGV2ZW50LnRhcmdldC52YWx1ZSl9IHJvd3M9ezN9IC8+PC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0zIG1kOmdyaWQtY29scy0yXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+PExhYmVsPlJlcXVlc3RlZCBieTwvTGFiZWw+PElucHV0IHZhbHVlPXtyZXF1ZXN0ZWRCeX0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0UmVxdWVzdGVkQnkoZXZlbnQudGFyZ2V0LnZhbHVlKX0gLz48L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj48TGFiZWw+RXhlY3V0aW9uIHJ1biBJRCAob3B0aW9uYWwpPC9MYWJlbD48SW5wdXQgdmFsdWU9e3dvcmtmbG93UnVuSWR9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFdvcmtmbG93UnVuSWQoZXZlbnQudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJ3NTcuLi5cIiAvPjwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPERpYWxvZ0Zvb3Rlcj5cbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9e29uQ2xvc2V9PkNhbmNlbDwvQnV0dG9uPlxuICAgICAgICAgIDxCdXR0b24gb25DbGljaz17KCkgPT4gb25DcmVhdGUoeyBhcHByb3ZhbFR5cGUsIHJlcXVlc3RlZEFjdGlvbiwgcmVxdWVzdGVkQnksIHdvcmtmbG93UnVuSWQgfSl9IGRpc2FibGVkPXtjcmVhdGluZyB8fCAhYXBwcm92YWxUeXBlLnRyaW0oKSB8fCAhcmVxdWVzdGVkQWN0aW9uLnRyaW0oKX0+e2NyZWF0aW5nID8gXCJSZXF1ZXN0aW5n4oCmXCIgOiBcIlJlcXVlc3QgYXBwcm92YWxcIn08L0J1dHRvbj5cbiAgICAgICAgPC9EaWFsb2dGb290ZXI+XG4gICAgICA8L0RpYWxvZ0NvbnRlbnQ+XG4gICAgPC9EaWFsb2c+XG4gICk7XG59XG5cbmZ1bmN0aW9uIFJlY29yZFZlcmlmaWNhdGlvblJlY2VpcHREaWFsb2coe1xuICBvcGVuLFxuICB3b3JrT3JkZXIsXG4gIGV4ZWN1dGlvblJ1bnMsXG4gIGFwcHJvdmFsRGVjaXNpb25zLFxuICBjcmVhdGluZyxcbiAgb25DbG9zZSxcbiAgb25DcmVhdGUsXG59OiB7XG4gIG9wZW46IGJvb2xlYW47XG4gIHdvcmtPcmRlcjogYW55O1xuICBleGVjdXRpb25SdW5zOiBhbnlbXTtcbiAgYXBwcm92YWxEZWNpc2lvbnM6IGFueVtdO1xuICBjcmVhdGluZzogYm9vbGVhbjtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbiAgb25DcmVhdGU6IChwYXlsb2FkOiB7XG4gICAgYWNjZXB0YW5jZUNyaXRlcmlvbklkOiBzdHJpbmc7XG4gICAgd29ya2Zsb3dSdW5JZDogc3RyaW5nO1xuICAgIHZlcmlmaWNhdGlvbk1ldGhvZDogc3RyaW5nO1xuICAgIGNvbW1hbmRPckNoZWNrOiBzdHJpbmc7XG4gICAgcmVzdWx0OiBzdHJpbmc7XG4gICAgZXZpZGVuY2VMb2NhdGlvbjogc3RyaW5nO1xuICAgIGFydGlmYWN0UmVmZXJlbmNlOiBzdHJpbmc7XG4gICAgdmVyaWZpZXI6IHN0cmluZztcbiAgICBzdGF0dXM6IHN0cmluZztcbiAgICBleGNlcHRpb25PcldhaXZlcjogc3RyaW5nO1xuICAgIHdhaXZlckFwcHJvdmFsRGVjaXNpb25JZDogc3RyaW5nO1xuICB9KSA9PiBQcm9taXNlPHZvaWQ+O1xufSkge1xuICBjb25zdCBbYWNjZXB0YW5jZUNyaXRlcmlvbklkLCBzZXRBY2NlcHRhbmNlQ3JpdGVyaW9uSWRdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFt3b3JrZmxvd1J1bklkLCBzZXRXb3JrZmxvd1J1bklkXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbdmVyaWZpY2F0aW9uTWV0aG9kLCBzZXRWZXJpZmljYXRpb25NZXRob2RdID0gdXNlU3RhdGUoXCJNQU5VQUxcIik7XG4gIGNvbnN0IFtjb21tYW5kT3JDaGVjaywgc2V0Q29tbWFuZE9yQ2hlY2tdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtyZXN1bHQsIHNldFJlc3VsdF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2V2aWRlbmNlTG9jYXRpb24sIHNldEV2aWRlbmNlTG9jYXRpb25dID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFthcnRpZmFjdFJlZmVyZW5jZSwgc2V0QXJ0aWZhY3RSZWZlcmVuY2VdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFt2ZXJpZmllciwgc2V0VmVyaWZpZXJdID0gdXNlU3RhdGUoXCJvcGVyYXRvclwiKTtcbiAgY29uc3QgW3N0YXR1cywgc2V0U3RhdHVzXSA9IHVzZVN0YXRlKFwiUEFTU0VEXCIpO1xuICBjb25zdCBbZXhjZXB0aW9uT3JXYWl2ZXIsIHNldEV4Y2VwdGlvbk9yV2FpdmVyXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbd2FpdmVyQXBwcm92YWxEZWNpc2lvbklkLCBzZXRXYWl2ZXJBcHByb3ZhbERlY2lzaW9uSWRdID0gdXNlU3RhdGUoXCJcIik7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXRBY2NlcHRhbmNlQ3JpdGVyaW9uSWQod29ya09yZGVyPy5hY2NlcHRhbmNlQ3JpdGVyaWE/LlswXT8uaWQgPz8gXCJcIik7XG4gICAgc2V0V29ya2Zsb3dSdW5JZCgoZXhlY3V0aW9uUnVucz8uWzBdPy5faWQgYXMgc3RyaW5nIHwgdW5kZWZpbmVkKSA/PyBcIlwiKTtcbiAgfSwgW3dvcmtPcmRlciwgZXhlY3V0aW9uUnVucywgb3Blbl0pO1xuXG4gIGNvbnN0IHdhaXZlck9wdGlvbnMgPSBhcHByb3ZhbERlY2lzaW9ucy5maWx0ZXIoKGFwcHJvdmFsKSA9PiBhcHByb3ZhbC5zdGF0dXMgPT09IFwiQVBQUk9WRURcIiB8fCBhcHByb3ZhbC5zdGF0dXMgPT09IFwiQ09ORElUSU9OQUxcIik7XG5cbiAgcmV0dXJuIChcbiAgICA8RGlhbG9nIG9wZW49e29wZW59IG9uT3BlbkNoYW5nZT17KG5leHQpID0+ICFuZXh0ICYmIG9uQ2xvc2UoKX0+XG4gICAgICA8RGlhbG9nQ29udGVudCBjbGFzc05hbWU9XCJzbTptYXgtdy1bNzIwcHhdXCI+XG4gICAgICAgIDxEaWFsb2dIZWFkZXI+XG4gICAgICAgICAgPERpYWxvZ1RpdGxlPlJlY29yZCB2ZXJpZmljYXRpb24gcmVjZWlwdDwvRGlhbG9nVGl0bGU+XG4gICAgICAgICAgPERpYWxvZ0Rlc2NyaXB0aW9uPkF0dGFjaCBldmlkZW5jZSB0byBvbmUgYWNjZXB0YW5jZSBjcml0ZXJpb24gYW5kIG1hcmsgd2hldGhlciBpdCBwYXNzZWQsIGZhaWxlZCwgb3Igd2FzIHdhaXZlZC48L0RpYWxvZ0Rlc2NyaXB0aW9uPlxuICAgICAgICA8L0RpYWxvZ0hlYWRlcj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC00IG1kOmdyaWQtY29scy0yXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgPExhYmVsPkFjY2VwdGFuY2UgY3JpdGVyaW9uPC9MYWJlbD5cbiAgICAgICAgICAgICAgPFNlbGVjdCB2YWx1ZT17YWNjZXB0YW5jZUNyaXRlcmlvbklkfSBvblZhbHVlQ2hhbmdlPXtzZXRBY2NlcHRhbmNlQ3JpdGVyaW9uSWR9PlxuICAgICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyPjxTZWxlY3RWYWx1ZSAvPjwvU2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICAgIHsod29ya09yZGVyPy5hY2NlcHRhbmNlQ3JpdGVyaWEgPz8gW10pLm1hcCgoY3JpdGVyaW9uOiBhbnkpID0+IDxTZWxlY3RJdGVtIGtleT17Y3JpdGVyaW9uLmlkfSB2YWx1ZT17Y3JpdGVyaW9uLmlkfT57Y3JpdGVyaW9uLnRpdGxlfTwvU2VsZWN0SXRlbT4pfVxuICAgICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgPExhYmVsPkV4ZWN1dGlvbiBydW48L0xhYmVsPlxuICAgICAgICAgICAgICA8U2VsZWN0IHZhbHVlPXt3b3JrZmxvd1J1bklkfSBvblZhbHVlQ2hhbmdlPXtzZXRXb3JrZmxvd1J1bklkfT5cbiAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlcj48U2VsZWN0VmFsdWUgLz48L1NlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICB7ZXhlY3V0aW9uUnVucy5tYXAoKHJ1bikgPT4gPFNlbGVjdEl0ZW0ga2V5PXtydW4uX2lkfSB2YWx1ZT17cnVuLl9pZH0+e3J1bi5ydW5JZH0gwrcge3J1bi5zdGF0dXN9PC9TZWxlY3RJdGVtPil9XG4gICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0zIG1kOmdyaWQtY29scy0yXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICA8TGFiZWw+TWV0aG9kPC9MYWJlbD5cbiAgICAgICAgICAgICAgICA8U2VsZWN0IHZhbHVlPXt2ZXJpZmljYXRpb25NZXRob2R9IG9uVmFsdWVDaGFuZ2U9e3NldFZlcmlmaWNhdGlvbk1ldGhvZH0+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlcj48U2VsZWN0VmFsdWUgLz48L1NlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICAgICAge1snTUFOVUFMJywgJ0NPTU1BTkQnLCAnVEVTVCcsICdDSEVDS0xJU1QnXS5tYXAoKG9wdGlvbikgPT4gPFNlbGVjdEl0ZW0ga2V5PXtvcHRpb259IHZhbHVlPXtvcHRpb259PntvcHRpb259PC9TZWxlY3RJdGVtPil9XG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgPExhYmVsPlN0YXR1czwvTGFiZWw+XG4gICAgICAgICAgICAgICAgPFNlbGVjdCB2YWx1ZT17c3RhdHVzfSBvblZhbHVlQ2hhbmdlPXtzZXRTdGF0dXN9PlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXI+PFNlbGVjdFZhbHVlIC8+PC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICAgIHtbJ1BBU1NFRCcsICdGQUlMRUQnLCAnV0FJVkVEJywgJ1BFTkRJTkcnXS5tYXAoKG9wdGlvbikgPT4gPFNlbGVjdEl0ZW0ga2V5PXtvcHRpb259IHZhbHVlPXtvcHRpb259PntvcHRpb259PC9TZWxlY3RJdGVtPil9XG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+PExhYmVsPlZlcmlmaWVyPC9MYWJlbD48SW5wdXQgdmFsdWU9e3ZlcmlmaWVyfSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRWZXJpZmllcihldmVudC50YXJnZXQudmFsdWUpfSAvPjwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj48TGFiZWw+Q29tbWFuZCBvciBjaGVjazwvTGFiZWw+PElucHV0IHZhbHVlPXtjb21tYW5kT3JDaGVja30gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0Q29tbWFuZE9yQ2hlY2soZXZlbnQudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJwbnBtIC0tZmlsdGVyIG1pc3Npb24tY29udHJvbC11aSBidWlsZFwiIC8+PC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+PExhYmVsPlJlc3VsdDwvTGFiZWw+PFRleHRhcmVhIHZhbHVlPXtyZXN1bHR9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFJlc3VsdChldmVudC50YXJnZXQudmFsdWUpfSByb3dzPXszfSBwbGFjZWhvbGRlcj1cIkJ1aWxkIGNvbXBsZXRlZCBzdWNjZXNzZnVsbHlcIiAvPjwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPjxMYWJlbD5FdmlkZW5jZSBsb2NhdGlvbjwvTGFiZWw+PElucHV0IHZhbHVlPXtldmlkZW5jZUxvY2F0aW9ufSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRFdmlkZW5jZUxvY2F0aW9uKGV2ZW50LnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiZG9jcy9zb2Z0d2FyZS1mYWN0b3J5L3ZlcmlmaWNhdGlvbi1yZWNlaXB0Lm1kXCIgLz48L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj48TGFiZWw+QXJ0aWZhY3QgcmVmZXJlbmNlPC9MYWJlbD48SW5wdXQgdmFsdWU9e2FydGlmYWN0UmVmZXJlbmNlfSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRBcnRpZmFjdFJlZmVyZW5jZShldmVudC50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cInRtcC9zY3JlZW5zaG90LnBuZyBvciBQUiBVUkxcIiAvPjwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPjxMYWJlbD5FeGNlcHRpb24gLyB3YWl2ZXIgbm90ZTwvTGFiZWw+PElucHV0IHZhbHVlPXtleGNlcHRpb25PcldhaXZlcn0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0RXhjZXB0aW9uT3JXYWl2ZXIoZXZlbnQudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJXaHkgYSB3YWl2ZXIgaXMgYWNjZXB0YWJsZVwiIC8+PC9kaXY+XG4gICAgICAgICAgICB7c3RhdHVzID09PSBcIldBSVZFRFwiID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgPExhYmVsPldhaXZlciBhcHByb3ZhbDwvTGFiZWw+XG4gICAgICAgICAgICAgICAgPFNlbGVjdCB2YWx1ZT17d2FpdmVyQXBwcm92YWxEZWNpc2lvbklkfSBvblZhbHVlQ2hhbmdlPXtzZXRXYWl2ZXJBcHByb3ZhbERlY2lzaW9uSWR9PlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXI+PFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiU2VsZWN0IGFwcHJvdmVkIGRlY2lzaW9uXCIgLz48L1NlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICAgICAge3dhaXZlck9wdGlvbnMubWFwKChhcHByb3ZhbCkgPT4gPFNlbGVjdEl0ZW0ga2V5PXthcHByb3ZhbC5faWR9IHZhbHVlPXthcHByb3ZhbC5faWR9PnthcHByb3ZhbC5hcHByb3ZhbFR5cGV9IMK3IHthcHByb3ZhbC5zdGF0dXN9PC9TZWxlY3RJdGVtPil9XG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8RGlhbG9nRm9vdGVyPlxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17b25DbG9zZX0+Q2FuY2VsPC9CdXR0b24+XG4gICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBvbkNyZWF0ZSh7IGFjY2VwdGFuY2VDcml0ZXJpb25JZCwgd29ya2Zsb3dSdW5JZCwgdmVyaWZpY2F0aW9uTWV0aG9kLCBjb21tYW5kT3JDaGVjaywgcmVzdWx0LCBldmlkZW5jZUxvY2F0aW9uLCBhcnRpZmFjdFJlZmVyZW5jZSwgdmVyaWZpZXIsIHN0YXR1cywgZXhjZXB0aW9uT3JXYWl2ZXIsIHdhaXZlckFwcHJvdmFsRGVjaXNpb25JZCB9KX0gZGlzYWJsZWQ9e2NyZWF0aW5nIHx8ICFhY2NlcHRhbmNlQ3JpdGVyaW9uSWQgfHwgIXdvcmtmbG93UnVuSWR9PntjcmVhdGluZyA/IFwiUmVjb3JkaW5n4oCmXCIgOiBcIlJlY29yZCByZWNlaXB0XCJ9PC9CdXR0b24+XG4gICAgICAgIDwvRGlhbG9nRm9vdGVyPlxuICAgICAgPC9EaWFsb2dDb250ZW50PlxuICAgIDwvRGlhbG9nPlxuICApO1xufVxuXG5mdW5jdGlvbiBSZXF1ZXN0UmV2aXNpb25EaWFsb2coe1xuICBvcGVuLFxuICB3b3JrT3JkZXIsXG4gIGNyZWF0aW5nLFxuICBvbkNsb3NlLFxuICBvbkNyZWF0ZSxcbn06IHtcbiAgb3BlbjogYm9vbGVhbjtcbiAgd29ya09yZGVyOiBhbnk7XG4gIGNyZWF0aW5nOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBvbkNyZWF0ZTogKHBheWxvYWQ6IHtcbiAgICBjaGFuZ2VTdW1tYXJ5OiBzdHJpbmc7XG4gICAgcmVhc29uOiBzdHJpbmc7XG4gICAgcmVxdWVzdGVkQnk6IHN0cmluZztcbiAgICBkZXNpcmVkT3V0Y29tZTogc3RyaW5nO1xuICAgIHdvcmtmbG93SWQ6IHN0cmluZztcbiAgICByZXBvc2l0b3J5OiBzdHJpbmc7XG4gICAgcmlza0xldmVsOiBzdHJpbmc7XG4gICAgcmVxdWlyZWRBcHByb3ZhbHM6IHN0cmluZ1tdO1xuICAgIGFjY2VwdGFuY2VDcml0ZXJpYTogc3RyaW5nO1xuICB9KSA9PiBQcm9taXNlPHZvaWQ+O1xufSkge1xuICBjb25zdCBbY2hhbmdlU3VtbWFyeSwgc2V0Q2hhbmdlU3VtbWFyeV0gPSB1c2VTdGF0ZShcIkNsYXJpZnkgb3IgcmV2aXNlIFdvcmtPcmRlciBzY29wZVwiKTtcbiAgY29uc3QgW3JlYXNvbiwgc2V0UmVhc29uXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbcmVxdWVzdGVkQnksIHNldFJlcXVlc3RlZEJ5XSA9IHVzZVN0YXRlKFwib3BlcmF0b3JcIik7XG4gIGNvbnN0IFtkZXNpcmVkT3V0Y29tZSwgc2V0RGVzaXJlZE91dGNvbWVdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFt3b3JrZmxvd0lkLCBzZXRXb3JrZmxvd0lkXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbcmVwb3NpdG9yeSwgc2V0UmVwb3NpdG9yeV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3Jpc2tMZXZlbCwgc2V0Umlza0xldmVsXSA9IHVzZVN0YXRlKFwiTUVESVVNXCIpO1xuICBjb25zdCBbcmVxdWlyZWRBcHByb3ZhbHNUZXh0LCBzZXRSZXF1aXJlZEFwcHJvdmFsc1RleHRdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFthY2NlcHRhbmNlQ3JpdGVyaWEsIHNldEFjY2VwdGFuY2VDcml0ZXJpYV0gPSB1c2VTdGF0ZShcIlwiKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghb3BlbiB8fCAhd29ya09yZGVyKSByZXR1cm47XG4gICAgc2V0RGVzaXJlZE91dGNvbWUod29ya09yZGVyLmRlc2lyZWRPdXRjb21lID8/IFwiXCIpO1xuICAgIHNldFdvcmtmbG93SWQod29ya09yZGVyLndvcmtmbG93SWQgPz8gXCJcIik7XG4gICAgc2V0UmVwb3NpdG9yeSh3b3JrT3JkZXIucmVwb3NpdG9yeSA/PyBcIlwiKTtcbiAgICBzZXRSaXNrTGV2ZWwod29ya09yZGVyLnJpc2tMZXZlbCA/PyBcIk1FRElVTVwiKTtcbiAgICBzZXRSZXF1aXJlZEFwcHJvdmFsc1RleHQoKHdvcmtPcmRlci5yZXF1aXJlZEFwcHJvdmFscyA/PyBbXSkuam9pbihcIlxcblwiKSk7XG4gICAgc2V0QWNjZXB0YW5jZUNyaXRlcmlhKCh3b3JrT3JkZXIuYWNjZXB0YW5jZUNyaXRlcmlhID8/IFtdKS5tYXAoKGNyaXRlcmlvbjogYW55KSA9PiBjcml0ZXJpb24udGl0bGUpLmpvaW4oXCJcXG5cIikpO1xuICB9LCBbb3Blbiwgd29ya09yZGVyXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8RGlhbG9nIG9wZW49e29wZW59IG9uT3BlbkNoYW5nZT17KG5leHQpID0+ICFuZXh0ICYmIG9uQ2xvc2UoKX0+XG4gICAgICA8RGlhbG9nQ29udGVudCBjbGFzc05hbWU9XCJzbTptYXgtdy1bNzYwcHhdXCI+XG4gICAgICAgIDxEaWFsb2dIZWFkZXI+XG4gICAgICAgICAgPERpYWxvZ1RpdGxlPlJlcXVlc3QgV29ya09yZGVyIHJldmlzaW9uPC9EaWFsb2dUaXRsZT5cbiAgICAgICAgICA8RGlhbG9nRGVzY3JpcHRpb24+VmVyc2lvbiBhIGNvbnRyb2xsZWQgcmV2aXNpb24uIEFjY2VwdGVkIHdvcmsgc3RheXMgaW1tdXRhYmxlIHVudGlsIGEgcmV2aXNpb24gaXMgZXhwbGljaXRseSBhcHBsaWVkLjwvRGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgIDwvRGlhbG9nSGVhZGVyPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTQgbWQ6Z3JpZC1jb2xzLTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPjxMYWJlbD5DaGFuZ2Ugc3VtbWFyeTwvTGFiZWw+PElucHV0IHZhbHVlPXtjaGFuZ2VTdW1tYXJ5fSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRDaGFuZ2VTdW1tYXJ5KGV2ZW50LnRhcmdldC52YWx1ZSl9IC8+PC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+PExhYmVsPlJlYXNvbjwvTGFiZWw+PFRleHRhcmVhIHZhbHVlPXtyZWFzb259IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFJlYXNvbihldmVudC50YXJnZXQudmFsdWUpfSByb3dzPXs0fSBwbGFjZWhvbGRlcj1cIldoeSBkb2VzIHRoaXMgcmV2aXNpb24gbmVlZCB0byBoYXBwZW4/XCIgLz48L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj48TGFiZWw+UmVxdWVzdGVkIGJ5PC9MYWJlbD48SW5wdXQgdmFsdWU9e3JlcXVlc3RlZEJ5fSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRSZXF1ZXN0ZWRCeShldmVudC50YXJnZXQudmFsdWUpfSAvPjwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPjxMYWJlbD5EZXNpcmVkIG91dGNvbWU8L0xhYmVsPjxUZXh0YXJlYSB2YWx1ZT17ZGVzaXJlZE91dGNvbWV9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldERlc2lyZWRPdXRjb21lKGV2ZW50LnRhcmdldC52YWx1ZSl9IHJvd3M9ezR9IC8+PC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtMyBtZDpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+PExhYmVsPldvcmtmbG93PC9MYWJlbD48SW5wdXQgdmFsdWU9e3dvcmtmbG93SWR9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFdvcmtmbG93SWQoZXZlbnQudGFyZ2V0LnZhbHVlKX0gLz48L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPjxMYWJlbD5SZXBvc2l0b3J5PC9MYWJlbD48SW5wdXQgdmFsdWU9e3JlcG9zaXRvcnl9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFJlcG9zaXRvcnkoZXZlbnQudGFyZ2V0LnZhbHVlKX0gLz48L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICA8TGFiZWw+UmlzayBsZXZlbDwvTGFiZWw+XG4gICAgICAgICAgICAgIDxTZWxlY3QgdmFsdWU9e3Jpc2tMZXZlbH0gb25WYWx1ZUNoYW5nZT17c2V0Umlza0xldmVsfT5cbiAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlcj48U2VsZWN0VmFsdWUgLz48L1NlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+e1tcIkxPV1wiLCBcIk1FRElVTVwiLCBcIkhJR0hcIiwgXCJDUklUSUNBTFwiXS5tYXAoKG9wdGlvbikgPT4gPFNlbGVjdEl0ZW0ga2V5PXtvcHRpb259IHZhbHVlPXtvcHRpb259PntvcHRpb259PC9TZWxlY3RJdGVtPil9PC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPjxMYWJlbD5SZXF1aXJlZCBhcHByb3ZhbHM8L0xhYmVsPjxUZXh0YXJlYSB2YWx1ZT17cmVxdWlyZWRBcHByb3ZhbHNUZXh0fSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRSZXF1aXJlZEFwcHJvdmFsc1RleHQoZXZlbnQudGFyZ2V0LnZhbHVlKX0gcm93cz17M30gcGxhY2Vob2xkZXI9XCJPbmUgcGVyIGxpbmVcIiAvPjwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPjxMYWJlbD5BY2NlcHRhbmNlIGNyaXRlcmlhPC9MYWJlbD48VGV4dGFyZWEgdmFsdWU9e2FjY2VwdGFuY2VDcml0ZXJpYX0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0QWNjZXB0YW5jZUNyaXRlcmlhKGV2ZW50LnRhcmdldC52YWx1ZSl9IHJvd3M9ezV9IHBsYWNlaG9sZGVyPVwiT25lIGNyaXRlcmlvbiBwZXIgbGluZVwiIC8+PC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8RGlhbG9nRm9vdGVyPlxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17b25DbG9zZX0+Q2FuY2VsPC9CdXR0b24+XG4gICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBvbkNyZWF0ZSh7XG4gICAgICAgICAgICBjaGFuZ2VTdW1tYXJ5LFxuICAgICAgICAgICAgcmVhc29uLFxuICAgICAgICAgICAgcmVxdWVzdGVkQnksXG4gICAgICAgICAgICBkZXNpcmVkT3V0Y29tZSxcbiAgICAgICAgICAgIHdvcmtmbG93SWQsXG4gICAgICAgICAgICByZXBvc2l0b3J5LFxuICAgICAgICAgICAgcmlza0xldmVsLFxuICAgICAgICAgICAgcmVxdWlyZWRBcHByb3ZhbHM6IHJlcXVpcmVkQXBwcm92YWxzVGV4dC5zcGxpdChcIlxcblwiKS5tYXAoKGxpbmUpID0+IGxpbmUudHJpbSgpKS5maWx0ZXIoQm9vbGVhbiksXG4gICAgICAgICAgICBhY2NlcHRhbmNlQ3JpdGVyaWEsXG4gICAgICAgICAgfSl9IGRpc2FibGVkPXtjcmVhdGluZyB8fCAhY2hhbmdlU3VtbWFyeS50cmltKCkgfHwgIXJlYXNvbi50cmltKCl9PntjcmVhdGluZyA/IFwiU2F2aW5n4oCmXCIgOiBcIlJlcXVlc3QgcmV2aXNpb25cIn08L0J1dHRvbj5cbiAgICAgICAgPC9EaWFsb2dGb290ZXI+XG4gICAgICA8L0RpYWxvZ0NvbnRlbnQ+XG4gICAgPC9EaWFsb2c+XG4gICk7XG59XG5cbmZ1bmN0aW9uIFJlb3BlbldvcmtPcmRlckRpYWxvZyh7XG4gIG9wZW4sXG4gIHdvcmtPcmRlcixcbiAgY3JlYXRpbmcsXG4gIG9uQ2xvc2UsXG4gIG9uQ3JlYXRlLFxufToge1xuICBvcGVuOiBib29sZWFuO1xuICB3b3JrT3JkZXI6IGFueTtcbiAgY3JlYXRpbmc6IGJvb2xlYW47XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gIG9uQ3JlYXRlOiAocGF5bG9hZDoge1xuICAgIHJlYXNvbjogc3RyaW5nO1xuICAgIHNvdXJjZUlzc3VlT3JEZWZlY3Q6IHN0cmluZztcbiAgICByZXF1ZXN0ZWRCeTogc3RyaW5nO1xuICAgIGFwcHJvdmVkQnk6IHN0cmluZztcbiAgICByZW9wZW5TY29wZTogc3RyaW5nO1xuICAgIGFjY2VwdGFuY2VDcml0ZXJpYUltcGFjdGVkOiBzdHJpbmdbXTtcbiAgICBuZXdSZXF1aXJlZEFjdGlvbnM6IHN0cmluZ1tdO1xuICB9KSA9PiBQcm9taXNlPHZvaWQ+O1xufSkge1xuICBjb25zdCBbcmVhc29uLCBzZXRSZWFzb25dID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtzb3VyY2VJc3N1ZU9yRGVmZWN0LCBzZXRTb3VyY2VJc3N1ZU9yRGVmZWN0XSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbcmVxdWVzdGVkQnksIHNldFJlcXVlc3RlZEJ5XSA9IHVzZVN0YXRlKFwib3BlcmF0b3JcIik7XG4gIGNvbnN0IFthcHByb3ZlZEJ5LCBzZXRBcHByb3ZlZEJ5XSA9IHVzZVN0YXRlKFwib3BlcmF0b3JcIik7XG4gIGNvbnN0IFtyZW9wZW5TY29wZSwgc2V0UmVvcGVuU2NvcGVdID0gdXNlU3RhdGUoXCJmdWxsLXdvcmtvcmRlclwiKTtcbiAgY29uc3QgW2FjY2VwdGFuY2VDcml0ZXJpYUltcGFjdGVkVGV4dCwgc2V0QWNjZXB0YW5jZUNyaXRlcmlhSW1wYWN0ZWRUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbbmV3UmVxdWlyZWRBY3Rpb25zVGV4dCwgc2V0TmV3UmVxdWlyZWRBY3Rpb25zVGV4dF0gPSB1c2VTdGF0ZShcIlJldmlldyBkZWZlY3RcXG5SZWNvcmQgcmVwbGFjZW1lbnQgZXZpZGVuY2VcXG5SZWRpc3BhdGNoIGlmIGltcGxlbWVudGF0aW9uIG11c3QgY2hhbmdlXCIpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFvcGVuIHx8ICF3b3JrT3JkZXIpIHJldHVybjtcbiAgICBzZXRBY2NlcHRhbmNlQ3JpdGVyaWFJbXBhY3RlZFRleHQoKHdvcmtPcmRlci5hY2NlcHRhbmNlQ3JpdGVyaWEgPz8gW10pLm1hcCgoY3JpdGVyaW9uOiBhbnkpID0+IGNyaXRlcmlvbi5pZCkuam9pbihcIlxcblwiKSk7XG4gIH0sIFtvcGVuLCB3b3JrT3JkZXJdKTtcblxuICByZXR1cm4gKFxuICAgIDxEaWFsb2cgb3Blbj17b3Blbn0gb25PcGVuQ2hhbmdlPXsobmV4dCkgPT4gIW5leHQgJiYgb25DbG9zZSgpfT5cbiAgICAgIDxEaWFsb2dDb250ZW50IGNsYXNzTmFtZT1cInNtOm1heC13LVs3MjBweF1cIj5cbiAgICAgICAgPERpYWxvZ0hlYWRlcj5cbiAgICAgICAgICA8RGlhbG9nVGl0bGU+UmVvcGVuIFdvcmtPcmRlcjwvRGlhbG9nVGl0bGU+XG4gICAgICAgICAgPERpYWxvZ0Rlc2NyaXB0aW9uPlByZXNlcnZlIHByaW9yIGV2aWRlbmNlIGFuZCBleHBsaWNpdGx5IG1hcmsgd2hhdCBiZWNhbWUgaW52YWxpZCBhbmQgd2hhdCBtdXN0IGhhcHBlbiBuZXh0LjwvRGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgIDwvRGlhbG9nSGVhZGVyPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj48TGFiZWw+UmVhc29uPC9MYWJlbD48VGV4dGFyZWEgdmFsdWU9e3JlYXNvbn0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0UmVhc29uKGV2ZW50LnRhcmdldC52YWx1ZSl9IHJvd3M9ezN9IHBsYWNlaG9sZGVyPVwiRGVmZWN0IGRpc2NvdmVyZWQsIGV2aWRlbmNlIGludmFsaWRhdGVkLCByZXZpZXdlciByZXF1ZXN0ZWQgY29ycmVjdGlvbuKAplwiIC8+PC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPjxMYWJlbD5Tb3VyY2UgaXNzdWUgb3IgZGVmZWN0PC9MYWJlbD48SW5wdXQgdmFsdWU9e3NvdXJjZUlzc3VlT3JEZWZlY3R9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFNvdXJjZUlzc3VlT3JEZWZlY3QoZXZlbnQudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJJc3N1ZSAvIGRlZmVjdCAvIGluY2lkZW50IHJlZmVyZW5jZVwiIC8+PC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0zIG1kOmdyaWQtY29scy0zXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+PExhYmVsPlJlcXVlc3RlZCBieTwvTGFiZWw+PElucHV0IHZhbHVlPXtyZXF1ZXN0ZWRCeX0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0UmVxdWVzdGVkQnkoZXZlbnQudGFyZ2V0LnZhbHVlKX0gLz48L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj48TGFiZWw+QXBwcm92ZWQgYnk8L0xhYmVsPjxJbnB1dCB2YWx1ZT17YXBwcm92ZWRCeX0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0QXBwcm92ZWRCeShldmVudC50YXJnZXQudmFsdWUpfSAvPjwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPjxMYWJlbD5SZW9wZW4gc2NvcGU8L0xhYmVsPjxJbnB1dCB2YWx1ZT17cmVvcGVuU2NvcGV9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFJlb3BlblNjb3BlKGV2ZW50LnRhcmdldC52YWx1ZSl9IC8+PC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0zIG1kOmdyaWQtY29scy0yXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+PExhYmVsPkltcGFjdGVkIGNyaXRlcmlhIElEczwvTGFiZWw+PFRleHRhcmVhIHZhbHVlPXthY2NlcHRhbmNlQ3JpdGVyaWFJbXBhY3RlZFRleHR9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldEFjY2VwdGFuY2VDcml0ZXJpYUltcGFjdGVkVGV4dChldmVudC50YXJnZXQudmFsdWUpfSByb3dzPXs0fSAvPjwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPjxMYWJlbD5OZXcgcmVxdWlyZWQgYWN0aW9uczwvTGFiZWw+PFRleHRhcmVhIHZhbHVlPXtuZXdSZXF1aXJlZEFjdGlvbnNUZXh0fSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXROZXdSZXF1aXJlZEFjdGlvbnNUZXh0KGV2ZW50LnRhcmdldC52YWx1ZSl9IHJvd3M9ezR9IC8+PC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8RGlhbG9nRm9vdGVyPlxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17b25DbG9zZX0+Q2FuY2VsPC9CdXR0b24+XG4gICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBvbkNyZWF0ZSh7XG4gICAgICAgICAgICByZWFzb24sXG4gICAgICAgICAgICBzb3VyY2VJc3N1ZU9yRGVmZWN0LFxuICAgICAgICAgICAgcmVxdWVzdGVkQnksXG4gICAgICAgICAgICBhcHByb3ZlZEJ5LFxuICAgICAgICAgICAgcmVvcGVuU2NvcGUsXG4gICAgICAgICAgICBhY2NlcHRhbmNlQ3JpdGVyaWFJbXBhY3RlZDogYWNjZXB0YW5jZUNyaXRlcmlhSW1wYWN0ZWRUZXh0LnNwbGl0KFwiXFxuXCIpLm1hcCgobGluZSkgPT4gbGluZS50cmltKCkpLmZpbHRlcihCb29sZWFuKSxcbiAgICAgICAgICAgIG5ld1JlcXVpcmVkQWN0aW9uczogbmV3UmVxdWlyZWRBY3Rpb25zVGV4dC5zcGxpdChcIlxcblwiKS5tYXAoKGxpbmUpID0+IGxpbmUudHJpbSgpKS5maWx0ZXIoQm9vbGVhbiksXG4gICAgICAgICAgfSl9IGRpc2FibGVkPXtjcmVhdGluZyB8fCAhcmVhc29uLnRyaW0oKX0+e2NyZWF0aW5nID8gXCJSZW9wZW5pbmfigKZcIiA6IFwiUmVvcGVuIFdvcmtPcmRlclwifTwvQnV0dG9uPlxuICAgICAgICA8L0RpYWxvZ0Zvb3Rlcj5cbiAgICAgIDwvRGlhbG9nQ29udGVudD5cbiAgICA8L0RpYWxvZz5cbiAgKTtcbn1cblxuZnVuY3Rpb24gU3VwZXJzZWRlV29ya09yZGVyRGlhbG9nKHtcbiAgb3BlbixcbiAgd29ya09yZGVycyxcbiAgY3VycmVudFdvcmtPcmRlcklkLFxuICBjcmVhdGluZyxcbiAgb25DbG9zZSxcbiAgb25DcmVhdGUsXG59OiB7XG4gIG9wZW46IGJvb2xlYW47XG4gIHdvcmtPcmRlcnM6IGFueVtdO1xuICBjdXJyZW50V29ya09yZGVySWQ6IHN0cmluZyB8IG51bGw7XG4gIGNyZWF0aW5nOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBvbkNyZWF0ZTogKHBheWxvYWQ6IHsgcmVwbGFjZW1lbnRXb3JrT3JkZXJJZDogc3RyaW5nOyByZWFzb246IHN0cmluZzsgYWN0b3JJZDogc3RyaW5nIH0pID0+IFByb21pc2U8dm9pZD47XG59KSB7XG4gIGNvbnN0IFtyZXBsYWNlbWVudFdvcmtPcmRlcklkLCBzZXRSZXBsYWNlbWVudFdvcmtPcmRlcklkXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbcmVhc29uLCBzZXRSZWFzb25dID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFthY3RvcklkLCBzZXRBY3RvcklkXSA9IHVzZVN0YXRlKFwib3BlcmF0b3JcIik7XG5cbiAgY29uc3Qgb3B0aW9ucyA9ICh3b3JrT3JkZXJzID8/IFtdKS5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0uX2lkICE9PSBjdXJyZW50V29ya09yZGVySWQpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFvcGVuKSByZXR1cm47XG4gICAgc2V0UmVwbGFjZW1lbnRXb3JrT3JkZXJJZChvcHRpb25zWzBdPy5faWQgPz8gXCJcIik7XG4gIH0sIFtvcGVuLCBjdXJyZW50V29ya09yZGVySWRdKTtcblxuICByZXR1cm4gKFxuICAgIDxEaWFsb2cgb3Blbj17b3Blbn0gb25PcGVuQ2hhbmdlPXsobmV4dCkgPT4gIW5leHQgJiYgb25DbG9zZSgpfT5cbiAgICAgIDxEaWFsb2dDb250ZW50IGNsYXNzTmFtZT1cInNtOm1heC13LVs2MjBweF1cIj5cbiAgICAgICAgPERpYWxvZ0hlYWRlcj5cbiAgICAgICAgICA8RGlhbG9nVGl0bGU+U3VwZXJzZWRlIFdvcmtPcmRlcjwvRGlhbG9nVGl0bGU+XG4gICAgICAgICAgPERpYWxvZ0Rlc2NyaXB0aW9uPkxpbmsgdGhpcyBXb3JrT3JkZXIgdG8gaXRzIGF1dGhvcml0YXRpdmUgcmVwbGFjZW1lbnQgd2l0aG91dCBsb3NpbmcgdW5yZXNvbHZlZCBvYmxpZ2F0aW9ucyBvciBldmlkZW5jZSBoaXN0b3J5LjwvRGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgIDwvRGlhbG9nSGVhZGVyPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgIDxMYWJlbD5SZXBsYWNlbWVudCBXb3JrT3JkZXI8L0xhYmVsPlxuICAgICAgICAgICAgPFNlbGVjdCB2YWx1ZT17cmVwbGFjZW1lbnRXb3JrT3JkZXJJZH0gb25WYWx1ZUNoYW5nZT17c2V0UmVwbGFjZW1lbnRXb3JrT3JkZXJJZH0+XG4gICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyPjxTZWxlY3RWYWx1ZSAvPjwvU2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAge29wdGlvbnMubWFwKChvcHRpb24pID0+IDxTZWxlY3RJdGVtIGtleT17b3B0aW9uLl9pZH0gdmFsdWU9e29wdGlvbi5faWR9PntvcHRpb24udGl0bGV9PC9TZWxlY3RJdGVtPil9XG4gICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgIDwvU2VsZWN0PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj48TGFiZWw+UmVhc29uPC9MYWJlbD48VGV4dGFyZWEgdmFsdWU9e3JlYXNvbn0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0UmVhc29uKGV2ZW50LnRhcmdldC52YWx1ZSl9IHJvd3M9ezN9IC8+PC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPjxMYWJlbD5BY3RvcjwvTGFiZWw+PElucHV0IHZhbHVlPXthY3RvcklkfSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRBY3RvcklkKGV2ZW50LnRhcmdldC52YWx1ZSl9IC8+PC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8RGlhbG9nRm9vdGVyPlxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17b25DbG9zZX0+Q2FuY2VsPC9CdXR0b24+XG4gICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBvbkNyZWF0ZSh7IHJlcGxhY2VtZW50V29ya09yZGVySWQsIHJlYXNvbiwgYWN0b3JJZCB9KX0gZGlzYWJsZWQ9e2NyZWF0aW5nIHx8ICFyZXBsYWNlbWVudFdvcmtPcmRlcklkIHx8ICFyZWFzb24udHJpbSgpfT57Y3JlYXRpbmcgPyBcIlN1cGVyc2VkaW5n4oCmXCIgOiBcIlN1cGVyc2VkZSBXb3JrT3JkZXJcIn08L0J1dHRvbj5cbiAgICAgICAgPC9EaWFsb2dGb290ZXI+XG4gICAgICA8L0RpYWxvZ0NvbnRlbnQ+XG4gICAgPC9EaWFsb2c+XG4gICk7XG59XG5cbmZ1bmN0aW9uIENyZWF0ZVdvcmtPcmRlckRpYWxvZyh7XG4gIG9wZW4sXG4gIGNyZWF0aW5nLFxuICBlcnJvcixcbiAgb25DbG9zZSxcbiAgb25DcmVhdGUsXG59OiB7XG4gIG9wZW46IGJvb2xlYW47XG4gIGNyZWF0aW5nOiBib29sZWFuO1xuICBlcnJvcjogc3RyaW5nIHwgbnVsbDtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbiAgb25DcmVhdGU6IChwYXlsb2FkOiB7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBkZXNpcmVkT3V0Y29tZTogc3RyaW5nO1xuICAgIGNvbnRleHQ6IHN0cmluZztcbiAgICB3b3JrZmxvd0lkOiBzdHJpbmc7XG4gICAgcmVwb3NpdG9yeTogc3RyaW5nO1xuICAgIGJyYW5jaFN0cmF0ZWd5OiBzdHJpbmc7XG4gICAgcHJpb3JpdHk6IHN0cmluZztcbiAgICByaXNrTGV2ZWw6IHN0cmluZztcbiAgICByZXF1ZXN0ZWRCeTogc3RyaW5nO1xuICAgIGFzc2lnbmVkQWdlbnQ6IHN0cmluZztcbiAgICBhY2NlcHRhbmNlQ3JpdGVyaWE6IHN0cmluZztcbiAgfSkgPT4gUHJvbWlzZTx2b2lkPjtcbn0pIHtcbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2Rlc2lyZWRPdXRjb21lLCBzZXREZXNpcmVkT3V0Y29tZV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2NvbnRleHQsIHNldENvbnRleHRdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFt3b3JrZmxvd0lkLCBzZXRXb3JrZmxvd0lkXSA9IHVzZVN0YXRlKFwiZmVhdHVyZS1kZXZcIik7XG4gIGNvbnN0IFtyZXBvc2l0b3J5LCBzZXRSZXBvc2l0b3J5XSA9IHVzZVN0YXRlKFwiamF5ZHVieWE4MTgvTWlzc2lvbkNvbnRyb2xcIik7XG4gIGNvbnN0IFticmFuY2hTdHJhdGVneSwgc2V0QnJhbmNoU3RyYXRlZ3ldID0gdXNlU3RhdGUoXCJpc29sYXRlZCBmZWF0dXJlIGJyYW5jaCBhbmQgd29ya3RyZWVcIik7XG4gIGNvbnN0IFtwcmlvcml0eSwgc2V0UHJpb3JpdHldID0gdXNlU3RhdGUoXCIyXCIpO1xuICBjb25zdCBbcmlza0xldmVsLCBzZXRSaXNrTGV2ZWxdID0gdXNlU3RhdGUoXCJNRURJVU1cIik7XG4gIGNvbnN0IFtyZXF1ZXN0ZWRCeSwgc2V0UmVxdWVzdGVkQnldID0gdXNlU3RhdGUoXCJIZXJtZXNcIik7XG4gIGNvbnN0IFthc3NpZ25lZEFnZW50LCBzZXRBc3NpZ25lZEFnZW50XSA9IHVzZVN0YXRlKFwiUGlcIik7XG4gIGNvbnN0IFthY2NlcHRhbmNlQ3JpdGVyaWEsIHNldEFjY2VwdGFuY2VDcml0ZXJpYV0gPSB1c2VTdGF0ZShcIlwiKTtcblxuICByZXR1cm4gKFxuICAgIDxEaWFsb2cgb3Blbj17b3Blbn0gb25PcGVuQ2hhbmdlPXsobmV4dCkgPT4gIW5leHQgJiYgb25DbG9zZSgpfT5cbiAgICAgIDxEaWFsb2dDb250ZW50IGNsYXNzTmFtZT1cInNtOm1heC13LVs3MjBweF1cIj5cbiAgICAgICAgPERpYWxvZ0hlYWRlcj5cbiAgICAgICAgICA8RGlhbG9nVGl0bGU+Q3JlYXRlIFdvcmtPcmRlcjwvRGlhbG9nVGl0bGU+XG4gICAgICAgICAgPERpYWxvZ0Rlc2NyaXB0aW9uPkRlZmluZSB2YWx1ZSBpbiB0ZXJtcyBvZiBvdXRjb21lLCByZXBvc2l0b3J5IGNvbnRleHQsIGFuZCBhY2NlcHRhbmNlIGNyaXRlcmlhLjwvRGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgIDwvRGlhbG9nSGVhZGVyPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNCBtZDpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgIDxMYWJlbD5UaXRsZTwvTGFiZWw+XG4gICAgICAgICAgICAgIDxJbnB1dCB2YWx1ZT17dGl0bGV9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFRpdGxlKGV2ZW50LnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiV29yayBvcmRlciB0aXRsZVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgPExhYmVsPkRlc2lyZWQgb3V0Y29tZTwvTGFiZWw+XG4gICAgICAgICAgICAgIDxUZXh0YXJlYSB2YWx1ZT17ZGVzaXJlZE91dGNvbWV9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldERlc2lyZWRPdXRjb21lKGV2ZW50LnRhcmdldC52YWx1ZSl9IHJvd3M9ezR9IHBsYWNlaG9sZGVyPVwiV2hhdCB2YWx1ZSBzaG91bGQgYmUgZGVsaXZlcmVkP1wiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgPExhYmVsPkNvbnRleHQ8L0xhYmVsPlxuICAgICAgICAgICAgICA8VGV4dGFyZWEgdmFsdWU9e2NvbnRleHR9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldENvbnRleHQoZXZlbnQudGFyZ2V0LnZhbHVlKX0gcm93cz17NH0gcGxhY2Vob2xkZXI9XCJCdXNpbmVzcyBvciBlbmdpbmVlcmluZyBjb250ZXh0XCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgPExhYmVsPldvcmtmbG93PC9MYWJlbD5cbiAgICAgICAgICAgICAgPElucHV0IHZhbHVlPXt3b3JrZmxvd0lkfSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRXb3JrZmxvd0lkKGV2ZW50LnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiZmVhdHVyZS1kZXZcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgIDxMYWJlbD5SZXBvc2l0b3J5PC9MYWJlbD5cbiAgICAgICAgICAgICAgPElucHV0IHZhbHVlPXtyZXBvc2l0b3J5fSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRSZXBvc2l0b3J5KGV2ZW50LnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwib3duZXIvcmVwb1wiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgPExhYmVsPkJyYW5jaCBzdHJhdGVneTwvTGFiZWw+XG4gICAgICAgICAgICAgIDxJbnB1dCB2YWx1ZT17YnJhbmNoU3RyYXRlZ3l9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldEJyYW5jaFN0cmF0ZWd5KGV2ZW50LnRhcmdldC52YWx1ZSl9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgPExhYmVsPlByaW9yaXR5PC9MYWJlbD5cbiAgICAgICAgICAgICAgICA8U2VsZWN0IHZhbHVlPXtwcmlvcml0eX0gb25WYWx1ZUNoYW5nZT17c2V0UHJpb3JpdHl9PlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXI+PFNlbGVjdFZhbHVlIC8+PC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiMVwiPkNyaXRpY2FsPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIjJcIj5IaWdoPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIjNcIj5Ob3JtYWw8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiNFwiPkxvdzwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICA8TGFiZWw+UmlzazwvTGFiZWw+XG4gICAgICAgICAgICAgICAgPFNlbGVjdCB2YWx1ZT17cmlza0xldmVsfSBvblZhbHVlQ2hhbmdlPXtzZXRSaXNrTGV2ZWx9PlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXI+PFNlbGVjdFZhbHVlIC8+PC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiTE9XXCI+TG93PC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIk1FRElVTVwiPk1lZGl1bTwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJISUdIXCI+SGlnaDwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJDUklUSUNBTFwiPkNyaXRpY2FsPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICA8TGFiZWw+UmVxdWVzdGVkIGJ5PC9MYWJlbD5cbiAgICAgICAgICAgICAgICA8SW5wdXQgdmFsdWU9e3JlcXVlc3RlZEJ5fSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRSZXF1ZXN0ZWRCeShldmVudC50YXJnZXQudmFsdWUpfSAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgIDxMYWJlbD5Bc3NpZ25lZCBhZ2VudDwvTGFiZWw+XG4gICAgICAgICAgICAgICAgPElucHV0IHZhbHVlPXthc3NpZ25lZEFnZW50fSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRBc3NpZ25lZEFnZW50KGV2ZW50LnRhcmdldC52YWx1ZSl9IC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgIDxMYWJlbD5BY2NlcHRhbmNlIGNyaXRlcmlhPC9MYWJlbD5cbiAgICAgICAgICAgICAgPFRleHRhcmVhIHZhbHVlPXthY2NlcHRhbmNlQ3JpdGVyaWF9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldEFjY2VwdGFuY2VDcml0ZXJpYShldmVudC50YXJnZXQudmFsdWUpfSByb3dzPXs2fSBwbGFjZWhvbGRlcj17XCJPbmUgY3JpdGVyaW9uIHBlciBsaW5lXFxuQnVpbGQgcGFzc2VzXFxuUXVldWUgcmVuZGVyc1xcbkxpbmtlZCBydW4gaXMgdmlzaWJsZVwifSAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHtlcnJvciA/IDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXJlZC0zMDBcIj57ZXJyb3J9PC9kaXY+IDogbnVsbH1cblxuICAgICAgICA8RGlhbG9nRm9vdGVyPlxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17b25DbG9zZX0+Q2FuY2VsPC9CdXR0b24+XG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25DcmVhdGUoeyB0aXRsZSwgZGVzaXJlZE91dGNvbWUsIGNvbnRleHQsIHdvcmtmbG93SWQsIHJlcG9zaXRvcnksIGJyYW5jaFN0cmF0ZWd5LCBwcmlvcml0eSwgcmlza0xldmVsLCByZXF1ZXN0ZWRCeSwgYXNzaWduZWRBZ2VudCwgYWNjZXB0YW5jZUNyaXRlcmlhIH0pfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2NyZWF0aW5nIHx8ICF0aXRsZS50cmltKCkgfHwgIWRlc2lyZWRPdXRjb21lLnRyaW0oKSB8fCAhYWNjZXB0YW5jZUNyaXRlcmlhLnRyaW0oKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7Y3JlYXRpbmcgPyBcIkNyZWF0aW5n4oCmXCIgOiBcIkNyZWF0ZSBXb3JrT3JkZXJcIn1cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9EaWFsb2dGb290ZXI+XG4gICAgICA8L0RpYWxvZ0NvbnRlbnQ+XG4gICAgPC9EaWFsb2c+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9jb250cm9sUGxhbmUvV29ya09yZGVyc1ZpZXcudHN4In0=