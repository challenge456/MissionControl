import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/CostAnalytics.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { ExternalLink, FileText, X } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { cn } from "/src/lib/utils.ts";
import { MetricBlock, MetricRow } from "/src/components/factory/MetricBlock.tsx";
import { CHART_SERIES } from "/src/components/factory/chartTheme.ts";
const CARD_CLASS = "rounded-xl border border-line bg-surface-1 p-4";
export function CostAnalytics({ projectId, onClose }) {
  _s();
  const runs = useQuery(
    api.runs.listRecent,
    projectId ? { projectId, limit: 1e3 } : "skip"
  );
  const agents = useQuery(
    api.agents.listAll,
    projectId ? { projectId } : "skip"
  );
  const tasks = useQuery(
    api.tasks.listAll,
    projectId ? { projectId } : "skip"
  );
  if (!runs || !agents || !tasks) {
    return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/60", children: /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-line bg-surface-1 p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "h-8 w-40 animate-pulse rounded bg-surface-2" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
      lineNumber: 55,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
      lineNumber: 54,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
      lineNumber: 53,
      columnNumber: 7
    }, this);
  }
  const totalCost = runs.reduce((sum, r) => sum + r.costUsd, 0);
  const todayStart = (/* @__PURE__ */ new Date()).setHours(0, 0, 0, 0);
  const todayCost = runs.filter((r) => r.startedAt >= todayStart).reduce((sum, r) => sum + r.costUsd, 0);
  const last7Days = Date.now() - 7 * 24 * 60 * 60 * 1e3;
  const last7DaysCost = runs.filter((r) => r.startedAt >= last7Days).reduce((sum, r) => sum + r.costUsd, 0);
  const last30Days = Date.now() - 30 * 24 * 60 * 60 * 1e3;
  const last30DaysCost = runs.filter((r) => r.startedAt >= last30Days).reduce((sum, r) => sum + r.costUsd, 0);
  const costByAgent = agents.map((agent) => {
    const agentRuns = runs.filter((r) => r.agentId === agent._id);
    const cost = agentRuns.reduce((sum, r) => sum + r.costUsd, 0);
    const runCount = agentRuns.length;
    return { agent, cost, runCount };
  }).sort((a, b) => b.cost - a.cost);
  const costByTask = tasks.map((task) => {
    return {
      task,
      cost: task.actualCost,
      budget: task.budgetAllocated || 0,
      remaining: task.budgetRemaining || 0
    };
  }).sort((a, b) => b.cost - a.cost);
  const costByModel = {};
  for (const run of runs) {
    if (!costByModel[run.model]) {
      costByModel[run.model] = { cost: 0, runs: 0 };
    }
    costByModel[run.model].cost += run.costUsd;
    costByModel[run.model].runs++;
  }
  const modelStats = Object.entries(costByModel).map(([model, stats]) => ({ model, ...stats })).sort((a, b) => b.cost - a.cost);
  const dailyCosts = {};
  for (const run of runs) {
    if (run.startedAt >= last7Days) {
      const date = new Date(run.startedAt).toISOString().split("T")[0];
      dailyCosts[date] = (dailyCosts[date] || 0) + run.costUsd;
    }
  }
  const costTrend = Object.entries(dailyCosts).map(([date, cost]) => ({ date, cost })).sort((a, b) => a.date.localeCompare(b.date));
  const maxDailyCost = Math.max(...Object.values(dailyCosts), 1);
  const providerBillingGroups = [
    {
      label: "AI & models",
      links: [
        { name: "Anthropic", url: "https://console.anthropic.com/settings/billing" },
        { name: "OpenAI", url: "https://platform.openai.com/usage" },
        { name: "Google / Gemini", url: "https://console.cloud.google.com/billing" },
        { name: "OpenRouter", url: "https://openrouter.ai/credits" },
        { name: "Perplexity", url: "https://www.perplexity.ai/settings" }
      ]
    },
    {
      label: "Infrastructure",
      links: [
        { name: "Convex", url: "https://dashboard.convex.dev" },
        { name: "Vercel", url: "https://vercel.com/dashboard/billing" },
        { name: "GitHub", url: "https://github.com/settings/billing" }
      ]
    },
    {
      label: "Tools & services",
      links: [
        { name: "Cursor", url: "https://cursor.com" },
        { name: "ElevenLabs", url: "https://elevenlabs.io/subscription" },
        { name: "Twilio", url: "https://console.twilio.com/billing" }
      ]
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex max-h-[90vh] w-full max-w-7xl flex-col overflow-hidden rounded-xl border border-line bg-surface-1", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "shrink-0 border-b border-line p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[19px] font-semibold text-ink", children: "Cost analytics" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
          lineNumber: 160,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "p",
          {
            className: "mt-1 text-[13px] text-ink-secondary",
            title: "Cost from agent runs. Savings vs. paying list price without run-level optimizations.",
            children: [
              runs.length,
              " runs · $",
              totalCost.toFixed(2),
              " total"
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
            lineNumber: 161,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
        lineNumber: 159,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: onClose,
          className: "rounded-md p-1.5 text-ink-muted transition-colors duration-150 hover:bg-surface-2 hover:text-ink",
          "aria-label": "Close",
          children: /* @__PURE__ */ jsxDEV(X, { size: 16, strokeWidth: 1.75 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
            lineNumber: 173,
            columnNumber: 15
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
          lineNumber: 168,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
      lineNumber: 158,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
      lineNumber: 157,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-y-auto p-6", children: [
      /* @__PURE__ */ jsxDEV(MetricRow, { className: "mb-6", children: [
        /* @__PURE__ */ jsxDEV(MetricBlock, { label: "Today", value: `$${todayCost.toFixed(2)}` }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
          lineNumber: 182,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(MetricBlock, { label: "Last 7 days", value: `$${last7DaysCost.toFixed(2)}` }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
          lineNumber: 183,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(MetricBlock, { label: "Last 30 days", value: `$${last30DaysCost.toFixed(2)}` }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
          lineNumber: 184,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(MetricBlock, { label: "All time", value: `$${totalCost.toFixed(2)}` }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
          lineNumber: 185,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
        lineNumber: 181,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: cn(CARD_CLASS, "mb-6 p-5"), children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[15px] font-semibold text-ink", children: "Provider billing" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
          lineNumber: 190,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-[12.5px] text-ink-muted", children: [
          "Vendor dashboards require manual sign-in. Review regularly and update",
          " ",
          /* @__PURE__ */ jsxDEV("code", { className: "rounded bg-surface-2 px-1.5 py-0.5 font-mono text-[11px] text-ink-secondary", children: "docs/COSTS.md" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
            lineNumber: 193,
            columnNumber: 15
          }, this),
          " ",
          "with current spending."
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
          lineNumber: 191,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-4 grid grid-cols-1 gap-6 md:grid-cols-3", children: providerBillingGroups.map(
          ({ label, links }) => /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-2 text-[11.5px] font-medium uppercase tracking-[0.06em] text-ink-muted", children: label }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
              lineNumber: 199,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { children: links.map(
              ({ name, url }) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
                "a",
                {
                  href: url,
                  target: "_blank",
                  rel: "noopener noreferrer",
                  className: "group flex items-center justify-between gap-2 rounded-md px-3 py-2 text-[13px] text-ink-secondary transition-colors duration-150 hover:bg-surface-2 hover:text-ink",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { children: name }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                      lineNumber: 211,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      ExternalLink,
                      {
                        size: 14,
                        strokeWidth: 1.75,
                        className: "shrink-0 text-ink-muted transition-colors duration-150 group-hover:text-ink-secondary"
                      },
                      void 0,
                      false,
                      {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                        lineNumber: 212,
                        columnNumber: 27
                      },
                      this
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                  lineNumber: 205,
                  columnNumber: 25
                },
                this
              ) }, name, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                lineNumber: 204,
                columnNumber: 19
              }, this)
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
              lineNumber: 202,
              columnNumber: 19
            }, this)
          ] }, label, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
            lineNumber: 198,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
          lineNumber: 196,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-4 flex items-center gap-1.5 border-t border-line pt-4 text-[12px] text-ink-muted", children: [
          /* @__PURE__ */ jsxDEV(FileText, { size: 14, strokeWidth: 1.75, className: "shrink-0" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
            lineNumber: 225,
            columnNumber: 15
          }, this),
          "Full checklist and spending table:",
          " ",
          /* @__PURE__ */ jsxDEV("code", { className: "rounded bg-surface-2 px-1.5 py-0.5 font-mono text-[11px] text-ink-secondary", children: "docs/COSTS.md" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
            lineNumber: 227,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
          lineNumber: 224,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
        lineNumber: 189,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: cn(CARD_CLASS, "mb-6"), children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-[15px] font-semibold text-ink", children: "Daily cost trend (last 7 days)" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
          lineNumber: 233,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: costTrend.map(
          ({ date, cost }) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-24 shrink-0 text-[12px] text-ink-muted", children: new Date(date).toLocaleDateString("en-US", { month: "short", day: "numeric" }) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
              lineNumber: 239,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "relative h-6 flex-1 overflow-hidden rounded-md bg-surface-2", children: [
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "h-6 min-w-[2px] rounded-md",
                  style: {
                    width: `${cost / maxDailyCost * 100}%`,
                    backgroundColor: CHART_SERIES[0]
                  }
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                  lineNumber: 243,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 flex items-center px-2 font-mono text-[12px] font-medium text-ink", children: [
                "$",
                cost.toFixed(2)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                lineNumber: 250,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
              lineNumber: 242,
              columnNumber: 19
            }, this)
          ] }, date, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
            lineNumber: 238,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
          lineNumber: 236,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
        lineNumber: 232,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-6 lg:grid-cols-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: CARD_CLASS, children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-[15px] font-semibold text-ink", children: "Cost by agent" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
            lineNumber: 262,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: costByAgent.slice(0, 10).map(
            ({ agent, cost, runCount }) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex min-w-0 items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "truncate text-[13px] text-ink", children: agent.name }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                  lineNumber: 267,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "shrink-0 text-[12px] text-ink-muted", children: [
                  "(",
                  runCount,
                  " runs)"
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                  lineNumber: 268,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                lineNumber: 266,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "ml-2 shrink-0 font-mono text-[13px] font-medium tabular-nums text-ink", children: [
                "$",
                cost.toFixed(2)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                lineNumber: 270,
                columnNumber: 21
              }, this)
            ] }, agent._id, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
              lineNumber: 265,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
            lineNumber: 263,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
          lineNumber: 261,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: CARD_CLASS, children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-[15px] font-semibold text-ink", children: "Cost by model" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
            lineNumber: 280,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: modelStats.map(
            ({ model, cost, runs: runs2 }) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex min-w-0 items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "truncate font-mono text-[12.5px] text-ink", children: model }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                  lineNumber: 285,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "shrink-0 text-[12px] text-ink-muted", children: [
                  "(",
                  runs2,
                  " runs)"
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                  lineNumber: 286,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                lineNumber: 284,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "ml-2 shrink-0 font-mono text-[13px] font-medium tabular-nums text-ink", children: [
                "$",
                cost.toFixed(2)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                lineNumber: 288,
                columnNumber: 21
              }, this)
            ] }, model, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
              lineNumber: 283,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
            lineNumber: 281,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
          lineNumber: 279,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: cn(CARD_CLASS, "lg:col-span-2"), children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-[15px] font-semibold text-ink", children: "Most expensive tasks" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
            lineNumber: 298,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: costByTask.slice(0, 10).map(
            ({ task, cost, budget, remaining }) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "truncate text-[13px] font-medium text-ink", children: task.title }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                  lineNumber: 303,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-0.5 text-[12px] text-ink-muted", children: [
                  task.type,
                  " · Priority ",
                  task.priority
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                  lineNumber: 304,
                  columnNumber: 23
                }, this),
                budget > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "h-1.5 w-full overflow-hidden rounded-full bg-surface-2", children: /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: cn(
                        "h-1.5 rounded-full",
                        remaining < 0 ? "bg-err" : remaining < budget * 0.2 ? "bg-warn" : "bg-ok"
                      ),
                      style: { width: `${Math.min(cost / budget * 100, 100)}%` }
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                      lineNumber: 310,
                      columnNumber: 29
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                    lineNumber: 309,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "mt-1 flex justify-between text-[12px] text-ink-muted", children: [
                    /* @__PURE__ */ jsxDEV("span", { children: [
                      "$",
                      cost.toFixed(2)
                    ] }, void 0, true, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                      lineNumber: 323,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: [
                      "$",
                      budget.toFixed(2),
                      " budget"
                    ] }, void 0, true, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                      lineNumber: 324,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                    lineNumber: 322,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                  lineNumber: 308,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                lineNumber: 302,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "shrink-0 text-right", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-[13px] font-semibold tabular-nums text-ink", children: [
                  "$",
                  cost.toFixed(2)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                  lineNumber: 330,
                  columnNumber: 23
                }, this),
                budget > 0 && /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: cn(
                      "mt-0.5 text-[12px]",
                      remaining < 0 ? "text-err" : "text-ink-muted"
                    ),
                    children: remaining < 0 ? "Over" : `${remaining.toFixed(2)} left`
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                    lineNumber: 334,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
                lineNumber: 329,
                columnNumber: 21
              }, this)
            ] }, task._id, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
              lineNumber: 301,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
            lineNumber: 299,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
          lineNumber: 297,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
        lineNumber: 259,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
      lineNumber: 179,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
    lineNumber: 155,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx",
    lineNumber: 154,
    columnNumber: 5
  }, this);
}
_s(CostAnalytics, "Gj2YYTZ0t3IZtRwz1wjB5845IbQ=", false, function() {
  return [useQuery, useQuery, useQuery];
});
_c = CostAnalytics;
var _c;
$RefreshReg$(_c, "CostAnalytics");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CostAnalytics.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUNVOzs7Ozs7Ozs7Ozs7Ozs7OztBQW5DVixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsV0FBVztBQUVwQixTQUFTQyxjQUFjQyxVQUFVQyxTQUFTO0FBQzFDLFNBQVNDLFVBQVU7QUFDbkIsU0FBU0MsYUFBYUMsaUJBQWlCO0FBQ3ZDLFNBQVNDLG9CQUFvQjtBQU83QixNQUFNQyxhQUFhO0FBRVosZ0JBQVNDLGNBQWMsRUFBRUMsV0FBV0MsUUFBNEIsR0FBRztBQUFBQyxLQUFBO0FBQ3hFLFFBQU1DLE9BQU9kO0FBQUFBLElBQ1hDLElBQUlhLEtBQUtDO0FBQUFBLElBQ1RKLFlBQVksRUFBRUEsV0FBV0ssT0FBTyxJQUFLLElBQUk7QUFBQSxFQUMzQztBQUVBLFFBQU1DLFNBQVNqQjtBQUFBQSxJQUNiQyxJQUFJZ0IsT0FBT0M7QUFBQUEsSUFDWFAsWUFBWSxFQUFFQSxVQUFVLElBQUk7QUFBQSxFQUM5QjtBQUVBLFFBQU1RLFFBQVFuQjtBQUFBQSxJQUNaQyxJQUFJa0IsTUFBTUQ7QUFBQUEsSUFDVlAsWUFBWSxFQUFFQSxVQUFVLElBQUk7QUFBQSxFQUM5QjtBQUVBLE1BQUksQ0FBQ0csUUFBUSxDQUFDRyxVQUFVLENBQUNFLE9BQU87QUFDOUIsV0FDRSx1QkFBQyxTQUFJLFdBQVUsbUVBQ2IsaUNBQUMsU0FBSSxXQUFVLGtEQUNiLGlDQUFDLFNBQUksV0FBVSxpREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRELEtBRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLEVBRUo7QUFHQSxRQUFNQyxZQUFZTixLQUFLTyxPQUFPLENBQUNDLEtBQUtDLE1BQU1ELE1BQU1DLEVBQUVDLFNBQVMsQ0FBQztBQUM1RCxRQUFNQyxjQUFhLG9CQUFJQyxLQUFLLEdBQUVDLFNBQVMsR0FBRyxHQUFHLEdBQUcsQ0FBQztBQUNqRCxRQUFNQyxZQUFZZCxLQUNmZSxPQUFPLENBQUNOLE1BQU1BLEVBQUVPLGFBQWFMLFVBQVUsRUFDdkNKLE9BQU8sQ0FBQ0MsS0FBS0MsTUFBTUQsTUFBTUMsRUFBRUMsU0FBUyxDQUFDO0FBRXhDLFFBQU1PLFlBQVlMLEtBQUtNLElBQUksSUFBSSxJQUFJLEtBQUssS0FBSyxLQUFLO0FBQ2xELFFBQU1DLGdCQUFnQm5CLEtBQ25CZSxPQUFPLENBQUNOLE1BQU1BLEVBQUVPLGFBQWFDLFNBQVMsRUFDdENWLE9BQU8sQ0FBQ0MsS0FBS0MsTUFBTUQsTUFBTUMsRUFBRUMsU0FBUyxDQUFDO0FBRXhDLFFBQU1VLGFBQWFSLEtBQUtNLElBQUksSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLO0FBQ3BELFFBQU1HLGlCQUFpQnJCLEtBQ3BCZSxPQUFPLENBQUNOLE1BQU1BLEVBQUVPLGFBQWFJLFVBQVUsRUFDdkNiLE9BQU8sQ0FBQ0MsS0FBS0MsTUFBTUQsTUFBTUMsRUFBRUMsU0FBUyxDQUFDO0FBR3hDLFFBQU1ZLGNBQWNuQixPQUFPb0IsSUFBSSxDQUFDQyxVQUFVO0FBQ3hDLFVBQU1DLFlBQVl6QixLQUFLZSxPQUFPLENBQUNOLE1BQU1BLEVBQUVpQixZQUFZRixNQUFNRyxHQUFHO0FBQzVELFVBQU1DLE9BQU9ILFVBQVVsQixPQUFPLENBQUNDLEtBQUtDLE1BQU1ELE1BQU1DLEVBQUVDLFNBQVMsQ0FBQztBQUM1RCxVQUFNbUIsV0FBV0osVUFBVUs7QUFDM0IsV0FBTyxFQUFFTixPQUFPSSxNQUFNQyxTQUFTO0FBQUEsRUFDakMsQ0FBQyxFQUFFRSxLQUFLLENBQUNDLEdBQUdDLE1BQU1BLEVBQUVMLE9BQU9JLEVBQUVKLElBQUk7QUFHakMsUUFBTU0sYUFBYTdCLE1BQU1rQixJQUFJLENBQUNZLFNBQVM7QUFDckMsV0FBTztBQUFBLE1BQ0xBO0FBQUFBLE1BQ0FQLE1BQU1PLEtBQUtDO0FBQUFBLE1BQ1hDLFFBQVFGLEtBQUtHLG1CQUFtQjtBQUFBLE1BQ2hDQyxXQUFXSixLQUFLSyxtQkFBbUI7QUFBQSxJQUNyQztBQUFBLEVBQ0YsQ0FBQyxFQUFFVCxLQUFLLENBQUNDLEdBQUdDLE1BQU1BLEVBQUVMLE9BQU9JLEVBQUVKLElBQUk7QUFHakMsUUFBTWEsY0FBOEQsQ0FBQztBQUNyRSxhQUFXQyxPQUFPMUMsTUFBTTtBQUN0QixRQUFJLENBQUN5QyxZQUFZQyxJQUFJQyxLQUFLLEdBQUc7QUFDM0JGLGtCQUFZQyxJQUFJQyxLQUFLLElBQUksRUFBRWYsTUFBTSxHQUFHNUIsTUFBTSxFQUFFO0FBQUEsSUFDOUM7QUFDQXlDLGdCQUFZQyxJQUFJQyxLQUFLLEVBQUVmLFFBQVFjLElBQUloQztBQUNuQytCLGdCQUFZQyxJQUFJQyxLQUFLLEVBQUUzQztBQUFBQSxFQUN6QjtBQUNBLFFBQU00QyxhQUFhQyxPQUFPQyxRQUFRTCxXQUFXLEVBQzFDbEIsSUFBSSxDQUFDLENBQUNvQixPQUFPSSxLQUFLLE9BQU8sRUFBRUosT0FBTyxHQUFHSSxNQUFNLEVBQUUsRUFDN0NoQixLQUFLLENBQUNDLEdBQUdDLE1BQU1BLEVBQUVMLE9BQU9JLEVBQUVKLElBQUk7QUFHakMsUUFBTW9CLGFBQXFDLENBQUM7QUFDNUMsYUFBV04sT0FBTzFDLE1BQU07QUFDdEIsUUFBSTBDLElBQUkxQixhQUFhQyxXQUFXO0FBQzlCLFlBQU1nQyxPQUFPLElBQUlyQyxLQUFLOEIsSUFBSTFCLFNBQVMsRUFBRWtDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUMvREgsaUJBQVdDLElBQUksS0FBS0QsV0FBV0MsSUFBSSxLQUFLLEtBQUtQLElBQUloQztBQUFBQSxJQUNuRDtBQUFBLEVBQ0Y7QUFDQSxRQUFNMEMsWUFBWVAsT0FBT0MsUUFBUUUsVUFBVSxFQUN4Q3pCLElBQUksQ0FBQyxDQUFDMEIsTUFBTXJCLElBQUksT0FBTyxFQUFFcUIsTUFBTXJCLEtBQUssRUFBRSxFQUN0Q0csS0FBSyxDQUFDQyxHQUFHQyxNQUFNRCxFQUFFaUIsS0FBS0ksY0FBY3BCLEVBQUVnQixJQUFJLENBQUM7QUFFOUMsUUFBTUssZUFBZUMsS0FBS0MsSUFBSSxHQUFHWCxPQUFPWSxPQUFPVCxVQUFVLEdBQUcsQ0FBQztBQUc3RCxRQUFNVSx3QkFBcUY7QUFBQSxJQUN6RjtBQUFBLE1BQ0VDLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsUUFDTCxFQUFFQyxNQUFNLGFBQWFDLEtBQUssaURBQWlEO0FBQUEsUUFDM0UsRUFBRUQsTUFBTSxVQUFVQyxLQUFLLG9DQUFvQztBQUFBLFFBQzNELEVBQUVELE1BQU0sbUJBQW1CQyxLQUFLLDJDQUEyQztBQUFBLFFBQzNFLEVBQUVELE1BQU0sY0FBY0MsS0FBSyxnQ0FBZ0M7QUFBQSxRQUMzRCxFQUFFRCxNQUFNLGNBQWNDLEtBQUsscUNBQXFDO0FBQUEsTUFBQztBQUFBLElBRXJFO0FBQUEsSUFDQTtBQUFBLE1BQ0VILE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsUUFDTCxFQUFFQyxNQUFNLFVBQVVDLEtBQUssK0JBQStCO0FBQUEsUUFDdEQsRUFBRUQsTUFBTSxVQUFVQyxLQUFLLHVDQUF1QztBQUFBLFFBQzlELEVBQUVELE1BQU0sVUFBVUMsS0FBSyxzQ0FBc0M7QUFBQSxNQUFDO0FBQUEsSUFFbEU7QUFBQSxJQUNBO0FBQUEsTUFDRUgsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxRQUNMLEVBQUVDLE1BQU0sVUFBVUMsS0FBSyxxQkFBcUI7QUFBQSxRQUM1QyxFQUFFRCxNQUFNLGNBQWNDLEtBQUsscUNBQXFDO0FBQUEsUUFDaEUsRUFBRUQsTUFBTSxVQUFVQyxLQUFLLHFDQUFxQztBQUFBLE1BQUM7QUFBQSxJQUVqRTtBQUFBLEVBQUM7QUFHSCxTQUNFLHVCQUFDLFNBQUksV0FBVSx1RUFDYixpQ0FBQyxTQUFJLFdBQVUsMEdBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUscUNBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSxzQ0FBcUMsOEJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUU7QUFBQSxRQUNqRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsT0FBTTtBQUFBLFlBRUw5RDtBQUFBQSxtQkFBSzhCO0FBQUFBLGNBQU87QUFBQSxjQUFVeEIsVUFBVXlELFFBQVEsQ0FBQztBQUFBLGNBQUU7QUFBQTtBQUFBO0FBQUEsVUFKOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVNqRTtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUNWLGNBQVc7QUFBQSxVQUVYLGlDQUFDLEtBQUUsTUFBTSxJQUFJLGFBQWEsUUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0I7QUFBQTtBQUFBLFFBTGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsOEJBRWI7QUFBQSw2QkFBQyxhQUFVLFdBQVUsUUFDbkI7QUFBQSwrQkFBQyxlQUFZLE9BQU0sU0FBUSxPQUFPLElBQUlnQixVQUFVaUQsUUFBUSxDQUFDLENBQUMsTUFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RDtBQUFBLFFBQzdELHVCQUFDLGVBQVksT0FBTSxlQUFjLE9BQU8sSUFBSTVDLGNBQWM0QyxRQUFRLENBQUMsQ0FBQyxNQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVFO0FBQUEsUUFDdkUsdUJBQUMsZUFBWSxPQUFNLGdCQUFlLE9BQU8sSUFBSTFDLGVBQWUwQyxRQUFRLENBQUMsQ0FBQyxNQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlFO0FBQUEsUUFDekUsdUJBQUMsZUFBWSxPQUFNLFlBQVcsT0FBTyxJQUFJekQsVUFBVXlELFFBQVEsQ0FBQyxDQUFDLE1BQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0U7QUFBQSxXQUpsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBV3hFLEdBQUdJLFlBQVksVUFBVSxHQUN2QztBQUFBLCtCQUFDLFFBQUcsV0FBVSxzQ0FBcUMsZ0NBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUU7QUFBQSxRQUNuRSx1QkFBQyxPQUFFLFdBQVUscUNBQW1DO0FBQUE7QUFBQSxVQUN3QjtBQUFBLFVBQ3RFLHVCQUFDLFVBQUssV0FBVSwrRUFBOEUsNkJBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJHO0FBQUEsVUFBUTtBQUFBLFVBQUc7QUFBQSxhQUZ4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSw4Q0FDWitELGdDQUFzQm5DO0FBQUFBLFVBQUksQ0FBQyxFQUFFb0MsT0FBT0MsTUFBTSxNQUN6Qyx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDZFQUNaRCxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxRQUNFQyxnQkFBTXJDO0FBQUFBLGNBQUksQ0FBQyxFQUFFc0MsTUFBTUMsSUFBSSxNQUN0Qix1QkFBQyxRQUNDO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQU1BO0FBQUFBLGtCQUNOLFFBQU87QUFBQSxrQkFDUCxLQUFJO0FBQUEsa0JBQ0osV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsVUFBTUQsa0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBWTtBQUFBLG9CQUNaO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQU07QUFBQSx3QkFDTixhQUFhO0FBQUEsd0JBQ2IsV0FBVTtBQUFBO0FBQUEsc0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUdtRztBQUFBO0FBQUE7QUFBQSxnQkFWckc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWUEsS0FiT0EsTUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsWUFDRCxLQWpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtCQTtBQUFBLGVBdEJRRixPQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUJBO0FBQUEsUUFDRCxLQTFCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkJBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsdUZBQ1g7QUFBQSxpQ0FBQyxZQUFTLE1BQU0sSUFBSSxhQUFhLE1BQU0sV0FBVSxjQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRDtBQUFBO0FBQUEsVUFDeEI7QUFBQSxVQUNuQyx1QkFBQyxVQUFLLFdBQVUsK0VBQThFLDZCQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRztBQUFBLGFBSDdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3Q0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBV3BFLEdBQUdJLFlBQVksTUFBTSxHQUNuQztBQUFBLCtCQUFDLFFBQUcsV0FBVSwyQ0FBeUMsOENBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ1p5RCxvQkFBVTdCO0FBQUFBLFVBQUksQ0FBQyxFQUFFMEIsTUFBTXJCLEtBQUssTUFDM0IsdUJBQUMsU0FBZSxXQUFVLDJCQUN4QjtBQUFBLG1DQUFDLFNBQUksV0FBVSw0Q0FDWixjQUFJaEIsS0FBS3FDLElBQUksRUFBRWUsbUJBQW1CLFNBQVMsRUFBRUMsT0FBTyxTQUFTQyxLQUFLLFVBQVUsQ0FBQyxLQURoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsT0FBTztBQUFBLG9CQUNMQyxPQUFPLEdBQUl2QyxPQUFPMEIsZUFBZ0IsR0FBRztBQUFBLG9CQUNyQ2MsaUJBQWlCMUUsYUFBYSxDQUFDO0FBQUEsa0JBQ2pDO0FBQUE7QUFBQSxnQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLSTtBQUFBLGNBRUosdUJBQUMsU0FBSSxXQUFVLHNGQUFvRjtBQUFBO0FBQUEsZ0JBQy9Ga0MsS0FBS21DLFFBQVEsQ0FBQztBQUFBLG1CQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLGVBZlFkLE1BQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxRQUNELEtBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxXQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUJBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBRWI7QUFBQSwrQkFBQyxTQUFJLFdBQVd0RCxZQUNkO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDJDQUEwQyw2QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUU7QUFBQSxVQUNyRSx1QkFBQyxTQUFJLFdBQVUsYUFDWjJCLHNCQUFZK0MsTUFBTSxHQUFHLEVBQUUsRUFBRTlDO0FBQUFBLFlBQUksQ0FBQyxFQUFFQyxPQUFPSSxNQUFNQyxTQUFTLE1BQ3JELHVCQUFDLFNBQW9CLFdBQVUscUNBQzdCO0FBQUEscUNBQUMsU0FBSSxXQUFVLG1DQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLGlDQUFpQ0wsZ0JBQU1xQyxRQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0RDtBQUFBLGdCQUM1RCx1QkFBQyxVQUFLLFdBQVUsdUNBQXNDO0FBQUE7QUFBQSxrQkFBRWhDO0FBQUFBLGtCQUFTO0FBQUEscUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVFO0FBQUEsbUJBRnpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSx5RUFBdUU7QUFBQTtBQUFBLGdCQUNuRkQsS0FBS21DLFFBQVEsQ0FBQztBQUFBLG1CQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBUFF2QyxNQUFNRyxLQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsVUFDRCxLQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxhQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFXaEMsWUFDZDtBQUFBLGlDQUFDLFFBQUcsV0FBVSwyQ0FBMEMsNkJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFFO0FBQUEsVUFDckUsdUJBQUMsU0FBSSxXQUFVLGFBQ1ppRCxxQkFBV3JCO0FBQUFBLFlBQUksQ0FBQyxFQUFFb0IsT0FBT2YsTUFBTTVCLFlBQUssTUFDbkMsdUJBQUMsU0FBZ0IsV0FBVSxxQ0FDekI7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsNkNBQTZDMkMsbUJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1FO0FBQUEsZ0JBQ25FLHVCQUFDLFVBQUssV0FBVSx1Q0FBc0M7QUFBQTtBQUFBLGtCQUFFM0M7QUFBQUEsa0JBQUs7QUFBQSxxQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUU7QUFBQSxtQkFGckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsVUFBSyxXQUFVLHlFQUF1RTtBQUFBO0FBQUEsZ0JBQ25GNEIsS0FBS21DLFFBQVEsQ0FBQztBQUFBLG1CQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBUFFwQixPQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxVQUNELEtBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLGFBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVdwRCxHQUFHSSxZQUFZLGVBQWUsR0FDNUM7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMkNBQTBDLG9DQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RTtBQUFBLFVBQzVFLHVCQUFDLFNBQUksV0FBVSxhQUNadUMscUJBQVdtQyxNQUFNLEdBQUcsRUFBRSxFQUFFOUM7QUFBQUEsWUFBSSxDQUFDLEVBQUVZLE1BQU1QLE1BQU1TLFFBQVFFLFVBQVUsTUFDNUQsdUJBQUMsU0FBbUIsV0FBVSwwQ0FDNUI7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsNkNBQTZDSixlQUFLbUMsU0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUU7QUFBQSxnQkFDdkUsdUJBQUMsU0FBSSxXQUFVLHFDQUNabkM7QUFBQUEsdUJBQUtvQztBQUFBQSxrQkFBSztBQUFBLGtCQUFhcEMsS0FBS3FDO0FBQUFBLHFCQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0NuQyxTQUFTLEtBQ1IsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsMERBQ2I7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVzlDO0FBQUFBLHdCQUNUO0FBQUEsd0JBQ0FnRCxZQUFZLElBQ1IsV0FDQUEsWUFBWUYsU0FBUyxNQUNuQixZQUNBO0FBQUEsc0JBQ1I7QUFBQSxzQkFDQSxPQUFPLEVBQUU4QixPQUFPLEdBQUdaLEtBQUtrQixJQUFLN0MsT0FBT1MsU0FBVSxLQUFLLEdBQUcsQ0FBQyxJQUFJO0FBQUE7QUFBQSxvQkFUN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVMrRCxLQVZqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVlBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsMkNBQUMsVUFBSztBQUFBO0FBQUEsc0JBQUVULEtBQUttQyxRQUFRLENBQUM7QUFBQSx5QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd0I7QUFBQSxvQkFDeEIsdUJBQUMsVUFBSztBQUFBO0FBQUEsc0JBQUUxQixPQUFPMEIsUUFBUSxDQUFDO0FBQUEsc0JBQUU7QUFBQSx5QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQSx1QkFGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWtCQTtBQUFBLG1CQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTBCQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDZEQUEyRDtBQUFBO0FBQUEsa0JBQ3RFbkMsS0FBS21DLFFBQVEsQ0FBQztBQUFBLHFCQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0MxQixTQUFTLEtBQ1I7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVzlDO0FBQUFBLHNCQUNUO0FBQUEsc0JBQ0FnRCxZQUFZLElBQUksYUFBYTtBQUFBLG9CQUMvQjtBQUFBLG9CQUVDQSxzQkFBWSxJQUFJLFNBQVMsR0FBR0EsVUFBVXdCLFFBQVEsQ0FBQyxDQUFDO0FBQUE7QUFBQSxrQkFObkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsbUJBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFjQTtBQUFBLGlCQTFDUTVCLEtBQUtSLEtBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEyQ0E7QUFBQSxVQUNELEtBOUNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0NBO0FBQUEsYUFqREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtEQTtBQUFBLFdBeEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5RkE7QUFBQSxTQXpLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEtBO0FBQUEsT0FsTUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1NQSxLQXBNRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcU1BO0FBRUo7QUFBQzVCLEdBOVRlSCxlQUFhO0FBQUEsVUFDZFYsVUFLRUEsVUFLREEsUUFBUTtBQUFBO0FBQUEsS0FYUlU7QUFBYSxJQUFBOEU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlUXVlcnkiLCJhcGkiLCJFeHRlcm5hbExpbmsiLCJGaWxlVGV4dCIsIlgiLCJjbiIsIk1ldHJpY0Jsb2NrIiwiTWV0cmljUm93IiwiQ0hBUlRfU0VSSUVTIiwiQ0FSRF9DTEFTUyIsIkNvc3RBbmFseXRpY3MiLCJwcm9qZWN0SWQiLCJvbkNsb3NlIiwiX3MiLCJydW5zIiwibGlzdFJlY2VudCIsImxpbWl0IiwiYWdlbnRzIiwibGlzdEFsbCIsInRhc2tzIiwidG90YWxDb3N0IiwicmVkdWNlIiwic3VtIiwiciIsImNvc3RVc2QiLCJ0b2RheVN0YXJ0IiwiRGF0ZSIsInNldEhvdXJzIiwidG9kYXlDb3N0IiwiZmlsdGVyIiwic3RhcnRlZEF0IiwibGFzdDdEYXlzIiwibm93IiwibGFzdDdEYXlzQ29zdCIsImxhc3QzMERheXMiLCJsYXN0MzBEYXlzQ29zdCIsImNvc3RCeUFnZW50IiwibWFwIiwiYWdlbnQiLCJhZ2VudFJ1bnMiLCJhZ2VudElkIiwiX2lkIiwiY29zdCIsInJ1bkNvdW50IiwibGVuZ3RoIiwic29ydCIsImEiLCJiIiwiY29zdEJ5VGFzayIsInRhc2siLCJhY3R1YWxDb3N0IiwiYnVkZ2V0IiwiYnVkZ2V0QWxsb2NhdGVkIiwicmVtYWluaW5nIiwiYnVkZ2V0UmVtYWluaW5nIiwiY29zdEJ5TW9kZWwiLCJydW4iLCJtb2RlbCIsIm1vZGVsU3RhdHMiLCJPYmplY3QiLCJlbnRyaWVzIiwic3RhdHMiLCJkYWlseUNvc3RzIiwiZGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJjb3N0VHJlbmQiLCJsb2NhbGVDb21wYXJlIiwibWF4RGFpbHlDb3N0IiwiTWF0aCIsIm1heCIsInZhbHVlcyIsInByb3ZpZGVyQmlsbGluZ0dyb3VwcyIsImxhYmVsIiwibGlua3MiLCJuYW1lIiwidXJsIiwidG9GaXhlZCIsInRvTG9jYWxlRGF0ZVN0cmluZyIsIm1vbnRoIiwiZGF5Iiwid2lkdGgiLCJiYWNrZ3JvdW5kQ29sb3IiLCJzbGljZSIsInRpdGxlIiwidHlwZSIsInByaW9yaXR5IiwibWluIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29zdEFuYWx5dGljcy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgRXh0ZXJuYWxMaW5rLCBGaWxlVGV4dCwgWCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5pbXBvcnQgeyBNZXRyaWNCbG9jaywgTWV0cmljUm93IH0gZnJvbSBcIi4vY29tcG9uZW50cy9mYWN0b3J5L01ldHJpY0Jsb2NrXCI7XG5pbXBvcnQgeyBDSEFSVF9TRVJJRVMgfSBmcm9tIFwiLi9jb21wb25lbnRzL2ZhY3RvcnkvY2hhcnRUaGVtZVwiO1xuXG5pbnRlcmZhY2UgQ29zdEFuYWx5dGljc1Byb3BzIHtcbiAgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+IHwgbnVsbDtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbn1cblxuY29uc3QgQ0FSRF9DTEFTUyA9IFwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xIHAtNFwiO1xuXG5leHBvcnQgZnVuY3Rpb24gQ29zdEFuYWx5dGljcyh7IHByb2plY3RJZCwgb25DbG9zZSB9OiBDb3N0QW5hbHl0aWNzUHJvcHMpIHtcbiAgY29uc3QgcnVucyA9IHVzZVF1ZXJ5KFxuICAgIGFwaS5ydW5zLmxpc3RSZWNlbnQsXG4gICAgcHJvamVjdElkID8geyBwcm9qZWN0SWQsIGxpbWl0OiAxMDAwIH0gOiBcInNraXBcIlxuICApO1xuXG4gIGNvbnN0IGFnZW50cyA9IHVzZVF1ZXJ5KFxuICAgIGFwaS5hZ2VudHMubGlzdEFsbCxcbiAgICBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCB9IDogXCJza2lwXCJcbiAgKTtcblxuICBjb25zdCB0YXNrcyA9IHVzZVF1ZXJ5KFxuICAgIGFwaS50YXNrcy5saXN0QWxsLFxuICAgIHByb2plY3RJZCA/IHsgcHJvamVjdElkIH0gOiBcInNraXBcIlxuICApO1xuXG4gIGlmICghcnVucyB8fCAhYWdlbnRzIHx8ICF0YXNrcykge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ibGFjay82MFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMSBwLTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtOCB3LTQwIGFuaW1hdGUtcHVsc2Ugcm91bmRlZCBiZy1zdXJmYWNlLTJcIiAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICAvLyBDYWxjdWxhdGUgbWV0cmljc1xuICBjb25zdCB0b3RhbENvc3QgPSBydW5zLnJlZHVjZSgoc3VtLCByKSA9PiBzdW0gKyByLmNvc3RVc2QsIDApO1xuICBjb25zdCB0b2RheVN0YXJ0ID0gbmV3IERhdGUoKS5zZXRIb3VycygwLCAwLCAwLCAwKTtcbiAgY29uc3QgdG9kYXlDb3N0ID0gcnVuc1xuICAgIC5maWx0ZXIoKHIpID0+IHIuc3RhcnRlZEF0ID49IHRvZGF5U3RhcnQpXG4gICAgLnJlZHVjZSgoc3VtLCByKSA9PiBzdW0gKyByLmNvc3RVc2QsIDApO1xuXG4gIGNvbnN0IGxhc3Q3RGF5cyA9IERhdGUubm93KCkgLSA3ICogMjQgKiA2MCAqIDYwICogMTAwMDtcbiAgY29uc3QgbGFzdDdEYXlzQ29zdCA9IHJ1bnNcbiAgICAuZmlsdGVyKChyKSA9PiByLnN0YXJ0ZWRBdCA+PSBsYXN0N0RheXMpXG4gICAgLnJlZHVjZSgoc3VtLCByKSA9PiBzdW0gKyByLmNvc3RVc2QsIDApO1xuXG4gIGNvbnN0IGxhc3QzMERheXMgPSBEYXRlLm5vdygpIC0gMzAgKiAyNCAqIDYwICogNjAgKiAxMDAwO1xuICBjb25zdCBsYXN0MzBEYXlzQ29zdCA9IHJ1bnNcbiAgICAuZmlsdGVyKChyKSA9PiByLnN0YXJ0ZWRBdCA+PSBsYXN0MzBEYXlzKVxuICAgIC5yZWR1Y2UoKHN1bSwgcikgPT4gc3VtICsgci5jb3N0VXNkLCAwKTtcblxuICAvLyBDb3N0IGJ5IGFnZW50XG4gIGNvbnN0IGNvc3RCeUFnZW50ID0gYWdlbnRzLm1hcCgoYWdlbnQpID0+IHtcbiAgICBjb25zdCBhZ2VudFJ1bnMgPSBydW5zLmZpbHRlcigocikgPT4gci5hZ2VudElkID09PSBhZ2VudC5faWQpO1xuICAgIGNvbnN0IGNvc3QgPSBhZ2VudFJ1bnMucmVkdWNlKChzdW0sIHIpID0+IHN1bSArIHIuY29zdFVzZCwgMCk7XG4gICAgY29uc3QgcnVuQ291bnQgPSBhZ2VudFJ1bnMubGVuZ3RoO1xuICAgIHJldHVybiB7IGFnZW50LCBjb3N0LCBydW5Db3VudCB9O1xuICB9KS5zb3J0KChhLCBiKSA9PiBiLmNvc3QgLSBhLmNvc3QpO1xuXG4gIC8vIENvc3QgYnkgdGFza1xuICBjb25zdCBjb3N0QnlUYXNrID0gdGFza3MubWFwKCh0YXNrKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHRhc2ssXG4gICAgICBjb3N0OiB0YXNrLmFjdHVhbENvc3QsXG4gICAgICBidWRnZXQ6IHRhc2suYnVkZ2V0QWxsb2NhdGVkIHx8IDAsXG4gICAgICByZW1haW5pbmc6IHRhc2suYnVkZ2V0UmVtYWluaW5nIHx8IDAsXG4gICAgfTtcbiAgfSkuc29ydCgoYSwgYikgPT4gYi5jb3N0IC0gYS5jb3N0KTtcblxuICAvLyBDb3N0IGJ5IG1vZGVsXG4gIGNvbnN0IGNvc3RCeU1vZGVsOiBSZWNvcmQ8c3RyaW5nLCB7IGNvc3Q6IG51bWJlcjsgcnVuczogbnVtYmVyIH0+ID0ge307XG4gIGZvciAoY29uc3QgcnVuIG9mIHJ1bnMpIHtcbiAgICBpZiAoIWNvc3RCeU1vZGVsW3J1bi5tb2RlbF0pIHtcbiAgICAgIGNvc3RCeU1vZGVsW3J1bi5tb2RlbF0gPSB7IGNvc3Q6IDAsIHJ1bnM6IDAgfTtcbiAgICB9XG4gICAgY29zdEJ5TW9kZWxbcnVuLm1vZGVsXS5jb3N0ICs9IHJ1bi5jb3N0VXNkO1xuICAgIGNvc3RCeU1vZGVsW3J1bi5tb2RlbF0ucnVucysrO1xuICB9XG4gIGNvbnN0IG1vZGVsU3RhdHMgPSBPYmplY3QuZW50cmllcyhjb3N0QnlNb2RlbClcbiAgICAubWFwKChbbW9kZWwsIHN0YXRzXSkgPT4gKHsgbW9kZWwsIC4uLnN0YXRzIH0pKVxuICAgIC5zb3J0KChhLCBiKSA9PiBiLmNvc3QgLSBhLmNvc3QpO1xuXG4gIC8vIERhaWx5IGNvc3QgdHJlbmQgKGxhc3QgNyBkYXlzKVxuICBjb25zdCBkYWlseUNvc3RzOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+ID0ge307XG4gIGZvciAoY29uc3QgcnVuIG9mIHJ1bnMpIHtcbiAgICBpZiAocnVuLnN0YXJ0ZWRBdCA+PSBsYXN0N0RheXMpIHtcbiAgICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShydW4uc3RhcnRlZEF0KS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcbiAgICAgIGRhaWx5Q29zdHNbZGF0ZV0gPSAoZGFpbHlDb3N0c1tkYXRlXSB8fCAwKSArIHJ1bi5jb3N0VXNkO1xuICAgIH1cbiAgfVxuICBjb25zdCBjb3N0VHJlbmQgPSBPYmplY3QuZW50cmllcyhkYWlseUNvc3RzKVxuICAgIC5tYXAoKFtkYXRlLCBjb3N0XSkgPT4gKHsgZGF0ZSwgY29zdCB9KSlcbiAgICAuc29ydCgoYSwgYikgPT4gYS5kYXRlLmxvY2FsZUNvbXBhcmUoYi5kYXRlKSk7XG5cbiAgY29uc3QgbWF4RGFpbHlDb3N0ID0gTWF0aC5tYXgoLi4uT2JqZWN0LnZhbHVlcyhkYWlseUNvc3RzKSwgMSk7XG5cbiAgLy8gUHJvdmlkZXIgYmlsbGluZyBkYXNoYm9hcmRzIChtYW51YWwgYXV0aCBvbmx5IOKAlCBzZWUgZG9jcy9DT1NUUy5tZCkuIEdyb3VwZWQgZm9yIGNsYXJpdHkuXG4gIGNvbnN0IHByb3ZpZGVyQmlsbGluZ0dyb3VwczogeyBsYWJlbDogc3RyaW5nOyBsaW5rczogeyBuYW1lOiBzdHJpbmc7IHVybDogc3RyaW5nIH1bXSB9W10gPSBbXG4gICAge1xuICAgICAgbGFiZWw6IFwiQUkgJiBtb2RlbHNcIixcbiAgICAgIGxpbmtzOiBbXG4gICAgICAgIHsgbmFtZTogXCJBbnRocm9waWNcIiwgdXJsOiBcImh0dHBzOi8vY29uc29sZS5hbnRocm9waWMuY29tL3NldHRpbmdzL2JpbGxpbmdcIiB9LFxuICAgICAgICB7IG5hbWU6IFwiT3BlbkFJXCIsIHVybDogXCJodHRwczovL3BsYXRmb3JtLm9wZW5haS5jb20vdXNhZ2VcIiB9LFxuICAgICAgICB7IG5hbWU6IFwiR29vZ2xlIC8gR2VtaW5pXCIsIHVybDogXCJodHRwczovL2NvbnNvbGUuY2xvdWQuZ29vZ2xlLmNvbS9iaWxsaW5nXCIgfSxcbiAgICAgICAgeyBuYW1lOiBcIk9wZW5Sb3V0ZXJcIiwgdXJsOiBcImh0dHBzOi8vb3BlbnJvdXRlci5haS9jcmVkaXRzXCIgfSxcbiAgICAgICAgeyBuYW1lOiBcIlBlcnBsZXhpdHlcIiwgdXJsOiBcImh0dHBzOi8vd3d3LnBlcnBsZXhpdHkuYWkvc2V0dGluZ3NcIiB9LFxuICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgIGxhYmVsOiBcIkluZnJhc3RydWN0dXJlXCIsXG4gICAgICBsaW5rczogW1xuICAgICAgICB7IG5hbWU6IFwiQ29udmV4XCIsIHVybDogXCJodHRwczovL2Rhc2hib2FyZC5jb252ZXguZGV2XCIgfSxcbiAgICAgICAgeyBuYW1lOiBcIlZlcmNlbFwiLCB1cmw6IFwiaHR0cHM6Ly92ZXJjZWwuY29tL2Rhc2hib2FyZC9iaWxsaW5nXCIgfSxcbiAgICAgICAgeyBuYW1lOiBcIkdpdEh1YlwiLCB1cmw6IFwiaHR0cHM6Ly9naXRodWIuY29tL3NldHRpbmdzL2JpbGxpbmdcIiB9LFxuICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgIGxhYmVsOiBcIlRvb2xzICYgc2VydmljZXNcIixcbiAgICAgIGxpbmtzOiBbXG4gICAgICAgIHsgbmFtZTogXCJDdXJzb3JcIiwgdXJsOiBcImh0dHBzOi8vY3Vyc29yLmNvbVwiIH0sXG4gICAgICAgIHsgbmFtZTogXCJFbGV2ZW5MYWJzXCIsIHVybDogXCJodHRwczovL2VsZXZlbmxhYnMuaW8vc3Vic2NyaXB0aW9uXCIgfSxcbiAgICAgICAgeyBuYW1lOiBcIlR3aWxpb1wiLCB1cmw6IFwiaHR0cHM6Ly9jb25zb2xlLnR3aWxpby5jb20vYmlsbGluZ1wiIH0sXG4gICAgICBdLFxuICAgIH0sXG4gIF07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ibGFjay82MCBwLTRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtYXgtaC1bOTB2aF0gdy1mdWxsIG1heC13LTd4bCBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xXCI+XG4gICAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2hyaW5rLTAgYm9yZGVyLWIgYm9yZGVyLWxpbmUgcC02XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsxOXB4XSBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+Q29zdCBhbmFseXRpY3M8L2gyPlxuICAgICAgICAgICAgICA8cFxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1bMTNweF0gdGV4dC1pbmstc2Vjb25kYXJ5XCJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIkNvc3QgZnJvbSBhZ2VudCBydW5zLiBTYXZpbmdzIHZzLiBwYXlpbmcgbGlzdCBwcmljZSB3aXRob3V0IHJ1bi1sZXZlbCBvcHRpbWl6YXRpb25zLlwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7cnVucy5sZW5ndGh9IHJ1bnMgwrcgJHt0b3RhbENvc3QudG9GaXhlZCgyKX0gdG90YWxcbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgcC0xLjUgdGV4dC1pbmstbXV0ZWQgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGhvdmVyOmJnLXN1cmZhY2UtMiBob3Zlcjp0ZXh0LWlua1wiXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJDbG9zZVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxYIHNpemU9ezE2fSBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQ29udGVudCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHAtNlwiPlxuICAgICAgICAgIHsvKiBTdW1tYXJ5ICovfVxuICAgICAgICAgIDxNZXRyaWNSb3cgY2xhc3NOYW1lPVwibWItNlwiPlxuICAgICAgICAgICAgPE1ldHJpY0Jsb2NrIGxhYmVsPVwiVG9kYXlcIiB2YWx1ZT17YCQke3RvZGF5Q29zdC50b0ZpeGVkKDIpfWB9IC8+XG4gICAgICAgICAgICA8TWV0cmljQmxvY2sgbGFiZWw9XCJMYXN0IDcgZGF5c1wiIHZhbHVlPXtgJCR7bGFzdDdEYXlzQ29zdC50b0ZpeGVkKDIpfWB9IC8+XG4gICAgICAgICAgICA8TWV0cmljQmxvY2sgbGFiZWw9XCJMYXN0IDMwIGRheXNcIiB2YWx1ZT17YCQke2xhc3QzMERheXNDb3N0LnRvRml4ZWQoMil9YH0gLz5cbiAgICAgICAgICAgIDxNZXRyaWNCbG9jayBsYWJlbD1cIkFsbCB0aW1lXCIgdmFsdWU9e2AkJHt0b3RhbENvc3QudG9GaXhlZCgyKX1gfSAvPlxuICAgICAgICAgIDwvTWV0cmljUm93PlxuXG4gICAgICAgICAgey8qIFByb3ZpZGVyIGJpbGxpbmcg4oCUIGdyb3VwZWQgdmVuZG9yIGRhc2hib2FyZHMgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2NuKENBUkRfQ0xBU1MsIFwibWItNiBwLTVcIil9PlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj5Qcm92aWRlciBiaWxsaW5nPC9oMz5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICBWZW5kb3IgZGFzaGJvYXJkcyByZXF1aXJlIG1hbnVhbCBzaWduLWluLiBSZXZpZXcgcmVndWxhcmx5IGFuZCB1cGRhdGV7XCIgXCJ9XG4gICAgICAgICAgICAgIDxjb2RlIGNsYXNzTmFtZT1cInJvdW5kZWQgYmctc3VyZmFjZS0yIHB4LTEuNSBweS0wLjUgZm9udC1tb25vIHRleHQtWzExcHhdIHRleHQtaW5rLXNlY29uZGFyeVwiPmRvY3MvQ09TVFMubWQ8L2NvZGU+e1wiIFwifVxuICAgICAgICAgICAgICB3aXRoIGN1cnJlbnQgc3BlbmRpbmcuXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZ3JpZCBncmlkLWNvbHMtMSBnYXAtNiBtZDpncmlkLWNvbHMtM1wiPlxuICAgICAgICAgICAgICB7cHJvdmlkZXJCaWxsaW5nR3JvdXBzLm1hcCgoeyBsYWJlbCwgbGlua3MgfSkgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtsYWJlbH0+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTIgdGV4dC1bMTEuNXB4XSBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMDZlbV0gdGV4dC1pbmstbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAge2xhYmVsfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8dWw+XG4gICAgICAgICAgICAgICAgICAgIHtsaW5rcy5tYXAoKHsgbmFtZSwgdXJsIH0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtuYW1lfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e3VybH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiByb3VuZGVkLW1kIHB4LTMgcHktMiB0ZXh0LVsxM3B4XSB0ZXh0LWluay1zZWNvbmRhcnkgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGhvdmVyOmJnLXN1cmZhY2UtMiBob3Zlcjp0ZXh0LWlua1wiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntuYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEV4dGVybmFsTGlua1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9ezE0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsxLjc1fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNocmluay0wIHRleHQtaW5rLW11dGVkIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBncm91cC1ob3Zlcjp0ZXh0LWluay1zZWNvbmRhcnlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBib3JkZXItdCBib3JkZXItbGluZSBwdC00IHRleHQtWzEycHhdIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAgICAgIDxGaWxlVGV4dCBzaXplPXsxNH0gc3Ryb2tlV2lkdGg9ezEuNzV9IGNsYXNzTmFtZT1cInNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgRnVsbCBjaGVja2xpc3QgYW5kIHNwZW5kaW5nIHRhYmxlOntcIiBcIn1cbiAgICAgICAgICAgICAgPGNvZGUgY2xhc3NOYW1lPVwicm91bmRlZCBiZy1zdXJmYWNlLTIgcHgtMS41IHB5LTAuNSBmb250LW1vbm8gdGV4dC1bMTFweF0gdGV4dC1pbmstc2Vjb25kYXJ5XCI+ZG9jcy9DT1NUUy5tZDwvY29kZT5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBEYWlseSBUcmVuZCBDaGFydCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17Y24oQ0FSRF9DTEFTUywgXCJtYi02XCIpfT5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj5cbiAgICAgICAgICAgICAgRGFpbHkgY29zdCB0cmVuZCAobGFzdCA3IGRheXMpXG4gICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAge2Nvc3RUcmVuZC5tYXAoKHsgZGF0ZSwgY29zdCB9KSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2RhdGV9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMjQgc2hyaW5rLTAgdGV4dC1bMTJweF0gdGV4dC1pbmstbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKGRhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLVVTXCIsIHsgbW9udGg6IFwic2hvcnRcIiwgZGF5OiBcIm51bWVyaWNcIiB9KX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBoLTYgZmxleC0xIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLW1kIGJnLXN1cmZhY2UtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC02IG1pbi13LVsycHhdIHJvdW5kZWQtbWRcIlxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogYCR7KGNvc3QgLyBtYXhEYWlseUNvc3QpICogMTAwfSVgLFxuICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBDSEFSVF9TRVJJRVNbMF0sXG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGZsZXggaXRlbXMtY2VudGVyIHB4LTIgZm9udC1tb25vIHRleHQtWzEycHhdIGZvbnQtbWVkaXVtIHRleHQtaW5rXCI+XG4gICAgICAgICAgICAgICAgICAgICAgJHtjb3N0LnRvRml4ZWQoMil9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTYgbGc6Z3JpZC1jb2xzLTJcIj5cbiAgICAgICAgICAgIHsvKiBDb3N0IGJ5IEFnZW50ICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e0NBUkRfQ0xBU1N9PlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+Q29zdCBieSBhZ2VudDwvaDM+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAge2Nvc3RCeUFnZW50LnNsaWNlKDAsIDEwKS5tYXAoKHsgYWdlbnQsIGNvc3QsIHJ1bkNvdW50IH0pID0+IChcbiAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXthZ2VudC5faWR9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLXctMCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZSB0ZXh0LVsxM3B4XSB0ZXh0LWlua1wiPnthZ2VudC5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzaHJpbmstMCB0ZXh0LVsxMnB4XSB0ZXh0LWluay1tdXRlZFwiPih7cnVuQ291bnR9IHJ1bnMpPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBzaHJpbmstMCBmb250LW1vbm8gdGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGFidWxhci1udW1zIHRleHQtaW5rXCI+XG4gICAgICAgICAgICAgICAgICAgICAgJHtjb3N0LnRvRml4ZWQoMil9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQ29zdCBieSBNb2RlbCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtDQVJEX0NMQVNTfT5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPkNvc3QgYnkgbW9kZWw8L2gzPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgIHttb2RlbFN0YXRzLm1hcCgoeyBtb2RlbCwgY29zdCwgcnVucyB9KSA9PiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17bW9kZWx9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLXctMCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZSBmb250LW1vbm8gdGV4dC1bMTIuNXB4XSB0ZXh0LWlua1wiPnttb2RlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2hyaW5rLTAgdGV4dC1bMTJweF0gdGV4dC1pbmstbXV0ZWRcIj4oe3J1bnN9IHJ1bnMpPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBzaHJpbmstMCBmb250LW1vbm8gdGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGFidWxhci1udW1zIHRleHQtaW5rXCI+XG4gICAgICAgICAgICAgICAgICAgICAgJHtjb3N0LnRvRml4ZWQoMil9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogTW9zdCBFeHBlbnNpdmUgVGFza3MgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17Y24oQ0FSRF9DTEFTUywgXCJsZzpjb2wtc3Bhbi0yXCIpfT5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPk1vc3QgZXhwZW5zaXZlIHRhc2tzPC9oMz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICB7Y29zdEJ5VGFzay5zbGljZSgwLCAxMCkubWFwKCh7IHRhc2ssIGNvc3QsIGJ1ZGdldCwgcmVtYWluaW5nIH0pID0+IChcbiAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXt0YXNrLl9pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidHJ1bmNhdGUgdGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGV4dC1pbmtcIj57dGFzay50aXRsZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTAuNSB0ZXh0LVsxMnB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3Rhc2sudHlwZX0gwrcgUHJpb3JpdHkge3Rhc2sucHJpb3JpdHl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAge2J1ZGdldCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0xLjUgdy1mdWxsIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLWZ1bGwgYmctc3VyZmFjZS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJoLTEuNSByb3VuZGVkLWZ1bGxcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVtYWluaW5nIDwgMFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1lcnJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogcmVtYWluaW5nIDwgYnVkZ2V0ICogMC4yXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctd2FyblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctb2tcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHtNYXRoLm1pbigoY29zdCAvIGJ1ZGdldCkgKiAxMDAsIDEwMCl9JWAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIGZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtWzEycHhdIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+JHtjb3N0LnRvRml4ZWQoMil9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPiR7YnVkZ2V0LnRvRml4ZWQoMil9IGJ1ZGdldDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaHJpbmstMCB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB0YWJ1bGFyLW51bXMgdGV4dC1pbmtcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICR7Y29zdC50b0ZpeGVkKDIpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIHtidWRnZXQgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIm10LTAuNSB0ZXh0LVsxMnB4XVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbWFpbmluZyA8IDAgPyBcInRleHQtZXJyXCIgOiBcInRleHQtaW5rLW11dGVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3JlbWFpbmluZyA8IDAgPyBcIk92ZXJcIiA6IGAke3JlbWFpbmluZy50b0ZpeGVkKDIpfSBsZWZ0YH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9Db3N0QW5hbHl0aWNzLnRzeCJ9