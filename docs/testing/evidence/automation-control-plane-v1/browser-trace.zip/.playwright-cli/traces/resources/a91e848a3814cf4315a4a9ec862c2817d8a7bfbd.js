import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/CreateTaskModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { Bot, CalendarDays, Flag, Layers3 } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { Button } from "/src/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "/src/components/ui/dialog.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
import { Textarea } from "/src/components/ui/textarea.tsx";
import { parseDateInputValue } from "/src/lib/dateInput.ts";
const TASK_TYPES = [
  "CONTENT",
  "SOCIAL",
  "EMAIL_MARKETING",
  "CUSTOMER_RESEARCH",
  "SEO_RESEARCH",
  "ENGINEERING",
  "DOCS",
  "OPS"
];
const PRIORITIES = [
  { value: 1, label: "Critical" },
  { value: 2, label: "High" },
  { value: 3, label: "Normal" },
  { value: 4, label: "Low" }
];
export function CreateTaskModal({
  projectId,
  onClose,
  onCreated
}) {
  _s();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [type, setType] = useState("ENGINEERING");
  const [priority, setPriority] = useState(3);
  const [dueAt, setDueAt] = useState("");
  const [assigneeIds, setAssigneeIds] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const agents = useQuery(api.agents.listAll, projectId ? { projectId } : {});
  const createTask = useMutation(api.tasks.create);
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim()) {
      setError("Title is required");
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      await createTask({
        projectId: projectId ?? void 0,
        title: title.trim(),
        description: description.trim() || void 0,
        type,
        priority,
        dueAt: parseDateInputValue(dueAt) ?? void 0,
        assigneeIds: assigneeIds.length > 0 ? assigneeIds : void 0,
        idempotencyKey: `ui-create:${Date.now()}`,
        source: "DASHBOARD",
        createdBy: "HUMAN"
      });
      onCreated?.();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to create task");
    }
    setSubmitting(false);
  };
  const toggleAssignee = (id) => {
    setAssigneeIds(
      (prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };
  return /* @__PURE__ */ jsxDEV(Dialog, { open: true, onOpenChange: (open) => {
    if (!open) onClose();
  }, children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "max-h-[90vh] overflow-y-auto sm:max-w-[640px]", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Create Task" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
        lineNumber: 125,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Add work to the queue with clear routing, priority, and due-date context so agents can execute without guesswork." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
        lineNumber: 126,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
      lineNumber: 124,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 lg:grid-cols-[minmax(0,1.3fr)_minmax(240px,0.7fr)]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 rounded-xl border border-line bg-surface-2 p-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(Layers3, { className: "h-4 w-4 text-ink-muted", strokeWidth: 1.75 }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
              lineNumber: 135,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-[11.5px] font-semibold uppercase tracking-[0.06em] text-ink-muted", children: "Task brief" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
              lineNumber: 136,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
            lineNumber: 134,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV(Label, { htmlFor: "task-title", children: "Title" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
              lineNumber: 139,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                id: "task-title",
                type: "text",
                value: title,
                onChange: (e) => setTitle(e.target.value),
                placeholder: "What needs to be done?",
                autoFocus: true,
                required: true
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                lineNumber: 140,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
            lineNumber: 138,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV(Label, { htmlFor: "task-description", children: "Description" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
              lineNumber: 152,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Textarea,
              {
                id: "task-description",
                value: description,
                onChange: (e) => setDescription(e.target.value),
                placeholder: "Add enough context that the next operator or agent knows the goal, constraints, and expected outcome.",
                rows: 5
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                lineNumber: 153,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
            lineNumber: 151,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
          lineNumber: 133,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 rounded-xl border border-line bg-surface-2 p-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(Flag, { className: "h-4 w-4 text-ink-muted", strokeWidth: 1.75 }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
              lineNumber: 165,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-[11.5px] font-semibold uppercase tracking-[0.06em] text-ink-muted", children: "Routing" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
              lineNumber: 166,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
            lineNumber: 164,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV(Label, { htmlFor: "task-type", children: "Type" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                lineNumber: 171,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(Select, { value: type, onValueChange: setType, children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { id: "task-type", children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                  lineNumber: 174,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                  lineNumber: 173,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: TASK_TYPES.map(
                  (taskType) => /* @__PURE__ */ jsxDEV(SelectItem, { value: taskType, children: taskType }, taskType, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                    lineNumber: 178,
                    columnNumber: 23
                  }, this)
                ) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                  lineNumber: 176,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                lineNumber: 172,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
              lineNumber: 170,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV(Label, { htmlFor: "task-priority", children: "Priority" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                lineNumber: 187,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  value: String(priority),
                  onValueChange: (value) => setPriority(Number(value)),
                  children: [
                    /* @__PURE__ */ jsxDEV(SelectTrigger, { id: "task-priority", children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                      lineNumber: 193,
                      columnNumber: 23
                    }, this) }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                      lineNumber: 192,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectContent, { children: PRIORITIES.map(
                      (p) => /* @__PURE__ */ jsxDEV(SelectItem, { value: String(p.value), children: p.label }, p.value, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                        lineNumber: 197,
                        columnNumber: 23
                      }, this)
                    ) }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                      lineNumber: 195,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                  lineNumber: 188,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
              lineNumber: 186,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV(Label, { htmlFor: "task-due", children: "Due date" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                lineNumber: 206,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                /* @__PURE__ */ jsxDEV(CalendarDays, { className: "pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                  lineNumber: 208,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    id: "task-due",
                    type: "date",
                    value: dueAt,
                    onChange: (e) => setDueAt(e.target.value),
                    className: "w-full pl-10"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                    lineNumber: 209,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                lineNumber: 207,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
              lineNumber: 205,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
            lineNumber: 169,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
          lineNumber: 163,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
        lineNumber: 132,
        columnNumber: 11
      }, this),
      agents && agents.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-3 rounded-xl border border-line bg-surface-2 p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(Bot, { className: "h-4 w-4 text-ink-muted", strokeWidth: 1.75 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
            lineNumber: 225,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Label, { children: "Assignees" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
            lineNumber: 226,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
          lineNumber: 224,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: agents.map((agent) => {
          const selected = assigneeIds.includes(agent._id);
          return /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "button",
              variant: selected ? "default" : "outline",
              size: "sm",
              className: "h-9 gap-2 rounded-lg px-3",
              onClick: () => toggleAssignee(agent._id),
              children: [
                /* @__PURE__ */ jsxDEV(Bot, { className: "h-3.5 w-3.5", strokeWidth: 1.75 }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                  lineNumber: 240,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: agent.name }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
                  lineNumber: 241,
                  columnNumber: 23
                }, this)
              ]
            },
            agent._id,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
              lineNumber: 232,
              columnNumber: 19
            },
            this
          );
        }) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
          lineNumber: 228,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
        lineNumber: 223,
        columnNumber: 11
      }, this),
      error && /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive", children: error }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
        lineNumber: 250,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
        /* @__PURE__ */ jsxDEV(Button, { type: "button", variant: "outline", onClick: onClose, children: "Cancel" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
          lineNumber: 256,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { type: "submit", disabled: submitting, children: submitting ? "Creating..." : "Create Task" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
          lineNumber: 259,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
        lineNumber: 255,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
      lineNumber: 131,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
    lineNumber: 123,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx",
    lineNumber: 122,
    columnNumber: 5
  }, this);
}
_s(CreateTaskModal, "pwk/QftEiDAQwHk5oS5zONE/RJ8=", false, function() {
  return [useQuery, useMutation];
});
_c = CreateTaskModal;
var _c;
$RefreshReg$(_c, "CreateTaskModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateTaskModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUdVOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpHVixTQUFTQSxnQkFBZ0M7QUFDekMsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLFdBQVc7QUFFcEIsU0FBU0MsS0FBS0MsY0FBY0MsTUFBTUMsZUFBZTtBQUNqRCxTQUFTQyxjQUFjO0FBQ3ZCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsYUFBYTtBQUN0QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsMkJBQTJCO0FBRXBDLE1BQU1DLGFBQWE7QUFBQSxFQUNqQjtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBSztBQUdQLE1BQU1DLGFBQWE7QUFBQSxFQUNqQixFQUFFQyxPQUFPLEdBQUdDLE9BQU8sV0FBVztBQUFBLEVBQzlCLEVBQUVELE9BQU8sR0FBR0MsT0FBTyxPQUFPO0FBQUEsRUFDMUIsRUFBRUQsT0FBTyxHQUFHQyxPQUFPLFNBQVM7QUFBQSxFQUM1QixFQUFFRCxPQUFPLEdBQUdDLE9BQU8sTUFBTTtBQUFDO0FBR3JCLGdCQUFTQyxnQkFBZ0I7QUFBQSxFQUM5QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFLRixHQUFHO0FBQUFDLEtBQUE7QUFDRCxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSWxDLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNtQyxhQUFhQyxjQUFjLElBQUlwQyxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDcUMsTUFBTUMsT0FBTyxJQUFJdEMsU0FBaUIsYUFBYTtBQUN0RCxRQUFNLENBQUN1QyxVQUFVQyxXQUFXLElBQUl4QyxTQUFTLENBQUM7QUFDMUMsUUFBTSxDQUFDeUMsT0FBT0MsUUFBUSxJQUFJMUMsU0FBaUIsRUFBRTtBQUM3QyxRQUFNLENBQUMyQyxhQUFhQyxjQUFjLElBQUk1QyxTQUF5QixFQUFFO0FBQ2pFLFFBQU0sQ0FBQzZDLFlBQVlDLGFBQWEsSUFBSTlDLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUMrQyxPQUFPQyxRQUFRLElBQUloRCxTQUF3QixJQUFJO0FBRXRELFFBQU1pRCxTQUFTL0MsU0FBU0MsSUFBSThDLE9BQU9DLFNBQVNyQixZQUFZLEVBQUVBLFVBQVUsSUFBSSxDQUFDLENBQUM7QUFDMUUsUUFBTXNCLGFBQWFsRCxZQUFZRSxJQUFJaUQsTUFBTUMsTUFBTTtBQUUvQyxRQUFNQyxlQUFlLE9BQU9DLE1BQWlCO0FBQzNDQSxNQUFFQyxlQUFlO0FBQ2pCLFFBQUksQ0FBQ3ZCLE1BQU13QixLQUFLLEdBQUc7QUFDakJULGVBQVMsbUJBQW1CO0FBQzVCO0FBQUEsSUFDRjtBQUVBRixrQkFBYyxJQUFJO0FBQ2xCRSxhQUFTLElBQUk7QUFDYixRQUFJO0FBQ0YsWUFBTUcsV0FBVztBQUFBLFFBQ2Z0QixXQUFXQSxhQUFhNkI7QUFBQUEsUUFDeEJ6QixPQUFPQSxNQUFNd0IsS0FBSztBQUFBLFFBQ2xCdEIsYUFBYUEsWUFBWXNCLEtBQUssS0FBS0M7QUFBQUEsUUFDbkNyQjtBQUFBQSxRQUNBRTtBQUFBQSxRQUNBRSxPQUFPbEIsb0JBQW9Ca0IsS0FBSyxLQUFLaUI7QUFBQUEsUUFDckNmLGFBQWFBLFlBQVlnQixTQUFTLElBQUloQixjQUFjZTtBQUFBQSxRQUNwREUsZ0JBQWdCLGFBQWFDLEtBQUtDLElBQUksQ0FBQztBQUFBLFFBQ3ZDQyxRQUFRO0FBQUEsUUFDUkMsV0FBVztBQUFBLE1BQ2IsQ0FBQztBQUNEakMsa0JBQVk7QUFDWkQsY0FBUTtBQUFBLElBQ1YsU0FBU21DLEtBQUs7QUFDWmpCLGVBQVNpQixlQUFlQyxRQUFRRCxJQUFJRSxVQUFVLHVCQUF1QjtBQUFBLElBQ3ZFO0FBQ0FyQixrQkFBYyxLQUFLO0FBQUEsRUFDckI7QUFFQSxRQUFNc0IsaUJBQWlCQSxDQUFDQyxPQUFxQjtBQUMzQ3pCO0FBQUFBLE1BQWUsQ0FBQzBCLFNBQ2RBLEtBQUtDLFNBQVNGLEVBQUUsSUFBSUMsS0FBS0UsT0FBTyxDQUFDQyxNQUFNQSxNQUFNSixFQUFFLElBQUksQ0FBQyxHQUFHQyxNQUFNRCxFQUFFO0FBQUEsSUFDakU7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxVQUFPLE1BQUksTUFBQyxjQUFjLENBQUNLLFNBQVM7QUFBRSxRQUFJLENBQUNBLEtBQU01QyxTQUFRO0FBQUEsRUFBRyxHQUMzRCxpQ0FBQyxpQkFBYyxXQUFVLGlEQUN2QjtBQUFBLDJCQUFDLGdCQUNDO0FBQUEsNkJBQUMsZUFBWSwyQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdCO0FBQUEsTUFDeEIsdUJBQUMscUJBQWlCLGlJQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBRUEsdUJBQUMsVUFBSyxVQUFVd0IsY0FBYyxXQUFVLGFBQ3RDO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsbUNBQUMsV0FBUSxXQUFVLDBCQUF5QixhQUFhLFFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThEO0FBQUEsWUFDOUQsdUJBQUMsU0FBSSxXQUFVLDBFQUF5RSwwQkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0c7QUFBQSxlQUZwRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLG1DQUFDLFNBQU0sU0FBUSxjQUFhLHFCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBLFlBQ2pDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsSUFBRztBQUFBLGdCQUNILE1BQUs7QUFBQSxnQkFDTCxPQUFPckI7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDc0IsTUFBTXJCLFNBQVNxQixFQUFFb0IsT0FBT2pELEtBQUs7QUFBQSxnQkFDeEMsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsVUFBUTtBQUFBO0FBQUEsY0FQVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPVTtBQUFBLGVBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxtQ0FBQyxTQUFNLFNBQVEsb0JBQW1CLDJCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QztBQUFBLFlBQzdDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsSUFBRztBQUFBLGdCQUNILE9BQU9TO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ29CLE1BQU1uQixlQUFlbUIsRUFBRW9CLE9BQU9qRCxLQUFLO0FBQUEsZ0JBQzlDLGFBQVk7QUFBQSxnQkFDWixNQUFNO0FBQUE7QUFBQSxjQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtVO0FBQUEsZUFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsYUEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsbUNBQUMsUUFBSyxXQUFVLDBCQUF5QixhQUFhLFFBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJEO0FBQUEsWUFDM0QsdUJBQUMsU0FBSSxXQUFVLDBFQUF5RSx1QkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Y7QUFBQSxlQUZqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHFDQUFDLFNBQU0sU0FBUSxhQUFZLG9CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBLGNBQy9CLHVCQUFDLFVBQU8sT0FBT1csTUFBTSxlQUFlQyxTQUNsQztBQUFBLHVDQUFDLGlCQUFjLElBQUcsYUFDaEIsaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBWSxLQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxpQkFDRWQscUJBQVdvRDtBQUFBQSxrQkFBSSxDQUFDQyxhQUNmLHVCQUFDLGNBQTBCLE9BQU9BLFVBQy9CQSxzQkFEY0EsVUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBLG1CQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxpQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHFDQUFDLFNBQU0sU0FBUSxpQkFBZ0Isd0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVDO0FBQUEsY0FDdkM7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBT0MsT0FBT3ZDLFFBQVE7QUFBQSxrQkFDdEIsZUFBZSxDQUFDYixVQUFVYyxZQUFZdUMsT0FBT3JELEtBQUssQ0FBQztBQUFBLGtCQUVuRDtBQUFBLDJDQUFDLGlCQUFjLElBQUcsaUJBQ2hCLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQVksS0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsaUJBQ0VELHFCQUFXbUQ7QUFBQUEsc0JBQUksQ0FBQ0ksTUFDZix1QkFBQyxjQUF5QixPQUFPRixPQUFPRSxFQUFFdEQsS0FBSyxHQUM1Q3NELFlBQUVyRCxTQURZcUQsRUFBRXRELE9BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxvQkFDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTUE7QUFBQTtBQUFBO0FBQUEsZ0JBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBY0E7QUFBQSxpQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEscUNBQUMsU0FBTSxTQUFRLFlBQVcsd0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtDO0FBQUEsY0FDbEMsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSx1Q0FBQyxnQkFBYSxXQUFVLGdHQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvSDtBQUFBLGdCQUNwSDtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxJQUFHO0FBQUEsb0JBQ0gsTUFBSztBQUFBLG9CQUNMLE9BQU9lO0FBQUFBLG9CQUNQLFVBQVUsQ0FBQ2MsTUFBTWIsU0FBU2EsRUFBRW9CLE9BQU9qRCxLQUFLO0FBQUEsb0JBQ3hDLFdBQVU7QUFBQTtBQUFBLGtCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLMEI7QUFBQSxtQkFQNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGlCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUE7QUFBQSxlQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlEQTtBQUFBLGFBdkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3REE7QUFBQSxXQXZGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0ZBO0FBQUEsTUFFQ3VCLFVBQVVBLE9BQU9VLFNBQVMsS0FDekIsdUJBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsT0FBSSxXQUFVLDBCQUF5QixhQUFhLFFBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBEO0FBQUEsVUFDMUQsdUJBQUMsU0FBTSx5QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQjtBQUFBLGFBRmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNYVixpQkFBMkIyQixJQUFJLENBQUNLLFVBQVU7QUFDMUMsZ0JBQU1DLFdBQVd2QyxZQUFZNEIsU0FBU1UsTUFBTUUsR0FBRztBQUMvQyxpQkFDRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsTUFBSztBQUFBLGNBQ0wsU0FBU0QsV0FBVyxZQUFZO0FBQUEsY0FDaEMsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsU0FBUyxNQUFNZCxlQUFlYSxNQUFNRSxHQUFHO0FBQUEsY0FFdkM7QUFBQSx1Q0FBQyxPQUFJLFdBQVUsZUFBYyxhQUFhLFFBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStDO0FBQUEsZ0JBQy9DLHVCQUFDLFVBQU1GLGdCQUFNRyxRQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtCO0FBQUE7QUFBQTtBQUFBLFlBUmJILE1BQU1FO0FBQUFBLFlBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsUUFFSixDQUFDLEtBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFBQSxXQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUJBO0FBQUEsTUFHRHBDLFNBQ0MsdUJBQUMsU0FBSSxXQUFVLGdHQUNaQSxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUdGLHVCQUFDLGdCQUNDO0FBQUEsK0JBQUMsVUFBTyxNQUFLLFVBQVMsU0FBUSxXQUFVLFNBQVNqQixTQUFRLHNCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFVBQU8sTUFBSyxVQUFTLFVBQVVlLFlBQzdCQSx1QkFBYSxnQkFBZ0IsaUJBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0FuSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9JQTtBQUFBLE9BNUlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2SUEsS0E5SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStJQTtBQUVKO0FBQUNiLEdBM01lSixpQkFBZTtBQUFBLFVBa0JkMUIsVUFDSUQsV0FBVztBQUFBO0FBQUEsS0FuQmhCMkI7QUFBZSxJQUFBeUQ7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsInVzZVF1ZXJ5IiwiYXBpIiwiQm90IiwiQ2FsZW5kYXJEYXlzIiwiRmxhZyIsIkxheWVyczMiLCJCdXR0b24iLCJEaWFsb2ciLCJEaWFsb2dDb250ZW50IiwiRGlhbG9nRGVzY3JpcHRpb24iLCJEaWFsb2dGb290ZXIiLCJEaWFsb2dIZWFkZXIiLCJEaWFsb2dUaXRsZSIsIklucHV0IiwiTGFiZWwiLCJTZWxlY3QiLCJTZWxlY3RDb250ZW50IiwiU2VsZWN0SXRlbSIsIlNlbGVjdFRyaWdnZXIiLCJTZWxlY3RWYWx1ZSIsIlRleHRhcmVhIiwicGFyc2VEYXRlSW5wdXRWYWx1ZSIsIlRBU0tfVFlQRVMiLCJQUklPUklUSUVTIiwidmFsdWUiLCJsYWJlbCIsIkNyZWF0ZVRhc2tNb2RhbCIsInByb2plY3RJZCIsIm9uQ2xvc2UiLCJvbkNyZWF0ZWQiLCJfcyIsInRpdGxlIiwic2V0VGl0bGUiLCJkZXNjcmlwdGlvbiIsInNldERlc2NyaXB0aW9uIiwidHlwZSIsInNldFR5cGUiLCJwcmlvcml0eSIsInNldFByaW9yaXR5IiwiZHVlQXQiLCJzZXREdWVBdCIsImFzc2lnbmVlSWRzIiwic2V0QXNzaWduZWVJZHMiLCJzdWJtaXR0aW5nIiwic2V0U3VibWl0dGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJhZ2VudHMiLCJsaXN0QWxsIiwiY3JlYXRlVGFzayIsInRhc2tzIiwiY3JlYXRlIiwiaGFuZGxlU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwidHJpbSIsInVuZGVmaW5lZCIsImxlbmd0aCIsImlkZW1wb3RlbmN5S2V5IiwiRGF0ZSIsIm5vdyIsInNvdXJjZSIsImNyZWF0ZWRCeSIsImVyciIsIkVycm9yIiwibWVzc2FnZSIsInRvZ2dsZUFzc2lnbmVlIiwiaWQiLCJwcmV2IiwiaW5jbHVkZXMiLCJmaWx0ZXIiLCJ4Iiwib3BlbiIsInRhcmdldCIsIm1hcCIsInRhc2tUeXBlIiwiU3RyaW5nIiwiTnVtYmVyIiwicCIsImFnZW50Iiwic2VsZWN0ZWQiLCJfaWQiLCJuYW1lIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ3JlYXRlVGFza01vZGFsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdHlwZSBGb3JtRXZlbnQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB0eXBlIHsgSWQsIERvYyB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9kYXRhTW9kZWxcIjtcbmltcG9ydCB7IEJvdCwgQ2FsZW5kYXJEYXlzLCBGbGFnLCBMYXllcnMzIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9idXR0b25cIjtcbmltcG9ydCB7XG4gIERpYWxvZyxcbiAgRGlhbG9nQ29udGVudCxcbiAgRGlhbG9nRGVzY3JpcHRpb24sXG4gIERpYWxvZ0Zvb3RlcixcbiAgRGlhbG9nSGVhZGVyLFxuICBEaWFsb2dUaXRsZSxcbn0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9kaWFsb2dcIjtcbmltcG9ydCB7IElucHV0IH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9pbnB1dFwiO1xuaW1wb3J0IHsgTGFiZWwgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2xhYmVsXCI7XG5pbXBvcnQge1xuICBTZWxlY3QsXG4gIFNlbGVjdENvbnRlbnQsXG4gIFNlbGVjdEl0ZW0sXG4gIFNlbGVjdFRyaWdnZXIsXG4gIFNlbGVjdFZhbHVlLFxufSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL3NlbGVjdFwiO1xuaW1wb3J0IHsgVGV4dGFyZWEgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL3RleHRhcmVhXCI7XG5pbXBvcnQgeyBwYXJzZURhdGVJbnB1dFZhbHVlIH0gZnJvbSBcIkAvbGliL2RhdGVJbnB1dFwiO1xuXG5jb25zdCBUQVNLX1RZUEVTID0gW1xuICBcIkNPTlRFTlRcIixcbiAgXCJTT0NJQUxcIixcbiAgXCJFTUFJTF9NQVJLRVRJTkdcIixcbiAgXCJDVVNUT01FUl9SRVNFQVJDSFwiLFxuICBcIlNFT19SRVNFQVJDSFwiLFxuICBcIkVOR0lORUVSSU5HXCIsXG4gIFwiRE9DU1wiLFxuICBcIk9QU1wiLFxuXSBhcyBjb25zdDtcblxuY29uc3QgUFJJT1JJVElFUyA9IFtcbiAgeyB2YWx1ZTogMSwgbGFiZWw6IFwiQ3JpdGljYWxcIiB9LFxuICB7IHZhbHVlOiAyLCBsYWJlbDogXCJIaWdoXCIgfSxcbiAgeyB2YWx1ZTogMywgbGFiZWw6IFwiTm9ybWFsXCIgfSxcbiAgeyB2YWx1ZTogNCwgbGFiZWw6IFwiTG93XCIgfSxcbl0gYXMgY29uc3Q7XG5cbmV4cG9ydCBmdW5jdGlvbiBDcmVhdGVUYXNrTW9kYWwoe1xuICBwcm9qZWN0SWQsXG4gIG9uQ2xvc2UsXG4gIG9uQ3JlYXRlZCxcbn06IHtcbiAgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+IHwgbnVsbDtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbiAgb25DcmVhdGVkPzogKCkgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2Rlc2NyaXB0aW9uLCBzZXREZXNjcmlwdGlvbl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3R5cGUsIHNldFR5cGVdID0gdXNlU3RhdGU8c3RyaW5nPihcIkVOR0lORUVSSU5HXCIpO1xuICBjb25zdCBbcHJpb3JpdHksIHNldFByaW9yaXR5XSA9IHVzZVN0YXRlKDMpO1xuICBjb25zdCBbZHVlQXQsIHNldER1ZUF0XSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG4gIGNvbnN0IFthc3NpZ25lZUlkcywgc2V0QXNzaWduZWVJZHNdID0gdXNlU3RhdGU8SWQ8XCJhZ2VudHNcIj5bXT4oW10pO1xuICBjb25zdCBbc3VibWl0dGluZywgc2V0U3VibWl0dGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgYWdlbnRzID0gdXNlUXVlcnkoYXBpLmFnZW50cy5saXN0QWxsLCBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCB9IDoge30pO1xuICBjb25zdCBjcmVhdGVUYXNrID0gdXNlTXV0YXRpb24oYXBpLnRhc2tzLmNyZWF0ZSk7XG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGU6IEZvcm1FdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIXRpdGxlLnRyaW0oKSkge1xuICAgICAgc2V0RXJyb3IoXCJUaXRsZSBpcyByZXF1aXJlZFwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzZXRTdWJtaXR0aW5nKHRydWUpO1xuICAgIHNldEVycm9yKG51bGwpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBjcmVhdGVUYXNrKHtcbiAgICAgICAgcHJvamVjdElkOiBwcm9qZWN0SWQgPz8gdW5kZWZpbmVkLFxuICAgICAgICB0aXRsZTogdGl0bGUudHJpbSgpLFxuICAgICAgICBkZXNjcmlwdGlvbjogZGVzY3JpcHRpb24udHJpbSgpIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgdHlwZSxcbiAgICAgICAgcHJpb3JpdHksXG4gICAgICAgIGR1ZUF0OiBwYXJzZURhdGVJbnB1dFZhbHVlKGR1ZUF0KSA/PyB1bmRlZmluZWQsXG4gICAgICAgIGFzc2lnbmVlSWRzOiBhc3NpZ25lZUlkcy5sZW5ndGggPiAwID8gYXNzaWduZWVJZHMgOiB1bmRlZmluZWQsXG4gICAgICAgIGlkZW1wb3RlbmN5S2V5OiBgdWktY3JlYXRlOiR7RGF0ZS5ub3coKX1gLFxuICAgICAgICBzb3VyY2U6IFwiREFTSEJPQVJEXCIsXG4gICAgICAgIGNyZWF0ZWRCeTogXCJIVU1BTlwiLFxuICAgICAgfSk7XG4gICAgICBvbkNyZWF0ZWQ/LigpO1xuICAgICAgb25DbG9zZSgpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6IFwiRmFpbGVkIHRvIGNyZWF0ZSB0YXNrXCIpO1xuICAgIH1cbiAgICBzZXRTdWJtaXR0aW5nKGZhbHNlKTtcbiAgfTtcblxuICBjb25zdCB0b2dnbGVBc3NpZ25lZSA9IChpZDogSWQ8XCJhZ2VudHNcIj4pID0+IHtcbiAgICBzZXRBc3NpZ25lZUlkcygocHJldikgPT5cbiAgICAgIHByZXYuaW5jbHVkZXMoaWQpID8gcHJldi5maWx0ZXIoKHgpID0+IHggIT09IGlkKSA6IFsuLi5wcmV2LCBpZF1cbiAgICApO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPERpYWxvZyBvcGVuIG9uT3BlbkNoYW5nZT17KG9wZW4pID0+IHsgaWYgKCFvcGVuKSBvbkNsb3NlKCk7IH19PlxuICAgICAgPERpYWxvZ0NvbnRlbnQgY2xhc3NOYW1lPVwibWF4LWgtWzkwdmhdIG92ZXJmbG93LXktYXV0byBzbTptYXgtdy1bNjQwcHhdXCI+XG4gICAgICAgIDxEaWFsb2dIZWFkZXI+XG4gICAgICAgICAgPERpYWxvZ1RpdGxlPkNyZWF0ZSBUYXNrPC9EaWFsb2dUaXRsZT5cbiAgICAgICAgICA8RGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgICAgICBBZGQgd29yayB0byB0aGUgcXVldWUgd2l0aCBjbGVhciByb3V0aW5nLCBwcmlvcml0eSwgYW5kIGR1ZS1kYXRlIGNvbnRleHQgc28gYWdlbnRzIGNhbiBleGVjdXRlIHdpdGhvdXQgZ3Vlc3N3b3JrLlxuICAgICAgICAgIDwvRGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgIDwvRGlhbG9nSGVhZGVyPlxuXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNCBsZzpncmlkLWNvbHMtW21pbm1heCgwLDEuM2ZyKV9taW5tYXgoMjQwcHgsMC43ZnIpXVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yIHAtNFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPExheWVyczMgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWluay1tdXRlZFwiIHN0cm9rZVdpZHRoPXsxLjc1fSAvPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy1bMC4wNmVtXSB0ZXh0LWluay1tdXRlZFwiPlRhc2sgYnJpZWY8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cInRhc2stdGl0bGVcIj5UaXRsZTwvTGFiZWw+XG4gICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICBpZD1cInRhc2stdGl0bGVcIlxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3RpdGxlfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUaXRsZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIldoYXQgbmVlZHMgdG8gYmUgZG9uZT9cIlxuICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cInRhc2stZGVzY3JpcHRpb25cIj5EZXNjcmlwdGlvbjwvTGFiZWw+XG4gICAgICAgICAgICAgICAgPFRleHRhcmVhXG4gICAgICAgICAgICAgICAgICBpZD1cInRhc2stZGVzY3JpcHRpb25cIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Rlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREZXNjcmlwdGlvbihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFkZCBlbm91Z2ggY29udGV4dCB0aGF0IHRoZSBuZXh0IG9wZXJhdG9yIG9yIGFnZW50IGtub3dzIHRoZSBnb2FsLCBjb25zdHJhaW50cywgYW5kIGV4cGVjdGVkIG91dGNvbWUuXCJcbiAgICAgICAgICAgICAgICAgIHJvd3M9ezV9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yIHAtNFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPEZsYWcgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWluay1tdXRlZFwiIHN0cm9rZVdpZHRoPXsxLjc1fSAvPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy1bMC4wNmVtXSB0ZXh0LWluay1tdXRlZFwiPlJvdXRpbmc8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJ0YXNrLXR5cGVcIj5UeXBlPC9MYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QgdmFsdWU9e3R5cGV9IG9uVmFsdWVDaGFuZ2U9e3NldFR5cGV9PlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBpZD1cInRhc2stdHlwZVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSAvPlxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgICAgICAgIHtUQVNLX1RZUEVTLm1hcCgodGFza1R5cGUpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17dGFza1R5cGV9IHZhbHVlPXt0YXNrVHlwZX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt0YXNrVHlwZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cInRhc2stcHJpb3JpdHlcIj5Qcmlvcml0eTwvTGFiZWw+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtTdHJpbmcocHJpb3JpdHkpfVxuICAgICAgICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsdWUpID0+IHNldFByaW9yaXR5KE51bWJlcih2YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBpZD1cInRhc2stcHJpb3JpdHlcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICAgICAgICB7UFJJT1JJVElFUy5tYXAoKHApID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17cC52YWx1ZX0gdmFsdWU9e1N0cmluZyhwLnZhbHVlKX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtwLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwidGFzay1kdWVcIj5EdWUgZGF0ZTwvTGFiZWw+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgICAgIDxDYWxlbmRhckRheXMgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSBsZWZ0LTMgdG9wLTEvMiBoLTQgdy00IC10cmFuc2xhdGUteS0xLzIgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0YXNrLWR1ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkdWVBdH1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldER1ZUF0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtMTBcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7YWdlbnRzICYmIGFnZW50cy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMiBwLTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxCb3QgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWluay1tdXRlZFwiIHN0cm9rZVdpZHRoPXsxLjc1fSAvPlxuICAgICAgICAgICAgICAgIDxMYWJlbD5Bc3NpZ25lZXM8L0xhYmVsPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIHsoYWdlbnRzIGFzIERvYzxcImFnZW50c1wiPltdKS5tYXAoKGFnZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBzZWxlY3RlZCA9IGFzc2lnbmVlSWRzLmluY2x1ZGVzKGFnZW50Ll9pZCk7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXthZ2VudC5faWR9XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD17c2VsZWN0ZWQgPyBcImRlZmF1bHRcIiA6IFwib3V0bGluZVwifVxuICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC05IGdhcC0yIHJvdW5kZWQtbGcgcHgtM1wiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlQXNzaWduZWUoYWdlbnQuX2lkKX1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxCb3QgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57YWdlbnQubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWRlc3RydWN0aXZlLzMwIGJnLWRlc3RydWN0aXZlLzEwIHB4LTMgcHktMiB0ZXh0LXNtIHRleHQtZGVzdHJ1Y3RpdmVcIj5cbiAgICAgICAgICAgICAge2Vycm9yfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxEaWFsb2dGb290ZXI+XG4gICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9e29uQ2xvc2V9PlxuICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e3N1Ym1pdHRpbmd9PlxuICAgICAgICAgICAgICB7c3VibWl0dGluZyA/IFwiQ3JlYXRpbmcuLi5cIiA6IFwiQ3JlYXRlIFRhc2tcIn1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvRGlhbG9nRm9vdGVyPlxuICAgICAgICA8L2Zvcm0+XG4gICAgICA8L0RpYWxvZ0NvbnRlbnQ+XG4gICAgPC9EaWFsb2c+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9DcmVhdGVUYXNrTW9kYWwudHN4In0=