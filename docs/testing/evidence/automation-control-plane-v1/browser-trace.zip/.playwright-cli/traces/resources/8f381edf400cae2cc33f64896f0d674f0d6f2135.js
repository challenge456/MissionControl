import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/controlPlane/WorkOrderApprovalsView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { PageHeader } from "/src/components/PageHeader.tsx";
import { Badge } from "/src/components/ui/badge.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Card } from "/src/components/ui/card.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "/src/components/ui/select.tsx";
import { ShieldCheck } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
const STATUS_OPTIONS = ["PENDING", "APPROVED", "CONDITIONAL", "REJECTED", "REVISION_REQUESTED", "EXPIRED", "SUPERSEDED", "REVOKED"];
export function WorkOrderApprovalsView({ projectId }) {
  _s();
  const [status, setStatus] = useState("PENDING");
  const [savingId, setSavingId] = useState(null);
  const [decisionNotes, setDecisionNotes] = useState({});
  const [conditionNotes, setConditionNotes] = useState({});
  const approvals = useQuery(api.workOrders.approvalQueue, projectId ? { projectId, status } : { status });
  const decideApprovalDecision = useMutation(api.workOrders.decideApprovalDecision);
  const counts = useMemo(() => ({
    total: approvals?.length ?? 0,
    waiting: (approvals ?? []).filter((item) => item.status === "PENDING").length,
    conditional: (approvals ?? []).filter((item) => item.status === "CONDITIONAL").length
  }), [approvals]);
  async function handleDecision(approvalDecisionId, decision) {
    try {
      setSavingId(approvalDecisionId);
      await decideApprovalDecision({
        approvalDecisionId,
        decision,
        approver: "operator",
        reason: decisionNotes[approvalDecisionId] || void 0,
        conditions: decision === "APPROVE_WITH_CONDITIONS" ? conditionNotes[approvalDecisionId]?.split("\n").map((line) => line.trim()).filter(Boolean) ?? [] : void 0
      });
    } finally {
      setSavingId(null);
    }
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-full min-h-0 flex-col overflow-hidden", children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        eyebrow: "Software factory",
        title: "Approval Center",
        description: "Review WorkOrder approvals, evidence on hand, and remaining uncertainty before protected actions or acceptance.",
        icon: /* @__PURE__ */ jsxDEV(ShieldCheck, { className: "h-5 w-5" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
          lineNumber: 72,
          columnNumber: 15
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
        lineNumber: 68,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "min-h-0 flex-1 overflow-y-auto p-5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-3", children: [
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground", children: "Shown" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
            lineNumber: 77,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-semibold", children: counts.total }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
            lineNumber: 77,
            columnNumber: 123
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
          lineNumber: 77,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground", children: "Pending" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
            lineNumber: 78,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-semibold text-amber-300", children: counts.waiting }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
            lineNumber: 78,
            columnNumber: 125
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
          lineNumber: 78,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground", children: "Conditional" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
            lineNumber: 79,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-semibold text-registry-accent", children: counts.conditional }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
            lineNumber: 79,
            columnNumber: 129
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
          lineNumber: 79,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
        lineNumber: 76,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 max-w-[220px] space-y-1.5", children: [
        /* @__PURE__ */ jsxDEV(Label, { className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground", children: "Status" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
          lineNumber: 83,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Select, { value: status, onValueChange: (value) => setStatus(value), children: [
          /* @__PURE__ */ jsxDEV(SelectTrigger, { "aria-label": "Approval status filter", children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
            lineNumber: 85,
            columnNumber: 64
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
            lineNumber: 85,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(SelectContent, { children: STATUS_OPTIONS.map((option) => /* @__PURE__ */ jsxDEV(SelectItem, { value: option, children: option }, option, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
            lineNumber: 87,
            columnNumber: 47
          }, this)) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
            lineNumber: 86,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
          lineNumber: 84,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
        lineNumber: 82,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 space-y-4", children: (approvals ?? []).length === 0 ? /* @__PURE__ */ jsxDEV(Card, { className: "p-8 text-center text-sm text-muted-foreground", children: "No approvals in this status." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
        lineNumber: 94,
        columnNumber: 11
      }, this) : (approvals ?? []).map(
        (approval) => /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-start justify-between gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-foreground", children: approval.workOrder?.title ?? approval.workOrderId }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                lineNumber: 99,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: [
                approval.approvalType,
                " · ",
                approval.requestedAction
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                lineNumber: 100,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
              lineNumber: 98,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: [
              /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: approval.riskLevel }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                lineNumber: 103,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: approval.status }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                lineNumber: 104,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
              lineNumber: 102,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
            lineNumber: 97,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-3 grid gap-2 text-xs text-muted-foreground md:grid-cols-2 xl:grid-cols-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/80", children: "Evidence available:" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                lineNumber: 109,
                columnNumber: 22
              }, this),
              " ",
              approval.evidenceAvailable
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
              lineNumber: 109,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/80", children: "Approver:" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                lineNumber: 110,
                columnNumber: 22
              }, this),
              " ",
              approval.approver ?? "—"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
              lineNumber: 110,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/80", children: "Requested by:" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                lineNumber: 111,
                columnNumber: 22
              }, this),
              " ",
              approval.requestedBy ?? "—"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
              lineNumber: 111,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/80", children: "Run:" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                lineNumber: 112,
                columnNumber: 22
              }, this),
              " ",
              approval.latestRun?.runId ?? "—"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
              lineNumber: 112,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/80", children: "Revision:" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                lineNumber: 113,
                columnNumber: 22
              }, this),
              " ",
              approval.workOrderRevisionNumber ? `r${approval.workOrderRevisionNumber}` : "—"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
              lineNumber: 113,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-foreground/80", children: "Expires:" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                lineNumber: 114,
                columnNumber: 22
              }, this),
              " ",
              approval.expiresAt ? new Date(approval.expiresAt).toLocaleString() : "—"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
              lineNumber: 114,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
            lineNumber: 108,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-3 rounded-lg border border-[var(--panel-line)] bg-background/40 p-3 text-xs text-muted-foreground", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-foreground/85", children: "Remaining uncertainty" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
              lineNumber: 118,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { className: "mt-2 list-disc space-y-1 pl-4", children: (approval.remainingUncertainty?.length ? approval.remainingUncertainty : ["No blocking uncertainty recorded."]).map(
              (item, index) => /* @__PURE__ */ jsxDEV("li", { children: item }, `${approval._id}-${index}`, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                lineNumber: 121,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
              lineNumber: 119,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
            lineNumber: 117,
            columnNumber: 15
          }, this),
          approval.status === "PENDING" ? /* @__PURE__ */ jsxDEV("div", { className: "mt-4 space-y-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "grid gap-3 md:grid-cols-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
                /* @__PURE__ */ jsxDEV(Label, { children: "Decision reason" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                  lineNumber: 130,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(Input, { value: decisionNotes[approval._id] ?? "", onChange: (event) => setDecisionNotes((current) => ({ ...current, [approval._id]: event.target.value })), placeholder: "Why this decision is safe / blocked" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                  lineNumber: 131,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                lineNumber: 129,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
                /* @__PURE__ */ jsxDEV(Label, { children: "Conditions" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                  lineNumber: 134,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(Input, { value: conditionNotes[approval._id] ?? "", onChange: (event) => setConditionNotes((current) => ({ ...current, [approval._id]: event.target.value })), placeholder: "One-line condition or newline-separated list" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                  lineNumber: 135,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                lineNumber: 133,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
              lineNumber: 128,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: [
              /* @__PURE__ */ jsxDEV(Button, { size: "sm", onClick: () => handleDecision(approval._id, "APPROVE"), disabled: savingId === approval._id, children: "Approve" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                lineNumber: 139,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => handleDecision(approval._id, "APPROVE_WITH_CONDITIONS"), disabled: savingId === approval._id, children: "Approve with conditions" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                lineNumber: 140,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "destructive", onClick: () => handleDecision(approval._id, "REJECT"), disabled: savingId === approval._id, children: "Reject" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                lineNumber: 141,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "secondary", onClick: () => handleDecision(approval._id, "REQUEST_REVISION"), disabled: savingId === approval._id, children: "Request revision" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
                lineNumber: 142,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
              lineNumber: 138,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
            lineNumber: 127,
            columnNumber: 13
          }, this) : null
        ] }, approval._id, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
          lineNumber: 96,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
        lineNumber: 92,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
      lineNumber: 75,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx",
    lineNumber: 67,
    columnNumber: 5
  }, this);
}
_s(WorkOrderApprovalsView, "/PMzvuTFEtVdu+daD+u8V8S16O8=", false, function() {
  return [useQuery, useMutation];
});
_c = WorkOrderApprovalsView;
var _c;
$RefreshReg$(_c, "WorkOrderApprovalsView");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/WorkOrderApprovalsView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0RjOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBEZCxTQUFTQSxTQUFTQyxnQkFBZ0I7QUFDbEMsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLFdBQVc7QUFFcEIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxRQUFRQyxlQUFlQyxZQUFZQyxlQUFlQyxtQkFBbUI7QUFDOUUsU0FBU0MsbUJBQW1CO0FBRTVCLE1BQU1DLGlCQUFpQixDQUFDLFdBQVcsWUFBWSxlQUFlLFlBQVksc0JBQXNCLFdBQVcsY0FBYyxTQUFTO0FBRTNILGdCQUFTQyx1QkFBdUIsRUFBRUMsVUFBZ0QsR0FBRztBQUFBQyxLQUFBO0FBQzFGLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJckIsU0FBMEMsU0FBUztBQUMvRSxRQUFNLENBQUNzQixVQUFVQyxXQUFXLElBQUl2QixTQUF3QixJQUFJO0FBQzVELFFBQU0sQ0FBQ3dCLGVBQWVDLGdCQUFnQixJQUFJekIsU0FBaUMsQ0FBQyxDQUFDO0FBQzdFLFFBQU0sQ0FBQzBCLGdCQUFnQkMsaUJBQWlCLElBQUkzQixTQUFpQyxDQUFDLENBQUM7QUFDL0UsUUFBTTRCLFlBQVkxQixTQUFTQyxJQUFJMEIsV0FBV0MsZUFBZVosWUFBWSxFQUFFQSxXQUFXRSxPQUFPLElBQUksRUFBRUEsT0FBTyxDQUFDO0FBQ3ZHLFFBQU1XLHlCQUF5QjlCLFlBQVlFLElBQUkwQixXQUFXRSxzQkFBc0I7QUFFaEYsUUFBTUMsU0FBU2pDLFFBQVEsT0FBTztBQUFBLElBQzVCa0MsT0FBT0wsV0FBV00sVUFBVTtBQUFBLElBQzVCQyxVQUFVUCxhQUFhLElBQUlRLE9BQU8sQ0FBQ0MsU0FBU0EsS0FBS2pCLFdBQVcsU0FBUyxFQUFFYztBQUFBQSxJQUN2RUksY0FBY1YsYUFBYSxJQUFJUSxPQUFPLENBQUNDLFNBQVNBLEtBQUtqQixXQUFXLGFBQWEsRUFBRWM7QUFBQUEsRUFDakYsSUFBSSxDQUFDTixTQUFTLENBQUM7QUFFZixpQkFBZVcsZUFBZUMsb0JBQTRCQyxVQUFpRjtBQUN6SSxRQUFJO0FBQ0ZsQixrQkFBWWlCLGtCQUFrQjtBQUM5QixZQUFNVCx1QkFBdUI7QUFBQSxRQUMzQlM7QUFBQUEsUUFDQUM7QUFBQUEsUUFDQUMsVUFBVTtBQUFBLFFBQ1ZDLFFBQVFuQixjQUFjZ0Isa0JBQWtCLEtBQUtJO0FBQUFBLFFBQzdDQyxZQUFZSixhQUFhLDRCQUNwQmYsZUFBZWMsa0JBQWtCLEdBQUdNLE1BQU0sSUFBSSxFQUFFQyxJQUFJLENBQUNDLFNBQVNBLEtBQUtDLEtBQUssQ0FBQyxFQUFFYixPQUFPYyxPQUFPLEtBQUssS0FDL0ZOO0FBQUFBLE1BQ04sQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDckIsa0JBQVksSUFBSTtBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVE7QUFBQSxRQUNSLE9BQU07QUFBQSxRQUNOLGFBQVk7QUFBQSxRQUNaLE1BQU0sdUJBQUMsZUFBWSxXQUFVLGFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0M7QUFBQTtBQUFBLE1BSnhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUk0QztBQUFBLElBRzVDLHVCQUFDLFNBQUksV0FBVSxzQ0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLCtCQUFDLFFBQUssV0FBVSxPQUFNO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlFQUFnRSxxQkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Y7QUFBQSxVQUFNLHVCQUFDLFNBQUksV0FBVSwrQkFBK0JTLGlCQUFPQyxTQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRDtBQUFBLGFBQTNLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUw7QUFBQSxRQUNqTCx1QkFBQyxRQUFLLFdBQVUsT0FBTTtBQUFBLGlDQUFDLFNBQUksV0FBVSxpRUFBZ0UsdUJBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGO0FBQUEsVUFBTSx1QkFBQyxTQUFJLFdBQVUsOENBQThDRCxpQkFBT0csV0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEU7QUFBQSxhQUE5TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9NO0FBQUEsUUFDcE0sdUJBQUMsUUFBSyxXQUFVLE9BQU07QUFBQSxpQ0FBQyxTQUFJLFdBQVUsaUVBQWdFLDJCQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRjtBQUFBLFVBQU0sdUJBQUMsU0FBSSxXQUFVLG9EQUFvREgsaUJBQU9NLGVBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGO0FBQUEsYUFBNU07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrTjtBQUFBLFdBSHBOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEsK0JBQUMsU0FBTSxXQUFVLGlFQUFnRSxzQkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RjtBQUFBLFFBQ3ZGLHVCQUFDLFVBQU8sT0FBT2xCLFFBQVEsZUFBZSxDQUFDK0IsVUFBVTlCLFVBQVU4QixLQUF3QyxHQUNqRztBQUFBLGlDQUFDLGlCQUFjLGNBQVcsMEJBQXlCLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVksS0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0U7QUFBQSxVQUNsRSx1QkFBQyxpQkFDRW5DLHlCQUFlK0IsSUFBSSxDQUFDSyxXQUFXLHVCQUFDLGNBQXdCLE9BQU9BLFFBQVNBLG9CQUF4QkEsUUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0QsQ0FBYSxLQUQvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGtCQUNYeEIsd0JBQWEsSUFBSU0sV0FBVyxJQUM1Qix1QkFBQyxRQUFLLFdBQVUsaURBQWdELDRDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRGLEtBQ3pGTixhQUFhLElBQUltQjtBQUFBQSxRQUFJLENBQUNNLGFBQ3pCLHVCQUFDLFFBQXdCLFdBQVUsT0FDakM7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsb0RBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsU0FBSSxXQUFVLHVDQUF1Q0EsbUJBQVNDLFdBQVdDLFNBQVNGLFNBQVNHLGVBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdHO0FBQUEsY0FDeEcsdUJBQUMsU0FBSSxXQUFVLHNDQUFzQ0g7QUFBQUEseUJBQVNJO0FBQUFBLGdCQUFhO0FBQUEsZ0JBQUlKLFNBQVNLO0FBQUFBLG1CQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RztBQUFBLGlCQUYxRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxxQ0FBQyxTQUFNLFNBQVEsV0FBV0wsbUJBQVNNLGFBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZDO0FBQUEsY0FDN0MsdUJBQUMsU0FBTSxTQUFRLFdBQVdOLG1CQUFTakMsVUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEM7QUFBQSxpQkFGNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLCtFQUNiO0FBQUEsbUNBQUMsU0FBSTtBQUFBLHFDQUFDLFVBQUssV0FBVSxzQkFBcUIsbUNBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdEO0FBQUEsY0FBTztBQUFBLGNBQUVpQyxTQUFTTztBQUFBQSxpQkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUc7QUFBQSxZQUNqRyx1QkFBQyxTQUFJO0FBQUEscUNBQUMsVUFBSyxXQUFVLHNCQUFxQix5QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEM7QUFBQSxjQUFPO0FBQUEsY0FBRVAsU0FBU1gsWUFBWTtBQUFBLGlCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRjtBQUFBLFlBQ3JGLHVCQUFDLFNBQUk7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsc0JBQXFCLDZCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRDtBQUFBLGNBQU87QUFBQSxjQUFFVyxTQUFTUSxlQUFlO0FBQUEsaUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRGO0FBQUEsWUFDNUYsdUJBQUMsU0FBSTtBQUFBLHFDQUFDLFVBQUssV0FBVSxzQkFBcUIsb0JBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlDO0FBQUEsY0FBTztBQUFBLGNBQUVSLFNBQVNTLFdBQVdDLFNBQVM7QUFBQSxpQkFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Y7QUFBQSxZQUN4Rix1QkFBQyxTQUFJO0FBQUEscUNBQUMsVUFBSyxXQUFVLHNCQUFxQix5QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEM7QUFBQSxjQUFPO0FBQUEsY0FBRVYsU0FBU1csMEJBQTBCLElBQUlYLFNBQVNXLHVCQUF1QixLQUFLO0FBQUEsaUJBQXhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRJO0FBQUEsWUFDNUksdUJBQUMsU0FBSTtBQUFBLHFDQUFDLFVBQUssV0FBVSxzQkFBcUIsd0JBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZDO0FBQUEsY0FBTztBQUFBLGNBQUVYLFNBQVNZLFlBQVksSUFBSUMsS0FBS2IsU0FBU1ksU0FBUyxFQUFFRSxlQUFlLElBQUk7QUFBQSxpQkFBaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0k7QUFBQSxlQU50STtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsd0dBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsa0NBQWlDLHFDQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRTtBQUFBLFlBQ3JFLHVCQUFDLFFBQUcsV0FBVSxpQ0FDVmQsb0JBQVNlLHNCQUFzQmxDLFNBQVNtQixTQUFTZSx1QkFBdUIsQ0FBQyxtQ0FBbUMsR0FBR3JCO0FBQUFBLGNBQUksQ0FBQ1YsTUFBY2dDLFVBQ2xJLHVCQUFDLFFBQXFDaEMsa0JBQTdCLEdBQUdnQixTQUFTaUIsR0FBRyxJQUFJRCxLQUFLLElBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJDO0FBQUEsWUFDNUMsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFFQ2hCLFNBQVNqQyxXQUFXLFlBQ25CLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsdUNBQUMsU0FBTSwrQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQjtBQUFBLGdCQUN0Qix1QkFBQyxTQUFNLE9BQU9JLGNBQWM2QixTQUFTaUIsR0FBRyxLQUFLLElBQUksVUFBVSxDQUFDQyxVQUFVOUMsaUJBQWlCLENBQUMrQyxhQUFhLEVBQUUsR0FBR0EsU0FBUyxDQUFDbkIsU0FBU2lCLEdBQUcsR0FBR0MsTUFBTUUsT0FBT3RCLE1BQU0sRUFBRSxHQUFHLGFBQVkseUNBQXZLO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRNO0FBQUEsbUJBRjlNO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsdUNBQUMsU0FBTSwwQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQjtBQUFBLGdCQUNqQix1QkFBQyxTQUFNLE9BQU96QixlQUFlMkIsU0FBU2lCLEdBQUcsS0FBSyxJQUFJLFVBQVUsQ0FBQ0MsVUFBVTVDLGtCQUFrQixDQUFDNkMsYUFBYSxFQUFFLEdBQUdBLFNBQVMsQ0FBQ25CLFNBQVNpQixHQUFHLEdBQUdDLE1BQU1FLE9BQU90QixNQUFNLEVBQUUsR0FBRyxhQUFZLGtEQUF6SztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1TjtBQUFBLG1CQUZ6TjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEscUNBQUMsVUFBTyxNQUFLLE1BQUssU0FBUyxNQUFNWixlQUFlYyxTQUFTaUIsS0FBSyxTQUFTLEdBQUcsVUFBVWhELGFBQWErQixTQUFTaUIsS0FBSyx1QkFBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0g7QUFBQSxjQUN0SCx1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFRLFdBQVUsU0FBUyxNQUFNL0IsZUFBZWMsU0FBU2lCLEtBQUsseUJBQXlCLEdBQUcsVUFBVWhELGFBQWErQixTQUFTaUIsS0FBSyx1Q0FBako7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0s7QUFBQSxjQUN4Syx1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFRLGVBQWMsU0FBUyxNQUFNL0IsZUFBZWMsU0FBU2lCLEtBQUssUUFBUSxHQUFHLFVBQVVoRCxhQUFhK0IsU0FBU2lCLEtBQUssc0JBQXBJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBJO0FBQUEsY0FDMUksdUJBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxhQUFZLFNBQVMsTUFBTS9CLGVBQWVjLFNBQVNpQixLQUFLLGtCQUFrQixHQUFHLFVBQVVoRCxhQUFhK0IsU0FBU2lCLEtBQUssZ0NBQTVJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRKO0FBQUEsaUJBSjlKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQSxJQUNFO0FBQUEsYUFqREtqQixTQUFTaUIsS0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtEQTtBQUFBLE1BQ0QsS0F2REg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdEQTtBQUFBLFNBekVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwRUE7QUFBQSxPQWxGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUZBO0FBRUo7QUFBQ25ELEdBckhlRix3QkFBc0I7QUFBQSxVQUtsQmYsVUFDYUQsV0FBVztBQUFBO0FBQUEsS0FONUJnQjtBQUFzQixJQUFBeUQ7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsInVzZVN0YXRlIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsImFwaSIsIlBhZ2VIZWFkZXIiLCJCYWRnZSIsIkJ1dHRvbiIsIkNhcmQiLCJJbnB1dCIsIkxhYmVsIiwiU2VsZWN0IiwiU2VsZWN0Q29udGVudCIsIlNlbGVjdEl0ZW0iLCJTZWxlY3RUcmlnZ2VyIiwiU2VsZWN0VmFsdWUiLCJTaGllbGRDaGVjayIsIlNUQVRVU19PUFRJT05TIiwiV29ya09yZGVyQXBwcm92YWxzVmlldyIsInByb2plY3RJZCIsIl9zIiwic3RhdHVzIiwic2V0U3RhdHVzIiwic2F2aW5nSWQiLCJzZXRTYXZpbmdJZCIsImRlY2lzaW9uTm90ZXMiLCJzZXREZWNpc2lvbk5vdGVzIiwiY29uZGl0aW9uTm90ZXMiLCJzZXRDb25kaXRpb25Ob3RlcyIsImFwcHJvdmFscyIsIndvcmtPcmRlcnMiLCJhcHByb3ZhbFF1ZXVlIiwiZGVjaWRlQXBwcm92YWxEZWNpc2lvbiIsImNvdW50cyIsInRvdGFsIiwibGVuZ3RoIiwid2FpdGluZyIsImZpbHRlciIsIml0ZW0iLCJjb25kaXRpb25hbCIsImhhbmRsZURlY2lzaW9uIiwiYXBwcm92YWxEZWNpc2lvbklkIiwiZGVjaXNpb24iLCJhcHByb3ZlciIsInJlYXNvbiIsInVuZGVmaW5lZCIsImNvbmRpdGlvbnMiLCJzcGxpdCIsIm1hcCIsImxpbmUiLCJ0cmltIiwiQm9vbGVhbiIsInZhbHVlIiwib3B0aW9uIiwiYXBwcm92YWwiLCJ3b3JrT3JkZXIiLCJ0aXRsZSIsIndvcmtPcmRlcklkIiwiYXBwcm92YWxUeXBlIiwicmVxdWVzdGVkQWN0aW9uIiwicmlza0xldmVsIiwiZXZpZGVuY2VBdmFpbGFibGUiLCJyZXF1ZXN0ZWRCeSIsImxhdGVzdFJ1biIsInJ1bklkIiwid29ya09yZGVyUmV2aXNpb25OdW1iZXIiLCJleHBpcmVzQXQiLCJEYXRlIiwidG9Mb2NhbGVTdHJpbmciLCJyZW1haW5pbmdVbmNlcnRhaW50eSIsImluZGV4IiwiX2lkIiwiZXZlbnQiLCJjdXJyZW50IiwidGFyZ2V0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiV29ya09yZGVyQXBwcm92YWxzVmlldy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB0eXBlIHsgSWQgfSBmcm9tIFwiLi4vLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvZGF0YU1vZGVsXCI7XG5pbXBvcnQgeyBQYWdlSGVhZGVyIH0gZnJvbSBcIkAvY29tcG9uZW50cy9QYWdlSGVhZGVyXCI7XG5pbXBvcnQgeyBCYWRnZSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYmFkZ2VcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQgeyBDYXJkIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9jYXJkXCI7XG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvaW5wdXRcIjtcbmltcG9ydCB7IExhYmVsIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9sYWJlbFwiO1xuaW1wb3J0IHsgU2VsZWN0LCBTZWxlY3RDb250ZW50LCBTZWxlY3RJdGVtLCBTZWxlY3RUcmlnZ2VyLCBTZWxlY3RWYWx1ZSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvc2VsZWN0XCI7XG5pbXBvcnQgeyBTaGllbGRDaGVjayB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcblxuY29uc3QgU1RBVFVTX09QVElPTlMgPSBbXCJQRU5ESU5HXCIsIFwiQVBQUk9WRURcIiwgXCJDT05ESVRJT05BTFwiLCBcIlJFSkVDVEVEXCIsIFwiUkVWSVNJT05fUkVRVUVTVEVEXCIsIFwiRVhQSVJFRFwiLCBcIlNVUEVSU0VERURcIiwgXCJSRVZPS0VEXCJdIGFzIGNvbnN0O1xuXG5leHBvcnQgZnVuY3Rpb24gV29ya09yZGVyQXBwcm92YWxzVmlldyh7IHByb2plY3RJZCB9OiB7IHByb2plY3RJZDogSWQ8XCJwcm9qZWN0c1wiPiB8IG51bGwgfSkge1xuICBjb25zdCBbc3RhdHVzLCBzZXRTdGF0dXNdID0gdXNlU3RhdGU8KHR5cGVvZiBTVEFUVVNfT1BUSU9OUylbbnVtYmVyXT4oXCJQRU5ESU5HXCIpO1xuICBjb25zdCBbc2F2aW5nSWQsIHNldFNhdmluZ0lkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbZGVjaXNpb25Ob3Rlcywgc2V0RGVjaXNpb25Ob3Rlc10gPSB1c2VTdGF0ZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+Pih7fSk7XG4gIGNvbnN0IFtjb25kaXRpb25Ob3Rlcywgc2V0Q29uZGl0aW9uTm90ZXNdID0gdXNlU3RhdGU8UmVjb3JkPHN0cmluZywgc3RyaW5nPj4oe30pO1xuICBjb25zdCBhcHByb3ZhbHMgPSB1c2VRdWVyeShhcGkud29ya09yZGVycy5hcHByb3ZhbFF1ZXVlLCBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCwgc3RhdHVzIH0gOiB7IHN0YXR1cyB9KTtcbiAgY29uc3QgZGVjaWRlQXBwcm92YWxEZWNpc2lvbiA9IHVzZU11dGF0aW9uKGFwaS53b3JrT3JkZXJzLmRlY2lkZUFwcHJvdmFsRGVjaXNpb24pO1xuXG4gIGNvbnN0IGNvdW50cyA9IHVzZU1lbW8oKCkgPT4gKHtcbiAgICB0b3RhbDogYXBwcm92YWxzPy5sZW5ndGggPz8gMCxcbiAgICB3YWl0aW5nOiAoYXBwcm92YWxzID8/IFtdKS5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0uc3RhdHVzID09PSBcIlBFTkRJTkdcIikubGVuZ3RoLFxuICAgIGNvbmRpdGlvbmFsOiAoYXBwcm92YWxzID8/IFtdKS5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0uc3RhdHVzID09PSBcIkNPTkRJVElPTkFMXCIpLmxlbmd0aCxcbiAgfSksIFthcHByb3ZhbHNdKTtcblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVEZWNpc2lvbihhcHByb3ZhbERlY2lzaW9uSWQ6IHN0cmluZywgZGVjaXNpb246IFwiQVBQUk9WRVwiIHwgXCJBUFBST1ZFX1dJVEhfQ09ORElUSU9OU1wiIHwgXCJSRUpFQ1RcIiB8IFwiUkVRVUVTVF9SRVZJU0lPTlwiKSB7XG4gICAgdHJ5IHtcbiAgICAgIHNldFNhdmluZ0lkKGFwcHJvdmFsRGVjaXNpb25JZCk7XG4gICAgICBhd2FpdCBkZWNpZGVBcHByb3ZhbERlY2lzaW9uKHtcbiAgICAgICAgYXBwcm92YWxEZWNpc2lvbklkOiBhcHByb3ZhbERlY2lzaW9uSWQgYXMgSWQ8XCJhcHByb3ZhbERlY2lzaW9uc1wiPixcbiAgICAgICAgZGVjaXNpb24sXG4gICAgICAgIGFwcHJvdmVyOiBcIm9wZXJhdG9yXCIsXG4gICAgICAgIHJlYXNvbjogZGVjaXNpb25Ob3Rlc1thcHByb3ZhbERlY2lzaW9uSWRdIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgY29uZGl0aW9uczogZGVjaXNpb24gPT09IFwiQVBQUk9WRV9XSVRIX0NPTkRJVElPTlNcIlxuICAgICAgICAgID8gKGNvbmRpdGlvbk5vdGVzW2FwcHJvdmFsRGVjaXNpb25JZF0/LnNwbGl0KFwiXFxuXCIpLm1hcCgobGluZSkgPT4gbGluZS50cmltKCkpLmZpbHRlcihCb29sZWFuKSA/PyBbXSlcbiAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgIH0pO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTYXZpbmdJZChudWxsKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLWZ1bGwgbWluLWgtMCBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgIDxQYWdlSGVhZGVyXG4gICAgICAgIGV5ZWJyb3c9XCJTb2Z0d2FyZSBmYWN0b3J5XCJcbiAgICAgICAgdGl0bGU9XCJBcHByb3ZhbCBDZW50ZXJcIlxuICAgICAgICBkZXNjcmlwdGlvbj1cIlJldmlldyBXb3JrT3JkZXIgYXBwcm92YWxzLCBldmlkZW5jZSBvbiBoYW5kLCBhbmQgcmVtYWluaW5nIHVuY2VydGFpbnR5IGJlZm9yZSBwcm90ZWN0ZWQgYWN0aW9ucyBvciBhY2NlcHRhbmNlLlwiXG4gICAgICAgIGljb249ezxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJoLTUgdy01XCIgLz59XG4gICAgICAvPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLTAgZmxleC0xIG92ZXJmbG93LXktYXV0byBwLTVcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC0zXCI+XG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC00XCI+PGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMTRlbV0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+U2hvd248L2Rpdj48ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPntjb3VudHMudG90YWx9PC9kaXY+PC9DYXJkPlxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNFwiPjxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjE0ZW1dIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlBlbmRpbmc8L2Rpdj48ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC0yeGwgZm9udC1zZW1pYm9sZCB0ZXh0LWFtYmVyLTMwMFwiPntjb3VudHMud2FpdGluZ308L2Rpdj48L0NhcmQ+XG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC00XCI+PGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMTRlbV0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+Q29uZGl0aW9uYWw8L2Rpdj48ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC0yeGwgZm9udC1zZW1pYm9sZCB0ZXh0LXJlZ2lzdHJ5LWFjY2VudFwiPntjb3VudHMuY29uZGl0aW9uYWx9PC9kaXY+PC9DYXJkPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgbWF4LXctWzIyMHB4XSBzcGFjZS15LTEuNVwiPlxuICAgICAgICAgIDxMYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMTRlbV0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+U3RhdHVzPC9MYWJlbD5cbiAgICAgICAgICA8U2VsZWN0IHZhbHVlPXtzdGF0dXN9IG9uVmFsdWVDaGFuZ2U9eyh2YWx1ZSkgPT4gc2V0U3RhdHVzKHZhbHVlIGFzICh0eXBlb2YgU1RBVFVTX09QVElPTlMpW251bWJlcl0pfT5cbiAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGFyaWEtbGFiZWw9XCJBcHByb3ZhbCBzdGF0dXMgZmlsdGVyXCI+PFNlbGVjdFZhbHVlIC8+PC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgIHtTVEFUVVNfT1BUSU9OUy5tYXAoKG9wdGlvbikgPT4gPFNlbGVjdEl0ZW0ga2V5PXtvcHRpb259IHZhbHVlPXtvcHRpb259PntvcHRpb259PC9TZWxlY3RJdGVtPil9XG4gICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBzcGFjZS15LTRcIj5cbiAgICAgICAgICB7KGFwcHJvdmFscyA/PyBbXSkubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyIHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+Tm8gYXBwcm92YWxzIGluIHRoaXMgc3RhdHVzLjwvQ2FyZD5cbiAgICAgICAgICApIDogKGFwcHJvdmFscyA/PyBbXSkubWFwKChhcHByb3ZhbCkgPT4gKFxuICAgICAgICAgICAgPENhcmQga2V5PXthcHByb3ZhbC5faWR9IGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mb3JlZ3JvdW5kXCI+e2FwcHJvdmFsLndvcmtPcmRlcj8udGl0bGUgPz8gYXBwcm92YWwud29ya09yZGVySWR9PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57YXBwcm92YWwuYXBwcm92YWxUeXBlfSDCtyB7YXBwcm92YWwucmVxdWVzdGVkQWN0aW9ufTwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwib3V0bGluZVwiPnthcHByb3ZhbC5yaXNrTGV2ZWx9PC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwib3V0bGluZVwiPnthcHByb3ZhbC5zdGF0dXN9PC9CYWRnZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGdyaWQgZ2FwLTIgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmQgbWQ6Z3JpZC1jb2xzLTIgeGw6Z3JpZC1jb2xzLTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PjxzcGFuIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZC84MFwiPkV2aWRlbmNlIGF2YWlsYWJsZTo8L3NwYW4+IHthcHByb3ZhbC5ldmlkZW5jZUF2YWlsYWJsZX08L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PjxzcGFuIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZC84MFwiPkFwcHJvdmVyOjwvc3Bhbj4ge2FwcHJvdmFsLmFwcHJvdmVyID8/IFwi4oCUXCJ9PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWZvcmVncm91bmQvODBcIj5SZXF1ZXN0ZWQgYnk6PC9zcGFuPiB7YXBwcm92YWwucmVxdWVzdGVkQnkgPz8gXCLigJRcIn08L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PjxzcGFuIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZC84MFwiPlJ1bjo8L3NwYW4+IHthcHByb3ZhbC5sYXRlc3RSdW4/LnJ1bklkID8/IFwi4oCUXCJ9PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj48c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWZvcmVncm91bmQvODBcIj5SZXZpc2lvbjo8L3NwYW4+IHthcHByb3ZhbC53b3JrT3JkZXJSZXZpc2lvbk51bWJlciA/IGByJHthcHByb3ZhbC53b3JrT3JkZXJSZXZpc2lvbk51bWJlcn1gIDogXCLigJRcIn08L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PjxzcGFuIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZC84MFwiPkV4cGlyZXM6PC9zcGFuPiB7YXBwcm92YWwuZXhwaXJlc0F0ID8gbmV3IERhdGUoYXBwcm92YWwuZXhwaXJlc0F0KS50b0xvY2FsZVN0cmluZygpIDogXCLigJRcIn08L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1bdmFyKC0tcGFuZWwtbGluZSldIGJnLWJhY2tncm91bmQvNDAgcC0zIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmQvODVcIj5SZW1haW5pbmcgdW5jZXJ0YWludHk8L2Rpdj5cbiAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwibXQtMiBsaXN0LWRpc2Mgc3BhY2UteS0xIHBsLTRcIj5cbiAgICAgICAgICAgICAgICAgIHsoYXBwcm92YWwucmVtYWluaW5nVW5jZXJ0YWludHk/Lmxlbmd0aCA/IGFwcHJvdmFsLnJlbWFpbmluZ1VuY2VydGFpbnR5IDogW1wiTm8gYmxvY2tpbmcgdW5jZXJ0YWludHkgcmVjb3JkZWQuXCJdKS5tYXAoKGl0ZW06IHN0cmluZywgaW5kZXg6IG51bWJlcikgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtgJHthcHByb3ZhbC5faWR9LSR7aW5kZXh9YH0+e2l0ZW19PC9saT5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHthcHByb3ZhbC5zdGF0dXMgPT09IFwiUEVORElOR1wiID8gKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtMyBtZDpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPExhYmVsPkRlY2lzaW9uIHJlYXNvbjwvTGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0IHZhbHVlPXtkZWNpc2lvbk5vdGVzW2FwcHJvdmFsLl9pZF0gPz8gXCJcIn0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0RGVjaXNpb25Ob3RlcygoY3VycmVudCkgPT4gKHsgLi4uY3VycmVudCwgW2FwcHJvdmFsLl9pZF06IGV2ZW50LnRhcmdldC52YWx1ZSB9KSl9IHBsYWNlaG9sZGVyPVwiV2h5IHRoaXMgZGVjaXNpb24gaXMgc2FmZSAvIGJsb2NrZWRcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxMYWJlbD5Db25kaXRpb25zPC9MYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8SW5wdXQgdmFsdWU9e2NvbmRpdGlvbk5vdGVzW2FwcHJvdmFsLl9pZF0gPz8gXCJcIn0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0Q29uZGl0aW9uTm90ZXMoKGN1cnJlbnQpID0+ICh7IC4uLmN1cnJlbnQsIFthcHByb3ZhbC5faWRdOiBldmVudC50YXJnZXQudmFsdWUgfSkpfSBwbGFjZWhvbGRlcj1cIk9uZS1saW5lIGNvbmRpdGlvbiBvciBuZXdsaW5lLXNlcGFyYXRlZCBsaXN0XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWNpc2lvbihhcHByb3ZhbC5faWQsIFwiQVBQUk9WRVwiKX0gZGlzYWJsZWQ9e3NhdmluZ0lkID09PSBhcHByb3ZhbC5faWR9PkFwcHJvdmU8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlY2lzaW9uKGFwcHJvdmFsLl9pZCwgXCJBUFBST1ZFX1dJVEhfQ09ORElUSU9OU1wiKX0gZGlzYWJsZWQ9e3NhdmluZ0lkID09PSBhcHByb3ZhbC5faWR9PkFwcHJvdmUgd2l0aCBjb25kaXRpb25zPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cImRlc3RydWN0aXZlXCIgb25DbGljaz17KCkgPT4gaGFuZGxlRGVjaXNpb24oYXBwcm92YWwuX2lkLCBcIlJFSkVDVFwiKX0gZGlzYWJsZWQ9e3NhdmluZ0lkID09PSBhcHByb3ZhbC5faWR9PlJlamVjdDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWNpc2lvbihhcHByb3ZhbC5faWQsIFwiUkVRVUVTVF9SRVZJU0lPTlwiKX0gZGlzYWJsZWQ9e3NhdmluZ0lkID09PSBhcHByb3ZhbC5faWR9PlJlcXVlc3QgcmV2aXNpb248L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL2NvbnRyb2xQbGFuZS9Xb3JrT3JkZXJBcHByb3ZhbHNWaWV3LnRzeCJ9