import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ErrorBoundary.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const Component = __vite__cjsImport2_react["Component"];
export class ErrorBoundary extends Component {
  state = { error: null };
  static getDerivedStateFromError(error) {
    return { error };
  }
  componentDidCatch(error, info) {
    console.error("Mission Control render failure", error, info.componentStack);
  }
  render() {
    if (!this.state.error) return this.props.children;
    return /* @__PURE__ */ jsxDEV("main", { className: "flex min-h-screen items-center justify-center bg-app p-6 text-ink", children: /* @__PURE__ */ jsxDEV(
      "section",
      {
        role: "alert",
        className: "w-full max-w-xl rounded-xl border border-err/40 bg-surface-1 p-6 shadow-xl",
        children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-[0.18em] text-err", children: "Mission Control could not render" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ErrorBoundary.tsx",
            lineNumber: 34,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("h1", { className: "mt-2 text-xl font-semibold", children: "The operator console hit an unexpected error." }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ErrorBoundary.tsx",
            lineNumber: 37,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-ink-secondary", children: "Your persisted work is safe. Reload the console to retry." }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ErrorBoundary.tsx",
            lineNumber: 38,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("pre", { className: "mt-4 max-h-40 overflow-auto rounded-lg bg-surface-2 p-3 text-xs text-err", children: this.state.error.message || "Unknown render error" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ErrorBoundary.tsx",
            lineNumber: 41,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => window.location.reload(),
              className: "mt-4 rounded-lg bg-schematic-accent px-4 py-2 text-sm font-semibold text-white",
              children: "Reload Mission Control"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ErrorBoundary.tsx",
              lineNumber: 44,
              columnNumber: 11
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ErrorBoundary.tsx",
        lineNumber: 30,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ErrorBoundary.tsx",
      lineNumber: 29,
      columnNumber: 7
    }, this);
  }
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ErrorBoundary.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ErrorBoundary.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEJVOzs7QUE5QlYsU0FBU0EsaUJBQWlEO0FBVW5ELGFBQU1DLHNCQUFzQkQsVUFBd0I7QUFBQSxFQUN6REUsUUFBZSxFQUFFQyxPQUFPLEtBQUs7QUFBQSxFQUU3QixPQUFPQyx5QkFBeUJELE9BQXFCO0FBQ25ELFdBQU8sRUFBRUEsTUFBTTtBQUFBLEVBQ2pCO0FBQUEsRUFFQUUsa0JBQWtCRixPQUFjRyxNQUFpQjtBQUMvQ0MsWUFBUUosTUFBTSxrQ0FBa0NBLE9BQU9HLEtBQUtFLGNBQWM7QUFBQSxFQUM1RTtBQUFBLEVBRUFDLFNBQVM7QUFDUCxRQUFJLENBQUMsS0FBS1AsTUFBTUMsTUFBTyxRQUFPLEtBQUtPLE1BQU1DO0FBRXpDLFdBQ0UsdUJBQUMsVUFBSyxXQUFVLHFFQUNkO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxXQUFVO0FBQUEsUUFFVjtBQUFBLGlDQUFDLE9BQUUsV0FBVSw4REFBNEQsZ0RBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFFBQUcsV0FBVSw4QkFBNkIsNkRBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdGO0FBQUEsVUFDeEYsdUJBQUMsT0FBRSxXQUFVLG1DQUFpQyx5RUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDRFQUNaLGVBQUtULE1BQU1DLE1BQU1TLFdBQVcsMEJBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU1DLE9BQU9DLFNBQVNDLE9BQU87QUFBQSxjQUN0QyxXQUFVO0FBQUEsY0FBZ0Y7QUFBQTtBQUFBLFlBSDVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUE7QUFBQTtBQUFBLE1BcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXFCQSxLQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsRUFFSjtBQUNGIiwibmFtZXMiOlsiQ29tcG9uZW50IiwiRXJyb3JCb3VuZGFyeSIsInN0YXRlIiwiZXJyb3IiLCJnZXREZXJpdmVkU3RhdGVGcm9tRXJyb3IiLCJjb21wb25lbnREaWRDYXRjaCIsImluZm8iLCJjb25zb2xlIiwiY29tcG9uZW50U3RhY2siLCJyZW5kZXIiLCJwcm9wcyIsImNoaWxkcmVuIiwibWVzc2FnZSIsIndpbmRvdyIsImxvY2F0aW9uIiwicmVsb2FkIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkVycm9yQm91bmRhcnkudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgdHlwZSBFcnJvckluZm8sIHR5cGUgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XG5cbmludGVyZmFjZSBQcm9wcyB7XG4gIGNoaWxkcmVuOiBSZWFjdE5vZGU7XG59XG5cbmludGVyZmFjZSBTdGF0ZSB7XG4gIGVycm9yOiBFcnJvciB8IG51bGw7XG59XG5cbmV4cG9ydCBjbGFzcyBFcnJvckJvdW5kYXJ5IGV4dGVuZHMgQ29tcG9uZW50PFByb3BzLCBTdGF0ZT4ge1xuICBzdGF0ZTogU3RhdGUgPSB7IGVycm9yOiBudWxsIH07XG5cbiAgc3RhdGljIGdldERlcml2ZWRTdGF0ZUZyb21FcnJvcihlcnJvcjogRXJyb3IpOiBTdGF0ZSB7XG4gICAgcmV0dXJuIHsgZXJyb3IgfTtcbiAgfVxuXG4gIGNvbXBvbmVudERpZENhdGNoKGVycm9yOiBFcnJvciwgaW5mbzogRXJyb3JJbmZvKSB7XG4gICAgY29uc29sZS5lcnJvcihcIk1pc3Npb24gQ29udHJvbCByZW5kZXIgZmFpbHVyZVwiLCBlcnJvciwgaW5mby5jb21wb25lbnRTdGFjayk7XG4gIH1cblxuICByZW5kZXIoKSB7XG4gICAgaWYgKCF0aGlzLnN0YXRlLmVycm9yKSByZXR1cm4gdGhpcy5wcm9wcy5jaGlsZHJlbjtcblxuICAgIHJldHVybiAoXG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYXBwIHAtNiB0ZXh0LWlua1wiPlxuICAgICAgICA8c2VjdGlvblxuICAgICAgICAgIHJvbGU9XCJhbGVydFwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LXhsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1lcnIvNDAgYmctc3VyZmFjZS0xIHAtNiBzaGFkb3cteGxcIlxuICAgICAgICA+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy1bMC4xOGVtXSB0ZXh0LWVyclwiPlxuICAgICAgICAgICAgTWlzc2lvbiBDb250cm9sIGNvdWxkIG5vdCByZW5kZXJcbiAgICAgICAgICA8L3A+XG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cIm10LTIgdGV4dC14bCBmb250LXNlbWlib2xkXCI+VGhlIG9wZXJhdG9yIGNvbnNvbGUgaGl0IGFuIHVuZXhwZWN0ZWQgZXJyb3IuPC9oMT5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1pbmstc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICBZb3VyIHBlcnNpc3RlZCB3b3JrIGlzIHNhZmUuIFJlbG9hZCB0aGUgY29uc29sZSB0byByZXRyeS5cbiAgICAgICAgICA8L3A+XG4gICAgICAgICAgPHByZSBjbGFzc05hbWU9XCJtdC00IG1heC1oLTQwIG92ZXJmbG93LWF1dG8gcm91bmRlZC1sZyBiZy1zdXJmYWNlLTIgcC0zIHRleHQteHMgdGV4dC1lcnJcIj5cbiAgICAgICAgICAgIHt0aGlzLnN0YXRlLmVycm9yLm1lc3NhZ2UgfHwgXCJVbmtub3duIHJlbmRlciBlcnJvclwifVxuICAgICAgICAgIDwvcHJlPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtNCByb3VuZGVkLWxnIGJnLXNjaGVtYXRpYy1hY2NlbnQgcHgtNCBweS0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBSZWxvYWQgTWlzc2lvbiBDb250cm9sXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvc2VjdGlvbj5cbiAgICAgIDwvbWFpbj5cbiAgICApO1xuICB9XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9FcnJvckJvdW5kYXJ5LnRzeCJ9