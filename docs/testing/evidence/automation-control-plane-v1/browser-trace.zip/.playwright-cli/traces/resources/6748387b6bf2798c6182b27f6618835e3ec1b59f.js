import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/KanbanFilters.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { cn } from "/src/lib/utils.ts";
import { Button } from "/src/components/ui/button.tsx";
import { StatusBadge } from "/src/components/factory/badges.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
import {
  Save,
  Trash2,
  X,
  Filter
} from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
const PRIORITY_CONFIG = {
  1: { label: "Critical", shortLabel: "P1" },
  2: { label: "High", shortLabel: "P2" },
  3: { label: "Normal", shortLabel: "P3" }
};
const TOGGLE_ACTIVE = "border-line-strong bg-surface-2 text-ink";
const TOGGLE_INACTIVE = "border-line bg-surface-1 text-ink-secondary hover:text-ink hover:border-line-strong";
export function KanbanFilters({ projectId, currentUserId, filters, onFiltersChange }) {
  _s();
  const [selectedViewId, setSelectedViewId] = useState("");
  const agents = useQuery(api.agents.listAll, projectId ? { projectId } : {});
  const tasks = useQuery(api.tasks.listAll, projectId ? { projectId } : {});
  const savedViews = useQuery(
    api.savedViews.list,
    projectId ? { projectId, ownerUserId: currentUserId, scope: "KANBAN" } : "skip"
  );
  const createSavedView = useMutation(api.savedViews.create);
  const removeSavedView = useMutation(api.savedViews.remove);
  const selectedView = savedViews?.find((view) => view._id === selectedViewId);
  if (!agents || !tasks) return null;
  const taskTypes = Array.from(new Set(tasks.map((t) => t.type))).sort();
  const toggleAgent = (agentId) => {
    const newAgents = filters.agents.includes(agentId) ? filters.agents.filter((id) => id !== agentId) : [...filters.agents, agentId];
    onFiltersChange({ ...filters, agents: newAgents });
  };
  const togglePriority = (priority) => {
    const newPriorities = filters.priorities.includes(priority) ? filters.priorities.filter((p) => p !== priority) : [...filters.priorities, priority];
    onFiltersChange({ ...filters, priorities: newPriorities });
  };
  const toggleType = (type) => {
    const newTypes = filters.types.includes(type) ? filters.types.filter((t) => t !== type) : [...filters.types, type];
    onFiltersChange({ ...filters, types: newTypes });
  };
  const clearFilters = () => {
    onFiltersChange({ agents: [], priorities: [], types: [] });
  };
  const hasFilters = filters.agents.length > 0 || filters.priorities.length > 0 || filters.types.length > 0;
  const activeCount = filters.agents.length + filters.priorities.length + filters.types.length;
  const handleSaveView = async () => {
    if (!projectId) {
      window.alert("Select a project before saving a view.");
      return;
    }
    const name = window.prompt("Saved view name", "Operator Focus");
    if (!name || !name.trim()) return;
    const isShared = window.confirm("Share this view with other operators in the project?");
    await createSavedView({
      projectId,
      ownerUserId: currentUserId,
      name: name.trim(),
      scope: "KANBAN",
      filters,
      isShared
    });
  };
  const handleApplyView = (viewId) => {
    setSelectedViewId(viewId);
    const view = savedViews?.find((candidate) => candidate._id === viewId);
    if (!view) return;
    const nextFilters = view.filters;
    onFiltersChange({
      agents: nextFilters.agents ?? [],
      priorities: nextFilters.priorities ?? [],
      types: nextFilters.types ?? []
    });
  };
  const handleDeleteView = async () => {
    if (!selectedView) return;
    if (selectedView.ownerUserId !== currentUserId) {
      window.alert("Only the owner can delete this view.");
      return;
    }
    const confirmDelete = window.confirm(`Delete saved view "${selectedView.name}"?`);
    if (!confirmDelete) return;
    await removeSavedView({
      viewId: selectedView._id,
      ownerUserId: currentUserId
    });
    setSelectedViewId("");
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "shrink-0 border-b border-line bg-app px-4 py-2", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 overflow-x-auto flex-nowrap", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 shrink-0", children: [
      /* @__PURE__ */ jsxDEV(Filter, { size: 14, strokeWidth: 1.6, className: "text-ink-muted" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
        lineNumber: 169,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] font-medium text-ink-muted", children: "Filters" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
        lineNumber: 170,
        columnNumber: 11
      }, this),
      activeCount > 0 && /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "info", children: activeCount }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
        lineNumber: 171,
        columnNumber: 31
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
      lineNumber: 168,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "w-px h-5 bg-line shrink-0" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
      lineNumber: 174,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 shrink-0", children: [
      /* @__PURE__ */ jsxDEV(Select, { value: selectedViewId, onValueChange: handleApplyView, children: [
        /* @__PURE__ */ jsxDEV(
          SelectTrigger,
          {
            "aria-label": "Saved task views",
            className: "h-8 w-[150px] text-xs",
            children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Saved views…" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
              lineNumber: 183,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
            lineNumber: 179,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(SelectContent, { children: [
          savedViews?.map(
            (view) => /* @__PURE__ */ jsxDEV(SelectItem, { value: view._id, children: [
              view.name,
              view.isShared ? " (shared)" : ""
            ] }, view._id, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
              lineNumber: 187,
              columnNumber: 15
            }, this)
          ),
          (!savedViews || savedViews.length === 0) && /* @__PURE__ */ jsxDEV(SelectItem, { value: "__none", disabled: true, children: "No saved views" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
            lineNumber: 192,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
          lineNumber: 185,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
        lineNumber: 178,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "outline", size: "sm", className: "h-8 text-xs px-2.5 gap-1", onClick: handleSaveView, children: [
        /* @__PURE__ */ jsxDEV(Save, { className: "h-3.5 w-3.5" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
          lineNumber: 197,
          columnNumber: 13
        }, this),
        "Save"
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
        lineNumber: 196,
        columnNumber: 11
      }, this),
      selectedView && /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "outline",
          size: "sm",
          className: "h-8 px-2 text-err hover:text-err hover:bg-err-soft",
          onClick: handleDeleteView,
          "aria-label": `Delete saved view ${selectedView.name}`,
          children: /* @__PURE__ */ jsxDEV(Trash2, { className: "h-3.5 w-3.5" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
            lineNumber: 208,
            columnNumber: 15
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
          lineNumber: 201,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
      lineNumber: 177,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "w-px h-5 bg-line shrink-0" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
      lineNumber: 213,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 shrink-0", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] font-medium text-ink-muted", children: "Priority" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
        lineNumber: 217,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [1, 2, 3].map((priority) => {
        const isActive = filters.priorities.includes(priority);
        const config = PRIORITY_CONFIG[priority];
        return /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => togglePriority(priority),
            title: config.label,
            className: cn(
              "h-8 px-3 rounded-lg text-xs font-medium border transition-colors duration-150",
              isActive ? TOGGLE_ACTIVE : TOGGLE_INACTIVE
            ),
            children: [
              config.shortLabel,
              !isActive && /* @__PURE__ */ jsxDEV("span", { className: "ml-1 text-[11px] opacity-60 hidden sm:inline", children: config.label }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
                lineNumber: 234,
                columnNumber: 19
              }, this)
            ]
          },
          priority,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
            lineNumber: 223,
            columnNumber: 17
          },
          this
        );
      }) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
        lineNumber: 218,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
      lineNumber: 216,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "w-px h-5 bg-line shrink-0" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
      lineNumber: 242,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] font-medium text-ink-muted shrink-0", children: "Agent" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
        lineNumber: 246,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 flex-nowrap", children: [
        agents.slice(0, 5).map((agent) => {
          const isActive = filters.agents.includes(agent._id);
          return /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => toggleAgent(agent._id),
              title: agent.name,
              className: cn(
                "h-8 w-8 rounded-lg text-sm flex items-center justify-center transition-colors duration-150 border font-medium",
                isActive ? TOGGLE_ACTIVE : TOGGLE_INACTIVE
              ),
              children: agent.emoji || agent.name.charAt(0)
            },
            agent._id,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
              lineNumber: 251,
              columnNumber: 17
            },
            this
          );
        }),
        agents.length > 5 && /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-ink-muted px-1", children: [
          "+",
          agents.length - 5
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
          lineNumber: 265,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
        lineNumber: 247,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
      lineNumber: 245,
      columnNumber: 9
    }, this),
    taskTypes.length > 0 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-px h-5 bg-line shrink-0" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
        lineNumber: 273,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] font-medium text-ink-muted shrink-0", children: "Type" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
          lineNumber: 275,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 flex-nowrap", children: [
          taskTypes.slice(0, 4).map((type) => {
            const isActive = filters.types.includes(type);
            return /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => toggleType(type),
                className: cn(
                  "h-8 px-3 rounded-lg text-xs font-medium border transition-colors duration-150",
                  isActive ? TOGGLE_ACTIVE : TOGGLE_INACTIVE
                ),
                children: type
              },
              type,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
                lineNumber: 280,
                columnNumber: 19
              },
              this
            );
          }),
          taskTypes.length > 4 && /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-ink-muted px-1", children: [
            "+",
            taskTypes.length - 4
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
            lineNumber: 293,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
          lineNumber: 276,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
        lineNumber: 274,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
      lineNumber: 272,
      columnNumber: 9
    }, this),
    hasFilters && /* @__PURE__ */ jsxDEV(
      Button,
      {
        variant: "ghost",
        size: "sm",
        className: "h-8 text-xs px-3 gap-1.5 ml-auto shrink-0",
        onClick: clearFilters,
        children: [
          /* @__PURE__ */ jsxDEV(X, { className: "h-3.5 w-3.5" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
            lineNumber: 308,
            columnNumber: 13
          }, this),
          "Clear filters"
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
        lineNumber: 302,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
    lineNumber: 166,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx",
    lineNumber: 165,
    columnNumber: 5
  }, this);
}
_s(KanbanFilters, "h/P8343/PGp15oCjPqfkGBp1LO4=", false, function() {
  return [useQuery, useQuery, useQuery, useMutation, useMutation];
});
_c = KanbanFilters;
var _c;
$RefreshReg$(_c, "KanbanFilters");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KanbanFilters.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUpVLFNBdUdBLFVBdkdBOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJKVixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLFdBQVc7QUFFcEIsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLG1CQUFtQjtBQUM1QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFpQlAsTUFBTUMsa0JBQXlFO0FBQUEsRUFDN0UsR0FBRyxFQUFFQyxPQUFPLFlBQVlDLFlBQVksS0FBSztBQUFBLEVBQ3pDLEdBQUcsRUFBRUQsT0FBTyxRQUFRQyxZQUFZLEtBQUs7QUFBQSxFQUNyQyxHQUFHLEVBQUVELE9BQU8sVUFBVUMsWUFBWSxLQUFLO0FBQ3pDO0FBRUEsTUFBTUMsZ0JBQWdCO0FBQ3RCLE1BQU1DLGtCQUNKO0FBRUssZ0JBQVNDLGNBQWMsRUFBRUMsV0FBV0MsZUFBZUMsU0FBU0MsZ0JBQW9DLEdBQUc7QUFBQUMsS0FBQTtBQUN4RyxRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUk1QixTQUFpQixFQUFFO0FBRS9ELFFBQU02QixTQUFTM0IsU0FBU0MsSUFBSTBCLE9BQU9DLFNBQVNSLFlBQVksRUFBRUEsVUFBVSxJQUFJLENBQUMsQ0FBQztBQUMxRSxRQUFNUyxRQUFRN0IsU0FBU0MsSUFBSTRCLE1BQU1ELFNBQVNSLFlBQVksRUFBRUEsVUFBVSxJQUFJLENBQUMsQ0FBQztBQUN4RSxRQUFNVSxhQUFhOUI7QUFBQUEsSUFDakJDLElBQUk2QixXQUFXQztBQUFBQSxJQUNmWCxZQUNJLEVBQUVBLFdBQVdZLGFBQWFYLGVBQWVZLE9BQU8sU0FBUyxJQUN6RDtBQUFBLEVBQ047QUFFQSxRQUFNQyxrQkFBa0JuQyxZQUFZRSxJQUFJNkIsV0FBV0ssTUFBTTtBQUN6RCxRQUFNQyxrQkFBa0JyQyxZQUFZRSxJQUFJNkIsV0FBV08sTUFBTTtBQUV6RCxRQUFNQyxlQUFlUixZQUFZUyxLQUFLLENBQUNDLFNBQVNBLEtBQUtDLFFBQVFoQixjQUFjO0FBRTNFLE1BQUksQ0FBQ0UsVUFBVSxDQUFDRSxNQUFPLFFBQU87QUFFOUIsUUFBTWEsWUFBWUMsTUFBTUMsS0FBSyxJQUFJQyxJQUFJaEIsTUFBTWlCLElBQUksQ0FBQ0MsTUFBTUEsRUFBRUMsSUFBSSxDQUFDLENBQUMsRUFBRUMsS0FBSztBQUVyRSxRQUFNQyxjQUFjQSxDQUFDQyxZQUFvQjtBQUN2QyxVQUFNQyxZQUFZOUIsUUFBUUssT0FBTzBCLFNBQVNGLE9BQU8sSUFDN0M3QixRQUFRSyxPQUFPMkIsT0FBTyxDQUFDQyxPQUFPQSxPQUFPSixPQUFPLElBQzVDLENBQUMsR0FBRzdCLFFBQVFLLFFBQVF3QixPQUFPO0FBQy9CNUIsb0JBQWdCLEVBQUUsR0FBR0QsU0FBU0ssUUFBUXlCLFVBQVUsQ0FBQztBQUFBLEVBQ25EO0FBRUEsUUFBTUksaUJBQWlCQSxDQUFDQyxhQUFxQjtBQUMzQyxVQUFNQyxnQkFBZ0JwQyxRQUFRcUMsV0FBV04sU0FBU0ksUUFBUSxJQUN0RG5DLFFBQVFxQyxXQUFXTCxPQUFPLENBQUNNLE1BQU1BLE1BQU1ILFFBQVEsSUFDL0MsQ0FBQyxHQUFHbkMsUUFBUXFDLFlBQVlGLFFBQVE7QUFDcENsQyxvQkFBZ0IsRUFBRSxHQUFHRCxTQUFTcUMsWUFBWUQsY0FBYyxDQUFDO0FBQUEsRUFDM0Q7QUFFQSxRQUFNRyxhQUFhQSxDQUFDYixTQUFpQjtBQUNuQyxVQUFNYyxXQUFXeEMsUUFBUXlDLE1BQU1WLFNBQVNMLElBQUksSUFDeEMxQixRQUFReUMsTUFBTVQsT0FBTyxDQUFDUCxNQUFNQSxNQUFNQyxJQUFJLElBQ3RDLENBQUMsR0FBRzFCLFFBQVF5QyxPQUFPZixJQUFJO0FBQzNCekIsb0JBQWdCLEVBQUUsR0FBR0QsU0FBU3lDLE9BQU9ELFNBQVMsQ0FBQztBQUFBLEVBQ2pEO0FBRUEsUUFBTUUsZUFBZUEsTUFBTTtBQUN6QnpDLG9CQUFnQixFQUFFSSxRQUFRLElBQUlnQyxZQUFZLElBQUlJLE9BQU8sR0FBRyxDQUFDO0FBQUEsRUFDM0Q7QUFFQSxRQUFNRSxhQUFhM0MsUUFBUUssT0FBT3VDLFNBQVMsS0FBSzVDLFFBQVFxQyxXQUFXTyxTQUFTLEtBQUs1QyxRQUFReUMsTUFBTUcsU0FBUztBQUN4RyxRQUFNQyxjQUFjN0MsUUFBUUssT0FBT3VDLFNBQVM1QyxRQUFRcUMsV0FBV08sU0FBUzVDLFFBQVF5QyxNQUFNRztBQUV0RixRQUFNRSxpQkFBaUIsWUFBWTtBQUNqQyxRQUFJLENBQUNoRCxXQUFXO0FBQ2RpRCxhQUFPQyxNQUFNLHdDQUF3QztBQUNyRDtBQUFBLElBQ0Y7QUFDQSxVQUFNQyxPQUFPRixPQUFPRyxPQUFPLG1CQUFtQixnQkFBZ0I7QUFDOUQsUUFBSSxDQUFDRCxRQUFRLENBQUNBLEtBQUtFLEtBQUssRUFBRztBQUMzQixVQUFNQyxXQUFXTCxPQUFPTSxRQUFRLHNEQUFzRDtBQUN0RixVQUFNekMsZ0JBQWdCO0FBQUEsTUFDcEJkO0FBQUFBLE1BQ0FZLGFBQWFYO0FBQUFBLE1BQ2JrRCxNQUFNQSxLQUFLRSxLQUFLO0FBQUEsTUFDaEJ4QyxPQUFPO0FBQUEsTUFDUFg7QUFBQUEsTUFDQW9EO0FBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNRSxrQkFBa0JBLENBQUNDLFdBQW1CO0FBQzFDbkQsc0JBQWtCbUQsTUFBTTtBQUN4QixVQUFNckMsT0FBT1YsWUFBWVMsS0FBSyxDQUFDdUMsY0FBY0EsVUFBVXJDLFFBQVFvQyxNQUFNO0FBQ3JFLFFBQUksQ0FBQ3JDLEtBQU07QUFDWCxVQUFNdUMsY0FBY3ZDLEtBQUtsQjtBQUt6QkMsb0JBQWdCO0FBQUEsTUFDZEksUUFBUW9ELFlBQVlwRCxVQUFVO0FBQUEsTUFDOUJnQyxZQUFZb0IsWUFBWXBCLGNBQWM7QUFBQSxNQUN0Q0ksT0FBT2dCLFlBQVloQixTQUFTO0FBQUEsSUFDOUIsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNaUIsbUJBQW1CLFlBQVk7QUFDbkMsUUFBSSxDQUFDMUMsYUFBYztBQUNuQixRQUFJQSxhQUFhTixnQkFBZ0JYLGVBQWU7QUFDOUNnRCxhQUFPQyxNQUFNLHNDQUFzQztBQUNuRDtBQUFBLElBQ0Y7QUFDQSxVQUFNVyxnQkFBZ0JaLE9BQU9NLFFBQVEsc0JBQXNCckMsYUFBYWlDLElBQUksSUFBSTtBQUNoRixRQUFJLENBQUNVLGNBQWU7QUFDcEIsVUFBTTdDLGdCQUFnQjtBQUFBLE1BQ3BCeUMsUUFBUXZDLGFBQWFHO0FBQUFBLE1BQ3JCVCxhQUFhWDtBQUFBQSxJQUNmLENBQUM7QUFDREssc0JBQWtCLEVBQUU7QUFBQSxFQUN0QjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGtEQUNiLGlDQUFDLFNBQUksV0FBVSx1REFFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLDZCQUFDLFVBQU8sTUFBTSxJQUFJLGFBQWEsS0FBSyxXQUFVLG9CQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThEO0FBQUEsTUFDOUQsdUJBQUMsVUFBSyxXQUFVLDRDQUEyQyx1QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRTtBQUFBLE1BQ2pFeUMsY0FBYyxLQUFLLHVCQUFDLGVBQVksTUFBSyxRQUFRQSx5QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQztBQUFBLFNBSDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLCtCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEM7QUFBQSxJQUcxQyx1QkFBQyxTQUFJLFdBQVUsc0NBQ2I7QUFBQSw2QkFBQyxVQUFPLE9BQU8xQyxnQkFBZ0IsZUFBZW1ELGlCQUM1QztBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxjQUFXO0FBQUEsWUFDWCxXQUFVO0FBQUEsWUFFVixpQ0FBQyxlQUFZLGFBQVksa0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVDO0FBQUE7QUFBQSxVQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFFBQ0EsdUJBQUMsaUJBQ0U5QztBQUFBQSxzQkFBWWdCO0FBQUFBLFlBQUksQ0FBQ04sU0FDaEIsdUJBQUMsY0FBMEIsT0FBT0EsS0FBS0MsS0FDcENEO0FBQUFBLG1CQUFLK0I7QUFBQUEsY0FBTS9CLEtBQUtrQyxXQUFXLGNBQWM7QUFBQSxpQkFEM0JsQyxLQUFLQyxLQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsVUFDRDtBQUFBLFdBQ0MsQ0FBQ1gsY0FBY0EsV0FBV29DLFdBQVcsTUFDckMsdUJBQUMsY0FBVyxPQUFNLFVBQVMsVUFBUSxNQUFDLDhCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRDtBQUFBLGFBUHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFdBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxNQUNBLHVCQUFDLFVBQU8sU0FBUSxXQUFVLE1BQUssTUFBSyxXQUFVLDRCQUEyQixTQUFTRSxnQkFDaEY7QUFBQSwrQkFBQyxRQUFLLFdBQVUsaUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkI7QUFBQTtBQUFBLFdBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0M5QixnQkFDQztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUTtBQUFBLFVBQ1IsTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBQ1YsU0FBUzBDO0FBQUFBLFVBQ1QsY0FBWSxxQkFBcUIxQyxhQUFhaUMsSUFBSTtBQUFBLFVBRWxELGlDQUFDLFVBQU8sV0FBVSxpQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0I7QUFBQTtBQUFBLFFBUGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBO0FBQUEsU0FoQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtDQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLCtCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEM7QUFBQSxJQUcxQyx1QkFBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSw2QkFBQyxVQUFLLFdBQVUsNENBQTJDLHdCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1FO0FBQUEsTUFDbkUsdUJBQUMsU0FBSSxXQUFVLDJCQUNYLFdBQUMsR0FBRyxHQUFHLENBQUMsRUFBWXpCLElBQUksQ0FBQ1csYUFBYTtBQUN0QyxjQUFNeUIsV0FBVzVELFFBQVFxQyxXQUFXTixTQUFTSSxRQUFRO0FBQ3JELGNBQU0wQixTQUFTckUsZ0JBQWdCMkMsUUFBUTtBQUN2QyxlQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxTQUFTLE1BQU1ELGVBQWVDLFFBQVE7QUFBQSxZQUN0QyxPQUFPMEIsT0FBT3BFO0FBQUFBLFlBQ2QsV0FBV2I7QUFBQUEsY0FDVDtBQUFBLGNBQ0FnRixXQUFXakUsZ0JBQWdCQztBQUFBQSxZQUM3QjtBQUFBLFlBRUNpRTtBQUFBQSxxQkFBT25FO0FBQUFBLGNBQ1AsQ0FBQ2tFLFlBQ0EsdUJBQUMsVUFBSyxXQUFVLGdEQUFnREMsaUJBQU9wRSxTQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RTtBQUFBO0FBQUE7QUFBQSxVQVYxRTBDO0FBQUFBLFVBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWFBO0FBQUEsTUFFSixDQUFDLEtBcEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxTQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0JBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsK0JBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQztBQUFBLElBRzFDLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDZCQUFDLFVBQUssV0FBVSxxREFBb0QscUJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUU7QUFBQSxNQUN6RSx1QkFBQyxTQUFJLFdBQVUsdUNBQ1o5QjtBQUFBQSxlQUFPeUQsTUFBTSxHQUFHLENBQUMsRUFBRXRDLElBQUksQ0FBQ3VDLFVBQVU7QUFDakMsZ0JBQU1ILFdBQVc1RCxRQUFRSyxPQUFPMEIsU0FBU2dDLE1BQU01QyxHQUFHO0FBQ2xELGlCQUNFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxTQUFTLE1BQU1TLFlBQVltQyxNQUFNNUMsR0FBRztBQUFBLGNBQ3BDLE9BQU80QyxNQUFNZDtBQUFBQSxjQUNiLFdBQVdyRTtBQUFBQSxnQkFDVDtBQUFBLGdCQUNBZ0YsV0FBV2pFLGdCQUFnQkM7QUFBQUEsY0FDN0I7QUFBQSxjQUVDbUUsZ0JBQU1DLFNBQVNELE1BQU1kLEtBQUtnQixPQUFPLENBQUM7QUFBQTtBQUFBLFlBUjlCRixNQUFNNUM7QUFBQUEsWUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxRQUVKLENBQUM7QUFBQSxRQUNBZCxPQUFPdUMsU0FBUyxLQUNmLHVCQUFDLFVBQUssV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLFVBQUV2QyxPQUFPdUMsU0FBUztBQUFBLGFBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0U7QUFBQSxXQWxCMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9CQTtBQUFBLFNBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkE7QUFBQSxJQUdDeEIsVUFBVXdCLFNBQVMsS0FDbEIsbUNBQ0U7QUFBQSw2QkFBQyxTQUFJLFdBQVUsK0JBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQztBQUFBLE1BQzFDLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLFVBQUssV0FBVSxxREFBb0Qsb0JBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0U7QUFBQSxRQUN4RSx1QkFBQyxTQUFJLFdBQVUsdUNBQ1p4QjtBQUFBQSxvQkFBVTBDLE1BQU0sR0FBRyxDQUFDLEVBQUV0QyxJQUFJLENBQUNFLFNBQVM7QUFDbkMsa0JBQU1rQyxXQUFXNUQsUUFBUXlDLE1BQU1WLFNBQVNMLElBQUk7QUFDNUMsbUJBQ0U7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxTQUFTLE1BQU1hLFdBQVdiLElBQUk7QUFBQSxnQkFDOUIsV0FBVzlDO0FBQUFBLGtCQUNUO0FBQUEsa0JBQ0FnRixXQUFXakUsZ0JBQWdCQztBQUFBQSxnQkFDN0I7QUFBQSxnQkFFQzhCO0FBQUFBO0FBQUFBLGNBUElBO0FBQUFBLGNBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBO0FBQUEsVUFFSixDQUFDO0FBQUEsVUFDQU4sVUFBVXdCLFNBQVMsS0FDbEIsdUJBQUMsVUFBSyxXQUFVLG1DQUFrQztBQUFBO0FBQUEsWUFBRXhCLFVBQVV3QixTQUFTO0FBQUEsZUFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUU7QUFBQSxhQWpCN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFdBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQkE7QUFBQSxTQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUJBO0FBQUEsSUFJREQsY0FDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsU0FBUTtBQUFBLFFBQ1IsTUFBSztBQUFBLFFBQ0wsV0FBVTtBQUFBLFFBQ1YsU0FBU0Q7QUFBQUEsUUFFVDtBQUFBLGlDQUFDLEtBQUUsV0FBVSxpQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVFBO0FBQUEsT0FoSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtKQSxLQW5KRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0pBO0FBRUo7QUFBQ3hDLEdBelBlTCxlQUFhO0FBQUEsVUFHWm5CLFVBQ0RBLFVBQ0tBLFVBT0tELGFBQ0FBLFdBQVc7QUFBQTtBQUFBLEtBYnJCb0I7QUFBYSxJQUFBcUU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsInVzZVF1ZXJ5IiwiYXBpIiwiY24iLCJCdXR0b24iLCJTdGF0dXNCYWRnZSIsIlNlbGVjdCIsIlNlbGVjdENvbnRlbnQiLCJTZWxlY3RJdGVtIiwiU2VsZWN0VHJpZ2dlciIsIlNlbGVjdFZhbHVlIiwiU2F2ZSIsIlRyYXNoMiIsIlgiLCJGaWx0ZXIiLCJQUklPUklUWV9DT05GSUciLCJsYWJlbCIsInNob3J0TGFiZWwiLCJUT0dHTEVfQUNUSVZFIiwiVE9HR0xFX0lOQUNUSVZFIiwiS2FuYmFuRmlsdGVycyIsInByb2plY3RJZCIsImN1cnJlbnRVc2VySWQiLCJmaWx0ZXJzIiwib25GaWx0ZXJzQ2hhbmdlIiwiX3MiLCJzZWxlY3RlZFZpZXdJZCIsInNldFNlbGVjdGVkVmlld0lkIiwiYWdlbnRzIiwibGlzdEFsbCIsInRhc2tzIiwic2F2ZWRWaWV3cyIsImxpc3QiLCJvd25lclVzZXJJZCIsInNjb3BlIiwiY3JlYXRlU2F2ZWRWaWV3IiwiY3JlYXRlIiwicmVtb3ZlU2F2ZWRWaWV3IiwicmVtb3ZlIiwic2VsZWN0ZWRWaWV3IiwiZmluZCIsInZpZXciLCJfaWQiLCJ0YXNrVHlwZXMiLCJBcnJheSIsImZyb20iLCJTZXQiLCJtYXAiLCJ0IiwidHlwZSIsInNvcnQiLCJ0b2dnbGVBZ2VudCIsImFnZW50SWQiLCJuZXdBZ2VudHMiLCJpbmNsdWRlcyIsImZpbHRlciIsImlkIiwidG9nZ2xlUHJpb3JpdHkiLCJwcmlvcml0eSIsIm5ld1ByaW9yaXRpZXMiLCJwcmlvcml0aWVzIiwicCIsInRvZ2dsZVR5cGUiLCJuZXdUeXBlcyIsInR5cGVzIiwiY2xlYXJGaWx0ZXJzIiwiaGFzRmlsdGVycyIsImxlbmd0aCIsImFjdGl2ZUNvdW50IiwiaGFuZGxlU2F2ZVZpZXciLCJ3aW5kb3ciLCJhbGVydCIsIm5hbWUiLCJwcm9tcHQiLCJ0cmltIiwiaXNTaGFyZWQiLCJjb25maXJtIiwiaGFuZGxlQXBwbHlWaWV3Iiwidmlld0lkIiwiY2FuZGlkYXRlIiwibmV4dEZpbHRlcnMiLCJoYW5kbGVEZWxldGVWaWV3IiwiY29uZmlybURlbGV0ZSIsImlzQWN0aXZlIiwiY29uZmlnIiwic2xpY2UiLCJhZ2VudCIsImVtb2ppIiwiY2hhckF0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiS2FuYmFuRmlsdGVycy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB0eXBlIHsgSWQgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvZGF0YU1vZGVsXCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9idXR0b25cIjtcbmltcG9ydCB7IFN0YXR1c0JhZGdlIH0gZnJvbSBcIkAvY29tcG9uZW50cy9mYWN0b3J5L2JhZGdlc1wiO1xuaW1wb3J0IHtcbiAgU2VsZWN0LFxuICBTZWxlY3RDb250ZW50LFxuICBTZWxlY3RJdGVtLFxuICBTZWxlY3RUcmlnZ2VyLFxuICBTZWxlY3RWYWx1ZSxcbn0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9zZWxlY3RcIjtcbmltcG9ydCB7XG4gIFNhdmUsXG4gIFRyYXNoMixcbiAgWCxcbiAgRmlsdGVyLFxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5cbmludGVyZmFjZSBLYW5iYW5GaWx0ZXJzUHJvcHMge1xuICBwcm9qZWN0SWQ6IElkPFwicHJvamVjdHNcIj4gfCBudWxsO1xuICBjdXJyZW50VXNlcklkOiBzdHJpbmc7XG4gIGZpbHRlcnM6IHtcbiAgICBhZ2VudHM6IHN0cmluZ1tdO1xuICAgIHByaW9yaXRpZXM6IG51bWJlcltdO1xuICAgIHR5cGVzOiBzdHJpbmdbXTtcbiAgfTtcbiAgb25GaWx0ZXJzQ2hhbmdlOiAoZmlsdGVyczoge1xuICAgIGFnZW50czogc3RyaW5nW107XG4gICAgcHJpb3JpdGllczogbnVtYmVyW107XG4gICAgdHlwZXM6IHN0cmluZ1tdO1xuICB9KSA9PiB2b2lkO1xufVxuXG5jb25zdCBQUklPUklUWV9DT05GSUc6IFJlY29yZDxudW1iZXIsIHsgbGFiZWw6IHN0cmluZzsgc2hvcnRMYWJlbDogc3RyaW5nIH0+ID0ge1xuICAxOiB7IGxhYmVsOiBcIkNyaXRpY2FsXCIsIHNob3J0TGFiZWw6IFwiUDFcIiB9LFxuICAyOiB7IGxhYmVsOiBcIkhpZ2hcIiwgc2hvcnRMYWJlbDogXCJQMlwiIH0sXG4gIDM6IHsgbGFiZWw6IFwiTm9ybWFsXCIsIHNob3J0TGFiZWw6IFwiUDNcIiB9LFxufTtcblxuY29uc3QgVE9HR0xFX0FDVElWRSA9IFwiYm9yZGVyLWxpbmUtc3Ryb25nIGJnLXN1cmZhY2UtMiB0ZXh0LWlua1wiO1xuY29uc3QgVE9HR0xFX0lOQUNUSVZFID1cbiAgXCJib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgdGV4dC1pbmstc2Vjb25kYXJ5IGhvdmVyOnRleHQtaW5rIGhvdmVyOmJvcmRlci1saW5lLXN0cm9uZ1wiO1xuXG5leHBvcnQgZnVuY3Rpb24gS2FuYmFuRmlsdGVycyh7IHByb2plY3RJZCwgY3VycmVudFVzZXJJZCwgZmlsdGVycywgb25GaWx0ZXJzQ2hhbmdlIH06IEthbmJhbkZpbHRlcnNQcm9wcykge1xuICBjb25zdCBbc2VsZWN0ZWRWaWV3SWQsIHNldFNlbGVjdGVkVmlld0lkXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG5cbiAgY29uc3QgYWdlbnRzID0gdXNlUXVlcnkoYXBpLmFnZW50cy5saXN0QWxsLCBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCB9IDoge30pO1xuICBjb25zdCB0YXNrcyA9IHVzZVF1ZXJ5KGFwaS50YXNrcy5saXN0QWxsLCBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCB9IDoge30pO1xuICBjb25zdCBzYXZlZFZpZXdzID0gdXNlUXVlcnkoXG4gICAgYXBpLnNhdmVkVmlld3MubGlzdCxcbiAgICBwcm9qZWN0SWRcbiAgICAgID8geyBwcm9qZWN0SWQsIG93bmVyVXNlcklkOiBjdXJyZW50VXNlcklkLCBzY29wZTogXCJLQU5CQU5cIiB9XG4gICAgICA6IFwic2tpcFwiXG4gICk7XG5cbiAgY29uc3QgY3JlYXRlU2F2ZWRWaWV3ID0gdXNlTXV0YXRpb24oYXBpLnNhdmVkVmlld3MuY3JlYXRlKTtcbiAgY29uc3QgcmVtb3ZlU2F2ZWRWaWV3ID0gdXNlTXV0YXRpb24oYXBpLnNhdmVkVmlld3MucmVtb3ZlKTtcblxuICBjb25zdCBzZWxlY3RlZFZpZXcgPSBzYXZlZFZpZXdzPy5maW5kKCh2aWV3KSA9PiB2aWV3Ll9pZCA9PT0gc2VsZWN0ZWRWaWV3SWQpO1xuXG4gIGlmICghYWdlbnRzIHx8ICF0YXNrcykgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgdGFza1R5cGVzID0gQXJyYXkuZnJvbShuZXcgU2V0KHRhc2tzLm1hcCgodCkgPT4gdC50eXBlKSkpLnNvcnQoKTtcblxuICBjb25zdCB0b2dnbGVBZ2VudCA9IChhZ2VudElkOiBzdHJpbmcpID0+IHtcbiAgICBjb25zdCBuZXdBZ2VudHMgPSBmaWx0ZXJzLmFnZW50cy5pbmNsdWRlcyhhZ2VudElkKVxuICAgICAgPyBmaWx0ZXJzLmFnZW50cy5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gYWdlbnRJZClcbiAgICAgIDogWy4uLmZpbHRlcnMuYWdlbnRzLCBhZ2VudElkXTtcbiAgICBvbkZpbHRlcnNDaGFuZ2UoeyAuLi5maWx0ZXJzLCBhZ2VudHM6IG5ld0FnZW50cyB9KTtcbiAgfTtcblxuICBjb25zdCB0b2dnbGVQcmlvcml0eSA9IChwcmlvcml0eTogbnVtYmVyKSA9PiB7XG4gICAgY29uc3QgbmV3UHJpb3JpdGllcyA9IGZpbHRlcnMucHJpb3JpdGllcy5pbmNsdWRlcyhwcmlvcml0eSlcbiAgICAgID8gZmlsdGVycy5wcmlvcml0aWVzLmZpbHRlcigocCkgPT4gcCAhPT0gcHJpb3JpdHkpXG4gICAgICA6IFsuLi5maWx0ZXJzLnByaW9yaXRpZXMsIHByaW9yaXR5XTtcbiAgICBvbkZpbHRlcnNDaGFuZ2UoeyAuLi5maWx0ZXJzLCBwcmlvcml0aWVzOiBuZXdQcmlvcml0aWVzIH0pO1xuICB9O1xuXG4gIGNvbnN0IHRvZ2dsZVR5cGUgPSAodHlwZTogc3RyaW5nKSA9PiB7XG4gICAgY29uc3QgbmV3VHlwZXMgPSBmaWx0ZXJzLnR5cGVzLmluY2x1ZGVzKHR5cGUpXG4gICAgICA/IGZpbHRlcnMudHlwZXMuZmlsdGVyKCh0KSA9PiB0ICE9PSB0eXBlKVxuICAgICAgOiBbLi4uZmlsdGVycy50eXBlcywgdHlwZV07XG4gICAgb25GaWx0ZXJzQ2hhbmdlKHsgLi4uZmlsdGVycywgdHlwZXM6IG5ld1R5cGVzIH0pO1xuICB9O1xuXG4gIGNvbnN0IGNsZWFyRmlsdGVycyA9ICgpID0+IHtcbiAgICBvbkZpbHRlcnNDaGFuZ2UoeyBhZ2VudHM6IFtdLCBwcmlvcml0aWVzOiBbXSwgdHlwZXM6IFtdIH0pO1xuICB9O1xuXG4gIGNvbnN0IGhhc0ZpbHRlcnMgPSBmaWx0ZXJzLmFnZW50cy5sZW5ndGggPiAwIHx8IGZpbHRlcnMucHJpb3JpdGllcy5sZW5ndGggPiAwIHx8IGZpbHRlcnMudHlwZXMubGVuZ3RoID4gMDtcbiAgY29uc3QgYWN0aXZlQ291bnQgPSBmaWx0ZXJzLmFnZW50cy5sZW5ndGggKyBmaWx0ZXJzLnByaW9yaXRpZXMubGVuZ3RoICsgZmlsdGVycy50eXBlcy5sZW5ndGg7XG5cbiAgY29uc3QgaGFuZGxlU2F2ZVZpZXcgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFwcm9qZWN0SWQpIHtcbiAgICAgIHdpbmRvdy5hbGVydChcIlNlbGVjdCBhIHByb2plY3QgYmVmb3JlIHNhdmluZyBhIHZpZXcuXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBuYW1lID0gd2luZG93LnByb21wdChcIlNhdmVkIHZpZXcgbmFtZVwiLCBcIk9wZXJhdG9yIEZvY3VzXCIpO1xuICAgIGlmICghbmFtZSB8fCAhbmFtZS50cmltKCkpIHJldHVybjtcbiAgICBjb25zdCBpc1NoYXJlZCA9IHdpbmRvdy5jb25maXJtKFwiU2hhcmUgdGhpcyB2aWV3IHdpdGggb3RoZXIgb3BlcmF0b3JzIGluIHRoZSBwcm9qZWN0P1wiKTtcbiAgICBhd2FpdCBjcmVhdGVTYXZlZFZpZXcoe1xuICAgICAgcHJvamVjdElkLFxuICAgICAgb3duZXJVc2VySWQ6IGN1cnJlbnRVc2VySWQsXG4gICAgICBuYW1lOiBuYW1lLnRyaW0oKSxcbiAgICAgIHNjb3BlOiBcIktBTkJBTlwiLFxuICAgICAgZmlsdGVycyxcbiAgICAgIGlzU2hhcmVkLFxuICAgIH0pO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUFwcGx5VmlldyA9ICh2aWV3SWQ6IHN0cmluZykgPT4ge1xuICAgIHNldFNlbGVjdGVkVmlld0lkKHZpZXdJZCk7XG4gICAgY29uc3QgdmlldyA9IHNhdmVkVmlld3M/LmZpbmQoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLl9pZCA9PT0gdmlld0lkKTtcbiAgICBpZiAoIXZpZXcpIHJldHVybjtcbiAgICBjb25zdCBuZXh0RmlsdGVycyA9IHZpZXcuZmlsdGVycyBhcyB7XG4gICAgICBhZ2VudHM/OiBzdHJpbmdbXTtcbiAgICAgIHByaW9yaXRpZXM/OiBudW1iZXJbXTtcbiAgICAgIHR5cGVzPzogc3RyaW5nW107XG4gICAgfTtcbiAgICBvbkZpbHRlcnNDaGFuZ2Uoe1xuICAgICAgYWdlbnRzOiBuZXh0RmlsdGVycy5hZ2VudHMgPz8gW10sXG4gICAgICBwcmlvcml0aWVzOiBuZXh0RmlsdGVycy5wcmlvcml0aWVzID8/IFtdLFxuICAgICAgdHlwZXM6IG5leHRGaWx0ZXJzLnR5cGVzID8/IFtdLFxuICAgIH0pO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZVZpZXcgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFzZWxlY3RlZFZpZXcpIHJldHVybjtcbiAgICBpZiAoc2VsZWN0ZWRWaWV3Lm93bmVyVXNlcklkICE9PSBjdXJyZW50VXNlcklkKSB7XG4gICAgICB3aW5kb3cuYWxlcnQoXCJPbmx5IHRoZSBvd25lciBjYW4gZGVsZXRlIHRoaXMgdmlldy5cIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGNvbmZpcm1EZWxldGUgPSB3aW5kb3cuY29uZmlybShgRGVsZXRlIHNhdmVkIHZpZXcgXCIke3NlbGVjdGVkVmlldy5uYW1lfVwiP2ApO1xuICAgIGlmICghY29uZmlybURlbGV0ZSkgcmV0dXJuO1xuICAgIGF3YWl0IHJlbW92ZVNhdmVkVmlldyh7XG4gICAgICB2aWV3SWQ6IHNlbGVjdGVkVmlldy5faWQsXG4gICAgICBvd25lclVzZXJJZDogY3VycmVudFVzZXJJZCxcbiAgICB9KTtcbiAgICBzZXRTZWxlY3RlZFZpZXdJZChcIlwiKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic2hyaW5rLTAgYm9yZGVyLWIgYm9yZGVyLWxpbmUgYmctYXBwIHB4LTQgcHktMlwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBvdmVyZmxvdy14LWF1dG8gZmxleC1ub3dyYXBcIj5cbiAgICAgICAgey8qIEZpbHRlciBpY29uICsgYWN0aXZlIGNvdW50ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHNocmluay0wXCI+XG4gICAgICAgICAgPEZpbHRlciBzaXplPXsxNH0gc3Ryb2tlV2lkdGg9ezEuNn0gY2xhc3NOYW1lPVwidGV4dC1pbmstbXV0ZWRcIiAvPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExLjVweF0gZm9udC1tZWRpdW0gdGV4dC1pbmstbXV0ZWRcIj5GaWx0ZXJzPC9zcGFuPlxuICAgICAgICAgIHthY3RpdmVDb3VudCA+IDAgJiYgPFN0YXR1c0JhZGdlIHRvbmU9XCJpbmZvXCI+e2FjdGl2ZUNvdW50fTwvU3RhdHVzQmFkZ2U+fVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctcHggaC01IGJnLWxpbmUgc2hyaW5rLTBcIiAvPlxuXG4gICAgICAgIHsvKiBTYXZlZCB2aWV3cyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHNocmluay0wXCI+XG4gICAgICAgICAgPFNlbGVjdCB2YWx1ZT17c2VsZWN0ZWRWaWV3SWR9IG9uVmFsdWVDaGFuZ2U9e2hhbmRsZUFwcGx5Vmlld30+XG4gICAgICAgICAgICA8U2VsZWN0VHJpZ2dlclxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiU2F2ZWQgdGFzayB2aWV3c1wiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOCB3LVsxNTBweF0gdGV4dC14c1wiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIlNhdmVkIHZpZXdz4oCmXCIgLz5cbiAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICB7c2F2ZWRWaWV3cz8ubWFwKCh2aWV3KSA9PiAoXG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXt2aWV3Ll9pZH0gdmFsdWU9e3ZpZXcuX2lkfT5cbiAgICAgICAgICAgICAgICAgIHt2aWV3Lm5hbWV9e3ZpZXcuaXNTaGFyZWQgPyBcIiAoc2hhcmVkKVwiIDogXCJcIn1cbiAgICAgICAgICAgICAgICA8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICB7KCFzYXZlZFZpZXdzIHx8IHNhdmVkVmlld3MubGVuZ3RoID09PSAwKSAmJiAoXG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJfX25vbmVcIiBkaXNhYmxlZD5ObyBzYXZlZCB2aWV3czwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cbiAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgc2l6ZT1cInNtXCIgY2xhc3NOYW1lPVwiaC04IHRleHQteHMgcHgtMi41IGdhcC0xXCIgb25DbGljaz17aGFuZGxlU2F2ZVZpZXd9PlxuICAgICAgICAgICAgPFNhdmUgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgU2F2ZVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIHtzZWxlY3RlZFZpZXcgJiYgKFxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOCBweC0yIHRleHQtZXJyIGhvdmVyOnRleHQtZXJyIGhvdmVyOmJnLWVyci1zb2Z0XCJcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRGVsZXRlVmlld31cbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YERlbGV0ZSBzYXZlZCB2aWV3ICR7c2VsZWN0ZWRWaWV3Lm5hbWV9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctcHggaC01IGJnLWxpbmUgc2hyaW5rLTBcIiAvPlxuXG4gICAgICAgIHsvKiBQcmlvcml0eSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzaHJpbmstMFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExLjVweF0gZm9udC1tZWRpdW0gdGV4dC1pbmstbXV0ZWRcIj5Qcmlvcml0eTwvc3Bhbj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICB7KFsxLCAyLCAzXSBhcyBjb25zdCkubWFwKChwcmlvcml0eSkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBpc0FjdGl2ZSA9IGZpbHRlcnMucHJpb3JpdGllcy5pbmNsdWRlcyhwcmlvcml0eSk7XG4gICAgICAgICAgICAgIGNvbnN0IGNvbmZpZyA9IFBSSU9SSVRZX0NPTkZJR1twcmlvcml0eV07XG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAga2V5PXtwcmlvcml0eX1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHRvZ2dsZVByaW9yaXR5KHByaW9yaXR5KX1cbiAgICAgICAgICAgICAgICAgIHRpdGxlPXtjb25maWcubGFiZWx9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICBcImgtOCBweC0zIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LW1lZGl1bSBib3JkZXIgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCIsXG4gICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlID8gVE9HR0xFX0FDVElWRSA6IFRPR0dMRV9JTkFDVElWRVxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7Y29uZmlnLnNob3J0TGFiZWx9XG4gICAgICAgICAgICAgICAgICB7IWlzQWN0aXZlICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMSB0ZXh0LVsxMXB4XSBvcGFjaXR5LTYwIGhpZGRlbiBzbTppbmxpbmVcIj57Y29uZmlnLmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LXB4IGgtNSBiZy1saW5lIHNocmluay0wXCIgLz5cblxuICAgICAgICB7LyogQWdlbnRzICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSBmb250LW1lZGl1bSB0ZXh0LWluay1tdXRlZCBzaHJpbmstMFwiPkFnZW50PC9zcGFuPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgZmxleC1ub3dyYXBcIj5cbiAgICAgICAgICAgIHthZ2VudHMuc2xpY2UoMCwgNSkubWFwKChhZ2VudCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBpc0FjdGl2ZSA9IGZpbHRlcnMuYWdlbnRzLmluY2x1ZGVzKGFnZW50Ll9pZCk7XG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAga2V5PXthZ2VudC5faWR9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB0b2dnbGVBZ2VudChhZ2VudC5faWQpfVxuICAgICAgICAgICAgICAgICAgdGl0bGU9e2FnZW50Lm5hbWV9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICBcImgtOCB3LTggcm91bmRlZC1sZyB0ZXh0LXNtIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBib3JkZXIgZm9udC1tZWRpdW1cIixcbiAgICAgICAgICAgICAgICAgICAgaXNBY3RpdmUgPyBUT0dHTEVfQUNUSVZFIDogVE9HR0xFX0lOQUNUSVZFXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHthZ2VudC5lbW9qaSB8fCBhZ2VudC5uYW1lLmNoYXJBdCgwKX1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAge2FnZW50cy5sZW5ndGggPiA1ICYmIChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1pbmstbXV0ZWQgcHgtMVwiPit7YWdlbnRzLmxlbmd0aCAtIDV9PC9zcGFuPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFR5cGUgKi99XG4gICAgICAgIHt0YXNrVHlwZXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1weCBoLTUgYmctbGluZSBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExLjVweF0gZm9udC1tZWRpdW0gdGV4dC1pbmstbXV0ZWQgc2hyaW5rLTBcIj5UeXBlPC9zcGFuPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGZsZXgtbm93cmFwXCI+XG4gICAgICAgICAgICAgICAge3Rhc2tUeXBlcy5zbGljZSgwLCA0KS5tYXAoKHR5cGUpID0+IHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGlzQWN0aXZlID0gZmlsdGVycy50eXBlcy5pbmNsdWRlcyh0eXBlKTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e3R5cGV9XG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlVHlwZSh0eXBlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJoLTggcHgtMyByb3VuZGVkLWxnIHRleHQteHMgZm9udC1tZWRpdW0gYm9yZGVyIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgaXNBY3RpdmUgPyBUT0dHTEVfQUNUSVZFIDogVE9HR0xFX0lOQUNUSVZFXG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHt0eXBlfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAge3Rhc2tUeXBlcy5sZW5ndGggPiA0ICYmIChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtaW5rLW11dGVkIHB4LTFcIj4re3Rhc2tUeXBlcy5sZW5ndGggLSA0fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvPlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBDbGVhciAqL31cbiAgICAgICAge2hhc0ZpbHRlcnMgJiYgKFxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHRleHQteHMgcHgtMyBnYXAtMS41IG1sLWF1dG8gc2hyaW5rLTBcIlxuICAgICAgICAgICAgb25DbGljaz17Y2xlYXJGaWx0ZXJzfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgIENsZWFyIGZpbHRlcnNcbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvS2FuYmFuRmlsdGVycy50c3gifQ==