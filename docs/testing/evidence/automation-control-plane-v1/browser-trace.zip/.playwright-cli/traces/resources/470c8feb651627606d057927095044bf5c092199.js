import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/OperatorControlsModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
const MODES = [
  { id: "NORMAL", label: "Normal", detail: "All automation and transitions allowed", color: "#16a34a" },
  { id: "PAUSED", label: "Paused", detail: "Blocks non-human execution immediately", color: "#f59e0b" },
  { id: "DRAINING", label: "Draining", detail: "Blocks new runs while allowing safe completion", color: "#0284c7" },
  { id: "QUARANTINED", label: "Quarantined", detail: "Hard block on autonomous execution", color: "#dc2626" }
];
export function OperatorControlsModal({
  projectId,
  onClose
}) {
  _s();
  const current = useQuery(
    api.operatorControls.getCurrent,
    projectId ? { projectId } : {}
  );
  const history = useQuery(
    api.operatorControls.listHistory,
    projectId ? { projectId, limit: 20 } : { limit: 20 }
  );
  const setMode = useMutation(api.operatorControls.setMode);
  const [mode, setModeState] = useState("NORMAL");
  const [reason, setReason] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  useEffect(() => {
    if (current?.mode) {
      setModeState(current.mode);
    }
  }, [current?.mode]);
  async function handleSave() {
    setSaving(true);
    setError(null);
    try {
      await setMode({
        projectId: projectId ?? void 0,
        mode,
        reason: reason.trim() || void 0,
        userId: "operator"
      });
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to update operator controls");
    } finally {
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsxDEV(Modal, { onClose, children: [
    /* @__PURE__ */ jsxDEV("h2", { style: { margin: "0 0 12px", fontSize: "1.2rem", fontWeight: 700 }, children: "Operator Controls" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
      lineNumber: 80,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { style: { margin: "0 0 14px", color: "var(--muted-foreground)", fontSize: "0.85rem" }, children: "Control execution posture for this project. Use quarantined mode for incident containment." }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
      lineNumber: 81,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gap: 8, marginBottom: 12 }, children: MODES.map((entry) => {
      const active = mode === entry.id;
      return /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setModeState(entry.id),
          style: {
            border: active ? `1px solid ${entry.color}` : "1px solid var(--border)",
            background: active ? "var(--background)" : "var(--card)",
            borderRadius: 8,
            padding: "10px 12px",
            textAlign: "left",
            cursor: "pointer"
          },
          children: [
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between" }, children: [
              /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: 600, color: "var(--foreground)" }, children: entry.label }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
                lineNumber: 103,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { style: { color: entry.color, fontSize: "0.75rem", fontWeight: 700 }, children: entry.id }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
                lineNumber: 104,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
              lineNumber: 102,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { color: "var(--muted-foreground)", fontSize: "0.8rem", marginTop: 4 }, children: entry.detail }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
              lineNumber: 106,
              columnNumber: 15
            }, this)
          ]
        },
        entry.id,
        true,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
          lineNumber: 89,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
      lineNumber: 85,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "textarea",
      {
        value: reason,
        onChange: (event) => setReason(event.target.value),
        placeholder: "Reason (recommended for non-normal modes)",
        rows: 3,
        style: {
          width: "100%",
          padding: "8px 10px",
          background: "var(--background)",
          border: "1px solid var(--border)",
          borderRadius: 6,
          color: "var(--foreground)",
          fontSize: "0.84rem",
          resize: "vertical"
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
        lineNumber: 112,
        columnNumber: 7
      },
      this
    ),
    error && /* @__PURE__ */ jsxDEV(
      "div",
      {
        style: {
          marginTop: 8,
          padding: "8px 10px",
          background: "#450a0a",
          border: "1px solid #ef4444",
          borderRadius: 6,
          color: "#fecaca",
          fontSize: "0.8rem"
        },
        children: error
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
        lineNumber: 130,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: 8, marginTop: 12 }, children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: handleSave,
          disabled: saving,
          style: {
            padding: "8px 12px",
            background: "#1d4ed8",
            border: "1px solid #2563eb",
            borderRadius: 6,
            color: "#dbeafe",
            fontSize: "0.82rem",
            cursor: saving ? "not-allowed" : "pointer"
          },
          children: saving ? "Saving..." : "Apply Mode"
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
          lineNumber: 146,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: onClose,
          disabled: saving,
          style: {
            padding: "8px 12px",
            background: "var(--border)",
            border: "1px solid var(--border)",
            borderRadius: 6,
            color: "#cbd5e1",
            fontSize: "0.82rem",
            cursor: "pointer"
          },
          children: "Cancel"
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
          lineNumber: 162,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
      lineNumber: 145,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { marginTop: 16, borderTop: "1px solid var(--border)", paddingTop: 10 }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { color: "var(--muted-foreground)", fontSize: "0.75rem", marginBottom: 6 }, children: "Recent mode changes" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
        lineNumber: 181,
        columnNumber: 9
      }, this),
      !history || history.length === 0 ? /* @__PURE__ */ jsxDEV("div", { style: { color: "var(--muted-foreground)", fontSize: "0.8rem" }, children: "No control changes yet." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
        lineNumber: 183,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: 6, maxHeight: 180, overflow: "auto" }, children: history.map(
        (entry) => /* @__PURE__ */ jsxDEV(
          "div",
          {
            style: {
              background: "var(--background)",
              border: "1px solid var(--border)",
              borderRadius: 6,
              padding: "8px 10px"
            },
            children: [
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", gap: 8 }, children: [
                /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--foreground)", fontSize: "0.82rem", fontWeight: 600 }, children: entry.mode }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
                  lineNumber: 197,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--muted-foreground)", fontSize: "0.75rem" }, children: new Date(entry.updatedAt).toLocaleString() }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
                  lineNumber: 198,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
                lineNumber: 196,
                columnNumber: 17
              }, this),
              entry.reason && /* @__PURE__ */ jsxDEV("div", { style: { color: "var(--muted-foreground)", fontSize: "0.78rem", marginTop: 2 }, children: entry.reason }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
                lineNumber: 203,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: { color: "var(--muted-foreground)", fontSize: "0.72rem", marginTop: 2 }, children: [
                "by ",
                entry.updatedBy
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
                lineNumber: 205,
                columnNumber: 17
              }, this)
            ]
          },
          entry._id,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
            lineNumber: 187,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
        lineNumber: 185,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
      lineNumber: 180,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
    lineNumber: 79,
    columnNumber: 5
  }, this);
}
_s(OperatorControlsModal, "HihtgOdQATQyJhVux+TZk/VLNog=", false, function() {
  return [useQuery, useQuery, useMutation];
});
_c = OperatorControlsModal;
function Modal({ children, onClose }) {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        style: {
          position: "fixed",
          inset: 0,
          background: "rgba(0,0,0,0.55)",
          zIndex: 9998
        },
        onClick: onClose,
        "aria-hidden": "true"
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
        lineNumber: 218,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        role: "dialog",
        "aria-modal": "true",
        style: {
          position: "fixed",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: "min(700px, 92vw)",
          maxHeight: "88vh",
          overflow: "auto",
          background: "var(--card)",
          border: "1px solid var(--border)",
          borderRadius: 12,
          zIndex: 9999,
          padding: 18
        },
        children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: onClose,
              style: {
                position: "absolute",
                top: 8,
                right: 10,
                background: "none",
                border: "none",
                color: "var(--muted-foreground)",
                fontSize: "1.5rem",
                cursor: "pointer"
              },
              "aria-label": "Close",
              children: "×"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
              lineNumber: 246,
              columnNumber: 9
            },
            this
          ),
          children
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
        lineNumber: 228,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx",
    lineNumber: 217,
    columnNumber: 5
  }, this);
}
_c2 = Modal;
var _c, _c2;
$RefreshReg$(_c, "OperatorControlsModal");
$RefreshReg$(_c2, "Modal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/OperatorControlsModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNERNLFNBeUlGLFVBeklFOzs7Ozs7Ozs7Ozs7Ozs7OztBQTVETixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLFdBQVc7QUFHcEIsTUFBTUMsUUFBdUg7QUFBQSxFQUMzSCxFQUFFQyxJQUFJLFVBQVVDLE9BQU8sVUFBVUMsUUFBUSwwQ0FBMENDLE9BQU8sVUFBVTtBQUFBLEVBQ3BHLEVBQUVILElBQUksVUFBVUMsT0FBTyxVQUFVQyxRQUFRLDBDQUEwQ0MsT0FBTyxVQUFVO0FBQUEsRUFDcEcsRUFBRUgsSUFBSSxZQUFZQyxPQUFPLFlBQVlDLFFBQVEsa0RBQWtEQyxPQUFPLFVBQVU7QUFBQSxFQUNoSCxFQUFFSCxJQUFJLGVBQWVDLE9BQU8sZUFBZUMsUUFBUSxzQ0FBc0NDLE9BQU8sVUFBVTtBQUFDO0FBR3RHLGdCQUFTQyxzQkFBc0I7QUFBQSxFQUNwQ0M7QUFBQUEsRUFDQUM7QUFJRixHQUFHO0FBQUFDLEtBQUE7QUFDRCxRQUFNQyxVQUFVWDtBQUFBQSxJQUNkQyxJQUFJVyxpQkFBaUJDO0FBQUFBLElBQ3JCTCxZQUFZLEVBQUVBLFVBQVUsSUFBSSxDQUFDO0FBQUEsRUFDL0I7QUFDQSxRQUFNTSxVQUFVZDtBQUFBQSxJQUNkQyxJQUFJVyxpQkFBaUJHO0FBQUFBLElBQ3JCUCxZQUFZLEVBQUVBLFdBQVdRLE9BQU8sR0FBRyxJQUFJLEVBQUVBLE9BQU8sR0FBRztBQUFBLEVBQ3JEO0FBQ0EsUUFBTUMsVUFBVWxCLFlBQVlFLElBQUlXLGlCQUFpQkssT0FBTztBQUV4RCxRQUFNLENBQUNDLE1BQU1DLFlBQVksSUFBSXJCLFNBQTJELFFBQVE7QUFDaEcsUUFBTSxDQUFDc0IsUUFBUUMsU0FBUyxJQUFJdkIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ3dCLFFBQVFDLFNBQVMsSUFBSXpCLFNBQVMsS0FBSztBQUMxQyxRQUFNLENBQUMwQixPQUFPQyxRQUFRLElBQUkzQixTQUF3QixJQUFJO0FBRXRERCxZQUFVLE1BQU07QUFDZCxRQUFJYyxTQUFTTyxNQUFNO0FBQ2pCQyxtQkFBYVIsUUFBUU8sSUFBSTtBQUFBLElBQzNCO0FBQUEsRUFDRixHQUFHLENBQUNQLFNBQVNPLElBQUksQ0FBQztBQUVsQixpQkFBZVEsYUFBYTtBQUMxQkgsY0FBVSxJQUFJO0FBQ2RFLGFBQVMsSUFBSTtBQUNiLFFBQUk7QUFDRixZQUFNUixRQUFRO0FBQUEsUUFDWlQsV0FBV0EsYUFBYW1CO0FBQUFBLFFBQ3hCVDtBQUFBQSxRQUNBRSxRQUFRQSxPQUFPUSxLQUFLLEtBQUtEO0FBQUFBLFFBQ3pCRSxRQUFRO0FBQUEsTUFDVixDQUFDO0FBQ0RwQixjQUFRO0FBQUEsSUFDVixTQUFTcUIsS0FBSztBQUNaTCxlQUFTSyxlQUFlQyxRQUFRRCxJQUFJRSxVQUFVLG9DQUFvQztBQUFBLElBQ3BGLFVBQUM7QUFDQ1QsZ0JBQVUsS0FBSztBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FBTSxTQUNMO0FBQUEsMkJBQUMsUUFBRyxPQUFPLEVBQUVVLFFBQVEsWUFBWUMsVUFBVSxVQUFVQyxZQUFZLElBQUksR0FBRyxpQ0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5RjtBQUFBLElBQ3pGLHVCQUFDLE9BQUUsT0FBTyxFQUFFRixRQUFRLFlBQVkzQixPQUFPLDJCQUEyQjRCLFVBQVUsVUFBVSxHQUFFLDBHQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFRSxTQUFTLFFBQVFDLEtBQUssR0FBR0MsY0FBYyxHQUFHLEdBQ3JEcEMsZ0JBQU1xQyxJQUFJLENBQUNDLFVBQVU7QUFDcEIsWUFBTUMsU0FBU3ZCLFNBQVNzQixNQUFNckM7QUFDOUIsYUFDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUMsTUFBSztBQUFBLFVBQ0wsU0FBUyxNQUFNZ0IsYUFBYXFCLE1BQU1yQyxFQUFFO0FBQUEsVUFDcEMsT0FBTztBQUFBLFlBQ0x1QyxRQUFRRCxTQUFTLGFBQWFELE1BQU1sQyxLQUFLLEtBQUs7QUFBQSxZQUM5Q3FDLFlBQVlGLFNBQVMsc0JBQXNCO0FBQUEsWUFDM0NHLGNBQWM7QUFBQSxZQUNkQyxTQUFTO0FBQUEsWUFDVEMsV0FBVztBQUFBLFlBQ1hDLFFBQVE7QUFBQSxVQUNWO0FBQUEsVUFFQTtBQUFBLG1DQUFDLFNBQUksT0FBTyxFQUFFWCxTQUFTLFFBQVFZLFlBQVksVUFBVUMsZ0JBQWdCLGdCQUFnQixHQUNuRjtBQUFBLHFDQUFDLFVBQUssT0FBTyxFQUFFZCxZQUFZLEtBQUs3QixPQUFPLG9CQUFvQixHQUFJa0MsZ0JBQU1wQyxTQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRTtBQUFBLGNBQzNFLHVCQUFDLFVBQUssT0FBTyxFQUFFRSxPQUFPa0MsTUFBTWxDLE9BQU80QixVQUFVLFdBQVdDLFlBQVksSUFBSSxHQUFJSyxnQkFBTXJDLE1BQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFGO0FBQUEsaUJBRnZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFRyxPQUFPLDJCQUEyQjRCLFVBQVUsVUFBVWdCLFdBQVcsRUFBRSxHQUFJVixnQkFBTW5DLFVBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtHO0FBQUE7QUFBQTtBQUFBLFFBaEI3Rm1DLE1BQU1yQztBQUFBQSxRQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFrQkE7QUFBQSxJQUVKLENBQUMsS0F4Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU9pQjtBQUFBQSxRQUNQLFVBQVUsQ0FBQytCLFVBQVU5QixVQUFVOEIsTUFBTUMsT0FBT0MsS0FBSztBQUFBLFFBQ2pELGFBQVk7QUFBQSxRQUNaLE1BQU07QUFBQSxRQUNOLE9BQU87QUFBQSxVQUNMQyxPQUFPO0FBQUEsVUFDUFQsU0FBUztBQUFBLFVBQ1RGLFlBQVk7QUFBQSxVQUNaRCxRQUFRO0FBQUEsVUFDUkUsY0FBYztBQUFBLFVBQ2R0QyxPQUFPO0FBQUEsVUFDUDRCLFVBQVU7QUFBQSxVQUNWcUIsUUFBUTtBQUFBLFFBQ1Y7QUFBQTtBQUFBLE1BZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBY0k7QUFBQSxJQUdIL0IsU0FDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTztBQUFBLFVBQ0wwQixXQUFXO0FBQUEsVUFDWEwsU0FBUztBQUFBLFVBQ1RGLFlBQVk7QUFBQSxVQUNaRCxRQUFRO0FBQUEsVUFDUkUsY0FBYztBQUFBLFVBQ2R0QyxPQUFPO0FBQUEsVUFDUDRCLFVBQVU7QUFBQSxRQUNaO0FBQUEsUUFFQ1Y7QUFBQUE7QUFBQUEsTUFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFZQTtBQUFBLElBR0YsdUJBQUMsU0FBSSxPQUFPLEVBQUVZLFNBQVMsUUFBUUMsS0FBSyxHQUFHYSxXQUFXLEdBQUcsR0FDbkQ7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FBU3hCO0FBQUFBLFVBQ1QsVUFBVUo7QUFBQUEsVUFDVixPQUFPO0FBQUEsWUFDTHVCLFNBQVM7QUFBQSxZQUNURixZQUFZO0FBQUEsWUFDWkQsUUFBUTtBQUFBLFlBQ1JFLGNBQWM7QUFBQSxZQUNkdEMsT0FBTztBQUFBLFlBQ1A0QixVQUFVO0FBQUEsWUFDVmEsUUFBUXpCLFNBQVMsZ0JBQWdCO0FBQUEsVUFDbkM7QUFBQSxVQUVDQSxtQkFBUyxjQUFjO0FBQUE7QUFBQSxRQWQxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFlQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVNiO0FBQUFBLFVBQ1QsVUFBVWE7QUFBQUEsVUFDVixPQUFPO0FBQUEsWUFDTHVCLFNBQVM7QUFBQSxZQUNURixZQUFZO0FBQUEsWUFDWkQsUUFBUTtBQUFBLFlBQ1JFLGNBQWM7QUFBQSxZQUNkdEMsT0FBTztBQUFBLFlBQ1A0QixVQUFVO0FBQUEsWUFDVmEsUUFBUTtBQUFBLFVBQ1Y7QUFBQSxVQUFFO0FBQUE7QUFBQSxRQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWVBO0FBQUEsU0FoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlDQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVHLFdBQVcsSUFBSU0sV0FBVywyQkFBMkJDLFlBQVksR0FBRyxHQUNoRjtBQUFBLDZCQUFDLFNBQUksT0FBTyxFQUFFbkQsT0FBTywyQkFBMkI0QixVQUFVLFdBQVdJLGNBQWMsRUFBRSxHQUFHLG1DQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJHO0FBQUEsTUFDMUcsQ0FBQ3hCLFdBQVdBLFFBQVE0QyxXQUFXLElBQzlCLHVCQUFDLFNBQUksT0FBTyxFQUFFcEQsT0FBTywyQkFBMkI0QixVQUFVLFNBQVMsR0FBRyx1Q0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RixJQUU3Rix1QkFBQyxTQUFJLE9BQU8sRUFBRUUsU0FBUyxRQUFRdUIsZUFBZSxVQUFVdEIsS0FBSyxHQUFHdUIsV0FBVyxLQUFLQyxVQUFVLE9BQU8sR0FDOUYvQyxrQkFBUXlCO0FBQUFBLFFBQUksQ0FBQ0MsVUFDWjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsT0FBTztBQUFBLGNBQ0xHLFlBQVk7QUFBQSxjQUNaRCxRQUFRO0FBQUEsY0FDUkUsY0FBYztBQUFBLGNBQ2RDLFNBQVM7QUFBQSxZQUNYO0FBQUEsWUFFQTtBQUFBLHFDQUFDLFNBQUksT0FBTyxFQUFFVCxTQUFTLFFBQVFhLGdCQUFnQixpQkFBaUJaLEtBQUssRUFBRSxHQUNyRTtBQUFBLHVDQUFDLFVBQUssT0FBTyxFQUFFL0IsT0FBTyxxQkFBcUI0QixVQUFVLFdBQVdDLFlBQVksSUFBSSxHQUFJSyxnQkFBTXRCLFFBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStGO0FBQUEsZ0JBQy9GLHVCQUFDLFVBQUssT0FBTyxFQUFFWixPQUFPLDJCQUEyQjRCLFVBQVUsVUFBVSxHQUNsRSxjQUFJNEIsS0FBS3RCLE1BQU11QixTQUFTLEVBQUVDLGVBQWUsS0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNDeEIsTUFBTXBCLFVBQ0wsdUJBQUMsU0FBSSxPQUFPLEVBQUVkLE9BQU8sMkJBQTJCNEIsVUFBVSxXQUFXZ0IsV0FBVyxFQUFFLEdBQUlWLGdCQUFNcEIsVUFBNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUc7QUFBQSxjQUVyRyx1QkFBQyxTQUFJLE9BQU8sRUFBRWQsT0FBTywyQkFBMkI0QixVQUFVLFdBQVdnQixXQUFXLEVBQUUsR0FBRztBQUFBO0FBQUEsZ0JBQUlWLE1BQU15QjtBQUFBQSxtQkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUc7QUFBQTtBQUFBO0FBQUEsVUFqQnBHekIsTUFBTTBCO0FBQUFBLFVBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW1CQTtBQUFBLE1BQ0QsS0F0Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVCQTtBQUFBLFNBNUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4QkE7QUFBQSxPQW5JRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0lBO0FBRUo7QUFBQ3hELEdBckxlSCx1QkFBcUI7QUFBQSxVQU9uQlAsVUFJQUEsVUFJQUQsV0FBVztBQUFBO0FBQUEsS0FmYlE7QUF1TGhCLFNBQVM0RCxNQUFNLEVBQUVDLFVBQVUzRCxRQUE0RCxHQUFHO0FBQ3hGLFNBQ0UsbUNBQ0U7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTztBQUFBLFVBQ0w0RCxVQUFVO0FBQUEsVUFDVkMsT0FBTztBQUFBLFVBQ1AzQixZQUFZO0FBQUEsVUFDWjRCLFFBQVE7QUFBQSxRQUNWO0FBQUEsUUFDQSxTQUFTOUQ7QUFBQUEsUUFDVCxlQUFZO0FBQUE7QUFBQSxNQVJkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVFvQjtBQUFBLElBRXBCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxjQUFXO0FBQUEsUUFDWCxPQUFPO0FBQUEsVUFDTDRELFVBQVU7QUFBQSxVQUNWRyxLQUFLO0FBQUEsVUFDTEMsTUFBTTtBQUFBLFVBQ05DLFdBQVc7QUFBQSxVQUNYcEIsT0FBTztBQUFBLFVBQ1BNLFdBQVc7QUFBQSxVQUNYQyxVQUFVO0FBQUEsVUFDVmxCLFlBQVk7QUFBQSxVQUNaRCxRQUFRO0FBQUEsVUFDUkUsY0FBYztBQUFBLFVBQ2QyQixRQUFRO0FBQUEsVUFDUjFCLFNBQVM7QUFBQSxRQUNYO0FBQUEsUUFFQTtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTcEM7QUFBQUEsY0FDVCxPQUFPO0FBQUEsZ0JBQ0w0RCxVQUFVO0FBQUEsZ0JBQ1ZHLEtBQUs7QUFBQSxnQkFDTEcsT0FBTztBQUFBLGdCQUNQaEMsWUFBWTtBQUFBLGdCQUNaRCxRQUFRO0FBQUEsZ0JBQ1JwQyxPQUFPO0FBQUEsZ0JBQ1A0QixVQUFVO0FBQUEsZ0JBQ1ZhLFFBQVE7QUFBQSxjQUNWO0FBQUEsY0FDQSxjQUFXO0FBQUEsY0FBTztBQUFBO0FBQUEsWUFicEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBZ0JBO0FBQUEsVUFDQ3FCO0FBQUFBO0FBQUFBO0FBQUFBLE1BbkNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQW9DQTtBQUFBLE9BL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnREE7QUFFSjtBQUFDUSxNQXBEUVQ7QUFBSyxJQUFBVSxJQUFBRDtBQUFBLGFBQUFDLElBQUE7QUFBQSxhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsInVzZVF1ZXJ5IiwiYXBpIiwiTU9ERVMiLCJpZCIsImxhYmVsIiwiZGV0YWlsIiwiY29sb3IiLCJPcGVyYXRvckNvbnRyb2xzTW9kYWwiLCJwcm9qZWN0SWQiLCJvbkNsb3NlIiwiX3MiLCJjdXJyZW50Iiwib3BlcmF0b3JDb250cm9scyIsImdldEN1cnJlbnQiLCJoaXN0b3J5IiwibGlzdEhpc3RvcnkiLCJsaW1pdCIsInNldE1vZGUiLCJtb2RlIiwic2V0TW9kZVN0YXRlIiwicmVhc29uIiwic2V0UmVhc29uIiwic2F2aW5nIiwic2V0U2F2aW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsImhhbmRsZVNhdmUiLCJ1bmRlZmluZWQiLCJ0cmltIiwidXNlcklkIiwiZXJyIiwiRXJyb3IiLCJtZXNzYWdlIiwibWFyZ2luIiwiZm9udFNpemUiLCJmb250V2VpZ2h0IiwiZGlzcGxheSIsImdhcCIsIm1hcmdpbkJvdHRvbSIsIm1hcCIsImVudHJ5IiwiYWN0aXZlIiwiYm9yZGVyIiwiYmFja2dyb3VuZCIsImJvcmRlclJhZGl1cyIsInBhZGRpbmciLCJ0ZXh0QWxpZ24iLCJjdXJzb3IiLCJhbGlnbkl0ZW1zIiwianVzdGlmeUNvbnRlbnQiLCJtYXJnaW5Ub3AiLCJldmVudCIsInRhcmdldCIsInZhbHVlIiwid2lkdGgiLCJyZXNpemUiLCJib3JkZXJUb3AiLCJwYWRkaW5nVG9wIiwibGVuZ3RoIiwiZmxleERpcmVjdGlvbiIsIm1heEhlaWdodCIsIm92ZXJmbG93IiwiRGF0ZSIsInVwZGF0ZWRBdCIsInRvTG9jYWxlU3RyaW5nIiwidXBkYXRlZEJ5IiwiX2lkIiwiTW9kYWwiLCJjaGlsZHJlbiIsInBvc2l0aW9uIiwiaW5zZXQiLCJ6SW5kZXgiLCJ0b3AiLCJsZWZ0IiwidHJhbnNmb3JtIiwicmlnaHQiLCJfYzIiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJPcGVyYXRvckNvbnRyb2xzTW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB0eXBlIHsgSWQgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvZGF0YU1vZGVsXCI7XG5cbmNvbnN0IE1PREVTOiBBcnJheTx7IGlkOiBcIk5PUk1BTFwiIHwgXCJQQVVTRURcIiB8IFwiRFJBSU5JTkdcIiB8IFwiUVVBUkFOVElORURcIjsgbGFiZWw6IHN0cmluZzsgZGV0YWlsOiBzdHJpbmc7IGNvbG9yOiBzdHJpbmcgfT4gPSBbXG4gIHsgaWQ6IFwiTk9STUFMXCIsIGxhYmVsOiBcIk5vcm1hbFwiLCBkZXRhaWw6IFwiQWxsIGF1dG9tYXRpb24gYW5kIHRyYW5zaXRpb25zIGFsbG93ZWRcIiwgY29sb3I6IFwiIzE2YTM0YVwiIH0sXG4gIHsgaWQ6IFwiUEFVU0VEXCIsIGxhYmVsOiBcIlBhdXNlZFwiLCBkZXRhaWw6IFwiQmxvY2tzIG5vbi1odW1hbiBleGVjdXRpb24gaW1tZWRpYXRlbHlcIiwgY29sb3I6IFwiI2Y1OWUwYlwiIH0sXG4gIHsgaWQ6IFwiRFJBSU5JTkdcIiwgbGFiZWw6IFwiRHJhaW5pbmdcIiwgZGV0YWlsOiBcIkJsb2NrcyBuZXcgcnVucyB3aGlsZSBhbGxvd2luZyBzYWZlIGNvbXBsZXRpb25cIiwgY29sb3I6IFwiIzAyODRjN1wiIH0sXG4gIHsgaWQ6IFwiUVVBUkFOVElORURcIiwgbGFiZWw6IFwiUXVhcmFudGluZWRcIiwgZGV0YWlsOiBcIkhhcmQgYmxvY2sgb24gYXV0b25vbW91cyBleGVjdXRpb25cIiwgY29sb3I6IFwiI2RjMjYyNlwiIH0sXG5dO1xuXG5leHBvcnQgZnVuY3Rpb24gT3BlcmF0b3JDb250cm9sc01vZGFsKHtcbiAgcHJvamVjdElkLFxuICBvbkNsb3NlLFxufToge1xuICBwcm9qZWN0SWQ6IElkPFwicHJvamVjdHNcIj4gfCBudWxsO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xufSkge1xuICBjb25zdCBjdXJyZW50ID0gdXNlUXVlcnkoXG4gICAgYXBpLm9wZXJhdG9yQ29udHJvbHMuZ2V0Q3VycmVudCxcbiAgICBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCB9IDoge31cbiAgKTtcbiAgY29uc3QgaGlzdG9yeSA9IHVzZVF1ZXJ5KFxuICAgIGFwaS5vcGVyYXRvckNvbnRyb2xzLmxpc3RIaXN0b3J5LFxuICAgIHByb2plY3RJZCA/IHsgcHJvamVjdElkLCBsaW1pdDogMjAgfSA6IHsgbGltaXQ6IDIwIH1cbiAgKTtcbiAgY29uc3Qgc2V0TW9kZSA9IHVzZU11dGF0aW9uKGFwaS5vcGVyYXRvckNvbnRyb2xzLnNldE1vZGUpO1xuXG4gIGNvbnN0IFttb2RlLCBzZXRNb2RlU3RhdGVdID0gdXNlU3RhdGU8XCJOT1JNQUxcIiB8IFwiUEFVU0VEXCIgfCBcIkRSQUlOSU5HXCIgfCBcIlFVQVJBTlRJTkVEXCI+KFwiTk9STUFMXCIpO1xuICBjb25zdCBbcmVhc29uLCBzZXRSZWFzb25dID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoY3VycmVudD8ubW9kZSkge1xuICAgICAgc2V0TW9kZVN0YXRlKGN1cnJlbnQubW9kZSk7XG4gICAgfVxuICB9LCBbY3VycmVudD8ubW9kZV0pO1xuXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVNhdmUoKSB7XG4gICAgc2V0U2F2aW5nKHRydWUpO1xuICAgIHNldEVycm9yKG51bGwpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBzZXRNb2RlKHtcbiAgICAgICAgcHJvamVjdElkOiBwcm9qZWN0SWQgPz8gdW5kZWZpbmVkLFxuICAgICAgICBtb2RlLFxuICAgICAgICByZWFzb246IHJlYXNvbi50cmltKCkgfHwgdW5kZWZpbmVkLFxuICAgICAgICB1c2VySWQ6IFwib3BlcmF0b3JcIixcbiAgICAgIH0pO1xuICAgICAgb25DbG9zZSgpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6IFwiRmFpbGVkIHRvIHVwZGF0ZSBvcGVyYXRvciBjb250cm9sc1wiKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0U2F2aW5nKGZhbHNlKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxNb2RhbCBvbkNsb3NlPXtvbkNsb3NlfT5cbiAgICAgIDxoMiBzdHlsZT17eyBtYXJnaW46IFwiMCAwIDEycHhcIiwgZm9udFNpemU6IFwiMS4ycmVtXCIsIGZvbnRXZWlnaHQ6IDcwMCB9fT5PcGVyYXRvciBDb250cm9sczwvaDI+XG4gICAgICA8cCBzdHlsZT17eyBtYXJnaW46IFwiMCAwIDE0cHhcIiwgY29sb3I6IFwidmFyKC0tbXV0ZWQtZm9yZWdyb3VuZClcIiwgZm9udFNpemU6IFwiMC44NXJlbVwiIH19PlxuICAgICAgICBDb250cm9sIGV4ZWN1dGlvbiBwb3N0dXJlIGZvciB0aGlzIHByb2plY3QuIFVzZSBxdWFyYW50aW5lZCBtb2RlIGZvciBpbmNpZGVudCBjb250YWlubWVudC5cbiAgICAgIDwvcD5cblxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ2FwOiA4LCBtYXJnaW5Cb3R0b206IDEyIH19PlxuICAgICAgICB7TU9ERVMubWFwKChlbnRyeSkgPT4ge1xuICAgICAgICAgIGNvbnN0IGFjdGl2ZSA9IG1vZGUgPT09IGVudHJ5LmlkO1xuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIGtleT17ZW50cnkuaWR9XG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNb2RlU3RhdGUoZW50cnkuaWQpfVxuICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgIGJvcmRlcjogYWN0aXZlID8gYDFweCBzb2xpZCAke2VudHJ5LmNvbG9yfWAgOiBcIjFweCBzb2xpZCB2YXIoLS1ib3JkZXIpXCIsXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogYWN0aXZlID8gXCJ2YXIoLS1iYWNrZ3JvdW5kKVwiIDogXCJ2YXIoLS1jYXJkKVwiLFxuICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogOCxcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjEwcHggMTJweFwiLFxuICAgICAgICAgICAgICAgIHRleHRBbGlnbjogXCJsZWZ0XCIsXG4gICAgICAgICAgICAgICAgY3Vyc29yOiBcInBvaW50ZXJcIixcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiIH19PlxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDYwMCwgY29sb3I6IFwidmFyKC0tZm9yZWdyb3VuZClcIiB9fT57ZW50cnkubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBlbnRyeS5jb2xvciwgZm9udFNpemU6IFwiMC43NXJlbVwiLCBmb250V2VpZ2h0OiA3MDAgfX0+e2VudHJ5LmlkfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0tbXV0ZWQtZm9yZWdyb3VuZClcIiwgZm9udFNpemU6IFwiMC44cmVtXCIsIG1hcmdpblRvcDogNCB9fT57ZW50cnkuZGV0YWlsfTwvZGl2PlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKTtcbiAgICAgICAgfSl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgPHRleHRhcmVhXG4gICAgICAgIHZhbHVlPXtyZWFzb259XG4gICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFJlYXNvbihldmVudC50YXJnZXQudmFsdWUpfVxuICAgICAgICBwbGFjZWhvbGRlcj1cIlJlYXNvbiAocmVjb21tZW5kZWQgZm9yIG5vbi1ub3JtYWwgbW9kZXMpXCJcbiAgICAgICAgcm93cz17M31cbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICB3aWR0aDogXCIxMDAlXCIsXG4gICAgICAgICAgcGFkZGluZzogXCI4cHggMTBweFwiLFxuICAgICAgICAgIGJhY2tncm91bmQ6IFwidmFyKC0tYmFja2dyb3VuZClcIixcbiAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkIHZhcigtLWJvcmRlcilcIixcbiAgICAgICAgICBib3JkZXJSYWRpdXM6IDYsXG4gICAgICAgICAgY29sb3I6IFwidmFyKC0tZm9yZWdyb3VuZClcIixcbiAgICAgICAgICBmb250U2l6ZTogXCIwLjg0cmVtXCIsXG4gICAgICAgICAgcmVzaXplOiBcInZlcnRpY2FsXCIsXG4gICAgICAgIH19XG4gICAgICAvPlxuXG4gICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICA8ZGl2XG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIG1hcmdpblRvcDogOCxcbiAgICAgICAgICAgIHBhZGRpbmc6IFwiOHB4IDEwcHhcIixcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IFwiIzQ1MGEwYVwiLFxuICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCAjZWY0NDQ0XCIsXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6IDYsXG4gICAgICAgICAgICBjb2xvcjogXCIjZmVjYWNhXCIsXG4gICAgICAgICAgICBmb250U2l6ZTogXCIwLjhyZW1cIixcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAge2Vycm9yfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogOCwgbWFyZ2luVG9wOiAxMiB9fT5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNhdmV9XG4gICAgICAgICAgZGlzYWJsZWQ9e3NhdmluZ31cbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgcGFkZGluZzogXCI4cHggMTJweFwiLFxuICAgICAgICAgICAgYmFja2dyb3VuZDogXCIjMWQ0ZWQ4XCIsXG4gICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkICMyNTYzZWJcIixcbiAgICAgICAgICAgIGJvcmRlclJhZGl1czogNixcbiAgICAgICAgICAgIGNvbG9yOiBcIiNkYmVhZmVcIixcbiAgICAgICAgICAgIGZvbnRTaXplOiBcIjAuODJyZW1cIixcbiAgICAgICAgICAgIGN1cnNvcjogc2F2aW5nID8gXCJub3QtYWxsb3dlZFwiIDogXCJwb2ludGVyXCIsXG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIHtzYXZpbmcgPyBcIlNhdmluZy4uLlwiIDogXCJBcHBseSBNb2RlXCJ9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICBkaXNhYmxlZD17c2F2aW5nfVxuICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICBwYWRkaW5nOiBcIjhweCAxMnB4XCIsXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBcInZhcigtLWJvcmRlcilcIixcbiAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWQgdmFyKC0tYm9yZGVyKVwiLFxuICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiA2LFxuICAgICAgICAgICAgY29sb3I6IFwiI2NiZDVlMVwiLFxuICAgICAgICAgICAgZm9udFNpemU6IFwiMC44MnJlbVwiLFxuICAgICAgICAgICAgY3Vyc29yOiBcInBvaW50ZXJcIixcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgQ2FuY2VsXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luVG9wOiAxNiwgYm9yZGVyVG9wOiBcIjFweCBzb2xpZCB2YXIoLS1ib3JkZXIpXCIsIHBhZGRpbmdUb3A6IDEwIH19PlxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLW11dGVkLWZvcmVncm91bmQpXCIsIGZvbnRTaXplOiBcIjAuNzVyZW1cIiwgbWFyZ2luQm90dG9tOiA2IH19PlJlY2VudCBtb2RlIGNoYW5nZXM8L2Rpdj5cbiAgICAgICAgeyFoaXN0b3J5IHx8IGhpc3RvcnkubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0tbXV0ZWQtZm9yZWdyb3VuZClcIiwgZm9udFNpemU6IFwiMC44cmVtXCIgfX0+Tm8gY29udHJvbCBjaGFuZ2VzIHlldC48L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLCBnYXA6IDYsIG1heEhlaWdodDogMTgwLCBvdmVyZmxvdzogXCJhdXRvXCIgfX0+XG4gICAgICAgICAgICB7aGlzdG9yeS5tYXAoKGVudHJ5KSA9PiAoXG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBrZXk9e2VudHJ5Ll9pZH1cbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCJ2YXIoLS1iYWNrZ3JvdW5kKVwiLFxuICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCB2YXIoLS1ib3JkZXIpXCIsXG4gICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDYsXG4gICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjhweCAxMHB4XCIsXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgZ2FwOiA4IH19PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0tZm9yZWdyb3VuZClcIiwgZm9udFNpemU6IFwiMC44MnJlbVwiLCBmb250V2VpZ2h0OiA2MDAgfX0+e2VudHJ5Lm1vZGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6IFwidmFyKC0tbXV0ZWQtZm9yZWdyb3VuZClcIiwgZm9udFNpemU6IFwiMC43NXJlbVwiIH19PlxuICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoZW50cnkudXBkYXRlZEF0KS50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIHtlbnRyeS5yZWFzb24gJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1tdXRlZC1mb3JlZ3JvdW5kKVwiLCBmb250U2l6ZTogXCIwLjc4cmVtXCIsIG1hcmdpblRvcDogMiB9fT57ZW50cnkucmVhc29ufTwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1tdXRlZC1mb3JlZ3JvdW5kKVwiLCBmb250U2l6ZTogXCIwLjcycmVtXCIsIG1hcmdpblRvcDogMiB9fT5ieSB7ZW50cnkudXBkYXRlZEJ5fTwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9Nb2RhbD5cbiAgKTtcbn1cblxuZnVuY3Rpb24gTW9kYWwoeyBjaGlsZHJlbiwgb25DbG9zZSB9OiB7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7IG9uQ2xvc2U6ICgpID0+IHZvaWQgfSkge1xuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8ZGl2XG4gICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgcG9zaXRpb246IFwiZml4ZWRcIixcbiAgICAgICAgICBpbnNldDogMCxcbiAgICAgICAgICBiYWNrZ3JvdW5kOiBcInJnYmEoMCwwLDAsMC41NSlcIixcbiAgICAgICAgICB6SW5kZXg6IDk5OTgsXG4gICAgICAgIH19XG4gICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXG4gICAgICAvPlxuICAgICAgPGRpdlxuICAgICAgICByb2xlPVwiZGlhbG9nXCJcbiAgICAgICAgYXJpYS1tb2RhbD1cInRydWVcIlxuICAgICAgICBzdHlsZT17e1xuICAgICAgICAgIHBvc2l0aW9uOiBcImZpeGVkXCIsXG4gICAgICAgICAgdG9wOiBcIjUwJVwiLFxuICAgICAgICAgIGxlZnQ6IFwiNTAlXCIsXG4gICAgICAgICAgdHJhbnNmb3JtOiBcInRyYW5zbGF0ZSgtNTAlLCAtNTAlKVwiLFxuICAgICAgICAgIHdpZHRoOiBcIm1pbig3MDBweCwgOTJ2dylcIixcbiAgICAgICAgICBtYXhIZWlnaHQ6IFwiODh2aFwiLFxuICAgICAgICAgIG92ZXJmbG93OiBcImF1dG9cIixcbiAgICAgICAgICBiYWNrZ3JvdW5kOiBcInZhcigtLWNhcmQpXCIsXG4gICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCB2YXIoLS1ib3JkZXIpXCIsXG4gICAgICAgICAgYm9yZGVyUmFkaXVzOiAxMixcbiAgICAgICAgICB6SW5kZXg6IDk5OTksXG4gICAgICAgICAgcGFkZGluZzogMTgsXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuICAgICAgICAgICAgdG9wOiA4LFxuICAgICAgICAgICAgcmlnaHQ6IDEwLFxuICAgICAgICAgICAgYmFja2dyb3VuZDogXCJub25lXCIsXG4gICAgICAgICAgICBib3JkZXI6IFwibm9uZVwiLFxuICAgICAgICAgICAgY29sb3I6IFwidmFyKC0tbXV0ZWQtZm9yZWdyb3VuZClcIixcbiAgICAgICAgICAgIGZvbnRTaXplOiBcIjEuNXJlbVwiLFxuICAgICAgICAgICAgY3Vyc29yOiBcInBvaW50ZXJcIixcbiAgICAgICAgICB9fVxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJDbG9zZVwiXG4gICAgICAgID5cbiAgICAgICAgICDDl1xuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAge2NoaWxkcmVufVxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9PcGVyYXRvckNvbnRyb2xzTW9kYWwudHN4In0=