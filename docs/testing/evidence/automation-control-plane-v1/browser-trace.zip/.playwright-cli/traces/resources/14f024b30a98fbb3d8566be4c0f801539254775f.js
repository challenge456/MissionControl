import {
  Activity,
  BarChart3,
  Bot,
  BookOpen,
  Brain,
  Building2,
  CheckCircle2,
  ClipboardList,
  Cog,
  FileSearch,
  FlaskConical,
  Gauge,
  GitBranch,
  Landmark,
  LayoutDashboard,
  ListChecks,
  Radar,
  ScrollText,
  Shield,
  Sparkles,
  Target,
  TrendingUp,
  Wrench,
  Scale,
  Route
} from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
export const EOS_NAV_GROUPS = [
  { id: "overview", label: "Overview", icon: LayoutDashboard, items: [
    { view: "command-center", label: "Command Center", icon: LayoutDashboard }
  ] },
  { id: "strategy", label: "Strategy", icon: Target, items: [
    { view: "missions", label: "Missions", icon: Target },
    { view: "goals", label: "Objectives", icon: TrendingUp }
  ] },
  { id: "delivery", label: "Delivery", icon: Wrench, items: [
    { view: "control-work-orders", label: "Work Orders", icon: ClipboardList },
    { view: "tasks", label: "Tasks", icon: ListChecks },
    { view: "factory", label: "Factory Board", icon: Wrench },
    { view: "trace-inspector", label: "Execution", icon: GitBranch },
    { view: "code", label: "Pipelines", icon: Cog },
    { view: "dag", label: "Task Graph", icon: GitBranch }
  ] },
  { id: "operations", label: "Operations", icon: Gauge, items: [
    { view: "agents", label: "Agent Registry", icon: Bot },
    { view: "atc", label: "Queue", icon: Radar },
    { view: "automations", label: "Automations", icon: Sparkles },
    { view: "audit", label: "Approvals & Audit", icon: ScrollText },
    { view: "telemetry", label: "Incidents", icon: Activity },
    { view: "analytics", label: "Cost", icon: BarChart3 }
  ] },
  { id: "intelligence", label: "Intelligence", icon: Brain, items: [
    { view: "harness-loops", label: "Loop Engineering", icon: GitBranch },
    { view: "effectiveness", label: "AI Effectiveness", icon: Gauge },
    { view: "factory-health", label: "Factory Health", icon: CheckCircle2 },
    { view: "readiness", label: "Environment Readiness", icon: Landmark },
    { view: "friction", label: "Friction & Waste", icon: Activity },
    { view: "recommendations", label: "Recommendations", icon: Sparkles },
    { view: "dossier", label: "Evidence Dossiers", icon: Scale }
  ] },
  { id: "quality-automation", label: "Quality & Automation", icon: Shield, items: [
    { view: "harness-code-review-wizard", label: "Code Review Setup", icon: CheckCircle2 },
    { view: "harness-change-review", label: "Change Review", icon: FileSearch },
    { view: "registry-runs", label: "Agent Code Quality", icon: FlaskConical },
    { view: "harness-meta-loop", label: "Improvement Loop", icon: GitBranch }
  ] },
  { id: "knowledge", label: "Knowledge", icon: BookOpen, items: [
    { view: "skills", label: "Context Catalog", icon: Sparkles },
    { view: "registry-lifecycle", label: "Context CDL", icon: BookOpen },
    { view: "registry-evaluate", label: "Evaluate Skill", icon: FlaskConical },
    { view: "registry-inventory", label: "Skill Inventory", icon: ClipboardList },
    { view: "registry-installations", label: "Installations", icon: ClipboardList },
    { view: "registry-runs", label: "Eval Runs", icon: FlaskConical },
    { view: "memory", label: "Memory", icon: Brain },
    { view: "docs", label: "Docs", icon: BookOpen }
  ] },
  { id: "governance", label: "Governance", icon: Shield, items: [
    { view: "policies", label: "Policies", icon: Shield },
    { view: "identity", label: "Identities", icon: ClipboardList },
    { view: "deployments", label: "Deployments", icon: GitBranch },
    { view: "qc-rulesets", label: "QC Rulesets", icon: ListChecks }
  ] },
  { id: "administration", label: "Settings", icon: Building2, items: [
    { view: "projects", label: "Workspaces & Repositories", icon: Building2 },
    { view: "model-routing", label: "Model Routing", icon: Route },
    { view: "gateway", label: "Gateway", icon: Cog },
    { view: "system", label: "Database", icon: Cog }
  ] },
  { id: "developer-tools", label: "Developer Tools", icon: Wrench, items: [
    { view: "design-system", label: "Design DNA", icon: Sparkles },
    { view: "recorder", label: "Recorder", icon: Activity },
    { view: "test-generation", label: "Test Generation", icon: FlaskConical },
    { view: "api-import", label: "API Import", icon: FileSearch }
  ] },
  { id: "labs", label: "Labs", icon: FlaskConical, items: [
    { view: "agent-catalog", label: "Agent Capability Catalog", icon: Bot },
    { view: "flaky-steps", label: "Flaky Steps", icon: Activity },
    { view: "gherkin", label: "Gherkin Studio", icon: ScrollText },
    { view: "codegen", label: "CodeGen", icon: Cog },
    { view: "pipeline", label: "Build Pipeline", icon: Cog }
  ] }
];

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVvc05hdkNvbmZpZy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IEx1Y2lkZUljb24gfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQge1xuICBBY3Rpdml0eSwgQmFyQ2hhcnQzLCBCb3QsIEJvb2tPcGVuLCBCcmFpbiwgQnVpbGRpbmcyLCBDaGVja0NpcmNsZTIsXG4gIENsaXBib2FyZExpc3QsIENvZywgRmlsZVNlYXJjaCwgRmxhc2tDb25pY2FsLCBHYXVnZSwgR2l0QnJhbmNoLCBMYW5kbWFyayxcbiAgTGF5b3V0RGFzaGJvYXJkLCBMaXN0Q2hlY2tzLCBSYWRhciwgU2Nyb2xsVGV4dCwgU2hpZWxkLCBTcGFya2xlcywgVGFyZ2V0LFxuICBUcmVuZGluZ1VwLCBXcmVuY2gsIFNjYWxlLCBSb3V0ZSxcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHR5cGUgeyBNYWluVmlldyB9IGZyb20gXCIuLi9Ub3BOYXZcIjtcbmltcG9ydCB0eXBlIHsgTmF2R3JvdXAgfSBmcm9tIFwiLi9uYXZDb25maWdcIjtcblxuLyoqXG4gKiBFbmdpbmVlcmluZy1PUyBpbmZvcm1hdGlvbiBhcmNoaXRlY3R1cmUgKGZsYWcgZW9zLmNvbW1hbmQtY2VudGVyLXByZXZpZXcpLlxuICogT3JnYW5pemVkIGFyb3VuZCBvcGVyYXRvciBqb2JzLiBSb3V0ZSBjYXBhYmlsaXR5IG1ldGFkYXRhIGRlY2lkZXMgd2hpY2hcbiAqIGxpdmUsIHByZXZpZXcsIGFuZCBkZW1vIGRlc3RpbmF0aW9ucyBhcmUgZXhwb3NlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IEVPU19OQVZfR1JPVVBTOiBOYXZHcm91cFtdID0gW1xuICB7IGlkOiBcIm92ZXJ2aWV3XCIsIGxhYmVsOiBcIk92ZXJ2aWV3XCIsIGljb246IExheW91dERhc2hib2FyZCwgaXRlbXM6IFtcbiAgICB7IHZpZXc6IFwiY29tbWFuZC1jZW50ZXJcIiBhcyBNYWluVmlldywgbGFiZWw6IFwiQ29tbWFuZCBDZW50ZXJcIiwgaWNvbjogTGF5b3V0RGFzaGJvYXJkIH0sXG4gIF19LFxuICB7IGlkOiBcInN0cmF0ZWd5XCIsIGxhYmVsOiBcIlN0cmF0ZWd5XCIsIGljb246IFRhcmdldCwgaXRlbXM6IFtcbiAgICB7IHZpZXc6IFwibWlzc2lvbnNcIiBhcyBNYWluVmlldywgbGFiZWw6IFwiTWlzc2lvbnNcIiwgaWNvbjogVGFyZ2V0IH0sXG4gICAgeyB2aWV3OiBcImdvYWxzXCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIk9iamVjdGl2ZXNcIiwgaWNvbjogVHJlbmRpbmdVcCB9LFxuICBdfSxcbiAgeyBpZDogXCJkZWxpdmVyeVwiLCBsYWJlbDogXCJEZWxpdmVyeVwiLCBpY29uOiBXcmVuY2gsIGl0ZW1zOiBbXG4gICAgeyB2aWV3OiBcImNvbnRyb2wtd29yay1vcmRlcnNcIiBhcyBNYWluVmlldywgbGFiZWw6IFwiV29yayBPcmRlcnNcIiwgaWNvbjogQ2xpcGJvYXJkTGlzdCB9LFxuICAgIHsgdmlldzogXCJ0YXNrc1wiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJUYXNrc1wiLCBpY29uOiBMaXN0Q2hlY2tzIH0sXG4gICAgeyB2aWV3OiBcImZhY3RvcnlcIiBhcyBNYWluVmlldywgbGFiZWw6IFwiRmFjdG9yeSBCb2FyZFwiLCBpY29uOiBXcmVuY2ggfSxcbiAgICB7IHZpZXc6IFwidHJhY2UtaW5zcGVjdG9yXCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIkV4ZWN1dGlvblwiLCBpY29uOiBHaXRCcmFuY2ggfSxcbiAgICB7IHZpZXc6IFwiY29kZVwiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJQaXBlbGluZXNcIiwgaWNvbjogQ29nIH0sXG4gICAgeyB2aWV3OiBcImRhZ1wiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJUYXNrIEdyYXBoXCIsIGljb246IEdpdEJyYW5jaCB9LFxuICBdfSxcbiAgeyBpZDogXCJvcGVyYXRpb25zXCIsIGxhYmVsOiBcIk9wZXJhdGlvbnNcIiwgaWNvbjogR2F1Z2UsIGl0ZW1zOiBbXG4gICAgeyB2aWV3OiBcImFnZW50c1wiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJBZ2VudCBSZWdpc3RyeVwiLCBpY29uOiBCb3QgfSxcbiAgICB7IHZpZXc6IFwiYXRjXCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIlF1ZXVlXCIsIGljb246IFJhZGFyIH0sXG4gICAgeyB2aWV3OiBcImF1dG9tYXRpb25zXCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIkF1dG9tYXRpb25zXCIsIGljb246IFNwYXJrbGVzIH0sXG4gICAgeyB2aWV3OiBcImF1ZGl0XCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIkFwcHJvdmFscyAmIEF1ZGl0XCIsIGljb246IFNjcm9sbFRleHQgfSxcbiAgICB7IHZpZXc6IFwidGVsZW1ldHJ5XCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIkluY2lkZW50c1wiLCBpY29uOiBBY3Rpdml0eSB9LFxuICAgIHsgdmlldzogXCJhbmFseXRpY3NcIiBhcyBNYWluVmlldywgbGFiZWw6IFwiQ29zdFwiLCBpY29uOiBCYXJDaGFydDMgfSxcbiAgXX0sXG4gIHsgaWQ6IFwiaW50ZWxsaWdlbmNlXCIsIGxhYmVsOiBcIkludGVsbGlnZW5jZVwiLCBpY29uOiBCcmFpbiwgaXRlbXM6IFtcbiAgICB7IHZpZXc6IFwiaGFybmVzcy1sb29wc1wiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJMb29wIEVuZ2luZWVyaW5nXCIsIGljb246IEdpdEJyYW5jaCB9LFxuICAgIHsgdmlldzogXCJlZmZlY3RpdmVuZXNzXCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIkFJIEVmZmVjdGl2ZW5lc3NcIiwgaWNvbjogR2F1Z2UgfSxcbiAgICB7IHZpZXc6IFwiZmFjdG9yeS1oZWFsdGhcIiBhcyBNYWluVmlldywgbGFiZWw6IFwiRmFjdG9yeSBIZWFsdGhcIiwgaWNvbjogQ2hlY2tDaXJjbGUyIH0sXG4gICAgeyB2aWV3OiBcInJlYWRpbmVzc1wiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJFbnZpcm9ubWVudCBSZWFkaW5lc3NcIiwgaWNvbjogTGFuZG1hcmsgfSxcbiAgICB7IHZpZXc6IFwiZnJpY3Rpb25cIiBhcyBNYWluVmlldywgbGFiZWw6IFwiRnJpY3Rpb24gJiBXYXN0ZVwiLCBpY29uOiBBY3Rpdml0eSB9LFxuICAgIHsgdmlldzogXCJyZWNvbW1lbmRhdGlvbnNcIiBhcyBNYWluVmlldywgbGFiZWw6IFwiUmVjb21tZW5kYXRpb25zXCIsIGljb246IFNwYXJrbGVzIH0sXG4gICAgeyB2aWV3OiBcImRvc3NpZXJcIiBhcyBNYWluVmlldywgbGFiZWw6IFwiRXZpZGVuY2UgRG9zc2llcnNcIiwgaWNvbjogU2NhbGUgfSxcbiAgXX0sXG4gIHsgaWQ6IFwicXVhbGl0eS1hdXRvbWF0aW9uXCIsIGxhYmVsOiBcIlF1YWxpdHkgJiBBdXRvbWF0aW9uXCIsIGljb246IFNoaWVsZCwgaXRlbXM6IFtcbiAgICB7IHZpZXc6IFwiaGFybmVzcy1jb2RlLXJldmlldy13aXphcmRcIiBhcyBNYWluVmlldywgbGFiZWw6IFwiQ29kZSBSZXZpZXcgU2V0dXBcIiwgaWNvbjogQ2hlY2tDaXJjbGUyIH0sXG4gICAgeyB2aWV3OiBcImhhcm5lc3MtY2hhbmdlLXJldmlld1wiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJDaGFuZ2UgUmV2aWV3XCIsIGljb246IEZpbGVTZWFyY2ggfSxcbiAgICB7IHZpZXc6IFwicmVnaXN0cnktcnVuc1wiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJBZ2VudCBDb2RlIFF1YWxpdHlcIiwgaWNvbjogRmxhc2tDb25pY2FsIH0sXG4gICAgeyB2aWV3OiBcImhhcm5lc3MtbWV0YS1sb29wXCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIkltcHJvdmVtZW50IExvb3BcIiwgaWNvbjogR2l0QnJhbmNoIH0sXG4gIF19LFxuICB7IGlkOiBcImtub3dsZWRnZVwiLCBsYWJlbDogXCJLbm93bGVkZ2VcIiwgaWNvbjogQm9va09wZW4sIGl0ZW1zOiBbXG4gICAgeyB2aWV3OiBcInNraWxsc1wiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJDb250ZXh0IENhdGFsb2dcIiwgaWNvbjogU3BhcmtsZXMgfSxcbiAgICB7IHZpZXc6IFwicmVnaXN0cnktbGlmZWN5Y2xlXCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIkNvbnRleHQgQ0RMXCIsIGljb246IEJvb2tPcGVuIH0sXG4gICAgeyB2aWV3OiBcInJlZ2lzdHJ5LWV2YWx1YXRlXCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIkV2YWx1YXRlIFNraWxsXCIsIGljb246IEZsYXNrQ29uaWNhbCB9LFxuICAgIHsgdmlldzogXCJyZWdpc3RyeS1pbnZlbnRvcnlcIiBhcyBNYWluVmlldywgbGFiZWw6IFwiU2tpbGwgSW52ZW50b3J5XCIsIGljb246IENsaXBib2FyZExpc3QgfSxcbiAgICB7IHZpZXc6IFwicmVnaXN0cnktaW5zdGFsbGF0aW9uc1wiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJJbnN0YWxsYXRpb25zXCIsIGljb246IENsaXBib2FyZExpc3QgfSxcbiAgICB7IHZpZXc6IFwicmVnaXN0cnktcnVuc1wiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJFdmFsIFJ1bnNcIiwgaWNvbjogRmxhc2tDb25pY2FsIH0sXG4gICAgeyB2aWV3OiBcIm1lbW9yeVwiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJNZW1vcnlcIiwgaWNvbjogQnJhaW4gfSxcbiAgICB7IHZpZXc6IFwiZG9jc1wiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJEb2NzXCIsIGljb246IEJvb2tPcGVuIH0sXG4gIF19LFxuICB7IGlkOiBcImdvdmVybmFuY2VcIiwgbGFiZWw6IFwiR292ZXJuYW5jZVwiLCBpY29uOiBTaGllbGQsIGl0ZW1zOiBbXG4gICAgeyB2aWV3OiBcInBvbGljaWVzXCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIlBvbGljaWVzXCIsIGljb246IFNoaWVsZCB9LFxuICAgIHsgdmlldzogXCJpZGVudGl0eVwiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJJZGVudGl0aWVzXCIsIGljb246IENsaXBib2FyZExpc3QgfSxcbiAgICB7IHZpZXc6IFwiZGVwbG95bWVudHNcIiBhcyBNYWluVmlldywgbGFiZWw6IFwiRGVwbG95bWVudHNcIiwgaWNvbjogR2l0QnJhbmNoIH0sXG4gICAgeyB2aWV3OiBcInFjLXJ1bGVzZXRzXCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIlFDIFJ1bGVzZXRzXCIsIGljb246IExpc3RDaGVja3MgfSxcbiAgXX0sXG4gIHsgaWQ6IFwiYWRtaW5pc3RyYXRpb25cIiwgbGFiZWw6IFwiU2V0dGluZ3NcIiwgaWNvbjogQnVpbGRpbmcyLCBpdGVtczogW1xuICAgIHsgdmlldzogXCJwcm9qZWN0c1wiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJXb3Jrc3BhY2VzICYgUmVwb3NpdG9yaWVzXCIsIGljb246IEJ1aWxkaW5nMiB9LFxuICAgIHsgdmlldzogXCJtb2RlbC1yb3V0aW5nXCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIk1vZGVsIFJvdXRpbmdcIiwgaWNvbjogUm91dGUgfSxcbiAgICB7IHZpZXc6IFwiZ2F0ZXdheVwiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJHYXRld2F5XCIsIGljb246IENvZyB9LFxuICAgIHsgdmlldzogXCJzeXN0ZW1cIiBhcyBNYWluVmlldywgbGFiZWw6IFwiRGF0YWJhc2VcIiwgaWNvbjogQ29nIH0sXG4gIF19LFxuICB7IGlkOiBcImRldmVsb3Blci10b29sc1wiLCBsYWJlbDogXCJEZXZlbG9wZXIgVG9vbHNcIiwgaWNvbjogV3JlbmNoLCBpdGVtczogW1xuICAgIHsgdmlldzogXCJkZXNpZ24tc3lzdGVtXCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIkRlc2lnbiBETkFcIiwgaWNvbjogU3BhcmtsZXMgfSxcbiAgICB7IHZpZXc6IFwicmVjb3JkZXJcIiBhcyBNYWluVmlldywgbGFiZWw6IFwiUmVjb3JkZXJcIiwgaWNvbjogQWN0aXZpdHkgfSxcbiAgICB7IHZpZXc6IFwidGVzdC1nZW5lcmF0aW9uXCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIlRlc3QgR2VuZXJhdGlvblwiLCBpY29uOiBGbGFza0NvbmljYWwgfSxcbiAgICB7IHZpZXc6IFwiYXBpLWltcG9ydFwiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJBUEkgSW1wb3J0XCIsIGljb246IEZpbGVTZWFyY2ggfSxcbiAgXX0sXG4gIHsgaWQ6IFwibGFic1wiLCBsYWJlbDogXCJMYWJzXCIsIGljb246IEZsYXNrQ29uaWNhbCwgaXRlbXM6IFtcbiAgICB7IHZpZXc6IFwiYWdlbnQtY2F0YWxvZ1wiIGFzIE1haW5WaWV3LCBsYWJlbDogXCJBZ2VudCBDYXBhYmlsaXR5IENhdGFsb2dcIiwgaWNvbjogQm90IH0sXG4gICAgeyB2aWV3OiBcImZsYWt5LXN0ZXBzXCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIkZsYWt5IFN0ZXBzXCIsIGljb246IEFjdGl2aXR5IH0sXG4gICAgeyB2aWV3OiBcImdoZXJraW5cIiBhcyBNYWluVmlldywgbGFiZWw6IFwiR2hlcmtpbiBTdHVkaW9cIiwgaWNvbjogU2Nyb2xsVGV4dCB9LFxuICAgIHsgdmlldzogXCJjb2RlZ2VuXCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIkNvZGVHZW5cIiwgaWNvbjogQ29nIH0sXG4gICAgeyB2aWV3OiBcInBpcGVsaW5lXCIgYXMgTWFpblZpZXcsIGxhYmVsOiBcIkJ1aWxkIFBpcGVsaW5lXCIsIGljb246IENvZyB9LFxuICBdfSxcbl07XG4iXSwibWFwcGluZ3MiOiJBQUNBO0FBQUEsRUFDRTtBQUFBLEVBQVU7QUFBQSxFQUFXO0FBQUEsRUFBSztBQUFBLEVBQVU7QUFBQSxFQUFPO0FBQUEsRUFBVztBQUFBLEVBQ3REO0FBQUEsRUFBZTtBQUFBLEVBQUs7QUFBQSxFQUFZO0FBQUEsRUFBYztBQUFBLEVBQU87QUFBQSxFQUFXO0FBQUEsRUFDaEU7QUFBQSxFQUFpQjtBQUFBLEVBQVk7QUFBQSxFQUFPO0FBQUEsRUFBWTtBQUFBLEVBQVE7QUFBQSxFQUFVO0FBQUEsRUFDbEU7QUFBQSxFQUFZO0FBQUEsRUFBUTtBQUFBLEVBQU87QUFBQSxPQUN0QjtBQVNBLGFBQU0saUJBQTZCO0FBQUEsRUFDeEMsRUFBRSxJQUFJLFlBQVksT0FBTyxZQUFZLE1BQU0saUJBQWlCLE9BQU87QUFBQSxJQUNqRSxFQUFFLE1BQU0sa0JBQThCLE9BQU8sa0JBQWtCLE1BQU0sZ0JBQWdCO0FBQUEsRUFDdkYsRUFBQztBQUFBLEVBQ0QsRUFBRSxJQUFJLFlBQVksT0FBTyxZQUFZLE1BQU0sUUFBUSxPQUFPO0FBQUEsSUFDeEQsRUFBRSxNQUFNLFlBQXdCLE9BQU8sWUFBWSxNQUFNLE9BQU87QUFBQSxJQUNoRSxFQUFFLE1BQU0sU0FBcUIsT0FBTyxjQUFjLE1BQU0sV0FBVztBQUFBLEVBQ3JFLEVBQUM7QUFBQSxFQUNELEVBQUUsSUFBSSxZQUFZLE9BQU8sWUFBWSxNQUFNLFFBQVEsT0FBTztBQUFBLElBQ3hELEVBQUUsTUFBTSx1QkFBbUMsT0FBTyxlQUFlLE1BQU0sY0FBYztBQUFBLElBQ3JGLEVBQUUsTUFBTSxTQUFxQixPQUFPLFNBQVMsTUFBTSxXQUFXO0FBQUEsSUFDOUQsRUFBRSxNQUFNLFdBQXVCLE9BQU8saUJBQWlCLE1BQU0sT0FBTztBQUFBLElBQ3BFLEVBQUUsTUFBTSxtQkFBK0IsT0FBTyxhQUFhLE1BQU0sVUFBVTtBQUFBLElBQzNFLEVBQUUsTUFBTSxRQUFvQixPQUFPLGFBQWEsTUFBTSxJQUFJO0FBQUEsSUFDMUQsRUFBRSxNQUFNLE9BQW1CLE9BQU8sY0FBYyxNQUFNLFVBQVU7QUFBQSxFQUNsRSxFQUFDO0FBQUEsRUFDRCxFQUFFLElBQUksY0FBYyxPQUFPLGNBQWMsTUFBTSxPQUFPLE9BQU87QUFBQSxJQUMzRCxFQUFFLE1BQU0sVUFBc0IsT0FBTyxrQkFBa0IsTUFBTSxJQUFJO0FBQUEsSUFDakUsRUFBRSxNQUFNLE9BQW1CLE9BQU8sU0FBUyxNQUFNLE1BQU07QUFBQSxJQUN2RCxFQUFFLE1BQU0sZUFBMkIsT0FBTyxlQUFlLE1BQU0sU0FBUztBQUFBLElBQ3hFLEVBQUUsTUFBTSxTQUFxQixPQUFPLHFCQUFxQixNQUFNLFdBQVc7QUFBQSxJQUMxRSxFQUFFLE1BQU0sYUFBeUIsT0FBTyxhQUFhLE1BQU0sU0FBUztBQUFBLElBQ3BFLEVBQUUsTUFBTSxhQUF5QixPQUFPLFFBQVEsTUFBTSxVQUFVO0FBQUEsRUFDbEUsRUFBQztBQUFBLEVBQ0QsRUFBRSxJQUFJLGdCQUFnQixPQUFPLGdCQUFnQixNQUFNLE9BQU8sT0FBTztBQUFBLElBQy9ELEVBQUUsTUFBTSxpQkFBNkIsT0FBTyxvQkFBb0IsTUFBTSxVQUFVO0FBQUEsSUFDaEYsRUFBRSxNQUFNLGlCQUE2QixPQUFPLG9CQUFvQixNQUFNLE1BQU07QUFBQSxJQUM1RSxFQUFFLE1BQU0sa0JBQThCLE9BQU8sa0JBQWtCLE1BQU0sYUFBYTtBQUFBLElBQ2xGLEVBQUUsTUFBTSxhQUF5QixPQUFPLHlCQUF5QixNQUFNLFNBQVM7QUFBQSxJQUNoRixFQUFFLE1BQU0sWUFBd0IsT0FBTyxvQkFBb0IsTUFBTSxTQUFTO0FBQUEsSUFDMUUsRUFBRSxNQUFNLG1CQUErQixPQUFPLG1CQUFtQixNQUFNLFNBQVM7QUFBQSxJQUNoRixFQUFFLE1BQU0sV0FBdUIsT0FBTyxxQkFBcUIsTUFBTSxNQUFNO0FBQUEsRUFDekUsRUFBQztBQUFBLEVBQ0QsRUFBRSxJQUFJLHNCQUFzQixPQUFPLHdCQUF3QixNQUFNLFFBQVEsT0FBTztBQUFBLElBQzlFLEVBQUUsTUFBTSw4QkFBMEMsT0FBTyxxQkFBcUIsTUFBTSxhQUFhO0FBQUEsSUFDakcsRUFBRSxNQUFNLHlCQUFxQyxPQUFPLGlCQUFpQixNQUFNLFdBQVc7QUFBQSxJQUN0RixFQUFFLE1BQU0saUJBQTZCLE9BQU8sc0JBQXNCLE1BQU0sYUFBYTtBQUFBLElBQ3JGLEVBQUUsTUFBTSxxQkFBaUMsT0FBTyxvQkFBb0IsTUFBTSxVQUFVO0FBQUEsRUFDdEYsRUFBQztBQUFBLEVBQ0QsRUFBRSxJQUFJLGFBQWEsT0FBTyxhQUFhLE1BQU0sVUFBVSxPQUFPO0FBQUEsSUFDNUQsRUFBRSxNQUFNLFVBQXNCLE9BQU8sbUJBQW1CLE1BQU0sU0FBUztBQUFBLElBQ3ZFLEVBQUUsTUFBTSxzQkFBa0MsT0FBTyxlQUFlLE1BQU0sU0FBUztBQUFBLElBQy9FLEVBQUUsTUFBTSxxQkFBaUMsT0FBTyxrQkFBa0IsTUFBTSxhQUFhO0FBQUEsSUFDckYsRUFBRSxNQUFNLHNCQUFrQyxPQUFPLG1CQUFtQixNQUFNLGNBQWM7QUFBQSxJQUN4RixFQUFFLE1BQU0sMEJBQXNDLE9BQU8saUJBQWlCLE1BQU0sY0FBYztBQUFBLElBQzFGLEVBQUUsTUFBTSxpQkFBNkIsT0FBTyxhQUFhLE1BQU0sYUFBYTtBQUFBLElBQzVFLEVBQUUsTUFBTSxVQUFzQixPQUFPLFVBQVUsTUFBTSxNQUFNO0FBQUEsSUFDM0QsRUFBRSxNQUFNLFFBQW9CLE9BQU8sUUFBUSxNQUFNLFNBQVM7QUFBQSxFQUM1RCxFQUFDO0FBQUEsRUFDRCxFQUFFLElBQUksY0FBYyxPQUFPLGNBQWMsTUFBTSxRQUFRLE9BQU87QUFBQSxJQUM1RCxFQUFFLE1BQU0sWUFBd0IsT0FBTyxZQUFZLE1BQU0sT0FBTztBQUFBLElBQ2hFLEVBQUUsTUFBTSxZQUF3QixPQUFPLGNBQWMsTUFBTSxjQUFjO0FBQUEsSUFDekUsRUFBRSxNQUFNLGVBQTJCLE9BQU8sZUFBZSxNQUFNLFVBQVU7QUFBQSxJQUN6RSxFQUFFLE1BQU0sZUFBMkIsT0FBTyxlQUFlLE1BQU0sV0FBVztBQUFBLEVBQzVFLEVBQUM7QUFBQSxFQUNELEVBQUUsSUFBSSxrQkFBa0IsT0FBTyxZQUFZLE1BQU0sV0FBVyxPQUFPO0FBQUEsSUFDakUsRUFBRSxNQUFNLFlBQXdCLE9BQU8sNkJBQTZCLE1BQU0sVUFBVTtBQUFBLElBQ3BGLEVBQUUsTUFBTSxpQkFBNkIsT0FBTyxpQkFBaUIsTUFBTSxNQUFNO0FBQUEsSUFDekUsRUFBRSxNQUFNLFdBQXVCLE9BQU8sV0FBVyxNQUFNLElBQUk7QUFBQSxJQUMzRCxFQUFFLE1BQU0sVUFBc0IsT0FBTyxZQUFZLE1BQU0sSUFBSTtBQUFBLEVBQzdELEVBQUM7QUFBQSxFQUNELEVBQUUsSUFBSSxtQkFBbUIsT0FBTyxtQkFBbUIsTUFBTSxRQUFRLE9BQU87QUFBQSxJQUN0RSxFQUFFLE1BQU0saUJBQTZCLE9BQU8sY0FBYyxNQUFNLFNBQVM7QUFBQSxJQUN6RSxFQUFFLE1BQU0sWUFBd0IsT0FBTyxZQUFZLE1BQU0sU0FBUztBQUFBLElBQ2xFLEVBQUUsTUFBTSxtQkFBK0IsT0FBTyxtQkFBbUIsTUFBTSxhQUFhO0FBQUEsSUFDcEYsRUFBRSxNQUFNLGNBQTBCLE9BQU8sY0FBYyxNQUFNLFdBQVc7QUFBQSxFQUMxRSxFQUFDO0FBQUEsRUFDRCxFQUFFLElBQUksUUFBUSxPQUFPLFFBQVEsTUFBTSxjQUFjLE9BQU87QUFBQSxJQUN0RCxFQUFFLE1BQU0saUJBQTZCLE9BQU8sNEJBQTRCLE1BQU0sSUFBSTtBQUFBLElBQ2xGLEVBQUUsTUFBTSxlQUEyQixPQUFPLGVBQWUsTUFBTSxTQUFTO0FBQUEsSUFDeEUsRUFBRSxNQUFNLFdBQXVCLE9BQU8sa0JBQWtCLE1BQU0sV0FBVztBQUFBLElBQ3pFLEVBQUUsTUFBTSxXQUF1QixPQUFPLFdBQVcsTUFBTSxJQUFJO0FBQUEsSUFDM0QsRUFBRSxNQUFNLFlBQXdCLE9BQU8sa0JBQWtCLE1BQU0sSUFBSTtBQUFBLEVBQ3JFLEVBQUM7QUFDSDsiLCJuYW1lcyI6W119