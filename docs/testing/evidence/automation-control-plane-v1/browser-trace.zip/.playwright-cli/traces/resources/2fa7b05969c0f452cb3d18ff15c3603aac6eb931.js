import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/workspace/WorkspaceScopeProvider.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/workspace/WorkspaceScopeProvider.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const createContext = __vite__cjsImport3_react["createContext"]; const useContext = __vite__cjsImport3_react["useContext"]


;
const WorkspaceScopeContext = createContext(null);
export function WorkspaceScopeProvider({
  value,
  children
}) {
  return /* @__PURE__ */ jsxDEV(WorkspaceScopeContext.Provider, { value, children }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/workspace/WorkspaceScopeProvider.tsx",
    lineNumber: 45,
    columnNumber: 5
  }, this);
}
_c = WorkspaceScopeProvider;
export function useWorkspaceScope() {
  _s();
  const value = useContext(WorkspaceScopeContext);
  if (!value) {
    throw new Error("useWorkspaceScope must be used inside WorkspaceScopeProvider");
  }
  return value;
}
_s(useWorkspaceScope, "ksutO2/Ix3UeCrGnhyM+QEP505Y=");
var _c;
$RefreshReg$(_c, "WorkspaceScopeProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/workspace/WorkspaceScopeProvider.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/workspace/WorkspaceScopeProvider.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJJOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpCSjtBQUFBLEVBQ0VBO0FBQUFBLEVBQ0FDO0FBQUFBLE9BSUs7QUFTUCxNQUFNQyx3QkFBd0JGLGNBQTBDLElBQUk7QUFFckUsZ0JBQVNHLHVCQUF1QjtBQUFBLEVBQ3JDQztBQUFBQSxFQUNBQztBQUlGLEdBQWdCO0FBQ2QsU0FDRSx1QkFBQyxzQkFBc0IsVUFBdEIsRUFBK0IsT0FDN0JBLFlBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUo7QUFBQ0MsS0FaZUg7QUFjVCxnQkFBU0ksb0JBQXlDO0FBQUFDLEtBQUE7QUFDdkQsUUFBTUosUUFBUUgsV0FBV0MscUJBQXFCO0FBQzlDLE1BQUksQ0FBQ0UsT0FBTztBQUNWLFVBQU0sSUFBSUssTUFBTSw4REFBOEQ7QUFBQSxFQUNoRjtBQUNBLFNBQU9MO0FBQ1Q7QUFBQ0ksR0FOZUQsbUJBQWlCO0FBQUEsSUFBQUQ7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiY3JlYXRlQ29udGV4dCIsInVzZUNvbnRleHQiLCJXb3Jrc3BhY2VTY29wZUNvbnRleHQiLCJXb3Jrc3BhY2VTY29wZVByb3ZpZGVyIiwidmFsdWUiLCJjaGlsZHJlbiIsIl9jIiwidXNlV29ya3NwYWNlU2NvcGUiLCJfcyIsIkVycm9yIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIldvcmtzcGFjZVNjb3BlUHJvdmlkZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIGNyZWF0ZUNvbnRleHQsXG4gIHVzZUNvbnRleHQsXG4gIHR5cGUgRGlzcGF0Y2gsXG4gIHR5cGUgUmVhY3ROb2RlLFxuICB0eXBlIFNldFN0YXRlQWN0aW9uLFxufSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB0eXBlIHsgRG9jLCBJZCB9IGZyb20gXCIuLi8uLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9kYXRhTW9kZWxcIjtcblxuZXhwb3J0IGludGVyZmFjZSBXb3Jrc3BhY2VTY29wZVZhbHVlIHtcbiAgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+IHwgbnVsbDtcbiAgc2V0UHJvamVjdElkOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxJZDxcInByb2plY3RzXCI+IHwgbnVsbD4+O1xuICBwcm9qZWN0OiBEb2M8XCJwcm9qZWN0c1wiPiB8IG51bGwgfCB1bmRlZmluZWQ7XG59XG5cbmNvbnN0IFdvcmtzcGFjZVNjb3BlQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQ8V29ya3NwYWNlU2NvcGVWYWx1ZSB8IG51bGw+KG51bGwpO1xuXG5leHBvcnQgZnVuY3Rpb24gV29ya3NwYWNlU2NvcGVQcm92aWRlcih7XG4gIHZhbHVlLFxuICBjaGlsZHJlbixcbn06IHtcbiAgdmFsdWU6IFdvcmtzcGFjZVNjb3BlVmFsdWU7XG4gIGNoaWxkcmVuOiBSZWFjdE5vZGU7XG59KTogSlNYLkVsZW1lbnQge1xuICByZXR1cm4gKFxuICAgIDxXb3Jrc3BhY2VTY29wZUNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3ZhbHVlfT5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L1dvcmtzcGFjZVNjb3BlQ29udGV4dC5Qcm92aWRlcj5cbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZVdvcmtzcGFjZVNjb3BlKCk6IFdvcmtzcGFjZVNjb3BlVmFsdWUge1xuICBjb25zdCB2YWx1ZSA9IHVzZUNvbnRleHQoV29ya3NwYWNlU2NvcGVDb250ZXh0KTtcbiAgaWYgKCF2YWx1ZSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcInVzZVdvcmtzcGFjZVNjb3BlIG11c3QgYmUgdXNlZCBpbnNpZGUgV29ya3NwYWNlU2NvcGVQcm92aWRlclwiKTtcbiAgfVxuICByZXR1cm4gdmFsdWU7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy93b3Jrc3BhY2UvV29ya3NwYWNlU2NvcGVQcm92aWRlci50c3gifQ==