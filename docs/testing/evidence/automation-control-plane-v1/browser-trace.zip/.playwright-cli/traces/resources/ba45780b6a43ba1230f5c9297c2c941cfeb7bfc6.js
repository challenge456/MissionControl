import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/automations/AutomationReceipts.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationReceipts.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Badge } from "/src/components/ui/badge.tsx";
import { Card } from "/src/components/ui/card.tsx";
import { formatDate, statusTone } from "/src/automations/automationModel.ts";
export function AutomationReceipts({ receipts }) {
  if (receipts.length === 0) return /* @__PURE__ */ jsxDEV(Card, { className: "border-dashed p-8 text-center text-sm text-muted-foreground", children: "No Automation receipts yet. Missing evidence blocks reliability promotion." }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationReceipts.tsx",
    lineNumber: 25,
    columnNumber: 37
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "grid gap-3", children: receipts.map(
    (receipt) => /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-start justify-between gap-3", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-foreground", children: receipt.automationName ?? "Automation receipt" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationReceipts.tsx",
            lineNumber: 31,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-muted-foreground", children: [
            receipt.acceptanceCriterionId,
            " · ",
            receipt.verifier ?? "Unknown validator"
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationReceipts.tsx",
            lineNumber: 32,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationReceipts.tsx",
          lineNumber: 30,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", className: statusTone(receipt.status), children: receipt.status }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationReceipts.tsx",
          lineNumber: 34,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationReceipts.tsx",
        lineNumber: 29,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-3 grid gap-2 text-xs text-muted-foreground sm:grid-cols-3", children: [
        /* @__PURE__ */ jsxDEV("span", { children: [
          "Recorded: ",
          formatDate(receipt.recordedAt)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationReceipts.tsx",
          lineNumber: 37,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          "Evidence: ",
          receipt.evidenceLocation ?? receipt.artifactReference ?? "Incomplete"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationReceipts.tsx",
          lineNumber: 38,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: "Policy: independent receipt required" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationReceipts.tsx",
          lineNumber: 39,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationReceipts.tsx",
        lineNumber: 36,
        columnNumber: 9
      }, this)
    ] }, receipt._id, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationReceipts.tsx",
      lineNumber: 28,
      columnNumber: 5
    }, this)
  ) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationReceipts.tsx",
    lineNumber: 26,
    columnNumber: 10
  }, this);
}
_c = AutomationReceipts;
var _c;
$RefreshReg$(_c, "AutomationReceipts");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationReceipts.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationReceipts.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS29DOzs7Ozs7Ozs7Ozs7Ozs7O0FBTHBDLFNBQVNBLGFBQWE7QUFDdEIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxZQUFZQyxrQkFBa0I7QUFFaEMsZ0JBQVNDLG1CQUFtQixFQUFFQyxTQUE4QixHQUFHO0FBQ3BFLE1BQUlBLFNBQVNDLFdBQVcsRUFBRyxRQUFPLHVCQUFDLFFBQUssV0FBVSwrREFBOEQsMEZBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBd0o7QUFDMUwsU0FBTyx1QkFBQyxTQUFJLFdBQVUsY0FDbkJELG1CQUFTRTtBQUFBQSxJQUFJLENBQUNDLFlBQ2IsdUJBQUMsUUFBdUIsV0FBVSxPQUNoQztBQUFBLDZCQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsK0JBQStCQSxrQkFBUUMsa0JBQWtCLHdCQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RjtBQUFBLFVBQzdGLHVCQUFDLE9BQUUsV0FBVSxzQ0FBc0NEO0FBQUFBLG9CQUFRRTtBQUFBQSxZQUFzQjtBQUFBLFlBQUlGLFFBQVFHLFlBQVk7QUFBQSxlQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2SDtBQUFBLGFBRi9IO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBTSxTQUFRLFdBQVUsV0FBV1IsV0FBV0ssUUFBUUksTUFBTSxHQUFJSixrQkFBUUksVUFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRjtBQUFBLFdBTGxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGdFQUNiO0FBQUEsK0JBQUMsVUFBSztBQUFBO0FBQUEsVUFBV1YsV0FBV00sUUFBUUssVUFBVTtBQUFBLGFBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Q7QUFBQSxRQUNoRCx1QkFBQyxVQUFLO0FBQUE7QUFBQSxVQUFXTCxRQUFRTSxvQkFBb0JOLFFBQVFPLHFCQUFxQjtBQUFBLGFBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUY7QUFBQSxRQUN2Rix1QkFBQyxVQUFLLG9EQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEM7QUFBQSxXQUg1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQVpTUCxRQUFRUSxLQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxFQUNELEtBaEJJO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpQlA7QUFDRjtBQUFDQyxLQXBCZWI7QUFBa0IsSUFBQWE7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQmFkZ2UiLCJDYXJkIiwiZm9ybWF0RGF0ZSIsInN0YXR1c1RvbmUiLCJBdXRvbWF0aW9uUmVjZWlwdHMiLCJyZWNlaXB0cyIsImxlbmd0aCIsIm1hcCIsInJlY2VpcHQiLCJhdXRvbWF0aW9uTmFtZSIsImFjY2VwdGFuY2VDcml0ZXJpb25JZCIsInZlcmlmaWVyIiwic3RhdHVzIiwicmVjb3JkZWRBdCIsImV2aWRlbmNlTG9jYXRpb24iLCJhcnRpZmFjdFJlZmVyZW5jZSIsIl9pZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkF1dG9tYXRpb25SZWNlaXB0cy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQmFkZ2UgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2JhZGdlXCI7XG5pbXBvcnQgeyBDYXJkIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9jYXJkXCI7XG5pbXBvcnQgeyBmb3JtYXREYXRlLCBzdGF0dXNUb25lIH0gZnJvbSBcIi4vYXV0b21hdGlvbk1vZGVsXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBBdXRvbWF0aW9uUmVjZWlwdHMoeyByZWNlaXB0cyB9OiB7IHJlY2VpcHRzOiBhbnlbXSB9KSB7XG4gIGlmIChyZWNlaXB0cy5sZW5ndGggPT09IDApIHJldHVybiA8Q2FyZCBjbGFzc05hbWU9XCJib3JkZXItZGFzaGVkIHAtOCB0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPk5vIEF1dG9tYXRpb24gcmVjZWlwdHMgeWV0LiBNaXNzaW5nIGV2aWRlbmNlIGJsb2NrcyByZWxpYWJpbGl0eSBwcm9tb3Rpb24uPC9DYXJkPjtcbiAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtM1wiPlxuICAgIHtyZWNlaXB0cy5tYXAoKHJlY2VpcHQpID0+IChcbiAgICAgIDxDYXJkIGtleT17cmVjZWlwdC5faWR9IGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZm9yZWdyb3VuZFwiPntyZWNlaXB0LmF1dG9tYXRpb25OYW1lID8/IFwiQXV0b21hdGlvbiByZWNlaXB0XCJ9PC9kaXY+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e3JlY2VpcHQuYWNjZXB0YW5jZUNyaXRlcmlvbklkfSDCtyB7cmVjZWlwdC52ZXJpZmllciA/PyBcIlVua25vd24gdmFsaWRhdG9yXCJ9PC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwib3V0bGluZVwiIGNsYXNzTmFtZT17c3RhdHVzVG9uZShyZWNlaXB0LnN0YXR1cyl9PntyZWNlaXB0LnN0YXR1c308L0JhZGdlPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGdyaWQgZ2FwLTIgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmQgc206Z3JpZC1jb2xzLTNcIj5cbiAgICAgICAgICA8c3Bhbj5SZWNvcmRlZDoge2Zvcm1hdERhdGUocmVjZWlwdC5yZWNvcmRlZEF0KX08L3NwYW4+XG4gICAgICAgICAgPHNwYW4+RXZpZGVuY2U6IHtyZWNlaXB0LmV2aWRlbmNlTG9jYXRpb24gPz8gcmVjZWlwdC5hcnRpZmFjdFJlZmVyZW5jZSA/PyBcIkluY29tcGxldGVcIn08L3NwYW4+XG4gICAgICAgICAgPHNwYW4+UG9saWN5OiBpbmRlcGVuZGVudCByZWNlaXB0IHJlcXVpcmVkPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZD5cbiAgICApKX1cbiAgPC9kaXY+O1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvYXV0b21hdGlvbnMvQXV0b21hdGlvblJlY2VpcHRzLnRzeCJ9