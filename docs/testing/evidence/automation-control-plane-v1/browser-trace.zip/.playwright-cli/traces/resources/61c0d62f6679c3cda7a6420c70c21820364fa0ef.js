import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TaskboardStats.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TaskboardStats.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { cn } from "/src/lib/utils.ts";
function startOfWeek(date) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  d.setDate(diff);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}
export function TaskboardStats({ projectId, className }) {
  _s();
  const tasks = useQuery(api.tasks.listAll, projectId ? { projectId } : {});
  if (tasks === void 0) return null;
  const weekStart = startOfWeek(/* @__PURE__ */ new Date());
  const thisWeek = tasks.filter(
    (t) => t._creationTime >= weekStart
  ).length;
  const inProgress = tasks.filter(
    (t) => t.status === "IN_PROGRESS" || t.status === "ASSIGNED" || t.status === "REVIEW" || t.status === "NEEDS_APPROVAL"
  ).length;
  const total = tasks.length;
  const done = tasks.filter((t) => t.status === "DONE").length;
  const completionPct = total > 0 ? Math.round(done / total * 100) : 0;
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: cn(
        "flex shrink-0 items-center gap-4 overflow-x-auto flex-nowrap px-4 py-2 border-b border-line bg-surface-1 text-[12.5px]",
        className
      ),
      children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-ink-secondary", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-ink", children: thisWeek }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TaskboardStats.tsx",
            lineNumber: 67,
            columnNumber: 9
          }, this),
          " This week"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TaskboardStats.tsx",
          lineNumber: 66,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-ink-secondary", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-ink", children: inProgress }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TaskboardStats.tsx",
            lineNumber: 70,
            columnNumber: 9
          }, this),
          " In progress"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TaskboardStats.tsx",
          lineNumber: 69,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-ink-secondary", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-ink", children: total }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TaskboardStats.tsx",
            lineNumber: 73,
            columnNumber: 9
          }, this),
          " Total"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TaskboardStats.tsx",
          lineNumber: 72,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-ink-secondary", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-ink", children: [
            completionPct,
            "%"
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TaskboardStats.tsx",
            lineNumber: 76,
            columnNumber: 9
          }, this),
          " Completion"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TaskboardStats.tsx",
          lineNumber: 75,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TaskboardStats.tsx",
      lineNumber: 60,
      columnNumber: 5
    },
    this
  );
}
_s(TaskboardStats, "f7waUesUkwRNKpYZRDjePBgTSho=", false, function() {
  return [useQuery];
});
_c = TaskboardStats;
var _c;
$RefreshReg$(_c, "TaskboardStats");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TaskboardStats.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TaskboardStats.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0NROzs7Ozs7Ozs7Ozs7Ozs7OztBQS9DUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsV0FBVztBQUVwQixTQUFTQyxVQUFVO0FBT25CLFNBQVNDLFlBQVlDLE1BQW9CO0FBQ3ZDLFFBQU1DLElBQUksSUFBSUMsS0FBS0YsSUFBSTtBQUN2QixRQUFNRyxNQUFNRixFQUFFRyxPQUFPO0FBQ3JCLFFBQU1DLE9BQU9KLEVBQUVLLFFBQVEsSUFBSUgsT0FBT0EsUUFBUSxJQUFJLEtBQUs7QUFDbkRGLElBQUVNLFFBQVFGLElBQUk7QUFDZEosSUFBRU8sU0FBUyxHQUFHLEdBQUcsR0FBRyxDQUFDO0FBQ3JCLFNBQU9QLEVBQUVRLFFBQVE7QUFDbkI7QUFFTyxnQkFBU0MsZUFBZSxFQUFFQyxXQUFXQyxVQUErQixHQUFHO0FBQUFDLEtBQUE7QUFDNUUsUUFBTUMsUUFBUWxCLFNBQVNDLElBQUlpQixNQUFNQyxTQUFTSixZQUFZLEVBQUVBLFVBQVUsSUFBSSxDQUFDLENBQUM7QUFFeEUsTUFBSUcsVUFBVUUsT0FBVyxRQUFPO0FBRWhDLFFBQU1DLFlBQVlsQixZQUFZLG9CQUFJRyxLQUFLLENBQUM7QUFDeEMsUUFBTWdCLFdBQVdKLE1BQU1LO0FBQUFBLElBQ3JCLENBQUNDLE1BQU9BLEVBQWlDQyxpQkFBaUJKO0FBQUFBLEVBQzVELEVBQUVLO0FBQ0YsUUFBTUMsYUFBYVQsTUFBTUs7QUFBQUEsSUFDdkIsQ0FBQ0MsTUFDQ0EsRUFBRUksV0FBVyxpQkFDYkosRUFBRUksV0FBVyxjQUNiSixFQUFFSSxXQUFXLFlBQ2JKLEVBQUVJLFdBQVc7QUFBQSxFQUNqQixFQUFFRjtBQUNGLFFBQU1HLFFBQVFYLE1BQU1RO0FBQ3BCLFFBQU1JLE9BQU9aLE1BQU1LLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRUksV0FBVyxNQUFNLEVBQUVGO0FBQ3RELFFBQU1LLGdCQUFnQkYsUUFBUSxJQUFJRyxLQUFLQyxNQUFPSCxPQUFPRCxRQUFTLEdBQUcsSUFBSTtBQUVyRSxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxXQUFXM0I7QUFBQUEsUUFDVDtBQUFBLFFBQ0FjO0FBQUFBLE1BQ0Y7QUFBQSxNQUVBO0FBQUEsK0JBQUMsVUFBSyxXQUFVLHNCQUNkO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHdCQUF3Qk0sc0JBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsVUFBTztBQUFBLGFBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsVUFBSyxXQUFVLHNCQUNkO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHdCQUF3Qkssd0JBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsVUFBTztBQUFBLGFBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsVUFBSyxXQUFVLHNCQUNkO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHdCQUF3QkUsbUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThDO0FBQUEsVUFBTztBQUFBLGFBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsVUFBSyxXQUFVLHNCQUNkO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHdCQUF3QkU7QUFBQUE7QUFBQUEsWUFBYztBQUFBLGVBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVEO0FBQUEsVUFBTztBQUFBLGFBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBO0FBQUE7QUFBQSxJQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFrQkE7QUFFSjtBQUFDZCxHQXpDZUgsZ0JBQWM7QUFBQSxVQUNkZCxRQUFRO0FBQUE7QUFBQSxLQURSYztBQUFjLElBQUFvQjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VRdWVyeSIsImFwaSIsImNuIiwic3RhcnRPZldlZWsiLCJkYXRlIiwiZCIsIkRhdGUiLCJkYXkiLCJnZXREYXkiLCJkaWZmIiwiZ2V0RGF0ZSIsInNldERhdGUiLCJzZXRIb3VycyIsImdldFRpbWUiLCJUYXNrYm9hcmRTdGF0cyIsInByb2plY3RJZCIsImNsYXNzTmFtZSIsIl9zIiwidGFza3MiLCJsaXN0QWxsIiwidW5kZWZpbmVkIiwid2Vla1N0YXJ0IiwidGhpc1dlZWsiLCJmaWx0ZXIiLCJ0IiwiX2NyZWF0aW9uVGltZSIsImxlbmd0aCIsImluUHJvZ3Jlc3MiLCJzdGF0dXMiLCJ0b3RhbCIsImRvbmUiLCJjb21wbGV0aW9uUGN0IiwiTWF0aCIsInJvdW5kIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVGFza2JvYXJkU3RhdHMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVF1ZXJ5IH0gZnJvbSBcImNvbnZleC9yZWFjdFwiO1xuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2FwaVwiO1xuaW1wb3J0IHR5cGUgeyBJZCB9IGZyb20gXCIuLi8uLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9kYXRhTW9kZWxcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5cbmludGVyZmFjZSBUYXNrYm9hcmRTdGF0c1Byb3BzIHtcbiAgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+IHwgbnVsbDtcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xufVxuXG5mdW5jdGlvbiBzdGFydE9mV2VlayhkYXRlOiBEYXRlKTogbnVtYmVyIHtcbiAgY29uc3QgZCA9IG5ldyBEYXRlKGRhdGUpO1xuICBjb25zdCBkYXkgPSBkLmdldERheSgpO1xuICBjb25zdCBkaWZmID0gZC5nZXREYXRlKCkgLSBkYXkgKyAoZGF5ID09PSAwID8gLTYgOiAxKTtcbiAgZC5zZXREYXRlKGRpZmYpO1xuICBkLnNldEhvdXJzKDAsIDAsIDAsIDApO1xuICByZXR1cm4gZC5nZXRUaW1lKCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBUYXNrYm9hcmRTdGF0cyh7IHByb2plY3RJZCwgY2xhc3NOYW1lIH06IFRhc2tib2FyZFN0YXRzUHJvcHMpIHtcbiAgY29uc3QgdGFza3MgPSB1c2VRdWVyeShhcGkudGFza3MubGlzdEFsbCwgcHJvamVjdElkID8geyBwcm9qZWN0SWQgfSA6IHt9KTtcblxuICBpZiAodGFza3MgPT09IHVuZGVmaW5lZCkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3Qgd2Vla1N0YXJ0ID0gc3RhcnRPZldlZWsobmV3IERhdGUoKSk7XG4gIGNvbnN0IHRoaXNXZWVrID0gdGFza3MuZmlsdGVyKFxuICAgICh0KSA9PiAodCBhcyB7IF9jcmVhdGlvblRpbWU/OiBudW1iZXIgfSkuX2NyZWF0aW9uVGltZSA+PSB3ZWVrU3RhcnRcbiAgKS5sZW5ndGg7XG4gIGNvbnN0IGluUHJvZ3Jlc3MgPSB0YXNrcy5maWx0ZXIoXG4gICAgKHQpID0+XG4gICAgICB0LnN0YXR1cyA9PT0gXCJJTl9QUk9HUkVTU1wiIHx8XG4gICAgICB0LnN0YXR1cyA9PT0gXCJBU1NJR05FRFwiIHx8XG4gICAgICB0LnN0YXR1cyA9PT0gXCJSRVZJRVdcIiB8fFxuICAgICAgdC5zdGF0dXMgPT09IFwiTkVFRFNfQVBQUk9WQUxcIlxuICApLmxlbmd0aDtcbiAgY29uc3QgdG90YWwgPSB0YXNrcy5sZW5ndGg7XG4gIGNvbnN0IGRvbmUgPSB0YXNrcy5maWx0ZXIoKHQpID0+IHQuc3RhdHVzID09PSBcIkRPTkVcIikubGVuZ3RoO1xuICBjb25zdCBjb21wbGV0aW9uUGN0ID0gdG90YWwgPiAwID8gTWF0aC5yb3VuZCgoZG9uZSAvIHRvdGFsKSAqIDEwMCkgOiAwO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJmbGV4IHNocmluay0wIGl0ZW1zLWNlbnRlciBnYXAtNCBvdmVyZmxvdy14LWF1dG8gZmxleC1ub3dyYXAgcHgtNCBweS0yIGJvcmRlci1iIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMSB0ZXh0LVsxMi41cHhdXCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICA+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWluay1zZWNvbmRhcnlcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1pbmtcIj57dGhpc1dlZWt9PC9zcGFuPiBUaGlzIHdlZWtcbiAgICAgIDwvc3Bhbj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtaW5rLXNlY29uZGFyeVwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWlua1wiPntpblByb2dyZXNzfTwvc3Bhbj4gSW4gcHJvZ3Jlc3NcbiAgICAgIDwvc3Bhbj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtaW5rLXNlY29uZGFyeVwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWlua1wiPnt0b3RhbH08L3NwYW4+IFRvdGFsXG4gICAgICA8L3NwYW4+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWluay1zZWNvbmRhcnlcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1pbmtcIj57Y29tcGxldGlvblBjdH0lPC9zcGFuPiBDb21wbGV0aW9uXG4gICAgICA8L3NwYW4+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9jb21wb25lbnRzL1Rhc2tib2FyZFN0YXRzLnRzeCJ9