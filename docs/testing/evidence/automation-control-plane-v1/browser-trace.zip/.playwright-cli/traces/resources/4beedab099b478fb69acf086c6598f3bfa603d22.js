import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/AgentDetailFlyout.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { X } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { cn } from "/src/lib/utils.ts";
import { StatusBadge } from "/src/components/factory/badges.tsx";
const FLYOUT_WIDTH = 360;
function DetailSection({ title, children }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "border-b border-line py-3 last:border-b-0", children: [
    /* @__PURE__ */ jsxDEV("h3", { className: "text-[11.5px] font-medium uppercase tracking-[0.06em] text-ink-muted mb-2", children: title }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
      lineNumber: 33,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2.5", children }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
      lineNumber: 36,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
    lineNumber: 32,
    columnNumber: 5
  }, this);
}
_c = DetailSection;
function DetailRow({
  label,
  value,
  mono,
  valueClassName
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-0.5", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] font-medium uppercase tracking-[0.06em] text-ink-muted", children: label }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
      lineNumber: 54,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "span",
      {
        className: cn(
          "break-all min-w-0 text-[13px] text-ink",
          mono && "font-mono text-[12px]",
          valueClassName
        ),
        children: value
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
        lineNumber: 55,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
    lineNumber: 53,
    columnNumber: 5
  }, this);
}
_c2 = DetailRow;
const FLYOUT_PANEL_CLASS = "fixed top-0 right-0 bottom-0 z-[60] flex flex-col bg-surface-1 border-l border-line max-w-[100vw] animate-in slide-in-from-right duration-200";
export function AgentDetailFlyout({
  agentId,
  onClose,
  onEdit
}) {
  _s();
  const panelRef = useRef(null);
  const returnFocusRef = useRef(null);
  useEffect(() => {
    returnFocusRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    panelRef.current?.focus({ preventScroll: true });
    return () => returnFocusRef.current?.focus({ preventScroll: true });
  }, []);
  useEffect(() => {
    const onKeyDown = (event) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [onClose]);
  const agent = useQuery(api.agents.get, { agentId });
  if (!agent) {
    return /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "fixed inset-0 z-[55] bg-black/40",
          "aria-hidden": true,
          onClick: onClose
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
          lineNumber: 102,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "aside",
        {
          ref: panelRef,
          className: FLYOUT_PANEL_CLASS,
          style: { width: FLYOUT_WIDTH, minWidth: 320 },
          role: "dialog",
          "aria-modal": "true",
          "aria-label": "Agent detail",
          tabIndex: -1,
          children: /* @__PURE__ */ jsxDEV("div", { className: "p-4 flex items-center justify-between border-b border-line", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-ink-muted text-[13.5px]", children: "Loading…" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
              lineNumber: 117,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: onClose,
                className: "p-1.5 rounded-md text-ink-muted hover:text-ink hover:bg-surface-2 transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                "aria-label": "Close",
                children: /* @__PURE__ */ jsxDEV(X, { className: "h-5 w-5" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                  lineNumber: 124,
                  columnNumber: 15
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                lineNumber: 118,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
            lineNumber: 116,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
          lineNumber: 107,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
      lineNumber: 101,
      columnNumber: 7
    }, this);
  }
  const meta = agent.metadata || {};
  const roleLabel = agent.role === "LEAD" ? "LEAD" : agent.role === "SPECIALIST" ? "Spc" : agent.role === "INTERN" ? "Int" : agent.role;
  const isActive = agent.status === "ACTIVE";
  const daily = agent.budgetDaily ?? 0;
  const perRun = agent.budgetPerRun ?? 0;
  const spent = agent.spendToday ?? 0;
  const remaining = Math.max(0, daily - spent);
  const ratio = daily > 0 ? spent / daily : 0;
  const ratioClass = ratio > 0.9 ? "text-err" : ratio > 0.7 ? "text-warn" : "text-ok";
  const hasContact = meta.email || meta.telegram || meta.whatsapp || meta.discord;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "fixed inset-0 z-[55] bg-black/40",
        "aria-hidden": true,
        onClick: onClose
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
        lineNumber: 155,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "aside",
      {
        ref: panelRef,
        className: FLYOUT_PANEL_CLASS,
        style: { width: FLYOUT_WIDTH, minWidth: 320 },
        role: "dialog",
        "aria-modal": "true",
        "aria-label": `${agent.name} details`,
        tabIndex: -1,
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "shrink-0 p-4 border-b border-line flex items-start justify-between gap-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 min-w-0", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-line bg-surface-2 text-lg text-ink", children: agent.emoji || agent.name.charAt(0).toUpperCase() }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                lineNumber: 171,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-[15px] font-semibold text-ink truncate", children: agent.name }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                  lineNumber: 175,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 mt-1 flex-wrap", children: [
                  /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", children: roleLabel }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                    lineNumber: 177,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV(StatusBadge, { tone: isActive ? "success" : "warning", children: agent.status }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                    lineNumber: 178,
                    columnNumber: 15
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                  lineNumber: 176,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                lineNumber: 174,
                columnNumber: 11
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
              lineNumber: 170,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: onClose,
                className: "p-1.5 rounded-md text-ink-muted hover:text-ink hover:bg-surface-2 transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring shrink-0",
                "aria-label": "Close agent detail",
                children: /* @__PURE__ */ jsxDEV(X, { className: "h-5 w-5" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                  lineNumber: 190,
                  columnNumber: 11
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                lineNumber: 184,
                columnNumber: 9
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
            lineNumber: 169,
            columnNumber: 7
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-y-auto p-4 space-y-0", children: [
            /* @__PURE__ */ jsxDEV(DetailSection, { title: "Identity", children: [
              /* @__PURE__ */ jsxDEV(DetailRow, { label: "Agent ID", value: agent._id, mono: true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                lineNumber: 196,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(DetailRow, { label: "Model", value: meta.model || "Claude Opus 4" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                lineNumber: 197,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(DetailRow, { label: "Workspace", value: agent.workspacePath || "—", mono: true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                lineNumber: 198,
                columnNumber: 11
              }, this),
              agent.soulVersionHash && /* @__PURE__ */ jsxDEV(DetailRow, { label: "Soul Version", value: agent.soulVersionHash, mono: true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                lineNumber: 200,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
              lineNumber: 195,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV(DetailSection, { title: "Contact Channels", children: hasContact ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              meta.email && /* @__PURE__ */ jsxDEV(DetailRow, { label: "Email", value: meta.email, mono: true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                lineNumber: 207,
                columnNumber: 40
              }, this),
              meta.telegram && /* @__PURE__ */ jsxDEV(DetailRow, { label: "Telegram", value: meta.telegram }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                lineNumber: 208,
                columnNumber: 43
              }, this),
              meta.whatsapp && /* @__PURE__ */ jsxDEV(DetailRow, { label: "WhatsApp", value: meta.whatsapp }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                lineNumber: 209,
                columnNumber: 43
              }, this),
              meta.discord && /* @__PURE__ */ jsxDEV(DetailRow, { label: "Discord", value: meta.discord }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                lineNumber: 210,
                columnNumber: 42
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
              lineNumber: 206,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-ink-muted", children: "No contact channels configured" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
              lineNumber: 213,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
              lineNumber: 204,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV(DetailSection, { title: "Configuration", children: [
              agent.allowedTaskTypes && agent.allowedTaskTypes.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11.5px] font-medium uppercase tracking-[0.06em] text-ink-muted mb-1", children: "Allowed Task Types" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                  lineNumber: 220,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1.5", children: agent.allowedTaskTypes.map(
                  (t) => /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", children: t }, t, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                    lineNumber: 223,
                    columnNumber: 17
                  }, this)
                ) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                  lineNumber: 221,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                lineNumber: 219,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(
                DetailRow,
                {
                  label: "Can Spawn Sub-Agents",
                  value: agent.canSpawn ? "Yes" : "No"
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                  lineNumber: 230,
                  columnNumber: 11
                },
                this
              ),
              agent.canSpawn && /* @__PURE__ */ jsxDEV(DetailRow, { label: "Max Sub-Agents", value: String(agent.maxSubAgents) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                lineNumber: 235,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
              lineNumber: 217,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV(DetailSection, { title: "Budget", children: [
              /* @__PURE__ */ jsxDEV(DetailRow, { label: "Daily Budget", value: `$${daily.toFixed(2)}`, mono: true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                lineNumber: 240,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(DetailRow, { label: "Per-Run Budget", value: `$${perRun.toFixed(2)}`, mono: true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                lineNumber: 241,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(DetailRow, { label: "Spent Today", value: `$${spent.toFixed(2)}`, mono: true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                lineNumber: 242,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(
                DetailRow,
                {
                  label: "Remaining",
                  value: `$${remaining.toFixed(2)}`,
                  mono: true,
                  valueClassName: ratioClass
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
                  lineNumber: 243,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
              lineNumber: 239,
              columnNumber: 9
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
            lineNumber: 194,
            columnNumber: 7
          }, this),
          onEdit && /* @__PURE__ */ jsxDEV("div", { className: "shrink-0 p-4 border-t border-line flex items-center gap-2", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => onEdit(agentId),
              className: "h-9 px-3 rounded-lg text-[13px] font-medium bg-act text-act-ink hover:opacity-90 transition-opacity duration-150",
              children: "Edit"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
              lineNumber: 255,
              columnNumber: 11
            },
            this
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
            lineNumber: 254,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
        lineNumber: 160,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx",
    lineNumber: 154,
    columnNumber: 5
  }, this);
}
_s(AgentDetailFlyout, "wvYmln+Ns+XC9CTaMQBZjtX1rsY=", false, function() {
  return [useQuery];
});
_c3 = AgentDetailFlyout;
var _c, _c2, _c3;
$RefreshReg$(_c, "DetailSection");
$RefreshReg$(_c2, "DetailRow");
$RefreshReg$(_c3, "AgentDetailFlyout");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDetailFlyout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYU0sU0FvRUEsVUFwRUE7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBYk4sU0FBU0EsV0FBV0MsY0FBYztBQUNsQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsV0FBVztBQUVwQixTQUFTQyxTQUFTO0FBQ2xCLFNBQVNDLFVBQVU7QUFDbkIsU0FBU0MsbUJBQW1CO0FBRTVCLE1BQU1DLGVBQWU7QUFFckIsU0FBU0MsY0FBYyxFQUFFQyxPQUFPQyxTQUF1RCxHQUFHO0FBQ3hGLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDZDQUNiO0FBQUEsMkJBQUMsUUFBRyxXQUFVLDZFQUNYRCxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSx5QkFBeUJDLFlBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUQ7QUFBQSxPQUpuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFFSjtBQUFDQyxLQVRRSDtBQVdULFNBQVNJLFVBQVU7QUFBQSxFQUNqQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFNRixHQUFHO0FBQ0QsU0FDRSx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSwyQkFBQyxVQUFLLFdBQVUsd0VBQXdFSCxtQkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RjtBQUFBLElBQzlGO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXUjtBQUFBQSxVQUNUO0FBQUEsVUFDQVUsUUFBUTtBQUFBLFVBQ1JDO0FBQUFBLFFBQ0Y7QUFBQSxRQUVDRjtBQUFBQTtBQUFBQSxNQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVFBO0FBQUEsT0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBV0E7QUFFSjtBQUFDRyxNQXpCUUw7QUEyQlQsTUFBTU0scUJBQ0o7QUFFSyxnQkFBU0Msa0JBQWtCO0FBQUEsRUFDaENDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBTUYsR0FBRztBQUFBQyxLQUFBO0FBQ0QsUUFBTUMsV0FBV3ZCLE9BQTJCLElBQUk7QUFDaEQsUUFBTXdCLGlCQUFpQnhCLE9BQTJCLElBQUk7QUFFdERELFlBQVUsTUFBTTtBQUNkeUIsbUJBQWVDLFVBQVVDLFNBQVNDLHlCQUF5QkMsY0FBY0YsU0FBU0MsZ0JBQWdCO0FBQ2xHSixhQUFTRSxTQUFTSSxNQUFNLEVBQUVDLGVBQWUsS0FBSyxDQUFDO0FBQy9DLFdBQU8sTUFBTU4sZUFBZUMsU0FBU0ksTUFBTSxFQUFFQyxlQUFlLEtBQUssQ0FBQztBQUFBLEVBQ3BFLEdBQUcsRUFBRTtBQUVML0IsWUFBVSxNQUFNO0FBQ2QsVUFBTWdDLFlBQVlBLENBQUNDLFVBQXlCO0FBQzFDLFVBQUlBLE1BQU1DLFFBQVEsU0FBVWIsU0FBUTtBQUFBLElBQ3RDO0FBQ0FjLFdBQU9DLGlCQUFpQixXQUFXSixTQUFTO0FBQzVDLFdBQU8sTUFBTUcsT0FBT0Usb0JBQW9CLFdBQVdMLFNBQVM7QUFBQSxFQUM5RCxHQUFHLENBQUNYLE9BQU8sQ0FBQztBQUVaLFFBQU1pQixRQUFRcEMsU0FBU0MsSUFBSW9DLE9BQU9DLEtBQUssRUFBRXBCLFFBQVEsQ0FBQztBQUNsRCxNQUFJLENBQUNrQixPQUFPO0FBQ1YsV0FDRSxtQ0FDRTtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFVO0FBQUEsVUFDVjtBQUFBLFVBQ0EsU0FBU2pCO0FBQUFBO0FBQUFBLFFBSFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR21CO0FBQUEsTUFFbkI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLEtBQUtHO0FBQUFBLFVBQ0wsV0FBV047QUFBQUEsVUFDWCxPQUFPLEVBQUV1QixPQUFPbEMsY0FBY21DLFVBQVUsSUFBSTtBQUFBLFVBQzVDLE1BQUs7QUFBQSxVQUNMLGNBQVc7QUFBQSxVQUNYLGNBQVc7QUFBQSxVQUNYLFVBQVU7QUFBQSxVQUVWLGlDQUFDLFNBQUksV0FBVSw4REFDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSxnQ0FBK0Isd0JBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVEO0FBQUEsWUFDdkQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU3JCO0FBQUFBLGdCQUNULFdBQVU7QUFBQSxnQkFDVixjQUFXO0FBQUEsZ0JBRVgsaUNBQUMsS0FBRSxXQUFVLGFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0I7QUFBQTtBQUFBLGNBTnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUE7QUFBQSxRQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFvQkE7QUFBQSxTQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkJBO0FBQUEsRUFFSjtBQUVBLFFBQU1zQixPQUFRTCxNQUFNTSxZQUFtRCxDQUFDO0FBQ3hFLFFBQU1DLFlBQ0pQLE1BQU1RLFNBQVMsU0FDWCxTQUNBUixNQUFNUSxTQUFTLGVBQ2IsUUFDQVIsTUFBTVEsU0FBUyxXQUNiLFFBQ0FSLE1BQU1RO0FBQ2hCLFFBQU1DLFdBQVdULE1BQU1VLFdBQVc7QUFDbEMsUUFBTUMsUUFBUVgsTUFBTVksZUFBZTtBQUNuQyxRQUFNQyxTQUFTYixNQUFNYyxnQkFBZ0I7QUFDckMsUUFBTUMsUUFBUWYsTUFBTWdCLGNBQWM7QUFDbEMsUUFBTUMsWUFBWUMsS0FBS0MsSUFBSSxHQUFHUixRQUFRSSxLQUFLO0FBQzNDLFFBQU1LLFFBQVFULFFBQVEsSUFBSUksUUFBUUosUUFBUTtBQUMxQyxRQUFNVSxhQUNKRCxRQUFRLE1BQU0sYUFBYUEsUUFBUSxNQUFNLGNBQWM7QUFFekQsUUFBTUUsYUFDSGpCLEtBQUtrQixTQUFxQmxCLEtBQUttQixZQUF3Qm5CLEtBQUtvQixZQUF3QnBCLEtBQUtxQjtBQUU1RixTQUNFLG1DQUNFO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVU7QUFBQSxRQUNWO0FBQUEsUUFDQSxTQUFTM0M7QUFBQUE7QUFBQUEsTUFIWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHbUI7QUFBQSxJQUVuQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsS0FBS0c7QUFBQUEsUUFDTCxXQUFXTjtBQUFBQSxRQUNYLE9BQU8sRUFBRXVCLE9BQU9sQyxjQUFjbUMsVUFBVSxJQUFJO0FBQUEsUUFDNUMsTUFBSztBQUFBLFFBQ0wsY0FBVztBQUFBLFFBQ1gsY0FBWSxHQUFHSixNQUFNMkIsSUFBSTtBQUFBLFFBQ3pCLFVBQVU7QUFBQSxRQUVaO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDRFQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLG1DQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLG1IQUNaM0IsZ0JBQU00QixTQUFTNUIsTUFBTTJCLEtBQUtFLE9BQU8sQ0FBQyxFQUFFQyxZQUFZLEtBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLCtDQUErQzlCLGdCQUFNMkIsUUFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0U7QUFBQSxnQkFDeEUsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEseUNBQUMsZUFBWSxNQUFLLFdBQVdwQix1QkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUM7QUFBQSxrQkFDdkMsdUJBQUMsZUFBWSxNQUFNRSxXQUFXLFlBQVksV0FDdkNULGdCQUFNVSxVQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGlCQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMzQjtBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBQ1YsY0FBVztBQUFBLGdCQUVYLGlDQUFDLEtBQUUsV0FBVSxhQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNCO0FBQUE7QUFBQSxjQU54QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQTtBQUFBLGVBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUJBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsd0NBQ2I7QUFBQSxtQ0FBQyxpQkFBYyxPQUFNLFlBQ25CO0FBQUEscUNBQUMsYUFBVSxPQUFNLFlBQVcsT0FBT2lCLE1BQU0rQixLQUFLLE1BQUksUUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0Q7QUFBQSxjQUNsRCx1QkFBQyxhQUFVLE9BQU0sU0FBUSxPQUFRMUIsS0FBSzJCLFNBQW9CLG1CQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRTtBQUFBLGNBQzFFLHVCQUFDLGFBQVUsT0FBTSxhQUFZLE9BQU9oQyxNQUFNaUMsaUJBQWlCLEtBQUssTUFBSSxRQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRTtBQUFBLGNBQ25FakMsTUFBTWtDLG1CQUNMLHVCQUFDLGFBQVUsT0FBTSxnQkFBZSxPQUFPbEMsTUFBTWtDLGlCQUFpQixNQUFJLFFBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtFO0FBQUEsaUJBTHRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUVBLHVCQUFDLGlCQUFjLE9BQU0sb0JBQ2xCWix1QkFDQyxtQ0FDSWpCO0FBQUFBLG1CQUFLa0IsU0FBb0IsdUJBQUMsYUFBVSxPQUFNLFNBQVEsT0FBT2xCLEtBQUtrQixPQUFpQixNQUFJLFFBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBEO0FBQUEsY0FDbkZsQixLQUFLbUIsWUFBdUIsdUJBQUMsYUFBVSxPQUFNLFlBQVcsT0FBT25CLEtBQUttQixZQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRDtBQUFBLGNBQ3ZGbkIsS0FBS29CLFlBQXVCLHVCQUFDLGFBQVUsT0FBTSxZQUFXLE9BQU9wQixLQUFLb0IsWUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkQ7QUFBQSxjQUN2RnBCLEtBQUtxQixXQUFzQix1QkFBQyxhQUFVLE9BQU0sV0FBVSxPQUFPckIsS0FBS3FCLFdBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlEO0FBQUEsaUJBSnhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0EsSUFFQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLDhDQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RSxLQVQ1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsWUFFQSx1QkFBQyxpQkFBYyxPQUFNLGlCQUNsQjFCO0FBQUFBLG9CQUFNbUMsb0JBQW9CbkMsTUFBTW1DLGlCQUFpQkMsU0FBUyxLQUN6RCx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSw2RUFBNEUsa0NBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZHO0FBQUEsZ0JBQzdHLHVCQUFDLFNBQUksV0FBVSwwQkFDWnBDLGdCQUFNbUMsaUJBQWlCRTtBQUFBQSxrQkFBSSxDQUFDQyxNQUMzQix1QkFBQyxlQUFvQixNQUFLLFdBQ3ZCQSxlQURlQSxHQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU1BO0FBQUEsbUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGNBRUY7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTTtBQUFBLGtCQUNOLE9BQU90QyxNQUFNdUMsV0FBVyxRQUFRO0FBQUE7QUFBQSxnQkFGbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRXVDO0FBQUEsY0FFdEN2QyxNQUFNdUMsWUFDTCx1QkFBQyxhQUFVLE9BQU0sa0JBQWlCLE9BQU9DLE9BQU94QyxNQUFNeUMsWUFBWSxLQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRTtBQUFBLGlCQWxCeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxZQUVBLHVCQUFDLGlCQUFjLE9BQU0sVUFDbkI7QUFBQSxxQ0FBQyxhQUFVLE9BQU0sZ0JBQWUsT0FBTyxJQUFJOUIsTUFBTStCLFFBQVEsQ0FBQyxDQUFDLElBQUksTUFBSSxRQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRTtBQUFBLGNBQ25FLHVCQUFDLGFBQVUsT0FBTSxrQkFBaUIsT0FBTyxJQUFJN0IsT0FBTzZCLFFBQVEsQ0FBQyxDQUFDLElBQUksTUFBSSxRQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRTtBQUFBLGNBQ3RFLHVCQUFDLGFBQVUsT0FBTSxlQUFjLE9BQU8sSUFBSTNCLE1BQU0yQixRQUFRLENBQUMsQ0FBQyxJQUFJLE1BQUksUUFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0U7QUFBQSxjQUNsRTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFNO0FBQUEsa0JBQ04sT0FBTyxJQUFJekIsVUFBVXlCLFFBQVEsQ0FBQyxDQUFDO0FBQUEsa0JBQy9CO0FBQUEsa0JBQ0EsZ0JBQWdCckI7QUFBQUE7QUFBQUEsZ0JBSmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUk2QjtBQUFBLGlCQVIvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsZUF2REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3REE7QUFBQSxVQUdDckMsVUFDQyx1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTUEsT0FBT0YsT0FBTztBQUFBLGNBQzdCLFdBQVU7QUFBQSxjQUFrSDtBQUFBO0FBQUEsWUFIOUg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUE7QUFBQTtBQUFBLE1BdEdGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXdHRjtBQUFBLE9BOUdBO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErR0E7QUFFSjtBQUFDRyxHQXBNZUosbUJBQWlCO0FBQUEsVUEyQmpCakIsUUFBUTtBQUFBO0FBQUEsTUEzQlJpQjtBQUFpQixJQUFBUixJQUFBTSxLQUFBZ0U7QUFBQSxhQUFBdEUsSUFBQTtBQUFBLGFBQUFNLEtBQUE7QUFBQSxhQUFBZ0UsS0FBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVF1ZXJ5IiwiYXBpIiwiWCIsImNuIiwiU3RhdHVzQmFkZ2UiLCJGTFlPVVRfV0lEVEgiLCJEZXRhaWxTZWN0aW9uIiwidGl0bGUiLCJjaGlsZHJlbiIsIl9jIiwiRGV0YWlsUm93IiwibGFiZWwiLCJ2YWx1ZSIsIm1vbm8iLCJ2YWx1ZUNsYXNzTmFtZSIsIl9jMiIsIkZMWU9VVF9QQU5FTF9DTEFTUyIsIkFnZW50RGV0YWlsRmx5b3V0IiwiYWdlbnRJZCIsIm9uQ2xvc2UiLCJvbkVkaXQiLCJfcyIsInBhbmVsUmVmIiwicmV0dXJuRm9jdXNSZWYiLCJjdXJyZW50IiwiZG9jdW1lbnQiLCJhY3RpdmVFbGVtZW50IiwiSFRNTEVsZW1lbnQiLCJmb2N1cyIsInByZXZlbnRTY3JvbGwiLCJvbktleURvd24iLCJldmVudCIsImtleSIsIndpbmRvdyIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiYWdlbnQiLCJhZ2VudHMiLCJnZXQiLCJ3aWR0aCIsIm1pbldpZHRoIiwibWV0YSIsIm1ldGFkYXRhIiwicm9sZUxhYmVsIiwicm9sZSIsImlzQWN0aXZlIiwic3RhdHVzIiwiZGFpbHkiLCJidWRnZXREYWlseSIsInBlclJ1biIsImJ1ZGdldFBlclJ1biIsInNwZW50Iiwic3BlbmRUb2RheSIsInJlbWFpbmluZyIsIk1hdGgiLCJtYXgiLCJyYXRpbyIsInJhdGlvQ2xhc3MiLCJoYXNDb250YWN0IiwiZW1haWwiLCJ0ZWxlZ3JhbSIsIndoYXRzYXBwIiwiZGlzY29yZCIsIm5hbWUiLCJlbW9qaSIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwiX2lkIiwibW9kZWwiLCJ3b3Jrc3BhY2VQYXRoIiwic291bFZlcnNpb25IYXNoIiwiYWxsb3dlZFRhc2tUeXBlcyIsImxlbmd0aCIsIm1hcCIsInQiLCJjYW5TcGF3biIsIlN0cmluZyIsIm1heFN1YkFnZW50cyIsInRvRml4ZWQiLCJfYzMiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQWdlbnREZXRhaWxGbHlvdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB0eXBlIHsgSWQgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvZGF0YU1vZGVsXCI7XG5pbXBvcnQgeyBYIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcbmltcG9ydCB7IFN0YXR1c0JhZGdlIH0gZnJvbSBcIi4vY29tcG9uZW50cy9mYWN0b3J5L2JhZGdlc1wiO1xuXG5jb25zdCBGTFlPVVRfV0lEVEggPSAzNjA7XG5cbmZ1bmN0aW9uIERldGFpbFNlY3Rpb24oeyB0aXRsZSwgY2hpbGRyZW4gfTogeyB0aXRsZTogc3RyaW5nOyBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1saW5lIHB5LTMgbGFzdDpib3JkZXItYi0wXCI+XG4gICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMDZlbV0gdGV4dC1pbmstbXV0ZWQgbWItMlwiPlxuICAgICAgICB7dGl0bGV9XG4gICAgICA8L2gzPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0yLjVcIj57Y2hpbGRyZW59PC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmZ1bmN0aW9uIERldGFpbFJvdyh7XG4gIGxhYmVsLFxuICB2YWx1ZSxcbiAgbW9ubyxcbiAgdmFsdWVDbGFzc05hbWUsXG59OiB7XG4gIGxhYmVsOiBzdHJpbmc7XG4gIHZhbHVlOiBzdHJpbmc7XG4gIG1vbm8/OiBib29sZWFuO1xuICB2YWx1ZUNsYXNzTmFtZT86IHN0cmluZztcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTAuNVwiPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMDZlbV0gdGV4dC1pbmstbXV0ZWRcIj57bGFiZWx9PC9zcGFuPlxuICAgICAgPHNwYW5cbiAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICBcImJyZWFrLWFsbCBtaW4tdy0wIHRleHQtWzEzcHhdIHRleHQtaW5rXCIsXG4gICAgICAgICAgbW9ubyAmJiBcImZvbnQtbW9ubyB0ZXh0LVsxMnB4XVwiLFxuICAgICAgICAgIHZhbHVlQ2xhc3NOYW1lXG4gICAgICAgICl9XG4gICAgICA+XG4gICAgICAgIHt2YWx1ZX1cbiAgICAgIDwvc3Bhbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuY29uc3QgRkxZT1VUX1BBTkVMX0NMQVNTID1cbiAgXCJmaXhlZCB0b3AtMCByaWdodC0wIGJvdHRvbS0wIHotWzYwXSBmbGV4IGZsZXgtY29sIGJnLXN1cmZhY2UtMSBib3JkZXItbCBib3JkZXItbGluZSBtYXgtdy1bMTAwdnddIGFuaW1hdGUtaW4gc2xpZGUtaW4tZnJvbS1yaWdodCBkdXJhdGlvbi0yMDBcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIEFnZW50RGV0YWlsRmx5b3V0KHtcbiAgYWdlbnRJZCxcbiAgb25DbG9zZSxcbiAgb25FZGl0LFxufToge1xuICBhZ2VudElkOiBJZDxcImFnZW50c1wiPjtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbiAgLyoqIENhbGxlZCB3aGVuIHRoZSB1c2VyIGNsaWNrcyBFZGl0IC0tIGhvc3QgY2FuIG5hdmlnYXRlIHRvIE9yZyB2aWV3ICovXG4gIG9uRWRpdD86IChhZ2VudElkOiBJZDxcImFnZW50c1wiPikgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgcGFuZWxSZWYgPSB1c2VSZWY8SFRNTEVsZW1lbnQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgcmV0dXJuRm9jdXNSZWYgPSB1c2VSZWY8SFRNTEVsZW1lbnQgfCBudWxsPihudWxsKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJldHVybkZvY3VzUmVmLmN1cnJlbnQgPSBkb2N1bWVudC5hY3RpdmVFbGVtZW50IGluc3RhbmNlb2YgSFRNTEVsZW1lbnQgPyBkb2N1bWVudC5hY3RpdmVFbGVtZW50IDogbnVsbDtcbiAgICBwYW5lbFJlZi5jdXJyZW50Py5mb2N1cyh7IHByZXZlbnRTY3JvbGw6IHRydWUgfSk7XG4gICAgcmV0dXJuICgpID0+IHJldHVybkZvY3VzUmVmLmN1cnJlbnQ/LmZvY3VzKHsgcHJldmVudFNjcm9sbDogdHJ1ZSB9KTtcbiAgfSwgW10pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3Qgb25LZXlEb3duID0gKGV2ZW50OiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBpZiAoZXZlbnQua2V5ID09PSBcIkVzY2FwZVwiKSBvbkNsb3NlKCk7XG4gICAgfTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgb25LZXlEb3duKTtcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIG9uS2V5RG93bik7XG4gIH0sIFtvbkNsb3NlXSk7XG5cbiAgY29uc3QgYWdlbnQgPSB1c2VRdWVyeShhcGkuYWdlbnRzLmdldCwgeyBhZ2VudElkIH0pO1xuICBpZiAoIWFnZW50KSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDw+XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzU1XSBiZy1ibGFjay80MFwiXG4gICAgICAgICAgYXJpYS1oaWRkZW5cbiAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAvPlxuICAgICAgICA8YXNpZGVcbiAgICAgICAgICByZWY9e3BhbmVsUmVmfVxuICAgICAgICAgIGNsYXNzTmFtZT17RkxZT1VUX1BBTkVMX0NMQVNTfVxuICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBGTFlPVVRfV0lEVEgsIG1pbldpZHRoOiAzMjAgfX1cbiAgICAgICAgICByb2xlPVwiZGlhbG9nXCJcbiAgICAgICAgICBhcmlhLW1vZGFsPVwidHJ1ZVwiXG4gICAgICAgICAgYXJpYS1sYWJlbD1cIkFnZW50IGRldGFpbFwiXG4gICAgICAgICAgdGFiSW5kZXg9ey0xfVxuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1saW5lXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWluay1tdXRlZCB0ZXh0LVsxMy41cHhdXCI+TG9hZGluZ+KApjwvc3Bhbj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHJvdW5kZWQtbWQgdGV4dC1pbmstbXV0ZWQgaG92ZXI6dGV4dC1pbmsgaG92ZXI6Ymctc3VyZmFjZS0yIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBmb2N1cy12aXNpYmxlOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctcmluZ1wiXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJDbG9zZVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvYXNpZGU+XG4gICAgICA8Lz5cbiAgICApO1xuICB9XG5cbiAgY29uc3QgbWV0YSA9IChhZ2VudC5tZXRhZGF0YSBhcyBSZWNvcmQ8c3RyaW5nLCBzdHJpbmcgfCB1bmRlZmluZWQ+KSB8fCB7fTtcbiAgY29uc3Qgcm9sZUxhYmVsID1cbiAgICBhZ2VudC5yb2xlID09PSBcIkxFQURcIlxuICAgICAgPyBcIkxFQURcIlxuICAgICAgOiBhZ2VudC5yb2xlID09PSBcIlNQRUNJQUxJU1RcIlxuICAgICAgICA/IFwiU3BjXCJcbiAgICAgICAgOiBhZ2VudC5yb2xlID09PSBcIklOVEVSTlwiXG4gICAgICAgICAgPyBcIkludFwiXG4gICAgICAgICAgOiBhZ2VudC5yb2xlO1xuICBjb25zdCBpc0FjdGl2ZSA9IGFnZW50LnN0YXR1cyA9PT0gXCJBQ1RJVkVcIjtcbiAgY29uc3QgZGFpbHkgPSBhZ2VudC5idWRnZXREYWlseSA/PyAwO1xuICBjb25zdCBwZXJSdW4gPSBhZ2VudC5idWRnZXRQZXJSdW4gPz8gMDtcbiAgY29uc3Qgc3BlbnQgPSBhZ2VudC5zcGVuZFRvZGF5ID8/IDA7XG4gIGNvbnN0IHJlbWFpbmluZyA9IE1hdGgubWF4KDAsIGRhaWx5IC0gc3BlbnQpO1xuICBjb25zdCByYXRpbyA9IGRhaWx5ID4gMCA/IHNwZW50IC8gZGFpbHkgOiAwO1xuICBjb25zdCByYXRpb0NsYXNzID1cbiAgICByYXRpbyA+IDAuOSA/IFwidGV4dC1lcnJcIiA6IHJhdGlvID4gMC43ID8gXCJ0ZXh0LXdhcm5cIiA6IFwidGV4dC1va1wiO1xuXG4gIGNvbnN0IGhhc0NvbnRhY3QgPVxuICAgIChtZXRhLmVtYWlsIGFzIHN0cmluZykgfHwgKG1ldGEudGVsZWdyYW0gYXMgc3RyaW5nKSB8fCAobWV0YS53aGF0c2FwcCBhcyBzdHJpbmcpIHx8IChtZXRhLmRpc2NvcmQgYXMgc3RyaW5nKTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bNTVdIGJnLWJsYWNrLzQwXCJcbiAgICAgICAgYXJpYS1oaWRkZW5cbiAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgIC8+XG4gICAgICA8YXNpZGVcbiAgICAgICAgcmVmPXtwYW5lbFJlZn1cbiAgICAgICAgY2xhc3NOYW1lPXtGTFlPVVRfUEFORUxfQ0xBU1N9XG4gICAgICAgIHN0eWxlPXt7IHdpZHRoOiBGTFlPVVRfV0lEVEgsIG1pbldpZHRoOiAzMjAgfX1cbiAgICAgICAgcm9sZT1cImRpYWxvZ1wiXG4gICAgICAgIGFyaWEtbW9kYWw9XCJ0cnVlXCJcbiAgICAgICAgYXJpYS1sYWJlbD17YCR7YWdlbnQubmFtZX0gZGV0YWlsc2B9XG4gICAgICAgIHRhYkluZGV4PXstMX1cbiAgICAgID5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2hyaW5rLTAgcC00IGJvcmRlci1iIGJvcmRlci1saW5lIGZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWluLXctMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTExIHctMTEgc2hyaW5rLTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMiB0ZXh0LWxnIHRleHQtaW5rXCI+XG4gICAgICAgICAgICB7YWdlbnQuZW1vamkgfHwgYWdlbnQubmFtZS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTBcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtaW5rIHRydW5jYXRlXCI+e2FnZW50Lm5hbWV9PC9oMj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBtdC0xIGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgICA8U3RhdHVzQmFkZ2UgdG9uZT1cIm5ldXRyYWxcIj57cm9sZUxhYmVsfTwvU3RhdHVzQmFkZ2U+XG4gICAgICAgICAgICAgIDxTdGF0dXNCYWRnZSB0b25lPXtpc0FjdGl2ZSA/IFwic3VjY2Vzc1wiIDogXCJ3YXJuaW5nXCJ9PlxuICAgICAgICAgICAgICAgIHthZ2VudC5zdGF0dXN9XG4gICAgICAgICAgICAgIDwvU3RhdHVzQmFkZ2U+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHJvdW5kZWQtbWQgdGV4dC1pbmstbXV0ZWQgaG92ZXI6dGV4dC1pbmsgaG92ZXI6Ymctc3VyZmFjZS0yIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBmb2N1cy12aXNpYmxlOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctcmluZyBzaHJpbmstMFwiXG4gICAgICAgICAgYXJpYS1sYWJlbD1cIkNsb3NlIGFnZW50IGRldGFpbFwiXG4gICAgICAgID5cbiAgICAgICAgICA8WCBjbGFzc05hbWU9XCJoLTUgdy01XCIgLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHAtNCBzcGFjZS15LTBcIj5cbiAgICAgICAgPERldGFpbFNlY3Rpb24gdGl0bGU9XCJJZGVudGl0eVwiPlxuICAgICAgICAgIDxEZXRhaWxSb3cgbGFiZWw9XCJBZ2VudCBJRFwiIHZhbHVlPXthZ2VudC5faWR9IG1vbm8gLz5cbiAgICAgICAgICA8RGV0YWlsUm93IGxhYmVsPVwiTW9kZWxcIiB2YWx1ZT17KG1ldGEubW9kZWwgYXMgc3RyaW5nKSB8fCBcIkNsYXVkZSBPcHVzIDRcIn0gLz5cbiAgICAgICAgICA8RGV0YWlsUm93IGxhYmVsPVwiV29ya3NwYWNlXCIgdmFsdWU9e2FnZW50LndvcmtzcGFjZVBhdGggfHwgXCLigJRcIn0gbW9ubyAvPlxuICAgICAgICAgIHthZ2VudC5zb3VsVmVyc2lvbkhhc2ggJiYgKFxuICAgICAgICAgICAgPERldGFpbFJvdyBsYWJlbD1cIlNvdWwgVmVyc2lvblwiIHZhbHVlPXthZ2VudC5zb3VsVmVyc2lvbkhhc2h9IG1vbm8gLz5cbiAgICAgICAgICApfVxuICAgICAgICA8L0RldGFpbFNlY3Rpb24+XG5cbiAgICAgICAgPERldGFpbFNlY3Rpb24gdGl0bGU9XCJDb250YWN0IENoYW5uZWxzXCI+XG4gICAgICAgICAge2hhc0NvbnRhY3QgPyAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICB7KG1ldGEuZW1haWwgYXMgc3RyaW5nKSAmJiA8RGV0YWlsUm93IGxhYmVsPVwiRW1haWxcIiB2YWx1ZT17bWV0YS5lbWFpbCBhcyBzdHJpbmd9IG1vbm8gLz59XG4gICAgICAgICAgICAgIHsobWV0YS50ZWxlZ3JhbSBhcyBzdHJpbmcpICYmIDxEZXRhaWxSb3cgbGFiZWw9XCJUZWxlZ3JhbVwiIHZhbHVlPXttZXRhLnRlbGVncmFtIGFzIHN0cmluZ30gLz59XG4gICAgICAgICAgICAgIHsobWV0YS53aGF0c2FwcCBhcyBzdHJpbmcpICYmIDxEZXRhaWxSb3cgbGFiZWw9XCJXaGF0c0FwcFwiIHZhbHVlPXttZXRhLndoYXRzYXBwIGFzIHN0cmluZ30gLz59XG4gICAgICAgICAgICAgIHsobWV0YS5kaXNjb3JkIGFzIHN0cmluZykgJiYgPERldGFpbFJvdyBsYWJlbD1cIkRpc2NvcmRcIiB2YWx1ZT17bWV0YS5kaXNjb3JkIGFzIHN0cmluZ30gLz59XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1pbmstbXV0ZWRcIj5ObyBjb250YWN0IGNoYW5uZWxzIGNvbmZpZ3VyZWQ8L3A+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9EZXRhaWxTZWN0aW9uPlxuXG4gICAgICAgIDxEZXRhaWxTZWN0aW9uIHRpdGxlPVwiQ29uZmlndXJhdGlvblwiPlxuICAgICAgICAgIHthZ2VudC5hbGxvd2VkVGFza1R5cGVzICYmIGFnZW50LmFsbG93ZWRUYXNrVHlwZXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMS41cHhdIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy1bMC4wNmVtXSB0ZXh0LWluay1tdXRlZCBtYi0xXCI+QWxsb3dlZCBUYXNrIFR5cGVzPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIHthZ2VudC5hbGxvd2VkVGFza1R5cGVzLm1hcCgodDogc3RyaW5nKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8U3RhdHVzQmFkZ2Uga2V5PXt0fSB0b25lPVwibmV1dHJhbFwiPlxuICAgICAgICAgICAgICAgICAgICB7dH1cbiAgICAgICAgICAgICAgICAgIDwvU3RhdHVzQmFkZ2U+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgICA8RGV0YWlsUm93XG4gICAgICAgICAgICBsYWJlbD1cIkNhbiBTcGF3biBTdWItQWdlbnRzXCJcbiAgICAgICAgICAgIHZhbHVlPXthZ2VudC5jYW5TcGF3biA/IFwiWWVzXCIgOiBcIk5vXCJ9XG4gICAgICAgICAgLz5cbiAgICAgICAgICB7YWdlbnQuY2FuU3Bhd24gJiYgKFxuICAgICAgICAgICAgPERldGFpbFJvdyBsYWJlbD1cIk1heCBTdWItQWdlbnRzXCIgdmFsdWU9e1N0cmluZyhhZ2VudC5tYXhTdWJBZ2VudHMpfSAvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvRGV0YWlsU2VjdGlvbj5cblxuICAgICAgICA8RGV0YWlsU2VjdGlvbiB0aXRsZT1cIkJ1ZGdldFwiPlxuICAgICAgICAgIDxEZXRhaWxSb3cgbGFiZWw9XCJEYWlseSBCdWRnZXRcIiB2YWx1ZT17YCQke2RhaWx5LnRvRml4ZWQoMil9YH0gbW9ubyAvPlxuICAgICAgICAgIDxEZXRhaWxSb3cgbGFiZWw9XCJQZXItUnVuIEJ1ZGdldFwiIHZhbHVlPXtgJCR7cGVyUnVuLnRvRml4ZWQoMil9YH0gbW9ubyAvPlxuICAgICAgICAgIDxEZXRhaWxSb3cgbGFiZWw9XCJTcGVudCBUb2RheVwiIHZhbHVlPXtgJCR7c3BlbnQudG9GaXhlZCgyKX1gfSBtb25vIC8+XG4gICAgICAgICAgPERldGFpbFJvd1xuICAgICAgICAgICAgbGFiZWw9XCJSZW1haW5pbmdcIlxuICAgICAgICAgICAgdmFsdWU9e2AkJHtyZW1haW5pbmcudG9GaXhlZCgyKX1gfVxuICAgICAgICAgICAgbW9ub1xuICAgICAgICAgICAgdmFsdWVDbGFzc05hbWU9e3JhdGlvQ2xhc3N9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9EZXRhaWxTZWN0aW9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBGb290ZXIgd2l0aCBFZGl0IGFjdGlvbiAqL31cbiAgICAgIHtvbkVkaXQgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNocmluay0wIHAtNCBib3JkZXItdCBib3JkZXItbGluZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25FZGl0KGFnZW50SWQpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC05IHB4LTMgcm91bmRlZC1sZyB0ZXh0LVsxM3B4XSBmb250LW1lZGl1bSBiZy1hY3QgdGV4dC1hY3QtaW5rIGhvdmVyOm9wYWNpdHktOTAgdHJhbnNpdGlvbi1vcGFjaXR5IGR1cmF0aW9uLTE1MFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgRWRpdFxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9hc2lkZT5cbiAgICA8Lz5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL0FnZW50RGV0YWlsRmx5b3V0LnRzeCJ9