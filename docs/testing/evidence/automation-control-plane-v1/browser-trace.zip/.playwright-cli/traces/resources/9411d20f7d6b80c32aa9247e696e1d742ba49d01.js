import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ExportReportButton.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ExportReportButton.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
export function ExportReportButton({ taskId }) {
  _s();
  const reportData = useQuery(api.reports.generateIncidentReport, { taskId });
  const handleExport = () => {
    if (!reportData) return;
    const blob = new Blob([reportData.report], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `incident-report-${taskId.slice(-6)}-${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      onClick: handleExport,
      disabled: !reportData,
      style: {
        padding: "8px 16px",
        background: reportData ? "#3b82f6" : "#334155",
        border: "none",
        borderRadius: "6px",
        color: "white",
        fontSize: "14px",
        fontWeight: 500,
        cursor: reportData ? "pointer" : "not-allowed",
        display: "flex",
        alignItems: "center",
        gap: "8px"
      },
      children: "Export Report"
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ExportReportButton.tsx",
      lineNumber: 44,
      columnNumber: 5
    },
    this
  );
}
_s(ExportReportButton, "pX0kBCjtctbOH6/fWqW2dIVrJzo=", false, function() {
  return [useQuery];
});
_c = ExportReportButton;
var _c;
$RefreshReg$(_c, "ExportReportButton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ExportReportButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ExportReportButton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JJOzs7Ozs7Ozs7Ozs7Ozs7OztBQXhCSixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsV0FBVztBQU9iLGdCQUFTQyxtQkFBbUIsRUFBRUMsT0FBZ0MsR0FBRztBQUFBQyxLQUFBO0FBQ3RFLFFBQU1DLGFBQWFMLFNBQVNDLElBQUlLLFFBQVFDLHdCQUF3QixFQUFFSixPQUFPLENBQUM7QUFFMUUsUUFBTUssZUFBZUEsTUFBTTtBQUN6QixRQUFJLENBQUNILFdBQVk7QUFFakIsVUFBTUksT0FBTyxJQUFJQyxLQUFLLENBQUNMLFdBQVdNLE1BQU0sR0FBRyxFQUFFQyxNQUFNLGdCQUFnQixDQUFDO0FBQ3BFLFVBQU1DLE1BQU1DLElBQUlDLGdCQUFnQk4sSUFBSTtBQUNwQyxVQUFNTyxJQUFJQyxTQUFTQyxjQUFjLEdBQUc7QUFDcENGLE1BQUVHLE9BQU9OO0FBQ1RHLE1BQUVJLFdBQVcsbUJBQW1CakIsT0FBT2tCLE1BQU0sRUFBRSxDQUFDLElBQUlDLEtBQUtDLElBQUksQ0FBQztBQUM5RFAsTUFBRVEsTUFBTTtBQUNSVixRQUFJVyxnQkFBZ0JaLEdBQUc7QUFBQSxFQUN6QjtBQUVBLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFNBQVNMO0FBQUFBLE1BQ1QsVUFBVSxDQUFDSDtBQUFBQSxNQUNYLE9BQU87QUFBQSxRQUNMcUIsU0FBUztBQUFBLFFBQ1RDLFlBQVl0QixhQUFhLFlBQVk7QUFBQSxRQUNyQ3VCLFFBQVE7QUFBQSxRQUNSQyxjQUFjO0FBQUEsUUFDZEMsT0FBTztBQUFBLFFBQ1BDLFVBQVU7QUFBQSxRQUNWQyxZQUFZO0FBQUEsUUFDWkMsUUFBUTVCLGFBQWEsWUFBWTtBQUFBLFFBQ2pDNkIsU0FBUztBQUFBLFFBQ1RDLFlBQVk7QUFBQSxRQUNaQyxLQUFLO0FBQUEsTUFDUDtBQUFBLE1BQUU7QUFBQTtBQUFBLElBZko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBa0JBO0FBRUo7QUFBQ2hDLEdBcENlRixvQkFBa0I7QUFBQSxVQUNiRixRQUFRO0FBQUE7QUFBQSxLQURiRTtBQUFrQixJQUFBbUM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlUXVlcnkiLCJhcGkiLCJFeHBvcnRSZXBvcnRCdXR0b24iLCJ0YXNrSWQiLCJfcyIsInJlcG9ydERhdGEiLCJyZXBvcnRzIiwiZ2VuZXJhdGVJbmNpZGVudFJlcG9ydCIsImhhbmRsZUV4cG9ydCIsImJsb2IiLCJCbG9iIiwicmVwb3J0IiwidHlwZSIsInVybCIsIlVSTCIsImNyZWF0ZU9iamVjdFVSTCIsImEiLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJocmVmIiwiZG93bmxvYWQiLCJzbGljZSIsIkRhdGUiLCJub3ciLCJjbGljayIsInJldm9rZU9iamVjdFVSTCIsInBhZGRpbmciLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwiYm9yZGVyUmFkaXVzIiwiY29sb3IiLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJjdXJzb3IiLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImdhcCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkV4cG9ydFJlcG9ydEJ1dHRvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuXG5pbnRlcmZhY2UgRXhwb3J0UmVwb3J0QnV0dG9uUHJvcHMge1xuICB0YXNrSWQ6IElkPFwidGFza3NcIj47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBFeHBvcnRSZXBvcnRCdXR0b24oeyB0YXNrSWQgfTogRXhwb3J0UmVwb3J0QnV0dG9uUHJvcHMpIHtcbiAgY29uc3QgcmVwb3J0RGF0YSA9IHVzZVF1ZXJ5KGFwaS5yZXBvcnRzLmdlbmVyYXRlSW5jaWRlbnRSZXBvcnQsIHsgdGFza0lkIH0pO1xuICBcbiAgY29uc3QgaGFuZGxlRXhwb3J0ID0gKCkgPT4ge1xuICAgIGlmICghcmVwb3J0RGF0YSkgcmV0dXJuO1xuICAgIFxuICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbcmVwb3J0RGF0YS5yZXBvcnRdLCB7IHR5cGU6IFwidGV4dC9tYXJrZG93blwiIH0pO1xuICAgIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XG4gICAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJhXCIpO1xuICAgIGEuaHJlZiA9IHVybDtcbiAgICBhLmRvd25sb2FkID0gYGluY2lkZW50LXJlcG9ydC0ke3Rhc2tJZC5zbGljZSgtNil9LSR7RGF0ZS5ub3coKX0ubWRgO1xuICAgIGEuY2xpY2soKTtcbiAgICBVUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XG4gIH07XG4gIFxuICByZXR1cm4gKFxuICAgIDxidXR0b25cbiAgICAgIG9uQ2xpY2s9e2hhbmRsZUV4cG9ydH1cbiAgICAgIGRpc2FibGVkPXshcmVwb3J0RGF0YX1cbiAgICAgIHN0eWxlPXt7XG4gICAgICAgIHBhZGRpbmc6IFwiOHB4IDE2cHhcIixcbiAgICAgICAgYmFja2dyb3VuZDogcmVwb3J0RGF0YSA/IFwiIzNiODJmNlwiIDogXCIjMzM0MTU1XCIsXG4gICAgICAgIGJvcmRlcjogXCJub25lXCIsXG4gICAgICAgIGJvcmRlclJhZGl1czogXCI2cHhcIixcbiAgICAgICAgY29sb3I6IFwid2hpdGVcIixcbiAgICAgICAgZm9udFNpemU6IFwiMTRweFwiLFxuICAgICAgICBmb250V2VpZ2h0OiA1MDAsXG4gICAgICAgIGN1cnNvcjogcmVwb3J0RGF0YSA/IFwicG9pbnRlclwiIDogXCJub3QtYWxsb3dlZFwiLFxuICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcbiAgICAgICAgZ2FwOiBcIjhweFwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICBFeHBvcnQgUmVwb3J0XG4gICAgPC9idXR0b24+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9FeHBvcnRSZXBvcnRCdXR0b24udHN4In0=