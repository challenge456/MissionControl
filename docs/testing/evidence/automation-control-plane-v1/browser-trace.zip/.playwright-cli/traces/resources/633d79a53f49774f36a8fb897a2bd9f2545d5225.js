import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/operator/ChatBubble.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatBubble.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export function ChatBubble({ text }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "schematic-bubble", children: text }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatBubble.tsx",
    lineNumber: 22,
    columnNumber: 10
  }, this);
}
_c = ChatBubble;
var _c;
$RefreshReg$(_c, "ChatBubble");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatBubble.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatBubble.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBRVM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFERixnQkFBU0EsV0FBVyxFQUFFQyxLQUF1QixHQUFnQjtBQUNsRSxTQUFPLHVCQUFDLFNBQUksV0FBVSxvQkFBb0JBLGtCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXdDO0FBQ2pEO0FBQUNDLEtBRmVGO0FBQVUsSUFBQUU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQ2hhdEJ1YmJsZSIsInRleHQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDaGF0QnViYmxlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiogVXNlciBtZXNzYWdlIGJ1YmJsZSBpbiBjaGF0IGRvY2sgKHdha3UgLmJ1YmJsZSkuICovXG5leHBvcnQgZnVuY3Rpb24gQ2hhdEJ1YmJsZSh7IHRleHQgfTogeyB0ZXh0OiBzdHJpbmcgfSk6IEpTWC5FbGVtZW50IHtcbiAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwic2NoZW1hdGljLWJ1YmJsZVwiPnt0ZXh0fTwvZGl2Pjtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL2NvbXBvbmVudHMvb3BlcmF0b3IvQ2hhdEJ1YmJsZS50c3gifQ==