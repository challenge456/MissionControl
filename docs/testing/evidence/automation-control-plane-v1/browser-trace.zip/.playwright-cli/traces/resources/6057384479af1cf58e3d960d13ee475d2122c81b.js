import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-JRFAWF3F.js?v=738cb978";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-GMP6FTHE.js?v=738cb978";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-G3PMV62Z.js?v=738cb978";

// ../../../../../../../../node_modules/.pnpm/@radix-ui+react-direction@1.1.1_@types+react@18.3.27_react@18.3.1/node_modules/@radix-ui/react-direction/dist/index.mjs
var React = __toESM(require_react(), 1);
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var DirectionContext = React.createContext(void 0);
function useDirection(localDir) {
  const globalDir = React.useContext(DirectionContext);
  return localDir || globalDir || "ltr";
}

export {
  useDirection
};
//# sourceMappingURL=chunk-CZ7L2UK3.js.map
