import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_CONVEX_URL": "http://127.0.0.1:3214", "VITE_FLAG_CONTEXT_REGISTRY": "true", "VITE_FLAG_EOS_COMMAND_CENTER_PREVIEW": "true", "VITE_FLAG_UI_SHELL_V2": "true"};import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=ffca6772"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import { ConvexProvider, ConvexReactClient } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { BrowserRouter } from "/node_modules/.vite/deps/react-router-dom.js?v=83faf592";
import { ErrorBoundary } from "/src/ErrorBoundary.tsx";
import { SetupMessage } from "/src/SetupMessage.tsx";
import { ToastProvider } from "/src/Toast.tsx";
import App from "/src/App.tsx?t=1785283949016";
import "/src/index.css?t=1785283949016";
const convexUrl = import.meta.env.VITE_CONVEX_URL?.trim() || "";
const rootEl = document.getElementById("root");
if (!rootEl) {
  document.body.innerHTML = "<div style='padding:24px;font-family:system-ui'>Mission Control: no #root element.</div>";
} else {
  const root = ReactDOM.createRoot(rootEl);
  root.render(
    /* @__PURE__ */ jsxDEV(React.StrictMode, { children: /* @__PURE__ */ jsxDEV(ErrorBoundary, { children: !convexUrl ? /* @__PURE__ */ jsxDEV(SetupMessage, {}, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/main.tsx",
      lineNumber: 22,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(ConvexProvider, { client: new ConvexReactClient(convexUrl), children: /* @__PURE__ */ jsxDEV(ToastProvider, { children: /* @__PURE__ */ jsxDEV(
      BrowserRouter,
      {
        future: {
          v7_startTransition: true,
          v7_relativeSplatPath: true
        },
        children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/main.tsx",
          lineNumber: 32,
          columnNumber: 17
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/main.tsx",
        lineNumber: 26,
        columnNumber: 15
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/main.tsx",
      lineNumber: 25,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/main.tsx",
      lineNumber: 24,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/main.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/main.tsx",
      lineNumber: 19,
      columnNumber: 5
    }, this)
  );
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJVO0FBckJWLE9BQU9BLFdBQVc7QUFDbEIsT0FBT0MsY0FBYztBQUNyQixTQUFTQyxnQkFBZ0JDLHlCQUF5QjtBQUNsRCxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxxQkFBcUI7QUFDOUIsT0FBT0MsU0FBUztBQUNoQixPQUFPO0FBRVAsTUFBTUMsWUFBYUMsWUFBWUMsSUFBSUMsaUJBQTRCQyxLQUFLLEtBQUs7QUFFekUsTUFBTUMsU0FBU0MsU0FBU0MsZUFBZSxNQUFNO0FBQzdDLElBQUksQ0FBQ0YsUUFBUTtBQUNYQyxXQUFTRSxLQUFLQyxZQUFZO0FBQzVCLE9BQU87QUFDTCxRQUFNQyxPQUFPbEIsU0FBU21CLFdBQVdOLE1BQU07QUFDdkNLLE9BQUtFO0FBQUFBLElBQ0gsdUJBQUMsTUFBTSxZQUFOLEVBQ0MsaUNBQUMsaUJBQ0UsV0FBQ1osWUFDQSx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWEsSUFFYix1QkFBQyxrQkFBZSxRQUFRLElBQUlOLGtCQUFrQk0sU0FBUyxHQUNyRCxpQ0FBQyxpQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsUUFBUTtBQUFBLFVBQ05hLG9CQUFvQjtBQUFBLFVBQ3BCQyxzQkFBc0I7QUFBQSxRQUN4QjtBQUFBLFFBRUEsaUNBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQUk7QUFBQTtBQUFBLE1BTk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0EsS0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBLEtBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQkE7QUFBQSxFQUNGO0FBQ0YiLCJuYW1lcyI6WyJSZWFjdCIsIlJlYWN0RE9NIiwiQ29udmV4UHJvdmlkZXIiLCJDb252ZXhSZWFjdENsaWVudCIsIkJyb3dzZXJSb3V0ZXIiLCJFcnJvckJvdW5kYXJ5IiwiU2V0dXBNZXNzYWdlIiwiVG9hc3RQcm92aWRlciIsIkFwcCIsImNvbnZleFVybCIsImltcG9ydCIsImVudiIsIlZJVEVfQ09OVkVYX1VSTCIsInRyaW0iLCJyb290RWwiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwiYm9keSIsImlubmVySFRNTCIsInJvb3QiLCJjcmVhdGVSb290IiwicmVuZGVyIiwidjdfc3RhcnRUcmFuc2l0aW9uIiwidjdfcmVsYXRpdmVTcGxhdFBhdGgiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibWFpbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IFJlYWN0RE9NIGZyb20gXCJyZWFjdC1kb20vY2xpZW50XCI7XG5pbXBvcnQgeyBDb252ZXhQcm92aWRlciwgQ29udmV4UmVhY3RDbGllbnQgfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBCcm93c2VyUm91dGVyIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IEVycm9yQm91bmRhcnkgfSBmcm9tIFwiLi9FcnJvckJvdW5kYXJ5XCI7XG5pbXBvcnQgeyBTZXR1cE1lc3NhZ2UgfSBmcm9tIFwiLi9TZXR1cE1lc3NhZ2VcIjtcbmltcG9ydCB7IFRvYXN0UHJvdmlkZXIgfSBmcm9tIFwiLi9Ub2FzdFwiO1xuaW1wb3J0IEFwcCBmcm9tIFwiLi9BcHBcIjtcbmltcG9ydCBcIi4vaW5kZXguY3NzXCI7XG5cbmNvbnN0IGNvbnZleFVybCA9IChpbXBvcnQubWV0YS5lbnYuVklURV9DT05WRVhfVVJMIGFzIHN0cmluZyk/LnRyaW0oKSB8fCBcIlwiO1xuXG5jb25zdCByb290RWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJvb3RcIik7XG5pZiAoIXJvb3RFbCkge1xuICBkb2N1bWVudC5ib2R5LmlubmVySFRNTCA9IFwiPGRpdiBzdHlsZT0ncGFkZGluZzoyNHB4O2ZvbnQtZmFtaWx5OnN5c3RlbS11aSc+TWlzc2lvbiBDb250cm9sOiBubyAjcm9vdCBlbGVtZW50LjwvZGl2PlwiO1xufSBlbHNlIHtcbiAgY29uc3Qgcm9vdCA9IFJlYWN0RE9NLmNyZWF0ZVJvb3Qocm9vdEVsKTtcbiAgcm9vdC5yZW5kZXIoXG4gICAgPFJlYWN0LlN0cmljdE1vZGU+XG4gICAgICA8RXJyb3JCb3VuZGFyeT5cbiAgICAgICAgeyFjb252ZXhVcmwgPyAoXG4gICAgICAgICAgPFNldHVwTWVzc2FnZSAvPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxDb252ZXhQcm92aWRlciBjbGllbnQ9e25ldyBDb252ZXhSZWFjdENsaWVudChjb252ZXhVcmwpfT5cbiAgICAgICAgICAgIDxUb2FzdFByb3ZpZGVyPlxuICAgICAgICAgICAgICA8QnJvd3NlclJvdXRlclxuICAgICAgICAgICAgICAgIGZ1dHVyZT17e1xuICAgICAgICAgICAgICAgICAgdjdfc3RhcnRUcmFuc2l0aW9uOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgdjdfcmVsYXRpdmVTcGxhdFBhdGg6IHRydWUsXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxBcHAgLz5cbiAgICAgICAgICAgICAgPC9Ccm93c2VyUm91dGVyPlxuICAgICAgICAgICAgPC9Ub2FzdFByb3ZpZGVyPlxuICAgICAgICAgIDwvQ29udmV4UHJvdmlkZXI+XG4gICAgICAgICl9XG4gICAgICA8L0Vycm9yQm91bmRhcnk+XG4gICAgPC9SZWFjdC5TdHJpY3RNb2RlPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvbWFpbi50c3gifQ==