import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/badge.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/badge.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const React = ((m) => m?.__esModule ? m : { ...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {}, default: m })(__vite__cjsImport3_react);
import { cva } from "/node_modules/.vite/deps/class-variance-authority.js?v=257b6f3a";
import { cn } from "/src/lib/utils.ts";
const badgeVariants = cva(
  "inline-flex items-center rounded-full border px-2 py-0.5 font-[family:var(--font-display)] text-[0.66rem] font-semibold tracking-[0.14em] uppercase transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
  {
    variants: {
      variant: {
        default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/85",
        secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
        destructive: "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",
        outline: "text-foreground border-border",
        success: "bg-primary/15 text-primary border-primary/30 hover:bg-primary/20",
        warning: "bg-amber-500/15 text-amber-400 border-amber-500/30 hover:bg-amber-500/20",
        error: "bg-red-500/15 text-red-400 border-red-500/30 hover:bg-red-500/20",
        muted: "bg-muted text-muted-foreground border-border hover:bg-muted/80",
        "neon-success": "border-transparent bg-ok-soft text-ok",
        "neon-cyan": "border-transparent bg-info-soft text-info-accent",
        "neon-error": "border-transparent bg-err-soft text-err"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);
const Badge = React.forwardRef(
  _c = ({ className, variant, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "div",
    {
      ref,
      className: cn(badgeVariants({ variant }), className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/badge.tsx",
      lineNumber: 67,
      columnNumber: 1
    },
    this
  )
);
_c2 = Badge;
Badge.displayName = "Badge";
export { Badge, badgeVariants };
var _c, _c2;
$RefreshReg$(_c, "Badge$React.forwardRef");
$RefreshReg$(_c2, "Badge");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/badge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/badge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0NJOzs7Ozs7Ozs7Ozs7Ozs7O0FBL0NKLFlBQVlBLFdBQVc7QUFDdkIsU0FBU0MsV0FBOEI7QUFFdkMsU0FBU0MsVUFBVTtBQUVuQixNQUFNQyxnQkFBZ0JGO0FBQUFBLEVBQ3BCO0FBQUEsRUFDQTtBQUFBLElBQ0VHLFVBQVU7QUFBQSxNQUNSQyxTQUFTO0FBQUEsUUFDUEMsU0FDRTtBQUFBLFFBQ0ZDLFdBQ0U7QUFBQSxRQUNGQyxhQUNFO0FBQUEsUUFDRkMsU0FBUztBQUFBLFFBQ1RDLFNBQ0U7QUFBQSxRQUNGQyxTQUNFO0FBQUEsUUFDRkMsT0FDRTtBQUFBLFFBQ0ZDLE9BQ0U7QUFBQSxRQUNGLGdCQUNFO0FBQUEsUUFDRixhQUNFO0FBQUEsUUFDRixjQUNFO0FBQUEsTUFDSjtBQUFBLElBQ0Y7QUFBQSxJQUNBQyxpQkFBaUI7QUFBQSxNQUNmVCxTQUFTO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFDRjtBQVFBLE1BQU1VLFFBQVFmLE1BQU1nQjtBQUFBQSxFQUFzQ0MsS0FDeERBLENBQUMsRUFBRUMsV0FBV2IsU0FBUyxHQUFHYyxNQUFNLEdBQUdDLFFBQ2pDO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQztBQUFBLE1BQ0EsV0FBV2xCLEdBQUdDLGNBQWMsRUFBRUUsUUFBUSxDQUFDLEdBQUdhLFNBQVM7QUFBQSxNQUNuRCxHQUFJQztBQUFBQTtBQUFBQSxJQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUdZO0FBR2hCO0FBQUNFLE1BUktOO0FBU05BLE1BQU1PLGNBQWM7QUFFcEIsU0FBU1AsT0FBT1o7QUFBZSxJQUFBYyxJQUFBSTtBQUFBLGFBQUFKLElBQUE7QUFBQSxhQUFBSSxLQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJjdmEiLCJjbiIsImJhZGdlVmFyaWFudHMiLCJ2YXJpYW50cyIsInZhcmlhbnQiLCJkZWZhdWx0Iiwic2Vjb25kYXJ5IiwiZGVzdHJ1Y3RpdmUiLCJvdXRsaW5lIiwic3VjY2VzcyIsIndhcm5pbmciLCJlcnJvciIsIm11dGVkIiwiZGVmYXVsdFZhcmlhbnRzIiwiQmFkZ2UiLCJmb3J3YXJkUmVmIiwiX2MiLCJjbGFzc05hbWUiLCJwcm9wcyIsInJlZiIsIl9jMiIsImRpc3BsYXlOYW1lIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImJhZGdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIlxuaW1wb3J0IHsgY3ZhLCB0eXBlIFZhcmlhbnRQcm9wcyB9IGZyb20gXCJjbGFzcy12YXJpYW5jZS1hdXRob3JpdHlcIlxuXG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiXG5cbmNvbnN0IGJhZGdlVmFyaWFudHMgPSBjdmEoXG4gIFwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHJvdW5kZWQtZnVsbCBib3JkZXIgcHgtMiBweS0wLjUgZm9udC1bZmFtaWx5OnZhcigtLWZvbnQtZGlzcGxheSldIHRleHQtWzAuNjZyZW1dIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctWzAuMTRlbV0gdXBwZXJjYXNlIHRyYW5zaXRpb24tY29sb3JzIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1yaW5nIGZvY3VzOnJpbmctb2Zmc2V0LTJcIixcbiAge1xuICAgIHZhcmlhbnRzOiB7XG4gICAgICB2YXJpYW50OiB7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgXCJib3JkZXItdHJhbnNwYXJlbnQgYmctcHJpbWFyeSB0ZXh0LXByaW1hcnktZm9yZWdyb3VuZCBob3ZlcjpiZy1wcmltYXJ5Lzg1XCIsXG4gICAgICAgIHNlY29uZGFyeTpcbiAgICAgICAgICBcImJvcmRlci10cmFuc3BhcmVudCBiZy1zZWNvbmRhcnkgdGV4dC1zZWNvbmRhcnktZm9yZWdyb3VuZCBob3ZlcjpiZy1zZWNvbmRhcnkvODBcIixcbiAgICAgICAgZGVzdHJ1Y3RpdmU6XG4gICAgICAgICAgXCJib3JkZXItdHJhbnNwYXJlbnQgYmctZGVzdHJ1Y3RpdmUgdGV4dC1kZXN0cnVjdGl2ZS1mb3JlZ3JvdW5kIGhvdmVyOmJnLWRlc3RydWN0aXZlLzgwXCIsXG4gICAgICAgIG91dGxpbmU6IFwidGV4dC1mb3JlZ3JvdW5kIGJvcmRlci1ib3JkZXJcIixcbiAgICAgICAgc3VjY2VzczpcbiAgICAgICAgICBcImJnLXByaW1hcnkvMTUgdGV4dC1wcmltYXJ5IGJvcmRlci1wcmltYXJ5LzMwIGhvdmVyOmJnLXByaW1hcnkvMjBcIixcbiAgICAgICAgd2FybmluZzpcbiAgICAgICAgICBcImJnLWFtYmVyLTUwMC8xNSB0ZXh0LWFtYmVyLTQwMCBib3JkZXItYW1iZXItNTAwLzMwIGhvdmVyOmJnLWFtYmVyLTUwMC8yMFwiLFxuICAgICAgICBlcnJvcjpcbiAgICAgICAgICBcImJnLXJlZC01MDAvMTUgdGV4dC1yZWQtNDAwIGJvcmRlci1yZWQtNTAwLzMwIGhvdmVyOmJnLXJlZC01MDAvMjBcIixcbiAgICAgICAgbXV0ZWQ6XG4gICAgICAgICAgXCJiZy1tdXRlZCB0ZXh0LW11dGVkLWZvcmVncm91bmQgYm9yZGVyLWJvcmRlciBob3ZlcjpiZy1tdXRlZC84MFwiLFxuICAgICAgICBcIm5lb24tc3VjY2Vzc1wiOlxuICAgICAgICAgIFwiYm9yZGVyLXRyYW5zcGFyZW50IGJnLW9rLXNvZnQgdGV4dC1va1wiLFxuICAgICAgICBcIm5lb24tY3lhblwiOlxuICAgICAgICAgIFwiYm9yZGVyLXRyYW5zcGFyZW50IGJnLWluZm8tc29mdCB0ZXh0LWluZm8tYWNjZW50XCIsXG4gICAgICAgIFwibmVvbi1lcnJvclwiOlxuICAgICAgICAgIFwiYm9yZGVyLXRyYW5zcGFyZW50IGJnLWVyci1zb2Z0IHRleHQtZXJyXCIsXG4gICAgICB9LFxuICAgIH0sXG4gICAgZGVmYXVsdFZhcmlhbnRzOiB7XG4gICAgICB2YXJpYW50OiBcImRlZmF1bHRcIixcbiAgICB9LFxuICB9XG4pXG5cbnR5cGUgQmFkZ2VFbGVtZW50UHJvcHMgPSBSZWFjdC5Db21wb25lbnRQcm9wc1dpdGhvdXRSZWY8XCJkaXZcIj5cblxuZXhwb3J0IGludGVyZmFjZSBCYWRnZVByb3BzXG4gIGV4dGVuZHMgQmFkZ2VFbGVtZW50UHJvcHMsXG4gICAgVmFyaWFudFByb3BzPHR5cGVvZiBiYWRnZVZhcmlhbnRzPiB7fVxuXG5jb25zdCBCYWRnZSA9IFJlYWN0LmZvcndhcmRSZWY8SFRNTERpdkVsZW1lbnQsIEJhZGdlUHJvcHM+KFxuICAoeyBjbGFzc05hbWUsIHZhcmlhbnQsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICAgIDxkaXZcbiAgICAgIHJlZj17cmVmfVxuICAgICAgY2xhc3NOYW1lPXtjbihiYWRnZVZhcmlhbnRzKHsgdmFyaWFudCB9KSwgY2xhc3NOYW1lKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG4pXG5CYWRnZS5kaXNwbGF5TmFtZSA9IFwiQmFkZ2VcIlxuXG5leHBvcnQgeyBCYWRnZSwgYmFkZ2VWYXJpYW50cyB9XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9jb21wb25lbnRzL3VpL2JhZGdlLnRzeCJ9