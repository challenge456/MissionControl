import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Sidebar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { cn } from "/src/lib/utils.ts";
import { StatusBadge } from "/src/components/factory/badges.tsx";
import { ScrollArea } from "/src/components/ui/scroll-area.tsx";
import { ChevronLeft, ChevronRight } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
export const SIDEBAR_WIDTH = 260;
export const SIDEBAR_COLLAPSED = 48;
export function Sidebar({
  projectId,
  onOpenApprovals,
  onOpenPolicy,
  onOpenOperatorControls,
  onOpenNotifications,
  onOpenStandup,
  onPauseSquad,
  onResumeSquad,
  onAgentSelect,
  onWidthChange
}) {
  _s();
  const [collapsed, setCollapsed] = useState(() => {
    if (typeof window === "undefined") return false;
    return window.localStorage.getItem("mc.sidebar_collapsed") === "1";
  });
  const agents = useQuery(api.agents.listAll, projectId ? { projectId } : {});
  const pendingApprovals = useQuery(api.approvals.listPending, projectId ? { projectId, limit: 10 } : { limit: 10 });
  const pendingCount = pendingApprovals?.length ?? 0;
  const agentCount = agents?.length ?? 0;
  const pausedCount = agents?.filter((a) => a.status === "PAUSED").length ?? 0;
  const width = collapsed ? SIDEBAR_COLLAPSED : SIDEBAR_WIDTH;
  useEffect(() => {
    if (typeof window === "undefined") return;
    window.localStorage.setItem("mc.sidebar_collapsed", collapsed ? "1" : "0");
  }, [collapsed]);
  useEffect(() => {
    onWidthChange?.(width);
  }, [onWidthChange, width]);
  return /* @__PURE__ */ jsxDEV(
    "aside",
    {
      className: "flex flex-col border-r border-line bg-rail shrink-0 overflow-hidden transition-[width] duration-200",
      style: { width, minWidth: width },
      children: [
        /* @__PURE__ */ jsxDEV("div", { className: cn("px-3 py-3 border-b border-line flex items-center shrink-0", collapsed ? "justify-center" : "justify-between"), children: [
          !collapsed && /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] font-medium uppercase tracking-[0.06em] text-ink-muted", children: "Agents" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
              lineNumber: 85,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", children: agentCount }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
              lineNumber: 88,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
            lineNumber: 84,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setCollapsed((c) => !c),
              className: "p-1 rounded-md text-ink-muted hover:text-ink hover:bg-surface-2 transition-colors duration-150",
              "aria-label": collapsed ? "Expand sidebar" : "Collapse sidebar",
              title: collapsed ? "Expand sidebar" : "Collapse sidebar",
              children: collapsed ? /* @__PURE__ */ jsxDEV(ChevronRight, { className: "h-4 w-4" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
                lineNumber: 98,
                columnNumber: 24
              }, this) : /* @__PURE__ */ jsxDEV(ChevronLeft, { className: "h-4 w-4" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
                lineNumber: 98,
                columnNumber: 63
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
              lineNumber: 91,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
          lineNumber: 82,
          columnNumber: 7
        }, this),
        !collapsed && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "px-3 py-3 shrink-0 border-b border-line", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-[11.5px] font-medium uppercase tracking-[0.06em] text-ink-muted mb-2", children: "Quick Actions" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
              lineNumber: 106,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-1.5 mb-2", children: [
              onOpenNotifications && /* @__PURE__ */ jsxDEV(SidebarButton, { onClick: onOpenNotifications, label: "Notifications" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
                lineNumber: 110,
                columnNumber: 39
              }, this),
              onOpenApprovals && /* @__PURE__ */ jsxDEV(
                SidebarButton,
                {
                  onClick: onOpenApprovals,
                  label: "Approvals",
                  badge: pendingCount > 0 ? String(pendingCount) : void 0
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
                  lineNumber: 112,
                  columnNumber: 13
                },
                this
              ),
              onOpenStandup && /* @__PURE__ */ jsxDEV(SidebarButton, { onClick: onOpenStandup, label: "Standup" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
                lineNumber: 118,
                columnNumber: 33
              }, this),
              onOpenPolicy && /* @__PURE__ */ jsxDEV(SidebarButton, { onClick: onOpenPolicy, label: "Policy" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
                lineNumber: 119,
                columnNumber: 32
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
              lineNumber: 109,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-1.5", children: [
              onOpenOperatorControls && /* @__PURE__ */ jsxDEV(SidebarButton, { onClick: onOpenOperatorControls, label: "Controls", variant: "warning", fullWidth: true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
                lineNumber: 123,
                columnNumber: 13
              }, this),
              onPauseSquad && /* @__PURE__ */ jsxDEV(SidebarButton, { onClick: onPauseSquad, label: "Pause squad", variant: "danger", fullWidth: true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
                lineNumber: 126,
                columnNumber: 13
              }, this),
              onResumeSquad && pausedCount > 0 && /* @__PURE__ */ jsxDEV(SidebarButton, { onClick: onResumeSquad, label: `Resume ${pausedCount} paused`, variant: "success", fullWidth: true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
                lineNumber: 129,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
              lineNumber: 121,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
            lineNumber: 105,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(ScrollArea, { className: "flex-1 min-h-0", children: /* @__PURE__ */ jsxDEV("div", { className: "py-1", children: agents === void 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2 p-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "h-3.5 animate-pulse rounded bg-surface-2" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
              lineNumber: 139,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "h-3.5 animate-pulse rounded bg-surface-2" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
              lineNumber: 140,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "h-3.5 animate-pulse rounded bg-surface-2" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
              lineNumber: 141,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
            lineNumber: 138,
            columnNumber: 13
          }, this) : agents.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "p-3 text-ink-muted text-[13.5px]", children: "No agents" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
            lineNumber: 144,
            columnNumber: 13
          }, this) : agents.map(
            (a) => /* @__PURE__ */ jsxDEV(
              AgentRow,
              {
                agent: a,
                onClick: onAgentSelect ? () => onAgentSelect(a._id) : void 0
              },
              a._id,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
                lineNumber: 147,
                columnNumber: 13
              },
              this
            )
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
            lineNumber: 136,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
            lineNumber: 135,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
          lineNumber: 103,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
      lineNumber: 77,
      columnNumber: 5
    },
    this
  );
}
_s(Sidebar, "yoy8AvsRQhReRRHuBAfpDz4FyvI=", false, function() {
  return [useQuery, useQuery];
});
_c = Sidebar;
function AgentRow({ agent, onClick }) {
  const isActive = agent.status === "ACTIVE";
  const statusLabel = isActive ? "Active" : "Not active";
  const roleShort = agent.role === "LEAD" ? "Lead" : agent.role === "SPECIALIST" ? "Spc" : agent.role === "INTERN" ? "Int" : agent.role;
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      className: cn(
        "w-full flex items-center gap-3 px-3 py-2 text-left border-0 bg-transparent transition-colors duration-150",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1 focus-visible:ring-offset-background",
        onClick ? "cursor-pointer hover:bg-surface-2" : "cursor-default"
      ),
      onClick,
      "aria-label": `${agent.name}, ${roleShort}, ${statusLabel}`,
      disabled: !onClick,
      children: [
        /* @__PURE__ */ jsxDEV("span", { className: "w-7 h-7 rounded-full border border-line bg-surface-2 flex items-center justify-center text-xs font-medium shrink-0 text-ink", children: agent.emoji || agent.name.charAt(0) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
          lineNumber: 186,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-[13.5px] font-medium text-ink truncate", children: agent.name }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
            lineNumber: 190,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-[12px] text-ink-muted", children: roleShort }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
            lineNumber: 191,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
          lineNumber: 189,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "span",
          {
            className: cn(
              "w-1.5 h-1.5 rounded-full shrink-0",
              isActive ? "bg-ok" : "bg-ink-muted/40"
            ),
            title: agent.status,
            "aria-hidden": true
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
            lineNumber: 193,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
      lineNumber: 175,
      columnNumber: 5
    },
    this
  );
}
_c2 = AgentRow;
function SidebarButton({
  onClick,
  label,
  badge,
  variant = "default",
  fullWidth = false
}) {
  const variantClasses = {
    default: "border-line bg-surface-2 text-ink-secondary hover:text-ink hover:border-line-strong",
    warning: "border-transparent bg-warn-soft text-warn hover:opacity-90",
    danger: "border-transparent bg-err-soft text-err hover:opacity-90",
    success: "border-transparent bg-ok-soft text-ok hover:opacity-90"
  };
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      onClick,
      className: cn(
        "px-3 py-2 rounded-lg text-xs font-medium border transition-colors duration-150 cursor-pointer",
        variantClasses[variant],
        fullWidth ? "w-full" : "flex-1 min-w-0"
      ),
      children: /* @__PURE__ */ jsxDEV("span", { className: "flex items-center justify-center gap-1.5", children: [
        label,
        badge && /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "warning", children: badge }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
          lineNumber: 237,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
        lineNumber: 235,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx",
      lineNumber: 226,
      columnNumber: 5
    },
    this
  );
}
_c3 = SidebarButton;
var _c, _c2, _c3;
$RefreshReg$(_c, "Sidebar");
$RefreshReg$(_c2, "AgentRow");
$RefreshReg$(_c3, "SidebarButton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Sidebar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0VVLG1CQUNFLGNBREY7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBaEVWLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsV0FBVztBQUVwQixTQUFTQyxVQUFVO0FBQ25CLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsYUFBYUMsb0JBQW9CO0FBRW5DLGFBQU1DLGdCQUFnQjtBQUN0QixhQUFNQyxvQkFBb0I7QUFFMUIsZ0JBQVNDLFFBQVE7QUFBQSxFQUN0QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFZRixHQUFHO0FBQUFDLEtBQUE7QUFDRCxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSXZCLFNBQVMsTUFBTTtBQUMvQyxRQUFJLE9BQU93QixXQUFXLFlBQWEsUUFBTztBQUMxQyxXQUFPQSxPQUFPQyxhQUFhQyxRQUFRLHNCQUFzQixNQUFNO0FBQUEsRUFDakUsQ0FBQztBQUNELFFBQU1DLFNBQVMxQixTQUFTQyxJQUFJeUIsT0FBT0MsU0FBU2pCLFlBQVksRUFBRUEsVUFBVSxJQUFJLENBQUMsQ0FBQztBQUMxRSxRQUFNa0IsbUJBQW1CNUIsU0FBU0MsSUFBSTRCLFVBQVVDLGFBQWFwQixZQUFZLEVBQUVBLFdBQVdxQixPQUFPLEdBQUcsSUFBSSxFQUFFQSxPQUFPLEdBQUcsQ0FBQztBQUNqSCxRQUFNQyxlQUFlSixrQkFBa0JLLFVBQVU7QUFDakQsUUFBTUMsYUFBYVIsUUFBUU8sVUFBVTtBQUNyQyxRQUFNRSxjQUFjVCxRQUFRVSxPQUFPLENBQUNDLE1BQU1BLEVBQUVDLFdBQVcsUUFBUSxFQUFFTCxVQUFVO0FBRTNFLFFBQU1NLFFBQVFsQixZQUFZYixvQkFBb0JEO0FBRTlDVCxZQUFVLE1BQU07QUFDZCxRQUFJLE9BQU95QixXQUFXLFlBQWE7QUFDbkNBLFdBQU9DLGFBQWFnQixRQUFRLHdCQUF3Qm5CLFlBQVksTUFBTSxHQUFHO0FBQUEsRUFDM0UsR0FBRyxDQUFDQSxTQUFTLENBQUM7QUFFZHZCLFlBQVUsTUFBTTtBQUNkcUIsb0JBQWdCb0IsS0FBSztBQUFBLEVBQ3ZCLEdBQUcsQ0FBQ3BCLGVBQWVvQixLQUFLLENBQUM7QUFFekIsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVTtBQUFBLE1BQ1YsT0FBTyxFQUFFQSxPQUFPRSxVQUFVRixNQUFNO0FBQUEsTUFHaEM7QUFBQSwrQkFBQyxTQUFJLFdBQVdyQyxHQUFHLDZEQUE2RG1CLFlBQVksbUJBQW1CLGlCQUFpQixHQUM3SDtBQUFBLFdBQUNBLGFBQ0EsbUNBQ0U7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsd0VBQXNFLHNCQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxlQUFZLE1BQUssV0FBV2Esd0JBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdDO0FBQUEsZUFKMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBRUY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTVosYUFBYSxDQUFDb0IsTUFBTSxDQUFDQSxDQUFDO0FBQUEsY0FDckMsV0FBVTtBQUFBLGNBQ1YsY0FBWXJCLFlBQVksbUJBQW1CO0FBQUEsY0FDM0MsT0FBT0EsWUFBWSxtQkFBbUI7QUFBQSxjQUVyQ0Esc0JBQVksdUJBQUMsZ0JBQWEsV0FBVSxhQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQyxJQUFNLHVCQUFDLGVBQVksV0FBVSxhQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBO0FBQUEsWUFQdEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQSxhQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0JBO0FBQUEsUUFFQyxDQUFDQSxhQUNBLG1DQUVFO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDZFQUEyRSw2QkFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGlDQUNaUDtBQUFBQSxxQ0FBdUIsdUJBQUMsaUJBQWMsU0FBU0EscUJBQXFCLE9BQU0sbUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtFO0FBQUEsY0FDekZILG1CQUNDO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVNBO0FBQUFBLGtCQUNULE9BQU07QUFBQSxrQkFDTixPQUFPcUIsZUFBZSxJQUFJVyxPQUFPWCxZQUFZLElBQUlZO0FBQUFBO0FBQUFBLGdCQUhuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHNkQ7QUFBQSxjQUc5RDdCLGlCQUFpQix1QkFBQyxpQkFBYyxTQUFTQSxlQUFlLE9BQU0sYUFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0Q7QUFBQSxjQUN2RUgsZ0JBQWdCLHVCQUFDLGlCQUFjLFNBQVNBLGNBQWMsT0FBTSxZQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRDtBQUFBLGlCQVZ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUseUJBQ1pDO0FBQUFBLHdDQUNDLHVCQUFDLGlCQUFjLFNBQVNBLHdCQUF3QixPQUFNLFlBQVcsU0FBUSxXQUFVLFdBQVMsUUFBNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEY7QUFBQSxjQUU3RkcsZ0JBQ0MsdUJBQUMsaUJBQWMsU0FBU0EsY0FBYyxPQUFNLGVBQWMsU0FBUSxVQUFTLFdBQVMsUUFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0Y7QUFBQSxjQUVyRkMsaUJBQWlCa0IsY0FBYyxLQUM5Qix1QkFBQyxpQkFBYyxTQUFTbEIsZUFBZSxPQUFPLFVBQVVrQixXQUFXLFdBQVcsU0FBUSxXQUFVLFdBQVMsUUFBekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUc7QUFBQSxpQkFSN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLGVBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMkJBO0FBQUEsVUFHQSx1QkFBQyxjQUFXLFdBQVUsa0JBQ3BCLGlDQUFDLFNBQUksV0FBVSxRQUNaVCxxQkFBV2tCLFNBQ1YsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDhDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlEO0FBQUEsWUFDekQsdUJBQUMsU0FBSSxXQUFVLDhDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlEO0FBQUEsWUFDekQsdUJBQUMsU0FBSSxXQUFVLDhDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlEO0FBQUEsZUFIM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQSxJQUNFbEIsT0FBT08sV0FBVyxJQUNwQix1QkFBQyxTQUFJLFdBQVUsb0NBQW1DLHlCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRCxJQUUzRFAsT0FBT21CO0FBQUFBLFlBQUksQ0FBQ1IsTUFDVjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUVDLE9BQU9BO0FBQUFBLGdCQUNQLFNBQVNuQixnQkFBZ0IsTUFBTUEsY0FBY21CLEVBQUVTLEdBQUcsSUFBSUY7QUFBQUE7QUFBQUEsY0FGakRQLEVBQUVTO0FBQUFBLGNBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUdrRTtBQUFBLFVBRW5FLEtBaEJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBLEtBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsYUFwREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFEQTtBQUFBO0FBQUE7QUFBQSxJQS9FSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFpRkE7QUFFSjtBQUFDMUIsR0FoSWVYLFNBQU87QUFBQSxVQTJCTlQsVUFDVUEsUUFBUTtBQUFBO0FBQUEsS0E1Qm5CUztBQWtJaEIsU0FBU3NDLFNBQVMsRUFBRUMsT0FBT0MsUUFBd0QsR0FBRztBQUNwRixRQUFNQyxXQUFXRixNQUFNVixXQUFXO0FBQ2xDLFFBQU1hLGNBQWNELFdBQVcsV0FBVztBQUMxQyxRQUFNRSxZQUNKSixNQUFNSyxTQUFTLFNBQ1gsU0FDQUwsTUFBTUssU0FBUyxlQUNiLFFBQ0FMLE1BQU1LLFNBQVMsV0FDYixRQUNBTCxNQUFNSztBQUVoQixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxNQUFLO0FBQUEsTUFDTCxXQUFXbkQ7QUFBQUEsUUFDVDtBQUFBLFFBQ0E7QUFBQSxRQUNBK0MsVUFBVSxzQ0FBc0M7QUFBQSxNQUNsRDtBQUFBLE1BQ0E7QUFBQSxNQUNBLGNBQVksR0FBR0QsTUFBTU0sSUFBSSxLQUFLRixTQUFTLEtBQUtELFdBQVc7QUFBQSxNQUN2RCxVQUFVLENBQUNGO0FBQUFBLE1BRVg7QUFBQSwrQkFBQyxVQUFLLFdBQVUsK0hBQ2JELGdCQUFNTyxTQUFTUCxNQUFNTSxLQUFLRSxPQUFPLENBQUMsS0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsK0NBQStDUixnQkFBTU0sUUFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUU7QUFBQSxVQUN6RSx1QkFBQyxTQUFJLFdBQVUsOEJBQThCRix1QkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUQ7QUFBQSxhQUZ6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFXbEQ7QUFBQUEsY0FDVDtBQUFBLGNBQ0FnRCxXQUFXLFVBQVU7QUFBQSxZQUN2QjtBQUFBLFlBQ0EsT0FBT0YsTUFBTVY7QUFBQUEsWUFDYixlQUFXO0FBQUE7QUFBQSxVQU5iO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1hO0FBQUE7QUFBQTtBQUFBLElBeEJmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTBCQTtBQUVKO0FBQUNtQixNQXpDUVY7QUEyQ1QsU0FBU1csY0FBYztBQUFBLEVBQ3JCVDtBQUFBQSxFQUNBVTtBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxVQUFVO0FBQUEsRUFDVkMsWUFBWTtBQU9kLEdBQUc7QUFDRCxRQUFNQyxpQkFBeUM7QUFBQSxJQUM3Q0MsU0FBUztBQUFBLElBQ1RDLFNBQVM7QUFBQSxJQUNUQyxRQUFRO0FBQUEsSUFDUkMsU0FBUztBQUFBLEVBQ1g7QUFFQSxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxNQUFLO0FBQUEsTUFDTDtBQUFBLE1BQ0EsV0FBV2pFO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBNkQsZUFBZUYsT0FBTztBQUFBLFFBQ3RCQyxZQUFZLFdBQVc7QUFBQSxNQUN6QjtBQUFBLE1BRUEsaUNBQUMsVUFBSyxXQUFVLDRDQUNiSDtBQUFBQTtBQUFBQSxRQUNBQyxTQUFTLHVCQUFDLGVBQVksTUFBSyxXQUFXQSxtQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFdBRi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBO0FBQUEsSUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFhQTtBQUVKO0FBQUNRLE1BcENRVjtBQUFhLElBQUFXLElBQUFaLEtBQUFXO0FBQUEsYUFBQUMsSUFBQTtBQUFBLGFBQUFaLEtBQUE7QUFBQSxhQUFBVyxLQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VRdWVyeSIsImFwaSIsImNuIiwiU3RhdHVzQmFkZ2UiLCJTY3JvbGxBcmVhIiwiQ2hldnJvbkxlZnQiLCJDaGV2cm9uUmlnaHQiLCJTSURFQkFSX1dJRFRIIiwiU0lERUJBUl9DT0xMQVBTRUQiLCJTaWRlYmFyIiwicHJvamVjdElkIiwib25PcGVuQXBwcm92YWxzIiwib25PcGVuUG9saWN5Iiwib25PcGVuT3BlcmF0b3JDb250cm9scyIsIm9uT3Blbk5vdGlmaWNhdGlvbnMiLCJvbk9wZW5TdGFuZHVwIiwib25QYXVzZVNxdWFkIiwib25SZXN1bWVTcXVhZCIsIm9uQWdlbnRTZWxlY3QiLCJvbldpZHRoQ2hhbmdlIiwiX3MiLCJjb2xsYXBzZWQiLCJzZXRDb2xsYXBzZWQiLCJ3aW5kb3ciLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiYWdlbnRzIiwibGlzdEFsbCIsInBlbmRpbmdBcHByb3ZhbHMiLCJhcHByb3ZhbHMiLCJsaXN0UGVuZGluZyIsImxpbWl0IiwicGVuZGluZ0NvdW50IiwibGVuZ3RoIiwiYWdlbnRDb3VudCIsInBhdXNlZENvdW50IiwiZmlsdGVyIiwiYSIsInN0YXR1cyIsIndpZHRoIiwic2V0SXRlbSIsIm1pbldpZHRoIiwiYyIsIlN0cmluZyIsInVuZGVmaW5lZCIsIm1hcCIsIl9pZCIsIkFnZW50Um93IiwiYWdlbnQiLCJvbkNsaWNrIiwiaXNBY3RpdmUiLCJzdGF0dXNMYWJlbCIsInJvbGVTaG9ydCIsInJvbGUiLCJuYW1lIiwiZW1vamkiLCJjaGFyQXQiLCJfYzIiLCJTaWRlYmFyQnV0dG9uIiwibGFiZWwiLCJiYWRnZSIsInZhcmlhbnQiLCJmdWxsV2lkdGgiLCJ2YXJpYW50Q2xhc3NlcyIsImRlZmF1bHQiLCJ3YXJuaW5nIiwiZGFuZ2VyIiwic3VjY2VzcyIsIl9jMyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNpZGViYXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5IH0gZnJvbSBcImNvbnZleC9yZWFjdFwiO1xuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2FwaVwiO1xuaW1wb3J0IHR5cGUgeyBEb2MsIElkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcbmltcG9ydCB7IFN0YXR1c0JhZGdlIH0gZnJvbSBcIkAvY29tcG9uZW50cy9mYWN0b3J5L2JhZGdlc1wiO1xuaW1wb3J0IHsgU2Nyb2xsQXJlYSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvc2Nyb2xsLWFyZWFcIjtcbmltcG9ydCB7IENoZXZyb25MZWZ0LCBDaGV2cm9uUmlnaHQgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5cbmV4cG9ydCBjb25zdCBTSURFQkFSX1dJRFRIID0gMjYwO1xuZXhwb3J0IGNvbnN0IFNJREVCQVJfQ09MTEFQU0VEID0gNDg7XG5cbmV4cG9ydCBmdW5jdGlvbiBTaWRlYmFyKHtcbiAgcHJvamVjdElkLFxuICBvbk9wZW5BcHByb3ZhbHMsXG4gIG9uT3BlblBvbGljeSxcbiAgb25PcGVuT3BlcmF0b3JDb250cm9scyxcbiAgb25PcGVuTm90aWZpY2F0aW9ucyxcbiAgb25PcGVuU3RhbmR1cCxcbiAgb25QYXVzZVNxdWFkLFxuICBvblJlc3VtZVNxdWFkLFxuICBvbkFnZW50U2VsZWN0LFxuICBvbldpZHRoQ2hhbmdlLFxufToge1xuICBwcm9qZWN0SWQ6IElkPFwicHJvamVjdHNcIj4gfCBudWxsO1xuICBvbk9wZW5BcHByb3ZhbHM/OiAoKSA9PiB2b2lkO1xuICBvbk9wZW5Qb2xpY3k/OiAoKSA9PiB2b2lkO1xuICBvbk9wZW5PcGVyYXRvckNvbnRyb2xzPzogKCkgPT4gdm9pZDtcbiAgb25PcGVuTm90aWZpY2F0aW9ucz86ICgpID0+IHZvaWQ7XG4gIG9uT3BlblN0YW5kdXA/OiAoKSA9PiB2b2lkO1xuICBvblBhdXNlU3F1YWQ/OiAoKSA9PiB2b2lkO1xuICBvblJlc3VtZVNxdWFkPzogKCkgPT4gdm9pZDtcbiAgb25BZ2VudFNlbGVjdD86IChhZ2VudElkOiBJZDxcImFnZW50c1wiPikgPT4gdm9pZDtcbiAgb25XaWR0aENoYW5nZT86ICh3aWR0aDogbnVtYmVyKSA9PiB2b2lkO1xufSkge1xuICBjb25zdCBbY29sbGFwc2VkLCBzZXRDb2xsYXBzZWRdID0gdXNlU3RhdGUoKCkgPT4ge1xuICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gZmFsc2U7XG4gICAgcmV0dXJuIHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcIm1jLnNpZGViYXJfY29sbGFwc2VkXCIpID09PSBcIjFcIjtcbiAgfSk7XG4gIGNvbnN0IGFnZW50cyA9IHVzZVF1ZXJ5KGFwaS5hZ2VudHMubGlzdEFsbCwgcHJvamVjdElkID8geyBwcm9qZWN0SWQgfSA6IHt9KTtcbiAgY29uc3QgcGVuZGluZ0FwcHJvdmFscyA9IHVzZVF1ZXJ5KGFwaS5hcHByb3ZhbHMubGlzdFBlbmRpbmcsIHByb2plY3RJZCA/IHsgcHJvamVjdElkLCBsaW1pdDogMTAgfSA6IHsgbGltaXQ6IDEwIH0pO1xuICBjb25zdCBwZW5kaW5nQ291bnQgPSBwZW5kaW5nQXBwcm92YWxzPy5sZW5ndGggPz8gMDtcbiAgY29uc3QgYWdlbnRDb3VudCA9IGFnZW50cz8ubGVuZ3RoID8/IDA7XG4gIGNvbnN0IHBhdXNlZENvdW50ID0gYWdlbnRzPy5maWx0ZXIoKGEpID0+IGEuc3RhdHVzID09PSBcIlBBVVNFRFwiKS5sZW5ndGggPz8gMDtcblxuICBjb25zdCB3aWR0aCA9IGNvbGxhcHNlZCA/IFNJREVCQVJfQ09MTEFQU0VEIDogU0lERUJBUl9XSURUSDtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm47XG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibWMuc2lkZWJhcl9jb2xsYXBzZWRcIiwgY29sbGFwc2VkID8gXCIxXCIgOiBcIjBcIik7XG4gIH0sIFtjb2xsYXBzZWRdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIG9uV2lkdGhDaGFuZ2U/Lih3aWR0aCk7XG4gIH0sIFtvbldpZHRoQ2hhbmdlLCB3aWR0aF0pO1xuXG4gIHJldHVybiAoXG4gICAgPGFzaWRlXG4gICAgICBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGJvcmRlci1yIGJvcmRlci1saW5lIGJnLXJhaWwgc2hyaW5rLTAgb3ZlcmZsb3ctaGlkZGVuIHRyYW5zaXRpb24tW3dpZHRoXSBkdXJhdGlvbi0yMDBcIlxuICAgICAgc3R5bGU9e3sgd2lkdGgsIG1pbldpZHRoOiB3aWR0aCB9fVxuICAgID5cbiAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT17Y24oXCJweC0zIHB5LTMgYm9yZGVyLWIgYm9yZGVyLWxpbmUgZmxleCBpdGVtcy1jZW50ZXIgc2hyaW5rLTBcIiwgY29sbGFwc2VkID8gXCJqdXN0aWZ5LWNlbnRlclwiIDogXCJqdXN0aWZ5LWJldHdlZW5cIil9PlxuICAgICAgICB7IWNvbGxhcHNlZCAmJiAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExLjVweF0gZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjA2ZW1dIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAgICAgIEFnZW50c1xuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPFN0YXR1c0JhZGdlIHRvbmU9XCJuZXV0cmFsXCI+e2FnZW50Q291bnR9PC9TdGF0dXNCYWRnZT5cbiAgICAgICAgICA8Lz5cbiAgICAgICAgKX1cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENvbGxhcHNlZCgoYykgPT4gIWMpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSByb3VuZGVkLW1kIHRleHQtaW5rLW11dGVkIGhvdmVyOnRleHQtaW5rIGhvdmVyOmJnLXN1cmZhY2UtMiB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxuICAgICAgICAgIGFyaWEtbGFiZWw9e2NvbGxhcHNlZCA/IFwiRXhwYW5kIHNpZGViYXJcIiA6IFwiQ29sbGFwc2Ugc2lkZWJhclwifVxuICAgICAgICAgIHRpdGxlPXtjb2xsYXBzZWQgPyBcIkV4cGFuZCBzaWRlYmFyXCIgOiBcIkNvbGxhcHNlIHNpZGViYXJcIn1cbiAgICAgICAgPlxuICAgICAgICAgIHtjb2xsYXBzZWQgPyA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPiA6IDxDaGV2cm9uTGVmdCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz59XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHshY29sbGFwc2VkICYmIChcbiAgICAgICAgPD5cbiAgICAgICAgICB7LyogUXVpY2sgQWN0aW9ucyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTMgcHktMyBzaHJpbmstMCBib3JkZXItYiBib3JkZXItbGluZVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMS41cHhdIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy1bMC4wNmVtXSB0ZXh0LWluay1tdXRlZCBtYi0yXCI+XG4gICAgICAgICAgICAgIFF1aWNrIEFjdGlvbnNcbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0xLjUgbWItMlwiPlxuICAgICAgICAgICAgICB7b25PcGVuTm90aWZpY2F0aW9ucyAmJiA8U2lkZWJhckJ1dHRvbiBvbkNsaWNrPXtvbk9wZW5Ob3RpZmljYXRpb25zfSBsYWJlbD1cIk5vdGlmaWNhdGlvbnNcIiAvPn1cbiAgICAgICAgICAgICAge29uT3BlbkFwcHJvdmFscyAmJiAoXG4gICAgICAgICAgICAgICAgPFNpZGViYXJCdXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uT3BlbkFwcHJvdmFsc31cbiAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQXBwcm92YWxzXCJcbiAgICAgICAgICAgICAgICAgIGJhZGdlPXtwZW5kaW5nQ291bnQgPiAwID8gU3RyaW5nKHBlbmRpbmdDb3VudCkgOiB1bmRlZmluZWR9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAge29uT3BlblN0YW5kdXAgJiYgPFNpZGViYXJCdXR0b24gb25DbGljaz17b25PcGVuU3RhbmR1cH0gbGFiZWw9XCJTdGFuZHVwXCIgLz59XG4gICAgICAgICAgICAgIHtvbk9wZW5Qb2xpY3kgJiYgPFNpZGViYXJCdXR0b24gb25DbGljaz17b25PcGVuUG9saWN5fSBsYWJlbD1cIlBvbGljeVwiIC8+fVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICB7b25PcGVuT3BlcmF0b3JDb250cm9scyAmJiAoXG4gICAgICAgICAgICAgICAgPFNpZGViYXJCdXR0b24gb25DbGljaz17b25PcGVuT3BlcmF0b3JDb250cm9sc30gbGFiZWw9XCJDb250cm9sc1wiIHZhcmlhbnQ9XCJ3YXJuaW5nXCIgZnVsbFdpZHRoIC8+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIHtvblBhdXNlU3F1YWQgJiYgKFxuICAgICAgICAgICAgICAgIDxTaWRlYmFyQnV0dG9uIG9uQ2xpY2s9e29uUGF1c2VTcXVhZH0gbGFiZWw9XCJQYXVzZSBzcXVhZFwiIHZhcmlhbnQ9XCJkYW5nZXJcIiBmdWxsV2lkdGggLz5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAge29uUmVzdW1lU3F1YWQgJiYgcGF1c2VkQ291bnQgPiAwICYmIChcbiAgICAgICAgICAgICAgICA8U2lkZWJhckJ1dHRvbiBvbkNsaWNrPXtvblJlc3VtZVNxdWFkfSBsYWJlbD17YFJlc3VtZSAke3BhdXNlZENvdW50fSBwYXVzZWRgfSB2YXJpYW50PVwic3VjY2Vzc1wiIGZ1bGxXaWR0aCAvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQWdlbnQgTGlzdCAqL31cbiAgICAgICAgICA8U2Nyb2xsQXJlYSBjbGFzc05hbWU9XCJmbGV4LTEgbWluLWgtMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS0xXCI+XG4gICAgICAgICAgICAgIHthZ2VudHMgPT09IHVuZGVmaW5lZCA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTIgcC0zXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMy41IGFuaW1hdGUtcHVsc2Ugcm91bmRlZCBiZy1zdXJmYWNlLTJcIiAvPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTMuNSBhbmltYXRlLXB1bHNlIHJvdW5kZWQgYmctc3VyZmFjZS0yXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0zLjUgYW5pbWF0ZS1wdWxzZSByb3VuZGVkIGJnLXN1cmZhY2UtMlwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkgOiBhZ2VudHMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHRleHQtaW5rLW11dGVkIHRleHQtWzEzLjVweF1cIj5ObyBhZ2VudHM8L2Rpdj5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICBhZ2VudHMubWFwKChhOiBEb2M8XCJhZ2VudHNcIj4pID0+IChcbiAgICAgICAgICAgICAgICAgIDxBZ2VudFJvd1xuICAgICAgICAgICAgICAgICAgICBrZXk9e2EuX2lkfVxuICAgICAgICAgICAgICAgICAgICBhZ2VudD17YX1cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17b25BZ2VudFNlbGVjdCA/ICgpID0+IG9uQWdlbnRTZWxlY3QoYS5faWQpIDogdW5kZWZpbmVkfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9TY3JvbGxBcmVhPlxuICAgICAgICA8Lz5cbiAgICAgICl9XG4gICAgPC9hc2lkZT5cbiAgKTtcbn1cblxuZnVuY3Rpb24gQWdlbnRSb3coeyBhZ2VudCwgb25DbGljayB9OiB7IGFnZW50OiBEb2M8XCJhZ2VudHNcIj47IG9uQ2xpY2s/OiAoKSA9PiB2b2lkIH0pIHtcbiAgY29uc3QgaXNBY3RpdmUgPSBhZ2VudC5zdGF0dXMgPT09IFwiQUNUSVZFXCI7XG4gIGNvbnN0IHN0YXR1c0xhYmVsID0gaXNBY3RpdmUgPyBcIkFjdGl2ZVwiIDogXCJOb3QgYWN0aXZlXCI7XG4gIGNvbnN0IHJvbGVTaG9ydCA9XG4gICAgYWdlbnQucm9sZSA9PT0gXCJMRUFEXCJcbiAgICAgID8gXCJMZWFkXCJcbiAgICAgIDogYWdlbnQucm9sZSA9PT0gXCJTUEVDSUFMSVNUXCJcbiAgICAgICAgPyBcIlNwY1wiXG4gICAgICAgIDogYWdlbnQucm9sZSA9PT0gXCJJTlRFUk5cIlxuICAgICAgICAgID8gXCJJbnRcIlxuICAgICAgICAgIDogYWdlbnQucm9sZTtcblxuICByZXR1cm4gKFxuICAgIDxidXR0b25cbiAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHgtMyBweS0yIHRleHQtbGVmdCBib3JkZXItMCBiZy10cmFuc3BhcmVudCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIixcbiAgICAgICAgXCJmb2N1cy12aXNpYmxlOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctcmluZyBmb2N1cy12aXNpYmxlOnJpbmctb2Zmc2V0LTEgZm9jdXMtdmlzaWJsZTpyaW5nLW9mZnNldC1iYWNrZ3JvdW5kXCIsXG4gICAgICAgIG9uQ2xpY2sgPyBcImN1cnNvci1wb2ludGVyIGhvdmVyOmJnLXN1cmZhY2UtMlwiIDogXCJjdXJzb3ItZGVmYXVsdFwiXG4gICAgICApfVxuICAgICAgb25DbGljaz17b25DbGlja31cbiAgICAgIGFyaWEtbGFiZWw9e2Ake2FnZW50Lm5hbWV9LCAke3JvbGVTaG9ydH0sICR7c3RhdHVzTGFiZWx9YH1cbiAgICAgIGRpc2FibGVkPXshb25DbGlja31cbiAgICA+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTcgaC03IHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQteHMgZm9udC1tZWRpdW0gc2hyaW5rLTAgdGV4dC1pbmtcIj5cbiAgICAgICAge2FnZW50LmVtb2ppIHx8IGFnZW50Lm5hbWUuY2hhckF0KDApfVxuICAgICAgPC9zcGFuPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEzLjVweF0gZm9udC1tZWRpdW0gdGV4dC1pbmsgdHJ1bmNhdGVcIj57YWdlbnQubmFtZX08L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LWluay1tdXRlZFwiPntyb2xlU2hvcnR9PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxzcGFuXG4gICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgXCJ3LTEuNSBoLTEuNSByb3VuZGVkLWZ1bGwgc2hyaW5rLTBcIixcbiAgICAgICAgICBpc0FjdGl2ZSA/IFwiYmctb2tcIiA6IFwiYmctaW5rLW11dGVkLzQwXCJcbiAgICAgICAgKX1cbiAgICAgICAgdGl0bGU9e2FnZW50LnN0YXR1c31cbiAgICAgICAgYXJpYS1oaWRkZW5cbiAgICAgIC8+XG4gICAgPC9idXR0b24+XG4gICk7XG59XG5cbmZ1bmN0aW9uIFNpZGViYXJCdXR0b24oe1xuICBvbkNsaWNrLFxuICBsYWJlbCxcbiAgYmFkZ2UsXG4gIHZhcmlhbnQgPSBcImRlZmF1bHRcIixcbiAgZnVsbFdpZHRoID0gZmFsc2UsXG59OiB7XG4gIG9uQ2xpY2s6ICgpID0+IHZvaWQ7XG4gIGxhYmVsOiBzdHJpbmc7XG4gIGJhZGdlPzogc3RyaW5nO1xuICB2YXJpYW50PzogXCJkZWZhdWx0XCIgfCBcIndhcm5pbmdcIiB8IFwiZGFuZ2VyXCIgfCBcInN1Y2Nlc3NcIjtcbiAgZnVsbFdpZHRoPzogYm9vbGVhbjtcbn0pIHtcbiAgY29uc3QgdmFyaWFudENsYXNzZXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gICAgZGVmYXVsdDogXCJib3JkZXItbGluZSBiZy1zdXJmYWNlLTIgdGV4dC1pbmstc2Vjb25kYXJ5IGhvdmVyOnRleHQtaW5rIGhvdmVyOmJvcmRlci1saW5lLXN0cm9uZ1wiLFxuICAgIHdhcm5pbmc6IFwiYm9yZGVyLXRyYW5zcGFyZW50IGJnLXdhcm4tc29mdCB0ZXh0LXdhcm4gaG92ZXI6b3BhY2l0eS05MFwiLFxuICAgIGRhbmdlcjogXCJib3JkZXItdHJhbnNwYXJlbnQgYmctZXJyLXNvZnQgdGV4dC1lcnIgaG92ZXI6b3BhY2l0eS05MFwiLFxuICAgIHN1Y2Nlc3M6IFwiYm9yZGVyLXRyYW5zcGFyZW50IGJnLW9rLXNvZnQgdGV4dC1vayBob3ZlcjpvcGFjaXR5LTkwXCIsXG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8YnV0dG9uXG4gICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgIG9uQ2xpY2s9e29uQ2xpY2t9XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcInB4LTMgcHktMiByb3VuZGVkLWxnIHRleHQteHMgZm9udC1tZWRpdW0gYm9yZGVyIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBjdXJzb3ItcG9pbnRlclwiLFxuICAgICAgICB2YXJpYW50Q2xhc3Nlc1t2YXJpYW50XSxcbiAgICAgICAgZnVsbFdpZHRoID8gXCJ3LWZ1bGxcIiA6IFwiZmxleC0xIG1pbi13LTBcIlxuICAgICAgKX1cbiAgICA+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgIHtsYWJlbH1cbiAgICAgICAge2JhZGdlICYmIDxTdGF0dXNCYWRnZSB0b25lPVwid2FybmluZ1wiPntiYWRnZX08L1N0YXR1c0JhZGdlPn1cbiAgICAgIDwvc3Bhbj5cbiAgICA8L2J1dHRvbj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL1NpZGViYXIudHN4In0=