import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shellV2/Sidebar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { ChevronDown, ChevronLeft, Command, Search } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { NAV_GROUPS } from "/src/shellV2/navConfig.ts";
import { cn } from "/src/lib/utils.ts";
export const SIDEBAR_V2_WIDTH = 256;
export function SidebarItem({ item, active, onNavigate }) {
  const Icon = item.icon;
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      onClick: () => onNavigate(item.view),
      "aria-current": active ? "page" : void 0,
      className: cn(
        "flex w-full items-center gap-2.5 rounded-lg px-2.5 py-[7px] text-[13px] transition-colors duration-150",
        active ? "bg-registry-accent-soft text-ink ring-1 ring-registry-accent/30" : "text-ink-secondary hover:bg-surface-1 hover:text-ink"
      ),
      children: [
        /* @__PURE__ */ jsxDEV(Icon, { size: 15, strokeWidth: 1.75, className: "shrink-0", "aria-hidden": true }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
          lineNumber: 48,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "min-w-0 flex-1 truncate text-left", children: item.label }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
          lineNumber: 49,
          columnNumber: 7
        }, this),
        item.badge ? /* @__PURE__ */ jsxDEV("span", { className: "shrink-0 rounded border border-line px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-[0.06em] text-ink-muted", children: item.badge }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
          lineNumber: 51,
          columnNumber: 7
        }, this) : null,
        item.count != null && item.count > 0 ? /* @__PURE__ */ jsxDEV("span", { className: "shrink-0 font-mono text-[11px] tabular-nums text-ink-muted", children: item.count }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
          lineNumber: 56,
          columnNumber: 7
        }, this) : null
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
      lineNumber: 37,
      columnNumber: 5
    },
    this
  );
}
_c = SidebarItem;
export function SidebarSection({
  group,
  activeView,
  expanded,
  onToggle,
  onNavigate
}) {
  const containsActive = group.items.some((i) => i.view === activeView);
  return /* @__PURE__ */ jsxDEV("div", { className: "mb-1", children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: onToggle,
        "aria-expanded": expanded,
        className: cn(
          "flex w-full items-center justify-between rounded-md px-2.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.08em] transition-colors duration-150",
          containsActive ? "text-ink-secondary" : "text-ink-muted hover:text-ink-secondary"
        ),
        children: [
          group.label,
          /* @__PURE__ */ jsxDEV(
            ChevronDown,
            {
              size: 12,
              "aria-hidden": true,
              className: cn("transition-transform duration-150", expanded ? "" : "-rotate-90")
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
              lineNumber: 92,
              columnNumber: 9
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
        lineNumber: 82,
        columnNumber: 7
      },
      this
    ),
    expanded && /* @__PURE__ */ jsxDEV("div", { className: "mt-0.5 flex flex-col gap-px", children: group.items.map(
      (item) => /* @__PURE__ */ jsxDEV(
        SidebarItem,
        {
          item,
          active: item.view === activeView,
          onNavigate
        },
        item.view,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
          lineNumber: 101,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
      lineNumber: 99,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
    lineNumber: 81,
    columnNumber: 5
  }, this);
}
_c2 = SidebarSection;
export function WorkspaceSwitcher({ children }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "px-3 pb-2", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-1.5 px-1 text-[11px] font-semibold uppercase tracking-[0.08em] text-ink-muted", children: "Workspace" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
      lineNumber: 122,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "[&_select]:h-9 [&_select]:w-full [&_select]:rounded-lg [&_select]:border [&_select]:border-line [&_select]:bg-surface-1 [&_select]:bg-none [&_select]:px-2.5 [&_select]:text-[13px] [&_select]:text-ink [&_select]:shadow-none [&_select]:backdrop-blur-none", children }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
      lineNumber: 125,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
    lineNumber: 121,
    columnNumber: 5
  }, this);
}
_c3 = WorkspaceSwitcher;
export function Sidebar({
  width = SIDEBAR_V2_WIDTH,
  groups,
  activeView,
  onNavigate,
  onOpenSearch,
  workspaceSwitcher,
  footer,
  onHide
}) {
  _s();
  const navGroups = groups ?? NAV_GROUPS;
  const activeGroupId = (navGroups.find((g) => g.items.some((i) => i.view === activeView)) ?? navGroups[0]).id;
  const [expandedIds, setExpandedIds] = useState(
    () => [
      navGroups[0].id,
      activeGroupId
    ]
  );
  const effectiveExpanded = expandedIds.includes(activeGroupId) ? expandedIds : [...expandedIds, activeGroupId];
  return /* @__PURE__ */ jsxDEV(
    "nav",
    {
      "aria-label": "Primary",
      style: { width },
      className: "flex h-full shrink-0 flex-col border-r border-line bg-rail",
      children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 px-4 pb-3 pt-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex h-7 w-7 items-center justify-center rounded-md bg-surface-3 text-[13px] font-bold text-ink", children: "MC" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
            lineNumber: 172,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "min-w-0 flex-1 truncate text-[13px] font-semibold tracking-tight text-ink", children: "Mission Control" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
            lineNumber: 175,
            columnNumber: 9
          }, this),
          onHide ? /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: onHide,
              className: "rounded p-1 text-ink-muted hover:text-ink",
              title: "Hide sidebar",
              "aria-label": "Hide sidebar",
              children: /* @__PURE__ */ jsxDEV(ChevronLeft, { size: 14, "aria-hidden": true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
                lineNumber: 186,
                columnNumber: 13
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
              lineNumber: 179,
              columnNumber: 9
            },
            this
          ) : null
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
          lineNumber: 171,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "px-3 pb-3", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: onOpenSearch,
            className: "flex h-9 w-full items-center gap-2 rounded-lg border border-line bg-surface-1 px-2.5 text-[13px] text-ink-muted transition-colors duration-150 hover:border-line-strong hover:text-ink-secondary",
            children: [
              /* @__PURE__ */ jsxDEV(Search, { size: 14, "aria-hidden": true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
                lineNumber: 197,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "flex-1 text-left", children: "Search…" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
                lineNumber: 198,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV("kbd", { className: "flex items-center gap-0.5 rounded border border-line bg-surface-2 px-1 py-0.5 text-[10px] text-ink-muted", children: [
                /* @__PURE__ */ jsxDEV(Command, { size: 9, "aria-hidden": true }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
                  lineNumber: 200,
                  columnNumber: 13
                }, this),
                "K"
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
                lineNumber: 199,
                columnNumber: 11
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
            lineNumber: 192,
            columnNumber: 9
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
          lineNumber: 191,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(WorkspaceSwitcher, { children: workspaceSwitcher }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
          lineNumber: 205,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-y-auto px-3 py-1", children: navGroups.map(
          (group) => /* @__PURE__ */ jsxDEV(
            SidebarSection,
            {
              group,
              activeView,
              expanded: effectiveExpanded.includes(group.id),
              onToggle: () => setExpandedIds(
                (ids) => ids.includes(group.id) ? ids.filter((id) => id !== group.id) : [...ids, group.id]
              ),
              onNavigate
            },
            group.id,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
              lineNumber: 209,
              columnNumber: 9
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
          lineNumber: 207,
          columnNumber: 7
        }, this),
        footer && /* @__PURE__ */ jsxDEV("div", { className: "border-t border-line px-3 py-3", children: footer }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
          lineNumber: 226,
          columnNumber: 18
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx",
      lineNumber: 166,
      columnNumber: 5
    },
    this
  );
}
_s(Sidebar, "Fp7N6NK8dIcN/J9zuKUbSEvBFpw=");
_c4 = Sidebar;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "SidebarItem");
$RefreshReg$(_c2, "SidebarSection");
$RefreshReg$(_c3, "WorkspaceSwitcher");
$RefreshReg$(_c4, "Sidebar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/Sidebar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTVCTixTQUFTQSxnQkFBZ0M7QUFDekMsU0FBU0MsYUFBYUMsYUFBYUMsU0FBU0MsY0FBYztBQUUxRCxTQUFTQyxrQkFBK0M7QUFDeEQsU0FBU0MsVUFBVTtBQUVaLGFBQU1DLG1CQUFtQjtBQVF6QixnQkFBU0MsWUFBWSxFQUFFQyxNQUFNQyxRQUFRQyxXQUE2QixHQUFnQjtBQUN2RixRQUFNQyxPQUFPSCxLQUFLSTtBQUNsQixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxNQUFLO0FBQUEsTUFDTCxTQUFTLE1BQU1GLFdBQVdGLEtBQUtLLElBQUk7QUFBQSxNQUNuQyxnQkFBY0osU0FBUyxTQUFTSztBQUFBQSxNQUNoQyxXQUFXVDtBQUFBQSxRQUNUO0FBQUEsUUFDQUksU0FDSSxvRUFDQTtBQUFBLE1BQ047QUFBQSxNQUVBO0FBQUEsK0JBQUMsUUFBSyxNQUFNLElBQUksYUFBYSxNQUFNLFdBQVUsWUFBVyxlQUFXLFFBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUU7QUFBQSxRQUNuRSx1QkFBQyxVQUFLLFdBQVUscUNBQXFDRCxlQUFLTyxTQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFO0FBQUEsUUFDL0RQLEtBQUtRLFFBQ0osdUJBQUMsVUFBSyxXQUFVLHlIQUNiUixlQUFLUSxTQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUNFO0FBQUEsUUFDSFIsS0FBS1MsU0FBUyxRQUFRVCxLQUFLUyxRQUFRLElBQ2xDLHVCQUFDLFVBQUssV0FBVSw4REFDYlQsZUFBS1MsU0FEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFDRTtBQUFBO0FBQUE7QUFBQSxJQXRCTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUF1QkE7QUFFSjtBQUFDQyxLQTVCZVg7QUFzQ1QsZ0JBQVNZLGVBQWU7QUFBQSxFQUM3QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQWI7QUFDbUIsR0FBZ0I7QUFDbkMsUUFBTWMsaUJBQWlCSixNQUFNSyxNQUFNQyxLQUFLLENBQUNDLE1BQU1BLEVBQUVkLFNBQVNRLFVBQVU7QUFDcEUsU0FDRSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxTQUFTRTtBQUFBQSxRQUNULGlCQUFlRDtBQUFBQSxRQUNmLFdBQVdqQjtBQUFBQSxVQUNUO0FBQUEsVUFDQW1CLGlCQUFpQix1QkFBdUI7QUFBQSxRQUMxQztBQUFBLFFBRUNKO0FBQUFBLGdCQUFNTDtBQUFBQSxVQUNQO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNO0FBQUEsY0FDTjtBQUFBLGNBQ0EsV0FBV1YsR0FBRyxxQ0FBcUNpQixXQUFXLEtBQUssWUFBWTtBQUFBO0FBQUEsWUFIakY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBR21GO0FBQUE7QUFBQTtBQUFBLE1BYnJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWVBO0FBQUEsSUFDQ0EsWUFDQyx1QkFBQyxTQUFJLFdBQVUsK0JBQ1pGLGdCQUFNSyxNQUFNRztBQUFBQSxNQUFJLENBQUNwQixTQUNoQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUM7QUFBQSxVQUNBLFFBQVFBLEtBQUtLLFNBQVNRO0FBQUFBLFVBQ3RCO0FBQUE7QUFBQSxRQUhLYixLQUFLSztBQUFBQSxRQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJeUI7QUFBQSxJQUUxQixLQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLE9BM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2QkE7QUFFSjtBQUFDZ0IsTUF4Q2VWO0FBK0NULGdCQUFTVyxrQkFBa0IsRUFBRUMsU0FBaUMsR0FBZ0I7QUFDbkYsU0FDRSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxvRkFBa0YseUJBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLGdRQUNaQSxZQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU9BO0FBRUo7QUFBQ0MsTUFYZUY7QUF3QlQsZ0JBQVNHLFFBQVE7QUFBQSxFQUN0QkMsUUFBUTVCO0FBQUFBLEVBQ1I2QjtBQUFBQSxFQUNBZDtBQUFBQSxFQUNBWDtBQUFBQSxFQUNBMEI7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDWSxHQUFnQjtBQUFBQyxLQUFBO0FBQzVCLFFBQU1DLFlBQVlOLFVBQVUvQjtBQUM1QixRQUFNc0MsaUJBQWlCRCxVQUFVRSxLQUFLLENBQUNDLE1BQU1BLEVBQUVuQixNQUFNQyxLQUFLLENBQUNDLE1BQU1BLEVBQUVkLFNBQVNRLFVBQVUsQ0FBQyxLQUFLb0IsVUFBVSxDQUFDLEdBQUdJO0FBQzFHLFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJaEQ7QUFBQUEsSUFBbUIsTUFBTTtBQUFBLE1BQzdEMEMsVUFBVSxDQUFDLEVBQUVJO0FBQUFBLE1BQ2JIO0FBQUFBLElBQWE7QUFBQSxFQUNkO0FBR0QsUUFBTU0sb0JBQW9CRixZQUFZRyxTQUFTUCxhQUFhLElBQ3hESSxjQUNBLENBQUMsR0FBR0EsYUFBYUosYUFBYTtBQUVsQyxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxjQUFXO0FBQUEsTUFDWCxPQUFPLEVBQUVSLE1BQU07QUFBQSxNQUNmLFdBQVU7QUFBQSxNQUVWO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1HQUFpRyxrQkFBaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLDZFQUEyRSwrQkFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0NLLFNBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVNBO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBQ1YsT0FBTTtBQUFBLGNBQ04sY0FBVztBQUFBLGNBRVgsaUNBQUMsZUFBWSxNQUFNLElBQUksZUFBVyxRQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrQztBQUFBO0FBQUEsWUFQcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUEsSUFDRTtBQUFBLGFBakJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTSDtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsVUFBTyxNQUFNLElBQUksZUFBVyxRQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QjtBQUFBLGNBQzdCLHVCQUFDLFVBQUssV0FBVSxvQkFBbUIsdUJBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBDO0FBQUEsY0FDMUMsdUJBQUMsU0FBSSxXQUFVLDRHQUNiO0FBQUEsdUNBQUMsV0FBUSxNQUFNLEdBQUcsZUFBVyxRQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QjtBQUFBLGdCQUFHO0FBQUEsbUJBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQTtBQUFBO0FBQUEsVUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFFBRUEsdUJBQUMscUJBQW1CQywrQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQztBQUFBLFFBRXRDLHVCQUFDLFNBQUksV0FBVSxvQ0FDWkksb0JBQVViO0FBQUFBLFVBQUksQ0FBQ1IsVUFDZDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUM7QUFBQSxjQUNBO0FBQUEsY0FDQSxVQUFVNEIsa0JBQWtCQyxTQUFTN0IsTUFBTXlCLEVBQUU7QUFBQSxjQUM3QyxVQUFVLE1BQ1JFO0FBQUFBLGdCQUFlLENBQUNHLFFBQ2RBLElBQUlELFNBQVM3QixNQUFNeUIsRUFBRSxJQUNqQkssSUFBSUMsT0FBTyxDQUFDTixPQUFPQSxPQUFPekIsTUFBTXlCLEVBQUUsSUFDbEMsQ0FBQyxHQUFHSyxLQUFLOUIsTUFBTXlCLEVBQUU7QUFBQSxjQUN2QjtBQUFBLGNBRUY7QUFBQTtBQUFBLFlBWEt6QixNQUFNeUI7QUFBQUEsWUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBWXlCO0FBQUEsUUFFMUIsS0FoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBRUNQLFVBQVUsdUJBQUMsU0FBSSxXQUFVLGtDQUFrQ0Esb0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0Q7QUFBQTtBQUFBO0FBQUEsSUE1RHJFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTZEQTtBQUVKO0FBQUNFLEdBdEZlUCxTQUFPO0FBQUEsTUFBUEE7QUFBTyxJQUFBZixJQUFBVyxLQUFBRyxLQUFBb0I7QUFBQSxhQUFBbEMsSUFBQTtBQUFBLGFBQUFXLEtBQUE7QUFBQSxhQUFBRyxLQUFBO0FBQUEsYUFBQW9CLEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkNoZXZyb25Eb3duIiwiQ2hldnJvbkxlZnQiLCJDb21tYW5kIiwiU2VhcmNoIiwiTkFWX0dST1VQUyIsImNuIiwiU0lERUJBUl9WMl9XSURUSCIsIlNpZGViYXJJdGVtIiwiaXRlbSIsImFjdGl2ZSIsIm9uTmF2aWdhdGUiLCJJY29uIiwiaWNvbiIsInZpZXciLCJ1bmRlZmluZWQiLCJsYWJlbCIsImJhZGdlIiwiY291bnQiLCJfYyIsIlNpZGViYXJTZWN0aW9uIiwiZ3JvdXAiLCJhY3RpdmVWaWV3IiwiZXhwYW5kZWQiLCJvblRvZ2dsZSIsImNvbnRhaW5zQWN0aXZlIiwiaXRlbXMiLCJzb21lIiwiaSIsIm1hcCIsIl9jMiIsIldvcmtzcGFjZVN3aXRjaGVyIiwiY2hpbGRyZW4iLCJfYzMiLCJTaWRlYmFyIiwid2lkdGgiLCJncm91cHMiLCJvbk9wZW5TZWFyY2giLCJ3b3Jrc3BhY2VTd2l0Y2hlciIsImZvb3RlciIsIm9uSGlkZSIsIl9zIiwibmF2R3JvdXBzIiwiYWN0aXZlR3JvdXBJZCIsImZpbmQiLCJnIiwiaWQiLCJleHBhbmRlZElkcyIsInNldEV4cGFuZGVkSWRzIiwiZWZmZWN0aXZlRXhwYW5kZWQiLCJpbmNsdWRlcyIsImlkcyIsImZpbHRlciIsIl9jNCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTaWRlYmFyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdHlwZSBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IENoZXZyb25Eb3duLCBDaGV2cm9uTGVmdCwgQ29tbWFuZCwgU2VhcmNoIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHR5cGUgeyBNYWluVmlldyB9IGZyb20gXCIuLi9Ub3BOYXZcIjtcbmltcG9ydCB7IE5BVl9HUk9VUFMsIHR5cGUgTmF2R3JvdXAsIHR5cGUgTmF2SXRlbSB9IGZyb20gXCIuL25hdkNvbmZpZ1wiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiLi4vbGliL3V0aWxzXCI7XG5cbmV4cG9ydCBjb25zdCBTSURFQkFSX1YyX1dJRFRIID0gMjU2O1xuXG5pbnRlcmZhY2UgU2lkZWJhckl0ZW1Qcm9wcyB7XG4gIGl0ZW06IE5hdkl0ZW07XG4gIGFjdGl2ZTogYm9vbGVhbjtcbiAgb25OYXZpZ2F0ZTogKHZpZXc6IE1haW5WaWV3KSA9PiB2b2lkO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gU2lkZWJhckl0ZW0oeyBpdGVtLCBhY3RpdmUsIG9uTmF2aWdhdGUgfTogU2lkZWJhckl0ZW1Qcm9wcyk6IEpTWC5FbGVtZW50IHtcbiAgY29uc3QgSWNvbiA9IGl0ZW0uaWNvbjtcbiAgcmV0dXJuIChcbiAgICA8YnV0dG9uXG4gICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoaXRlbS52aWV3KX1cbiAgICAgIGFyaWEtY3VycmVudD17YWN0aXZlID8gXCJwYWdlXCIgOiB1bmRlZmluZWR9XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcImZsZXggdy1mdWxsIGl0ZW1zLWNlbnRlciBnYXAtMi41IHJvdW5kZWQtbGcgcHgtMi41IHB5LVs3cHhdIHRleHQtWzEzcHhdIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiLFxuICAgICAgICBhY3RpdmVcbiAgICAgICAgICA/IFwiYmctcmVnaXN0cnktYWNjZW50LXNvZnQgdGV4dC1pbmsgcmluZy0xIHJpbmctcmVnaXN0cnktYWNjZW50LzMwXCJcbiAgICAgICAgICA6IFwidGV4dC1pbmstc2Vjb25kYXJ5IGhvdmVyOmJnLXN1cmZhY2UtMSBob3Zlcjp0ZXh0LWlua1wiXG4gICAgICApfVxuICAgID5cbiAgICAgIDxJY29uIHNpemU9ezE1fSBzdHJva2VXaWR0aD17MS43NX0gY2xhc3NOYW1lPVwic2hyaW5rLTBcIiBhcmlhLWhpZGRlbiAvPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTEgdHJ1bmNhdGUgdGV4dC1sZWZ0XCI+e2l0ZW0ubGFiZWx9PC9zcGFuPlxuICAgICAge2l0ZW0uYmFkZ2UgPyAoXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNocmluay0wIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1saW5lIHB4LTEuNSBweS0wLjUgdGV4dC1bOXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy1bMC4wNmVtXSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgIHtpdGVtLmJhZGdlfVxuICAgICAgICA8L3NwYW4+XG4gICAgICApIDogbnVsbH1cbiAgICAgIHtpdGVtLmNvdW50ICE9IG51bGwgJiYgaXRlbS5jb3VudCA+IDAgPyAoXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNocmluay0wIGZvbnQtbW9ubyB0ZXh0LVsxMXB4XSB0YWJ1bGFyLW51bXMgdGV4dC1pbmstbXV0ZWRcIj5cbiAgICAgICAgICB7aXRlbS5jb3VudH1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgKSA6IG51bGx9XG4gICAgPC9idXR0b24+XG4gICk7XG59XG5cbmludGVyZmFjZSBTaWRlYmFyU2VjdGlvblByb3BzIHtcbiAgZ3JvdXA6IE5hdkdyb3VwO1xuICBhY3RpdmVWaWV3OiBNYWluVmlldztcbiAgZXhwYW5kZWQ6IGJvb2xlYW47XG4gIG9uVG9nZ2xlOiAoKSA9PiB2b2lkO1xuICBvbk5hdmlnYXRlOiAodmlldzogTWFpblZpZXcpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBTaWRlYmFyU2VjdGlvbih7XG4gIGdyb3VwLFxuICBhY3RpdmVWaWV3LFxuICBleHBhbmRlZCxcbiAgb25Ub2dnbGUsXG4gIG9uTmF2aWdhdGUsXG59OiBTaWRlYmFyU2VjdGlvblByb3BzKTogSlNYLkVsZW1lbnQge1xuICBjb25zdCBjb250YWluc0FjdGl2ZSA9IGdyb3VwLml0ZW1zLnNvbWUoKGkpID0+IGkudmlldyA9PT0gYWN0aXZlVmlldyk7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtYi0xXCI+XG4gICAgICA8YnV0dG9uXG4gICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICBvbkNsaWNrPXtvblRvZ2dsZX1cbiAgICAgICAgYXJpYS1leHBhbmRlZD17ZXhwYW5kZWR9XG4gICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgXCJmbGV4IHctZnVsbCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHJvdW5kZWQtbWQgcHgtMi41IHB5LTEuNSB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy1bMC4wOGVtXSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIixcbiAgICAgICAgICBjb250YWluc0FjdGl2ZSA/IFwidGV4dC1pbmstc2Vjb25kYXJ5XCIgOiBcInRleHQtaW5rLW11dGVkIGhvdmVyOnRleHQtaW5rLXNlY29uZGFyeVwiXG4gICAgICAgICl9XG4gICAgICA+XG4gICAgICAgIHtncm91cC5sYWJlbH1cbiAgICAgICAgPENoZXZyb25Eb3duXG4gICAgICAgICAgc2l6ZT17MTJ9XG4gICAgICAgICAgYXJpYS1oaWRkZW5cbiAgICAgICAgICBjbGFzc05hbWU9e2NuKFwidHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMTUwXCIsIGV4cGFuZGVkID8gXCJcIiA6IFwiLXJvdGF0ZS05MFwiKX1cbiAgICAgICAgLz5cbiAgICAgIDwvYnV0dG9uPlxuICAgICAge2V4cGFuZGVkICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0wLjUgZmxleCBmbGV4LWNvbCBnYXAtcHhcIj5cbiAgICAgICAgICB7Z3JvdXAuaXRlbXMubWFwKChpdGVtKSA9PiAoXG4gICAgICAgICAgICA8U2lkZWJhckl0ZW1cbiAgICAgICAgICAgICAga2V5PXtpdGVtLnZpZXd9XG4gICAgICAgICAgICAgIGl0ZW09e2l0ZW19XG4gICAgICAgICAgICAgIGFjdGl2ZT17aXRlbS52aWV3ID09PSBhY3RpdmVWaWV3fVxuICAgICAgICAgICAgICBvbk5hdmlnYXRlPXtvbk5hdmlnYXRlfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufVxuXG5pbnRlcmZhY2UgV29ya3NwYWNlU3dpdGNoZXJQcm9wcyB7XG4gIGNoaWxkcmVuOiBSZWFjdE5vZGU7XG59XG5cbi8qKiBCb3JkZXJlZCBjb250YWluZXIgc3R5bGluZyB0aGUgcHJvamVjdCBzZWxlY3RvciBsaWtlIGEgd29ya3NwYWNlIGNhcmQuICovXG5leHBvcnQgZnVuY3Rpb24gV29ya3NwYWNlU3dpdGNoZXIoeyBjaGlsZHJlbiB9OiBXb3Jrc3BhY2VTd2l0Y2hlclByb3BzKTogSlNYLkVsZW1lbnQge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtMyBwYi0yXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTEuNSBweC0xIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLVswLjA4ZW1dIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgIFdvcmtzcGFjZVxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIlsmX3NlbGVjdF06aC05IFsmX3NlbGVjdF06dy1mdWxsIFsmX3NlbGVjdF06cm91bmRlZC1sZyBbJl9zZWxlY3RdOmJvcmRlciBbJl9zZWxlY3RdOmJvcmRlci1saW5lIFsmX3NlbGVjdF06Ymctc3VyZmFjZS0xIFsmX3NlbGVjdF06Ymctbm9uZSBbJl9zZWxlY3RdOnB4LTIuNSBbJl9zZWxlY3RdOnRleHQtWzEzcHhdIFsmX3NlbGVjdF06dGV4dC1pbmsgWyZfc2VsZWN0XTpzaGFkb3ctbm9uZSBbJl9zZWxlY3RdOmJhY2tkcm9wLWJsdXItbm9uZVwiPlxuICAgICAgICB7Y2hpbGRyZW59XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuaW50ZXJmYWNlIFNpZGViYXJQcm9wcyB7XG4gIHdpZHRoPzogbnVtYmVyO1xuICBncm91cHM/OiBOYXZHcm91cFtdO1xuICBhY3RpdmVWaWV3OiBNYWluVmlldztcbiAgb25OYXZpZ2F0ZTogKHZpZXc6IE1haW5WaWV3KSA9PiB2b2lkO1xuICBvbk9wZW5TZWFyY2g6ICgpID0+IHZvaWQ7XG4gIHdvcmtzcGFjZVN3aXRjaGVyOiBSZWFjdE5vZGU7XG4gIGZvb3Rlcj86IFJlYWN0Tm9kZTtcbiAgb25IaWRlPzogKCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFNpZGViYXIoe1xuICB3aWR0aCA9IFNJREVCQVJfVjJfV0lEVEgsXG4gIGdyb3VwcyxcbiAgYWN0aXZlVmlldyxcbiAgb25OYXZpZ2F0ZSxcbiAgb25PcGVuU2VhcmNoLFxuICB3b3Jrc3BhY2VTd2l0Y2hlcixcbiAgZm9vdGVyLFxuICBvbkhpZGUsXG59OiBTaWRlYmFyUHJvcHMpOiBKU1guRWxlbWVudCB7XG4gIGNvbnN0IG5hdkdyb3VwcyA9IGdyb3VwcyA/PyBOQVZfR1JPVVBTO1xuICBjb25zdCBhY3RpdmVHcm91cElkID0gKG5hdkdyb3Vwcy5maW5kKChnKSA9PiBnLml0ZW1zLnNvbWUoKGkpID0+IGkudmlldyA9PT0gYWN0aXZlVmlldykpID8/IG5hdkdyb3Vwc1swXSkuaWQ7XG4gIGNvbnN0IFtleHBhbmRlZElkcywgc2V0RXhwYW5kZWRJZHNdID0gdXNlU3RhdGU8c3RyaW5nW10+KCgpID0+IFtcbiAgICBuYXZHcm91cHNbMF0uaWQsXG4gICAgYWN0aXZlR3JvdXBJZCxcbiAgXSk7XG5cbiAgLy8gS2VlcCB0aGUgZ3JvdXAgb3duaW5nIHRoZSBhY3RpdmUgdmlldyBleHBhbmRlZCBhcyBuYXZpZ2F0aW9uIGhhcHBlbnNcbiAgY29uc3QgZWZmZWN0aXZlRXhwYW5kZWQgPSBleHBhbmRlZElkcy5pbmNsdWRlcyhhY3RpdmVHcm91cElkKVxuICAgID8gZXhwYW5kZWRJZHNcbiAgICA6IFsuLi5leHBhbmRlZElkcywgYWN0aXZlR3JvdXBJZF07XG5cbiAgcmV0dXJuIChcbiAgICA8bmF2XG4gICAgICBhcmlhLWxhYmVsPVwiUHJpbWFyeVwiXG4gICAgICBzdHlsZT17eyB3aWR0aCB9fVxuICAgICAgY2xhc3NOYW1lPVwiZmxleCBoLWZ1bGwgc2hyaW5rLTAgZmxleC1jb2wgYm9yZGVyLXIgYm9yZGVyLWxpbmUgYmctcmFpbFwiXG4gICAgPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHBiLTMgcHQtNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC03IHctNyBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1tZCBiZy1zdXJmYWNlLTMgdGV4dC1bMTNweF0gZm9udC1ib2xkIHRleHQtaW5rXCI+XG4gICAgICAgICAgTUNcbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xIHRydW5jYXRlIHRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1pbmtcIj5cbiAgICAgICAgICBNaXNzaW9uIENvbnRyb2xcbiAgICAgICAgPC9zcGFuPlxuICAgICAgICB7b25IaWRlID8gKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17b25IaWRlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZCBwLTEgdGV4dC1pbmstbXV0ZWQgaG92ZXI6dGV4dC1pbmtcIlxuICAgICAgICAgICAgdGl0bGU9XCJIaWRlIHNpZGViYXJcIlxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkhpZGUgc2lkZWJhclwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPENoZXZyb25MZWZ0IHNpemU9ezE0fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApIDogbnVsbH1cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTMgcGItM1wiPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgb25DbGljaz17b25PcGVuU2VhcmNofVxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaC05IHctZnVsbCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xIHB4LTIuNSB0ZXh0LVsxM3B4XSB0ZXh0LWluay1tdXRlZCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgaG92ZXI6Ym9yZGVyLWxpbmUtc3Ryb25nIGhvdmVyOnRleHQtaW5rLXNlY29uZGFyeVwiXG4gICAgICAgID5cbiAgICAgICAgICA8U2VhcmNoIHNpemU9ezE0fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXgtMSB0ZXh0LWxlZnRcIj5TZWFyY2jigKY8L3NwYW4+XG4gICAgICAgICAgPGtiZCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMC41IHJvdW5kZWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMiBweC0xIHB5LTAuNSB0ZXh0LVsxMHB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgPENvbW1hbmQgc2l6ZT17OX0gYXJpYS1oaWRkZW4gLz5LXG4gICAgICAgICAgPC9rYmQ+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxXb3Jrc3BhY2VTd2l0Y2hlcj57d29ya3NwYWNlU3dpdGNoZXJ9PC9Xb3Jrc3BhY2VTd2l0Y2hlcj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHB4LTMgcHktMVwiPlxuICAgICAgICB7bmF2R3JvdXBzLm1hcCgoZ3JvdXApID0+IChcbiAgICAgICAgICA8U2lkZWJhclNlY3Rpb25cbiAgICAgICAgICAgIGtleT17Z3JvdXAuaWR9XG4gICAgICAgICAgICBncm91cD17Z3JvdXB9XG4gICAgICAgICAgICBhY3RpdmVWaWV3PXthY3RpdmVWaWV3fVxuICAgICAgICAgICAgZXhwYW5kZWQ9e2VmZmVjdGl2ZUV4cGFuZGVkLmluY2x1ZGVzKGdyb3VwLmlkKX1cbiAgICAgICAgICAgIG9uVG9nZ2xlPXsoKSA9PlxuICAgICAgICAgICAgICBzZXRFeHBhbmRlZElkcygoaWRzKSA9PlxuICAgICAgICAgICAgICAgIGlkcy5pbmNsdWRlcyhncm91cC5pZClcbiAgICAgICAgICAgICAgICAgID8gaWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSBncm91cC5pZClcbiAgICAgICAgICAgICAgICAgIDogWy4uLmlkcywgZ3JvdXAuaWRdXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG9uTmF2aWdhdGU9e29uTmF2aWdhdGV9XG4gICAgICAgICAgLz5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cblxuICAgICAge2Zvb3RlciAmJiA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1saW5lIHB4LTMgcHktM1wiPntmb290ZXJ9PC9kaXY+fVxuICAgIDwvbmF2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvc2hlbGxWMi9TaWRlYmFyLnRzeCJ9