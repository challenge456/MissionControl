import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/table.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/table.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const React = ((m) => m?.__esModule ? m : { ...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {}, default: m })(__vite__cjsImport3_react);
import { cn } from "/src/lib/utils.ts";
const Table = React.forwardRef(
  _c = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV("div", { className: "relative w-full overflow-auto rounded-xl border border-line bg-surface-1", children: /* @__PURE__ */ jsxDEV(
    "table",
    {
      ref,
      className: cn("w-full caption-bottom text-sm", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/table.tsx",
      lineNumber: 29,
      columnNumber: 5
    },
    this
  ) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/table.tsx",
    lineNumber: 28,
    columnNumber: 1
  }, this)
);
_c2 = Table;
Table.displayName = "Table";
const TableHeader = React.forwardRef(
  _c3 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "thead",
    {
      ref,
      className: cn("sticky top-0 z-[1] bg-surface-2 [&_tr]:border-b [&_tr]:border-line", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/table.tsx",
      lineNumber: 42,
      columnNumber: 1
    },
    this
  )
);
_c4 = TableHeader;
TableHeader.displayName = "TableHeader";
const TableBody = React.forwardRef(
  _c5 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "tbody",
    {
      ref,
      className: cn("[&_tr:last-child]:border-0", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/table.tsx",
      lineNumber: 54,
      columnNumber: 1
    },
    this
  )
);
_c6 = TableBody;
TableBody.displayName = "TableBody";
const TableFooter = React.forwardRef(
  _c7 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "tfoot",
    {
      ref,
      className: cn("border-t border-[var(--panel-line)] bg-[color:var(--shell-panel)] font-medium [&>tr]:last:border-b-0", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/table.tsx",
      lineNumber: 66,
      columnNumber: 1
    },
    this
  )
);
_c8 = TableFooter;
TableFooter.displayName = "TableFooter";
const TableRow = React.forwardRef(
  _c9 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "tr",
    {
      ref,
      className: cn(
        "border-b border-[var(--panel-line)] transition-colors hover:bg-registry-accent-soft data-[state=selected]:bg-registry-accent-soft",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/table.tsx",
      lineNumber: 78,
      columnNumber: 1
    },
    this
  )
);
_c0 = TableRow;
TableRow.displayName = "TableRow";
const TableHead = React.forwardRef(
  _c1 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "th",
    {
      ref,
      className: cn("h-10 px-4 text-left align-middle font-[family:var(--font-medium)] text-[0.7rem] font-semibold uppercase tracking-[0.06em] text-muted-foreground", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/table.tsx",
      lineNumber: 93,
      columnNumber: 1
    },
    this
  )
);
_c10 = TableHead;
TableHead.displayName = "TableHead";
const TableCell = React.forwardRef(
  _c11 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV("td", { ref, className: cn("px-4 py-3 align-middle", className), ...props }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/table.tsx",
    lineNumber: 105,
    columnNumber: 1
  }, this)
);
_c12 = TableCell;
TableCell.displayName = "TableCell";
const TableCaption = React.forwardRef(
  _c13 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "caption",
    {
      ref,
      className: cn("mt-3 text-sm text-muted-foreground", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/table.tsx",
      lineNumber: 113,
      columnNumber: 1
    },
    this
  )
);
_c14 = TableCaption;
TableCaption.displayName = "TableCaption";
export {
  Table,
  TableHeader,
  TableBody,
  TableFooter,
  TableHead,
  TableRow,
  TableCell,
  TableCaption
};
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0, _c1, _c10, _c11, _c12, _c13, _c14;
$RefreshReg$(_c, "Table$React.forwardRef");
$RefreshReg$(_c2, "Table");
$RefreshReg$(_c3, "TableHeader$React.forwardRef");
$RefreshReg$(_c4, "TableHeader");
$RefreshReg$(_c5, "TableBody$React.forwardRef");
$RefreshReg$(_c6, "TableBody");
$RefreshReg$(_c7, "TableFooter$React.forwardRef");
$RefreshReg$(_c8, "TableFooter");
$RefreshReg$(_c9, "TableRow$React.forwardRef");
$RefreshReg$(_c0, "TableRow");
$RefreshReg$(_c1, "TableHead$React.forwardRef");
$RefreshReg$(_c10, "TableHead");
$RefreshReg$(_c11, "TableCell$React.forwardRef");
$RefreshReg$(_c12, "TableCell");
$RefreshReg$(_c13, "TableCaption$React.forwardRef");
$RefreshReg$(_c14, "TableCaption");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/table.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/table.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU0k7Ozs7Ozs7Ozs7Ozs7Ozs7QUFUSixZQUFZQSxXQUFXO0FBRXZCLFNBQVNDLFVBQVU7QUFFbkIsTUFBTUMsUUFBUUYsTUFBTUc7QUFBQUEsRUFHbkJDLEtBQUNBLENBQUMsRUFBRUMsV0FBVyxHQUFHQyxNQUFNLEdBQUdDLFFBQzFCLHVCQUFDLFNBQUksV0FBVSw0RUFDYjtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0M7QUFBQSxNQUNBLFdBQVdOLEdBQUcsaUNBQWlDSSxTQUFTO0FBQUEsTUFDeEQsR0FBSUM7QUFBQUE7QUFBQUEsSUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFHWSxLQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FNQTtBQUNEO0FBQUNFLE1BWElOO0FBWU5BLE1BQU1PLGNBQWM7QUFFcEIsTUFBTUMsY0FBY1YsTUFBTUc7QUFBQUEsRUFHekJRLE1BQUNBLENBQUMsRUFBRU4sV0FBVyxHQUFHQyxNQUFNLEdBQUdDLFFBQzFCO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQztBQUFBLE1BQ0EsV0FBV04sR0FBRyxzRUFBc0VJLFNBQVM7QUFBQSxNQUM3RixHQUFJQztBQUFBQTtBQUFBQSxJQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUdZO0FBRWI7QUFBQ00sTUFUSUY7QUFVTkEsWUFBWUQsY0FBYztBQUUxQixNQUFNSSxZQUFZYixNQUFNRztBQUFBQSxFQUd2QlcsTUFBQ0EsQ0FBQyxFQUFFVCxXQUFXLEdBQUdDLE1BQU0sR0FBR0MsUUFDMUI7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXTixHQUFHLDhCQUE4QkksU0FBUztBQUFBLE1BQ3JELEdBQUlDO0FBQUFBO0FBQUFBLElBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBR1k7QUFFYjtBQUFDUyxNQVRJRjtBQVVOQSxVQUFVSixjQUFjO0FBRXhCLE1BQU1PLGNBQWNoQixNQUFNRztBQUFBQSxFQUd6QmMsTUFBQ0EsQ0FBQyxFQUFFWixXQUFXLEdBQUdDLE1BQU0sR0FBR0MsUUFDMUI7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXTixHQUFHLHdHQUF3R0ksU0FBUztBQUFBLE1BQy9ILEdBQUlDO0FBQUFBO0FBQUFBLElBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBR1k7QUFFYjtBQUFDWSxNQVRJRjtBQVVOQSxZQUFZUCxjQUFjO0FBRTFCLE1BQU1VLFdBQVduQixNQUFNRztBQUFBQSxFQUd0QmlCLE1BQUNBLENBQUMsRUFBRWYsV0FBVyxHQUFHQyxNQUFNLEdBQUdDLFFBQzFCO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQztBQUFBLE1BQ0EsV0FBV047QUFBQUEsUUFDVDtBQUFBLFFBQ0FJO0FBQUFBLE1BQ0Y7QUFBQSxNQUNBLEdBQUlDO0FBQUFBO0FBQUFBLElBTk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTVk7QUFFYjtBQUFDZSxNQVpJRjtBQWFOQSxTQUFTVixjQUFjO0FBRXZCLE1BQU1hLFlBQVl0QixNQUFNRztBQUFBQSxFQUd2Qm9CLE1BQUNBLENBQUMsRUFBRWxCLFdBQVcsR0FBR0MsTUFBTSxHQUFHQyxRQUMxQjtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0M7QUFBQSxNQUNBLFdBQVdOLEdBQUcsbUpBQW1KSSxTQUFTO0FBQUEsTUFDMUssR0FBSUM7QUFBQUE7QUFBQUEsSUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFHWTtBQUViO0FBQUNrQixPQVRJRjtBQVVOQSxVQUFVYixjQUFjO0FBRXhCLE1BQU1nQixZQUFZekIsTUFBTUc7QUFBQUEsRUFHdkJ1QixPQUFDQSxDQUFDLEVBQUVyQixXQUFXLEdBQUdDLE1BQU0sR0FBR0MsUUFDMUIsdUJBQUMsUUFBRyxLQUFVLFdBQVdOLEdBQUcsMEJBQTBCSSxTQUFTLEdBQUcsR0FBSUMsU0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0RTtBQUM3RTtBQUFDcUIsT0FMSUY7QUFNTkEsVUFBVWhCLGNBQWM7QUFFeEIsTUFBTW1CLGVBQWU1QixNQUFNRztBQUFBQSxFQUcxQjBCLE9BQUNBLENBQUMsRUFBRXhCLFdBQVcsR0FBR0MsTUFBTSxHQUFHQyxRQUMxQjtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0M7QUFBQSxNQUNBLFdBQVdOLEdBQUcsc0NBQXNDSSxTQUFTO0FBQUEsTUFDN0QsR0FBSUM7QUFBQUE7QUFBQUEsSUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFHWTtBQUViO0FBQUN3QixPQVRJRjtBQVVOQSxhQUFhbkIsY0FBYztBQUUzQjtBQUFBLEVBQ0VQO0FBQUFBLEVBQ0FRO0FBQUFBLEVBQ0FHO0FBQUFBLEVBQ0FHO0FBQUFBLEVBQ0FNO0FBQUFBLEVBQ0FIO0FBQUFBLEVBQ0FNO0FBQUFBLEVBQ0FHO0FBQUFBO0FBQ0QsSUFBQXhCLElBQUFJLEtBQUFHLEtBQUFDLEtBQUFFLEtBQUFDLEtBQUFFLEtBQUFDLEtBQUFFLEtBQUFDLEtBQUFFLEtBQUFDLE1BQUFFLE1BQUFDLE1BQUFFLE1BQUFDO0FBQUEsYUFBQTFCLElBQUE7QUFBQSxhQUFBSSxLQUFBO0FBQUEsYUFBQUcsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUMsTUFBQTtBQUFBLGFBQUFFLE1BQUE7QUFBQSxhQUFBQyxNQUFBO0FBQUEsYUFBQUUsTUFBQTtBQUFBLGFBQUFDLE1BQUEiLCJuYW1lcyI6WyJSZWFjdCIsImNuIiwiVGFibGUiLCJmb3J3YXJkUmVmIiwiX2MiLCJjbGFzc05hbWUiLCJwcm9wcyIsInJlZiIsIl9jMiIsImRpc3BsYXlOYW1lIiwiVGFibGVIZWFkZXIiLCJfYzMiLCJfYzQiLCJUYWJsZUJvZHkiLCJfYzUiLCJfYzYiLCJUYWJsZUZvb3RlciIsIl9jNyIsIl9jOCIsIlRhYmxlUm93IiwiX2M5IiwiX2MwIiwiVGFibGVIZWFkIiwiX2MxIiwiX2MxMCIsIlRhYmxlQ2VsbCIsIl9jMTEiLCJfYzEyIiwiVGFibGVDYXB0aW9uIiwiX2MxMyIsIl9jMTQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsidGFibGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiXG5cbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCJcblxuY29uc3QgVGFibGUgPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBIVE1MVGFibGVFbGVtZW50LFxuICBSZWFjdC5UYWJsZUhUTUxBdHRyaWJ1dGVzPEhUTUxUYWJsZUVsZW1lbnQ+XG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG92ZXJmbG93LWF1dG8gcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xXCI+XG4gICAgPHRhYmxlXG4gICAgICByZWY9e3JlZn1cbiAgICAgIGNsYXNzTmFtZT17Y24oXCJ3LWZ1bGwgY2FwdGlvbi1ib3R0b20gdGV4dC1zbVwiLCBjbGFzc05hbWUpfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIDwvZGl2PlxuKSlcblRhYmxlLmRpc3BsYXlOYW1lID0gXCJUYWJsZVwiXG5cbmNvbnN0IFRhYmxlSGVhZGVyID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgSFRNTFRhYmxlU2VjdGlvbkVsZW1lbnQsXG4gIFJlYWN0LkhUTUxBdHRyaWJ1dGVzPEhUTUxUYWJsZVNlY3Rpb25FbGVtZW50PlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8dGhlYWRcbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFwic3RpY2t5IHRvcC0wIHotWzFdIGJnLXN1cmZhY2UtMiBbJl90cl06Ym9yZGVyLWIgWyZfdHJdOmJvcmRlci1saW5lXCIsIGNsYXNzTmFtZSl9XG4gICAgey4uLnByb3BzfVxuICAvPlxuKSlcblRhYmxlSGVhZGVyLmRpc3BsYXlOYW1lID0gXCJUYWJsZUhlYWRlclwiXG5cbmNvbnN0IFRhYmxlQm9keSA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIEhUTUxUYWJsZVNlY3Rpb25FbGVtZW50LFxuICBSZWFjdC5IVE1MQXR0cmlidXRlczxIVE1MVGFibGVTZWN0aW9uRWxlbWVudD5cbj4oKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9LCByZWYpID0+IChcbiAgPHRib2R5XG4gICAgcmVmPXtyZWZ9XG4gICAgY2xhc3NOYW1lPXtjbihcIlsmX3RyOmxhc3QtY2hpbGRdOmJvcmRlci0wXCIsIGNsYXNzTmFtZSl9XG4gICAgey4uLnByb3BzfVxuICAvPlxuKSlcblRhYmxlQm9keS5kaXNwbGF5TmFtZSA9IFwiVGFibGVCb2R5XCJcblxuY29uc3QgVGFibGVGb290ZXIgPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBIVE1MVGFibGVTZWN0aW9uRWxlbWVudCxcbiAgUmVhY3QuSFRNTEF0dHJpYnV0ZXM8SFRNTFRhYmxlU2VjdGlvbkVsZW1lbnQ+XG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDx0Zm9vdFxuICAgIHJlZj17cmVmfVxuICAgIGNsYXNzTmFtZT17Y24oXCJib3JkZXItdCBib3JkZXItW3ZhcigtLXBhbmVsLWxpbmUpXSBiZy1bY29sb3I6dmFyKC0tc2hlbGwtcGFuZWwpXSBmb250LW1lZGl1bSBbJj50cl06bGFzdDpib3JkZXItYi0wXCIsIGNsYXNzTmFtZSl9XG4gICAgey4uLnByb3BzfVxuICAvPlxuKSlcblRhYmxlRm9vdGVyLmRpc3BsYXlOYW1lID0gXCJUYWJsZUZvb3RlclwiXG5cbmNvbnN0IFRhYmxlUm93ID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgSFRNTFRhYmxlUm93RWxlbWVudCxcbiAgUmVhY3QuSFRNTEF0dHJpYnV0ZXM8SFRNTFRhYmxlUm93RWxlbWVudD5cbj4oKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9LCByZWYpID0+IChcbiAgPHRyXG4gICAgcmVmPXtyZWZ9XG4gICAgY2xhc3NOYW1lPXtjbihcbiAgICAgIFwiYm9yZGVyLWIgYm9yZGVyLVt2YXIoLS1wYW5lbC1saW5lKV0gdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6YmctcmVnaXN0cnktYWNjZW50LXNvZnQgZGF0YS1bc3RhdGU9c2VsZWN0ZWRdOmJnLXJlZ2lzdHJ5LWFjY2VudC1zb2Z0XCIsXG4gICAgICBjbGFzc05hbWVcbiAgICApfVxuICAgIHsuLi5wcm9wc31cbiAgLz5cbikpXG5UYWJsZVJvdy5kaXNwbGF5TmFtZSA9IFwiVGFibGVSb3dcIlxuXG5jb25zdCBUYWJsZUhlYWQgPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBIVE1MVGFibGVDZWxsRWxlbWVudCxcbiAgUmVhY3QuVGhIVE1MQXR0cmlidXRlczxIVE1MVGFibGVDZWxsRWxlbWVudD5cbj4oKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9LCByZWYpID0+IChcbiAgPHRoXG4gICAgcmVmPXtyZWZ9XG4gICAgY2xhc3NOYW1lPXtjbihcImgtMTAgcHgtNCB0ZXh0LWxlZnQgYWxpZ24tbWlkZGxlIGZvbnQtW2ZhbWlseTp2YXIoLS1mb250LW1lZGl1bSldIHRleHQtWzAuN3JlbV0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMDZlbV0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIsIGNsYXNzTmFtZSl9XG4gICAgey4uLnByb3BzfVxuICAvPlxuKSlcblRhYmxlSGVhZC5kaXNwbGF5TmFtZSA9IFwiVGFibGVIZWFkXCJcblxuY29uc3QgVGFibGVDZWxsID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgSFRNTFRhYmxlQ2VsbEVsZW1lbnQsXG4gIFJlYWN0LlRkSFRNTEF0dHJpYnV0ZXM8SFRNTFRhYmxlQ2VsbEVsZW1lbnQ+XG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDx0ZCByZWY9e3JlZn0gY2xhc3NOYW1lPXtjbihcInB4LTQgcHktMyBhbGlnbi1taWRkbGVcIiwgY2xhc3NOYW1lKX0gey4uLnByb3BzfSAvPlxuKSlcblRhYmxlQ2VsbC5kaXNwbGF5TmFtZSA9IFwiVGFibGVDZWxsXCJcblxuY29uc3QgVGFibGVDYXB0aW9uID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgSFRNTFRhYmxlQ2FwdGlvbkVsZW1lbnQsXG4gIFJlYWN0LkhUTUxBdHRyaWJ1dGVzPEhUTUxUYWJsZUNhcHRpb25FbGVtZW50PlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8Y2FwdGlvblxuICAgIHJlZj17cmVmfVxuICAgIGNsYXNzTmFtZT17Y24oXCJtdC0zIHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIsIGNsYXNzTmFtZSl9XG4gICAgey4uLnByb3BzfVxuICAvPlxuKSlcblRhYmxlQ2FwdGlvbi5kaXNwbGF5TmFtZSA9IFwiVGFibGVDYXB0aW9uXCJcblxuZXhwb3J0IHtcbiAgVGFibGUsXG4gIFRhYmxlSGVhZGVyLFxuICBUYWJsZUJvZHksXG4gIFRhYmxlRm9vdGVyLFxuICBUYWJsZUhlYWQsXG4gIFRhYmxlUm93LFxuICBUYWJsZUNlbGwsXG4gIFRhYmxlQ2FwdGlvbixcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL2NvbXBvbmVudHMvdWkvdGFibGUudHN4In0=