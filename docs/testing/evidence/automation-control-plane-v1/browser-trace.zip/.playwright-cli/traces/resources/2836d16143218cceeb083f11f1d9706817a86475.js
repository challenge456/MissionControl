import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ActivityFeed.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { cn } from "/src/lib/utils.ts";
import {
  Ban,
  CheckCircle2,
  Eye,
  FileText,
  Inbox,
  MessageSquare,
  Pencil,
  Plus,
  Trash2,
  User,
  XCircle
} from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from "/src/components/ui/dialog.tsx";
import { EmptyState } from "/src/components/ui/empty-state.tsx";
export function ActivityFeed({ projectId, limit = 50 }) {
  _s();
  const activities = useQuery(
    api.activities.listRecent,
    projectId ? { projectId, limit } : { limit }
  );
  if (!activities) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2 p-5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "h-4 w-56 animate-pulse rounded bg-surface-2" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
        lineNumber: 60,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "h-4 w-72 animate-pulse rounded bg-surface-2" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
        lineNumber: 61,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "h-4 w-48 animate-pulse rounded bg-surface-2" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
        lineNumber: 62,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
      lineNumber: 59,
      columnNumber: 7
    }, this);
  }
  const getActivityIcon = (action) => {
    if (action.includes("CREATED")) return Plus;
    if (action.includes("UPDATED")) return Pencil;
    if (action.includes("DELETED")) return Trash2;
    if (action.includes("APPROVED")) return CheckCircle2;
    if (action.includes("DENIED")) return XCircle;
    if (action.includes("ASSIGNED")) return User;
    if (action.includes("COMPLETED")) return CheckCircle2;
    if (action.includes("BLOCKED")) return Ban;
    if (action.includes("REVIEW")) return Eye;
    if (action.includes("COMMENT")) return MessageSquare;
    return FileText;
  };
  const getActivityBorderClass = (action) => {
    if (action.includes("CREATED")) return "border-l-ok";
    if (action.includes("COMPLETED")) return "border-l-ok";
    if (action.includes("APPROVED")) return "border-l-ok";
    if (action.includes("DENIED")) return "border-l-err";
    if (action.includes("BLOCKED")) return "border-l-err";
    if (action.includes("DELETED")) return "border-l-err";
    if (action.includes("REVIEW")) return "border-l-info-accent";
    if (action.includes("ASSIGNED")) return "border-l-info-accent";
    return "border-l-line-strong";
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg bg-surface-1 p-4 max-h-[600px] overflow-auto", children: [
    /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-[15px] font-semibold text-ink", children: "Recent Activity" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
      lineNumber: 95,
      columnNumber: 7
    }, this),
    activities.length === 0 ? /* @__PURE__ */ jsxDEV(EmptyState, { icon: Inbox, title: "No activity yet", className: "border-none bg-transparent" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
      lineNumber: 98,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2", children: activities.map((activity) => {
      const Icon = getActivityIcon(activity.action);
      return /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: cn(
            "p-3 bg-surface-2 rounded-md border-l-2",
            getActivityBorderClass(activity.action)
          ),
          children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2.5", children: [
            /* @__PURE__ */ jsxDEV(Icon, { className: "mt-0.5 h-4 w-4 shrink-0 text-ink-muted", strokeWidth: 1.75 }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
              lineNumber: 112,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] text-ink mb-1", children: activity.description }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
                lineNumber: 114,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-[11.5px] text-ink-muted flex gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { children: activity.actorType }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
                  lineNumber: 118,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: "·" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
                  lineNumber: 119,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: new Date(activity._creationTime).toLocaleTimeString() }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
                  lineNumber: 120,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
                lineNumber: 117,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
              lineNumber: 113,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
            lineNumber: 111,
            columnNumber: 17
          }, this)
        },
        activity._id,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
          lineNumber: 104,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
      lineNumber: 100,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
    lineNumber: 94,
    columnNumber: 5
  }, this);
}
_s(ActivityFeed, "/JldKgXXBw55h00z9SNOA/B07rQ=", false, function() {
  return [useQuery];
});
_c = ActivityFeed;
export function ActivityFeedModal({ projectId, onClose }) {
  return /* @__PURE__ */ jsxDEV(Dialog, { open: true, onOpenChange: (open) => !open && onClose(), children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "max-w-[800px] max-h-[85vh] flex flex-col gap-0 p-0", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { className: "p-6 pb-4 border-b border-line", children: /* @__PURE__ */ jsxDEV(DialogTitle, { className: "text-[19px]", children: "Activity Feed" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
      lineNumber: 138,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
      lineNumber: 137,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-6 overflow-auto flex-1 min-h-0", children: /* @__PURE__ */ jsxDEV(ActivityFeed, { projectId, limit: 100 }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
      lineNumber: 141,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
      lineNumber: 140,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
    lineNumber: 136,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx",
    lineNumber: 135,
    columnNumber: 5
  }, this);
}
_c2 = ActivityFeedModal;
var _c, _c2;
$RefreshReg$(_c, "ActivityFeed");
$RefreshReg$(_c2, "ActivityFeedModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ActivityFeed.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0NROzs7Ozs7Ozs7Ozs7Ozs7OztBQXhDUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsV0FBVztBQUVwQixTQUFTQyxVQUFVO0FBQ25CO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FFSztBQUNQO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLGtCQUFrQjtBQU9wQixnQkFBU0MsYUFBYSxFQUFFQyxXQUFXQyxRQUFRLEdBQXNCLEdBQUc7QUFBQUMsS0FBQTtBQUN6RSxRQUFNQyxhQUFhdkI7QUFBQUEsSUFDakJDLElBQUlzQixXQUFXQztBQUFBQSxJQUNmSixZQUFZLEVBQUVBLFdBQVdDLE1BQU0sSUFBSSxFQUFFQSxNQUFNO0FBQUEsRUFDN0M7QUFFQSxNQUFJLENBQUNFLFlBQVk7QUFDZixXQUNFLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTREO0FBQUEsTUFDNUQsdUJBQUMsU0FBSSxXQUFVLGlEQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEQ7QUFBQSxNQUM1RCx1QkFBQyxTQUFJLFdBQVUsaURBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RDtBQUFBLFNBSDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLEVBRUo7QUFFQSxRQUFNRSxrQkFBa0JBLENBQUNDLFdBQStCO0FBQ3RELFFBQUlBLE9BQU9DLFNBQVMsU0FBUyxFQUFHLFFBQU9qQjtBQUN2QyxRQUFJZ0IsT0FBT0MsU0FBUyxTQUFTLEVBQUcsUUFBT2xCO0FBQ3ZDLFFBQUlpQixPQUFPQyxTQUFTLFNBQVMsRUFBRyxRQUFPaEI7QUFDdkMsUUFBSWUsT0FBT0MsU0FBUyxVQUFVLEVBQUcsUUFBT3ZCO0FBQ3hDLFFBQUlzQixPQUFPQyxTQUFTLFFBQVEsRUFBRyxRQUFPZDtBQUN0QyxRQUFJYSxPQUFPQyxTQUFTLFVBQVUsRUFBRyxRQUFPZjtBQUN4QyxRQUFJYyxPQUFPQyxTQUFTLFdBQVcsRUFBRyxRQUFPdkI7QUFDekMsUUFBSXNCLE9BQU9DLFNBQVMsU0FBUyxFQUFHLFFBQU94QjtBQUN2QyxRQUFJdUIsT0FBT0MsU0FBUyxRQUFRLEVBQUcsUUFBT3RCO0FBQ3RDLFFBQUlxQixPQUFPQyxTQUFTLFNBQVMsRUFBRyxRQUFPbkI7QUFDdkMsV0FBT0Y7QUFBQUEsRUFDVDtBQUVBLFFBQU1zQix5QkFBeUJBLENBQUNGLFdBQW1CO0FBQ2pELFFBQUlBLE9BQU9DLFNBQVMsU0FBUyxFQUFHLFFBQU87QUFDdkMsUUFBSUQsT0FBT0MsU0FBUyxXQUFXLEVBQUcsUUFBTztBQUN6QyxRQUFJRCxPQUFPQyxTQUFTLFVBQVUsRUFBRyxRQUFPO0FBQ3hDLFFBQUlELE9BQU9DLFNBQVMsUUFBUSxFQUFHLFFBQU87QUFDdEMsUUFBSUQsT0FBT0MsU0FBUyxTQUFTLEVBQUcsUUFBTztBQUN2QyxRQUFJRCxPQUFPQyxTQUFTLFNBQVMsRUFBRyxRQUFPO0FBQ3ZDLFFBQUlELE9BQU9DLFNBQVMsUUFBUSxFQUFHLFFBQU87QUFDdEMsUUFBSUQsT0FBT0MsU0FBUyxVQUFVLEVBQUcsUUFBTztBQUN4QyxXQUFPO0FBQUEsRUFDVDtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDJEQUNiO0FBQUEsMkJBQUMsUUFBRyxXQUFVLDJDQUEwQywrQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1RTtBQUFBLElBRXRFSixXQUFXTSxXQUFXLElBQ3JCLHVCQUFDLGNBQVcsTUFBTXRCLE9BQU8sT0FBTSxtQkFBa0IsV0FBVSxnQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1RixJQUV2Rix1QkFBQyxTQUFJLFdBQVUsdUJBQ1pnQixxQkFBV08sSUFBSSxDQUFDQyxhQUFhO0FBQzVCLFlBQU1DLE9BQU9QLGdCQUFnQk0sU0FBU0wsTUFBTTtBQUM1QyxhQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxXQUFXeEI7QUFBQUEsWUFDVDtBQUFBLFlBQ0EwQix1QkFBdUJHLFNBQVNMLE1BQU07QUFBQSxVQUN4QztBQUFBLFVBRUEsaUNBQUMsU0FBSSxXQUFVLDRCQUNiO0FBQUEsbUNBQUMsUUFBSyxXQUFVLDBDQUF5QyxhQUFhLFFBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJFO0FBQUEsWUFDM0UsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsNkJBQ1pLLG1CQUFTRSxlQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHVDQUFDLFVBQU1GLG1CQUFTRyxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQjtBQUFBLGdCQUMxQix1QkFBQyxVQUFLLGlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQU87QUFBQSxnQkFDUCx1QkFBQyxVQUFNLGNBQUlDLEtBQUtKLFNBQVNLLGFBQWEsRUFBRUMsbUJBQW1CLEtBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZEO0FBQUEsbUJBSC9EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxpQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsZUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUE7QUFBQSxRQWxCS04sU0FBU087QUFBQUEsUUFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQW9CQTtBQUFBLElBRUosQ0FBQyxLQTFCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkJBO0FBQUEsT0FqQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1DQTtBQUVKO0FBQUNoQixHQWhGZUgsY0FBWTtBQUFBLFVBQ1BuQixRQUFRO0FBQUE7QUFBQSxLQURibUI7QUFrRlQsZ0JBQVNvQixrQkFBa0IsRUFBRW5CLFdBQVdvQixRQUFtRSxHQUFHO0FBQ25ILFNBQ0UsdUJBQUMsVUFBTyxNQUFJLE1BQUMsY0FBYyxDQUFDQyxTQUFTLENBQUNBLFFBQVFELFFBQVEsR0FDcEQsaUNBQUMsaUJBQWMsV0FBVSxzREFDdkI7QUFBQSwyQkFBQyxnQkFBYSxXQUFVLGlDQUN0QixpQ0FBQyxlQUFZLFdBQVUsZUFBYyw2QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrRCxLQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSxvQ0FDYixpQ0FBQyxnQkFBYSxXQUFzQixPQUFPLE9BQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0MsS0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBU0E7QUFFSjtBQUFDRSxNQWJlSDtBQUFpQixJQUFBSSxJQUFBRDtBQUFBLGFBQUFDLElBQUE7QUFBQSxhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlUXVlcnkiLCJhcGkiLCJjbiIsIkJhbiIsIkNoZWNrQ2lyY2xlMiIsIkV5ZSIsIkZpbGVUZXh0IiwiSW5ib3giLCJNZXNzYWdlU3F1YXJlIiwiUGVuY2lsIiwiUGx1cyIsIlRyYXNoMiIsIlVzZXIiLCJYQ2lyY2xlIiwiRGlhbG9nIiwiRGlhbG9nQ29udGVudCIsIkRpYWxvZ0hlYWRlciIsIkRpYWxvZ1RpdGxlIiwiRW1wdHlTdGF0ZSIsIkFjdGl2aXR5RmVlZCIsInByb2plY3RJZCIsImxpbWl0IiwiX3MiLCJhY3Rpdml0aWVzIiwibGlzdFJlY2VudCIsImdldEFjdGl2aXR5SWNvbiIsImFjdGlvbiIsImluY2x1ZGVzIiwiZ2V0QWN0aXZpdHlCb3JkZXJDbGFzcyIsImxlbmd0aCIsIm1hcCIsImFjdGl2aXR5IiwiSWNvbiIsImRlc2NyaXB0aW9uIiwiYWN0b3JUeXBlIiwiRGF0ZSIsIl9jcmVhdGlvblRpbWUiLCJ0b0xvY2FsZVRpbWVTdHJpbmciLCJfaWQiLCJBY3Rpdml0eUZlZWRNb2RhbCIsIm9uQ2xvc2UiLCJvcGVuIiwiX2MyIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQWN0aXZpdHlGZWVkLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB0eXBlIHsgSWQgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvZGF0YU1vZGVsXCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiO1xuaW1wb3J0IHtcbiAgQmFuLFxuICBDaGVja0NpcmNsZTIsXG4gIEV5ZSxcbiAgRmlsZVRleHQsXG4gIEluYm94LFxuICBNZXNzYWdlU3F1YXJlLFxuICBQZW5jaWwsXG4gIFBsdXMsXG4gIFRyYXNoMixcbiAgVXNlcixcbiAgWENpcmNsZSxcbiAgdHlwZSBMdWNpZGVJY29uLFxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQge1xuICBEaWFsb2csXG4gIERpYWxvZ0NvbnRlbnQsXG4gIERpYWxvZ0hlYWRlcixcbiAgRGlhbG9nVGl0bGUsXG59IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvZGlhbG9nXCI7XG5pbXBvcnQgeyBFbXB0eVN0YXRlIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9lbXB0eS1zdGF0ZVwiO1xuXG5pbnRlcmZhY2UgQWN0aXZpdHlGZWVkUHJvcHMge1xuICBwcm9qZWN0SWQ6IElkPFwicHJvamVjdHNcIj4gfCBudWxsO1xuICBsaW1pdD86IG51bWJlcjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEFjdGl2aXR5RmVlZCh7IHByb2plY3RJZCwgbGltaXQgPSA1MCB9OiBBY3Rpdml0eUZlZWRQcm9wcykge1xuICBjb25zdCBhY3Rpdml0aWVzID0gdXNlUXVlcnkoXG4gICAgYXBpLmFjdGl2aXRpZXMubGlzdFJlY2VudCxcbiAgICBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCwgbGltaXQgfSA6IHsgbGltaXQgfVxuICApO1xuXG4gIGlmICghYWN0aXZpdGllcykge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTIgcC01XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC00IHctNTYgYW5pbWF0ZS1wdWxzZSByb3VuZGVkIGJnLXN1cmZhY2UtMlwiIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC00IHctNzIgYW5pbWF0ZS1wdWxzZSByb3VuZGVkIGJnLXN1cmZhY2UtMlwiIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC00IHctNDggYW5pbWF0ZS1wdWxzZSByb3VuZGVkIGJnLXN1cmZhY2UtMlwiIC8+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgY29uc3QgZ2V0QWN0aXZpdHlJY29uID0gKGFjdGlvbjogc3RyaW5nKTogTHVjaWRlSWNvbiA9PiB7XG4gICAgaWYgKGFjdGlvbi5pbmNsdWRlcyhcIkNSRUFURURcIikpIHJldHVybiBQbHVzO1xuICAgIGlmIChhY3Rpb24uaW5jbHVkZXMoXCJVUERBVEVEXCIpKSByZXR1cm4gUGVuY2lsO1xuICAgIGlmIChhY3Rpb24uaW5jbHVkZXMoXCJERUxFVEVEXCIpKSByZXR1cm4gVHJhc2gyO1xuICAgIGlmIChhY3Rpb24uaW5jbHVkZXMoXCJBUFBST1ZFRFwiKSkgcmV0dXJuIENoZWNrQ2lyY2xlMjtcbiAgICBpZiAoYWN0aW9uLmluY2x1ZGVzKFwiREVOSUVEXCIpKSByZXR1cm4gWENpcmNsZTtcbiAgICBpZiAoYWN0aW9uLmluY2x1ZGVzKFwiQVNTSUdORURcIikpIHJldHVybiBVc2VyO1xuICAgIGlmIChhY3Rpb24uaW5jbHVkZXMoXCJDT01QTEVURURcIikpIHJldHVybiBDaGVja0NpcmNsZTI7XG4gICAgaWYgKGFjdGlvbi5pbmNsdWRlcyhcIkJMT0NLRURcIikpIHJldHVybiBCYW47XG4gICAgaWYgKGFjdGlvbi5pbmNsdWRlcyhcIlJFVklFV1wiKSkgcmV0dXJuIEV5ZTtcbiAgICBpZiAoYWN0aW9uLmluY2x1ZGVzKFwiQ09NTUVOVFwiKSkgcmV0dXJuIE1lc3NhZ2VTcXVhcmU7XG4gICAgcmV0dXJuIEZpbGVUZXh0O1xuICB9O1xuXG4gIGNvbnN0IGdldEFjdGl2aXR5Qm9yZGVyQ2xhc3MgPSAoYWN0aW9uOiBzdHJpbmcpID0+IHtcbiAgICBpZiAoYWN0aW9uLmluY2x1ZGVzKFwiQ1JFQVRFRFwiKSkgcmV0dXJuIFwiYm9yZGVyLWwtb2tcIjtcbiAgICBpZiAoYWN0aW9uLmluY2x1ZGVzKFwiQ09NUExFVEVEXCIpKSByZXR1cm4gXCJib3JkZXItbC1va1wiO1xuICAgIGlmIChhY3Rpb24uaW5jbHVkZXMoXCJBUFBST1ZFRFwiKSkgcmV0dXJuIFwiYm9yZGVyLWwtb2tcIjtcbiAgICBpZiAoYWN0aW9uLmluY2x1ZGVzKFwiREVOSUVEXCIpKSByZXR1cm4gXCJib3JkZXItbC1lcnJcIjtcbiAgICBpZiAoYWN0aW9uLmluY2x1ZGVzKFwiQkxPQ0tFRFwiKSkgcmV0dXJuIFwiYm9yZGVyLWwtZXJyXCI7XG4gICAgaWYgKGFjdGlvbi5pbmNsdWRlcyhcIkRFTEVURURcIikpIHJldHVybiBcImJvcmRlci1sLWVyclwiO1xuICAgIGlmIChhY3Rpb24uaW5jbHVkZXMoXCJSRVZJRVdcIikpIHJldHVybiBcImJvcmRlci1sLWluZm8tYWNjZW50XCI7XG4gICAgaWYgKGFjdGlvbi5pbmNsdWRlcyhcIkFTU0lHTkVEXCIpKSByZXR1cm4gXCJib3JkZXItbC1pbmZvLWFjY2VudFwiO1xuICAgIHJldHVybiBcImJvcmRlci1sLWxpbmUtc3Ryb25nXCI7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYmctc3VyZmFjZS0xIHAtNCBtYXgtaC1bNjAwcHhdIG92ZXJmbG93LWF1dG9cIj5cbiAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj5SZWNlbnQgQWN0aXZpdHk8L2gzPlxuXG4gICAgICB7YWN0aXZpdGllcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgIDxFbXB0eVN0YXRlIGljb249e0luYm94fSB0aXRsZT1cIk5vIGFjdGl2aXR5IHlldFwiIGNsYXNzTmFtZT1cImJvcmRlci1ub25lIGJnLXRyYW5zcGFyZW50XCIgLz5cbiAgICAgICkgOiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMlwiPlxuICAgICAgICAgIHthY3Rpdml0aWVzLm1hcCgoYWN0aXZpdHkpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IEljb24gPSBnZXRBY3Rpdml0eUljb24oYWN0aXZpdHkuYWN0aW9uKTtcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBrZXk9e2FjdGl2aXR5Ll9pZH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgXCJwLTMgYmctc3VyZmFjZS0yIHJvdW5kZWQtbWQgYm9yZGVyLWwtMlwiLFxuICAgICAgICAgICAgICAgICAgZ2V0QWN0aXZpdHlCb3JkZXJDbGFzcyhhY3Rpdml0eS5hY3Rpb24pXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJtdC0wLjUgaC00IHctNCBzaHJpbmstMCB0ZXh0LWluay1tdXRlZFwiIHN0cm9rZVdpZHRoPXsxLjc1fSAvPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWluayBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2FjdGl2aXR5LmRlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMS41cHhdIHRleHQtaW5rLW11dGVkIGZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57YWN0aXZpdHkuYWN0b3JUeXBlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7Ctzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57bmV3IERhdGUoYWN0aXZpdHkuX2NyZWF0aW9uVGltZSkudG9Mb2NhbGVUaW1lU3RyaW5nKCl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEFjdGl2aXR5RmVlZE1vZGFsKHsgcHJvamVjdElkLCBvbkNsb3NlIH06IHsgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+IHwgbnVsbDsgb25DbG9zZTogKCkgPT4gdm9pZCB9KSB7XG4gIHJldHVybiAoXG4gICAgPERpYWxvZyBvcGVuIG9uT3BlbkNoYW5nZT17KG9wZW4pID0+ICFvcGVuICYmIG9uQ2xvc2UoKX0+XG4gICAgICA8RGlhbG9nQ29udGVudCBjbGFzc05hbWU9XCJtYXgtdy1bODAwcHhdIG1heC1oLVs4NXZoXSBmbGV4IGZsZXgtY29sIGdhcC0wIHAtMFwiPlxuICAgICAgICA8RGlhbG9nSGVhZGVyIGNsYXNzTmFtZT1cInAtNiBwYi00IGJvcmRlci1iIGJvcmRlci1saW5lXCI+XG4gICAgICAgICAgPERpYWxvZ1RpdGxlIGNsYXNzTmFtZT1cInRleHQtWzE5cHhdXCI+QWN0aXZpdHkgRmVlZDwvRGlhbG9nVGl0bGU+XG4gICAgICAgIDwvRGlhbG9nSGVhZGVyPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBvdmVyZmxvdy1hdXRvIGZsZXgtMSBtaW4taC0wXCI+XG4gICAgICAgICAgPEFjdGl2aXR5RmVlZCBwcm9qZWN0SWQ9e3Byb2plY3RJZH0gbGltaXQ9ezEwMH0gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0RpYWxvZ0NvbnRlbnQ+XG4gICAgPC9EaWFsb2c+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9BY3Rpdml0eUZlZWQudHN4In0=