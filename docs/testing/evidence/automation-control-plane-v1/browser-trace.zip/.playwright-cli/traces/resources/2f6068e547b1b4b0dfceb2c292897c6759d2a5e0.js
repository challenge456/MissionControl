import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/CommandPalette.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
  CommandShortcut
} from "/src/components/ui/command.tsx";
import {
  Bot,
  Plus,
  Shield,
  AlertTriangle,
  DollarSign,
  Radio,
  LayoutDashboard,
  ListTodo,
  Calendar,
  Activity,
  Radar,
  Factory,
  GitBranch,
  MessageSquare,
  Brain,
  Users,
  ClipboardList
} from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
export function CommandPalette({
  projectId,
  onClose,
  onSelectTask,
  onCreateTask,
  onOpenApprovals,
  onOpenAgents,
  onOpenControls,
  onOpenCostAnalytics,
  onOpenCreateAgent,
  onNavigateToGateway,
  onNavigateView
}) {
  _s();
  const [search, setSearch] = useState("");
  const searchResults = useQuery(
    api.search.searchAll,
    projectId && search.trim().length >= 2 ? { projectId, query: search.trim(), limit: 8 } : "skip"
  );
  const commands = useMemo(
    () => [
      { id: "new-task", label: "Create New Task", icon: /* @__PURE__ */ jsxDEV(Plus, { className: "h-4 w-4" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
        lineNumber: 94,
        columnNumber: 55
      }, this), shortcut: "Cmd+N", action: onCreateTask },
      { id: "open-approvals", label: "Open Approvals Center", icon: /* @__PURE__ */ jsxDEV(Shield, { className: "h-4 w-4" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
        lineNumber: 95,
        columnNumber: 67
      }, this), shortcut: "Cmd+Shift+A", action: onOpenApprovals },
      { id: "open-agents", label: "Open Agent Registry", icon: /* @__PURE__ */ jsxDEV(Bot, { className: "h-4 w-4" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
        lineNumber: 96,
        columnNumber: 62
      }, this), shortcut: "Cmd+2", action: onOpenAgents },
      ...onOpenCostAnalytics ? [{ id: "cost-analytics", label: "Cost Analytics", icon: /* @__PURE__ */ jsxDEV(DollarSign, { className: "h-4 w-4" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
        lineNumber: 97,
        columnNumber: 87
      }, this), shortcut: "Cmd+Shift+I", action: onOpenCostAnalytics }] : [],
      ...onOpenCreateAgent ? [{ id: "create-agent", label: "Create Agent", icon: /* @__PURE__ */ jsxDEV(Bot, { className: "h-4 w-4" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
        lineNumber: 98,
        columnNumber: 81
      }, this), shortcut: "", action: onOpenCreateAgent }] : [],
      ...onNavigateToGateway ? [{ id: "connect-gateway", label: "Connect Gateway", icon: /* @__PURE__ */ jsxDEV(Radio, { className: "h-4 w-4" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
        lineNumber: 99,
        columnNumber: 89
      }, this), shortcut: "", action: onNavigateToGateway }] : [],
      ...onOpenControls ? [{ id: "open-controls", label: "Open Operator Controls", icon: /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "h-4 w-4" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
        lineNumber: 101,
        columnNumber: 68
      }, this), shortcut: "Cmd+Shift+C", action: onOpenControls }] : []
    ],
    [onCreateTask, onOpenApprovals, onOpenAgents, onOpenControls, onOpenCostAnalytics, onOpenCreateAgent, onNavigateToGateway]
  );
  const filteredCommands = commands.filter(
    (command) => command.label.toLowerCase().includes(search.toLowerCase())
  );
  const navigateCommands = useMemo(() => {
    if (!onNavigateView) return [];
    const q = search.trim().toLowerCase();
    const all = [
      {
        id: "nav-home",
        label: "Go to Home",
        view: "home",
        icon: /* @__PURE__ */ jsxDEV(LayoutDashboard, { className: "h-4 w-4" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
          lineNumber: 126,
          columnNumber: 13
        }, this),
        value: "Go to Home dashboard home start"
      },
      {
        id: "nav-tasks",
        label: "Go to Tasks",
        view: "tasks",
        icon: /* @__PURE__ */ jsxDEV(ListTodo, { className: "h-4 w-4" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
          lineNumber: 133,
          columnNumber: 13
        }, this),
        value: "Go to Tasks board kanban inbox"
      },
      {
        id: "nav-agents",
        label: "Go to Agents",
        view: "agents",
        icon: /* @__PURE__ */ jsxDEV(Users, { className: "h-4 w-4" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
          lineNumber: 140,
          columnNumber: 13
        }, this),
        value: "Go to Agents registry squad"
      },
      {
        id: "nav-schedule",
        label: "Go to Schedule",
        view: "ops-schedule",
        icon: /* @__PURE__ */ jsxDEV(Calendar, { className: "h-4 w-4" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
          lineNumber: 147,
          columnNumber: 13
        }, this),
        value: "Go to Schedule ops calendar timeline operations"
      },
      {
        id: "nav-system",
        label: "Go to System",
        view: "system",
        icon: /* @__PURE__ */ jsxDEV(Activity, { className: "h-4 w-4" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
          lineNumber: 154,
          columnNumber: 13
        }, this),
        value: "Go to System platform health status"
      },
      {
        id: "nav-radar",
        label: "Go to Radar",
        view: "radar",
        icon: /* @__PURE__ */ jsxDEV(Radar, { className: "h-4 w-4" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
          lineNumber: 161,
          columnNumber: 13
        }, this),
        value: "Go to Radar alerts monitoring"
      },
      {
        id: "nav-factory",
        label: "Go to Factory",
        view: "factory",
        icon: /* @__PURE__ */ jsxDEV(Factory, { className: "h-4 w-4" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
          lineNumber: 168,
          columnNumber: 13
        }, this),
        value: "Go to Factory jobs batch scheduled"
      },
      {
        id: "nav-pipeline",
        label: "Go to Pipeline",
        view: "pipeline",
        icon: /* @__PURE__ */ jsxDEV(GitBranch, { className: "h-4 w-4" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
          lineNumber: 175,
          columnNumber: 13
        }, this),
        value: "Go to Pipeline content code crm"
      },
      {
        id: "nav-feedback",
        label: "Go to Feedback",
        view: "feedback",
        icon: /* @__PURE__ */ jsxDEV(MessageSquare, { className: "h-4 w-4" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
          lineNumber: 182,
          columnNumber: 13
        }, this),
        value: "Go to Feedback qc approvals findings"
      },
      {
        id: "nav-memory",
        label: "Go to Memory",
        view: "memory",
        icon: /* @__PURE__ */ jsxDEV(Brain, { className: "h-4 w-4" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
          lineNumber: 189,
          columnNumber: 13
        }, this),
        value: "Go to Memory journal knowledge"
      }
    ];
    if (!q) return all;
    return all.filter((item) => item.value.toLowerCase().includes(q));
  }, [onNavigateView, search]);
  const hasSearch = search.trim().length >= 2;
  const hasNoResults = hasSearch && !!searchResults && searchResults.totalResults === 0 && filteredCommands.length === 0 && navigateCommands.length === 0;
  return /* @__PURE__ */ jsxDEV(CommandDialog, { open: true, onOpenChange: (open) => {
    if (!open) onClose();
  }, children: [
    /* @__PURE__ */ jsxDEV(
      CommandInput,
      {
        value: search,
        onValueChange: setSearch,
        placeholder: "Search tasks, approvals, agents, or run a command..."
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
        lineNumber: 207,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(CommandList, { children: [
      /* @__PURE__ */ jsxDEV(CommandEmpty, { children: "No results found." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
        lineNumber: 213,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(CommandGroup, { heading: "Commands", children: (search ? filteredCommands : commands).map(
        (command) => /* @__PURE__ */ jsxDEV(
          CommandItem,
          {
            value: `${command.label}-${command.id}`,
            onSelect: () => {
              command.action();
              onClose();
            },
            children: [
              command.icon,
              /* @__PURE__ */ jsxDEV("span", { className: "flex-1", children: command.label }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
                lineNumber: 226,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(CommandShortcut, { children: command.shortcut }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
                lineNumber: 227,
                columnNumber: 15
              }, this)
            ]
          },
          command.id,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
            lineNumber: 217,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
        lineNumber: 215,
        columnNumber: 9
      }, this),
      onNavigateView && navigateCommands.length > 0 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(CommandSeparator, {}, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
          lineNumber: 234,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(CommandGroup, { heading: "Navigate", children: navigateCommands.map(
          (item) => /* @__PURE__ */ jsxDEV(
            CommandItem,
            {
              value: item.value,
              onSelect: () => {
                onNavigateView(item.view);
                onClose();
              },
              children: [
                item.icon,
                /* @__PURE__ */ jsxDEV("span", { className: "flex-1", children: item.label }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
                  lineNumber: 246,
                  columnNumber: 19
                }, this)
              ]
            },
            item.id,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
              lineNumber: 237,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
          lineNumber: 235,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
        lineNumber: 233,
        columnNumber: 9
      }, this),
      hasSearch && /* @__PURE__ */ jsxDEV(CommandSeparator, {}, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
        lineNumber: 253,
        columnNumber: 23
      }, this),
      hasSearch && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(CommandGroup, { heading: "Tasks", children: (searchResults?.tasks ?? []).map(
          (task) => /* @__PURE__ */ jsxDEV(
            CommandItem,
            {
              value: `${task.title}-${task._id}`,
              onSelect: () => {
                onSelectTask(task._id);
                onClose();
              },
              children: [
                /* @__PURE__ */ jsxDEV(ClipboardList, { className: "h-4 w-4 shrink-0 text-ink-muted", strokeWidth: 1.75 }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
                  lineNumber: 267,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "flex-1 min-w-0", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "block truncate text-sm", children: task.title }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
                    lineNumber: 269,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "block truncate text-xs text-muted-foreground", children: [
                    task.status,
                    " · ",
                    task.type,
                    " · P",
                    task.priority
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
                    lineNumber: 270,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
                  lineNumber: 268,
                  columnNumber: 19
                }, this)
              ]
            },
            task._id,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
              lineNumber: 259,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
          lineNumber: 257,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(CommandGroup, { heading: "Approvals", children: (searchResults?.approvals ?? []).map(
          (approval) => /* @__PURE__ */ jsxDEV(
            CommandItem,
            {
              value: `${approval.actionSummary}-${approval._id}`,
              onSelect: () => {
                if (!approval.taskId) return;
                onSelectTask(approval.taskId);
                onClose();
              },
              disabled: !approval.taskId,
              children: [
                /* @__PURE__ */ jsxDEV(Shield, { className: "h-4 w-4 shrink-0 text-ink-muted", strokeWidth: 1.75 }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
                  lineNumber: 290,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "flex-1 min-w-0", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "block truncate text-sm", children: approval.actionSummary }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
                    lineNumber: 292,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "block truncate text-xs text-muted-foreground", children: [
                    approval.status,
                    " · ",
                    approval.riskLevel,
                    " · ",
                    approval.actionType
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
                    lineNumber: 293,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
                  lineNumber: 291,
                  columnNumber: 19
                }, this)
              ]
            },
            approval._id,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
              lineNumber: 280,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
          lineNumber: 278,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(CommandGroup, { heading: "Agents", children: (searchResults?.agents ?? []).map(
          (agent) => /* @__PURE__ */ jsxDEV(
            CommandItem,
            {
              value: `${agent.name}-${agent._id}`,
              onSelect: () => {
                onOpenAgents();
                onClose();
              },
              children: [
                agent.emoji ? /* @__PURE__ */ jsxDEV("span", { className: "text-base leading-none", children: agent.emoji }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
                  lineNumber: 311,
                  columnNumber: 34
                }, this) : /* @__PURE__ */ jsxDEV(Bot, { className: "h-4 w-4 shrink-0 text-ink-muted", strokeWidth: 1.75 }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
                  lineNumber: 311,
                  columnNumber: 98
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "flex-1 min-w-0", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "block truncate text-sm", children: agent.name }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
                    lineNumber: 313,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "block truncate text-xs text-muted-foreground", children: [
                    agent.role,
                    " · ",
                    agent.status
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
                    lineNumber: 314,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
                  lineNumber: 312,
                  columnNumber: 19
                }, this)
              ]
            },
            agent._id,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
              lineNumber: 303,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
          lineNumber: 301,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
        lineNumber: 256,
        columnNumber: 9
      }, this),
      hasNoResults && /* @__PURE__ */ jsxDEV("div", { className: "px-3 py-6 text-center text-sm text-muted-foreground", children: [
        "No results for “",
        search,
        "”."
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
        lineNumber: 325,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
      lineNumber: 212,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx",
    lineNumber: 206,
    columnNumber: 5
  }, this);
}
_s(CommandPalette, "4BXEkS8kHm8up6aqSYBO/G7XL2g=", false, function() {
  return [useQuery];
});
_c = CommandPalette;
var _c;
$RefreshReg$(_c, "CommandPalette");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CommandPalette.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEV3RCxTQTJJOUMsVUEzSThDOzs7Ozs7Ozs7Ozs7Ozs7OztBQTFFeEQsU0FBU0EsU0FBU0MsZ0JBQWdDO0FBQ2xELFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxXQUFXO0FBR3BCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQWlCQSxnQkFBU0MsZUFBZTtBQUFBLEVBQzdCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNtQixHQUFHO0FBQUFDLEtBQUE7QUFDdEIsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUkxQyxTQUFTLEVBQUU7QUFFdkMsUUFBTTJDLGdCQUFnQjFDO0FBQUFBLElBQ3BCQyxJQUFJdUMsT0FBT0c7QUFBQUEsSUFDWGYsYUFBYVksT0FBT0ksS0FBSyxFQUFFQyxVQUFVLElBQ2pDLEVBQUVqQixXQUFXa0IsT0FBT04sT0FBT0ksS0FBSyxHQUFHRyxPQUFPLEVBQUUsSUFDNUM7QUFBQSxFQUNOO0FBRUEsUUFBTUMsV0FBV2xEO0FBQUFBLElBQ2YsTUFBTTtBQUFBLE1BQ0osRUFBRW1ELElBQUksWUFBWUMsT0FBTyxtQkFBbUJDLE1BQU0sdUJBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUIsR0FBS0MsVUFBVSxTQUFTQyxRQUFRdEIsYUFBYTtBQUFBLE1BQ3hILEVBQUVrQixJQUFJLGtCQUFrQkMsT0FBTyx5QkFBeUJDLE1BQU0sdUJBQUMsVUFBTyxXQUFVLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkIsR0FBS0MsVUFBVSxlQUFlQyxRQUFRckIsZ0JBQWdCO0FBQUEsTUFDL0ksRUFBRWlCLElBQUksZUFBZUMsT0FBTyx1QkFBdUJDLE1BQU0sdUJBQUMsT0FBSSxXQUFVLGFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QixHQUFLQyxVQUFVLFNBQVNDLFFBQVFwQixhQUFhO0FBQUEsTUFDOUgsR0FBSUUsc0JBQXNCLENBQUMsRUFBRWMsSUFBSSxrQkFBa0JDLE9BQU8sa0JBQWtCQyxNQUFNLHVCQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCLEdBQUtDLFVBQVUsZUFBZUMsUUFBUWxCLG9CQUFvQixDQUFDLElBQUk7QUFBQSxNQUNoTCxHQUFJQyxvQkFBb0IsQ0FBQyxFQUFFYSxJQUFJLGdCQUFnQkMsT0FBTyxnQkFBZ0JDLE1BQU0sdUJBQUMsT0FBSSxXQUFVLGFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QixHQUFLQyxVQUFVLElBQUlDLFFBQVFqQixrQkFBa0IsQ0FBQyxJQUFJO0FBQUEsTUFDdEosR0FBSUMsc0JBQXNCLENBQUMsRUFBRVksSUFBSSxtQkFBbUJDLE9BQU8sbUJBQW1CQyxNQUFNLHVCQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBCLEdBQUtDLFVBQVUsSUFBSUMsUUFBUWhCLG9CQUFvQixDQUFDLElBQUk7QUFBQSxNQUNsSyxHQUFJSCxpQkFDQSxDQUFDLEVBQUVlLElBQUksaUJBQWlCQyxPQUFPLDBCQUEwQkMsTUFBTSx1QkFBQyxpQkFBYyxXQUFVLGFBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0MsR0FBS0MsVUFBVSxlQUFlQyxRQUFRbkIsZUFBZSxDQUFDLElBQ3ZKO0FBQUEsSUFBRztBQUFBLElBRVQsQ0FBQ0gsY0FBY0MsaUJBQWlCQyxjQUFjQyxnQkFBZ0JDLHFCQUFxQkMsbUJBQW1CQyxtQkFBbUI7QUFBQSxFQUMzSDtBQUVBLFFBQU1pQixtQkFBbUJOLFNBQVNPO0FBQUFBLElBQU8sQ0FBQ0MsWUFDeENBLFFBQVFOLE1BQU1PLFlBQVksRUFBRUMsU0FBU2xCLE9BQU9pQixZQUFZLENBQUM7QUFBQSxFQUMzRDtBQUVBLFFBQU1FLG1CQUFtQjdELFFBQVEsTUFBTTtBQUNyQyxRQUFJLENBQUN3QyxlQUFnQixRQUFPO0FBQzVCLFVBQU1zQixJQUFJcEIsT0FBT0ksS0FBSyxFQUFFYSxZQUFZO0FBQ3BDLFVBQU1JLE1BT0E7QUFBQSxNQUNKO0FBQUEsUUFDRVosSUFBSTtBQUFBLFFBQ0pDLE9BQU87QUFBQSxRQUNQWSxNQUFNO0FBQUEsUUFDTlgsTUFBTSx1QkFBQyxtQkFBZ0IsV0FBVSxhQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DO0FBQUEsUUFDMUNZLE9BQU87QUFBQSxNQUNUO0FBQUEsTUFDQTtBQUFBLFFBQ0VkLElBQUk7QUFBQSxRQUNKQyxPQUFPO0FBQUEsUUFDUFksTUFBTTtBQUFBLFFBQ05YLE1BQU0sdUJBQUMsWUFBUyxXQUFVLGFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkI7QUFBQSxRQUNuQ1ksT0FBTztBQUFBLE1BQ1Q7QUFBQSxNQUNBO0FBQUEsUUFDRWQsSUFBSTtBQUFBLFFBQ0pDLE9BQU87QUFBQSxRQUNQWSxNQUFNO0FBQUEsUUFDTlgsTUFBTSx1QkFBQyxTQUFNLFdBQVUsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQjtBQUFBLFFBQ2hDWSxPQUFPO0FBQUEsTUFDVDtBQUFBLE1BQ0E7QUFBQSxRQUNFZCxJQUFJO0FBQUEsUUFDSkMsT0FBTztBQUFBLFFBQ1BZLE1BQU07QUFBQSxRQUNOWCxNQUFNLHVCQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZCO0FBQUEsUUFDbkNZLE9BQU87QUFBQSxNQUNUO0FBQUEsTUFDQTtBQUFBLFFBQ0VkLElBQUk7QUFBQSxRQUNKQyxPQUFPO0FBQUEsUUFDUFksTUFBTTtBQUFBLFFBQ05YLE1BQU0sdUJBQUMsWUFBUyxXQUFVLGFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkI7QUFBQSxRQUNuQ1ksT0FBTztBQUFBLE1BQ1Q7QUFBQSxNQUNBO0FBQUEsUUFDRWQsSUFBSTtBQUFBLFFBQ0pDLE9BQU87QUFBQSxRQUNQWSxNQUFNO0FBQUEsUUFDTlgsTUFBTSx1QkFBQyxTQUFNLFdBQVUsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQjtBQUFBLFFBQ2hDWSxPQUFPO0FBQUEsTUFDVDtBQUFBLE1BQ0E7QUFBQSxRQUNFZCxJQUFJO0FBQUEsUUFDSkMsT0FBTztBQUFBLFFBQ1BZLE1BQU07QUFBQSxRQUNOWCxNQUFNLHVCQUFDLFdBQVEsV0FBVSxhQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsUUFDbENZLE9BQU87QUFBQSxNQUNUO0FBQUEsTUFDQTtBQUFBLFFBQ0VkLElBQUk7QUFBQSxRQUNKQyxPQUFPO0FBQUEsUUFDUFksTUFBTTtBQUFBLFFBQ05YLE1BQU0sdUJBQUMsYUFBVSxXQUFVLGFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEI7QUFBQSxRQUNwQ1ksT0FBTztBQUFBLE1BQ1Q7QUFBQSxNQUNBO0FBQUEsUUFDRWQsSUFBSTtBQUFBLFFBQ0pDLE9BQU87QUFBQSxRQUNQWSxNQUFNO0FBQUEsUUFDTlgsTUFBTSx1QkFBQyxpQkFBYyxXQUFVLGFBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0M7QUFBQSxRQUN4Q1ksT0FBTztBQUFBLE1BQ1Q7QUFBQSxNQUNBO0FBQUEsUUFDRWQsSUFBSTtBQUFBLFFBQ0pDLE9BQU87QUFBQSxRQUNQWSxNQUFNO0FBQUEsUUFDTlgsTUFBTSx1QkFBQyxTQUFNLFdBQVUsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQjtBQUFBLFFBQ2hDWSxPQUFPO0FBQUEsTUFDVDtBQUFBLElBQUM7QUFFSCxRQUFJLENBQUNILEVBQUcsUUFBT0M7QUFDZixXQUFPQSxJQUFJTixPQUFPLENBQUNTLFNBQVNBLEtBQUtELE1BQU1OLFlBQVksRUFBRUMsU0FBU0UsQ0FBQyxDQUFDO0FBQUEsRUFDbEUsR0FBRyxDQUFDdEIsZ0JBQWdCRSxNQUFNLENBQUM7QUFFM0IsUUFBTXlCLFlBQVl6QixPQUFPSSxLQUFLLEVBQUVDLFVBQVU7QUFDMUMsUUFBTXFCLGVBQ0pELGFBQ0EsQ0FBQyxDQUFDdkIsaUJBQ0ZBLGNBQWN5QixpQkFBaUIsS0FDL0JiLGlCQUFpQlQsV0FBVyxLQUM1QmMsaUJBQWlCZCxXQUFXO0FBRTlCLFNBQ0UsdUJBQUMsaUJBQWMsTUFBSSxNQUFDLGNBQWMsQ0FBQ3VCLFNBQVM7QUFBRSxRQUFJLENBQUNBLEtBQU12QyxTQUFRO0FBQUEsRUFBRyxHQUNsRTtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFPVztBQUFBQSxRQUNQLGVBQWVDO0FBQUFBLFFBQ2YsYUFBWTtBQUFBO0FBQUEsTUFIZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHb0U7QUFBQSxJQUVwRSx1QkFBQyxlQUNDO0FBQUEsNkJBQUMsZ0JBQWEsaUNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQjtBQUFBLE1BRS9CLHVCQUFDLGdCQUFhLFNBQVEsWUFDbEJELG9CQUFTYyxtQkFBbUJOLFVBQVVxQjtBQUFBQSxRQUFJLENBQUNiLFlBQzNDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxPQUFPLEdBQUdBLFFBQVFOLEtBQUssSUFBSU0sUUFBUVAsRUFBRTtBQUFBLFlBQ3JDLFVBQVUsTUFBTTtBQUNkTyxzQkFBUUgsT0FBTztBQUNmeEIsc0JBQVE7QUFBQSxZQUNWO0FBQUEsWUFFQzJCO0FBQUFBLHNCQUFRTDtBQUFBQSxjQUNULHVCQUFDLFVBQUssV0FBVSxVQUFVSyxrQkFBUU4sU0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0M7QUFBQSxjQUN4Qyx1QkFBQyxtQkFBaUJNLGtCQUFRSixZQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQztBQUFBO0FBQUE7QUFBQSxVQVQ5QkksUUFBUVA7QUFBQUEsVUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBV0E7QUFBQSxNQUNELEtBZEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsTUFFQ1gsa0JBQWtCcUIsaUJBQWlCZCxTQUFTLEtBQzNDLG1DQUNFO0FBQUEsK0JBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQjtBQUFBLFFBQ2pCLHVCQUFDLGdCQUFhLFNBQVEsWUFDbkJjLDJCQUFpQlU7QUFBQUEsVUFBSSxDQUFDTCxTQUNyQjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsT0FBT0EsS0FBS0Q7QUFBQUEsY0FDWixVQUFVLE1BQU07QUFDZHpCLCtCQUFlMEIsS0FBS0YsSUFBSTtBQUN4QmpDLHdCQUFRO0FBQUEsY0FDVjtBQUFBLGNBRUNtQztBQUFBQSxxQkFBS2I7QUFBQUEsZ0JBQ04sdUJBQUMsVUFBSyxXQUFVLFVBQVVhLGVBQUtkLFNBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFDO0FBQUE7QUFBQTtBQUFBLFlBUmhDYyxLQUFLZjtBQUFBQSxZQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLFFBQ0QsS0FiSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0E7QUFBQSxXQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBO0FBQUEsTUFHRGdCLGFBQWEsdUJBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQjtBQUFBLE1BRTlCQSxhQUNDLG1DQUNFO0FBQUEsK0JBQUMsZ0JBQWEsU0FBUSxTQUNsQnZCLDBCQUFlNEIsU0FBUyxJQUFJRDtBQUFBQSxVQUFJLENBQUNFLFNBQ2pDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxPQUFPLEdBQUdBLEtBQUtDLEtBQUssSUFBSUQsS0FBS0UsR0FBRztBQUFBLGNBQ2hDLFVBQVUsTUFBTTtBQUNkM0MsNkJBQWF5QyxLQUFLRSxHQUFHO0FBQ3JCNUMsd0JBQVE7QUFBQSxjQUNWO0FBQUEsY0FFQTtBQUFBLHVDQUFDLGlCQUFjLFdBQVUsbUNBQWtDLGFBQWEsUUFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkU7QUFBQSxnQkFDN0UsdUJBQUMsVUFBSyxXQUFVLGtCQUNkO0FBQUEseUNBQUMsVUFBSyxXQUFVLDBCQUEwQjBDLGVBQUtDLFNBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFEO0FBQUEsa0JBQ3JELHVCQUFDLFVBQUssV0FBVSxnREFDYkQ7QUFBQUEseUJBQUtHO0FBQUFBLG9CQUFPO0FBQUEsb0JBQUlILEtBQUtJO0FBQUFBLG9CQUFLO0FBQUEsb0JBQUtKLEtBQUtLO0FBQUFBLHVCQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBO0FBQUE7QUFBQSxZQWJLTCxLQUFLRTtBQUFBQSxZQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFlQTtBQUFBLFFBQ0QsS0FsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFFBRUEsdUJBQUMsZ0JBQWEsU0FBUSxhQUNsQi9CLDBCQUFlbUMsYUFBYSxJQUFJUjtBQUFBQSxVQUFJLENBQUNTLGFBQ3JDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxPQUFPLEdBQUdBLFNBQVNDLGFBQWEsSUFBSUQsU0FBU0wsR0FBRztBQUFBLGNBQ2hELFVBQVUsTUFBTTtBQUNkLG9CQUFJLENBQUNLLFNBQVNFLE9BQVE7QUFDdEJsRCw2QkFBYWdELFNBQVNFLE1BQXFCO0FBQzNDbkQsd0JBQVE7QUFBQSxjQUNWO0FBQUEsY0FDQSxVQUFVLENBQUNpRCxTQUFTRTtBQUFBQSxjQUVwQjtBQUFBLHVDQUFDLFVBQU8sV0FBVSxtQ0FBa0MsYUFBYSxRQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzRTtBQUFBLGdCQUN0RSx1QkFBQyxVQUFLLFdBQVUsa0JBQ2Q7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsMEJBQTBCRixtQkFBU0MsaUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlFO0FBQUEsa0JBQ2pFLHVCQUFDLFVBQUssV0FBVSxnREFDYkQ7QUFBQUEsNkJBQVNKO0FBQUFBLG9CQUFPO0FBQUEsb0JBQUlJLFNBQVNHO0FBQUFBLG9CQUFVO0FBQUEsb0JBQUlILFNBQVNJO0FBQUFBLHVCQUR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBO0FBQUE7QUFBQSxZQWZLSixTQUFTTDtBQUFBQSxZQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBaUJBO0FBQUEsUUFDRCxLQXBCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUJBO0FBQUEsUUFFQSx1QkFBQyxnQkFBYSxTQUFRLFVBQ2xCL0IsMEJBQWV5QyxVQUFVLElBQUlkO0FBQUFBLFVBQUksQ0FBQ2UsVUFDbEM7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLE9BQU8sR0FBR0EsTUFBTUMsSUFBSSxJQUFJRCxNQUFNWCxHQUFHO0FBQUEsY0FDakMsVUFBVSxNQUFNO0FBQ2R4Qyw2QkFBYTtBQUNiSix3QkFBUTtBQUFBLGNBQ1Y7QUFBQSxjQUVDdUQ7QUFBQUEsc0JBQU1FLFFBQVEsdUJBQUMsVUFBSyxXQUFVLDBCQUEwQkYsZ0JBQU1FLFNBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNELElBQVUsdUJBQUMsT0FBSSxXQUFVLG1DQUFrQyxhQUFhLFFBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1FO0FBQUEsZ0JBQ2xKLHVCQUFDLFVBQUssV0FBVSxrQkFDZDtBQUFBLHlDQUFDLFVBQUssV0FBVSwwQkFBMEJGLGdCQUFNQyxRQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxRDtBQUFBLGtCQUNyRCx1QkFBQyxVQUFLLFdBQVUsZ0RBQ2JEO0FBQUFBLDBCQUFNRztBQUFBQSxvQkFBSztBQUFBLG9CQUFJSCxNQUFNVjtBQUFBQSx1QkFEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQTtBQUFBO0FBQUEsWUFiS1UsTUFBTVg7QUFBQUEsWUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBZUE7QUFBQSxRQUNELEtBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQkE7QUFBQSxXQWhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUVBO0FBQUEsTUFHRFAsZ0JBQ0MsdUJBQUMsU0FBSSxXQUFVLHVEQUFxRDtBQUFBO0FBQUEsUUFDM0MxQjtBQUFBQSxRQUFPO0FBQUEsV0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FuSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFIQTtBQUFBLE9BM0hGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0SEE7QUFFSjtBQUFDRCxHQXRRZVosZ0JBQWM7QUFBQSxVQWVOM0IsUUFBUTtBQUFBO0FBQUEsS0FmaEIyQjtBQUFjLElBQUE2RDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VNZW1vIiwidXNlU3RhdGUiLCJ1c2VRdWVyeSIsImFwaSIsIkNvbW1hbmREaWFsb2ciLCJDb21tYW5kRW1wdHkiLCJDb21tYW5kR3JvdXAiLCJDb21tYW5kSW5wdXQiLCJDb21tYW5kSXRlbSIsIkNvbW1hbmRMaXN0IiwiQ29tbWFuZFNlcGFyYXRvciIsIkNvbW1hbmRTaG9ydGN1dCIsIkJvdCIsIlBsdXMiLCJTaGllbGQiLCJBbGVydFRyaWFuZ2xlIiwiRG9sbGFyU2lnbiIsIlJhZGlvIiwiTGF5b3V0RGFzaGJvYXJkIiwiTGlzdFRvZG8iLCJDYWxlbmRhciIsIkFjdGl2aXR5IiwiUmFkYXIiLCJGYWN0b3J5IiwiR2l0QnJhbmNoIiwiTWVzc2FnZVNxdWFyZSIsIkJyYWluIiwiVXNlcnMiLCJDbGlwYm9hcmRMaXN0IiwiQ29tbWFuZFBhbGV0dGUiLCJwcm9qZWN0SWQiLCJvbkNsb3NlIiwib25TZWxlY3RUYXNrIiwib25DcmVhdGVUYXNrIiwib25PcGVuQXBwcm92YWxzIiwib25PcGVuQWdlbnRzIiwib25PcGVuQ29udHJvbHMiLCJvbk9wZW5Db3N0QW5hbHl0aWNzIiwib25PcGVuQ3JlYXRlQWdlbnQiLCJvbk5hdmlnYXRlVG9HYXRld2F5Iiwib25OYXZpZ2F0ZVZpZXciLCJfcyIsInNlYXJjaCIsInNldFNlYXJjaCIsInNlYXJjaFJlc3VsdHMiLCJzZWFyY2hBbGwiLCJ0cmltIiwibGVuZ3RoIiwicXVlcnkiLCJsaW1pdCIsImNvbW1hbmRzIiwiaWQiLCJsYWJlbCIsImljb24iLCJzaG9ydGN1dCIsImFjdGlvbiIsImZpbHRlcmVkQ29tbWFuZHMiLCJmaWx0ZXIiLCJjb21tYW5kIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsIm5hdmlnYXRlQ29tbWFuZHMiLCJxIiwiYWxsIiwidmlldyIsInZhbHVlIiwiaXRlbSIsImhhc1NlYXJjaCIsImhhc05vUmVzdWx0cyIsInRvdGFsUmVzdWx0cyIsIm9wZW4iLCJtYXAiLCJ0YXNrcyIsInRhc2siLCJ0aXRsZSIsIl9pZCIsInN0YXR1cyIsInR5cGUiLCJwcmlvcml0eSIsImFwcHJvdmFscyIsImFwcHJvdmFsIiwiYWN0aW9uU3VtbWFyeSIsInRhc2tJZCIsInJpc2tMZXZlbCIsImFjdGlvblR5cGUiLCJhZ2VudHMiLCJhZ2VudCIsIm5hbWUiLCJlbW9qaSIsInJvbGUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDb21tYW5kUGFsZXR0ZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUsIHR5cGUgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB0eXBlIHsgSWQgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvZGF0YU1vZGVsXCI7XG5pbXBvcnQgdHlwZSB7IE1haW5WaWV3IH0gZnJvbSBcIi4vVG9wTmF2XCI7XG5pbXBvcnQge1xuICBDb21tYW5kRGlhbG9nLFxuICBDb21tYW5kRW1wdHksXG4gIENvbW1hbmRHcm91cCxcbiAgQ29tbWFuZElucHV0LFxuICBDb21tYW5kSXRlbSxcbiAgQ29tbWFuZExpc3QsXG4gIENvbW1hbmRTZXBhcmF0b3IsXG4gIENvbW1hbmRTaG9ydGN1dCxcbn0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9jb21tYW5kXCI7XG5pbXBvcnQge1xuICBCb3QsXG4gIFBsdXMsXG4gIFNoaWVsZCxcbiAgQWxlcnRUcmlhbmdsZSxcbiAgRG9sbGFyU2lnbixcbiAgUmFkaW8sXG4gIExheW91dERhc2hib2FyZCxcbiAgTGlzdFRvZG8sXG4gIENhbGVuZGFyLFxuICBBY3Rpdml0eSxcbiAgUmFkYXIsXG4gIEZhY3RvcnksXG4gIEdpdEJyYW5jaCxcbiAgTWVzc2FnZVNxdWFyZSxcbiAgQnJhaW4sXG4gIFVzZXJzLFxuICBDbGlwYm9hcmRMaXN0LFxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5cbmludGVyZmFjZSBDb21tYW5kUGFsZXR0ZVByb3BzIHtcbiAgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+IHwgbnVsbDtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbiAgb25TZWxlY3RUYXNrOiAodGFza0lkOiBJZDxcInRhc2tzXCI+KSA9PiB2b2lkO1xuICBvbkNyZWF0ZVRhc2s6ICgpID0+IHZvaWQ7XG4gIG9uT3BlbkFwcHJvdmFsczogKCkgPT4gdm9pZDtcbiAgb25PcGVuQWdlbnRzOiAoKSA9PiB2b2lkO1xuICBvbk9wZW5Db250cm9scz86ICgpID0+IHZvaWQ7XG4gIG9uT3BlbkNvc3RBbmFseXRpY3M/OiAoKSA9PiB2b2lkO1xuICBvbk9wZW5DcmVhdGVBZ2VudD86ICgpID0+IHZvaWQ7XG4gIG9uTmF2aWdhdGVUb0dhdGV3YXk/OiAoKSA9PiB2b2lkO1xuICAvKiogSnVtcCB0byBhIG1haW4gdmlldyBhbmQgY2xvc2UgdGhlIHBhbGV0dGUgKi9cbiAgb25OYXZpZ2F0ZVZpZXc/OiAodmlldzogTWFpblZpZXcpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBDb21tYW5kUGFsZXR0ZSh7XG4gIHByb2plY3RJZCxcbiAgb25DbG9zZSxcbiAgb25TZWxlY3RUYXNrLFxuICBvbkNyZWF0ZVRhc2ssXG4gIG9uT3BlbkFwcHJvdmFscyxcbiAgb25PcGVuQWdlbnRzLFxuICBvbk9wZW5Db250cm9scyxcbiAgb25PcGVuQ29zdEFuYWx5dGljcyxcbiAgb25PcGVuQ3JlYXRlQWdlbnQsXG4gIG9uTmF2aWdhdGVUb0dhdGV3YXksXG4gIG9uTmF2aWdhdGVWaWV3LFxufTogQ29tbWFuZFBhbGV0dGVQcm9wcykge1xuICBjb25zdCBbc2VhcmNoLCBzZXRTZWFyY2hdID0gdXNlU3RhdGUoXCJcIik7XG5cbiAgY29uc3Qgc2VhcmNoUmVzdWx0cyA9IHVzZVF1ZXJ5KFxuICAgIGFwaS5zZWFyY2guc2VhcmNoQWxsLFxuICAgIHByb2plY3RJZCAmJiBzZWFyY2gudHJpbSgpLmxlbmd0aCA+PSAyXG4gICAgICA/IHsgcHJvamVjdElkLCBxdWVyeTogc2VhcmNoLnRyaW0oKSwgbGltaXQ6IDggfVxuICAgICAgOiBcInNraXBcIlxuICApO1xuXG4gIGNvbnN0IGNvbW1hbmRzID0gdXNlTWVtbyhcbiAgICAoKSA9PiBbXG4gICAgICB7IGlkOiBcIm5ldy10YXNrXCIsIGxhYmVsOiBcIkNyZWF0ZSBOZXcgVGFza1wiLCBpY29uOiA8UGx1cyBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz4sIHNob3J0Y3V0OiBcIkNtZCtOXCIsIGFjdGlvbjogb25DcmVhdGVUYXNrIH0sXG4gICAgICB7IGlkOiBcIm9wZW4tYXBwcm92YWxzXCIsIGxhYmVsOiBcIk9wZW4gQXBwcm92YWxzIENlbnRlclwiLCBpY29uOiA8U2hpZWxkIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPiwgc2hvcnRjdXQ6IFwiQ21kK1NoaWZ0K0FcIiwgYWN0aW9uOiBvbk9wZW5BcHByb3ZhbHMgfSxcbiAgICAgIHsgaWQ6IFwib3Blbi1hZ2VudHNcIiwgbGFiZWw6IFwiT3BlbiBBZ2VudCBSZWdpc3RyeVwiLCBpY29uOiA8Qm90IGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPiwgc2hvcnRjdXQ6IFwiQ21kKzJcIiwgYWN0aW9uOiBvbk9wZW5BZ2VudHMgfSxcbiAgICAgIC4uLihvbk9wZW5Db3N0QW5hbHl0aWNzID8gW3sgaWQ6IFwiY29zdC1hbmFseXRpY3NcIiwgbGFiZWw6IFwiQ29zdCBBbmFseXRpY3NcIiwgaWNvbjogPERvbGxhclNpZ24gY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+LCBzaG9ydGN1dDogXCJDbWQrU2hpZnQrSVwiLCBhY3Rpb246IG9uT3BlbkNvc3RBbmFseXRpY3MgfV0gOiBbXSksXG4gICAgICAuLi4ob25PcGVuQ3JlYXRlQWdlbnQgPyBbeyBpZDogXCJjcmVhdGUtYWdlbnRcIiwgbGFiZWw6IFwiQ3JlYXRlIEFnZW50XCIsIGljb246IDxCb3QgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+LCBzaG9ydGN1dDogXCJcIiwgYWN0aW9uOiBvbk9wZW5DcmVhdGVBZ2VudCB9XSA6IFtdKSxcbiAgICAgIC4uLihvbk5hdmlnYXRlVG9HYXRld2F5ID8gW3sgaWQ6IFwiY29ubmVjdC1nYXRld2F5XCIsIGxhYmVsOiBcIkNvbm5lY3QgR2F0ZXdheVwiLCBpY29uOiA8UmFkaW8gY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+LCBzaG9ydGN1dDogXCJcIiwgYWN0aW9uOiBvbk5hdmlnYXRlVG9HYXRld2F5IH1dIDogW10pLFxuICAgICAgLi4uKG9uT3BlbkNvbnRyb2xzXG4gICAgICAgID8gW3sgaWQ6IFwib3Blbi1jb250cm9sc1wiLCBsYWJlbDogXCJPcGVuIE9wZXJhdG9yIENvbnRyb2xzXCIsIGljb246IDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPiwgc2hvcnRjdXQ6IFwiQ21kK1NoaWZ0K0NcIiwgYWN0aW9uOiBvbk9wZW5Db250cm9scyB9XVxuICAgICAgICA6IFtdKSxcbiAgICBdLFxuICAgIFtvbkNyZWF0ZVRhc2ssIG9uT3BlbkFwcHJvdmFscywgb25PcGVuQWdlbnRzLCBvbk9wZW5Db250cm9scywgb25PcGVuQ29zdEFuYWx5dGljcywgb25PcGVuQ3JlYXRlQWdlbnQsIG9uTmF2aWdhdGVUb0dhdGV3YXldXG4gICk7XG5cbiAgY29uc3QgZmlsdGVyZWRDb21tYW5kcyA9IGNvbW1hbmRzLmZpbHRlcigoY29tbWFuZCkgPT5cbiAgICBjb21tYW5kLmxhYmVsLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoLnRvTG93ZXJDYXNlKCkpXG4gICk7XG5cbiAgY29uc3QgbmF2aWdhdGVDb21tYW5kcyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGlmICghb25OYXZpZ2F0ZVZpZXcpIHJldHVybiBbXTtcbiAgICBjb25zdCBxID0gc2VhcmNoLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuICAgIGNvbnN0IGFsbDoge1xuICAgICAgaWQ6IHN0cmluZztcbiAgICAgIGxhYmVsOiBzdHJpbmc7XG4gICAgICB2aWV3OiBNYWluVmlldztcbiAgICAgIGljb246IFJlYWN0Tm9kZTtcbiAgICAgIC8qKiBNYXRjaGVkIGJ5IGNtZGsgdmlhIHZhbHVlIHN0cmluZyAqL1xuICAgICAgdmFsdWU6IHN0cmluZztcbiAgICB9W10gPSBbXG4gICAgICB7XG4gICAgICAgIGlkOiBcIm5hdi1ob21lXCIsXG4gICAgICAgIGxhYmVsOiBcIkdvIHRvIEhvbWVcIixcbiAgICAgICAgdmlldzogXCJob21lXCIsXG4gICAgICAgIGljb246IDxMYXlvdXREYXNoYm9hcmQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+LFxuICAgICAgICB2YWx1ZTogXCJHbyB0byBIb21lIGRhc2hib2FyZCBob21lIHN0YXJ0XCIsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBpZDogXCJuYXYtdGFza3NcIixcbiAgICAgICAgbGFiZWw6IFwiR28gdG8gVGFza3NcIixcbiAgICAgICAgdmlldzogXCJ0YXNrc1wiLFxuICAgICAgICBpY29uOiA8TGlzdFRvZG8gY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+LFxuICAgICAgICB2YWx1ZTogXCJHbyB0byBUYXNrcyBib2FyZCBrYW5iYW4gaW5ib3hcIixcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGlkOiBcIm5hdi1hZ2VudHNcIixcbiAgICAgICAgbGFiZWw6IFwiR28gdG8gQWdlbnRzXCIsXG4gICAgICAgIHZpZXc6IFwiYWdlbnRzXCIsXG4gICAgICAgIGljb246IDxVc2VycyBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz4sXG4gICAgICAgIHZhbHVlOiBcIkdvIHRvIEFnZW50cyByZWdpc3RyeSBzcXVhZFwiLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgaWQ6IFwibmF2LXNjaGVkdWxlXCIsXG4gICAgICAgIGxhYmVsOiBcIkdvIHRvIFNjaGVkdWxlXCIsXG4gICAgICAgIHZpZXc6IFwib3BzLXNjaGVkdWxlXCIsXG4gICAgICAgIGljb246IDxDYWxlbmRhciBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz4sXG4gICAgICAgIHZhbHVlOiBcIkdvIHRvIFNjaGVkdWxlIG9wcyBjYWxlbmRhciB0aW1lbGluZSBvcGVyYXRpb25zXCIsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBpZDogXCJuYXYtc3lzdGVtXCIsXG4gICAgICAgIGxhYmVsOiBcIkdvIHRvIFN5c3RlbVwiLFxuICAgICAgICB2aWV3OiBcInN5c3RlbVwiLFxuICAgICAgICBpY29uOiA8QWN0aXZpdHkgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+LFxuICAgICAgICB2YWx1ZTogXCJHbyB0byBTeXN0ZW0gcGxhdGZvcm0gaGVhbHRoIHN0YXR1c1wiLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgaWQ6IFwibmF2LXJhZGFyXCIsXG4gICAgICAgIGxhYmVsOiBcIkdvIHRvIFJhZGFyXCIsXG4gICAgICAgIHZpZXc6IFwicmFkYXJcIixcbiAgICAgICAgaWNvbjogPFJhZGFyIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPixcbiAgICAgICAgdmFsdWU6IFwiR28gdG8gUmFkYXIgYWxlcnRzIG1vbml0b3JpbmdcIixcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGlkOiBcIm5hdi1mYWN0b3J5XCIsXG4gICAgICAgIGxhYmVsOiBcIkdvIHRvIEZhY3RvcnlcIixcbiAgICAgICAgdmlldzogXCJmYWN0b3J5XCIsXG4gICAgICAgIGljb246IDxGYWN0b3J5IGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPixcbiAgICAgICAgdmFsdWU6IFwiR28gdG8gRmFjdG9yeSBqb2JzIGJhdGNoIHNjaGVkdWxlZFwiLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgaWQ6IFwibmF2LXBpcGVsaW5lXCIsXG4gICAgICAgIGxhYmVsOiBcIkdvIHRvIFBpcGVsaW5lXCIsXG4gICAgICAgIHZpZXc6IFwicGlwZWxpbmVcIixcbiAgICAgICAgaWNvbjogPEdpdEJyYW5jaCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz4sXG4gICAgICAgIHZhbHVlOiBcIkdvIHRvIFBpcGVsaW5lIGNvbnRlbnQgY29kZSBjcm1cIixcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGlkOiBcIm5hdi1mZWVkYmFja1wiLFxuICAgICAgICBsYWJlbDogXCJHbyB0byBGZWVkYmFja1wiLFxuICAgICAgICB2aWV3OiBcImZlZWRiYWNrXCIsXG4gICAgICAgIGljb246IDxNZXNzYWdlU3F1YXJlIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPixcbiAgICAgICAgdmFsdWU6IFwiR28gdG8gRmVlZGJhY2sgcWMgYXBwcm92YWxzIGZpbmRpbmdzXCIsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBpZDogXCJuYXYtbWVtb3J5XCIsXG4gICAgICAgIGxhYmVsOiBcIkdvIHRvIE1lbW9yeVwiLFxuICAgICAgICB2aWV3OiBcIm1lbW9yeVwiLFxuICAgICAgICBpY29uOiA8QnJhaW4gY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+LFxuICAgICAgICB2YWx1ZTogXCJHbyB0byBNZW1vcnkgam91cm5hbCBrbm93bGVkZ2VcIixcbiAgICAgIH0sXG4gICAgXTtcbiAgICBpZiAoIXEpIHJldHVybiBhbGw7XG4gICAgcmV0dXJuIGFsbC5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0udmFsdWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxKSk7XG4gIH0sIFtvbk5hdmlnYXRlVmlldywgc2VhcmNoXSk7XG5cbiAgY29uc3QgaGFzU2VhcmNoID0gc2VhcmNoLnRyaW0oKS5sZW5ndGggPj0gMjtcbiAgY29uc3QgaGFzTm9SZXN1bHRzID1cbiAgICBoYXNTZWFyY2ggJiZcbiAgICAhIXNlYXJjaFJlc3VsdHMgJiZcbiAgICBzZWFyY2hSZXN1bHRzLnRvdGFsUmVzdWx0cyA9PT0gMCAmJlxuICAgIGZpbHRlcmVkQ29tbWFuZHMubGVuZ3RoID09PSAwICYmXG4gICAgbmF2aWdhdGVDb21tYW5kcy5sZW5ndGggPT09IDA7XG5cbiAgcmV0dXJuIChcbiAgICA8Q29tbWFuZERpYWxvZyBvcGVuIG9uT3BlbkNoYW5nZT17KG9wZW4pID0+IHsgaWYgKCFvcGVuKSBvbkNsb3NlKCk7IH19PlxuICAgICAgPENvbW1hbmRJbnB1dFxuICAgICAgICB2YWx1ZT17c2VhcmNofVxuICAgICAgICBvblZhbHVlQ2hhbmdlPXtzZXRTZWFyY2h9XG4gICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIHRhc2tzLCBhcHByb3ZhbHMsIGFnZW50cywgb3IgcnVuIGEgY29tbWFuZC4uLlwiXG4gICAgICAvPlxuICAgICAgPENvbW1hbmRMaXN0PlxuICAgICAgICA8Q29tbWFuZEVtcHR5Pk5vIHJlc3VsdHMgZm91bmQuPC9Db21tYW5kRW1wdHk+XG5cbiAgICAgICAgPENvbW1hbmRHcm91cCBoZWFkaW5nPVwiQ29tbWFuZHNcIj5cbiAgICAgICAgICB7KHNlYXJjaCA/IGZpbHRlcmVkQ29tbWFuZHMgOiBjb21tYW5kcykubWFwKChjb21tYW5kKSA9PiAoXG4gICAgICAgICAgICA8Q29tbWFuZEl0ZW1cbiAgICAgICAgICAgICAga2V5PXtjb21tYW5kLmlkfVxuICAgICAgICAgICAgICB2YWx1ZT17YCR7Y29tbWFuZC5sYWJlbH0tJHtjb21tYW5kLmlkfWB9XG4gICAgICAgICAgICAgIG9uU2VsZWN0PXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29tbWFuZC5hY3Rpb24oKTtcbiAgICAgICAgICAgICAgICBvbkNsb3NlKCk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtjb21tYW5kLmljb259XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXgtMVwiPntjb21tYW5kLmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPENvbW1hbmRTaG9ydGN1dD57Y29tbWFuZC5zaG9ydGN1dH08L0NvbW1hbmRTaG9ydGN1dD5cbiAgICAgICAgICAgIDwvQ29tbWFuZEl0ZW0+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvQ29tbWFuZEdyb3VwPlxuXG4gICAgICAgIHtvbk5hdmlnYXRlVmlldyAmJiBuYXZpZ2F0ZUNvbW1hbmRzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8Q29tbWFuZFNlcGFyYXRvciAvPlxuICAgICAgICAgICAgPENvbW1hbmRHcm91cCBoZWFkaW5nPVwiTmF2aWdhdGVcIj5cbiAgICAgICAgICAgICAge25hdmlnYXRlQ29tbWFuZHMubWFwKChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgPENvbW1hbmRJdGVtXG4gICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0uaWR9XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17aXRlbS52YWx1ZX1cbiAgICAgICAgICAgICAgICAgIG9uU2VsZWN0PXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIG9uTmF2aWdhdGVWaWV3KGl0ZW0udmlldyk7XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2UoKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge2l0ZW0uaWNvbn1cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXgtMVwiPntpdGVtLmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L0NvbW1hbmRJdGVtPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvQ29tbWFuZEdyb3VwPlxuICAgICAgICAgIDwvPlxuICAgICAgICApfVxuXG4gICAgICAgIHtoYXNTZWFyY2ggJiYgPENvbW1hbmRTZXBhcmF0b3IgLz59XG5cbiAgICAgICAge2hhc1NlYXJjaCAmJiAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxDb21tYW5kR3JvdXAgaGVhZGluZz1cIlRhc2tzXCI+XG4gICAgICAgICAgICAgIHsoc2VhcmNoUmVzdWx0cz8udGFza3MgPz8gW10pLm1hcCgodGFzaykgPT4gKFxuICAgICAgICAgICAgICAgIDxDb21tYW5kSXRlbVxuICAgICAgICAgICAgICAgICAga2V5PXt0YXNrLl9pZH1cbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtgJHt0YXNrLnRpdGxlfS0ke3Rhc2suX2lkfWB9XG4gICAgICAgICAgICAgICAgICBvblNlbGVjdD17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBvblNlbGVjdFRhc2sodGFzay5faWQpO1xuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlKCk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxDbGlwYm9hcmRMaXN0IGNsYXNzTmFtZT1cImgtNCB3LTQgc2hyaW5rLTAgdGV4dC1pbmstbXV0ZWRcIiBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRydW5jYXRlIHRleHQtc21cIj57dGFzay50aXRsZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRydW5jYXRlIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3Rhc2suc3RhdHVzfSDCtyB7dGFzay50eXBlfSDCtyBQe3Rhc2sucHJpb3JpdHl9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L0NvbW1hbmRJdGVtPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvQ29tbWFuZEdyb3VwPlxuXG4gICAgICAgICAgICA8Q29tbWFuZEdyb3VwIGhlYWRpbmc9XCJBcHByb3ZhbHNcIj5cbiAgICAgICAgICAgICAgeyhzZWFyY2hSZXN1bHRzPy5hcHByb3ZhbHMgPz8gW10pLm1hcCgoYXBwcm92YWwpID0+IChcbiAgICAgICAgICAgICAgICA8Q29tbWFuZEl0ZW1cbiAgICAgICAgICAgICAgICAgIGtleT17YXBwcm92YWwuX2lkfVxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Ake2FwcHJvdmFsLmFjdGlvblN1bW1hcnl9LSR7YXBwcm92YWwuX2lkfWB9XG4gICAgICAgICAgICAgICAgICBvblNlbGVjdD17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWFwcHJvdmFsLnRhc2tJZCkgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICBvblNlbGVjdFRhc2soYXBwcm92YWwudGFza0lkIGFzIElkPFwidGFza3NcIj4pO1xuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlKCk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFhcHByb3ZhbC50YXNrSWR9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFNoaWVsZCBjbGFzc05hbWU9XCJoLTQgdy00IHNocmluay0wIHRleHQtaW5rLW11dGVkXCIgc3Ryb2tlV2lkdGg9ezEuNzV9IC8+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayB0cnVuY2F0ZSB0ZXh0LXNtXCI+e2FwcHJvdmFsLmFjdGlvblN1bW1hcnl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayB0cnVuY2F0ZSB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHthcHByb3ZhbC5zdGF0dXN9IMK3IHthcHByb3ZhbC5yaXNrTGV2ZWx9IMK3IHthcHByb3ZhbC5hY3Rpb25UeXBlfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9Db21tYW5kSXRlbT5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L0NvbW1hbmRHcm91cD5cblxuICAgICAgICAgICAgPENvbW1hbmRHcm91cCBoZWFkaW5nPVwiQWdlbnRzXCI+XG4gICAgICAgICAgICAgIHsoc2VhcmNoUmVzdWx0cz8uYWdlbnRzID8/IFtdKS5tYXAoKGFnZW50KSA9PiAoXG4gICAgICAgICAgICAgICAgPENvbW1hbmRJdGVtXG4gICAgICAgICAgICAgICAgICBrZXk9e2FnZW50Ll9pZH1cbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtgJHthZ2VudC5uYW1lfS0ke2FnZW50Ll9pZH1gfVxuICAgICAgICAgICAgICAgICAgb25TZWxlY3Q9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgb25PcGVuQWdlbnRzKCk7XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2UoKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge2FnZW50LmVtb2ppID8gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1iYXNlIGxlYWRpbmctbm9uZVwiPnthZ2VudC5lbW9qaX08L3NwYW4+IDogPEJvdCBjbGFzc05hbWU9XCJoLTQgdy00IHNocmluay0wIHRleHQtaW5rLW11dGVkXCIgc3Ryb2tlV2lkdGg9ezEuNzV9IC8+fVxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgdHJ1bmNhdGUgdGV4dC1zbVwiPnthZ2VudC5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgdHJ1bmNhdGUgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7YWdlbnQucm9sZX0gwrcge2FnZW50LnN0YXR1c31cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvQ29tbWFuZEl0ZW0+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9Db21tYW5kR3JvdXA+XG4gICAgICAgICAgPC8+XG4gICAgICAgICl9XG5cbiAgICAgICAge2hhc05vUmVzdWx0cyAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC0zIHB5LTYgdGV4dC1jZW50ZXIgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgIE5vIHJlc3VsdHMgZm9yICZsZHF1bzt7c2VhcmNofSZyZHF1bzsuXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L0NvbW1hbmRMaXN0PlxuICAgIDwvQ29tbWFuZERpYWxvZz5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL0NvbW1hbmRQYWxldHRlLnRzeCJ9