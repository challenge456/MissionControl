import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/sections/OpsSection.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Sidebar } from "/src/Sidebar.tsx";
import { Kanban } from "/src/Kanban.tsx";
import { KanbanFilters } from "/src/KanbanFilters.tsx";
import { LiveFeed } from "/src/LiveFeed.tsx";
import { MissionDAGView } from "/src/MissionDAGView.tsx";
import { CalendarView } from "/src/CalendarView.tsx";
import { ScheduleView } from "/src/ScheduleView.tsx";
import { AuditView } from "/src/AuditView.tsx";
import { TelemetryView } from "/src/TelemetryView.tsx";
import { GoalsView } from "/src/GoalsView.tsx";
import { AutomationsView } from "/src/automations/AutomationsView.tsx?t=1785283753032";
import { PageHeader } from "/src/components/PageHeader.tsx";
import { TaskboardStats } from "/src/components/TaskboardStats.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { LoopDetectionPanel } from "/src/LoopDetectionPanel.tsx";
import { FileUp, Plus, PauseCircle, ShieldCheck, Users } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
export function OpsSection({
  currentView,
  projectId,
  taskCount,
  onTaskSelect,
  liveFeedExpanded,
  onToggleLiveFeed,
  kanbanFilters,
  onFiltersChange,
  sidebarSelectedAgentId: _sidebarSelectedAgentId,
  onAgentSelect,
  onSidebarWidthChange,
  onOpenApprovals,
  onOpenPolicy,
  onOpenOperatorControls,
  onOpenNotifications,
  onOpenStandup,
  onPauseSquad,
  onResumeSquad,
  onOpenImportPrd,
  onNavigate,
  onNewTask
}) {
  if (currentView === "tasks") {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex h-full min-h-0 w-full flex-1 overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV(
        Sidebar,
        {
          projectId,
          onOpenApprovals,
          onOpenPolicy,
          onOpenOperatorControls,
          onOpenNotifications,
          onOpenStandup,
          onPauseSquad,
          onResumeSquad,
          onAgentSelect,
          onWidthChange: onSidebarWidthChange
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
          lineNumber: 89,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("section", { className: "flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden", children: [
        /* @__PURE__ */ jsxDEV(
          PageHeader,
          {
            title: "Tasks",
            description: "Execution queue for active work orders",
            actions: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              onNewTask && /* @__PURE__ */ jsxDEV(
                Button,
                {
                  size: "sm",
                  className: "h-8 gap-1.5 text-xs font-medium bg-primary text-primary-foreground hover:bg-primary/90",
                  onClick: onNewTask,
                  children: [
                    /* @__PURE__ */ jsxDEV(Plus, { className: "h-3.5 w-3.5" }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
                      lineNumber: 113,
                      columnNumber: 21
                    }, this),
                    "New task"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
                  lineNumber: 108,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  variant: "outline",
                  size: "sm",
                  onClick: onOpenImportPrd,
                  className: "h-8 gap-1.5 text-xs font-medium border-border text-muted-foreground hover:bg-accent hover:text-foreground",
                  children: [
                    /* @__PURE__ */ jsxDEV(FileUp, { className: "h-3.5 w-3.5" }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
                      lineNumber: 123,
                      columnNumber: 19
                    }, this),
                    "Import PRD"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
                  lineNumber: 117,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  variant: "outline",
                  size: "sm",
                  onClick: onPauseSquad,
                  className: "h-8 gap-1.5 text-xs font-medium border-amber-500/30 text-amber-300 hover:bg-amber-500/10 hover:text-amber-200 hover:border-amber-400/50",
                  children: [
                    /* @__PURE__ */ jsxDEV(PauseCircle, { className: "h-3.5 w-3.5" }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
                      lineNumber: 132,
                      columnNumber: 19
                    }, this),
                    "Pause Squad"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
                  lineNumber: 126,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  variant: "outline",
                  size: "sm",
                  onClick: onOpenStandup,
                  className: "h-8 gap-1.5 text-xs font-medium",
                  children: [
                    /* @__PURE__ */ jsxDEV(Users, { className: "h-3.5 w-3.5" }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
                      lineNumber: 141,
                      columnNumber: 19
                    }, this),
                    "Standup"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
                  lineNumber: 135,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  variant: "outline",
                  size: "sm",
                  onClick: onOpenPolicy,
                  className: "h-8 gap-1.5 text-xs font-medium border-slate-500/50 hover:border-slate-400",
                  children: [
                    /* @__PURE__ */ jsxDEV(ShieldCheck, { className: "h-3.5 w-3.5" }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
                      lineNumber: 150,
                      columnNumber: 19
                    }, this),
                    "Policy"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
                  lineNumber: 144,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
              lineNumber: 106,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
            lineNumber: 102,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(TaskboardStats, { projectId }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
          lineNumber: 156,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          KanbanFilters,
          {
            projectId,
            currentUserId: "operator",
            filters: kanbanFilters,
            onFiltersChange
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
            lineNumber: 157,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-0 flex-1 flex-col overflow-hidden", children: [
          /* @__PURE__ */ jsxDEV(
            Kanban,
            {
              projectId,
              onSelectTask: onTaskSelect,
              filters: kanbanFilters
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
              lineNumber: 164,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(LoopDetectionPanel, { projectId, onTaskSelect }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
            lineNumber: 169,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
          lineNumber: 163,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
        lineNumber: 101,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        LiveFeed,
        {
          projectId,
          expanded: liveFeedExpanded,
          onToggle: onToggleLiveFeed,
          onTaskSelect,
          onExecutionSelect: () => onNavigate("control-work-orders")
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
          lineNumber: 172,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
      lineNumber: 88,
      columnNumber: 7
    }, this);
  }
  if (currentView === "goals") {
    return /* @__PURE__ */ jsxDEV(
      GoalsView,
      {
        projectId,
        onTaskSelect: (taskId) => {
          onTaskSelect(taskId);
          onNavigate("tasks");
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
        lineNumber: 185,
        columnNumber: 7
      },
      this
    );
  }
  if (currentView === "dag") {
    return /* @__PURE__ */ jsxDEV(
      MissionDAGView,
      {
        projectId,
        onTaskSelect: (taskId) => {
          onTaskSelect(taskId);
          onNavigate("tasks");
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
        lineNumber: 197,
        columnNumber: 7
      },
      this
    );
  }
  if (currentView === "calendar") return /* @__PURE__ */ jsxDEV(CalendarView, { projectId }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
    lineNumber: 207,
    columnNumber: 42
  }, this);
  if (currentView === "automations" || currentView === "automation-runs") {
    return /* @__PURE__ */ jsxDEV(AutomationsView, { projectId, forceRuns: currentView === "automation-runs" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
      lineNumber: 209,
      columnNumber: 12
    }, this);
  }
  if (currentView === "ops-schedule") {
    return /* @__PURE__ */ jsxDEV(
      ScheduleView,
      {
        projectId,
        onNavigate,
        onTaskSelect
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
        lineNumber: 213,
        columnNumber: 7
      },
      this
    );
  }
  if (currentView === "audit") return /* @__PURE__ */ jsxDEV(AuditView, { projectId }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
    lineNumber: 220,
    columnNumber: 39
  }, this);
  if (currentView === "telemetry") return /* @__PURE__ */ jsxDEV(TelemetryView, { projectId }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx",
    lineNumber: 221,
    columnNumber: 43
  }, this);
  return null;
}
_c = OpsSection;
var _c;
$RefreshReg$(_c, "OpsSection");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/OpsSection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUVROzs7Ozs7Ozs7Ozs7Ozs7O0FBbkVSLFNBQVNBLGVBQWU7QUFDeEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsMEJBQTBCO0FBQ25DLFNBQVNDLFFBQVFDLE1BQU1DLGFBQWFDLGFBQWFDLGFBQWE7QUEwQnZELGdCQUFTQyxXQUFXO0FBQUEsRUFDekJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLHdCQUF3QkM7QUFBQUEsRUFDeEJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ2UsR0FBRztBQUNsQixNQUFJckIsZ0JBQWdCLFNBQVM7QUFDM0IsV0FDRSx1QkFBQyxTQUFJLFdBQVUscURBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0EsZUFBZVc7QUFBQUE7QUFBQUEsUUFWakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BVXNDO0FBQUEsTUFFdEMsdUJBQUMsYUFBUSxXQUFVLHdEQUNqQjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixhQUFZO0FBQUEsWUFDWixTQUNFLHVCQUFDLFNBQUksV0FBVSwyQkFDWlU7QUFBQUEsMkJBQ0M7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixTQUFTQTtBQUFBQSxrQkFFVDtBQUFBLDJDQUFDLFFBQUssV0FBVSxpQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFML0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxjQUVGO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVE7QUFBQSxrQkFDUixNQUFLO0FBQUEsa0JBQ0wsU0FBU0Y7QUFBQUEsa0JBQ1QsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsVUFBTyxXQUFVLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU5qQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUTtBQUFBLGtCQUNSLE1BQUs7QUFBQSxrQkFDTCxTQUFTRjtBQUFBQSxrQkFDVCxXQUFVO0FBQUEsa0JBRVY7QUFBQSwyQ0FBQyxlQUFZLFdBQVUsaUJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFRO0FBQUEsa0JBQ1IsTUFBSztBQUFBLGtCQUNMLFNBQVNEO0FBQUFBLGtCQUNULFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLFNBQU0sV0FBVSxpQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFOaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVE7QUFBQSxrQkFDUixNQUFLO0FBQUEsa0JBQ0wsU0FBU0g7QUFBQUEsa0JBQ1QsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsZUFBWSxXQUFVLGlCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU50QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRQTtBQUFBLGlCQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQStDQTtBQUFBO0FBQUEsVUFuREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBb0RHO0FBQUEsUUFFSCx1QkFBQyxrQkFBZSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDO0FBQUEsUUFDckM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxlQUFjO0FBQUEsWUFDZCxTQUFTUDtBQUFBQSxZQUNUO0FBQUE7QUFBQSxVQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUltQztBQUFBLFFBRW5DLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQztBQUFBLGNBQ0EsY0FBY0g7QUFBQUEsY0FDZCxTQUFTRztBQUFBQTtBQUFBQSxZQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUd5QjtBQUFBLFVBRXpCLHVCQUFDLHNCQUFtQixXQUFzQixnQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUU7QUFBQSxhQU52RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQXJFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0VBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBLFVBQVVGO0FBQUFBLFVBQ1YsVUFBVUM7QUFBQUEsVUFDVjtBQUFBLFVBQ0EsbUJBQW1CLE1BQU1lLFdBQVcscUJBQXFCO0FBQUE7QUFBQSxRQUwzRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLNkQ7QUFBQSxTQXpGL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJGQTtBQUFBLEVBRUo7QUFFQSxNQUFJcEIsZ0JBQWdCLFNBQVM7QUFDM0IsV0FDRTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLGNBQWMsQ0FBQ3NCLFdBQVc7QUFDeEJuQix1QkFBYW1CLE1BQU07QUFDbkJGLHFCQUFXLE9BQU87QUFBQSxRQUNwQjtBQUFBO0FBQUEsTUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLSTtBQUFBLEVBR1I7QUFFQSxNQUFJcEIsZ0JBQWdCLE9BQU87QUFDekIsV0FDRTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLGNBQWMsQ0FBQ3NCLFdBQVc7QUFDeEJuQix1QkFBYW1CLE1BQU07QUFDbkJGLHFCQUFXLE9BQU87QUFBQSxRQUNwQjtBQUFBO0FBQUEsTUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLSTtBQUFBLEVBR1I7QUFFQSxNQUFJcEIsZ0JBQWdCLFdBQVksUUFBTyx1QkFBQyxnQkFBYSxhQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBbUM7QUFDMUUsTUFBSUEsZ0JBQWdCLGlCQUFpQkEsZ0JBQWdCLG1CQUFtQjtBQUN0RSxXQUFPLHVCQUFDLG1CQUFnQixXQUFzQixXQUFXQSxnQkFBZ0IscUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0Y7QUFBQSxFQUM3RjtBQUNBLE1BQUlBLGdCQUFnQixnQkFBZ0I7QUFDbEMsV0FDRTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBO0FBQUEsTUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHNkI7QUFBQSxFQUdqQztBQUNBLE1BQUlBLGdCQUFnQixRQUFTLFFBQU8sdUJBQUMsYUFBVSxhQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZ0M7QUFDcEUsTUFBSUEsZ0JBQWdCLFlBQWEsUUFBTyx1QkFBQyxpQkFBYyxhQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBb0M7QUFDNUUsU0FBTztBQUNUO0FBQUN1QixLQWhLZXhCO0FBQVUsSUFBQXdCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlNpZGViYXIiLCJLYW5iYW4iLCJLYW5iYW5GaWx0ZXJzIiwiTGl2ZUZlZWQiLCJNaXNzaW9uREFHVmlldyIsIkNhbGVuZGFyVmlldyIsIlNjaGVkdWxlVmlldyIsIkF1ZGl0VmlldyIsIlRlbGVtZXRyeVZpZXciLCJHb2Fsc1ZpZXciLCJBdXRvbWF0aW9uc1ZpZXciLCJQYWdlSGVhZGVyIiwiVGFza2JvYXJkU3RhdHMiLCJCdXR0b24iLCJMb29wRGV0ZWN0aW9uUGFuZWwiLCJGaWxlVXAiLCJQbHVzIiwiUGF1c2VDaXJjbGUiLCJTaGllbGRDaGVjayIsIlVzZXJzIiwiT3BzU2VjdGlvbiIsImN1cnJlbnRWaWV3IiwicHJvamVjdElkIiwidGFza0NvdW50Iiwib25UYXNrU2VsZWN0IiwibGl2ZUZlZWRFeHBhbmRlZCIsIm9uVG9nZ2xlTGl2ZUZlZWQiLCJrYW5iYW5GaWx0ZXJzIiwib25GaWx0ZXJzQ2hhbmdlIiwic2lkZWJhclNlbGVjdGVkQWdlbnRJZCIsIl9zaWRlYmFyU2VsZWN0ZWRBZ2VudElkIiwib25BZ2VudFNlbGVjdCIsIm9uU2lkZWJhcldpZHRoQ2hhbmdlIiwib25PcGVuQXBwcm92YWxzIiwib25PcGVuUG9saWN5Iiwib25PcGVuT3BlcmF0b3JDb250cm9scyIsIm9uT3Blbk5vdGlmaWNhdGlvbnMiLCJvbk9wZW5TdGFuZHVwIiwib25QYXVzZVNxdWFkIiwib25SZXN1bWVTcXVhZCIsIm9uT3BlbkltcG9ydFByZCIsIm9uTmF2aWdhdGUiLCJvbk5ld1Rhc2siLCJ0YXNrSWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJPcHNTZWN0aW9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHR5cGUgeyBNYWluVmlldyB9IGZyb20gXCIuLi9Ub3BOYXZcIjtcbmltcG9ydCB7IFNpZGViYXIgfSBmcm9tIFwiLi4vU2lkZWJhclwiO1xuaW1wb3J0IHsgS2FuYmFuIH0gZnJvbSBcIi4uL0thbmJhblwiO1xuaW1wb3J0IHsgS2FuYmFuRmlsdGVycyB9IGZyb20gXCIuLi9LYW5iYW5GaWx0ZXJzXCI7XG5pbXBvcnQgeyBMaXZlRmVlZCB9IGZyb20gXCIuLi9MaXZlRmVlZFwiO1xuaW1wb3J0IHsgTWlzc2lvbkRBR1ZpZXcgfSBmcm9tIFwiLi4vTWlzc2lvbkRBR1ZpZXdcIjtcbmltcG9ydCB7IENhbGVuZGFyVmlldyB9IGZyb20gXCIuLi9DYWxlbmRhclZpZXdcIjtcbmltcG9ydCB7IFNjaGVkdWxlVmlldyB9IGZyb20gXCIuLi9TY2hlZHVsZVZpZXdcIjtcbmltcG9ydCB7IEF1ZGl0VmlldyB9IGZyb20gXCIuLi9BdWRpdFZpZXdcIjtcbmltcG9ydCB7IFRlbGVtZXRyeVZpZXcgfSBmcm9tIFwiLi4vVGVsZW1ldHJ5Vmlld1wiO1xuaW1wb3J0IHsgR29hbHNWaWV3IH0gZnJvbSBcIi4uL0dvYWxzVmlld1wiO1xuaW1wb3J0IHsgQXV0b21hdGlvbnNWaWV3IH0gZnJvbSBcIi4uL2F1dG9tYXRpb25zL0F1dG9tYXRpb25zVmlld1wiO1xuaW1wb3J0IHsgUGFnZUhlYWRlciB9IGZyb20gXCIuLi9jb21wb25lbnRzL1BhZ2VIZWFkZXJcIjtcbmltcG9ydCB7IFRhc2tib2FyZFN0YXRzIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvVGFza2JvYXJkU3RhdHNcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQgeyBMb29wRGV0ZWN0aW9uUGFuZWwgfSBmcm9tIFwiLi4vTG9vcERldGVjdGlvblBhbmVsXCI7XG5pbXBvcnQgeyBGaWxlVXAsIFBsdXMsIFBhdXNlQ2lyY2xlLCBTaGllbGRDaGVjaywgVXNlcnMgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgT3BzU2VjdGlvblByb3BzIHtcbiAgY3VycmVudFZpZXc6IE1haW5WaWV3O1xuICBwcm9qZWN0SWQ6IElkPFwicHJvamVjdHNcIj4gfCBudWxsO1xuICB0YXNrQ291bnQ6IG51bWJlcjtcbiAgb25UYXNrU2VsZWN0OiAodGFza0lkOiBJZDxcInRhc2tzXCI+KSA9PiB2b2lkO1xuICBsaXZlRmVlZEV4cGFuZGVkOiBib29sZWFuO1xuICBvblRvZ2dsZUxpdmVGZWVkOiAoKSA9PiB2b2lkO1xuICBrYW5iYW5GaWx0ZXJzOiB7IGFnZW50czogc3RyaW5nW107IHByaW9yaXRpZXM6IG51bWJlcltdOyB0eXBlczogc3RyaW5nW10gfTtcbiAgb25GaWx0ZXJzQ2hhbmdlOiAoZjogeyBhZ2VudHM6IHN0cmluZ1tdOyBwcmlvcml0aWVzOiBudW1iZXJbXTsgdHlwZXM6IHN0cmluZ1tdIH0pID0+IHZvaWQ7XG4gIHNpZGViYXJTZWxlY3RlZEFnZW50SWQ6IElkPFwiYWdlbnRzXCI+IHwgbnVsbDtcbiAgb25BZ2VudFNlbGVjdDogKGFnZW50SWQ6IElkPFwiYWdlbnRzXCI+KSA9PiB2b2lkO1xuICBvblNpZGViYXJXaWR0aENoYW5nZTogKHc6IG51bWJlcikgPT4gdm9pZDtcbiAgb25PcGVuQXBwcm92YWxzOiAoKSA9PiB2b2lkO1xuICBvbk9wZW5Qb2xpY3k6ICgpID0+IHZvaWQ7XG4gIG9uT3Blbk9wZXJhdG9yQ29udHJvbHM6ICgpID0+IHZvaWQ7XG4gIG9uT3Blbk5vdGlmaWNhdGlvbnM6ICgpID0+IHZvaWQ7XG4gIG9uT3BlblN0YW5kdXA6ICgpID0+IHZvaWQ7XG4gIG9uUGF1c2VTcXVhZDogKCkgPT4gdm9pZDtcbiAgb25SZXN1bWVTcXVhZDogKCkgPT4gdm9pZDtcbiAgb25PcGVuSW1wb3J0UHJkOiAoKSA9PiB2b2lkO1xuICBvbk5hdmlnYXRlOiAodmlldzogTWFpblZpZXcpID0+IHZvaWQ7XG4gIG9uTmV3VGFzaz86ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBPcHNTZWN0aW9uKHtcbiAgY3VycmVudFZpZXcsXG4gIHByb2plY3RJZCxcbiAgdGFza0NvdW50LFxuICBvblRhc2tTZWxlY3QsXG4gIGxpdmVGZWVkRXhwYW5kZWQsXG4gIG9uVG9nZ2xlTGl2ZUZlZWQsXG4gIGthbmJhbkZpbHRlcnMsXG4gIG9uRmlsdGVyc0NoYW5nZSxcbiAgc2lkZWJhclNlbGVjdGVkQWdlbnRJZDogX3NpZGViYXJTZWxlY3RlZEFnZW50SWQsXG4gIG9uQWdlbnRTZWxlY3QsXG4gIG9uU2lkZWJhcldpZHRoQ2hhbmdlLFxuICBvbk9wZW5BcHByb3ZhbHMsXG4gIG9uT3BlblBvbGljeSxcbiAgb25PcGVuT3BlcmF0b3JDb250cm9scyxcbiAgb25PcGVuTm90aWZpY2F0aW9ucyxcbiAgb25PcGVuU3RhbmR1cCxcbiAgb25QYXVzZVNxdWFkLFxuICBvblJlc3VtZVNxdWFkLFxuICBvbk9wZW5JbXBvcnRQcmQsXG4gIG9uTmF2aWdhdGUsXG4gIG9uTmV3VGFzayxcbn06IE9wc1NlY3Rpb25Qcm9wcykge1xuICBpZiAoY3VycmVudFZpZXcgPT09IFwidGFza3NcIikge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1mdWxsIG1pbi1oLTAgdy1mdWxsIGZsZXgtMSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgPFNpZGViYXJcbiAgICAgICAgICBwcm9qZWN0SWQ9e3Byb2plY3RJZH1cbiAgICAgICAgICBvbk9wZW5BcHByb3ZhbHM9e29uT3BlbkFwcHJvdmFsc31cbiAgICAgICAgICBvbk9wZW5Qb2xpY3k9e29uT3BlblBvbGljeX1cbiAgICAgICAgICBvbk9wZW5PcGVyYXRvckNvbnRyb2xzPXtvbk9wZW5PcGVyYXRvckNvbnRyb2xzfVxuICAgICAgICAgIG9uT3Blbk5vdGlmaWNhdGlvbnM9e29uT3Blbk5vdGlmaWNhdGlvbnN9XG4gICAgICAgICAgb25PcGVuU3RhbmR1cD17b25PcGVuU3RhbmR1cH1cbiAgICAgICAgICBvblBhdXNlU3F1YWQ9e29uUGF1c2VTcXVhZH1cbiAgICAgICAgICBvblJlc3VtZVNxdWFkPXtvblJlc3VtZVNxdWFkfVxuICAgICAgICAgIG9uQWdlbnRTZWxlY3Q9e29uQWdlbnRTZWxlY3R9XG4gICAgICAgICAgb25XaWR0aENoYW5nZT17b25TaWRlYmFyV2lkdGhDaGFuZ2V9XG4gICAgICAgIC8+XG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImZsZXggbWluLWgtMCBtaW4tdy0wIGZsZXgtMSBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICA8UGFnZUhlYWRlclxuICAgICAgICAgICAgdGl0bGU9XCJUYXNrc1wiXG4gICAgICAgICAgICBkZXNjcmlwdGlvbj1cIkV4ZWN1dGlvbiBxdWV1ZSBmb3IgYWN0aXZlIHdvcmsgb3JkZXJzXCJcbiAgICAgICAgICAgIGFjdGlvbnM9e1xuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAge29uTmV3VGFzayAmJiAoXG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOCBnYXAtMS41IHRleHQteHMgZm9udC1tZWRpdW0gYmctcHJpbWFyeSB0ZXh0LXByaW1hcnktZm9yZWdyb3VuZCBob3ZlcjpiZy1wcmltYXJ5LzkwXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17b25OZXdUYXNrfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIE5ldyB0YXNrXG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbk9wZW5JbXBvcnRQcmR9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggZ2FwLTEuNSB0ZXh0LXhzIGZvbnQtbWVkaXVtIGJvcmRlci1ib3JkZXIgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGhvdmVyOmJnLWFjY2VudCBob3Zlcjp0ZXh0LWZvcmVncm91bmRcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxGaWxlVXAgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgSW1wb3J0IFBSRFxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvblBhdXNlU3F1YWR9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggZ2FwLTEuNSB0ZXh0LXhzIGZvbnQtbWVkaXVtIGJvcmRlci1hbWJlci01MDAvMzAgdGV4dC1hbWJlci0zMDAgaG92ZXI6YmctYW1iZXItNTAwLzEwIGhvdmVyOnRleHQtYW1iZXItMjAwIGhvdmVyOmJvcmRlci1hbWJlci00MDAvNTBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxQYXVzZUNpcmNsZSBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICBQYXVzZSBTcXVhZFxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbk9wZW5TdGFuZHVwfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IGdhcC0xLjUgdGV4dC14cyBmb250LW1lZGl1bVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFVzZXJzIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgIFN0YW5kdXBcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17b25PcGVuUG9saWN5fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IGdhcC0xLjUgdGV4dC14cyBmb250LW1lZGl1bSBib3JkZXItc2xhdGUtNTAwLzUwIGhvdmVyOmJvcmRlci1zbGF0ZS00MDBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICBQb2xpY3lcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8VGFza2JvYXJkU3RhdHMgcHJvamVjdElkPXtwcm9qZWN0SWR9IC8+XG4gICAgICAgICAgPEthbmJhbkZpbHRlcnNcbiAgICAgICAgICAgIHByb2plY3RJZD17cHJvamVjdElkfVxuICAgICAgICAgICAgY3VycmVudFVzZXJJZD1cIm9wZXJhdG9yXCJcbiAgICAgICAgICAgIGZpbHRlcnM9e2thbmJhbkZpbHRlcnN9XG4gICAgICAgICAgICBvbkZpbHRlcnNDaGFuZ2U9e29uRmlsdGVyc0NoYW5nZX1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC0wIGZsZXgtMSBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgIDxLYW5iYW5cbiAgICAgICAgICAgICAgcHJvamVjdElkPXtwcm9qZWN0SWR9XG4gICAgICAgICAgICAgIG9uU2VsZWN0VGFzaz17b25UYXNrU2VsZWN0fVxuICAgICAgICAgICAgICBmaWx0ZXJzPXtrYW5iYW5GaWx0ZXJzfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxMb29wRGV0ZWN0aW9uUGFuZWwgcHJvamVjdElkPXtwcm9qZWN0SWR9IG9uVGFza1NlbGVjdD17b25UYXNrU2VsZWN0fSAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L3NlY3Rpb24+XG4gICAgICAgIDxMaXZlRmVlZFxuICAgICAgICAgIHByb2plY3RJZD17cHJvamVjdElkfVxuICAgICAgICAgIGV4cGFuZGVkPXtsaXZlRmVlZEV4cGFuZGVkfVxuICAgICAgICAgIG9uVG9nZ2xlPXtvblRvZ2dsZUxpdmVGZWVkfVxuICAgICAgICAgIG9uVGFza1NlbGVjdD17b25UYXNrU2VsZWN0fVxuICAgICAgICAgIG9uRXhlY3V0aW9uU2VsZWN0PXsoKSA9PiBvbk5hdmlnYXRlKFwiY29udHJvbC13b3JrLW9yZGVyc1wiKX1cbiAgICAgICAgLz5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICBpZiAoY3VycmVudFZpZXcgPT09IFwiZ29hbHNcIikge1xuICAgIHJldHVybiAoXG4gICAgICA8R29hbHNWaWV3XG4gICAgICAgIHByb2plY3RJZD17cHJvamVjdElkfVxuICAgICAgICBvblRhc2tTZWxlY3Q9eyh0YXNrSWQpID0+IHtcbiAgICAgICAgICBvblRhc2tTZWxlY3QodGFza0lkKTtcbiAgICAgICAgICBvbk5hdmlnYXRlKFwidGFza3NcIik7XG4gICAgICAgIH19XG4gICAgICAvPlxuICAgICk7XG4gIH1cblxuICBpZiAoY3VycmVudFZpZXcgPT09IFwiZGFnXCIpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPE1pc3Npb25EQUdWaWV3XG4gICAgICAgIHByb2plY3RJZD17cHJvamVjdElkfVxuICAgICAgICBvblRhc2tTZWxlY3Q9eyh0YXNrSWQpID0+IHtcbiAgICAgICAgICBvblRhc2tTZWxlY3QodGFza0lkKTtcbiAgICAgICAgICBvbk5hdmlnYXRlKFwidGFza3NcIik7XG4gICAgICAgIH19XG4gICAgICAvPlxuICAgICk7XG4gIH1cblxuICBpZiAoY3VycmVudFZpZXcgPT09IFwiY2FsZW5kYXJcIikgcmV0dXJuIDxDYWxlbmRhclZpZXcgcHJvamVjdElkPXtwcm9qZWN0SWR9IC8+O1xuICBpZiAoY3VycmVudFZpZXcgPT09IFwiYXV0b21hdGlvbnNcIiB8fCBjdXJyZW50VmlldyA9PT0gXCJhdXRvbWF0aW9uLXJ1bnNcIikge1xuICAgIHJldHVybiA8QXV0b21hdGlvbnNWaWV3IHByb2plY3RJZD17cHJvamVjdElkfSBmb3JjZVJ1bnM9e2N1cnJlbnRWaWV3ID09PSBcImF1dG9tYXRpb24tcnVuc1wifSAvPjtcbiAgfVxuICBpZiAoY3VycmVudFZpZXcgPT09IFwib3BzLXNjaGVkdWxlXCIpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPFNjaGVkdWxlVmlld1xuICAgICAgICBwcm9qZWN0SWQ9e3Byb2plY3RJZH1cbiAgICAgICAgb25OYXZpZ2F0ZT17b25OYXZpZ2F0ZX1cbiAgICAgICAgb25UYXNrU2VsZWN0PXtvblRhc2tTZWxlY3R9XG4gICAgICAvPlxuICAgICk7XG4gIH1cbiAgaWYgKGN1cnJlbnRWaWV3ID09PSBcImF1ZGl0XCIpIHJldHVybiA8QXVkaXRWaWV3IHByb2plY3RJZD17cHJvamVjdElkfSAvPjtcbiAgaWYgKGN1cnJlbnRWaWV3ID09PSBcInRlbGVtZXRyeVwiKSByZXR1cm4gPFRlbGVtZXRyeVZpZXcgcHJvamVjdElkPXtwcm9qZWN0SWR9IC8+O1xuICByZXR1cm4gbnVsbDtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL3NlY3Rpb25zL09wc1NlY3Rpb24udHN4In0=