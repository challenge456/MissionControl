import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/scroll-area.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/scroll-area.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
"use client";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const React = ((m) => m?.__esModule ? m : { ...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {}, default: m })(__vite__cjsImport3_react);
import * as ScrollAreaPrimitive from "/node_modules/.vite/deps/@radix-ui_react-scroll-area.js?v=34764c80";
import { cn } from "/src/lib/utils.ts";
const ScrollArea = React.forwardRef(
  _c = ({ className, children, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    ScrollAreaPrimitive.Root,
    {
      ref,
      className: cn("relative overflow-hidden", className),
      ...props,
      children: [
        /* @__PURE__ */ jsxDEV(ScrollAreaPrimitive.Viewport, { className: "h-full w-full rounded-[inherit]", children }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/scroll-area.tsx",
          lineNumber: 36,
          columnNumber: 5
        }, this),
        /* @__PURE__ */ jsxDEV(ScrollBar, {}, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/scroll-area.tsx",
          lineNumber: 39,
          columnNumber: 5
        }, this),
        /* @__PURE__ */ jsxDEV(ScrollAreaPrimitive.Corner, {}, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/scroll-area.tsx",
          lineNumber: 40,
          columnNumber: 5
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/scroll-area.tsx",
      lineNumber: 31,
      columnNumber: 1
    },
    this
  )
);
_c2 = ScrollArea;
ScrollArea.displayName = ScrollAreaPrimitive.Root.displayName;
const ScrollBar = React.forwardRef(_c3 = ({ className, orientation = "vertical", ...props }, ref) => {
  const resolvedOrientation = orientation === "horizontal" ? "horizontal" : "vertical";
  return /* @__PURE__ */ jsxDEV(
    ScrollAreaPrimitive.ScrollAreaScrollbar,
    {
      ref,
      orientation: resolvedOrientation,
      className: cn(
        "flex touch-none select-none transition-colors",
        resolvedOrientation === "vertical" && "h-full w-2.5 border-l border-l-transparent p-[1px]",
        resolvedOrientation === "horizontal" && "h-2.5 flex-col border-t border-t-transparent p-[1px]",
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsxDEV(ScrollAreaPrimitive.ScrollAreaThumb, { className: "relative flex-1 rounded-full bg-border" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/scroll-area.tsx",
        lineNumber: 66,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/scroll-area.tsx",
      lineNumber: 53,
      columnNumber: 5
    },
    this
  );
});
_c4 = ScrollBar;
ScrollBar.displayName = ScrollAreaPrimitive.ScrollAreaScrollbar.displayName;
export { ScrollArea, ScrollBar };
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "ScrollArea$React.forwardRef");
$RefreshReg$(_c2, "ScrollArea");
$RefreshReg$(_c3, "ScrollBar$React.forwardRef");
$RefreshReg$(_c4, "ScrollBar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/scroll-area.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/scroll-area.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JJOzs7Ozs7Ozs7Ozs7Ozs7O0FBaEJKO0FBRUEsWUFBWUEsV0FBVztBQUN2QixZQUFZQyx5QkFBeUI7QUFFckMsU0FBU0MsVUFBVTtBQUVuQixNQUFNQyxhQUFhSCxNQUFNSTtBQUFBQSxFQUd4QkMsS0FBQ0EsQ0FBQyxFQUFFQyxXQUFXQyxVQUFVLEdBQUdDLE1BQU0sR0FBR0MsUUFDcEM7QUFBQSxJQUFDLG9CQUFvQjtBQUFBLElBQXBCO0FBQUEsTUFDQztBQUFBLE1BQ0EsV0FBV1AsR0FBRyw0QkFBNEJJLFNBQVM7QUFBQSxNQUNuRCxHQUFJRTtBQUFBQSxNQUVKO0FBQUEsK0JBQUMsb0JBQW9CLFVBQXBCLEVBQTZCLFdBQVUsbUNBQ3JDRCxZQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVU7QUFBQSxRQUNWLHVCQUFDLG9CQUFvQixRQUFwQixJQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkI7QUFBQTtBQUFBO0FBQUEsSUFUN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBVUE7QUFDRDtBQUFDRyxNQWZJUDtBQWdCTkEsV0FBV1EsY0FBY1Ysb0JBQW9CVyxLQUFLRDtBQUVsRCxNQUFNRSxZQUFZYixNQUFNSSxXQUd2QlUsTUFBQ0EsQ0FBQyxFQUFFUixXQUFXUyxjQUFjLFlBQVksR0FBR1AsTUFBTSxHQUFHQyxRQUFRO0FBQzVELFFBQU1PLHNCQUNKRCxnQkFBZ0IsZUFBZSxlQUFlO0FBRWhELFNBQ0U7QUFBQSxJQUFDLG9CQUFvQjtBQUFBLElBQXBCO0FBQUEsTUFDQztBQUFBLE1BQ0EsYUFBYUM7QUFBQUEsTUFDYixXQUFXZDtBQUFBQSxRQUNUO0FBQUEsUUFDQWMsd0JBQXdCLGNBQ3RCO0FBQUEsUUFDRkEsd0JBQXdCLGdCQUN0QjtBQUFBLFFBQ0ZWO0FBQUFBLE1BQ0Y7QUFBQSxNQUNBLEdBQUlFO0FBQUFBLE1BRUosaUNBQUMsb0JBQW9CLGlCQUFwQixFQUFvQyxXQUFVLDRDQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVGO0FBQUE7QUFBQSxJQWJ6RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFjQTtBQUVKLENBQUM7QUFBQ1MsTUF4QklKO0FBeUJOQSxVQUFVRixjQUFjVixvQkFBb0JpQixvQkFBb0JQO0FBRWhFLFNBQVNSLFlBQVlVO0FBQVcsSUFBQVIsSUFBQUssS0FBQUksS0FBQUc7QUFBQSxhQUFBWixJQUFBO0FBQUEsYUFBQUssS0FBQTtBQUFBLGFBQUFJLEtBQUE7QUFBQSxhQUFBRyxLQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJTY3JvbGxBcmVhUHJpbWl0aXZlIiwiY24iLCJTY3JvbGxBcmVhIiwiZm9yd2FyZFJlZiIsIl9jIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJwcm9wcyIsInJlZiIsIl9jMiIsImRpc3BsYXlOYW1lIiwiUm9vdCIsIlNjcm9sbEJhciIsIl9jMyIsIm9yaWVudGF0aW9uIiwicmVzb2x2ZWRPcmllbnRhdGlvbiIsIl9jNCIsIlNjcm9sbEFyZWFTY3JvbGxiYXIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsic2Nyb2xsLWFyZWEudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIGNsaWVudFwiXG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiXG5pbXBvcnQgKiBhcyBTY3JvbGxBcmVhUHJpbWl0aXZlIGZyb20gXCJAcmFkaXgtdWkvcmVhY3Qtc2Nyb2xsLWFyZWFcIlxuXG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiXG5cbmNvbnN0IFNjcm9sbEFyZWEgPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBSZWFjdC5FbGVtZW50UmVmPHR5cGVvZiBTY3JvbGxBcmVhUHJpbWl0aXZlLlJvb3Q+LFxuICBSZWFjdC5Db21wb25lbnRQcm9wc1dpdGhvdXRSZWY8dHlwZW9mIFNjcm9sbEFyZWFQcmltaXRpdmUuUm9vdD5cbj4oKHsgY2xhc3NOYW1lLCBjaGlsZHJlbiwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDxTY3JvbGxBcmVhUHJpbWl0aXZlLlJvb3RcbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFwicmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCIsIGNsYXNzTmFtZSl9XG4gICAgey4uLnByb3BzfVxuICA+XG4gICAgPFNjcm9sbEFyZWFQcmltaXRpdmUuVmlld3BvcnQgY2xhc3NOYW1lPVwiaC1mdWxsIHctZnVsbCByb3VuZGVkLVtpbmhlcml0XVwiPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvU2Nyb2xsQXJlYVByaW1pdGl2ZS5WaWV3cG9ydD5cbiAgICA8U2Nyb2xsQmFyIC8+XG4gICAgPFNjcm9sbEFyZWFQcmltaXRpdmUuQ29ybmVyIC8+XG4gIDwvU2Nyb2xsQXJlYVByaW1pdGl2ZS5Sb290PlxuKSlcblNjcm9sbEFyZWEuZGlzcGxheU5hbWUgPSBTY3JvbGxBcmVhUHJpbWl0aXZlLlJvb3QuZGlzcGxheU5hbWVcblxuY29uc3QgU2Nyb2xsQmFyID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgUmVhY3QuRWxlbWVudFJlZjx0eXBlb2YgU2Nyb2xsQXJlYVByaW1pdGl2ZS5TY3JvbGxBcmVhU2Nyb2xsYmFyPixcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBTY3JvbGxBcmVhUHJpbWl0aXZlLlNjcm9sbEFyZWFTY3JvbGxiYXI+XG4+KCh7IGNsYXNzTmFtZSwgb3JpZW50YXRpb24gPSBcInZlcnRpY2FsXCIsIC4uLnByb3BzIH0sIHJlZikgPT4ge1xuICBjb25zdCByZXNvbHZlZE9yaWVudGF0aW9uOiBcImhvcml6b250YWxcIiB8IFwidmVydGljYWxcIiA9XG4gICAgb3JpZW50YXRpb24gPT09IFwiaG9yaXpvbnRhbFwiID8gXCJob3Jpem9udGFsXCIgOiBcInZlcnRpY2FsXCJcblxuICByZXR1cm4gKFxuICAgIDxTY3JvbGxBcmVhUHJpbWl0aXZlLlNjcm9sbEFyZWFTY3JvbGxiYXJcbiAgICAgIHJlZj17cmVmfVxuICAgICAgb3JpZW50YXRpb249e3Jlc29sdmVkT3JpZW50YXRpb259XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcImZsZXggdG91Y2gtbm9uZSBzZWxlY3Qtbm9uZSB0cmFuc2l0aW9uLWNvbG9yc1wiLFxuICAgICAgICByZXNvbHZlZE9yaWVudGF0aW9uID09PSBcInZlcnRpY2FsXCIgJiZcbiAgICAgICAgICBcImgtZnVsbCB3LTIuNSBib3JkZXItbCBib3JkZXItbC10cmFuc3BhcmVudCBwLVsxcHhdXCIsXG4gICAgICAgIHJlc29sdmVkT3JpZW50YXRpb24gPT09IFwiaG9yaXpvbnRhbFwiICYmXG4gICAgICAgICAgXCJoLTIuNSBmbGV4LWNvbCBib3JkZXItdCBib3JkZXItdC10cmFuc3BhcmVudCBwLVsxcHhdXCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICA8U2Nyb2xsQXJlYVByaW1pdGl2ZS5TY3JvbGxBcmVhVGh1bWIgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleC0xIHJvdW5kZWQtZnVsbCBiZy1ib3JkZXJcIiAvPlxuICAgIDwvU2Nyb2xsQXJlYVByaW1pdGl2ZS5TY3JvbGxBcmVhU2Nyb2xsYmFyPlxuICApXG59KVxuU2Nyb2xsQmFyLmRpc3BsYXlOYW1lID0gU2Nyb2xsQXJlYVByaW1pdGl2ZS5TY3JvbGxBcmVhU2Nyb2xsYmFyLmRpc3BsYXlOYW1lXG5cbmV4cG9ydCB7IFNjcm9sbEFyZWEsIFNjcm9sbEJhciB9XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9jb21wb25lbnRzL3VpL3Njcm9sbC1hcmVhLnRzeCJ9