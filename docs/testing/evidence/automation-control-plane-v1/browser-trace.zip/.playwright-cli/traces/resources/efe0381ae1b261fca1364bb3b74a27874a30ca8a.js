import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/LoopDetectionPanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { cn } from "/src/lib/utils.ts";
import { Button } from "/src/components/ui/button.tsx";
import { StatusBadge } from "/src/components/factory/badges.tsx";
import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  MessageSquareWarning,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  XCircle,
  Zap,
  Clock
} from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
const LOOP_TYPE_INFO = {
  COMMENT_STORM: {
    icon: /* @__PURE__ */ jsxDEV(MessageSquareWarning, { className: "h-4 w-4", strokeWidth: 1.75 }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
      lineNumber: 60,
      columnNumber: 11
    }, this),
    label: "Comment Storm",
    description: "Too many messages in a short window",
    colorClass: "text-warn",
    borderClass: "border-warn"
  },
  REVIEW_PING_PONG: {
    icon: /* @__PURE__ */ jsxDEV(RefreshCw, { className: "h-4 w-4", strokeWidth: 1.75 }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
      lineNumber: 67,
      columnNumber: 11
    }, this),
    label: "Review Ping-Pong",
    description: "Excessive review cycles without resolution",
    colorClass: "text-err",
    borderClass: "border-err"
  },
  BACK_AND_FORTH: {
    icon: /* @__PURE__ */ jsxDEV(Zap, { className: "h-4 w-4", strokeWidth: 1.75 }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
      lineNumber: 74,
      columnNumber: 11
    }, this),
    label: "State Churn",
    description: "Task repeatedly bouncing between states",
    colorClass: "text-warn",
    borderClass: "border-warn"
  },
  REPEATED_FAILURES: {
    icon: /* @__PURE__ */ jsxDEV(XCircle, { className: "h-4 w-4", strokeWidth: 1.75 }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
      lineNumber: 81,
      columnNumber: 11
    }, this),
    label: "Repeated Failures",
    description: "Same operation failing repeatedly",
    colorClass: "text-err",
    borderClass: "border-err"
  }
};
const SEVERITY_CONFIG = {
  CRITICAL: { label: "Critical", tone: "error" },
  WARNING: { label: "Warning", tone: "warning" },
  INFO: { label: "Info", tone: "info" }
};
export function LoopDetectionPanel({
  projectId: _projectId,
  onTaskSelect
}) {
  _s();
  const [filter, setFilter] = useState("all");
  const [expanded, setExpanded] = useState(false);
  const [actionLoading, setActionLoading] = useState(null);
  const openAlerts = useQuery(api.alerts.listOpen, { limit: 100 });
  const acknowledgeAlert = useMutation(api.alerts.acknowledge);
  const resolveAlert = useMutation(api.alerts.resolve);
  const ignoreAlert = useMutation(api.alerts.ignore);
  const transitionTask = useMutation(api.tasks.transition);
  const loopAlerts = (openAlerts ?? []).filter((a) => a.type === "LOOP_DETECTED");
  const filteredAlerts = filter === "all" ? loopAlerts : loopAlerts.filter((a) => a.status === filter);
  const hasLoopAlerts = loopAlerts.length > 0;
  const openCount = loopAlerts.filter((a) => a.status === "OPEN").length;
  const acknowledgedCount = loopAlerts.filter((a) => a.status === "ACKNOWLEDGED").length;
  const summary = useMemo(
    () => Object.entries(LOOP_TYPE_INFO).map(([type, info]) => ({
      type,
      info,
      count: loopAlerts.filter(
        (a) => a.metadata?.loopData?.type === type || a.title.includes(type)
      ).length
    })),
    [loopAlerts]
  );
  const activeSummary = summary.filter((item) => item.count > 0);
  const handleAcknowledge = async (alertId) => {
    setActionLoading(alertId);
    try {
      await acknowledgeAlert({ alertId, acknowledgedBy: "operator" });
    } finally {
      setActionLoading(null);
    }
  };
  const handleResolve = async (alertId) => {
    setActionLoading(alertId);
    try {
      await resolveAlert({ alertId, resolutionNote: "Resolved via Loop Detection Panel" });
    } finally {
      setActionLoading(null);
    }
  };
  const handleIgnore = async (alertId) => {
    setActionLoading(alertId);
    try {
      await ignoreAlert({ alertId, reason: "Ignored via Loop Detection Panel" });
    } finally {
      setActionLoading(null);
    }
  };
  const handleUnblockTask = async (taskId, alertId) => {
    setActionLoading(alertId);
    try {
      await transitionTask({
        taskId,
        toStatus: "ASSIGNED",
        actorType: "HUMAN",
        reason: "Unblocked from Loop Detection Panel",
        idempotencyKey: `unblock-loop-${taskId}-${Date.now()}`
      });
      await resolveAlert({ alertId, resolutionNote: "Task unblocked by operator" });
    } finally {
      setActionLoading(null);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "mx-4 my-3 shrink-0 rounded-xl border border-line bg-surface-1", children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: () => setExpanded((v) => !v),
        className: cn(
          "flex w-full items-center justify-between px-4 py-3 transition-colors duration-150",
          expanded ? "rounded-t-xl" : "rounded-xl",
          "hover:bg-surface-2"
        ),
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV("span", { className: cn("h-2 w-2 rounded-full", hasLoopAlerts ? "bg-warn" : "bg-ok") }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
              lineNumber: 186,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                ShieldAlert,
                {
                  className: cn("h-4 w-4", hasLoopAlerts ? "text-warn" : "text-ink-muted"),
                  strokeWidth: 1.75
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                  lineNumber: 189,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[13.5px] font-semibold text-ink", children: "Loop Risk Monitor" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                lineNumber: 193,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
              lineNumber: 188,
              columnNumber: 11
            }, this),
            hasLoopAlerts ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
              openCount > 0 && /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "error", children: [
                openCount,
                " open"
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                lineNumber: 198,
                columnNumber: 33
              }, this),
              acknowledgedCount > 0 && /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", children: [
                acknowledgedCount,
                " acknowledged"
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                lineNumber: 200,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
              lineNumber: 197,
              columnNumber: 11
            }, this) : /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "success", children: "All clear" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
              lineNumber: 204,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
            lineNumber: 184,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-ink-muted", children: [
            hasLoopAlerts && activeSummary.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 mr-1", children: activeSummary.map(
              ({ type, info, count }) => /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: cn(
                    "flex items-center gap-1 rounded-md border border-line bg-surface-2 px-1.5 py-0.5 text-[11px]",
                    info.colorClass
                  ),
                  children: [
                    info.icon,
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: count }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                      lineNumber: 220,
                      columnNumber: 19
                    }, this)
                  ]
                },
                type,
                true,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                  lineNumber: 212,
                  columnNumber: 13
                },
                this
              )
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
              lineNumber: 210,
              columnNumber: 11
            }, this),
            expanded ? /* @__PURE__ */ jsxDEV(ChevronDown, { className: "h-4 w-4", strokeWidth: 1.75 }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
              lineNumber: 226,
              columnNumber: 11
            }, this) : /* @__PURE__ */ jsxDEV(ChevronRight, { className: "h-4 w-4", strokeWidth: 1.75 }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
              lineNumber: 227,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
            lineNumber: 208,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
        lineNumber: 175,
        columnNumber: 7
      },
      this
    ),
    expanded && /* @__PURE__ */ jsxDEV("div", { className: "h-px mx-4 bg-line" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
      lineNumber: 233,
      columnNumber: 20
    }, this),
    expanded && /* @__PURE__ */ jsxDEV("div", { className: "px-4 pb-4 pt-3 space-y-3", children: !hasLoopAlerts ? (
      /* All-clear state */
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-line bg-surface-2 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV(ShieldCheck, { className: "h-5 w-5 shrink-0 text-ok", strokeWidth: 1.75 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
            lineNumber: 243,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-0.5", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[13.5px] font-semibold text-ink", children: "No active loop incidents" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                lineNumber: 246,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "success", children: "Stable" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                lineNumber: 247,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
              lineNumber: 245,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[12.5px] text-ink-muted leading-relaxed", children: "Comment storms and state churn are currently stable." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
              lineNumber: 249,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
            lineNumber: 244,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "shrink-0 text-right", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-[11.5px] text-ink-muted", children: "Last scan" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
              lineNumber: 254,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] font-medium text-ink-secondary mt-0.5", children: (/* @__PURE__ */ new Date()).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
              lineNumber: 255,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
            lineNumber: 253,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
          lineNumber: 242,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
          lineNumber: 241,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2", children: Object.entries(LOOP_TYPE_INFO).map(
          ([type, info]) => /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "flex items-center gap-3 rounded-lg border border-line bg-surface-2 px-3 py-2.5 transition-colors duration-150 hover:border-line-strong",
              children: [
                /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-3.5 w-3.5 shrink-0 text-ok", strokeWidth: 1.75 }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                  lineNumber: 269,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[11.5px] font-semibold text-ink-secondary truncate", children: info.label }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                    lineNumber: 271,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[11.5px] text-ink-muted mt-0.5", children: "0 incidents" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                    lineNumber: 272,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                  lineNumber: 270,
                  columnNumber: 21
                }, this)
              ]
            },
            type,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
              lineNumber: 265,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
          lineNumber: 263,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 px-1 text-[11.5px] text-ink-muted", children: [
          /* @__PURE__ */ jsxDEV(Clock, { className: "h-3 w-3", strokeWidth: 1.75 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
            lineNumber: 280,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "Loop detection scans every 5 minutes · Powered by Convex cron" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
            lineNumber: 281,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
          lineNumber: 279,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
        lineNumber: 240,
        columnNumber: 9
      }, this)
    ) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center gap-0.5 rounded-lg border border-line p-0.5", children: ["all", "OPEN", "ACKNOWLEDGED"].map(
        (f) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setFilter(f),
            className: cn(
              "h-7 px-3 rounded-md text-xs font-medium transition-colors duration-150",
              filter === f ? "bg-surface-2 text-ink" : "text-ink-muted hover:text-ink"
            ),
            children: f === "all" ? "All" : f === "OPEN" ? `Open (${openCount})` : `Acknowledged (${acknowledgedCount})`
          },
          f,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
            lineNumber: 289,
            columnNumber: 13
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
        lineNumber: 287,
        columnNumber: 15
      }, this),
      filteredAlerts.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 rounded-lg border border-dashed border-line text-xs text-ink-muted", children: "No incidents for this filter." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
        lineNumber: 305,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2", children: filteredAlerts.map((alert) => {
        const loopData = alert.metadata?.loopData;
        const loopType = loopData?.type ?? "UNKNOWN";
        const info = LOOP_TYPE_INFO[loopType] ?? {
          icon: /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "h-4 w-4", strokeWidth: 1.75 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
            lineNumber: 314,
            columnNumber: 23
          }, this),
          label: loopType,
          description: "",
          colorClass: "text-warn",
          borderClass: "border-warn"
        };
        const severityConfig = SEVERITY_CONFIG[alert.severity] ?? SEVERITY_CONFIG.INFO;
        const isLoading = actionLoading === alert._id;
        return /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: cn(
              "rounded-lg border-l-2 border border-line bg-surface-1 p-3 space-y-2.5",
              info.borderClass.replace("border-", "border-l-")
            ),
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-2", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2.5", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: cn("mt-0.5 shrink-0", info.colorClass), children: info.icon }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                    lineNumber: 334,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-[13.5px] font-semibold text-ink leading-tight", children: alert.title }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                      lineNumber: 336,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-[11.5px] text-ink-muted mt-0.5", children: new Date(alert._creationTime).toLocaleString() }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                      lineNumber: 337,
                      columnNumber: 31
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                    lineNumber: 335,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                  lineNumber: 333,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV(StatusBadge, { tone: severityConfig.tone, className: "shrink-0", children: severityConfig.label }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                  lineNumber: 342,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                lineNumber: 332,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[12.5px] text-ink-secondary leading-relaxed", children: alert.description }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                lineNumber: 348,
                columnNumber: 25
              }, this),
              loopData && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1.5", children: [
                { label: "Count", value: String(loopData.count) },
                { label: "Threshold", value: String(loopData.threshold) },
                loopData.window ? { label: "Window", value: `${loopData.window} min` } : null,
                loopData.detail ? { label: "Detail", value: String(loopData.detail) } : null
              ].filter(Boolean).map(
                (item) => /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "flex items-center gap-1.5 px-2 py-1 rounded-md bg-surface-2 border border-line",
                    children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] text-ink-muted font-medium", children: item.label }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                        lineNumber: 369,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] font-semibold text-ink", children: item.value }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                        lineNumber: 370,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  item.label,
                  true,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                    lineNumber: 365,
                    columnNumber: 21
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                lineNumber: 352,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-1.5 pt-0.5", children: [
                alert.taskId && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      size: "sm",
                      className: "h-7 text-xs px-3",
                      disabled: isLoading,
                      onClick: () => handleUnblockTask(alert.taskId, alert._id),
                      children: isLoading ? "Working…" : "Unblock Task"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                      lineNumber: 380,
                      columnNumber: 31
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      variant: "outline",
                      size: "sm",
                      className: "h-7 text-xs px-3",
                      onClick: () => onTaskSelect?.(alert.taskId),
                      children: "View Task"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                      lineNumber: 388,
                      columnNumber: 31
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                  lineNumber: 379,
                  columnNumber: 21
                }, this),
                alert.status === "OPEN" && /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    variant: "outline",
                    size: "sm",
                    className: "h-7 text-xs px-3",
                    disabled: isLoading,
                    onClick: () => handleAcknowledge(alert._id),
                    children: "Acknowledge"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                    lineNumber: 399,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    variant: "outline",
                    size: "sm",
                    className: "h-7 text-xs px-3",
                    disabled: isLoading,
                    onClick: () => handleResolve(alert._id),
                    children: "Resolve"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                    lineNumber: 409,
                    columnNumber: 27
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    variant: "ghost",
                    size: "sm",
                    className: "h-7 text-xs px-3 text-ink-muted",
                    disabled: isLoading,
                    onClick: () => handleIgnore(alert._id),
                    children: "Ignore"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                    lineNumber: 418,
                    columnNumber: 27
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
                lineNumber: 377,
                columnNumber: 25
              }, this)
            ]
          },
          alert._id,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
            lineNumber: 324,
            columnNumber: 17
          },
          this
        );
      }) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
        lineNumber: 309,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
      lineNumber: 285,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
      lineNumber: 237,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx",
    lineNumber: 173,
    columnNumber: 5
  }, this);
}
_s(LoopDetectionPanel, "MCO87HAafwCmdVWkH/1jmfryyZM=", false, function() {
  return [useQuery, useMutation, useMutation, useMutation, useMutation];
});
_c = LoopDetectionPanel;
var _c;
$RefreshReg$(_c, "LoopDetectionPanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LoopDetectionPanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0NVLFNBK1RrQixVQS9UbEI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBakNWLFNBQVNBLFNBQVNDLGdCQUFnQjtBQUNsQyxTQUFTQyxhQUFhQyxnQkFBZ0I7QUFDdEMsU0FBU0MsV0FBVztBQUVwQixTQUFTQyxVQUFVO0FBQ25CLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsbUJBQTBDO0FBQ25EO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQVNQLE1BQU1DLGlCQUdGO0FBQUEsRUFDRkMsZUFBZTtBQUFBLElBQ2JDLE1BQU0sdUJBQUMsd0JBQXFCLFdBQVUsV0FBVSxhQUFhLFFBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEQ7QUFBQSxJQUNsRUMsT0FBTztBQUFBLElBQ1BDLGFBQWE7QUFBQSxJQUNiQyxZQUFZO0FBQUEsSUFDWkMsYUFBYTtBQUFBLEVBQ2Y7QUFBQSxFQUNBQyxrQkFBa0I7QUFBQSxJQUNoQkwsTUFBTSx1QkFBQyxhQUFVLFdBQVUsV0FBVSxhQUFhLFFBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUQ7QUFBQSxJQUN2REMsT0FBTztBQUFBLElBQ1BDLGFBQWE7QUFBQSxJQUNiQyxZQUFZO0FBQUEsSUFDWkMsYUFBYTtBQUFBLEVBQ2Y7QUFBQSxFQUNBRSxnQkFBZ0I7QUFBQSxJQUNkTixNQUFNLHVCQUFDLE9BQUksV0FBVSxXQUFVLGFBQWEsUUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQztBQUFBLElBQ2pEQyxPQUFPO0FBQUEsSUFDUEMsYUFBYTtBQUFBLElBQ2JDLFlBQVk7QUFBQSxJQUNaQyxhQUFhO0FBQUEsRUFDZjtBQUFBLEVBQ0FHLG1CQUFtQjtBQUFBLElBQ2pCUCxNQUFNLHVCQUFDLFdBQVEsV0FBVSxXQUFVLGFBQWEsUUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErQztBQUFBLElBQ3JEQyxPQUFPO0FBQUEsSUFDUEMsYUFBYTtBQUFBLElBQ2JDLFlBQVk7QUFBQSxJQUNaQyxhQUFhO0FBQUEsRUFDZjtBQUNGO0FBRUEsTUFBTUksa0JBQXFGO0FBQUEsRUFDekZDLFVBQVUsRUFBRVIsT0FBTyxZQUFZUyxNQUFNLFFBQVE7QUFBQSxFQUM3Q0MsU0FBUyxFQUFFVixPQUFPLFdBQVdTLE1BQU0sVUFBVTtBQUFBLEVBQzdDRSxNQUFNLEVBQUVYLE9BQU8sUUFBUVMsTUFBTSxPQUFPO0FBQ3RDO0FBRU8sZ0JBQVNHLG1CQUFtQjtBQUFBLEVBQ2pDQyxXQUFXQztBQUFBQSxFQUNYQztBQUN1QixHQUFHO0FBQUFDLEtBQUE7QUFDMUIsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUl2QyxTQUEwQyxLQUFLO0FBQzNFLFFBQU0sQ0FBQ3dDLFVBQVVDLFdBQVcsSUFBSXpDLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUMwQyxlQUFlQyxnQkFBZ0IsSUFBSTNDLFNBQXdCLElBQUk7QUFFdEUsUUFBTTRDLGFBQWExQyxTQUFTQyxJQUFJMEMsT0FBT0MsVUFBVSxFQUFFQyxPQUFPLElBQUksQ0FBQztBQUMvRCxRQUFNQyxtQkFBbUIvQyxZQUFZRSxJQUFJMEMsT0FBT0ksV0FBVztBQUMzRCxRQUFNQyxlQUFlakQsWUFBWUUsSUFBSTBDLE9BQU9NLE9BQU87QUFDbkQsUUFBTUMsY0FBY25ELFlBQVlFLElBQUkwQyxPQUFPUSxNQUFNO0FBQ2pELFFBQU1DLGlCQUFpQnJELFlBQVlFLElBQUlvRCxNQUFNQyxVQUFVO0FBRXZELFFBQU1DLGNBQWNiLGNBQWMsSUFBSU4sT0FBTyxDQUFDb0IsTUFBTUEsRUFBRUMsU0FBUyxlQUFlO0FBQzlFLFFBQU1DLGlCQUFpQnRCLFdBQVcsUUFBUW1CLGFBQWFBLFdBQVduQixPQUFPLENBQUNvQixNQUFNQSxFQUFFRyxXQUFXdkIsTUFBTTtBQUNuRyxRQUFNd0IsZ0JBQWdCTCxXQUFXTSxTQUFTO0FBQzFDLFFBQU1DLFlBQVlQLFdBQVduQixPQUFPLENBQUNvQixNQUFNQSxFQUFFRyxXQUFXLE1BQU0sRUFBRUU7QUFDaEUsUUFBTUUsb0JBQW9CUixXQUFXbkIsT0FBTyxDQUFDb0IsTUFBTUEsRUFBRUcsV0FBVyxjQUFjLEVBQUVFO0FBRWhGLFFBQU1HLFVBQVVuRTtBQUFBQSxJQUNkLE1BQ0VvRSxPQUFPQyxRQUFRbEQsY0FBYyxFQUFFbUQsSUFBSSxDQUFDLENBQUNWLE1BQU1XLElBQUksT0FBTztBQUFBLE1BQ3BEWDtBQUFBQSxNQUNBVztBQUFBQSxNQUNBQyxPQUFPZCxXQUFXbkI7QUFBQUEsUUFDaEIsQ0FBQ29CLE1BQU9BLEVBQUVjLFVBQXlFQyxVQUFVZCxTQUFTQSxRQUFRRCxFQUFFZ0IsTUFBTUMsU0FBU2hCLElBQUk7QUFBQSxNQUNySSxFQUFFSTtBQUFBQSxJQUNKLEVBQUU7QUFBQSxJQUNKLENBQUNOLFVBQVU7QUFBQSxFQUNiO0FBRUEsUUFBTW1CLGdCQUFnQlYsUUFBUTVCLE9BQU8sQ0FBQ3VDLFNBQVNBLEtBQUtOLFFBQVEsQ0FBQztBQUU3RCxRQUFNTyxvQkFBb0IsT0FBT0MsWUFBMEI7QUFDekRwQyxxQkFBaUJvQyxPQUFPO0FBQ3hCLFFBQUk7QUFDRixZQUFNL0IsaUJBQWlCLEVBQUUrQixTQUFTQyxnQkFBZ0IsV0FBVyxDQUFDO0FBQUEsSUFDaEUsVUFBQztBQUNDckMsdUJBQWlCLElBQUk7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNc0MsZ0JBQWdCLE9BQU9GLFlBQTBCO0FBQ3JEcEMscUJBQWlCb0MsT0FBTztBQUN4QixRQUFJO0FBQ0YsWUFBTTdCLGFBQWEsRUFBRTZCLFNBQVNHLGdCQUFnQixvQ0FBb0MsQ0FBQztBQUFBLElBQ3JGLFVBQUM7QUFDQ3ZDLHVCQUFpQixJQUFJO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBRUEsUUFBTXdDLGVBQWUsT0FBT0osWUFBMEI7QUFDcERwQyxxQkFBaUJvQyxPQUFPO0FBQ3hCLFFBQUk7QUFDRixZQUFNM0IsWUFBWSxFQUFFMkIsU0FBU0ssUUFBUSxtQ0FBbUMsQ0FBQztBQUFBLElBQzNFLFVBQUM7QUFDQ3pDLHVCQUFpQixJQUFJO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBRUEsUUFBTTBDLG9CQUFvQixPQUFPQyxRQUFxQlAsWUFBMEI7QUFDOUVwQyxxQkFBaUJvQyxPQUFPO0FBQ3hCLFFBQUk7QUFDRixZQUFNekIsZUFBZTtBQUFBLFFBQ25CZ0M7QUFBQUEsUUFDQUMsVUFBVTtBQUFBLFFBQ1ZDLFdBQVc7QUFBQSxRQUNYSixRQUFRO0FBQUEsUUFDUkssZ0JBQWdCLGdCQUFnQkgsTUFBTSxJQUFJSSxLQUFLQyxJQUFJLENBQUM7QUFBQSxNQUN0RCxDQUFDO0FBQ0QsWUFBTXpDLGFBQWEsRUFBRTZCLFNBQVNHLGdCQUFnQiw2QkFBNkIsQ0FBQztBQUFBLElBQzlFLFVBQUM7QUFDQ3ZDLHVCQUFpQixJQUFJO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsaUVBRWI7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsU0FBUyxNQUFNRixZQUFZLENBQUNtRCxNQUFNLENBQUNBLENBQUM7QUFBQSxRQUNwQyxXQUFXeEY7QUFBQUEsVUFDVDtBQUFBLFVBQ0FvQyxXQUFXLGlCQUFpQjtBQUFBLFVBQzVCO0FBQUEsUUFDRjtBQUFBLFFBRUE7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkJBRWI7QUFBQSxtQ0FBQyxVQUFLLFdBQVdwQyxHQUFHLHdCQUF3QjBELGdCQUFnQixZQUFZLE9BQU8sS0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUY7QUFBQSxZQUVqRix1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXMUQsR0FBRyxXQUFXMEQsZ0JBQWdCLGNBQWMsZ0JBQWdCO0FBQUEsa0JBQ3ZFLGFBQWE7QUFBQTtBQUFBLGdCQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUVvQjtBQUFBLGNBRXBCLHVCQUFDLFVBQUssV0FBVSx3Q0FBdUMsaUNBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdFO0FBQUEsaUJBTDFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxZQUVDQSxnQkFDQyx1QkFBQyxTQUFJLFdBQVUsNkJBQ1pFO0FBQUFBLDBCQUFZLEtBQUssdUJBQUMsZUFBWSxNQUFLLFNBQVNBO0FBQUFBO0FBQUFBLGdCQUFVO0FBQUEsbUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBDO0FBQUEsY0FDM0RDLG9CQUFvQixLQUNuQix1QkFBQyxlQUFZLE1BQUssV0FBV0E7QUFBQUE7QUFBQUEsZ0JBQWtCO0FBQUEsbUJBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTREO0FBQUEsaUJBSGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0EsSUFFQSx1QkFBQyxlQUFZLE1BQUssV0FBVSx5QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUM7QUFBQSxlQXBCekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDWkg7QUFBQUEsNkJBQWlCYyxjQUFjYixTQUFTLEtBQ3ZDLHVCQUFDLFNBQUksV0FBVSxnQ0FDWmEsd0JBQWNQO0FBQUFBLGNBQUksQ0FBQyxFQUFFVixNQUFNVyxNQUFNQyxNQUFNLE1BQ3RDO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLFdBQVduRTtBQUFBQSxvQkFDVDtBQUFBLG9CQUNBa0UsS0FBSy9DO0FBQUFBLGtCQUNQO0FBQUEsa0JBRUMrQztBQUFBQSx5QkFBS2xEO0FBQUFBLG9CQUNOLHVCQUFDLFVBQUssV0FBVSxpQkFBaUJtRCxtQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUM7QUFBQTtBQUFBO0FBQUEsZ0JBUGxDWjtBQUFBQSxnQkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBU0E7QUFBQSxZQUNELEtBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBLFlBRURuQixXQUNHLHVCQUFDLGVBQVksV0FBVSxXQUFVLGFBQWEsUUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUQsSUFDbkQsdUJBQUMsZ0JBQWEsV0FBVSxXQUFVLGFBQWEsUUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Q7QUFBQSxlQW5CMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQTtBQUFBO0FBQUEsTUF0REY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBdURBO0FBQUEsSUFHQ0EsWUFBWSx1QkFBQyxTQUFJLFdBQVUsdUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrQztBQUFBLElBRzlDQSxZQUNDLHVCQUFDLFNBQUksV0FBVSw0QkFDWixXQUFDc0I7QUFBQUE7QUFBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxrREFDYixpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxlQUFZLFdBQVUsNEJBQTJCLGFBQWEsUUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0U7QUFBQSxVQUNwRSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsd0NBQXVDLHdDQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErRTtBQUFBLGNBQy9FLHVCQUFDLGVBQVksTUFBSyxXQUFVLHNCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrQztBQUFBLGlCQUZwQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsZ0RBQThDLG9FQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsZ0NBQStCLHlCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RDtBQUFBLFlBQ3ZELHVCQUFDLFNBQUksV0FBVSx1REFDWiwrQkFBSTRCLEtBQUssR0FBRUcsbUJBQW1CLElBQUksRUFBRUMsTUFBTSxXQUFXQyxRQUFRLFVBQVUsQ0FBQyxLQUQzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ1o1QixpQkFBT0MsUUFBUWxELGNBQWMsRUFBRW1EO0FBQUFBLFVBQUksQ0FBQyxDQUFDVixNQUFNVyxJQUFJLE1BQzlDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLGdCQUFhLFdBQVUsZ0NBQStCLGFBQWEsUUFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUU7QUFBQSxnQkFDekUsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDJEQUEyREEsZUFBS2pELFNBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFGO0FBQUEsa0JBQ3JGLHVCQUFDLFNBQUksV0FBVSx1Q0FBc0MsMkJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdFO0FBQUEscUJBRmxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQTtBQUFBO0FBQUEsWUFQS3NDO0FBQUFBLFlBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBO0FBQUEsUUFDRCxLQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUEsaUNBQUMsU0FBTSxXQUFVLFdBQVUsYUFBYSxRQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QztBQUFBLFVBQzdDLHVCQUFDLFVBQUssNkVBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUU7QUFBQSxhQUZyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQTFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkNBO0FBQUEsUUFFQSxtQ0FFRTtBQUFBLDZCQUFDLFNBQUksV0FBVSx3RUFDWCxXQUFDLE9BQU8sUUFBUSxjQUFjLEVBQVlVO0FBQUFBLFFBQUksQ0FBQzJCLE1BQy9DO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxTQUFTLE1BQU16RCxVQUFVeUQsQ0FBQztBQUFBLFlBQzFCLFdBQVc1RjtBQUFBQSxjQUNUO0FBQUEsY0FDQWtDLFdBQVcwRCxJQUNQLDBCQUNBO0FBQUEsWUFDTjtBQUFBLFlBRUNBLGdCQUFNLFFBQVEsUUFBUUEsTUFBTSxTQUFTLFNBQVNoQyxTQUFTLE1BQU0saUJBQWlCQyxpQkFBaUI7QUFBQTtBQUFBLFVBVDNGK0I7QUFBQUEsVUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBV0E7QUFBQSxNQUNELEtBZEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsTUFFQ3BDLGVBQWVHLFdBQVcsSUFDekIsdUJBQUMsU0FBSSxXQUFVLGdGQUE4RSw2Q0FBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHVCQUNaSCx5QkFBZVMsSUFBSSxDQUFDNEIsVUFBVTtBQUM3QixjQUFNeEIsV0FBWXdCLE1BQU16QixVQUErRUM7QUFDdkcsY0FBTXlCLFdBQVl6QixVQUFnQ2QsUUFBUTtBQUMxRCxjQUFNVyxPQUFPcEQsZUFBZWdGLFFBQVEsS0FBSztBQUFBLFVBQ3ZDOUUsTUFBTSx1QkFBQyxpQkFBYyxXQUFVLFdBQVUsYUFBYSxRQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRDtBQUFBLFVBQzNEQyxPQUFPNkU7QUFBQUEsVUFDUDVFLGFBQWE7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsYUFBYTtBQUFBLFFBQ2Y7QUFDQSxjQUFNMkUsaUJBQWlCdkUsZ0JBQWdCcUUsTUFBTUcsUUFBUSxLQUFLeEUsZ0JBQWdCSTtBQUMxRSxjQUFNcUUsWUFBWTNELGtCQUFrQnVELE1BQU1LO0FBRTFDLGVBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLFdBQVdsRztBQUFBQSxjQUNUO0FBQUEsY0FDQWtFLEtBQUs5QyxZQUFZK0UsUUFBUSxXQUFXLFdBQVc7QUFBQSxZQUNqRDtBQUFBLFlBR0E7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSx5Q0FBQyxVQUFLLFdBQVduRyxHQUFHLG1CQUFtQmtFLEtBQUsvQyxVQUFVLEdBQUkrQyxlQUFLbEQsUUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0U7QUFBQSxrQkFDcEUsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFNBQUksV0FBVSxzREFBc0Q2RSxnQkFBTXZCLFNBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlGO0FBQUEsb0JBQ2pGLHVCQUFDLFNBQUksV0FBVSx1Q0FDWixjQUFJZ0IsS0FBS08sTUFBTU8sYUFBYSxFQUFFQyxlQUFlLEtBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEscUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLGdCQUNBLHVCQUFDLGVBQVksTUFBTU4sZUFBZXJFLE1BQU0sV0FBVSxZQUMvQ3FFLHlCQUFlOUUsU0FEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYUE7QUFBQSxjQUdBLHVCQUFDLE9BQUUsV0FBVSxvREFBb0Q0RSxnQkFBTTNFLGVBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1GO0FBQUEsY0FHbEZtRCxZQUNDLHVCQUFDLFNBQUksV0FBVSwwQkFDWjtBQUFBLGdCQUNDLEVBQUVwRCxPQUFPLFNBQVNxRixPQUFPQyxPQUFRbEMsU0FBaUNGLEtBQUssRUFBRTtBQUFBLGdCQUN6RSxFQUFFbEQsT0FBTyxhQUFhcUYsT0FBT0MsT0FBUWxDLFNBQXFDbUMsU0FBUyxFQUFFO0FBQUEsZ0JBQ3BGbkMsU0FBa0NvQyxTQUMvQixFQUFFeEYsT0FBTyxVQUFVcUYsT0FBTyxHQUFJakMsU0FBaUNvQyxNQUFNLE9BQU8sSUFDNUU7QUFBQSxnQkFDSHBDLFNBQWtDcUMsU0FDL0IsRUFBRXpGLE9BQU8sVUFBVXFGLE9BQU9DLE9BQVFsQyxTQUFpQ3FDLE1BQU0sRUFBRSxJQUMzRTtBQUFBLGNBQUksRUFFUHhFLE9BQU95RSxPQUFPLEVBQ2QxQztBQUFBQSxnQkFBSSxDQUFDUSxTQUNKO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUVDLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFVBQUssV0FBVSw0Q0FBNENBLGVBQU14RCxTQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF3RTtBQUFBLHNCQUN4RSx1QkFBQyxVQUFLLFdBQVUsd0NBQXdDd0QsZUFBTTZCLFNBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW9FO0FBQUE7QUFBQTtBQUFBLGtCQUovRDdCLEtBQU14RDtBQUFBQSxrQkFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsY0FDRCxLQXBCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGNBSUYsdUJBQUMsU0FBSSxXQUFVLDhDQUNaNEU7QUFBQUEsc0JBQU1YLFVBQ0wsbUNBQ0U7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsV0FBVTtBQUFBLHNCQUNWLFVBQVVlO0FBQUFBLHNCQUNWLFNBQVMsTUFBTWhCLGtCQUFrQlksTUFBTVgsUUFBdUJXLE1BQU1LLEdBQUc7QUFBQSxzQkFFdEVELHNCQUFZLGFBQWE7QUFBQTtBQUFBLG9CQU41QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFRO0FBQUEsc0JBQ1IsTUFBSztBQUFBLHNCQUNMLFdBQVU7QUFBQSxzQkFDVixTQUFTLE1BQU1qRSxlQUFlNkQsTUFBTVgsTUFBcUI7QUFBQSxzQkFBRTtBQUFBO0FBQUEsb0JBSjdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPQTtBQUFBLHFCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlCQTtBQUFBLGdCQUVEVyxNQUFNcEMsV0FBVyxVQUNoQjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFRO0FBQUEsb0JBQ1IsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixVQUFVd0M7QUFBQUEsb0JBQ1YsU0FBUyxNQUFNdkIsa0JBQWtCbUIsTUFBTUssR0FBRztBQUFBLG9CQUFFO0FBQUE7QUFBQSxrQkFMOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVFBO0FBQUEsZ0JBRUY7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBUTtBQUFBLG9CQUNSLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQ1YsVUFBVUQ7QUFBQUEsb0JBQ1YsU0FBUyxNQUFNcEIsY0FBY2dCLE1BQU1LLEdBQUc7QUFBQSxvQkFBRTtBQUFBO0FBQUEsa0JBTDFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVE7QUFBQSxvQkFDUixNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLFVBQVVEO0FBQUFBLG9CQUNWLFNBQVMsTUFBTWxCLGFBQWFjLE1BQU1LLEdBQUc7QUFBQSxvQkFBRTtBQUFBO0FBQUEsa0JBTHpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRQTtBQUFBLG1CQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWtEQTtBQUFBO0FBQUE7QUFBQSxVQXRHS0wsTUFBTUs7QUFBQUEsVUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBd0dBO0FBQUEsTUFFSixDQUFDLEtBekhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwSEE7QUFBQSxTQWxKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0pBLEtBcE1KO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzTUE7QUFBQSxPQXRRSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd1FBO0FBRUo7QUFBQ2pFLEdBeFZlSixvQkFBa0I7QUFBQSxVQVFiL0IsVUFDTUQsYUFDSkEsYUFDREEsYUFDR0EsV0FBVztBQUFBO0FBQUEsS0FacEJnQztBQUFrQixJQUFBK0U7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsInVzZVN0YXRlIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsImFwaSIsImNuIiwiQnV0dG9uIiwiU3RhdHVzQmFkZ2UiLCJBbGVydFRyaWFuZ2xlIiwiQ2hlY2tDaXJjbGUyIiwiQ2hldnJvbkRvd24iLCJDaGV2cm9uUmlnaHQiLCJNZXNzYWdlU3F1YXJlV2FybmluZyIsIlJlZnJlc2hDdyIsIlNoaWVsZEFsZXJ0IiwiU2hpZWxkQ2hlY2siLCJYQ2lyY2xlIiwiWmFwIiwiQ2xvY2siLCJMT09QX1RZUEVfSU5GTyIsIkNPTU1FTlRfU1RPUk0iLCJpY29uIiwibGFiZWwiLCJkZXNjcmlwdGlvbiIsImNvbG9yQ2xhc3MiLCJib3JkZXJDbGFzcyIsIlJFVklFV19QSU5HX1BPTkciLCJCQUNLX0FORF9GT1JUSCIsIlJFUEVBVEVEX0ZBSUxVUkVTIiwiU0VWRVJJVFlfQ09ORklHIiwiQ1JJVElDQUwiLCJ0b25lIiwiV0FSTklORyIsIklORk8iLCJMb29wRGV0ZWN0aW9uUGFuZWwiLCJwcm9qZWN0SWQiLCJfcHJvamVjdElkIiwib25UYXNrU2VsZWN0IiwiX3MiLCJmaWx0ZXIiLCJzZXRGaWx0ZXIiLCJleHBhbmRlZCIsInNldEV4cGFuZGVkIiwiYWN0aW9uTG9hZGluZyIsInNldEFjdGlvbkxvYWRpbmciLCJvcGVuQWxlcnRzIiwiYWxlcnRzIiwibGlzdE9wZW4iLCJsaW1pdCIsImFja25vd2xlZGdlQWxlcnQiLCJhY2tub3dsZWRnZSIsInJlc29sdmVBbGVydCIsInJlc29sdmUiLCJpZ25vcmVBbGVydCIsImlnbm9yZSIsInRyYW5zaXRpb25UYXNrIiwidGFza3MiLCJ0cmFuc2l0aW9uIiwibG9vcEFsZXJ0cyIsImEiLCJ0eXBlIiwiZmlsdGVyZWRBbGVydHMiLCJzdGF0dXMiLCJoYXNMb29wQWxlcnRzIiwibGVuZ3RoIiwib3BlbkNvdW50IiwiYWNrbm93bGVkZ2VkQ291bnQiLCJzdW1tYXJ5IiwiT2JqZWN0IiwiZW50cmllcyIsIm1hcCIsImluZm8iLCJjb3VudCIsIm1ldGFkYXRhIiwibG9vcERhdGEiLCJ0aXRsZSIsImluY2x1ZGVzIiwiYWN0aXZlU3VtbWFyeSIsIml0ZW0iLCJoYW5kbGVBY2tub3dsZWRnZSIsImFsZXJ0SWQiLCJhY2tub3dsZWRnZWRCeSIsImhhbmRsZVJlc29sdmUiLCJyZXNvbHV0aW9uTm90ZSIsImhhbmRsZUlnbm9yZSIsInJlYXNvbiIsImhhbmRsZVVuYmxvY2tUYXNrIiwidGFza0lkIiwidG9TdGF0dXMiLCJhY3RvclR5cGUiLCJpZGVtcG90ZW5jeUtleSIsIkRhdGUiLCJub3ciLCJ2IiwidG9Mb2NhbGVUaW1lU3RyaW5nIiwiaG91ciIsIm1pbnV0ZSIsImYiLCJhbGVydCIsImxvb3BUeXBlIiwic2V2ZXJpdHlDb25maWciLCJzZXZlcml0eSIsImlzTG9hZGluZyIsIl9pZCIsInJlcGxhY2UiLCJfY3JlYXRpb25UaW1lIiwidG9Mb2NhbGVTdHJpbmciLCJ2YWx1ZSIsIlN0cmluZyIsInRocmVzaG9sZCIsIndpbmRvdyIsImRldGFpbCIsIkJvb2xlYW4iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJMb29wRGV0ZWN0aW9uUGFuZWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogTG9vcCBEZXRlY3Rpb24gUGFuZWxcbiAqXG4gKiBTaG93cyBsb29wLWRldGVjdGVkIGFsZXJ0cyAoY29tbWVudCBzdG9ybXMsIHJldmlldyBwaW5nLXBvbmcsIHJlcGVhdGVkIGZhaWx1cmVzKVxuICogYW5kIHByb3ZpZGVzIG9uZS1jbGljayBhY3Rpb25zIHRvIGFja25vd2xlZGdlLCByZXNvbHZlLCBvciB1bmJsb2NrIHRhc2tzLlxuICovXG5cbmltcG9ydCB7IHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnkgfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQgeyBTdGF0dXNCYWRnZSwgdHlwZSBTdGF0dXNCYWRnZVByb3BzIH0gZnJvbSBcIkAvY29tcG9uZW50cy9mYWN0b3J5L2JhZGdlc1wiO1xuaW1wb3J0IHtcbiAgQWxlcnRUcmlhbmdsZSxcbiAgQ2hlY2tDaXJjbGUyLFxuICBDaGV2cm9uRG93bixcbiAgQ2hldnJvblJpZ2h0LFxuICBNZXNzYWdlU3F1YXJlV2FybmluZyxcbiAgUmVmcmVzaEN3LFxuICBTaGllbGRBbGVydCxcbiAgU2hpZWxkQ2hlY2ssXG4gIFhDaXJjbGUsXG4gIFphcCxcbiAgQ2xvY2ssXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcblxuaW50ZXJmYWNlIExvb3BEZXRlY3Rpb25QYW5lbFByb3BzIHtcbiAgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+IHwgbnVsbDtcbiAgb25UYXNrU2VsZWN0PzogKHRhc2tJZDogSWQ8XCJ0YXNrc1wiPikgPT4gdm9pZDtcbn1cblxudHlwZSBMb29wVHlwZSA9IFwiQ09NTUVOVF9TVE9STVwiIHwgXCJSRVZJRVdfUElOR19QT05HXCIgfCBcIkJBQ0tfQU5EX0ZPUlRIXCIgfCBcIlJFUEVBVEVEX0ZBSUxVUkVTXCI7XG5cbmNvbnN0IExPT1BfVFlQRV9JTkZPOiBSZWNvcmQ8XG4gIHN0cmluZyxcbiAgeyBpY29uOiBSZWFjdC5SZWFjdE5vZGU7IGxhYmVsOiBzdHJpbmc7IGRlc2NyaXB0aW9uOiBzdHJpbmc7IGNvbG9yQ2xhc3M6IHN0cmluZzsgYm9yZGVyQ2xhc3M6IHN0cmluZyB9XG4+ID0ge1xuICBDT01NRU5UX1NUT1JNOiB7XG4gICAgaWNvbjogPE1lc3NhZ2VTcXVhcmVXYXJuaW5nIGNsYXNzTmFtZT1cImgtNCB3LTRcIiBzdHJva2VXaWR0aD17MS43NX0gLz4sXG4gICAgbGFiZWw6IFwiQ29tbWVudCBTdG9ybVwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIlRvbyBtYW55IG1lc3NhZ2VzIGluIGEgc2hvcnQgd2luZG93XCIsXG4gICAgY29sb3JDbGFzczogXCJ0ZXh0LXdhcm5cIixcbiAgICBib3JkZXJDbGFzczogXCJib3JkZXItd2FyblwiLFxuICB9LFxuICBSRVZJRVdfUElOR19QT05HOiB7XG4gICAgaWNvbjogPFJlZnJlc2hDdyBjbGFzc05hbWU9XCJoLTQgdy00XCIgc3Ryb2tlV2lkdGg9ezEuNzV9IC8+LFxuICAgIGxhYmVsOiBcIlJldmlldyBQaW5nLVBvbmdcIixcbiAgICBkZXNjcmlwdGlvbjogXCJFeGNlc3NpdmUgcmV2aWV3IGN5Y2xlcyB3aXRob3V0IHJlc29sdXRpb25cIixcbiAgICBjb2xvckNsYXNzOiBcInRleHQtZXJyXCIsXG4gICAgYm9yZGVyQ2xhc3M6IFwiYm9yZGVyLWVyclwiLFxuICB9LFxuICBCQUNLX0FORF9GT1JUSDoge1xuICAgIGljb246IDxaYXAgY2xhc3NOYW1lPVwiaC00IHctNFwiIHN0cm9rZVdpZHRoPXsxLjc1fSAvPixcbiAgICBsYWJlbDogXCJTdGF0ZSBDaHVyblwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIlRhc2sgcmVwZWF0ZWRseSBib3VuY2luZyBiZXR3ZWVuIHN0YXRlc1wiLFxuICAgIGNvbG9yQ2xhc3M6IFwidGV4dC13YXJuXCIsXG4gICAgYm9yZGVyQ2xhc3M6IFwiYm9yZGVyLXdhcm5cIixcbiAgfSxcbiAgUkVQRUFURURfRkFJTFVSRVM6IHtcbiAgICBpY29uOiA8WENpcmNsZSBjbGFzc05hbWU9XCJoLTQgdy00XCIgc3Ryb2tlV2lkdGg9ezEuNzV9IC8+LFxuICAgIGxhYmVsOiBcIlJlcGVhdGVkIEZhaWx1cmVzXCIsXG4gICAgZGVzY3JpcHRpb246IFwiU2FtZSBvcGVyYXRpb24gZmFpbGluZyByZXBlYXRlZGx5XCIsXG4gICAgY29sb3JDbGFzczogXCJ0ZXh0LWVyclwiLFxuICAgIGJvcmRlckNsYXNzOiBcImJvcmRlci1lcnJcIixcbiAgfSxcbn07XG5cbmNvbnN0IFNFVkVSSVRZX0NPTkZJRzogUmVjb3JkPHN0cmluZywgeyBsYWJlbDogc3RyaW5nOyB0b25lOiBTdGF0dXNCYWRnZVByb3BzW1widG9uZVwiXSB9PiA9IHtcbiAgQ1JJVElDQUw6IHsgbGFiZWw6IFwiQ3JpdGljYWxcIiwgdG9uZTogXCJlcnJvclwiIH0sXG4gIFdBUk5JTkc6IHsgbGFiZWw6IFwiV2FybmluZ1wiLCB0b25lOiBcIndhcm5pbmdcIiB9LFxuICBJTkZPOiB7IGxhYmVsOiBcIkluZm9cIiwgdG9uZTogXCJpbmZvXCIgfSxcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBMb29wRGV0ZWN0aW9uUGFuZWwoe1xuICBwcm9qZWN0SWQ6IF9wcm9qZWN0SWQsXG4gIG9uVGFza1NlbGVjdCxcbn06IExvb3BEZXRlY3Rpb25QYW5lbFByb3BzKSB7XG4gIGNvbnN0IFtmaWx0ZXIsIHNldEZpbHRlcl0gPSB1c2VTdGF0ZTxcImFsbFwiIHwgXCJPUEVOXCIgfCBcIkFDS05PV0xFREdFRFwiPihcImFsbFwiKTtcbiAgY29uc3QgW2V4cGFuZGVkLCBzZXRFeHBhbmRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFthY3Rpb25Mb2FkaW5nLCBzZXRBY3Rpb25Mb2FkaW5nXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IG9wZW5BbGVydHMgPSB1c2VRdWVyeShhcGkuYWxlcnRzLmxpc3RPcGVuLCB7IGxpbWl0OiAxMDAgfSk7XG4gIGNvbnN0IGFja25vd2xlZGdlQWxlcnQgPSB1c2VNdXRhdGlvbihhcGkuYWxlcnRzLmFja25vd2xlZGdlKTtcbiAgY29uc3QgcmVzb2x2ZUFsZXJ0ID0gdXNlTXV0YXRpb24oYXBpLmFsZXJ0cy5yZXNvbHZlKTtcbiAgY29uc3QgaWdub3JlQWxlcnQgPSB1c2VNdXRhdGlvbihhcGkuYWxlcnRzLmlnbm9yZSk7XG4gIGNvbnN0IHRyYW5zaXRpb25UYXNrID0gdXNlTXV0YXRpb24oYXBpLnRhc2tzLnRyYW5zaXRpb24pO1xuXG4gIGNvbnN0IGxvb3BBbGVydHMgPSAob3BlbkFsZXJ0cyA/PyBbXSkuZmlsdGVyKChhKSA9PiBhLnR5cGUgPT09IFwiTE9PUF9ERVRFQ1RFRFwiKTtcbiAgY29uc3QgZmlsdGVyZWRBbGVydHMgPSBmaWx0ZXIgPT09IFwiYWxsXCIgPyBsb29wQWxlcnRzIDogbG9vcEFsZXJ0cy5maWx0ZXIoKGEpID0+IGEuc3RhdHVzID09PSBmaWx0ZXIpO1xuICBjb25zdCBoYXNMb29wQWxlcnRzID0gbG9vcEFsZXJ0cy5sZW5ndGggPiAwO1xuICBjb25zdCBvcGVuQ291bnQgPSBsb29wQWxlcnRzLmZpbHRlcigoYSkgPT4gYS5zdGF0dXMgPT09IFwiT1BFTlwiKS5sZW5ndGg7XG4gIGNvbnN0IGFja25vd2xlZGdlZENvdW50ID0gbG9vcEFsZXJ0cy5maWx0ZXIoKGEpID0+IGEuc3RhdHVzID09PSBcIkFDS05PV0xFREdFRFwiKS5sZW5ndGg7XG5cbiAgY29uc3Qgc3VtbWFyeSA9IHVzZU1lbW8oXG4gICAgKCkgPT5cbiAgICAgIE9iamVjdC5lbnRyaWVzKExPT1BfVFlQRV9JTkZPKS5tYXAoKFt0eXBlLCBpbmZvXSkgPT4gKHtcbiAgICAgICAgdHlwZTogdHlwZSBhcyBMb29wVHlwZSxcbiAgICAgICAgaW5mbyxcbiAgICAgICAgY291bnQ6IGxvb3BBbGVydHMuZmlsdGVyKFxuICAgICAgICAgIChhKSA9PiAoYS5tZXRhZGF0YSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiAmIHsgbG9vcERhdGE/OiB7IHR5cGU/OiBzdHJpbmcgfSB9KT8ubG9vcERhdGE/LnR5cGUgPT09IHR5cGUgfHwgYS50aXRsZS5pbmNsdWRlcyh0eXBlKVxuICAgICAgICApLmxlbmd0aCxcbiAgICAgIH0pKSxcbiAgICBbbG9vcEFsZXJ0c11cbiAgKTtcblxuICBjb25zdCBhY3RpdmVTdW1tYXJ5ID0gc3VtbWFyeS5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0uY291bnQgPiAwKTtcblxuICBjb25zdCBoYW5kbGVBY2tub3dsZWRnZSA9IGFzeW5jIChhbGVydElkOiBJZDxcImFsZXJ0c1wiPikgPT4ge1xuICAgIHNldEFjdGlvbkxvYWRpbmcoYWxlcnRJZCk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGFja25vd2xlZGdlQWxlcnQoeyBhbGVydElkLCBhY2tub3dsZWRnZWRCeTogXCJvcGVyYXRvclwiIH0pO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRBY3Rpb25Mb2FkaW5nKG51bGwpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVSZXNvbHZlID0gYXN5bmMgKGFsZXJ0SWQ6IElkPFwiYWxlcnRzXCI+KSA9PiB7XG4gICAgc2V0QWN0aW9uTG9hZGluZyhhbGVydElkKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgcmVzb2x2ZUFsZXJ0KHsgYWxlcnRJZCwgcmVzb2x1dGlvbk5vdGU6IFwiUmVzb2x2ZWQgdmlhIExvb3AgRGV0ZWN0aW9uIFBhbmVsXCIgfSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEFjdGlvbkxvYWRpbmcobnVsbCk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUlnbm9yZSA9IGFzeW5jIChhbGVydElkOiBJZDxcImFsZXJ0c1wiPikgPT4ge1xuICAgIHNldEFjdGlvbkxvYWRpbmcoYWxlcnRJZCk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGlnbm9yZUFsZXJ0KHsgYWxlcnRJZCwgcmVhc29uOiBcIklnbm9yZWQgdmlhIExvb3AgRGV0ZWN0aW9uIFBhbmVsXCIgfSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEFjdGlvbkxvYWRpbmcobnVsbCk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVVuYmxvY2tUYXNrID0gYXN5bmMgKHRhc2tJZDogSWQ8XCJ0YXNrc1wiPiwgYWxlcnRJZDogSWQ8XCJhbGVydHNcIj4pID0+IHtcbiAgICBzZXRBY3Rpb25Mb2FkaW5nKGFsZXJ0SWQpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0cmFuc2l0aW9uVGFzayh7XG4gICAgICAgIHRhc2tJZCxcbiAgICAgICAgdG9TdGF0dXM6IFwiQVNTSUdORURcIixcbiAgICAgICAgYWN0b3JUeXBlOiBcIkhVTUFOXCIsXG4gICAgICAgIHJlYXNvbjogXCJVbmJsb2NrZWQgZnJvbSBMb29wIERldGVjdGlvbiBQYW5lbFwiLFxuICAgICAgICBpZGVtcG90ZW5jeUtleTogYHVuYmxvY2stbG9vcC0ke3Rhc2tJZH0tJHtEYXRlLm5vdygpfWAsXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IHJlc29sdmVBbGVydCh7IGFsZXJ0SWQsIHJlc29sdXRpb25Ob3RlOiBcIlRhc2sgdW5ibG9ja2VkIGJ5IG9wZXJhdG9yXCIgfSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEFjdGlvbkxvYWRpbmcobnVsbCk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJteC00IG15LTMgc2hyaW5rLTAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xXCI+XG4gICAgICB7LyogSGVhZGVyICovfVxuICAgICAgPGJ1dHRvblxuICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RXhwYW5kZWQoKHYpID0+ICF2KX1cbiAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICBcImZsZXggdy1mdWxsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtNCBweS0zIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiLFxuICAgICAgICAgIGV4cGFuZGVkID8gXCJyb3VuZGVkLXQteGxcIiA6IFwicm91bmRlZC14bFwiLFxuICAgICAgICAgIFwiaG92ZXI6Ymctc3VyZmFjZS0yXCJcbiAgICAgICAgKX1cbiAgICAgID5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgIHsvKiBTdGF0dXMgZG90ICovfVxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17Y24oXCJoLTIgdy0yIHJvdW5kZWQtZnVsbFwiLCBoYXNMb29wQWxlcnRzID8gXCJiZy13YXJuXCIgOiBcImJnLW9rXCIpfSAvPlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPFNoaWVsZEFsZXJ0XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXCJoLTQgdy00XCIsIGhhc0xvb3BBbGVydHMgPyBcInRleHQtd2FyblwiIDogXCJ0ZXh0LWluay1tdXRlZFwiKX1cbiAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezEuNzV9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTMuNXB4XSBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+TG9vcCBSaXNrIE1vbml0b3I8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7aGFzTG9vcEFsZXJ0cyA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICB7b3BlbkNvdW50ID4gMCAmJiA8U3RhdHVzQmFkZ2UgdG9uZT1cImVycm9yXCI+e29wZW5Db3VudH0gb3BlbjwvU3RhdHVzQmFkZ2U+fVxuICAgICAgICAgICAgICB7YWNrbm93bGVkZ2VkQ291bnQgPiAwICYmIChcbiAgICAgICAgICAgICAgICA8U3RhdHVzQmFkZ2UgdG9uZT1cIm5ldXRyYWxcIj57YWNrbm93bGVkZ2VkQ291bnR9IGFja25vd2xlZGdlZDwvU3RhdHVzQmFkZ2U+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPFN0YXR1c0JhZGdlIHRvbmU9XCJzdWNjZXNzXCI+QWxsIGNsZWFyPC9TdGF0dXNCYWRnZT5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAge2hhc0xvb3BBbGVydHMgJiYgYWN0aXZlU3VtbWFyeS5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgbXItMVwiPlxuICAgICAgICAgICAgICB7YWN0aXZlU3VtbWFyeS5tYXAoKHsgdHlwZSwgaW5mbywgY291bnQgfSkgPT4gKFxuICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICBrZXk9e3R5cGV9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICBcImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMiBweC0xLjUgcHktMC41IHRleHQtWzExcHhdXCIsXG4gICAgICAgICAgICAgICAgICAgIGluZm8uY29sb3JDbGFzc1xuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7aW5mby5pY29ufVxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPntjb3VudH08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgICAge2V4cGFuZGVkXG4gICAgICAgICAgICA/IDxDaGV2cm9uRG93biBjbGFzc05hbWU9XCJoLTQgdy00XCIgc3Ryb2tlV2lkdGg9ezEuNzV9IC8+XG4gICAgICAgICAgICA6IDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwiaC00IHctNFwiIHN0cm9rZVdpZHRoPXsxLjc1fSAvPlxuICAgICAgICAgIH1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2J1dHRvbj5cblxuICAgICAgey8qIERpdmlkZXIgb25seSB3aGVuIGV4cGFuZGVkICovfVxuICAgICAge2V4cGFuZGVkICYmIDxkaXYgY2xhc3NOYW1lPVwiaC1weCBteC00IGJnLWxpbmVcIiAvPn1cblxuICAgICAgey8qIEV4cGFuZGVkIGJvZHkgKi99XG4gICAgICB7ZXhwYW5kZWQgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgcGItNCBwdC0zIHNwYWNlLXktM1wiPlxuICAgICAgICAgIHshaGFzTG9vcEFsZXJ0cyA/IChcbiAgICAgICAgICAgIC8qIEFsbC1jbGVhciBzdGF0ZSAqL1xuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTIgcC00XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgPFNoaWVsZENoZWNrIGNsYXNzTmFtZT1cImgtNSB3LTUgc2hyaW5rLTAgdGV4dC1va1wiIHN0cm9rZVdpZHRoPXsxLjc1fSAvPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEzLjVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPk5vIGFjdGl2ZSBsb29wIGluY2lkZW50czwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8U3RhdHVzQmFkZ2UgdG9uZT1cInN1Y2Nlc3NcIj5TdGFibGU8L1N0YXR1c0JhZGdlPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICBDb21tZW50IHN0b3JtcyBhbmQgc3RhdGUgY2h1cm4gYXJlIGN1cnJlbnRseSBzdGFibGUuXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaHJpbmstMCB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSB0ZXh0LWluay1tdXRlZFwiPkxhc3Qgc2NhbjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEyLjVweF0gZm9udC1tZWRpdW0gdGV4dC1pbmstc2Vjb25kYXJ5IG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZyhbXSwgeyBob3VyOiBcIjItZGlnaXRcIiwgbWludXRlOiBcIjItZGlnaXRcIiB9KX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFBlci1tb25pdG9yIGhlYWx0aCByb3dzICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICB7T2JqZWN0LmVudHJpZXMoTE9PUF9UWVBFX0lORk8pLm1hcCgoW3R5cGUsIGluZm9dKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIGtleT17dHlwZX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yIHB4LTMgcHktMi41IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBob3Zlcjpib3JkZXItbGluZS1zdHJvbmdcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cImgtMy41IHctMy41IHNocmluay0wIHRleHQtb2tcIiBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSBmb250LXNlbWlib2xkIHRleHQtaW5rLXNlY29uZGFyeSB0cnVuY2F0ZVwiPntpbmZvLmxhYmVsfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSB0ZXh0LWluay1tdXRlZCBtdC0wLjVcIj4wIGluY2lkZW50czwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogRm9vdGVyIG5vdGUgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtMSB0ZXh0LVsxMS41cHhdIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAgICAgICAgPENsb2NrIGNsYXNzTmFtZT1cImgtMyB3LTNcIiBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5Mb29wIGRldGVjdGlvbiBzY2FucyBldmVyeSA1IG1pbnV0ZXMgwrcgUG93ZXJlZCBieSBDb252ZXggY3Jvbjwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgey8qIEZpbHRlciB0YWJzICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMC41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1saW5lIHAtMC41XCI+XG4gICAgICAgICAgICAgICAgeyhbXCJhbGxcIiwgXCJPUEVOXCIsIFwiQUNLTk9XTEVER0VEXCJdIGFzIGNvbnN0KS5tYXAoKGYpID0+IChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAga2V5PXtmfVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRGaWx0ZXIoZil9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgXCJoLTcgcHgtMyByb3VuZGVkLW1kIHRleHQteHMgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCIsXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyID09PSBmXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctc3VyZmFjZS0yIHRleHQtaW5rXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWluay1tdXRlZCBob3Zlcjp0ZXh0LWlua1wiXG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtmID09PSBcImFsbFwiID8gXCJBbGxcIiA6IGYgPT09IFwiT1BFTlwiID8gYE9wZW4gKCR7b3BlbkNvdW50fSlgIDogYEFja25vd2xlZGdlZCAoJHthY2tub3dsZWRnZWRDb3VudH0pYH1cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7ZmlsdGVyZWRBbGVydHMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS0zIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1kYXNoZWQgYm9yZGVyLWxpbmUgdGV4dC14cyB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgTm8gaW5jaWRlbnRzIGZvciB0aGlzIGZpbHRlci5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZEFsZXJ0cy5tYXAoKGFsZXJ0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGxvb3BEYXRhID0gKGFsZXJ0Lm1ldGFkYXRhIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+ICYgeyBsb29wRGF0YT86IFJlY29yZDxzdHJpbmcsIHVua25vd24+IH0pPy5sb29wRGF0YTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbG9vcFR5cGUgPSAobG9vcERhdGEgYXMgeyB0eXBlPzogc3RyaW5nIH0pPy50eXBlID8/IFwiVU5LTk9XTlwiO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpbmZvID0gTE9PUF9UWVBFX0lORk9bbG9vcFR5cGVdID8/IHtcbiAgICAgICAgICAgICAgICAgICAgICBpY29uOiA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJoLTQgdy00XCIgc3Ryb2tlV2lkdGg9ezEuNzV9IC8+LFxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBsb29wVHlwZSxcbiAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJcIixcbiAgICAgICAgICAgICAgICAgICAgICBjb2xvckNsYXNzOiBcInRleHQtd2FyblwiLFxuICAgICAgICAgICAgICAgICAgICAgIGJvcmRlckNsYXNzOiBcImJvcmRlci13YXJuXCIsXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHNldmVyaXR5Q29uZmlnID0gU0VWRVJJVFlfQ09ORklHW2FsZXJ0LnNldmVyaXR5XSA/PyBTRVZFUklUWV9DT05GSUcuSU5GTztcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNMb2FkaW5nID0gYWN0aW9uTG9hZGluZyA9PT0gYWxlcnQuX2lkO1xuXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXthbGVydC5faWR9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICAgICAgICBcInJvdW5kZWQtbGcgYm9yZGVyLWwtMiBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xIHAtMyBzcGFjZS15LTIuNVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBpbmZvLmJvcmRlckNsYXNzLnJlcGxhY2UoXCJib3JkZXItXCIsIFwiYm9yZGVyLWwtXCIpXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBBbGVydCBoZWFkZXIgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtjbihcIm10LTAuNSBzaHJpbmstMFwiLCBpbmZvLmNvbG9yQ2xhc3MpfT57aW5mby5pY29ufTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMy41cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmsgbGVhZGluZy10aWdodFwiPnthbGVydC50aXRsZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSB0ZXh0LWluay1tdXRlZCBtdC0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKGFsZXJ0Ll9jcmVhdGlvblRpbWUpLnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTdGF0dXNCYWRnZSB0b25lPXtzZXZlcml0eUNvbmZpZy50b25lfSBjbGFzc05hbWU9XCJzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZXZlcml0eUNvbmZpZy5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TdGF0dXNCYWRnZT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogRGVzY3JpcHRpb24gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMi41cHhdIHRleHQtaW5rLXNlY29uZGFyeSBsZWFkaW5nLXJlbGF4ZWRcIj57YWxlcnQuZGVzY3JpcHRpb259PC9wPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogTG9vcCBkZXRhaWwgY2hpcHMgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICB7bG9vcERhdGEgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7W1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJDb3VudFwiLCB2YWx1ZTogU3RyaW5nKChsb29wRGF0YSBhcyB7IGNvdW50PzogdW5rbm93biB9KS5jb3VudCkgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiVGhyZXNob2xkXCIsIHZhbHVlOiBTdHJpbmcoKGxvb3BEYXRhIGFzIHsgdGhyZXNob2xkPzogdW5rbm93biB9KS50aHJlc2hvbGQpIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAobG9vcERhdGEgYXMgeyB3aW5kb3c/OiB1bmtub3duIH0pLndpbmRvd1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHsgbGFiZWw6IFwiV2luZG93XCIsIHZhbHVlOiBgJHsobG9vcERhdGEgYXMgeyB3aW5kb3c6IHVua25vd24gfSkud2luZG93fSBtaW5gIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGxvb3BEYXRhIGFzIHsgZGV0YWlsPzogdW5rbm93biB9KS5kZXRhaWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB7IGxhYmVsOiBcIkRldGFpbFwiLCB2YWx1ZTogU3RyaW5nKChsb29wRGF0YSBhcyB7IGRldGFpbDogdW5rbm93biB9KS5kZXRhaWwpIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoQm9vbGVhbilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbSEubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yIHB5LTEgcm91bmRlZC1tZCBiZy1zdXJmYWNlLTIgYm9yZGVyIGJvcmRlci1saW5lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExLjVweF0gdGV4dC1pbmstbXV0ZWQgZm9udC1tZWRpdW1cIj57aXRlbSEubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExLjVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPntpdGVtIS52YWx1ZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEFjdGlvbnMgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMS41IHB0LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7YWxlcnQudGFza0lkICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTcgdGV4dC14cyBweC0zXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVW5ibG9ja1Rhc2soYWxlcnQudGFza0lkIGFzIElkPFwidGFza3NcIj4sIGFsZXJ0Ll9pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyBcIldvcmtpbmfigKZcIiA6IFwiVW5ibG9jayBUYXNrXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTcgdGV4dC14cyBweC0zXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25UYXNrU2VsZWN0Py4oYWxlcnQudGFza0lkIGFzIElkPFwidGFza3NcIj4pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBWaWV3IFRhc2tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7YWxlcnQuc3RhdHVzID09PSBcIk9QRU5cIiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtNyB0ZXh0LXhzIHB4LTNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUFja25vd2xlZGdlKGFsZXJ0Ll9pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWNrbm93bGVkZ2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtNyB0ZXh0LXhzIHB4LTNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUmVzb2x2ZShhbGVydC5faWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVzb2x2ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTcgdGV4dC14cyBweC0zIHRleHQtaW5rLW11dGVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUlnbm9yZShhbGVydC5faWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgSWdub3JlXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL0xvb3BEZXRlY3Rpb25QYW5lbC50c3gifQ==