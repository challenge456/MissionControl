import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/controlPlane/FactoryOverviewView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { ClipboardList, Loader2, ShieldAlert, Sparkles, Waypoints } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { useMutation, useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { PageHeader } from "/src/components/PageHeader.tsx";
import { Badge } from "/src/components/ui/badge.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { buildFactoryOverviewCards, summarizeAttentionLoad } from "/src/controlPlane/factoryOverviewModel.ts";
export function FactoryOverviewView({ projectId, onNavigate }) {
  _s();
  const overview = useQuery(api.workOrders.factoryOverview, { projectId: projectId ?? void 0, limit: 5 });
  const createSoftwareFactoryProject = useMutation(api.projects.createSoftwareFactoryProject);
  const [createState, setCreateState] = useState("idle");
  const [createMessage, setCreateMessage] = useState(null);
  const handleCreateSoftwareFactoryProject = async () => {
    setCreateState("submitting");
    setCreateMessage(null);
    try {
      const result = await createSoftwareFactoryProject({
        name: "Apple Notes Software Factory",
        slug: "apple-notes-software-factory",
        repository: "jaydubya818/MissionControl",
        githubBranch: "main",
        requestedBy: "Hermes"
      });
      setCreateState(result.created ? "created" : "replayed");
      setCreateMessage(
        result.created ? `Created ${result.createdWorkOrders} factory WorkOrders for ${result.project?.name ?? "the project"}.` : `${result.project?.name ?? "Software factory project"} already exists; refreshed the read model.`
      );
    } catch (error) {
      setCreateState("error");
      setCreateMessage(error instanceof Error ? error.message : "Failed to create software factory project.");
    }
  };
  if (!overview) {
    return /* @__PURE__ */ jsxDEV("section", { className: "flex flex-1 flex-col overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV(PageHeader, { eyebrow: "Control plane", title: "Portfolio", description: "Live factory overview backed by WorkOrders, approvals, and execution runs.", icon: /* @__PURE__ */ jsxDEV(Waypoints, { className: "h-5 w-5" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
        lineNumber: 64,
        columnNumber: 158
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
        lineNumber: 64,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-1 items-center justify-center p-6 text-sm text-muted-foreground", children: [
        /* @__PURE__ */ jsxDEV(Loader2, { className: "mr-2 h-4 w-4 animate-spin" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
          lineNumber: 66,
          columnNumber: 11
        }, this),
        " Loading factory overview…"
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
        lineNumber: 65,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
      lineNumber: 63,
      columnNumber: 7
    }, this);
  }
  const cards = buildFactoryOverviewCards(overview.summary);
  const attentionLoad = summarizeAttentionLoad(overview.summary);
  return /* @__PURE__ */ jsxDEV("section", { className: "flex flex-1 flex-col overflow-hidden", children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        eyebrow: "Control plane",
        title: "Portfolio",
        description: "Exception-first overview of software-factory throughput, approvals, stale evidence, and runs needing attention.",
        icon: /* @__PURE__ */ jsxDEV(Waypoints, { className: "h-5 w-5" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
          lineNumber: 81,
          columnNumber: 15
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
        lineNumber: 77,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-y-auto p-5 space-y-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-3 md:grid-cols-2 xl:grid-cols-6", children: cards.map(
        (card) => /* @__PURE__ */ jsxDEV(Card, { children: /* @__PURE__ */ jsxDEV(CardHeader, { className: "pb-2", children: [
          /* @__PURE__ */ jsxDEV(CardDescription, { children: card.label }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
            lineNumber: 89,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(CardTitle, { className: toneClass(card.tone), children: card.value }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
            lineNumber: 90,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
          lineNumber: 88,
          columnNumber: 15
        }, this) }, card.key, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
          lineNumber: 87,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
        lineNumber: 85,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 xl:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]", children: [
        /* @__PURE__ */ jsxDEV(Card, { children: [
          /* @__PURE__ */ jsxDEV(CardHeader, { children: [
            /* @__PURE__ */ jsxDEV(CardTitle, { children: "Project creation" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
              lineNumber: 99,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(CardDescription, { children: "Create the Apple Notes software-factory project and hydrate the project-scoped read model with WorkOrders, runs, approvals, artifacts, and receipts." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
              lineNumber: 100,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
            lineNumber: 98,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(CardContent, { className: "space-y-3", children: [
            /* @__PURE__ */ jsxDEV(Button, { variant: "neon-cyan", onClick: handleCreateSoftwareFactoryProject, disabled: createState === "submitting", children: [
              createState === "submitting" ? /* @__PURE__ */ jsxDEV(Loader2, { className: "h-4 w-4 animate-spin" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
                lineNumber: 104,
                columnNumber: 49
              }, this) : /* @__PURE__ */ jsxDEV(Sparkles, { className: "h-4 w-4" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
                lineNumber: 104,
                columnNumber: 96
              }, this),
              "Create factory project"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
              lineNumber: 103,
              columnNumber: 15
            }, this),
            createMessage && /* @__PURE__ */ jsxDEV("div", { className: `rounded-2xl border p-3 text-sm ${createState === "error" ? "border-red-500/30 text-red-200" : "border-emerald-500/30 text-emerald-200"}`, children: createMessage }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
              lineNumber: 108,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
            lineNumber: 102,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
          lineNumber: 97,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { children: [
          /* @__PURE__ */ jsxDEV(CardHeader, { children: [
            /* @__PURE__ */ jsxDEV(CardTitle, { children: "Operator attention" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
              lineNumber: 117,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(CardDescription, { children: [
              attentionLoad,
              " live exceptions currently need a decision, rerun, or evidence refresh."
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
              lineNumber: 118,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
            lineNumber: 116,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(CardContent, { className: "flex flex-wrap gap-2", children: [
            /* @__PURE__ */ jsxDEV(Button, { variant: "outline", onClick: () => onNavigate("control-work-orders"), children: [
              /* @__PURE__ */ jsxDEV(ClipboardList, { className: "h-4 w-4" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
                lineNumber: 121,
                columnNumber: 91
              }, this),
              " Open Work Orders"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
              lineNumber: 121,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { variant: "outline", onClick: () => onNavigate("control-approvals"), children: [
              /* @__PURE__ */ jsxDEV(ShieldAlert, { className: "h-4 w-4" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
                lineNumber: 122,
                columnNumber: 89
              }, this),
              " Open Approval Center"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
              lineNumber: 122,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
            lineNumber: 120,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
          lineNumber: 115,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { children: [
          /* @__PURE__ */ jsxDEV(CardHeader, { children: [
            /* @__PURE__ */ jsxDEV(CardTitle, { children: "Recent acceptance" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
              lineNumber: 128,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(CardDescription, { children: "Recently accepted outcomes remain visible here as proof of throughput." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
              lineNumber: 129,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
            lineNumber: 127,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(CardContent, { className: "space-y-3", children: overview.recentAccepted.length === 0 ? /* @__PURE__ */ jsxDEV(EmptyLine, { label: "No recently accepted work yet." }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
            lineNumber: 132,
            columnNumber: 55
          }, this) : overview.recentAccepted.map(
            ({ workOrder, latestRun }) => /* @__PURE__ */ jsxDEV(
              OverviewRow,
              {
                title: workOrder.title,
                subtitle: workOrder.repository ?? workOrder.workflowId ?? "—",
                badge: latestRun?.status ?? workOrder.state,
                tone: "success"
              },
              workOrder._id,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
                lineNumber: 133,
                columnNumber: 15
              },
              this
            )
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
            lineNumber: 131,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
          lineNumber: 126,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
        lineNumber: 96,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 xl:grid-cols-2", children: [
        /* @__PURE__ */ jsxDEV(
          OverviewListCard,
          {
            title: "Blocked WorkOrders",
            description: "Requests that cannot progress until a human or system intervention happens.",
            empty: "No blocked WorkOrders.",
            items: overview.blockedWorkOrders.map(({ workOrder, latestRun }) => ({
              key: workOrder._id,
              title: workOrder.title,
              subtitle: workOrder.requiredHumanAction ?? workOrder.blockingIssue ?? latestRun?.failureReason ?? "Awaiting attention",
              badge: latestRun?.status ?? workOrder.state,
              tone: "danger"
            }))
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
            lineNumber: 146,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          OverviewListCard,
          {
            title: "Approval queue",
            description: "Human decisions currently blocking dispatch, acceptance, or revision flow.",
            empty: "No pending approvals.",
            items: overview.approvalQueue.map(({ _id, workOrder, approvalType, requestedAction }) => ({
              key: _id,
              title: workOrder?.title ?? approvalType,
              subtitle: requestedAction,
              badge: approvalType,
              tone: "warning"
            }))
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
            lineNumber: 159,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          OverviewListCard,
          {
            title: "Stale evidence",
            description: "Verification receipts that must be refreshed before acceptance can proceed.",
            empty: "No stale evidence.",
            items: overview.staleEvidence.map(({ receipt, workOrder }) => ({
              key: receipt._id,
              title: workOrder?.title ?? receipt.acceptanceCriterionId,
              subtitle: `Criterion ${receipt.acceptanceCriterionId}`,
              badge: receipt.status,
              tone: "warning"
            }))
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
            lineNumber: 172,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          OverviewListCard,
          {
            title: "Runs needing attention",
            description: "Latest execution runs with failures, pauses, retries, or human interventions.",
            empty: "No attention-seeking runs.",
            items: overview.runsNeedingAttention.map(({ workOrder, latestRun }) => ({
              key: latestRun._id,
              title: workOrder.title,
              subtitle: latestRun.failureReason ?? latestRun.currentStepLabel ?? latestRun.workflowId,
              badge: latestRun.status,
              tone: "danger"
            }))
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
            lineNumber: 185,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
        lineNumber: 145,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
      lineNumber: 84,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
    lineNumber: 76,
    columnNumber: 5
  }, this);
}
_s(FactoryOverviewView, "tUY+7RFyCumi1qBagd3TgYeCxDU=", false, function() {
  return [useQuery, useMutation];
});
_c = FactoryOverviewView;
function OverviewListCard({ title, description, empty, items }) {
  return /* @__PURE__ */ jsxDEV(Card, { children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { children: [
      /* @__PURE__ */ jsxDEV(CardTitle, { children: title }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
        lineNumber: 207,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(CardDescription, { children: description }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
        lineNumber: 208,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
      lineNumber: 206,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { className: "space-y-3", children: items.length === 0 ? /* @__PURE__ */ jsxDEV(EmptyLine, { label: empty }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
      lineNumber: 211,
      columnNumber: 31
    }, this) : items.map((item) => /* @__PURE__ */ jsxDEV(OverviewRow, { ...item }, item.key, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
      lineNumber: 211,
      columnNumber: 81
    }, this)) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
      lineNumber: 210,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
    lineNumber: 205,
    columnNumber: 5
  }, this);
}
_c2 = OverviewListCard;
function OverviewRow({ title, subtitle, badge, tone }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-[var(--panel-line)] bg-background/40 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-3", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-foreground", children: title }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
        lineNumber: 222,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-sm text-muted-foreground", children: subtitle }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
        lineNumber: 223,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
      lineNumber: 221,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", className: toneClass(tone), children: badge }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
      lineNumber: 225,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
    lineNumber: 220,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
    lineNumber: 219,
    columnNumber: 5
  }, this);
}
_c3 = OverviewRow;
function EmptyLine({ label }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-dashed border-[var(--panel-line)] p-4 text-sm text-muted-foreground", children: label }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx",
    lineNumber: 232,
    columnNumber: 10
  }, this);
}
_c4 = EmptyLine;
function toneClass(tone) {
  switch (tone) {
    case "warning":
      return "text-amber-200 border-amber-500/30";
    case "danger":
      return "text-red-200 border-red-500/30";
    case "success":
      return "text-emerald-200 border-emerald-500/30";
    default:
      return "text-registry-accent border-registry-accent/30";
  }
}
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "FactoryOverviewView");
$RefreshReg$(_c2, "OverviewListCard");
$RefreshReg$(_c3, "OverviewRow");
$RefreshReg$(_c4, "EmptyLine");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/FactoryOverviewView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEM2Sjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE1QzdKLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxlQUFlQyxTQUFTQyxhQUFhQyxVQUFVQyxpQkFBaUI7QUFDekUsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBRXRDLFNBQVNDLFdBQVc7QUFDcEIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxNQUFNQyxhQUFhQyxpQkFBaUJDLFlBQVlDLGlCQUFpQjtBQUMxRSxTQUFTQywyQkFBMkJDLDhCQUE4QjtBQUczRCxnQkFBU0Msb0JBQW9CLEVBQUVDLFdBQVdDLFdBQXVGLEdBQUc7QUFBQUMsS0FBQTtBQUN6SSxRQUFNQyxXQUFXaEIsU0FBU0MsSUFBSWdCLFdBQVdDLGlCQUFpQixFQUFFTCxXQUFXQSxhQUFhTSxRQUFXQyxPQUFPLEVBQUUsQ0FBQztBQUN6RyxRQUFNQywrQkFBK0J0QixZQUFZRSxJQUFJcUIsU0FBU0QsNEJBQTRCO0FBQzFGLFFBQU0sQ0FBQ0UsYUFBYUMsY0FBYyxJQUFJL0IsU0FBbUUsTUFBTTtBQUMvRyxRQUFNLENBQUNnQyxlQUFlQyxnQkFBZ0IsSUFBSWpDLFNBQXdCLElBQUk7QUFFdEUsUUFBTWtDLHFDQUFxQyxZQUFZO0FBQ3JESCxtQkFBZSxZQUFZO0FBQzNCRSxxQkFBaUIsSUFBSTtBQUNyQixRQUFJO0FBQ0YsWUFBTUUsU0FBUyxNQUFNUCw2QkFBNkI7QUFBQSxRQUNoRFEsTUFBTTtBQUFBLFFBQ05DLE1BQU07QUFBQSxRQUNOQyxZQUFZO0FBQUEsUUFDWkMsY0FBYztBQUFBLFFBQ2RDLGFBQWE7QUFBQSxNQUNmLENBQUM7QUFDRFQscUJBQWVJLE9BQU9NLFVBQVUsWUFBWSxVQUFVO0FBQ3REUjtBQUFBQSxRQUNFRSxPQUFPTSxVQUNILFdBQVdOLE9BQU9PLGlCQUFpQiwyQkFBMkJQLE9BQU9RLFNBQVNQLFFBQVEsYUFBYSxNQUNuRyxHQUFHRCxPQUFPUSxTQUFTUCxRQUFRLDBCQUEwQjtBQUFBLE1BQzNEO0FBQUEsSUFDRixTQUFTUSxPQUFPO0FBQ2RiLHFCQUFlLE9BQU87QUFDdEJFLHVCQUFpQlcsaUJBQWlCQyxRQUFRRCxNQUFNRSxVQUFVLDRDQUE0QztBQUFBLElBQ3hHO0FBQUEsRUFDRjtBQUVBLE1BQUksQ0FBQ3ZCLFVBQVU7QUFDYixXQUNFLHVCQUFDLGFBQVEsV0FBVSx3Q0FDakI7QUFBQSw2QkFBQyxjQUFXLFNBQVEsaUJBQWdCLE9BQU0sYUFBWSxhQUFZLDhFQUE2RSxNQUFNLHVCQUFDLGFBQVUsV0FBVSxhQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThCLEtBQW5MO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUw7QUFBQSxNQUN2TCx1QkFBQyxTQUFJLFdBQVUsNkVBQ2I7QUFBQSwrQkFBQyxXQUFRLFdBQVUsK0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUFHO0FBQUEsV0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxFQUVKO0FBRUEsUUFBTXdCLFFBQVE5QiwwQkFBMEJNLFNBQVN5QixPQUFPO0FBQ3hELFFBQU1DLGdCQUFnQi9CLHVCQUF1QkssU0FBU3lCLE9BQU87QUFFN0QsU0FDRSx1QkFBQyxhQUFRLFdBQVUsd0NBQ2pCO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVE7QUFBQSxRQUNSLE9BQU07QUFBQSxRQUNOLGFBQVk7QUFBQSxRQUNaLE1BQU0sdUJBQUMsYUFBVSxXQUFVLGFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEI7QUFBQTtBQUFBLE1BSnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUkwQztBQUFBLElBRzFDLHVCQUFDLFNBQUksV0FBVSx3Q0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSw0Q0FDWkQsZ0JBQU1HO0FBQUFBLFFBQUksQ0FBQ0MsU0FDVix1QkFBQyxRQUNDLGlDQUFDLGNBQVcsV0FBVSxRQUNwQjtBQUFBLGlDQUFDLG1CQUFpQkEsZUFBS0MsU0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkI7QUFBQSxVQUM3Qix1QkFBQyxhQUFVLFdBQVdDLFVBQVVGLEtBQUtHLElBQUksR0FBSUgsZUFBS0ksU0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Q7QUFBQSxhQUYxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0EsS0FKU0osS0FBS0ssS0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsTUFDRCxLQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUEsK0JBQUMsUUFDQztBQUFBLGlDQUFDLGNBQ0M7QUFBQSxtQ0FBQyxhQUFVLGdDQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJCO0FBQUEsWUFDM0IsdUJBQUMsbUJBQWdCLG9LQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxSztBQUFBLGVBRnZLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLGVBQVksV0FBVSxhQUNyQjtBQUFBLG1DQUFDLFVBQU8sU0FBUSxhQUFZLFNBQVN0QixvQ0FBb0MsVUFBVUosZ0JBQWdCLGNBQ2hHQTtBQUFBQSw4QkFBZ0IsZUFBZSx1QkFBQyxXQUFRLFdBQVUsMEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlDLElBQU0sdUJBQUMsWUFBUyxXQUFVLGFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZCO0FBQUEsY0FBRztBQUFBLGlCQURqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQ0UsaUJBQ0MsdUJBQUMsU0FBSSxXQUFXLGtDQUFrQ0YsZ0JBQWdCLFVBQVUsbUNBQW1DLHdDQUF3QyxJQUNwSkUsMkJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLGFBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQTtBQUFBLFFBRUEsdUJBQUMsUUFDQztBQUFBLGlDQUFDLGNBQ0M7QUFBQSxtQ0FBQyxhQUFVLGtDQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZCO0FBQUEsWUFDN0IsdUJBQUMsbUJBQWlCaUI7QUFBQUE7QUFBQUEsY0FBYztBQUFBLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RztBQUFBLGVBRnpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLGVBQVksV0FBVSx3QkFDckI7QUFBQSxtQ0FBQyxVQUFPLFNBQVEsV0FBVSxTQUFTLE1BQU01QixXQUFXLHFCQUFxQixHQUFHO0FBQUEscUNBQUMsaUJBQWMsV0FBVSxhQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrQztBQUFBLGNBQUc7QUFBQSxpQkFBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0k7QUFBQSxZQUNsSSx1QkFBQyxVQUFPLFNBQVEsV0FBVSxTQUFTLE1BQU1BLFdBQVcsbUJBQW1CLEdBQUc7QUFBQSxxQ0FBQyxlQUFZLFdBQVUsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxjQUFHO0FBQUEsaUJBQTdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtJO0FBQUEsZUFGcEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFFQSx1QkFBQyxRQUNDO0FBQUEsaUNBQUMsY0FDQztBQUFBLG1DQUFDLGFBQVUsaUNBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEI7QUFBQSxZQUM1Qix1QkFBQyxtQkFBZ0Isc0ZBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVGO0FBQUEsZUFGekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsZUFBWSxXQUFVLGFBQ3BCRSxtQkFBU2tDLGVBQWVDLFdBQVcsSUFBSSx1QkFBQyxhQUFVLE9BQU0sb0NBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlELElBQU1uQyxTQUFTa0MsZUFBZVA7QUFBQUEsWUFBSSxDQUFDLEVBQUVTLFdBQVdDLFVBQWUsTUFDdEo7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxPQUFPRCxVQUFVRTtBQUFBQSxnQkFDakIsVUFBVUYsVUFBVXJCLGNBQWNxQixVQUFVRyxjQUFjO0FBQUEsZ0JBQzFELE9BQU9GLFdBQVdHLFVBQVVKLFVBQVVLO0FBQUFBLGdCQUN0QyxNQUFLO0FBQUE7QUFBQSxjQUpBTCxVQUFVTTtBQUFBQSxjQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS2dCO0FBQUEsVUFFakIsS0FUSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsYUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsV0E5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStDQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLGFBQVk7QUFBQSxZQUNaLE9BQU07QUFBQSxZQUNOLE9BQU8xQyxTQUFTMkMsa0JBQWtCaEIsSUFBSSxDQUFDLEVBQUVTLFdBQVdDLFVBQWUsT0FBTztBQUFBLGNBQ3hFSixLQUFLRyxVQUFVTTtBQUFBQSxjQUNmSixPQUFPRixVQUFVRTtBQUFBQSxjQUNqQk0sVUFBVVIsVUFBVVMsdUJBQXVCVCxVQUFVVSxpQkFBaUJULFdBQVdVLGlCQUFpQjtBQUFBLGNBQ2xHQyxPQUFPWCxXQUFXRyxVQUFVSixVQUFVSztBQUFBQSxjQUN0Q1YsTUFBTTtBQUFBLFlBQ1IsRUFBRTtBQUFBO0FBQUEsVUFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFVTTtBQUFBLFFBR047QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLGFBQVk7QUFBQSxZQUNaLE9BQU07QUFBQSxZQUNOLE9BQU8vQixTQUFTaUQsY0FBY3RCLElBQUksQ0FBQyxFQUFFZSxLQUFLTixXQUFXYyxjQUFjQyxnQkFBcUIsT0FBTztBQUFBLGNBQzdGbEIsS0FBS1M7QUFBQUEsY0FDTEosT0FBT0YsV0FBV0UsU0FBU1k7QUFBQUEsY0FDM0JOLFVBQVVPO0FBQUFBLGNBQ1ZILE9BQU9FO0FBQUFBLGNBQ1BuQixNQUFNO0FBQUEsWUFDUixFQUFFO0FBQUE7QUFBQSxVQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVVNO0FBQUEsUUFHTjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sYUFBWTtBQUFBLFlBQ1osT0FBTTtBQUFBLFlBQ04sT0FBTy9CLFNBQVNvRCxjQUFjekIsSUFBSSxDQUFDLEVBQUUwQixTQUFTakIsVUFBZSxPQUFPO0FBQUEsY0FDbEVILEtBQUtvQixRQUFRWDtBQUFBQSxjQUNiSixPQUFPRixXQUFXRSxTQUFTZSxRQUFRQztBQUFBQSxjQUNuQ1YsVUFBVSxhQUFhUyxRQUFRQyxxQkFBcUI7QUFBQSxjQUNwRE4sT0FBT0ssUUFBUWI7QUFBQUEsY0FDZlQsTUFBTTtBQUFBLFlBQ1IsRUFBRTtBQUFBO0FBQUEsVUFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFVTTtBQUFBLFFBR047QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLGFBQVk7QUFBQSxZQUNaLE9BQU07QUFBQSxZQUNOLE9BQU8vQixTQUFTdUQscUJBQXFCNUIsSUFBSSxDQUFDLEVBQUVTLFdBQVdDLFVBQWUsT0FBTztBQUFBLGNBQzNFSixLQUFLSSxVQUFVSztBQUFBQSxjQUNmSixPQUFPRixVQUFVRTtBQUFBQSxjQUNqQk0sVUFBVVAsVUFBVVUsaUJBQWlCVixVQUFVbUIsb0JBQW9CbkIsVUFBVUU7QUFBQUEsY0FDN0VTLE9BQU9YLFVBQVVHO0FBQUFBLGNBQ2pCVCxNQUFNO0FBQUEsWUFDUixFQUFFO0FBQUE7QUFBQSxVQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVVNO0FBQUEsV0FsRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9EQTtBQUFBLFNBakhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrSEE7QUFBQSxPQTFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkhBO0FBRUo7QUFBQ2hDLEdBektlSCxxQkFBbUI7QUFBQSxVQUNoQlosVUFDb0JELFdBQVc7QUFBQTtBQUFBLEtBRmxDYTtBQTJLaEIsU0FBUzZELGlCQUFpQixFQUFFbkIsT0FBT29CLGFBQWFDLE9BQU9DLE1BQW9MLEdBQUc7QUFDNU8sU0FDRSx1QkFBQyxRQUNDO0FBQUEsMkJBQUMsY0FDQztBQUFBLDZCQUFDLGFBQVd0QixtQkFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtCO0FBQUEsTUFDbEIsdUJBQUMsbUJBQWlCb0IseUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEI7QUFBQSxTQUZoQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLGVBQVksV0FBVSxhQUNwQkUsZ0JBQU16QixXQUFXLElBQUksdUJBQUMsYUFBVSxPQUFPd0IsU0FBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QixJQUFNQyxNQUFNakMsSUFBSSxDQUFDa0MsU0FBUyx1QkFBQyxlQUEyQixHQUFJQSxRQUFkQSxLQUFLNUIsS0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQyxDQUFHLEtBRGxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRUo7QUFBQzZCLE1BWlFMO0FBY1QsU0FBU00sWUFBWSxFQUFFekIsT0FBT00sVUFBVUksT0FBT2pCLEtBQWlHLEdBQUc7QUFDakosU0FDRSx1QkFBQyxTQUFJLFdBQVUsc0VBQ2IsaUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsMkJBQUMsU0FDQztBQUFBLDZCQUFDLFNBQUksV0FBVSwrQkFBK0JPLG1CQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9EO0FBQUEsTUFDcEQsdUJBQUMsU0FBSSxXQUFVLHNDQUFzQ00sc0JBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEQ7QUFBQSxTQUZoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLFNBQU0sU0FBUSxXQUFVLFdBQVdkLFVBQVVDLElBQUksR0FBSWlCLG1CQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTREO0FBQUEsT0FMOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRUo7QUFBQ2dCLE1BWlFEO0FBY1QsU0FBU0UsVUFBVSxFQUFFcEMsTUFBeUIsR0FBRztBQUMvQyxTQUFPLHVCQUFDLFNBQUksV0FBVSxpR0FBaUdBLG1CQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXNIO0FBQy9IO0FBQUNxQyxNQUZRRDtBQUlULFNBQVNuQyxVQUFVQyxNQUFvRDtBQUNyRSxVQUFRQSxNQUFJO0FBQUEsSUFDVixLQUFLO0FBQ0gsYUFBTztBQUFBLElBQ1QsS0FBSztBQUNILGFBQU87QUFBQSxJQUNULEtBQUs7QUFDSCxhQUFPO0FBQUEsSUFDVDtBQUNFLGFBQU87QUFBQSxFQUNYO0FBQ0Y7QUFBQyxJQUFBb0MsSUFBQUwsS0FBQUUsS0FBQUU7QUFBQSxhQUFBQyxJQUFBO0FBQUEsYUFBQUwsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBRSxLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJDbGlwYm9hcmRMaXN0IiwiTG9hZGVyMiIsIlNoaWVsZEFsZXJ0IiwiU3BhcmtsZXMiLCJXYXlwb2ludHMiLCJ1c2VNdXRhdGlvbiIsInVzZVF1ZXJ5IiwiYXBpIiwiUGFnZUhlYWRlciIsIkJhZGdlIiwiQnV0dG9uIiwiQ2FyZCIsIkNhcmRDb250ZW50IiwiQ2FyZERlc2NyaXB0aW9uIiwiQ2FyZEhlYWRlciIsIkNhcmRUaXRsZSIsImJ1aWxkRmFjdG9yeU92ZXJ2aWV3Q2FyZHMiLCJzdW1tYXJpemVBdHRlbnRpb25Mb2FkIiwiRmFjdG9yeU92ZXJ2aWV3VmlldyIsInByb2plY3RJZCIsIm9uTmF2aWdhdGUiLCJfcyIsIm92ZXJ2aWV3Iiwid29ya09yZGVycyIsImZhY3RvcnlPdmVydmlldyIsInVuZGVmaW5lZCIsImxpbWl0IiwiY3JlYXRlU29mdHdhcmVGYWN0b3J5UHJvamVjdCIsInByb2plY3RzIiwiY3JlYXRlU3RhdGUiLCJzZXRDcmVhdGVTdGF0ZSIsImNyZWF0ZU1lc3NhZ2UiLCJzZXRDcmVhdGVNZXNzYWdlIiwiaGFuZGxlQ3JlYXRlU29mdHdhcmVGYWN0b3J5UHJvamVjdCIsInJlc3VsdCIsIm5hbWUiLCJzbHVnIiwicmVwb3NpdG9yeSIsImdpdGh1YkJyYW5jaCIsInJlcXVlc3RlZEJ5IiwiY3JlYXRlZCIsImNyZWF0ZWRXb3JrT3JkZXJzIiwicHJvamVjdCIsImVycm9yIiwiRXJyb3IiLCJtZXNzYWdlIiwiY2FyZHMiLCJzdW1tYXJ5IiwiYXR0ZW50aW9uTG9hZCIsIm1hcCIsImNhcmQiLCJsYWJlbCIsInRvbmVDbGFzcyIsInRvbmUiLCJ2YWx1ZSIsImtleSIsInJlY2VudEFjY2VwdGVkIiwibGVuZ3RoIiwid29ya09yZGVyIiwibGF0ZXN0UnVuIiwidGl0bGUiLCJ3b3JrZmxvd0lkIiwic3RhdHVzIiwic3RhdGUiLCJfaWQiLCJibG9ja2VkV29ya09yZGVycyIsInN1YnRpdGxlIiwicmVxdWlyZWRIdW1hbkFjdGlvbiIsImJsb2NraW5nSXNzdWUiLCJmYWlsdXJlUmVhc29uIiwiYmFkZ2UiLCJhcHByb3ZhbFF1ZXVlIiwiYXBwcm92YWxUeXBlIiwicmVxdWVzdGVkQWN0aW9uIiwic3RhbGVFdmlkZW5jZSIsInJlY2VpcHQiLCJhY2NlcHRhbmNlQ3JpdGVyaW9uSWQiLCJydW5zTmVlZGluZ0F0dGVudGlvbiIsImN1cnJlbnRTdGVwTGFiZWwiLCJPdmVydmlld0xpc3RDYXJkIiwiZGVzY3JpcHRpb24iLCJlbXB0eSIsIml0ZW1zIiwiaXRlbSIsIl9jMiIsIk92ZXJ2aWV3Um93IiwiX2MzIiwiRW1wdHlMaW5lIiwiX2M0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRmFjdG9yeU92ZXJ2aWV3Vmlldy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IENsaXBib2FyZExpc3QsIExvYWRlcjIsIFNoaWVsZEFsZXJ0LCBTcGFya2xlcywgV2F5cG9pbnRzIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5IH0gZnJvbSBcImNvbnZleC9yZWFjdFwiO1xuaW1wb3J0IHR5cGUgeyBJZCB9IGZyb20gXCIuLi8uLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9kYXRhTW9kZWxcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB7IFBhZ2VIZWFkZXIgfSBmcm9tIFwiQC9jb21wb25lbnRzL1BhZ2VIZWFkZXJcIjtcbmltcG9ydCB7IEJhZGdlIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9iYWRnZVwiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9idXR0b25cIjtcbmltcG9ydCB7IENhcmQsIENhcmRDb250ZW50LCBDYXJkRGVzY3JpcHRpb24sIENhcmRIZWFkZXIsIENhcmRUaXRsZSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvY2FyZFwiO1xuaW1wb3J0IHsgYnVpbGRGYWN0b3J5T3ZlcnZpZXdDYXJkcywgc3VtbWFyaXplQXR0ZW50aW9uTG9hZCB9IGZyb20gXCIuL2ZhY3RvcnlPdmVydmlld01vZGVsXCI7XG5pbXBvcnQgdHlwZSB7IE1haW5WaWV3IH0gZnJvbSBcIi4uL1RvcE5hdlwiO1xuXG5leHBvcnQgZnVuY3Rpb24gRmFjdG9yeU92ZXJ2aWV3Vmlldyh7IHByb2plY3RJZCwgb25OYXZpZ2F0ZSB9OiB7IHByb2plY3RJZDogSWQ8XCJwcm9qZWN0c1wiPiB8IG51bGw7IG9uTmF2aWdhdGU6ICh2aWV3OiBNYWluVmlldykgPT4gdm9pZCB9KSB7XG4gIGNvbnN0IG92ZXJ2aWV3ID0gdXNlUXVlcnkoYXBpLndvcmtPcmRlcnMuZmFjdG9yeU92ZXJ2aWV3LCB7IHByb2plY3RJZDogcHJvamVjdElkID8/IHVuZGVmaW5lZCwgbGltaXQ6IDUgfSk7XG4gIGNvbnN0IGNyZWF0ZVNvZnR3YXJlRmFjdG9yeVByb2plY3QgPSB1c2VNdXRhdGlvbihhcGkucHJvamVjdHMuY3JlYXRlU29mdHdhcmVGYWN0b3J5UHJvamVjdCk7XG4gIGNvbnN0IFtjcmVhdGVTdGF0ZSwgc2V0Q3JlYXRlU3RhdGVdID0gdXNlU3RhdGU8XCJpZGxlXCIgfCBcInN1Ym1pdHRpbmdcIiB8IFwiY3JlYXRlZFwiIHwgXCJyZXBsYXllZFwiIHwgXCJlcnJvclwiPihcImlkbGVcIik7XG4gIGNvbnN0IFtjcmVhdGVNZXNzYWdlLCBzZXRDcmVhdGVNZXNzYWdlXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZVNvZnR3YXJlRmFjdG9yeVByb2plY3QgPSBhc3luYyAoKSA9PiB7XG4gICAgc2V0Q3JlYXRlU3RhdGUoXCJzdWJtaXR0aW5nXCIpO1xuICAgIHNldENyZWF0ZU1lc3NhZ2UobnVsbCk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNyZWF0ZVNvZnR3YXJlRmFjdG9yeVByb2plY3Qoe1xuICAgICAgICBuYW1lOiBcIkFwcGxlIE5vdGVzIFNvZnR3YXJlIEZhY3RvcnlcIixcbiAgICAgICAgc2x1ZzogXCJhcHBsZS1ub3Rlcy1zb2Z0d2FyZS1mYWN0b3J5XCIsXG4gICAgICAgIHJlcG9zaXRvcnk6IFwiamF5ZHVieWE4MTgvTWlzc2lvbkNvbnRyb2xcIixcbiAgICAgICAgZ2l0aHViQnJhbmNoOiBcIm1haW5cIixcbiAgICAgICAgcmVxdWVzdGVkQnk6IFwiSGVybWVzXCIsXG4gICAgICB9KTtcbiAgICAgIHNldENyZWF0ZVN0YXRlKHJlc3VsdC5jcmVhdGVkID8gXCJjcmVhdGVkXCIgOiBcInJlcGxheWVkXCIpO1xuICAgICAgc2V0Q3JlYXRlTWVzc2FnZShcbiAgICAgICAgcmVzdWx0LmNyZWF0ZWRcbiAgICAgICAgICA/IGBDcmVhdGVkICR7cmVzdWx0LmNyZWF0ZWRXb3JrT3JkZXJzfSBmYWN0b3J5IFdvcmtPcmRlcnMgZm9yICR7cmVzdWx0LnByb2plY3Q/Lm5hbWUgPz8gXCJ0aGUgcHJvamVjdFwifS5gXG4gICAgICAgICAgOiBgJHtyZXN1bHQucHJvamVjdD8ubmFtZSA/PyBcIlNvZnR3YXJlIGZhY3RvcnkgcHJvamVjdFwifSBhbHJlYWR5IGV4aXN0czsgcmVmcmVzaGVkIHRoZSByZWFkIG1vZGVsLmBcbiAgICAgICk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHNldENyZWF0ZVN0YXRlKFwiZXJyb3JcIik7XG4gICAgICBzZXRDcmVhdGVNZXNzYWdlKGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJGYWlsZWQgdG8gY3JlYXRlIHNvZnR3YXJlIGZhY3RvcnkgcHJvamVjdC5cIik7XG4gICAgfVxuICB9O1xuXG4gIGlmICghb3ZlcnZpZXcpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiZmxleCBmbGV4LTEgZmxleC1jb2wgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgIDxQYWdlSGVhZGVyIGV5ZWJyb3c9XCJDb250cm9sIHBsYW5lXCIgdGl0bGU9XCJQb3J0Zm9saW9cIiBkZXNjcmlwdGlvbj1cIkxpdmUgZmFjdG9yeSBvdmVydmlldyBiYWNrZWQgYnkgV29ya09yZGVycywgYXBwcm92YWxzLCBhbmQgZXhlY3V0aW9uIHJ1bnMuXCIgaWNvbj17PFdheXBvaW50cyBjbGFzc05hbWU9XCJoLTUgdy01XCIgLz59IC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LTEgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNiB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cIm1yLTIgaC00IHctNCBhbmltYXRlLXNwaW5cIiAvPiBMb2FkaW5nIGZhY3Rvcnkgb3ZlcnZpZXfigKZcbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG4gICAgKTtcbiAgfVxuXG4gIGNvbnN0IGNhcmRzID0gYnVpbGRGYWN0b3J5T3ZlcnZpZXdDYXJkcyhvdmVydmlldy5zdW1tYXJ5KTtcbiAgY29uc3QgYXR0ZW50aW9uTG9hZCA9IHN1bW1hcml6ZUF0dGVudGlvbkxvYWQob3ZlcnZpZXcuc3VtbWFyeSk7XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtMSBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgIDxQYWdlSGVhZGVyXG4gICAgICAgIGV5ZWJyb3c9XCJDb250cm9sIHBsYW5lXCJcbiAgICAgICAgdGl0bGU9XCJQb3J0Zm9saW9cIlxuICAgICAgICBkZXNjcmlwdGlvbj1cIkV4Y2VwdGlvbi1maXJzdCBvdmVydmlldyBvZiBzb2Z0d2FyZS1mYWN0b3J5IHRocm91Z2hwdXQsIGFwcHJvdmFscywgc3RhbGUgZXZpZGVuY2UsIGFuZCBydW5zIG5lZWRpbmcgYXR0ZW50aW9uLlwiXG4gICAgICAgIGljb249ezxXYXlwb2ludHMgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+fVxuICAgICAgLz5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHAtNSBzcGFjZS15LTRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0zIG1kOmdyaWQtY29scy0yIHhsOmdyaWQtY29scy02XCI+XG4gICAgICAgICAge2NhcmRzLm1hcCgoY2FyZCkgPT4gKFxuICAgICAgICAgICAgPENhcmQga2V5PXtjYXJkLmtleX0+XG4gICAgICAgICAgICAgIDxDYXJkSGVhZGVyIGNsYXNzTmFtZT1cInBiLTJcIj5cbiAgICAgICAgICAgICAgICA8Q2FyZERlc2NyaXB0aW9uPntjYXJkLmxhYmVsfTwvQ2FyZERlc2NyaXB0aW9uPlxuICAgICAgICAgICAgICAgIDxDYXJkVGl0bGUgY2xhc3NOYW1lPXt0b25lQ2xhc3MoY2FyZC50b25lKX0+e2NhcmQudmFsdWV9PC9DYXJkVGl0bGU+XG4gICAgICAgICAgICAgIDwvQ2FyZEhlYWRlcj5cbiAgICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC00IHhsOmdyaWQtY29scy1bbWlubWF4KDAsMS4xZnIpX21pbm1heCgwLDAuOWZyKV1cIj5cbiAgICAgICAgICA8Q2FyZD5cbiAgICAgICAgICAgIDxDYXJkSGVhZGVyPlxuICAgICAgICAgICAgICA8Q2FyZFRpdGxlPlByb2plY3QgY3JlYXRpb248L0NhcmRUaXRsZT5cbiAgICAgICAgICAgICAgPENhcmREZXNjcmlwdGlvbj5DcmVhdGUgdGhlIEFwcGxlIE5vdGVzIHNvZnR3YXJlLWZhY3RvcnkgcHJvamVjdCBhbmQgaHlkcmF0ZSB0aGUgcHJvamVjdC1zY29wZWQgcmVhZCBtb2RlbCB3aXRoIFdvcmtPcmRlcnMsIHJ1bnMsIGFwcHJvdmFscywgYXJ0aWZhY3RzLCBhbmQgcmVjZWlwdHMuPC9DYXJkRGVzY3JpcHRpb24+XG4gICAgICAgICAgICA8L0NhcmRIZWFkZXI+XG4gICAgICAgICAgICA8Q2FyZENvbnRlbnQgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm5lb24tY3lhblwiIG9uQ2xpY2s9e2hhbmRsZUNyZWF0ZVNvZnR3YXJlRmFjdG9yeVByb2plY3R9IGRpc2FibGVkPXtjcmVhdGVTdGF0ZSA9PT0gXCJzdWJtaXR0aW5nXCJ9PlxuICAgICAgICAgICAgICAgIHtjcmVhdGVTdGF0ZSA9PT0gXCJzdWJtaXR0aW5nXCIgPyA8TG9hZGVyMiBjbGFzc05hbWU9XCJoLTQgdy00IGFuaW1hdGUtc3BpblwiIC8+IDogPFNwYXJrbGVzIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPn1cbiAgICAgICAgICAgICAgICBDcmVhdGUgZmFjdG9yeSBwcm9qZWN0XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICB7Y3JlYXRlTWVzc2FnZSAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Byb3VuZGVkLTJ4bCBib3JkZXIgcC0zIHRleHQtc20gJHtjcmVhdGVTdGF0ZSA9PT0gXCJlcnJvclwiID8gXCJib3JkZXItcmVkLTUwMC8zMCB0ZXh0LXJlZC0yMDBcIiA6IFwiYm9yZGVyLWVtZXJhbGQtNTAwLzMwIHRleHQtZW1lcmFsZC0yMDBcIn1gfT5cbiAgICAgICAgICAgICAgICAgIHtjcmVhdGVNZXNzYWdlfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9DYXJkQ29udGVudD5cbiAgICAgICAgICA8L0NhcmQ+XG5cbiAgICAgICAgICA8Q2FyZD5cbiAgICAgICAgICAgIDxDYXJkSGVhZGVyPlxuICAgICAgICAgICAgICA8Q2FyZFRpdGxlPk9wZXJhdG9yIGF0dGVudGlvbjwvQ2FyZFRpdGxlPlxuICAgICAgICAgICAgICA8Q2FyZERlc2NyaXB0aW9uPnthdHRlbnRpb25Mb2FkfSBsaXZlIGV4Y2VwdGlvbnMgY3VycmVudGx5IG5lZWQgYSBkZWNpc2lvbiwgcmVydW4sIG9yIGV2aWRlbmNlIHJlZnJlc2guPC9DYXJkRGVzY3JpcHRpb24+XG4gICAgICAgICAgICA8L0NhcmRIZWFkZXI+XG4gICAgICAgICAgICA8Q2FyZENvbnRlbnQgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoXCJjb250cm9sLXdvcmstb3JkZXJzXCIpfT48Q2xpcGJvYXJkTGlzdCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz4gT3BlbiBXb3JrIE9yZGVyczwvQnV0dG9uPlxuICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZShcImNvbnRyb2wtYXBwcm92YWxzXCIpfT48U2hpZWxkQWxlcnQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IE9wZW4gQXBwcm92YWwgQ2VudGVyPC9CdXR0b24+XG4gICAgICAgICAgICA8L0NhcmRDb250ZW50PlxuICAgICAgICAgIDwvQ2FyZD5cblxuICAgICAgICAgIDxDYXJkPlxuICAgICAgICAgICAgPENhcmRIZWFkZXI+XG4gICAgICAgICAgICAgIDxDYXJkVGl0bGU+UmVjZW50IGFjY2VwdGFuY2U8L0NhcmRUaXRsZT5cbiAgICAgICAgICAgICAgPENhcmREZXNjcmlwdGlvbj5SZWNlbnRseSBhY2NlcHRlZCBvdXRjb21lcyByZW1haW4gdmlzaWJsZSBoZXJlIGFzIHByb29mIG9mIHRocm91Z2hwdXQuPC9DYXJkRGVzY3JpcHRpb24+XG4gICAgICAgICAgICA8L0NhcmRIZWFkZXI+XG4gICAgICAgICAgICA8Q2FyZENvbnRlbnQgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIHtvdmVydmlldy5yZWNlbnRBY2NlcHRlZC5sZW5ndGggPT09IDAgPyA8RW1wdHlMaW5lIGxhYmVsPVwiTm8gcmVjZW50bHkgYWNjZXB0ZWQgd29yayB5ZXQuXCIgLz4gOiBvdmVydmlldy5yZWNlbnRBY2NlcHRlZC5tYXAoKHsgd29ya09yZGVyLCBsYXRlc3RSdW4gfTogYW55KSA9PiAoXG4gICAgICAgICAgICAgICAgPE92ZXJ2aWV3Um93XG4gICAgICAgICAgICAgICAgICBrZXk9e3dvcmtPcmRlci5faWR9XG4gICAgICAgICAgICAgICAgICB0aXRsZT17d29ya09yZGVyLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgc3VidGl0bGU9e3dvcmtPcmRlci5yZXBvc2l0b3J5ID8/IHdvcmtPcmRlci53b3JrZmxvd0lkID8/IFwi4oCUXCJ9XG4gICAgICAgICAgICAgICAgICBiYWRnZT17bGF0ZXN0UnVuPy5zdGF0dXMgPz8gd29ya09yZGVyLnN0YXRlfVxuICAgICAgICAgICAgICAgICAgdG9uZT1cInN1Y2Nlc3NcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9DYXJkQ29udGVudD5cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNCB4bDpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgIDxPdmVydmlld0xpc3RDYXJkXG4gICAgICAgICAgICB0aXRsZT1cIkJsb2NrZWQgV29ya09yZGVyc1wiXG4gICAgICAgICAgICBkZXNjcmlwdGlvbj1cIlJlcXVlc3RzIHRoYXQgY2Fubm90IHByb2dyZXNzIHVudGlsIGEgaHVtYW4gb3Igc3lzdGVtIGludGVydmVudGlvbiBoYXBwZW5zLlwiXG4gICAgICAgICAgICBlbXB0eT1cIk5vIGJsb2NrZWQgV29ya09yZGVycy5cIlxuICAgICAgICAgICAgaXRlbXM9e292ZXJ2aWV3LmJsb2NrZWRXb3JrT3JkZXJzLm1hcCgoeyB3b3JrT3JkZXIsIGxhdGVzdFJ1biB9OiBhbnkpID0+ICh7XG4gICAgICAgICAgICAgIGtleTogd29ya09yZGVyLl9pZCxcbiAgICAgICAgICAgICAgdGl0bGU6IHdvcmtPcmRlci50aXRsZSxcbiAgICAgICAgICAgICAgc3VidGl0bGU6IHdvcmtPcmRlci5yZXF1aXJlZEh1bWFuQWN0aW9uID8/IHdvcmtPcmRlci5ibG9ja2luZ0lzc3VlID8/IGxhdGVzdFJ1bj8uZmFpbHVyZVJlYXNvbiA/PyBcIkF3YWl0aW5nIGF0dGVudGlvblwiLFxuICAgICAgICAgICAgICBiYWRnZTogbGF0ZXN0UnVuPy5zdGF0dXMgPz8gd29ya09yZGVyLnN0YXRlLFxuICAgICAgICAgICAgICB0b25lOiBcImRhbmdlclwiIGFzIGNvbnN0LFxuICAgICAgICAgICAgfSkpfVxuICAgICAgICAgIC8+XG5cbiAgICAgICAgICA8T3ZlcnZpZXdMaXN0Q2FyZFxuICAgICAgICAgICAgdGl0bGU9XCJBcHByb3ZhbCBxdWV1ZVwiXG4gICAgICAgICAgICBkZXNjcmlwdGlvbj1cIkh1bWFuIGRlY2lzaW9ucyBjdXJyZW50bHkgYmxvY2tpbmcgZGlzcGF0Y2gsIGFjY2VwdGFuY2UsIG9yIHJldmlzaW9uIGZsb3cuXCJcbiAgICAgICAgICAgIGVtcHR5PVwiTm8gcGVuZGluZyBhcHByb3ZhbHMuXCJcbiAgICAgICAgICAgIGl0ZW1zPXtvdmVydmlldy5hcHByb3ZhbFF1ZXVlLm1hcCgoeyBfaWQsIHdvcmtPcmRlciwgYXBwcm92YWxUeXBlLCByZXF1ZXN0ZWRBY3Rpb24gfTogYW55KSA9PiAoe1xuICAgICAgICAgICAgICBrZXk6IF9pZCxcbiAgICAgICAgICAgICAgdGl0bGU6IHdvcmtPcmRlcj8udGl0bGUgPz8gYXBwcm92YWxUeXBlLFxuICAgICAgICAgICAgICBzdWJ0aXRsZTogcmVxdWVzdGVkQWN0aW9uLFxuICAgICAgICAgICAgICBiYWRnZTogYXBwcm92YWxUeXBlLFxuICAgICAgICAgICAgICB0b25lOiBcIndhcm5pbmdcIiBhcyBjb25zdCxcbiAgICAgICAgICAgIH0pKX1cbiAgICAgICAgICAvPlxuXG4gICAgICAgICAgPE92ZXJ2aWV3TGlzdENhcmRcbiAgICAgICAgICAgIHRpdGxlPVwiU3RhbGUgZXZpZGVuY2VcIlxuICAgICAgICAgICAgZGVzY3JpcHRpb249XCJWZXJpZmljYXRpb24gcmVjZWlwdHMgdGhhdCBtdXN0IGJlIHJlZnJlc2hlZCBiZWZvcmUgYWNjZXB0YW5jZSBjYW4gcHJvY2VlZC5cIlxuICAgICAgICAgICAgZW1wdHk9XCJObyBzdGFsZSBldmlkZW5jZS5cIlxuICAgICAgICAgICAgaXRlbXM9e292ZXJ2aWV3LnN0YWxlRXZpZGVuY2UubWFwKCh7IHJlY2VpcHQsIHdvcmtPcmRlciB9OiBhbnkpID0+ICh7XG4gICAgICAgICAgICAgIGtleTogcmVjZWlwdC5faWQsXG4gICAgICAgICAgICAgIHRpdGxlOiB3b3JrT3JkZXI/LnRpdGxlID8/IHJlY2VpcHQuYWNjZXB0YW5jZUNyaXRlcmlvbklkLFxuICAgICAgICAgICAgICBzdWJ0aXRsZTogYENyaXRlcmlvbiAke3JlY2VpcHQuYWNjZXB0YW5jZUNyaXRlcmlvbklkfWAsXG4gICAgICAgICAgICAgIGJhZGdlOiByZWNlaXB0LnN0YXR1cyxcbiAgICAgICAgICAgICAgdG9uZTogXCJ3YXJuaW5nXCIgYXMgY29uc3QsXG4gICAgICAgICAgICB9KSl9XG4gICAgICAgICAgLz5cblxuICAgICAgICAgIDxPdmVydmlld0xpc3RDYXJkXG4gICAgICAgICAgICB0aXRsZT1cIlJ1bnMgbmVlZGluZyBhdHRlbnRpb25cIlxuICAgICAgICAgICAgZGVzY3JpcHRpb249XCJMYXRlc3QgZXhlY3V0aW9uIHJ1bnMgd2l0aCBmYWlsdXJlcywgcGF1c2VzLCByZXRyaWVzLCBvciBodW1hbiBpbnRlcnZlbnRpb25zLlwiXG4gICAgICAgICAgICBlbXB0eT1cIk5vIGF0dGVudGlvbi1zZWVraW5nIHJ1bnMuXCJcbiAgICAgICAgICAgIGl0ZW1zPXtvdmVydmlldy5ydW5zTmVlZGluZ0F0dGVudGlvbi5tYXAoKHsgd29ya09yZGVyLCBsYXRlc3RSdW4gfTogYW55KSA9PiAoe1xuICAgICAgICAgICAgICBrZXk6IGxhdGVzdFJ1bi5faWQsXG4gICAgICAgICAgICAgIHRpdGxlOiB3b3JrT3JkZXIudGl0bGUsXG4gICAgICAgICAgICAgIHN1YnRpdGxlOiBsYXRlc3RSdW4uZmFpbHVyZVJlYXNvbiA/PyBsYXRlc3RSdW4uY3VycmVudFN0ZXBMYWJlbCA/PyBsYXRlc3RSdW4ud29ya2Zsb3dJZCxcbiAgICAgICAgICAgICAgYmFkZ2U6IGxhdGVzdFJ1bi5zdGF0dXMsXG4gICAgICAgICAgICAgIHRvbmU6IFwiZGFuZ2VyXCIgYXMgY29uc3QsXG4gICAgICAgICAgICB9KSl9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG5cbmZ1bmN0aW9uIE92ZXJ2aWV3TGlzdENhcmQoeyB0aXRsZSwgZGVzY3JpcHRpb24sIGVtcHR5LCBpdGVtcyB9OiB7IHRpdGxlOiBzdHJpbmc7IGRlc2NyaXB0aW9uOiBzdHJpbmc7IGVtcHR5OiBzdHJpbmc7IGl0ZW1zOiBBcnJheTx7IGtleTogc3RyaW5nOyB0aXRsZTogc3RyaW5nOyBzdWJ0aXRsZTogc3RyaW5nOyBiYWRnZTogc3RyaW5nOyB0b25lOiBcImRhbmdlclwiIHwgXCJ3YXJuaW5nXCIgfCBcInN1Y2Nlc3NcIiB9PiB9KSB7XG4gIHJldHVybiAoXG4gICAgPENhcmQ+XG4gICAgICA8Q2FyZEhlYWRlcj5cbiAgICAgICAgPENhcmRUaXRsZT57dGl0bGV9PC9DYXJkVGl0bGU+XG4gICAgICAgIDxDYXJkRGVzY3JpcHRpb24+e2Rlc2NyaXB0aW9ufTwvQ2FyZERlc2NyaXB0aW9uPlxuICAgICAgPC9DYXJkSGVhZGVyPlxuICAgICAgPENhcmRDb250ZW50IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICB7aXRlbXMubGVuZ3RoID09PSAwID8gPEVtcHR5TGluZSBsYWJlbD17ZW1wdHl9IC8+IDogaXRlbXMubWFwKChpdGVtKSA9PiA8T3ZlcnZpZXdSb3cga2V5PXtpdGVtLmtleX0gey4uLml0ZW19IC8+KX1cbiAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgPC9DYXJkPlxuICApO1xufVxuXG5mdW5jdGlvbiBPdmVydmlld1Jvdyh7IHRpdGxlLCBzdWJ0aXRsZSwgYmFkZ2UsIHRvbmUgfTogeyB0aXRsZTogc3RyaW5nOyBzdWJ0aXRsZTogc3RyaW5nOyBiYWRnZTogc3RyaW5nOyB0b25lOiBcImRhbmdlclwiIHwgXCJ3YXJuaW5nXCIgfCBcInN1Y2Nlc3NcIiB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLVt2YXIoLS1wYW5lbC1saW5lKV0gYmctYmFja2dyb3VuZC80MCBwLTRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZm9yZWdyb3VuZFwiPnt0aXRsZX08L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57c3VidGl0bGV9PC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8QmFkZ2UgdmFyaWFudD1cIm91dGxpbmVcIiBjbGFzc05hbWU9e3RvbmVDbGFzcyh0b25lKX0+e2JhZGdlfTwvQmFkZ2U+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gRW1wdHlMaW5lKHsgbGFiZWwgfTogeyBsYWJlbDogc3RyaW5nIH0pIHtcbiAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1kYXNoZWQgYm9yZGVyLVt2YXIoLS1wYW5lbC1saW5lKV0gcC00IHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e2xhYmVsfTwvZGl2Pjtcbn1cblxuZnVuY3Rpb24gdG9uZUNsYXNzKHRvbmU6IFwibmV1dHJhbFwiIHwgXCJ3YXJuaW5nXCIgfCBcImRhbmdlclwiIHwgXCJzdWNjZXNzXCIpIHtcbiAgc3dpdGNoICh0b25lKSB7XG4gICAgY2FzZSBcIndhcm5pbmdcIjpcbiAgICAgIHJldHVybiBcInRleHQtYW1iZXItMjAwIGJvcmRlci1hbWJlci01MDAvMzBcIjtcbiAgICBjYXNlIFwiZGFuZ2VyXCI6XG4gICAgICByZXR1cm4gXCJ0ZXh0LXJlZC0yMDAgYm9yZGVyLXJlZC01MDAvMzBcIjtcbiAgICBjYXNlIFwic3VjY2Vzc1wiOlxuICAgICAgcmV0dXJuIFwidGV4dC1lbWVyYWxkLTIwMCBib3JkZXItZW1lcmFsZC01MDAvMzBcIjtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIFwidGV4dC1yZWdpc3RyeS1hY2NlbnQgYm9yZGVyLXJlZ2lzdHJ5LWFjY2VudC8zMFwiO1xuICB9XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9jb250cm9sUGxhbmUvRmFjdG9yeU92ZXJ2aWV3Vmlldy50c3gifQ==