import {
  Slot,
  Slottable,
  createSlot,
  createSlottable
} from "/node_modules/.vite/deps/chunk-GD4GA362.js?v=738cb978";
import "/node_modules/.vite/deps/chunk-ES6K7VX6.js?v=738cb978";
import "/node_modules/.vite/deps/chunk-JRFAWF3F.js?v=738cb978";
import "/node_modules/.vite/deps/chunk-GMP6FTHE.js?v=738cb978";
import "/node_modules/.vite/deps/chunk-G3PMV62Z.js?v=738cb978";
export {
  Slot as Root,
  Slot,
  Slottable,
  createSlot,
  createSlottable
};
//# sourceMappingURL=@radix-ui_react-slot.js.map
