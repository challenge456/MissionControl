import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/CalendarView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { cn } from "/src/lib/utils.ts";
import { PageHeader } from "/src/components/PageHeader.tsx";
import { Card } from "/src/components/ui/card.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { EmptyState } from "/src/components/ui/empty-state.tsx";
import { MetricBlock } from "/src/components/factory/MetricBlock.tsx";
import { Calendar, RefreshCw } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
export function CalendarView({ projectId }) {
  _s();
  const [viewMode, setViewMode] = useState("week");
  const tasks = useQuery(api.tasks.list, { projectId: projectId ?? void 0 });
  const scheduledTasks = tasks?.filter(
    (t) => t.scheduledFor || t.recurrence
  ) ?? [];
  const recurringTasks = scheduledTasks.filter((t) => t.recurrence);
  const today = /* @__PURE__ */ new Date();
  const startOfWeek = getStartOfWeek(today);
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const date = new Date(startOfWeek);
    date.setDate(date.getDate() + i);
    return date;
  });
  const tasksByDay = groupTasksByDay(scheduledTasks, weekDays);
  return /* @__PURE__ */ jsxDEV("section", { className: "flex min-h-0 flex-1 flex-col overflow-y-auto bg-app", children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: "Calendar",
        description: scheduledTasks.length > 0 ? `${scheduledTasks.length} scheduled · ${recurringTasks.length} recurring — confirm your agents are being proactive` : "Cron jobs and scheduled tasks for your agents. Schedule routines to confirm your open claw is being proactive.",
        eyebrow: "Operations",
        actions: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1 rounded-lg border border-line p-0.5", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setViewMode("week"),
                className: cn(
                  "rounded-md px-3 py-1 text-xs font-medium transition-colors duration-150",
                  viewMode === "week" ? "bg-surface-2 text-ink" : "text-ink-secondary hover:text-ink"
                ),
                children: "Week"
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
                lineNumber: 75,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setViewMode("today"),
                className: cn(
                  "rounded-md px-3 py-1 text-xs font-medium transition-colors duration-150",
                  viewMode === "today" ? "bg-surface-2 text-ink" : "text-ink-secondary hover:text-ink"
                ),
                children: "Today"
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
                lineNumber: 84,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
            lineNumber: 74,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "ghost", className: "h-8 w-8 p-0", "aria-label": "Refresh", children: /* @__PURE__ */ jsxDEV(RefreshCw, { className: "h-3.5 w-3.5", strokeWidth: 1.7 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
            lineNumber: 95,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
            lineNumber: 94,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
          lineNumber: 73,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
        lineNumber: 64,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-6 flex flex-col gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 md:grid-cols-4", children: [
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Scheduled",
            value: scheduledTasks.length,
            detail: "Tasks visible on the calendar"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
            lineNumber: 104,
            columnNumber: 11
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
          lineNumber: 103,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Recurring",
            value: recurringTasks.length,
            detail: "Routines still repeating without manual re-entry"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
            lineNumber: 111,
            columnNumber: 11
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
          lineNumber: 110,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Today",
            value: tasksByDay[today.getDay()]?.length ?? 0,
            detail: "Tasks currently landing on today's schedule"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
            lineNumber: 118,
            columnNumber: 11
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
          lineNumber: 117,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "View",
            value: /* @__PURE__ */ jsxDEV("span", { className: "capitalize", children: viewMode }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
              lineNumber: 127,
              columnNumber: 22
            }, this),
            detail: "Switch between a weekly scan and a focused today view"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
            lineNumber: 125,
            columnNumber: 11
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
          lineNumber: 124,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
        lineNumber: 102,
        columnNumber: 7
      }, this),
      scheduledTasks.length === 0 && /* @__PURE__ */ jsxDEV(
        EmptyState,
        {
          icon: Calendar,
          title: "No scheduled tasks",
          description: "Add a due date or recurrence to tasks from the task drawer to see them here. Great for standups, reviews, and recurring agent routines."
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
          lineNumber: 134,
          columnNumber: 9
        },
        this
      ),
      scheduledTasks.length > 0 && recurringTasks.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[19px] font-semibold text-ink mt-0 mb-3", children: "Always running" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
          lineNumber: 143,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 flex-wrap", children: recurringTasks.map(
          (task) => /* @__PURE__ */ jsxDEV("div", { className: "py-3 px-4 bg-surface-1 border border-line rounded-xl transition-colors duration-150 hover:border-line-strong", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-[13.5px] font-medium text-ink mb-1", children: task.title }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
              lineNumber: 147,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] text-ink-muted", children: [
              "Every ",
              formatRecurrence(task.recurrence)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
              lineNumber: 148,
              columnNumber: 17
            }, this)
          ] }, task._id, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
            lineNumber: 146,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
          lineNumber: 144,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
        lineNumber: 142,
        columnNumber: 9
      }, this),
      scheduledTasks.length > 0 && viewMode === "week" && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-7 gap-3", children: weekDays.map((day, i) => {
        const dayTasks = tasksByDay[i] || [];
        const isToday = isSameDay(day, today);
        return /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: cn(
              "bg-surface-1 border rounded-xl overflow-hidden",
              isToday ? "border-line-strong" : "border-line"
            ),
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-3 border-b border-line text-center", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-[13.5px] font-semibold text-ink mb-0.5", children: day.toLocaleDateString("en-US", { weekday: "short" }) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
                  lineNumber: 171,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] text-ink-muted", children: day.toLocaleDateString("en-US", { month: "short", day: "numeric" }) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
                  lineNumber: 174,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
                lineNumber: 170,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "p-2 flex flex-col gap-2", children: dayTasks.map(
                (task) => /* @__PURE__ */ jsxDEV(TaskCard, { task }, task._id, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
                  lineNumber: 180,
                  columnNumber: 19
                }, this)
              ) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
                lineNumber: 178,
                columnNumber: 17
              }, this)
            ]
          },
          day.toISOString(),
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
            lineNumber: 163,
            columnNumber: 15
          },
          this
        );
      }) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
        lineNumber: 158,
        columnNumber: 9
      }, this),
      scheduledTasks.length > 0 && viewMode === "today" && /* @__PURE__ */ jsxDEV("div", { className: "max-w-[800px] mx-auto w-full", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[19px] font-semibold text-ink mt-0 mb-6", children: today.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" }) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
          lineNumber: 191,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3", children: (tasksByDay[today.getDay()] || []).map(
          (task) => /* @__PURE__ */ jsxDEV(TaskCard, { task, large: true }, task._id, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
            lineNumber: 196,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
          lineNumber: 194,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
        lineNumber: 190,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
      lineNumber: 101,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
    lineNumber: 63,
    columnNumber: 5
  }, this);
}
_s(CalendarView, "nuBTWdLg/V5XV2N/1YUwDsjwbHU=", false, function() {
  return [useQuery];
});
_c = CalendarView;
function TaskCard({ task, large }) {
  const time = task.scheduledFor ? new Date(task.scheduledFor).toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit"
  }) : "All day";
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: cn(
        "py-2 px-3 bg-surface-2 border border-line rounded-lg cursor-pointer transition-colors duration-150 hover:border-line-strong",
        large && "py-3 px-4"
      ),
      children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] text-ink-muted mb-1", children: [
          time,
          " · ",
          task.type
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
          lineNumber: 226,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-[13.5px] font-medium text-ink leading-snug", children: task.title }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
          lineNumber: 227,
          columnNumber: 7
        }, this),
        task.description && large && /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] text-ink-muted mt-1.5 leading-snug", children: task.description }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
          lineNumber: 229,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx",
      lineNumber: 220,
      columnNumber: 5
    },
    this
  );
}
_c2 = TaskCard;
function getStartOfWeek(date) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day;
  return new Date(d.setDate(diff));
}
function isSameDay(d1, d2) {
  return d1.getFullYear() === d2.getFullYear() && d1.getMonth() === d2.getMonth() && d1.getDate() === d2.getDate();
}
function groupTasksByDay(tasks, weekDays) {
  const grouped = Array.from({ length: 7 }, () => []);
  for (const task of tasks) {
    if (task.scheduledFor) {
      const taskDate = new Date(task.scheduledFor);
      const dayIndex = weekDays.findIndex((d) => isSameDay(d, taskDate));
      if (dayIndex !== -1) {
        grouped[dayIndex].push(task);
      }
    } else if (task.recurrence) {
      for (let i = 0; i < 7; i++) {
        grouped[i].push(task);
      }
    }
  }
  for (const dayTasks of grouped) {
    dayTasks.sort((a, b) => {
      const timeA = a.scheduledFor ?? 0;
      const timeB = b.scheduledFor ?? 0;
      return timeA - timeB;
    });
  }
  return grouped;
}
function formatRecurrence(recurrence) {
  if (!recurrence) return "";
  const { frequency, interval } = recurrence;
  if (!frequency) return "";
  if (interval === 1) {
    return frequency.toLowerCase();
  }
  return `${interval} ${frequency.toLowerCase()}`;
}
var _c, _c2;
$RefreshReg$(_c, "CalendarView");
$RefreshReg$(_c2, "TaskCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CalendarView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdURjOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZEZCxTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFdBQVc7QUFFcEIsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsVUFBVUMsaUJBQWlCO0FBUTdCLGdCQUFTQyxhQUFhLEVBQUVDLFVBQTZCLEdBQUc7QUFBQUMsS0FBQTtBQUM3RCxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSWYsU0FBbUIsTUFBTTtBQUN6RCxRQUFNZ0IsUUFBUWYsU0FBU0MsSUFBSWMsTUFBTUMsTUFBTSxFQUFFTCxXQUFXQSxhQUFhTSxPQUFVLENBQUM7QUFHNUUsUUFBTUMsaUJBQWlCSCxPQUFPSTtBQUFBQSxJQUM1QixDQUFDQyxNQUFNQSxFQUFFQyxnQkFBZ0JELEVBQUVFO0FBQUFBLEVBQzdCLEtBQUs7QUFHTCxRQUFNQyxpQkFBaUJMLGVBQWVDLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRUUsVUFBVTtBQUdoRSxRQUFNRSxRQUFRLG9CQUFJQyxLQUFLO0FBQ3ZCLFFBQU1DLGNBQWNDLGVBQWVILEtBQUs7QUFDeEMsUUFBTUksV0FBV0MsTUFBTUMsS0FBSyxFQUFFQyxRQUFRLEVBQUUsR0FBRyxDQUFDQyxHQUFHQyxNQUFNO0FBQ25ELFVBQU1DLE9BQU8sSUFBSVQsS0FBS0MsV0FBVztBQUNqQ1EsU0FBS0MsUUFBUUQsS0FBS0UsUUFBUSxJQUFJSCxDQUFDO0FBQy9CLFdBQU9DO0FBQUFBLEVBQ1QsQ0FBQztBQUdELFFBQU1HLGFBQWFDLGdCQUFnQnBCLGdCQUFnQlUsUUFBUTtBQUUzRCxTQUNFLHVCQUFDLGFBQVEsV0FBVSx1REFDakI7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sYUFDRVYsZUFBZWEsU0FBUyxJQUNwQixHQUFHYixlQUFlYSxNQUFNLGdCQUFnQlIsZUFBZVEsTUFBTSx5REFDN0Q7QUFBQSxRQUVOLFNBQVE7QUFBQSxRQUNSLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGtEQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU1qQixZQUFZLE1BQU07QUFBQSxnQkFDakMsV0FBV1o7QUFBQUEsa0JBQ1Q7QUFBQSxrQkFDQVcsYUFBYSxTQUFTLDBCQUEwQjtBQUFBLGdCQUNsRDtBQUFBLGdCQUFFO0FBQUE7QUFBQSxjQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTUMsWUFBWSxPQUFPO0FBQUEsZ0JBQ2xDLFdBQVdaO0FBQUFBLGtCQUNUO0FBQUEsa0JBQ0FXLGFBQWEsVUFBVSwwQkFBMEI7QUFBQSxnQkFDbkQ7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsVUFDQSx1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFRLFNBQVEsV0FBVSxlQUFjLGNBQVcsV0FDbkUsaUNBQUMsYUFBVSxXQUFVLGVBQWMsYUFBYSxPQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRCxLQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBO0FBQUEsTUFqQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBa0NHO0FBQUEsSUFHSCx1QkFBQyxTQUFJLFdBQVUsaUNBQ2Y7QUFBQSw2QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSwrQkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sT0FBT0ssZUFBZWE7QUFBQUEsWUFDdEIsUUFBTztBQUFBO0FBQUEsVUFIVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHd0MsS0FKMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sT0FBT1IsZUFBZVE7QUFBQUEsWUFDdEIsUUFBTztBQUFBO0FBQUEsVUFIVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHMkQsS0FKN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sT0FBT00sV0FBV2IsTUFBTWUsT0FBTyxDQUFDLEdBQUdSLFVBQVU7QUFBQSxZQUM3QyxRQUFPO0FBQUE7QUFBQSxVQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdzRCxLQUp4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUNBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPLHVCQUFDLFVBQUssV0FBVSxjQUFjbEIsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVDO0FBQUEsWUFDOUMsUUFBTztBQUFBO0FBQUEsVUFIVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHZ0UsS0FKbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsV0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZCQTtBQUFBLE1BRUNLLGVBQWVhLFdBQVcsS0FDekI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU12QjtBQUFBQSxVQUNOLE9BQU07QUFBQSxVQUNOLGFBQVk7QUFBQTtBQUFBLFFBSGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR3VKO0FBQUEsTUFJeEpVLGVBQWVhLFNBQVMsS0FBS1IsZUFBZVEsU0FBUyxLQUNwRCx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGdEQUErQyw4QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRTtBQUFBLFFBQzNFLHVCQUFDLFNBQUksV0FBVSx3QkFDWlIseUJBQWVpQjtBQUFBQSxVQUFJLENBQUNDLFNBQ25CLHVCQUFDLFNBQW1CLFdBQVUsZ0hBQzVCO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDJDQUEyQ0EsZUFBS0MsU0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUU7QUFBQSxZQUNyRSx1QkFBQyxTQUFJLFdBQVUsZ0NBQThCO0FBQUE7QUFBQSxjQUNwQ0MsaUJBQWlCRixLQUFLbkIsVUFBVTtBQUFBLGlCQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKUW1CLEtBQUtHLEtBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFFBQ0QsS0FSSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BR0QxQixlQUFlYSxTQUFTLEtBQUtsQixhQUFhLFVBQ3pDLHVCQUFDLFNBQUksV0FBVSwwQkFDWmUsbUJBQVNZLElBQUksQ0FBQ0ssS0FBS1osTUFBTTtBQUN4QixjQUFNYSxXQUFXVCxXQUFXSixDQUFDLEtBQUs7QUFDbEMsY0FBTWMsVUFBVUMsVUFBVUgsS0FBS3JCLEtBQUs7QUFDcEMsZUFDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsV0FBV3RCO0FBQUFBLGNBQ1Q7QUFBQSxjQUNBNkMsVUFBVSx1QkFBdUI7QUFBQSxZQUNuQztBQUFBLFlBRUE7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsd0NBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsK0NBQ1pGLGNBQUlJLG1CQUFtQixTQUFTLEVBQUVDLFNBQVMsUUFBUSxDQUFDLEtBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ1pMLGNBQUlJLG1CQUFtQixTQUFTLEVBQUVFLE9BQU8sU0FBU04sS0FBSyxVQUFVLENBQUMsS0FEckU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDWkMsbUJBQVNOO0FBQUFBLGdCQUFJLENBQUNDLFNBQ2IsdUJBQUMsWUFBd0IsUUFBVkEsS0FBS0csS0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0M7QUFBQSxjQUNyQyxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQTtBQUFBO0FBQUEsVUFsQktDLElBQUlPLFlBQVk7QUFBQSxVQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBb0JBO0FBQUEsTUFFSixDQUFDLEtBM0JIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0QkE7QUFBQSxNQUdEbEMsZUFBZWEsU0FBUyxLQUFLbEIsYUFBYSxXQUN6Qyx1QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsZ0RBQ1hXLGdCQUFNeUIsbUJBQW1CLFNBQVMsRUFBRUMsU0FBUyxRQUFRQyxPQUFPLFFBQVFOLEtBQUssVUFBVSxDQUFDLEtBRHZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHVCQUNYUixzQkFBV2IsTUFBTWUsT0FBTyxDQUFDLEtBQUssSUFBSUM7QUFBQUEsVUFBSSxDQUFDQyxTQUN2Qyx1QkFBQyxZQUF3QixNQUFZLE9BQUssUUFBM0JBLEtBQUtHLEtBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBDO0FBQUEsUUFDM0MsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLFNBbEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvR0E7QUFBQSxPQTFJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMklBO0FBRUo7QUFBQ2hDLEdBdEtlRixjQUFZO0FBQUEsVUFFWlYsUUFBUTtBQUFBO0FBQUEsS0FGUlU7QUE2S2hCLFNBQVMyQyxTQUFTLEVBQUVaLE1BQU1hLE1BQXFCLEdBQUc7QUFDaEQsUUFBTUMsT0FBT2QsS0FBS3BCLGVBQ2QsSUFBSUksS0FBS2dCLEtBQUtwQixZQUFZLEVBQUVtQyxtQkFBbUIsU0FBUztBQUFBLElBQ3REQyxNQUFNO0FBQUEsSUFDTkMsUUFBUTtBQUFBLEVBQ1YsQ0FBQyxJQUNEO0FBRUosU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBV3hEO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBb0QsU0FBUztBQUFBLE1BQ1g7QUFBQSxNQUVBO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFDQUFxQ0M7QUFBQUE7QUFBQUEsVUFBSztBQUFBLFVBQUlkLEtBQUtrQjtBQUFBQSxhQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVFO0FBQUEsUUFDdkUsdUJBQUMsU0FBSSxXQUFVLG1EQUFtRGxCLGVBQUtDLFNBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkU7QUFBQSxRQUM1RUQsS0FBS21CLGVBQWVOLFNBQ25CLHVCQUFDLFNBQUksV0FBVSxvREFBb0RiLGVBQUttQixlQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9GO0FBQUE7QUFBQTtBQUFBLElBVHhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVdBO0FBRUo7QUFBQ0MsTUF0QlFSO0FBd0JULFNBQVMxQixlQUFlTyxNQUFrQjtBQUN4QyxRQUFNNEIsSUFBSSxJQUFJckMsS0FBS1MsSUFBSTtBQUN2QixRQUFNVyxNQUFNaUIsRUFBRXZCLE9BQU87QUFDckIsUUFBTXdCLE9BQU9ELEVBQUUxQixRQUFRLElBQUlTO0FBQzNCLFNBQU8sSUFBSXBCLEtBQUtxQyxFQUFFM0IsUUFBUTRCLElBQUksQ0FBQztBQUNqQztBQUVBLFNBQVNmLFVBQVVnQixJQUFVQyxJQUFtQjtBQUM5QyxTQUNFRCxHQUFHRSxZQUFZLE1BQU1ELEdBQUdDLFlBQVksS0FDcENGLEdBQUdHLFNBQVMsTUFBTUYsR0FBR0UsU0FBUyxLQUM5QkgsR0FBRzVCLFFBQVEsTUFBTTZCLEdBQUc3QixRQUFRO0FBRWhDO0FBRUEsU0FBU0UsZ0JBQWdCdkIsT0FBdUJhLFVBQW9DO0FBQ2xGLFFBQU13QyxVQUE0QnZDLE1BQU1DLEtBQUssRUFBRUMsUUFBUSxFQUFFLEdBQUcsTUFBTSxFQUFFO0FBRXBFLGFBQVdVLFFBQVExQixPQUFPO0FBQ3hCLFFBQUkwQixLQUFLcEIsY0FBYztBQUNyQixZQUFNZ0QsV0FBVyxJQUFJNUMsS0FBS2dCLEtBQUtwQixZQUFZO0FBQzNDLFlBQU1pRCxXQUFXMUMsU0FBUzJDLFVBQVUsQ0FBQ1QsTUFBTWQsVUFBVWMsR0FBR08sUUFBUSxDQUFDO0FBQ2pFLFVBQUlDLGFBQWEsSUFBSTtBQUNuQkYsZ0JBQVFFLFFBQVEsRUFBRUUsS0FBSy9CLElBQUk7QUFBQSxNQUM3QjtBQUFBLElBQ0YsV0FBV0EsS0FBS25CLFlBQVk7QUFDMUIsZUFBU1csSUFBSSxHQUFHQSxJQUFJLEdBQUdBLEtBQUs7QUFDMUJtQyxnQkFBUW5DLENBQUMsRUFBRXVDLEtBQUsvQixJQUFJO0FBQUEsTUFDdEI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLGFBQVdLLFlBQVlzQixTQUFTO0FBQzlCdEIsYUFBUzJCLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTTtBQUN0QixZQUFNQyxRQUFRRixFQUFFckQsZ0JBQWdCO0FBQ2hDLFlBQU13RCxRQUFRRixFQUFFdEQsZ0JBQWdCO0FBQ2hDLGFBQU91RCxRQUFRQztBQUFBQSxJQUNqQixDQUFDO0FBQUEsRUFDSDtBQUVBLFNBQU9UO0FBQ1Q7QUFFQSxTQUFTekIsaUJBQWlCckIsWUFBZ0Q7QUFDeEUsTUFBSSxDQUFDQSxXQUFZLFFBQU87QUFDeEIsUUFBTSxFQUFFd0QsV0FBV0MsU0FBUyxJQUFJekQ7QUFDaEMsTUFBSSxDQUFDd0QsVUFBVyxRQUFPO0FBQ3ZCLE1BQUlDLGFBQWEsR0FBRztBQUNsQixXQUFPRCxVQUFVRSxZQUFZO0FBQUEsRUFDL0I7QUFDQSxTQUFPLEdBQUdELFFBQVEsSUFBSUQsVUFBVUUsWUFBWSxDQUFDO0FBQy9DO0FBQUMsSUFBQUMsSUFBQXBCO0FBQUEsYUFBQW9CLElBQUE7QUFBQSxhQUFBcEIsS0FBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlUXVlcnkiLCJhcGkiLCJjbiIsIlBhZ2VIZWFkZXIiLCJDYXJkIiwiQnV0dG9uIiwiRW1wdHlTdGF0ZSIsIk1ldHJpY0Jsb2NrIiwiQ2FsZW5kYXIiLCJSZWZyZXNoQ3ciLCJDYWxlbmRhclZpZXciLCJwcm9qZWN0SWQiLCJfcyIsInZpZXdNb2RlIiwic2V0Vmlld01vZGUiLCJ0YXNrcyIsImxpc3QiLCJ1bmRlZmluZWQiLCJzY2hlZHVsZWRUYXNrcyIsImZpbHRlciIsInQiLCJzY2hlZHVsZWRGb3IiLCJyZWN1cnJlbmNlIiwicmVjdXJyaW5nVGFza3MiLCJ0b2RheSIsIkRhdGUiLCJzdGFydE9mV2VlayIsImdldFN0YXJ0T2ZXZWVrIiwid2Vla0RheXMiLCJBcnJheSIsImZyb20iLCJsZW5ndGgiLCJfIiwiaSIsImRhdGUiLCJzZXREYXRlIiwiZ2V0RGF0ZSIsInRhc2tzQnlEYXkiLCJncm91cFRhc2tzQnlEYXkiLCJnZXREYXkiLCJtYXAiLCJ0YXNrIiwidGl0bGUiLCJmb3JtYXRSZWN1cnJlbmNlIiwiX2lkIiwiZGF5IiwiZGF5VGFza3MiLCJpc1RvZGF5IiwiaXNTYW1lRGF5IiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwid2Vla2RheSIsIm1vbnRoIiwidG9JU09TdHJpbmciLCJUYXNrQ2FyZCIsImxhcmdlIiwidGltZSIsInRvTG9jYWxlVGltZVN0cmluZyIsImhvdXIiLCJtaW51dGUiLCJ0eXBlIiwiZGVzY3JpcHRpb24iLCJfYzIiLCJkIiwiZGlmZiIsImQxIiwiZDIiLCJnZXRGdWxsWWVhciIsImdldE1vbnRoIiwiZ3JvdXBlZCIsInRhc2tEYXRlIiwiZGF5SW5kZXgiLCJmaW5kSW5kZXgiLCJwdXNoIiwic29ydCIsImEiLCJiIiwidGltZUEiLCJ0aW1lQiIsImZyZXF1ZW5jeSIsImludGVydmFsIiwidG9Mb3dlckNhc2UiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYWxlbmRhclZpZXcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB0eXBlIHsgSWQsIERvYyB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9kYXRhTW9kZWxcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5pbXBvcnQgeyBQYWdlSGVhZGVyIH0gZnJvbSBcIi4vY29tcG9uZW50cy9QYWdlSGVhZGVyXCI7XG5pbXBvcnQgeyBDYXJkIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9jYXJkXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuaW1wb3J0IHsgRW1wdHlTdGF0ZSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvZW1wdHktc3RhdGVcIjtcbmltcG9ydCB7IE1ldHJpY0Jsb2NrIH0gZnJvbSBcIkAvY29tcG9uZW50cy9mYWN0b3J5L01ldHJpY0Jsb2NrXCI7XG5pbXBvcnQgeyBDYWxlbmRhciwgUmVmcmVzaEN3IH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuXG5pbnRlcmZhY2UgQ2FsZW5kYXJWaWV3UHJvcHMge1xuICBwcm9qZWN0SWQ6IElkPFwicHJvamVjdHNcIj4gfCBudWxsO1xufVxuXG50eXBlIFZpZXdNb2RlID0gXCJ3ZWVrXCIgfCBcInRvZGF5XCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBDYWxlbmRhclZpZXcoeyBwcm9qZWN0SWQgfTogQ2FsZW5kYXJWaWV3UHJvcHMpIHtcbiAgY29uc3QgW3ZpZXdNb2RlLCBzZXRWaWV3TW9kZV0gPSB1c2VTdGF0ZTxWaWV3TW9kZT4oXCJ3ZWVrXCIpO1xuICBjb25zdCB0YXNrcyA9IHVzZVF1ZXJ5KGFwaS50YXNrcy5saXN0LCB7IHByb2plY3RJZDogcHJvamVjdElkID8/IHVuZGVmaW5lZCB9KTtcblxuICAvLyBHZXQgc2NoZWR1bGVkIHRhc2tzICh0YXNrcyB3aXRoIHNjaGVkdWxlZEZvciBvciByZWN1cnJlbmNlKVxuICBjb25zdCBzY2hlZHVsZWRUYXNrcyA9IHRhc2tzPy5maWx0ZXIoXG4gICAgKHQpID0+IHQuc2NoZWR1bGVkRm9yIHx8IHQucmVjdXJyZW5jZVxuICApID8/IFtdO1xuXG4gIC8vIEdldCByZWN1cnJpbmcgdGFza3MgKGFsd2F5cyBydW5uaW5nKVxuICBjb25zdCByZWN1cnJpbmdUYXNrcyA9IHNjaGVkdWxlZFRhc2tzLmZpbHRlcigodCkgPT4gdC5yZWN1cnJlbmNlKTtcblxuICAvLyBHZXQgdG9kYXkncyBkYXRlXG4gIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcbiAgY29uc3Qgc3RhcnRPZldlZWsgPSBnZXRTdGFydE9mV2Vlayh0b2RheSk7XG4gIGNvbnN0IHdlZWtEYXlzID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogNyB9LCAoXywgaSkgPT4ge1xuICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShzdGFydE9mV2Vlayk7XG4gICAgZGF0ZS5zZXREYXRlKGRhdGUuZ2V0RGF0ZSgpICsgaSk7XG4gICAgcmV0dXJuIGRhdGU7XG4gIH0pO1xuXG4gIC8vIEdyb3VwIHRhc2tzIGJ5IGRheVxuICBjb25zdCB0YXNrc0J5RGF5ID0gZ3JvdXBUYXNrc0J5RGF5KHNjaGVkdWxlZFRhc2tzLCB3ZWVrRGF5cyk7XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLTAgZmxleC0xIGZsZXgtY29sIG92ZXJmbG93LXktYXV0byBiZy1hcHBcIj5cbiAgICAgIDxQYWdlSGVhZGVyXG4gICAgICAgIHRpdGxlPVwiQ2FsZW5kYXJcIlxuICAgICAgICBkZXNjcmlwdGlvbj17XG4gICAgICAgICAgc2NoZWR1bGVkVGFza3MubGVuZ3RoID4gMFxuICAgICAgICAgICAgPyBgJHtzY2hlZHVsZWRUYXNrcy5sZW5ndGh9IHNjaGVkdWxlZCDCtyAke3JlY3VycmluZ1Rhc2tzLmxlbmd0aH0gcmVjdXJyaW5nIOKAlCBjb25maXJtIHlvdXIgYWdlbnRzIGFyZSBiZWluZyBwcm9hY3RpdmVgXG4gICAgICAgICAgICA6IFwiQ3JvbiBqb2JzIGFuZCBzY2hlZHVsZWQgdGFza3MgZm9yIHlvdXIgYWdlbnRzLiBTY2hlZHVsZSByb3V0aW5lcyB0byBjb25maXJtIHlvdXIgb3BlbiBjbGF3IGlzIGJlaW5nIHByb2FjdGl2ZS5cIlxuICAgICAgICB9XG4gICAgICAgIGV5ZWJyb3c9XCJPcGVyYXRpb25zXCJcbiAgICAgICAgYWN0aW9ucz17XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0xIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1saW5lIHAtMC41XCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3TW9kZShcIndlZWtcIil9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgIFwicm91bmRlZC1tZCBweC0zIHB5LTEgdGV4dC14cyBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIixcbiAgICAgICAgICAgICAgICAgIHZpZXdNb2RlID09PSBcIndlZWtcIiA/IFwiYmctc3VyZmFjZS0yIHRleHQtaW5rXCIgOiBcInRleHQtaW5rLXNlY29uZGFyeSBob3Zlcjp0ZXh0LWlua1wiXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIFdlZWtcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3TW9kZShcInRvZGF5XCIpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICBcInJvdW5kZWQtbWQgcHgtMyBweS0xIHRleHQteHMgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCIsXG4gICAgICAgICAgICAgICAgICB2aWV3TW9kZSA9PT0gXCJ0b2RheVwiID8gXCJiZy1zdXJmYWNlLTIgdGV4dC1pbmtcIiA6IFwidGV4dC1pbmstc2Vjb25kYXJ5IGhvdmVyOnRleHQtaW5rXCJcbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgVG9kYXlcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cImdob3N0XCIgY2xhc3NOYW1lPVwiaC04IHctOCBwLTBcIiBhcmlhLWxhYmVsPVwiUmVmcmVzaFwiPlxuICAgICAgICAgICAgICA8UmVmcmVzaEN3IGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgc3Ryb2tlV2lkdGg9ezEuN30gLz5cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICAvPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNiBmbGV4IGZsZXgtY29sIGdhcC02XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTQgbWQ6Z3JpZC1jb2xzLTRcIj5cbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC00XCI+XG4gICAgICAgICAgPE1ldHJpY0Jsb2NrXG4gICAgICAgICAgICBsYWJlbD1cIlNjaGVkdWxlZFwiXG4gICAgICAgICAgICB2YWx1ZT17c2NoZWR1bGVkVGFza3MubGVuZ3RofVxuICAgICAgICAgICAgZGV0YWlsPVwiVGFza3MgdmlzaWJsZSBvbiB0aGUgY2FsZW5kYXJcIlxuICAgICAgICAgIC8+XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC00XCI+XG4gICAgICAgICAgPE1ldHJpY0Jsb2NrXG4gICAgICAgICAgICBsYWJlbD1cIlJlY3VycmluZ1wiXG4gICAgICAgICAgICB2YWx1ZT17cmVjdXJyaW5nVGFza3MubGVuZ3RofVxuICAgICAgICAgICAgZGV0YWlsPVwiUm91dGluZXMgc3RpbGwgcmVwZWF0aW5nIHdpdGhvdXQgbWFudWFsIHJlLWVudHJ5XCJcbiAgICAgICAgICAvPlxuICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICAgIDxNZXRyaWNCbG9ja1xuICAgICAgICAgICAgbGFiZWw9XCJUb2RheVwiXG4gICAgICAgICAgICB2YWx1ZT17dGFza3NCeURheVt0b2RheS5nZXREYXkoKV0/Lmxlbmd0aCA/PyAwfVxuICAgICAgICAgICAgZGV0YWlsPVwiVGFza3MgY3VycmVudGx5IGxhbmRpbmcgb24gdG9kYXkncyBzY2hlZHVsZVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9DYXJkPlxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTRcIj5cbiAgICAgICAgICA8TWV0cmljQmxvY2tcbiAgICAgICAgICAgIGxhYmVsPVwiVmlld1wiXG4gICAgICAgICAgICB2YWx1ZT17PHNwYW4gY2xhc3NOYW1lPVwiY2FwaXRhbGl6ZVwiPnt2aWV3TW9kZX08L3NwYW4+fVxuICAgICAgICAgICAgZGV0YWlsPVwiU3dpdGNoIGJldHdlZW4gYSB3ZWVrbHkgc2NhbiBhbmQgYSBmb2N1c2VkIHRvZGF5IHZpZXdcIlxuICAgICAgICAgIC8+XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7c2NoZWR1bGVkVGFza3MubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgPEVtcHR5U3RhdGVcbiAgICAgICAgICBpY29uPXtDYWxlbmRhcn1cbiAgICAgICAgICB0aXRsZT1cIk5vIHNjaGVkdWxlZCB0YXNrc1wiXG4gICAgICAgICAgZGVzY3JpcHRpb249XCJBZGQgYSBkdWUgZGF0ZSBvciByZWN1cnJlbmNlIHRvIHRhc2tzIGZyb20gdGhlIHRhc2sgZHJhd2VyIHRvIHNlZSB0aGVtIGhlcmUuIEdyZWF0IGZvciBzdGFuZHVwcywgcmV2aWV3cywgYW5kIHJlY3VycmluZyBhZ2VudCByb3V0aW5lcy5cIlxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAge3NjaGVkdWxlZFRhc2tzLmxlbmd0aCA+IDAgJiYgcmVjdXJyaW5nVGFza3MubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzE5cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmsgbXQtMCBtYi0zXCI+QWx3YXlzIHJ1bm5pbmc8L2gyPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMyBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgIHtyZWN1cnJpbmdUYXNrcy5tYXAoKHRhc2spID0+IChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e3Rhc2suX2lkfSBjbGFzc05hbWU9XCJweS0zIHB4LTQgYmctc3VyZmFjZS0xIGJvcmRlciBib3JkZXItbGluZSByb3VuZGVkLXhsIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBob3Zlcjpib3JkZXItbGluZS1zdHJvbmdcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEzLjVweF0gZm9udC1tZWRpdW0gdGV4dC1pbmsgbWItMVwiPnt0YXNrLnRpdGxlfTwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgRXZlcnkge2Zvcm1hdFJlY3VycmVuY2UodGFzay5yZWN1cnJlbmNlKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7c2NoZWR1bGVkVGFza3MubGVuZ3RoID4gMCAmJiB2aWV3TW9kZSA9PT0gXCJ3ZWVrXCIgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTcgZ2FwLTNcIj5cbiAgICAgICAgICB7d2Vla0RheXMubWFwKChkYXksIGkpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGRheVRhc2tzID0gdGFza3NCeURheVtpXSB8fCBbXTtcbiAgICAgICAgICAgIGNvbnN0IGlzVG9kYXkgPSBpc1NhbWVEYXkoZGF5LCB0b2RheSk7XG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAga2V5PXtkYXkudG9JU09TdHJpbmcoKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgXCJiZy1zdXJmYWNlLTEgYm9yZGVyIHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuXCIsXG4gICAgICAgICAgICAgICAgICBpc1RvZGF5ID8gXCJib3JkZXItbGluZS1zdHJvbmdcIiA6IFwiYm9yZGVyLWxpbmVcIlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBib3JkZXItYiBib3JkZXItbGluZSB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMy41cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmsgbWItMC41XCI+XG4gICAgICAgICAgICAgICAgICAgIHtkYXkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tVVNcIiwgeyB3ZWVrZGF5OiBcInNob3J0XCIgfSl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgICB7ZGF5LnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLVVTXCIsIHsgbW9udGg6IFwic2hvcnRcIiwgZGF5OiBcIm51bWVyaWNcIiB9KX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGZsZXggZmxleC1jb2wgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIHtkYXlUYXNrcy5tYXAoKHRhc2spID0+IChcbiAgICAgICAgICAgICAgICAgICAgPFRhc2tDYXJkIGtleT17dGFzay5faWR9IHRhc2s9e3Rhc2t9IC8+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHtzY2hlZHVsZWRUYXNrcy5sZW5ndGggPiAwICYmIHZpZXdNb2RlID09PSBcInRvZGF5XCIgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LVs4MDBweF0gbXgtYXV0byB3LWZ1bGxcIj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMTlweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWluayBtdC0wIG1iLTZcIj5cbiAgICAgICAgICAgIHt0b2RheS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1VU1wiLCB7IHdlZWtkYXk6IFwibG9uZ1wiLCBtb250aDogXCJsb25nXCIsIGRheTogXCJudW1lcmljXCIgfSl9XG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTNcIj5cbiAgICAgICAgICAgIHsodGFza3NCeURheVt0b2RheS5nZXREYXkoKV0gfHwgW10pLm1hcCgodGFzaykgPT4gKFxuICAgICAgICAgICAgICA8VGFza0NhcmQga2V5PXt0YXNrLl9pZH0gdGFzaz17dGFza30gbGFyZ2UgLz5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG5cbmludGVyZmFjZSBUYXNrQ2FyZFByb3BzIHtcbiAgdGFzazogRG9jPFwidGFza3NcIj47XG4gIGxhcmdlPzogYm9vbGVhbjtcbn1cblxuZnVuY3Rpb24gVGFza0NhcmQoeyB0YXNrLCBsYXJnZSB9OiBUYXNrQ2FyZFByb3BzKSB7XG4gIGNvbnN0IHRpbWUgPSB0YXNrLnNjaGVkdWxlZEZvclxuICAgID8gbmV3IERhdGUodGFzay5zY2hlZHVsZWRGb3IpLnRvTG9jYWxlVGltZVN0cmluZyhcImVuLVVTXCIsIHtcbiAgICAgICAgaG91cjogXCIyLWRpZ2l0XCIsXG4gICAgICAgIG1pbnV0ZTogXCIyLWRpZ2l0XCIsXG4gICAgICB9KVxuICAgIDogXCJBbGwgZGF5XCI7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcInB5LTIgcHgtMyBiZy1zdXJmYWNlLTIgYm9yZGVyIGJvcmRlci1saW5lIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGhvdmVyOmJvcmRlci1saW5lLXN0cm9uZ1wiLFxuICAgICAgICBsYXJnZSAmJiBcInB5LTMgcHgtNFwiXG4gICAgICApfVxuICAgID5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZCBtYi0xXCI+e3RpbWV9IMK3IHt0YXNrLnR5cGV9PC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEzLjVweF0gZm9udC1tZWRpdW0gdGV4dC1pbmsgbGVhZGluZy1zbnVnXCI+e3Rhc2sudGl0bGV9PC9kaXY+XG4gICAgICB7dGFzay5kZXNjcmlwdGlvbiAmJiBsYXJnZSAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZCBtdC0xLjUgbGVhZGluZy1zbnVnXCI+e3Rhc2suZGVzY3JpcHRpb259PC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufVxuXG5mdW5jdGlvbiBnZXRTdGFydE9mV2VlayhkYXRlOiBEYXRlKTogRGF0ZSB7XG4gIGNvbnN0IGQgPSBuZXcgRGF0ZShkYXRlKTtcbiAgY29uc3QgZGF5ID0gZC5nZXREYXkoKTtcbiAgY29uc3QgZGlmZiA9IGQuZ2V0RGF0ZSgpIC0gZGF5O1xuICByZXR1cm4gbmV3IERhdGUoZC5zZXREYXRlKGRpZmYpKTtcbn1cblxuZnVuY3Rpb24gaXNTYW1lRGF5KGQxOiBEYXRlLCBkMjogRGF0ZSk6IGJvb2xlYW4ge1xuICByZXR1cm4gKFxuICAgIGQxLmdldEZ1bGxZZWFyKCkgPT09IGQyLmdldEZ1bGxZZWFyKCkgJiZcbiAgICBkMS5nZXRNb250aCgpID09PSBkMi5nZXRNb250aCgpICYmXG4gICAgZDEuZ2V0RGF0ZSgpID09PSBkMi5nZXREYXRlKClcbiAgKTtcbn1cblxuZnVuY3Rpb24gZ3JvdXBUYXNrc0J5RGF5KHRhc2tzOiBEb2M8XCJ0YXNrc1wiPltdLCB3ZWVrRGF5czogRGF0ZVtdKTogRG9jPFwidGFza3NcIj5bXVtdIHtcbiAgY29uc3QgZ3JvdXBlZDogRG9jPFwidGFza3NcIj5bXVtdID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogNyB9LCAoKSA9PiBbXSk7XG5cbiAgZm9yIChjb25zdCB0YXNrIG9mIHRhc2tzKSB7XG4gICAgaWYgKHRhc2suc2NoZWR1bGVkRm9yKSB7XG4gICAgICBjb25zdCB0YXNrRGF0ZSA9IG5ldyBEYXRlKHRhc2suc2NoZWR1bGVkRm9yKTtcbiAgICAgIGNvbnN0IGRheUluZGV4ID0gd2Vla0RheXMuZmluZEluZGV4KChkKSA9PiBpc1NhbWVEYXkoZCwgdGFza0RhdGUpKTtcbiAgICAgIGlmIChkYXlJbmRleCAhPT0gLTEpIHtcbiAgICAgICAgZ3JvdXBlZFtkYXlJbmRleF0ucHVzaCh0YXNrKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHRhc2sucmVjdXJyZW5jZSkge1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCA3OyBpKyspIHtcbiAgICAgICAgZ3JvdXBlZFtpXS5wdXNoKHRhc2spO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGZvciAoY29uc3QgZGF5VGFza3Mgb2YgZ3JvdXBlZCkge1xuICAgIGRheVRhc2tzLnNvcnQoKGEsIGIpID0+IHtcbiAgICAgIGNvbnN0IHRpbWVBID0gYS5zY2hlZHVsZWRGb3IgPz8gMDtcbiAgICAgIGNvbnN0IHRpbWVCID0gYi5zY2hlZHVsZWRGb3IgPz8gMDtcbiAgICAgIHJldHVybiB0aW1lQSAtIHRpbWVCO1xuICAgIH0pO1xuICB9XG5cbiAgcmV0dXJuIGdyb3VwZWQ7XG59XG5cbmZ1bmN0aW9uIGZvcm1hdFJlY3VycmVuY2UocmVjdXJyZW5jZTogRG9jPFwidGFza3NcIj5bXCJyZWN1cnJlbmNlXCJdKTogc3RyaW5nIHtcbiAgaWYgKCFyZWN1cnJlbmNlKSByZXR1cm4gXCJcIjtcbiAgY29uc3QgeyBmcmVxdWVuY3ksIGludGVydmFsIH0gPSByZWN1cnJlbmNlO1xuICBpZiAoIWZyZXF1ZW5jeSkgcmV0dXJuIFwiXCI7XG4gIGlmIChpbnRlcnZhbCA9PT0gMSkge1xuICAgIHJldHVybiBmcmVxdWVuY3kudG9Mb3dlckNhc2UoKTtcbiAgfVxuICByZXR1cm4gYCR7aW50ZXJ2YWx9ICR7ZnJlcXVlbmN5LnRvTG93ZXJDYXNlKCl9YDtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL0NhbGVuZGFyVmlldy50c3gifQ==