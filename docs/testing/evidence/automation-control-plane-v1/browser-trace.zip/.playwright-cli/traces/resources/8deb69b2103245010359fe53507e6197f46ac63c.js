import {
  useLayoutEffect2
} from "/node_modules/.vite/deps/chunk-O33AWSB4.js?v=738cb978";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-GMP6FTHE.js?v=738cb978";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-G3PMV62Z.js?v=738cb978";

// ../../../../../../../../node_modules/.pnpm/@radix-ui+react-id@1.1.1_@types+react@18.3.27_react@18.3.1/node_modules/@radix-ui/react-id/dist/index.mjs
var React = __toESM(require_react(), 1);
var useReactId = React[" useId ".trim().toString()] || (() => void 0);
var count = 0;
function useId(deterministicId) {
  const [id, setId] = React.useState(useReactId());
  useLayoutEffect2(() => {
    if (!deterministicId) setId((reactId) => reactId ?? String(count++));
  }, [deterministicId]);
  return deterministicId || (id ? `radix-${id}` : "");
}

// ../../../../../../../../node_modules/.pnpm/@radix-ui+react-use-controllable-state@1.2.2_@types+react@18.3.27_react@18.3.1/node_modules/@radix-ui/react-use-controllable-state/dist/index.mjs
var React3 = __toESM(require_react(), 1);
var React22 = __toESM(require_react(), 1);

// ../../../../../../../../node_modules/.pnpm/@radix-ui+react-use-effect-event@0.0.2_@types+react@18.3.27_react@18.3.1/node_modules/@radix-ui/react-use-effect-event/dist/index.mjs
var React2 = __toESM(require_react(), 1);
var useReactEffectEvent = React2[" useEffectEvent ".trim().toString()];
var useReactInsertionEffect = React2[" useInsertionEffect ".trim().toString()];

// ../../../../../../../../node_modules/.pnpm/@radix-ui+react-use-controllable-state@1.2.2_@types+react@18.3.27_react@18.3.1/node_modules/@radix-ui/react-use-controllable-state/dist/index.mjs
var useInsertionEffect = React3[" useInsertionEffect ".trim().toString()] || useLayoutEffect2;
function useControllableState({
  prop,
  defaultProp,
  onChange = () => {
  },
  caller
}) {
  const [uncontrolledProp, setUncontrolledProp, onChangeRef] = useUncontrolledState({
    defaultProp,
    onChange
  });
  const isControlled = prop !== void 0;
  const value = isControlled ? prop : uncontrolledProp;
  if (true) {
    const isControlledRef = React3.useRef(prop !== void 0);
    React3.useEffect(() => {
      const wasControlled = isControlledRef.current;
      if (wasControlled !== isControlled) {
        const from = wasControlled ? "controlled" : "uncontrolled";
        const to = isControlled ? "controlled" : "uncontrolled";
        console.warn(
          `${caller} is changing from ${from} to ${to}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`
        );
      }
      isControlledRef.current = isControlled;
    }, [isControlled, caller]);
  }
  const setValue = React3.useCallback(
    (nextValue) => {
      var _a;
      if (isControlled) {
        const value2 = isFunction(nextValue) ? nextValue(prop) : nextValue;
        if (value2 !== prop) {
          (_a = onChangeRef.current) == null ? void 0 : _a.call(onChangeRef, value2);
        }
      } else {
        setUncontrolledProp(nextValue);
      }
    },
    [isControlled, prop, setUncontrolledProp, onChangeRef]
  );
  return [value, setValue];
}
function useUncontrolledState({
  defaultProp,
  onChange
}) {
  const [value, setValue] = React3.useState(defaultProp);
  const prevValueRef = React3.useRef(value);
  const onChangeRef = React3.useRef(onChange);
  useInsertionEffect(() => {
    onChangeRef.current = onChange;
  }, [onChange]);
  React3.useEffect(() => {
    var _a;
    if (prevValueRef.current !== value) {
      (_a = onChangeRef.current) == null ? void 0 : _a.call(onChangeRef, value);
      prevValueRef.current = value;
    }
  }, [value, prevValueRef]);
  return [value, setValue, onChangeRef];
}
function isFunction(value) {
  return typeof value === "function";
}
var SYNC_STATE = Symbol("RADIX:SYNC_STATE");

export {
  useId,
  useControllableState
};
//# sourceMappingURL=chunk-CYJRKYTH.js.map
