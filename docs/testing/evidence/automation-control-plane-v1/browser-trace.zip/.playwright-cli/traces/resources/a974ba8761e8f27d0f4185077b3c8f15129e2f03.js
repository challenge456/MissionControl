import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/AgentsFlyout.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { X } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { cn } from "/src/lib/utils.ts";
import { StatusBadge } from "/src/components/factory/badges.tsx";
import { ScrollArea } from "/src/components/ui/scroll-area.tsx";
import { AgentDetailFlyout } from "/src/AgentDetailFlyout.tsx";
const FLYOUT_WIDTH = 320;
function SidebarButton({
  onClick,
  label,
  badge,
  variant = "default",
  fullWidth = false
}) {
  const variantClasses = {
    default: "border-line bg-surface-2 text-ink-secondary hover:text-ink hover:border-line-strong",
    warning: "border-transparent bg-warn-soft text-warn hover:opacity-90",
    danger: "border-transparent bg-err-soft text-err hover:opacity-90",
    success: "border-transparent bg-ok-soft text-ok hover:opacity-90"
  };
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      onClick,
      className: cn(
        "px-3 py-2 rounded-lg text-xs font-medium border transition-colors duration-150 cursor-pointer",
        variantClasses[variant],
        fullWidth ? "w-full" : "flex-1 min-w-0"
      ),
      children: /* @__PURE__ */ jsxDEV("span", { className: "flex items-center justify-center gap-1.5", children: [
        label,
        badge && /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "info", children: badge }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
          lineNumber: 64,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
        lineNumber: 62,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
      lineNumber: 53,
      columnNumber: 5
    },
    this
  );
}
_c = SidebarButton;
function AgentRow({
  agent,
  onClick
}) {
  const isActive = agent.status === "ACTIVE";
  const statusLabel = isActive ? "Active" : "Not active";
  const roleShort = agent.role === "LEAD" ? "Lead" : agent.role === "SPECIALIST" ? "Spc" : agent.role === "INTERN" ? "Int" : agent.role;
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      onClick,
      className: "w-full flex items-center gap-3 px-3 py-2 text-left cursor-pointer border-0 bg-transparent hover:bg-surface-2 transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
      "aria-label": `${agent.name}, ${roleShort}, ${statusLabel}`,
      children: [
        /* @__PURE__ */ jsxDEV("span", { className: "flex w-8 h-8 shrink-0 items-center justify-center rounded-lg border border-line bg-surface-2 text-sm text-ink", children: agent.emoji || agent.name.charAt(0) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
          lineNumber: 95,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] font-medium text-ink truncate", children: agent.name }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
            lineNumber: 99,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-[11.5px] text-ink-muted", children: roleShort }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
            lineNumber: 100,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
          lineNumber: 98,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "span",
          {
            className: cn(
              "w-2 h-2 rounded-full shrink-0",
              isActive ? "bg-ok" : "bg-ink-muted"
            ),
            title: agent.status,
            "aria-hidden": true
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
            lineNumber: 102,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
      lineNumber: 89,
      columnNumber: 5
    },
    this
  );
}
_c2 = AgentRow;
export function AgentsFlyout({
  projectId,
  onClose,
  onOpenApprovals,
  onOpenPolicy,
  onOpenOperatorControls,
  onOpenNotifications,
  onOpenStandup,
  onPauseSquad,
  onResumeSquad,
  onOpenOrg
}) {
  _s();
  const [selectedAgentId, setSelectedAgentId] = useState(null);
  const panelRef = useRef(null);
  const returnFocusRef = useRef(null);
  const agents = useQuery(api.agents.listAll, projectId ? { projectId } : {});
  const pendingApprovals = useQuery(api.approvals.listPending, projectId ? { projectId, limit: 10 } : { limit: 10 });
  const pendingCount = pendingApprovals?.length ?? 0;
  const agentCount = agents?.length ?? 0;
  const pausedCount = agents?.filter((a) => a.status === "PAUSED").length ?? 0;
  useEffect(() => {
    const onKeyDown = (event) => {
      if (event.key !== "Escape") return;
      if (selectedAgentId) {
        setSelectedAgentId(null);
      } else {
        onClose();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [onClose, selectedAgentId]);
  useEffect(() => {
    returnFocusRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    panelRef.current?.focus({ preventScroll: true });
    return () => returnFocusRef.current?.focus({ preventScroll: true });
  }, []);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "fixed inset-0 z-40 bg-black/40",
        "aria-hidden": true,
        onClick: onClose
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
        lineNumber: 168,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "aside",
      {
        ref: panelRef,
        className: "fixed top-0 left-0 bottom-0 z-50 flex flex-col border-r border-line bg-surface-1 animate-in slide-in-from-left duration-200",
        style: { width: FLYOUT_WIDTH },
        role: "dialog",
        "aria-modal": "true",
        "aria-label": "Agents panel",
        tabIndex: -1,
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 px-4 py-3 shrink-0 border-b border-line", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-[13px] text-ink", children: "Agents" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
              lineNumber: 186,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", children: agentCount }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
              lineNumber: 189,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: onClose,
                className: "ml-auto p-1.5 rounded-md text-ink-muted hover:text-ink hover:bg-surface-2 transition-colors duration-150",
                "aria-label": "Close agents panel",
                children: /* @__PURE__ */ jsxDEV(X, { className: "h-4 w-4" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
                  lineNumber: 196,
                  columnNumber: 13
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
                lineNumber: 190,
                columnNumber: 11
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
            lineNumber: 185,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "px-3 py-3 shrink-0 border-b border-line", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-[11.5px] font-medium uppercase tracking-[0.06em] text-ink-muted mb-2", children: "Quick Actions" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
              lineNumber: 202,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-1.5 mb-2", children: [
              onOpenNotifications && /* @__PURE__ */ jsxDEV(SidebarButton, { onClick: onOpenNotifications, label: "Notifications" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
                lineNumber: 207,
                columnNumber: 13
              }, this),
              onOpenApprovals && /* @__PURE__ */ jsxDEV(
                SidebarButton,
                {
                  onClick: onOpenApprovals,
                  label: "Approvals",
                  badge: pendingCount > 0 ? String(pendingCount) : void 0
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
                  lineNumber: 210,
                  columnNumber: 13
                },
                this
              ),
              onOpenStandup && /* @__PURE__ */ jsxDEV(SidebarButton, { onClick: onOpenStandup, label: "Standup" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
                lineNumber: 216,
                columnNumber: 31
              }, this),
              onOpenPolicy && /* @__PURE__ */ jsxDEV(SidebarButton, { onClick: onOpenPolicy, label: "Policy" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
                lineNumber: 217,
                columnNumber: 30
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
              lineNumber: 205,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-1.5", children: [
              onOpenOperatorControls && /* @__PURE__ */ jsxDEV(
                SidebarButton,
                {
                  onClick: onOpenOperatorControls,
                  label: "Controls",
                  variant: "warning",
                  fullWidth: true
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
                  lineNumber: 221,
                  columnNumber: 13
                },
                this
              ),
              onPauseSquad && /* @__PURE__ */ jsxDEV(SidebarButton, { onClick: onPauseSquad, label: "Pause squad", variant: "danger", fullWidth: true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
                lineNumber: 229,
                columnNumber: 13
              }, this),
              onResumeSquad && pausedCount > 0 && /* @__PURE__ */ jsxDEV(
                SidebarButton,
                {
                  onClick: onResumeSquad,
                  label: `Resume ${pausedCount} paused`,
                  variant: "success",
                  fullWidth: true
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
                  lineNumber: 232,
                  columnNumber: 13
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
              lineNumber: 219,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
            lineNumber: 201,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(ScrollArea, { className: "flex-1 min-h-0", children: /* @__PURE__ */ jsxDEV("div", { className: "py-1", children: agents === void 0 ? /* @__PURE__ */ jsxDEV("div", { className: "p-3 flex flex-col gap-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "h-3.5 animate-pulse rounded bg-surface-2" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
              lineNumber: 247,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "h-3.5 animate-pulse rounded bg-surface-2" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
              lineNumber: 248,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "h-3.5 animate-pulse rounded bg-surface-2" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
              lineNumber: 249,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
            lineNumber: 246,
            columnNumber: 13
          }, this) : agents.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "p-3 text-ink-muted text-[13px]", children: "No agents" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
            lineNumber: 252,
            columnNumber: 13
          }, this) : agents.map(
            (a) => /* @__PURE__ */ jsxDEV(
              AgentRow,
              {
                agent: a,
                onClick: () => setSelectedAgentId(a._id)
              },
              a._id,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
                lineNumber: 255,
                columnNumber: 13
              },
              this
            )
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
            lineNumber: 244,
            columnNumber: 11
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
            lineNumber: 243,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
        lineNumber: 175,
        columnNumber: 7
      },
      this
    ),
    selectedAgentId && /* @__PURE__ */ jsxDEV(
      AgentDetailFlyout,
      {
        agentId: selectedAgentId,
        onClose: () => setSelectedAgentId(null),
        onEdit: onOpenOrg
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
        lineNumber: 267,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx",
    lineNumber: 166,
    columnNumber: 5
  }, this);
}
_s(AgentsFlyout, "YGxZXz+lXeDr11NcCPx2FUCWLp8=", false, function() {
  return [useQuery, useQuery];
});
_c3 = AgentsFlyout;
var _c, _c2, _c3;
$RefreshReg$(_c, "SidebarButton");
$RefreshReg$(_c2, "AgentRow");
$RefreshReg$(_c3, "AgentsFlyout");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentsFlyout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENrQixTQXNHZCxVQXRHYzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE1Q2xCLFNBQVNBLFdBQVdDLFFBQVFDLGdCQUFnQjtBQUM1QyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsV0FBVztBQUVwQixTQUFTQyxTQUFTO0FBQ2xCLFNBQVNDLFVBQVU7QUFDbkIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyx5QkFBeUI7QUFFbEMsTUFBTUMsZUFBZTtBQUVyQixTQUFTQyxjQUFjO0FBQUEsRUFDckJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLFVBQVU7QUFBQSxFQUNWQyxZQUFZO0FBT2QsR0FBRztBQUNELFFBQU1DLGlCQUF5QztBQUFBLElBQzdDQyxTQUFTO0FBQUEsSUFDVEMsU0FBUztBQUFBLElBQ1RDLFFBQVE7QUFBQSxJQUNSQyxTQUFTO0FBQUEsRUFDWDtBQUVBLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE1BQUs7QUFBQSxNQUNMO0FBQUEsTUFDQSxXQUFXZjtBQUFBQSxRQUNUO0FBQUEsUUFDQVcsZUFBZUYsT0FBTztBQUFBLFFBQ3RCQyxZQUFZLFdBQVc7QUFBQSxNQUN6QjtBQUFBLE1BRUEsaUNBQUMsVUFBSyxXQUFVLDRDQUNiSDtBQUFBQTtBQUFBQSxRQUNBQyxTQUFTLHVCQUFDLGVBQVksTUFBSyxRQUFRQSxtQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQztBQUFBLFdBRjVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBO0FBQUEsSUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFhQTtBQUVKO0FBQUNRLEtBcENRWDtBQXNDVCxTQUFTWSxTQUFTO0FBQUEsRUFDaEJDO0FBQUFBLEVBQ0FaO0FBSUYsR0FBRztBQUNELFFBQU1hLFdBQVdELE1BQU1FLFdBQVc7QUFDbEMsUUFBTUMsY0FBY0YsV0FBVyxXQUFXO0FBQzFDLFFBQU1HLFlBQ0pKLE1BQU1LLFNBQVMsU0FDWCxTQUNBTCxNQUFNSyxTQUFTLGVBQ2IsUUFDQUwsTUFBTUssU0FBUyxXQUNiLFFBQ0FMLE1BQU1LO0FBRWhCLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE1BQUs7QUFBQSxNQUNMO0FBQUEsTUFDQSxXQUFVO0FBQUEsTUFDVixjQUFZLEdBQUdMLE1BQU1NLElBQUksS0FBS0YsU0FBUyxLQUFLRCxXQUFXO0FBQUEsTUFFdkQ7QUFBQSwrQkFBQyxVQUFLLFdBQVUsaUhBQ2JILGdCQUFNTyxTQUFTUCxNQUFNTSxLQUFLRSxPQUFPLENBQUMsS0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNkNBQTZDUixnQkFBTU0sUUFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUU7QUFBQSxVQUN2RSx1QkFBQyxTQUFJLFdBQVUsZ0NBQWdDRix1QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUQ7QUFBQSxhQUYzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFXdEI7QUFBQUEsY0FDVDtBQUFBLGNBQ0FtQixXQUFXLFVBQVU7QUFBQSxZQUN2QjtBQUFBLFlBQ0EsT0FBT0QsTUFBTUU7QUFBQUEsWUFDYixlQUFXO0FBQUE7QUFBQSxVQU5iO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1hO0FBQUE7QUFBQTtBQUFBLElBbkJmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQXFCQTtBQUVKO0FBQUNPLE1BMUNRVjtBQTRDRixnQkFBU1csYUFBYTtBQUFBLEVBQzNCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQVlGLEdBQUc7QUFBQUMsS0FBQTtBQUNELFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSTdDLFNBQThCLElBQUk7QUFDaEYsUUFBTThDLFdBQVcvQyxPQUEyQixJQUFJO0FBQ2hELFFBQU1nRCxpQkFBaUJoRCxPQUEyQixJQUFJO0FBQ3RELFFBQU1pRCxTQUFTL0MsU0FBU0MsSUFBSThDLE9BQU9DLFNBQVNoQixZQUFZLEVBQUVBLFVBQVUsSUFBSSxDQUFDLENBQUM7QUFDMUUsUUFBTWlCLG1CQUFtQmpELFNBQVNDLElBQUlpRCxVQUFVQyxhQUFhbkIsWUFBWSxFQUFFQSxXQUFXb0IsT0FBTyxHQUFHLElBQUksRUFBRUEsT0FBTyxHQUFHLENBQUM7QUFDakgsUUFBTUMsZUFBZUosa0JBQWtCSyxVQUFVO0FBQ2pELFFBQU1DLGFBQWFSLFFBQVFPLFVBQVU7QUFDckMsUUFBTUUsY0FBY1QsUUFBUVUsT0FBTyxDQUFDQyxNQUFNQSxFQUFFbkMsV0FBVyxRQUFRLEVBQUUrQixVQUFVO0FBRTNFekQsWUFBVSxNQUFNO0FBQ2QsVUFBTThELFlBQVlBLENBQUNDLFVBQXlCO0FBQzFDLFVBQUlBLE1BQU1DLFFBQVEsU0FBVTtBQUM1QixVQUFJbEIsaUJBQWlCO0FBQ25CQywyQkFBbUIsSUFBSTtBQUFBLE1BQ3pCLE9BQU87QUFDTFgsZ0JBQVE7QUFBQSxNQUNWO0FBQUEsSUFDRjtBQUNBNkIsV0FBT0MsaUJBQWlCLFdBQVdKLFNBQVM7QUFDNUMsV0FBTyxNQUFNRyxPQUFPRSxvQkFBb0IsV0FBV0wsU0FBUztBQUFBLEVBQzlELEdBQUcsQ0FBQzFCLFNBQVNVLGVBQWUsQ0FBQztBQUU3QjlDLFlBQVUsTUFBTTtBQUNkaUQsbUJBQWVtQixVQUFVQyxTQUFTQyx5QkFBeUJDLGNBQWNGLFNBQVNDLGdCQUFnQjtBQUNsR3RCLGFBQVNvQixTQUFTSSxNQUFNLEVBQUVDLGVBQWUsS0FBSyxDQUFDO0FBQy9DLFdBQU8sTUFBTXhCLGVBQWVtQixTQUFTSSxNQUFNLEVBQUVDLGVBQWUsS0FBSyxDQUFDO0FBQUEsRUFDcEUsR0FBRyxFQUFFO0FBRUwsU0FDRSxtQ0FFRTtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFVO0FBQUEsUUFDVjtBQUFBLFFBQ0EsU0FBU3JDO0FBQUFBO0FBQUFBLE1BSFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBR21CO0FBQUEsSUFJbkI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLEtBQUtZO0FBQUFBLFFBQ0wsV0FBVTtBQUFBLFFBQ1YsT0FBTyxFQUFFMEIsT0FBT2hFLGFBQWE7QUFBQSxRQUM3QixNQUFLO0FBQUEsUUFDTCxjQUFXO0FBQUEsUUFDWCxjQUFXO0FBQUEsUUFDWCxVQUFVO0FBQUEsUUFHVjtBQUFBLGlDQUFDLFNBQUksV0FBVSxtRUFDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSxzQ0FBb0Msc0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLGVBQVksTUFBSyxXQUFXZ0Qsd0JBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdDO0FBQUEsWUFDeEM7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU3RCO0FBQUFBLGdCQUNULFdBQVU7QUFBQSxnQkFDVixjQUFXO0FBQUEsZ0JBRVgsaUNBQUMsS0FBRSxXQUFVLGFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0I7QUFBQTtBQUFBLGNBTnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsNkVBQTJFLDZCQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsaUNBQ1pJO0FBQUFBLHFDQUNDLHVCQUFDLGlCQUFjLFNBQVNBLHFCQUFxQixPQUFNLG1CQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRTtBQUFBLGNBRW5FSCxtQkFDQztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTQTtBQUFBQSxrQkFDVCxPQUFNO0FBQUEsa0JBQ04sT0FBT21CLGVBQWUsSUFBSW1CLE9BQU9uQixZQUFZLElBQUlvQjtBQUFBQTtBQUFBQSxnQkFIbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRzZEO0FBQUEsY0FHOURuQyxpQkFBaUIsdUJBQUMsaUJBQWMsU0FBU0EsZUFBZSxPQUFNLGFBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNEO0FBQUEsY0FDdkVILGdCQUFnQix1QkFBQyxpQkFBYyxTQUFTQSxjQUFjLE9BQU0sWUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0Q7QUFBQSxpQkFadkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNaQztBQUFBQSx3Q0FDQztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTQTtBQUFBQSxrQkFDVCxPQUFNO0FBQUEsa0JBQ04sU0FBUTtBQUFBLGtCQUNSLFdBQVM7QUFBQTtBQUFBLGdCQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUlXO0FBQUEsY0FHWkcsZ0JBQ0MsdUJBQUMsaUJBQWMsU0FBU0EsY0FBYyxPQUFNLGVBQWMsU0FBUSxVQUFTLFdBQVMsUUFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0Y7QUFBQSxjQUVyRkMsaUJBQWlCZ0IsY0FBYyxLQUM5QjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTaEI7QUFBQUEsa0JBQ1QsT0FBTyxVQUFVZ0IsV0FBVztBQUFBLGtCQUM1QixTQUFRO0FBQUEsa0JBQ1IsV0FBUztBQUFBO0FBQUEsZ0JBSlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSVc7QUFBQSxpQkFqQmY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxlQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVDQTtBQUFBLFVBR0EsdUJBQUMsY0FBVyxXQUFVLGtCQUNwQixpQ0FBQyxTQUFJLFdBQVUsUUFDWlQscUJBQVcwQixTQUNWLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSw4Q0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RDtBQUFBLFlBQ3pELHVCQUFDLFNBQUksV0FBVSw4Q0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RDtBQUFBLFlBQ3pELHVCQUFDLFNBQUksV0FBVSw4Q0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RDtBQUFBLGVBSDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUEsSUFDRTFCLE9BQU9PLFdBQVcsSUFDcEIsdUJBQUMsU0FBSSxXQUFVLGtDQUFpQyx5QkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUQsSUFFekRQLE9BQU8yQjtBQUFBQSxZQUFJLENBQUNoQixNQUNWO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsT0FBT0E7QUFBQUEsZ0JBQ1AsU0FBUyxNQUFNZCxtQkFBbUJjLEVBQUVpQixHQUFHO0FBQUE7QUFBQSxjQUZsQ2pCLEVBQUVpQjtBQUFBQSxjQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHMkM7QUFBQSxVQUU1QyxLQWhCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBO0FBQUE7QUFBQSxNQXhGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF5RkE7QUFBQSxJQUVDaEMsbUJBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVNBO0FBQUFBLFFBQ1QsU0FBUyxNQUFNQyxtQkFBbUIsSUFBSTtBQUFBLFFBQ3RDLFFBQVFIO0FBQUFBO0FBQUFBLE1BSFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBR29CO0FBQUEsT0F4R3hCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyR0E7QUFFSjtBQUFDQyxHQWpLZVgsY0FBWTtBQUFBLFVBMEJYL0IsVUFDVUEsUUFBUTtBQUFBO0FBQUEsTUEzQm5CK0I7QUFBWSxJQUFBWixJQUFBVyxLQUFBOEM7QUFBQSxhQUFBekQsSUFBQTtBQUFBLGFBQUFXLEtBQUE7QUFBQSxhQUFBOEMsS0FBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVN0YXRlIiwidXNlUXVlcnkiLCJhcGkiLCJYIiwiY24iLCJTdGF0dXNCYWRnZSIsIlNjcm9sbEFyZWEiLCJBZ2VudERldGFpbEZseW91dCIsIkZMWU9VVF9XSURUSCIsIlNpZGViYXJCdXR0b24iLCJvbkNsaWNrIiwibGFiZWwiLCJiYWRnZSIsInZhcmlhbnQiLCJmdWxsV2lkdGgiLCJ2YXJpYW50Q2xhc3NlcyIsImRlZmF1bHQiLCJ3YXJuaW5nIiwiZGFuZ2VyIiwic3VjY2VzcyIsIl9jIiwiQWdlbnRSb3ciLCJhZ2VudCIsImlzQWN0aXZlIiwic3RhdHVzIiwic3RhdHVzTGFiZWwiLCJyb2xlU2hvcnQiLCJyb2xlIiwibmFtZSIsImVtb2ppIiwiY2hhckF0IiwiX2MyIiwiQWdlbnRzRmx5b3V0IiwicHJvamVjdElkIiwib25DbG9zZSIsIm9uT3BlbkFwcHJvdmFscyIsIm9uT3BlblBvbGljeSIsIm9uT3Blbk9wZXJhdG9yQ29udHJvbHMiLCJvbk9wZW5Ob3RpZmljYXRpb25zIiwib25PcGVuU3RhbmR1cCIsIm9uUGF1c2VTcXVhZCIsIm9uUmVzdW1lU3F1YWQiLCJvbk9wZW5PcmciLCJfcyIsInNlbGVjdGVkQWdlbnRJZCIsInNldFNlbGVjdGVkQWdlbnRJZCIsInBhbmVsUmVmIiwicmV0dXJuRm9jdXNSZWYiLCJhZ2VudHMiLCJsaXN0QWxsIiwicGVuZGluZ0FwcHJvdmFscyIsImFwcHJvdmFscyIsImxpc3RQZW5kaW5nIiwibGltaXQiLCJwZW5kaW5nQ291bnQiLCJsZW5ndGgiLCJhZ2VudENvdW50IiwicGF1c2VkQ291bnQiLCJmaWx0ZXIiLCJhIiwib25LZXlEb3duIiwiZXZlbnQiLCJrZXkiLCJ3aW5kb3ciLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsImN1cnJlbnQiLCJkb2N1bWVudCIsImFjdGl2ZUVsZW1lbnQiLCJIVE1MRWxlbWVudCIsImZvY3VzIiwicHJldmVudFNjcm9sbCIsIndpZHRoIiwiU3RyaW5nIiwidW5kZWZpbmVkIiwibWFwIiwiX2lkIiwiX2MzIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFnZW50c0ZseW91dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB0eXBlIHsgRG9jLCBJZCB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9kYXRhTW9kZWxcIjtcbmltcG9ydCB7IFggfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiO1xuaW1wb3J0IHsgU3RhdHVzQmFkZ2UgfSBmcm9tIFwiLi9jb21wb25lbnRzL2ZhY3RvcnkvYmFkZ2VzXCI7XG5pbXBvcnQgeyBTY3JvbGxBcmVhIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9zY3JvbGwtYXJlYVwiO1xuaW1wb3J0IHsgQWdlbnREZXRhaWxGbHlvdXQgfSBmcm9tIFwiLi9BZ2VudERldGFpbEZseW91dFwiO1xuXG5jb25zdCBGTFlPVVRfV0lEVEggPSAzMjA7XG5cbmZ1bmN0aW9uIFNpZGViYXJCdXR0b24oe1xuICBvbkNsaWNrLFxuICBsYWJlbCxcbiAgYmFkZ2UsXG4gIHZhcmlhbnQgPSBcImRlZmF1bHRcIixcbiAgZnVsbFdpZHRoID0gZmFsc2UsXG59OiB7XG4gIG9uQ2xpY2s6ICgpID0+IHZvaWQ7XG4gIGxhYmVsOiBzdHJpbmc7XG4gIGJhZGdlPzogc3RyaW5nO1xuICB2YXJpYW50PzogXCJkZWZhdWx0XCIgfCBcIndhcm5pbmdcIiB8IFwiZGFuZ2VyXCIgfCBcInN1Y2Nlc3NcIjtcbiAgZnVsbFdpZHRoPzogYm9vbGVhbjtcbn0pIHtcbiAgY29uc3QgdmFyaWFudENsYXNzZXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gICAgZGVmYXVsdDogXCJib3JkZXItbGluZSBiZy1zdXJmYWNlLTIgdGV4dC1pbmstc2Vjb25kYXJ5IGhvdmVyOnRleHQtaW5rIGhvdmVyOmJvcmRlci1saW5lLXN0cm9uZ1wiLFxuICAgIHdhcm5pbmc6IFwiYm9yZGVyLXRyYW5zcGFyZW50IGJnLXdhcm4tc29mdCB0ZXh0LXdhcm4gaG92ZXI6b3BhY2l0eS05MFwiLFxuICAgIGRhbmdlcjogXCJib3JkZXItdHJhbnNwYXJlbnQgYmctZXJyLXNvZnQgdGV4dC1lcnIgaG92ZXI6b3BhY2l0eS05MFwiLFxuICAgIHN1Y2Nlc3M6IFwiYm9yZGVyLXRyYW5zcGFyZW50IGJnLW9rLXNvZnQgdGV4dC1vayBob3ZlcjpvcGFjaXR5LTkwXCIsXG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8YnV0dG9uXG4gICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgIG9uQ2xpY2s9e29uQ2xpY2t9XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcInB4LTMgcHktMiByb3VuZGVkLWxnIHRleHQteHMgZm9udC1tZWRpdW0gYm9yZGVyIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBjdXJzb3ItcG9pbnRlclwiLFxuICAgICAgICB2YXJpYW50Q2xhc3Nlc1t2YXJpYW50XSxcbiAgICAgICAgZnVsbFdpZHRoID8gXCJ3LWZ1bGxcIiA6IFwiZmxleC0xIG1pbi13LTBcIlxuICAgICAgKX1cbiAgICA+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgIHtsYWJlbH1cbiAgICAgICAge2JhZGdlICYmIDxTdGF0dXNCYWRnZSB0b25lPVwiaW5mb1wiPntiYWRnZX08L1N0YXR1c0JhZGdlPn1cbiAgICAgIDwvc3Bhbj5cbiAgICA8L2J1dHRvbj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gQWdlbnRSb3coe1xuICBhZ2VudCxcbiAgb25DbGljayxcbn06IHtcbiAgYWdlbnQ6IERvYzxcImFnZW50c1wiPjtcbiAgb25DbGljazogKCkgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgaXNBY3RpdmUgPSBhZ2VudC5zdGF0dXMgPT09IFwiQUNUSVZFXCI7XG4gIGNvbnN0IHN0YXR1c0xhYmVsID0gaXNBY3RpdmUgPyBcIkFjdGl2ZVwiIDogXCJOb3QgYWN0aXZlXCI7XG4gIGNvbnN0IHJvbGVTaG9ydCA9XG4gICAgYWdlbnQucm9sZSA9PT0gXCJMRUFEXCJcbiAgICAgID8gXCJMZWFkXCJcbiAgICAgIDogYWdlbnQucm9sZSA9PT0gXCJTUEVDSUFMSVNUXCJcbiAgICAgICAgPyBcIlNwY1wiXG4gICAgICAgIDogYWdlbnQucm9sZSA9PT0gXCJJTlRFUk5cIlxuICAgICAgICAgID8gXCJJbnRcIlxuICAgICAgICAgIDogYWdlbnQucm9sZTtcblxuICByZXR1cm4gKFxuICAgIDxidXR0b25cbiAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgb25DbGljaz17b25DbGlja31cbiAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC0zIHB5LTIgdGV4dC1sZWZ0IGN1cnNvci1wb2ludGVyIGJvcmRlci0wIGJnLXRyYW5zcGFyZW50IGhvdmVyOmJnLXN1cmZhY2UtMiB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLXJpbmdcIlxuICAgICAgYXJpYS1sYWJlbD17YCR7YWdlbnQubmFtZX0sICR7cm9sZVNob3J0fSwgJHtzdGF0dXNMYWJlbH1gfVxuICAgID5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggdy04IGgtOCBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yIHRleHQtc20gdGV4dC1pbmtcIj5cbiAgICAgICAge2FnZW50LmVtb2ppIHx8IGFnZW50Lm5hbWUuY2hhckF0KDApfVxuICAgICAgPC9zcGFuPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtaW5rIHRydW5jYXRlXCI+e2FnZW50Lm5hbWV9PC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSB0ZXh0LWluay1tdXRlZFwiPntyb2xlU2hvcnR9PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxzcGFuXG4gICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgXCJ3LTIgaC0yIHJvdW5kZWQtZnVsbCBzaHJpbmstMFwiLFxuICAgICAgICAgIGlzQWN0aXZlID8gXCJiZy1va1wiIDogXCJiZy1pbmstbXV0ZWRcIlxuICAgICAgICApfVxuICAgICAgICB0aXRsZT17YWdlbnQuc3RhdHVzfVxuICAgICAgICBhcmlhLWhpZGRlblxuICAgICAgLz5cbiAgICA8L2J1dHRvbj5cbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEFnZW50c0ZseW91dCh7XG4gIHByb2plY3RJZCxcbiAgb25DbG9zZSxcbiAgb25PcGVuQXBwcm92YWxzLFxuICBvbk9wZW5Qb2xpY3ksXG4gIG9uT3Blbk9wZXJhdG9yQ29udHJvbHMsXG4gIG9uT3Blbk5vdGlmaWNhdGlvbnMsXG4gIG9uT3BlblN0YW5kdXAsXG4gIG9uUGF1c2VTcXVhZCxcbiAgb25SZXN1bWVTcXVhZCxcbiAgb25PcGVuT3JnLFxufToge1xuICBwcm9qZWN0SWQ6IElkPFwicHJvamVjdHNcIj4gfCBudWxsO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBvbk9wZW5BcHByb3ZhbHM/OiAoKSA9PiB2b2lkO1xuICBvbk9wZW5Qb2xpY3k/OiAoKSA9PiB2b2lkO1xuICBvbk9wZW5PcGVyYXRvckNvbnRyb2xzPzogKCkgPT4gdm9pZDtcbiAgb25PcGVuTm90aWZpY2F0aW9ucz86ICgpID0+IHZvaWQ7XG4gIG9uT3BlblN0YW5kdXA/OiAoKSA9PiB2b2lkO1xuICBvblBhdXNlU3F1YWQ/OiAoKSA9PiB2b2lkO1xuICBvblJlc3VtZVNxdWFkPzogKCkgPT4gdm9pZDtcbiAgb25PcGVuT3JnPzogKGFnZW50SWQ6IElkPFwiYWdlbnRzXCI+KSA9PiB2b2lkO1xufSkge1xuICBjb25zdCBbc2VsZWN0ZWRBZ2VudElkLCBzZXRTZWxlY3RlZEFnZW50SWRdID0gdXNlU3RhdGU8SWQ8XCJhZ2VudHNcIj4gfCBudWxsPihudWxsKTtcbiAgY29uc3QgcGFuZWxSZWYgPSB1c2VSZWY8SFRNTEVsZW1lbnQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgcmV0dXJuRm9jdXNSZWYgPSB1c2VSZWY8SFRNTEVsZW1lbnQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgYWdlbnRzID0gdXNlUXVlcnkoYXBpLmFnZW50cy5saXN0QWxsLCBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCB9IDoge30pO1xuICBjb25zdCBwZW5kaW5nQXBwcm92YWxzID0gdXNlUXVlcnkoYXBpLmFwcHJvdmFscy5saXN0UGVuZGluZywgcHJvamVjdElkID8geyBwcm9qZWN0SWQsIGxpbWl0OiAxMCB9IDogeyBsaW1pdDogMTAgfSk7XG4gIGNvbnN0IHBlbmRpbmdDb3VudCA9IHBlbmRpbmdBcHByb3ZhbHM/Lmxlbmd0aCA/PyAwO1xuICBjb25zdCBhZ2VudENvdW50ID0gYWdlbnRzPy5sZW5ndGggPz8gMDtcbiAgY29uc3QgcGF1c2VkQ291bnQgPSBhZ2VudHM/LmZpbHRlcigoYSkgPT4gYS5zdGF0dXMgPT09IFwiUEFVU0VEXCIpLmxlbmd0aCA/PyAwO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3Qgb25LZXlEb3duID0gKGV2ZW50OiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBpZiAoZXZlbnQua2V5ICE9PSBcIkVzY2FwZVwiKSByZXR1cm47XG4gICAgICBpZiAoc2VsZWN0ZWRBZ2VudElkKSB7XG4gICAgICAgIHNldFNlbGVjdGVkQWdlbnRJZChudWxsKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG9uQ2xvc2UoKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBvbktleURvd24pO1xuICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgb25LZXlEb3duKTtcbiAgfSwgW29uQ2xvc2UsIHNlbGVjdGVkQWdlbnRJZF0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgcmV0dXJuRm9jdXNSZWYuY3VycmVudCA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCA/IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgOiBudWxsO1xuICAgIHBhbmVsUmVmLmN1cnJlbnQ/LmZvY3VzKHsgcHJldmVudFNjcm9sbDogdHJ1ZSB9KTtcbiAgICByZXR1cm4gKCkgPT4gcmV0dXJuRm9jdXNSZWYuY3VycmVudD8uZm9jdXMoeyBwcmV2ZW50U2Nyb2xsOiB0cnVlIH0pO1xuICB9LCBbXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgey8qIEJhY2tkcm9wICovfVxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNDAgYmctYmxhY2svNDBcIlxuICAgICAgICBhcmlhLWhpZGRlblxuICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgLz5cblxuICAgICAgey8qIEZseS1vdXQgcGFuZWwgKi99XG4gICAgICA8YXNpZGVcbiAgICAgICAgcmVmPXtwYW5lbFJlZn1cbiAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgdG9wLTAgbGVmdC0wIGJvdHRvbS0wIHotNTAgZmxleCBmbGV4LWNvbCBib3JkZXItciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgYW5pbWF0ZS1pbiBzbGlkZS1pbi1mcm9tLWxlZnQgZHVyYXRpb24tMjAwXCJcbiAgICAgICAgc3R5bGU9e3sgd2lkdGg6IEZMWU9VVF9XSURUSCB9fVxuICAgICAgICByb2xlPVwiZGlhbG9nXCJcbiAgICAgICAgYXJpYS1tb2RhbD1cInRydWVcIlxuICAgICAgICBhcmlhLWxhYmVsPVwiQWdlbnRzIHBhbmVsXCJcbiAgICAgICAgdGFiSW5kZXg9ey0xfVxuICAgICAgPlxuICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMyBzaHJpbmstMCBib3JkZXItYiBib3JkZXItbGluZVwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1bMTNweF0gdGV4dC1pbmtcIj5cbiAgICAgICAgICAgIEFnZW50c1xuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8U3RhdHVzQmFkZ2UgdG9uZT1cIm5ldXRyYWxcIj57YWdlbnRDb3VudH08L1N0YXR1c0JhZGdlPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLWF1dG8gcC0xLjUgcm91bmRlZC1tZCB0ZXh0LWluay1tdXRlZCBob3Zlcjp0ZXh0LWluayBob3ZlcjpiZy1zdXJmYWNlLTIgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJDbG9zZSBhZ2VudHMgcGFuZWxcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogUXVpY2sgQWN0aW9ucyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC0zIHB5LTMgc2hyaW5rLTAgYm9yZGVyLWIgYm9yZGVyLWxpbmVcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExLjVweF0gZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjA2ZW1dIHRleHQtaW5rLW11dGVkIG1iLTJcIj5cbiAgICAgICAgICAgIFF1aWNrIEFjdGlvbnNcbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTEuNSBtYi0yXCI+XG4gICAgICAgICAgICB7b25PcGVuTm90aWZpY2F0aW9ucyAmJiAoXG4gICAgICAgICAgICAgIDxTaWRlYmFyQnV0dG9uIG9uQ2xpY2s9e29uT3Blbk5vdGlmaWNhdGlvbnN9IGxhYmVsPVwiTm90aWZpY2F0aW9uc1wiIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAge29uT3BlbkFwcHJvdmFscyAmJiAoXG4gICAgICAgICAgICAgIDxTaWRlYmFyQnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25PcGVuQXBwcm92YWxzfVxuICAgICAgICAgICAgICAgIGxhYmVsPVwiQXBwcm92YWxzXCJcbiAgICAgICAgICAgICAgICBiYWRnZT17cGVuZGluZ0NvdW50ID4gMCA/IFN0cmluZyhwZW5kaW5nQ291bnQpIDogdW5kZWZpbmVkfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHtvbk9wZW5TdGFuZHVwICYmIDxTaWRlYmFyQnV0dG9uIG9uQ2xpY2s9e29uT3BlblN0YW5kdXB9IGxhYmVsPVwiU3RhbmR1cFwiIC8+fVxuICAgICAgICAgICAge29uT3BlblBvbGljeSAmJiA8U2lkZWJhckJ1dHRvbiBvbkNsaWNrPXtvbk9wZW5Qb2xpY3l9IGxhYmVsPVwiUG9saWN5XCIgLz59XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xLjVcIj5cbiAgICAgICAgICAgIHtvbk9wZW5PcGVyYXRvckNvbnRyb2xzICYmIChcbiAgICAgICAgICAgICAgPFNpZGViYXJCdXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbk9wZW5PcGVyYXRvckNvbnRyb2xzfVxuICAgICAgICAgICAgICAgIGxhYmVsPVwiQ29udHJvbHNcIlxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJ3YXJuaW5nXCJcbiAgICAgICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICB7b25QYXVzZVNxdWFkICYmIChcbiAgICAgICAgICAgICAgPFNpZGViYXJCdXR0b24gb25DbGljaz17b25QYXVzZVNxdWFkfSBsYWJlbD1cIlBhdXNlIHNxdWFkXCIgdmFyaWFudD1cImRhbmdlclwiIGZ1bGxXaWR0aCAvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHtvblJlc3VtZVNxdWFkICYmIHBhdXNlZENvdW50ID4gMCAmJiAoXG4gICAgICAgICAgICAgIDxTaWRlYmFyQnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25SZXN1bWVTcXVhZH1cbiAgICAgICAgICAgICAgICBsYWJlbD17YFJlc3VtZSAke3BhdXNlZENvdW50fSBwYXVzZWRgfVxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJzdWNjZXNzXCJcbiAgICAgICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBBZ2VudCBMaXN0ICovfVxuICAgICAgICA8U2Nyb2xsQXJlYSBjbGFzc05hbWU9XCJmbGV4LTEgbWluLWgtMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMVwiPlxuICAgICAgICAgICAge2FnZW50cyA9PT0gdW5kZWZpbmVkID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBmbGV4IGZsZXgtY29sIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTMuNSBhbmltYXRlLXB1bHNlIHJvdW5kZWQgYmctc3VyZmFjZS0yXCIgLz5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMy41IGFuaW1hdGUtcHVsc2Ugcm91bmRlZCBiZy1zdXJmYWNlLTJcIiAvPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0zLjUgYW5pbWF0ZS1wdWxzZSByb3VuZGVkIGJnLXN1cmZhY2UtMlwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IGFnZW50cy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHRleHQtaW5rLW11dGVkIHRleHQtWzEzcHhdXCI+Tm8gYWdlbnRzPC9kaXY+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICBhZ2VudHMubWFwKChhOiBEb2M8XCJhZ2VudHNcIj4pID0+IChcbiAgICAgICAgICAgICAgICA8QWdlbnRSb3dcbiAgICAgICAgICAgICAgICAgIGtleT17YS5faWR9XG4gICAgICAgICAgICAgICAgICBhZ2VudD17YX1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkQWdlbnRJZChhLl9pZCl9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgKSlcbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvU2Nyb2xsQXJlYT5cbiAgICAgIDwvYXNpZGU+XG5cbiAgICAgIHtzZWxlY3RlZEFnZW50SWQgJiYgKFxuICAgICAgICA8QWdlbnREZXRhaWxGbHlvdXRcbiAgICAgICAgICBhZ2VudElkPXtzZWxlY3RlZEFnZW50SWR9XG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2VsZWN0ZWRBZ2VudElkKG51bGwpfVxuICAgICAgICAgIG9uRWRpdD17b25PcGVuT3JnfVxuICAgICAgICAvPlxuICAgICAgKX1cbiAgICA8Lz5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL0FnZW50c0ZseW91dC50c3gifQ==