import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/tasks/VerificationTracePanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { CheckCircle2, Circle, XCircle } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { cn } from "/src/lib/utils.ts";
function StatusIcon({ status }) {
  switch (status) {
    case "pass":
      return /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-4 w-4 text-ok shrink-0", strokeWidth: 1.75 }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
        lineNumber: 27,
        columnNumber: 14
      }, this);
    case "fail":
      return /* @__PURE__ */ jsxDEV(XCircle, { className: "h-4 w-4 text-err shrink-0", strokeWidth: 1.75 }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
        lineNumber: 29,
        columnNumber: 14
      }, this);
    case "pending":
      return /* @__PURE__ */ jsxDEV(Circle, { className: "h-4 w-4 text-warn shrink-0", strokeWidth: 1.75 }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
        lineNumber: 31,
        columnNumber: 14
      }, this);
    case "na":
      return /* @__PURE__ */ jsxDEV(Circle, { className: "h-4 w-4 text-ink-muted shrink-0", strokeWidth: 1.75 }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
        lineNumber: 33,
        columnNumber: 14
      }, this);
    default: {
      const _exhaustive = status;
      return _exhaustive;
    }
  }
}
_c = StatusIcon;
function statusLabel(status) {
  switch (status) {
    case "pass":
      return "Pass";
    case "fail":
      return "Fail";
    case "pending":
      return "Pending";
    case "na":
      return "N/A";
    default: {
      const _exhaustive = status;
      return _exhaustive;
    }
  }
}
export function VerificationTracePanel({ trace }) {
  const { outcome, criteria, evidence, summary } = trace;
  const verdict = summary.fail > 0 ? "fail" : summary.pending > 0 ? "pending" : summary.pass > 0 ? "pass" : "pending";
  return /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-line bg-surface-2 overflow-hidden", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-3 px-4 py-3 border-b border-line bg-surface-1", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-semibold uppercase tracking-wide text-ink-muted", children: "Outcome & proof" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
          lineNumber: 67,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-ink mt-1 leading-relaxed", children: outcome }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
          lineNumber: 68,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
        lineNumber: 66,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: cn(
            "shrink-0 inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-[11px] font-semibold uppercase",
            verdict === "pass" && "bg-ok-soft text-ok",
            verdict === "fail" && "bg-err-soft text-err",
            verdict === "pending" && "bg-warn-soft text-warn"
          ),
          children: [
            /* @__PURE__ */ jsxDEV(StatusIcon, { status: verdict }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
              lineNumber: 78,
              columnNumber: 11
            }, this),
            verdict === "pass" ? "Verified" : verdict === "fail" ? "Failed" : "In progress"
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
          lineNumber: 70,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
      lineNumber: 65,
      columnNumber: 7
    }, this),
    criteria.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 border-b border-line", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-semibold uppercase tracking-wide text-ink-muted mb-2", children: "Acceptance criteria" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
        lineNumber: 85,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2", children: criteria.map(
        (item, index) => /* @__PURE__ */ jsxDEV("li", { className: "flex items-start gap-2 text-sm", children: [
          /* @__PURE__ */ jsxDEV(StatusIcon, { status: item.status }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
            lineNumber: 91,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-ink-secondary", children: item.label }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
              lineNumber: 93,
              columnNumber: 19
            }, this),
            item.note && /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-ink-muted mt-0.5", children: item.note }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
              lineNumber: 94,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
            lineNumber: 92,
            columnNumber: 17
          }, this)
        ] }, index, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
          lineNumber: 90,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
        lineNumber: 88,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
      lineNumber: 84,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-semibold uppercase tracking-wide text-ink-muted mb-2", children: "Evidence" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
        lineNumber: 103,
        columnNumber: 9
      }, this),
      evidence.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-ink-muted", children: "No runs or approvals recorded yet." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
        lineNumber: 105,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2", children: evidence.map(
        (row) => /* @__PURE__ */ jsxDEV("li", { className: "flex items-start gap-2 text-sm", children: [
          /* @__PURE__ */ jsxDEV(StatusIcon, { status: row.status }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
            lineNumber: 110,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-2", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-ink truncate", children: row.label }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
                lineNumber: 113,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-medium uppercase text-ink-muted shrink-0", children: statusLabel(row.status) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
                lineNumber: 114,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
              lineNumber: 112,
              columnNumber: 19
            }, this),
            row.detail && /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-ink-muted mt-0.5 truncate", children: row.detail }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
              lineNumber: 119,
              columnNumber: 15
            }, this),
            row.at != null && /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] text-ink-muted mt-0.5", children: new Date(row.at).toLocaleString() }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
              lineNumber: 122,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
            lineNumber: 111,
            columnNumber: 17
          }, this)
        ] }, row.id, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
          lineNumber: 109,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
        lineNumber: 107,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
      lineNumber: 102,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx",
    lineNumber: 64,
    columnNumber: 5
  }, this);
}
_c2 = VerificationTracePanel;
var _c, _c2;
$RefreshReg$(_c, "StatusIcon");
$RefreshReg$(_c2, "VerificationTracePanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/tasks/VerificationTracePanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT2E7Ozs7Ozs7Ozs7Ozs7Ozs7QUFQYixTQUFTQSxjQUFjQyxRQUFRQyxlQUFlO0FBQzlDLFNBQVNDLFVBQVU7QUFHbkIsU0FBU0MsV0FBVyxFQUFFQyxPQUF1QyxHQUFHO0FBQzlELFVBQVFBLFFBQU07QUFBQSxJQUNaLEtBQUs7QUFDSCxhQUFPLHVCQUFDLGdCQUFhLFdBQVUsNEJBQTJCLGFBQWEsUUFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRTtBQUFBLElBQzlFLEtBQUs7QUFDSCxhQUFPLHVCQUFDLFdBQVEsV0FBVSw2QkFBNEIsYUFBYSxRQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlFO0FBQUEsSUFDMUUsS0FBSztBQUNILGFBQU8sdUJBQUMsVUFBTyxXQUFVLDhCQUE2QixhQUFhLFFBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUU7QUFBQSxJQUMxRSxLQUFLO0FBQ0gsYUFBTyx1QkFBQyxVQUFPLFdBQVUsbUNBQWtDLGFBQWEsUUFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRTtBQUFBLElBQy9FLFNBQVM7QUFDUCxZQUFNQyxjQUFxQkQ7QUFDM0IsYUFBT0M7QUFBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDRjtBQUFDQyxLQWZRSDtBQWlCVCxTQUFTSSxZQUFZSCxRQUFvQztBQUN2RCxVQUFRQSxRQUFNO0FBQUEsSUFDWixLQUFLO0FBQ0gsYUFBTztBQUFBLElBQ1QsS0FBSztBQUNILGFBQU87QUFBQSxJQUNULEtBQUs7QUFDSCxhQUFPO0FBQUEsSUFDVCxLQUFLO0FBQ0gsYUFBTztBQUFBLElBQ1QsU0FBUztBQUNQLFlBQU1DLGNBQXFCRDtBQUMzQixhQUFPQztBQUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNGO0FBRU8sZ0JBQVNHLHVCQUF1QixFQUFFQyxNQUFvQyxHQUFHO0FBQzlFLFFBQU0sRUFBRUMsU0FBU0MsVUFBVUMsVUFBVUMsUUFBUSxJQUFJSjtBQUNqRCxRQUFNSyxVQUNKRCxRQUFRRSxPQUFPLElBQUksU0FBU0YsUUFBUUcsVUFBVSxJQUFJLFlBQVlILFFBQVFJLE9BQU8sSUFBSSxTQUFTO0FBRTVGLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDhEQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHNGQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSwrQkFBQyxPQUFFLFdBQVUsb0VBQW1FLCtCQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStGO0FBQUEsUUFDL0YsdUJBQUMsT0FBRSxXQUFVLHlDQUF5Q1AscUJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEQ7QUFBQSxXQUZoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFXUjtBQUFBQSxZQUNUO0FBQUEsWUFDQVksWUFBWSxVQUFVO0FBQUEsWUFDdEJBLFlBQVksVUFBVTtBQUFBLFlBQ3RCQSxZQUFZLGFBQWE7QUFBQSxVQUMzQjtBQUFBLFVBRUE7QUFBQSxtQ0FBQyxjQUFXLFFBQVFBLFdBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRCO0FBQUEsWUFDM0JBLFlBQVksU0FBUyxhQUFhQSxZQUFZLFNBQVMsV0FBVztBQUFBO0FBQUE7QUFBQSxRQVRyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFVQTtBQUFBLFNBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLElBRUNILFNBQVNPLFNBQVMsS0FDakIsdUJBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEsNkJBQUMsT0FBRSxXQUFVLHlFQUF1RSxtQ0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxRQUFHLFdBQVUsYUFDWFAsbUJBQVNRO0FBQUFBLFFBQUksQ0FBQ0MsTUFBTUMsVUFDbkIsdUJBQUMsUUFBZSxXQUFVLGtDQUN4QjtBQUFBLGlDQUFDLGNBQVcsUUFBUUQsS0FBS2hCLFVBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUEsVUFDaEMsdUJBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsc0JBQXNCZ0IsZUFBS0UsU0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEM7QUFBQSxZQUM3Q0YsS0FBS0csUUFBUSx1QkFBQyxPQUFFLFdBQVUsaUNBQWlDSCxlQUFLRyxRQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RDtBQUFBLGVBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQUxPRixPQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLE1BQ0QsS0FUSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxTQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLElBR0YsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSw2QkFBQyxPQUFFLFdBQVUseUVBQXdFLHdCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZGO0FBQUEsTUFDNUZULFNBQVNNLFdBQVcsSUFDbkIsdUJBQUMsT0FBRSxXQUFVLDBCQUF5QixrREFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RSxJQUV4RSx1QkFBQyxRQUFHLFdBQVUsYUFDWE4sbUJBQVNPO0FBQUFBLFFBQUksQ0FBQ0ssUUFDYix1QkFBQyxRQUFnQixXQUFVLGtDQUN6QjtBQUFBLGlDQUFDLGNBQVcsUUFBUUEsSUFBSXBCLFVBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStCO0FBQUEsVUFDL0IsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsT0FBRSxXQUFVLHFCQUFxQm9CLGNBQUlGLFNBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRDO0FBQUEsY0FDNUMsdUJBQUMsVUFBSyxXQUFVLDZEQUNiZixzQkFBWWlCLElBQUlwQixNQUFNLEtBRHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQ29CLElBQUlDLFVBQ0gsdUJBQUMsT0FBRSxXQUFVLDBDQUEwQ0QsY0FBSUMsVUFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0U7QUFBQSxZQUVuRUQsSUFBSUUsTUFBTSxRQUNULHVCQUFDLE9BQUUsV0FBVSxxQ0FDVixjQUFJQyxLQUFLSCxJQUFJRSxFQUFFLEVBQUVFLGVBQWUsS0FEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLGFBakJPSixJQUFJSyxJQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxNQUNELEtBckJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQkE7QUFBQSxTQTNCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkJBO0FBQUEsT0FuRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9FQTtBQUVKO0FBQUNDLE1BNUVldEI7QUFBc0IsSUFBQUYsSUFBQXdCO0FBQUEsYUFBQXhCLElBQUE7QUFBQSxhQUFBd0IsS0FBQSIsIm5hbWVzIjpbIkNoZWNrQ2lyY2xlMiIsIkNpcmNsZSIsIlhDaXJjbGUiLCJjbiIsIlN0YXR1c0ljb24iLCJzdGF0dXMiLCJfZXhoYXVzdGl2ZSIsIl9jIiwic3RhdHVzTGFiZWwiLCJWZXJpZmljYXRpb25UcmFjZVBhbmVsIiwidHJhY2UiLCJvdXRjb21lIiwiY3JpdGVyaWEiLCJldmlkZW5jZSIsInN1bW1hcnkiLCJ2ZXJkaWN0IiwiZmFpbCIsInBlbmRpbmciLCJwYXNzIiwibGVuZ3RoIiwibWFwIiwiaXRlbSIsImluZGV4IiwibGFiZWwiLCJub3RlIiwicm93IiwiZGV0YWlsIiwiYXQiLCJEYXRlIiwidG9Mb2NhbGVTdHJpbmciLCJpZCIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJWZXJpZmljYXRpb25UcmFjZVBhbmVsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDaGVja0NpcmNsZTIsIENpcmNsZSwgWENpcmNsZSB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5pbXBvcnQgdHlwZSB7IFZlcmlmaWNhdGlvblN0YXR1cywgVmVyaWZpY2F0aW9uVHJhY2UgfSBmcm9tIFwiQC9saWIvdmVyaWZpY2F0aW9uVHJhY2VcIjtcblxuZnVuY3Rpb24gU3RhdHVzSWNvbih7IHN0YXR1cyB9OiB7IHN0YXR1czogVmVyaWZpY2F0aW9uU3RhdHVzIH0pIHtcbiAgc3dpdGNoIChzdGF0dXMpIHtcbiAgICBjYXNlIFwicGFzc1wiOlxuICAgICAgcmV0dXJuIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LW9rIHNocmluay0wXCIgc3Ryb2tlV2lkdGg9ezEuNzV9IC8+O1xuICAgIGNhc2UgXCJmYWlsXCI6XG4gICAgICByZXR1cm4gPFhDaXJjbGUgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWVyciBzaHJpbmstMFwiIHN0cm9rZVdpZHRoPXsxLjc1fSAvPjtcbiAgICBjYXNlIFwicGVuZGluZ1wiOlxuICAgICAgcmV0dXJuIDxDaXJjbGUgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LXdhcm4gc2hyaW5rLTBcIiBzdHJva2VXaWR0aD17MS43NX0gLz47XG4gICAgY2FzZSBcIm5hXCI6XG4gICAgICByZXR1cm4gPENpcmNsZSBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtaW5rLW11dGVkIHNocmluay0wXCIgc3Ryb2tlV2lkdGg9ezEuNzV9IC8+O1xuICAgIGRlZmF1bHQ6IHtcbiAgICAgIGNvbnN0IF9leGhhdXN0aXZlOiBuZXZlciA9IHN0YXR1cztcbiAgICAgIHJldHVybiBfZXhoYXVzdGl2ZTtcbiAgICB9XG4gIH1cbn1cblxuZnVuY3Rpb24gc3RhdHVzTGFiZWwoc3RhdHVzOiBWZXJpZmljYXRpb25TdGF0dXMpOiBzdHJpbmcge1xuICBzd2l0Y2ggKHN0YXR1cykge1xuICAgIGNhc2UgXCJwYXNzXCI6XG4gICAgICByZXR1cm4gXCJQYXNzXCI7XG4gICAgY2FzZSBcImZhaWxcIjpcbiAgICAgIHJldHVybiBcIkZhaWxcIjtcbiAgICBjYXNlIFwicGVuZGluZ1wiOlxuICAgICAgcmV0dXJuIFwiUGVuZGluZ1wiO1xuICAgIGNhc2UgXCJuYVwiOlxuICAgICAgcmV0dXJuIFwiTi9BXCI7XG4gICAgZGVmYXVsdDoge1xuICAgICAgY29uc3QgX2V4aGF1c3RpdmU6IG5ldmVyID0gc3RhdHVzO1xuICAgICAgcmV0dXJuIF9leGhhdXN0aXZlO1xuICAgIH1cbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gVmVyaWZpY2F0aW9uVHJhY2VQYW5lbCh7IHRyYWNlIH06IHsgdHJhY2U6IFZlcmlmaWNhdGlvblRyYWNlIH0pIHtcbiAgY29uc3QgeyBvdXRjb21lLCBjcml0ZXJpYSwgZXZpZGVuY2UsIHN1bW1hcnkgfSA9IHRyYWNlO1xuICBjb25zdCB2ZXJkaWN0ID1cbiAgICBzdW1tYXJ5LmZhaWwgPiAwID8gXCJmYWlsXCIgOiBzdW1tYXJ5LnBlbmRpbmcgPiAwID8gXCJwZW5kaW5nXCIgOiBzdW1tYXJ5LnBhc3MgPiAwID8gXCJwYXNzXCIgOiBcInBlbmRpbmdcIjtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtMyBweC00IHB5LTMgYm9yZGVyLWIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1pbmstbXV0ZWRcIj5PdXRjb21lICYgcHJvb2Y8L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWluayBtdC0xIGxlYWRpbmctcmVsYXhlZFwiPntvdXRjb21lfTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgXCJzaHJpbmstMCBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLW1kIHB4LTIgcHktMSB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZVwiLFxuICAgICAgICAgICAgdmVyZGljdCA9PT0gXCJwYXNzXCIgJiYgXCJiZy1vay1zb2Z0IHRleHQtb2tcIixcbiAgICAgICAgICAgIHZlcmRpY3QgPT09IFwiZmFpbFwiICYmIFwiYmctZXJyLXNvZnQgdGV4dC1lcnJcIixcbiAgICAgICAgICAgIHZlcmRpY3QgPT09IFwicGVuZGluZ1wiICYmIFwiYmctd2Fybi1zb2Z0IHRleHQtd2FyblwiLFxuICAgICAgICAgICl9XG4gICAgICAgID5cbiAgICAgICAgICA8U3RhdHVzSWNvbiBzdGF0dXM9e3ZlcmRpY3R9IC8+XG4gICAgICAgICAge3ZlcmRpY3QgPT09IFwicGFzc1wiID8gXCJWZXJpZmllZFwiIDogdmVyZGljdCA9PT0gXCJmYWlsXCIgPyBcIkZhaWxlZFwiIDogXCJJbiBwcm9ncmVzc1wifVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7Y3JpdGVyaWEubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS0zIGJvcmRlci1iIGJvcmRlci1saW5lXCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSB0ZXh0LWluay1tdXRlZCBtYi0yXCI+XG4gICAgICAgICAgICBBY2NlcHRhbmNlIGNyaXRlcmlhXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgIHtjcml0ZXJpYS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgIDxsaSBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICA8U3RhdHVzSWNvbiBzdGF0dXM9e2l0ZW0uc3RhdHVzfSAvPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1pbmstc2Vjb25kYXJ5XCI+e2l0ZW0ubGFiZWx9PC9wPlxuICAgICAgICAgICAgICAgICAge2l0ZW0ubm90ZSAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtaW5rLW11dGVkIG10LTAuNVwiPntpdGVtLm5vdGV9PC9wPn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvdWw+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC00IHB5LTNcIj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSB0ZXh0LWluay1tdXRlZCBtYi0yXCI+RXZpZGVuY2U8L3A+XG4gICAgICAgIHtldmlkZW5jZS5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWluay1tdXRlZFwiPk5vIHJ1bnMgb3IgYXBwcm92YWxzIHJlY29yZGVkIHlldC48L3A+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAge2V2aWRlbmNlLm1hcCgocm93KSA9PiAoXG4gICAgICAgICAgICAgIDxsaSBrZXk9e3Jvdy5pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMiB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgPFN0YXR1c0ljb24gc3RhdHVzPXtyb3cuc3RhdHVzfSAvPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtaW5rIHRydW5jYXRlXCI+e3Jvdy5sYWJlbH08L3A+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0ZXh0LWluay1tdXRlZCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtzdGF0dXNMYWJlbChyb3cuc3RhdHVzKX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICB7cm93LmRldGFpbCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1pbmstbXV0ZWQgbXQtMC41IHRydW5jYXRlXCI+e3Jvdy5kZXRhaWx9PC9wPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIHtyb3cuYXQgIT0gbnVsbCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtaW5rLW11dGVkIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShyb3cuYXQpLnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L3VsPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9jb21wb25lbnRzL3Rhc2tzL1ZlcmlmaWNhdGlvblRyYWNlUGFuZWwudHN4In0=