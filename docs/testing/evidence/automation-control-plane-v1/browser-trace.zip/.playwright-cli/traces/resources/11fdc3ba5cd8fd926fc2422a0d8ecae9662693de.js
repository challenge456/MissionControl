import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/MissionSuggestionsDrawer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useAction } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { Plus, Sparkles, CheckCircle2, Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { Badge } from "/src/components/ui/badge.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Card } from "/src/components/ui/card.tsx";
import { ScrollArea } from "/src/components/ui/scroll-area.tsx";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle
} from "/src/components/ui/sheet.tsx";
const PRIORITY_LABELS = {
  1: { label: "Critical", classes: "text-err" },
  2: { label: "High", classes: "text-warn" },
  3: { label: "Normal", classes: "text-ink-secondary" },
  4: { label: "Low", classes: "text-ink-muted" }
};
const TYPE_BADGE_CLASSES = "border-line bg-surface-2 text-ink-secondary";
export function MissionSuggestionsDrawer({ projectId, onClose }) {
  _s();
  const [suggestions, setSuggestions] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [createdTasks, setCreatedTasks] = useState(/* @__PURE__ */ new Set());
  const [error, setError] = useState(null);
  const reversePrompt = useAction(api.mission.reversePrompt);
  const createTask = useMutation(api.tasks.create);
  const handleGenerate = async () => {
    setIsGenerating(true);
    setError(null);
    setSuggestions([]);
    try {
      const result = await reversePrompt({
        projectId: projectId ?? void 0,
        autoCreate: false,
        maxSuggestions: 3
      });
      setSuggestions(result.suggestions);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to generate suggestions");
    } finally {
      setIsGenerating(false);
    }
  };
  const handleCreateTask = async (suggestion, index) => {
    try {
      await createTask({
        projectId: projectId ?? void 0,
        title: suggestion.title,
        description: `${suggestion.description}

**Mission Alignment:** ${suggestion.reasoning}`,
        type: suggestion.type,
        priority: suggestion.priority,
        source: "MISSION_PROMPT"
      });
      setCreatedTasks((prev) => new Set(prev).add(index));
    } catch (err) {
      console.error("Failed to create task:", err);
    }
  };
  const handleCreateAll = async () => {
    for (let i = 0; i < suggestions.length; i++) {
      if (!createdTasks.has(i)) {
        await handleCreateTask(suggestions[i], i);
      }
    }
  };
  useEffect(() => {
    void handleGenerate();
  }, []);
  return /* @__PURE__ */ jsxDEV(Sheet, { open: true, onOpenChange: (open) => {
    if (!open) onClose();
  }, children: /* @__PURE__ */ jsxDEV(SheetContent, { side: "right", className: "w-[620px] max-w-[92vw] p-0", children: /* @__PURE__ */ jsxDEV("div", { className: "flex h-full flex-col", children: [
    /* @__PURE__ */ jsxDEV(SheetHeader, { className: "border-b border-border px-6 py-4 text-left", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV(Sparkles, { className: "h-4 w-4 text-ink-secondary", strokeWidth: 1.75 }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
        lineNumber: 132,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV(SheetTitle, { children: "Mission-Aligned Tasks" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
          lineNumber: 134,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(SheetDescription, { children: "Suggested tasks to move current mission goals forward." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
          lineNumber: 135,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
        lineNumber: 133,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
      lineNumber: 131,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
      lineNumber: 130,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(ScrollArea, { className: "flex-1", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 px-6 py-5", children: [
      isGenerating && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center py-12 text-center", children: [
        /* @__PURE__ */ jsxDEV(Loader2, { className: "mb-4 h-8 w-8 animate-spin text-primary" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
          lineNumber: 146,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "Generating mission-aligned task suggestions..." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
          lineNumber: 147,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
        lineNumber: 145,
        columnNumber: 15
      }, this),
      error && /* @__PURE__ */ jsxDEV(Card, { className: "border-destructive/30 bg-destructive/5 p-4", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-destructive", children: error }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
          lineNumber: 155,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "link",
            size: "sm",
            className: "mt-1 h-auto p-0 text-destructive",
            onClick: handleGenerate,
            children: "Try again"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
            lineNumber: 156,
            columnNumber: 19
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
        lineNumber: 154,
        columnNumber: 15
      }, this),
      !isGenerating && suggestions.length === 0 && !error && /* @__PURE__ */ jsxDEV(Card, { className: "p-8 text-center", children: [
        /* @__PURE__ */ jsxDEV(Sparkles, { className: "mx-auto mb-3 h-10 w-10 text-muted-foreground/50" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
          lineNumber: 169,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mb-4 text-sm text-muted-foreground", children: "No suggestions available yet." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
          lineNumber: 170,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { size: "sm", onClick: handleGenerate, children: "Generate Suggestions" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
          lineNumber: 171,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
        lineNumber: 168,
        columnNumber: 15
      }, this),
      !isGenerating && suggestions.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: suggestions.map((suggestion, index) => {
        const isCreated = createdTasks.has(index);
        const priorityInfo = PRIORITY_LABELS[suggestion.priority];
        return /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex items-start justify-between gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "mb-1 text-sm font-semibold text-foreground", children: suggestion.title }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
                lineNumber: 185,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(
                  Badge,
                  {
                    variant: "outline",
                    className: TYPE_BADGE_CLASSES,
                    children: suggestion.type.replace(/_/g, " ")
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
                    lineNumber: 189,
                    columnNumber: 31
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: `text-xs font-medium ${priorityInfo.classes}`, children: priorityInfo.label }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
                  lineNumber: 195,
                  columnNumber: 31
                }, this),
                suggestion.suggestedAssignee && /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-muted-foreground", children: [
                  "→ ",
                  suggestion.suggestedAssignee
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
                  lineNumber: 199,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
                lineNumber: 188,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
              lineNumber: 184,
              columnNumber: 27
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                variant: isCreated ? "secondary" : "outline",
                size: "icon",
                disabled: isCreated,
                onClick: () => handleCreateTask(suggestion, index),
                "aria-label": isCreated ? "Task created" : "Create task",
                children: isCreated ? /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-4 w-4 text-primary" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
                  lineNumber: 213,
                  columnNumber: 27
                }, this) : /* @__PURE__ */ jsxDEV(Plus, { className: "h-4 w-4" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
                  lineNumber: 215,
                  columnNumber: 27
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
                lineNumber: 205,
                columnNumber: 27
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
            lineNumber: 183,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mb-3 text-sm leading-relaxed text-muted-foreground", children: suggestion.description }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
            lineNumber: 220,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "rounded-md border border-border bg-muted/40 px-3 py-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "mb-1 text-xs font-semibold text-foreground", children: "Mission Alignment" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
              lineNumber: 225,
              columnNumber: 27
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs leading-relaxed text-muted-foreground", children: suggestion.reasoning }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
              lineNumber: 226,
              columnNumber: 27
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
            lineNumber: 224,
            columnNumber: 25
          }, this)
        ] }, index, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
          lineNumber: 182,
          columnNumber: 21
        }, this);
      }) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
        lineNumber: 176,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
      lineNumber: 143,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
      lineNumber: 142,
      columnNumber: 11
    }, this),
    !isGenerating && suggestions.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-t border-border px-6 py-4", children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", onClick: handleGenerate, children: "Regenerate" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
        lineNumber: 240,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          size: "sm",
          onClick: handleCreateAll,
          disabled: createdTasks.size === suggestions.length,
          className: "gap-2",
          children: [
            /* @__PURE__ */ jsxDEV(Plus, { className: "h-4 w-4" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
              lineNumber: 249,
              columnNumber: 17
            }, this),
            "Create All (",
            suggestions.length - createdTasks.size,
            ")"
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
          lineNumber: 243,
          columnNumber: 15
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
      lineNumber: 239,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
    lineNumber: 129,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
    lineNumber: 128,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx",
    lineNumber: 127,
    columnNumber: 5
  }, this);
}
_s(MissionSuggestionsDrawer, "THlSf5U6NngphcGlEqkO7EUK99s=", false, function() {
  return [useAction, useMutation];
});
_c = MissionSuggestionsDrawer;
var _c;
$RefreshReg$(_c, "MissionSuggestionsDrawer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionSuggestionsDrawer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0hjOzs7Ozs7Ozs7Ozs7Ozs7OztBQWhIZCxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsYUFBYUMsaUJBQWlCO0FBQ3ZDLFNBQVNDLFdBQVc7QUFFcEIsU0FBU0MsTUFBTUMsVUFBVUMsY0FBY0MsZUFBZTtBQUN0RCxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxrQkFBa0I7QUFDM0I7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBd0JQLE1BQU1DLGtCQUFzRTtBQUFBLEVBQzFFLEdBQUcsRUFBRUMsT0FBTyxZQUFZQyxTQUFTLFdBQVc7QUFBQSxFQUM1QyxHQUFHLEVBQUVELE9BQU8sUUFBUUMsU0FBUyxZQUFZO0FBQUEsRUFDekMsR0FBRyxFQUFFRCxPQUFPLFVBQVVDLFNBQVMscUJBQXFCO0FBQUEsRUFDcEQsR0FBRyxFQUFFRCxPQUFPLE9BQU9DLFNBQVMsaUJBQWlCO0FBQy9DO0FBR0EsTUFBTUMscUJBQXFCO0FBRXBCLGdCQUFTQyx5QkFBeUIsRUFBRUMsV0FBV0MsUUFBdUMsR0FBRztBQUFBQyxLQUFBO0FBQzlGLFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJMUIsU0FBMkIsRUFBRTtBQUNuRSxRQUFNLENBQUMyQixjQUFjQyxlQUFlLElBQUk1QixTQUFTLEtBQUs7QUFDdEQsUUFBTSxDQUFDNkIsY0FBY0MsZUFBZSxJQUFJOUIsU0FBc0Isb0JBQUkrQixJQUFJLENBQUM7QUFDdkUsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlqQyxTQUF3QixJQUFJO0FBRXRELFFBQU1rQyxnQkFBZ0JoQyxVQUFVQyxJQUFJZ0MsUUFBUUQsYUFBYTtBQUN6RCxRQUFNRSxhQUFhbkMsWUFBWUUsSUFBSWtDLE1BQU1DLE1BQU07QUFFL0MsUUFBTUMsaUJBQWlCLFlBQVk7QUFDakNYLG9CQUFnQixJQUFJO0FBQ3BCSyxhQUFTLElBQUk7QUFDYlAsbUJBQWUsRUFBRTtBQUVqQixRQUFJO0FBQ0YsWUFBTWMsU0FBUyxNQUFNTixjQUFjO0FBQUEsUUFDakNaLFdBQVdBLGFBQWFtQjtBQUFBQSxRQUN4QkMsWUFBWTtBQUFBLFFBQ1pDLGdCQUFnQjtBQUFBLE1BQ2xCLENBQUM7QUFDRGpCLHFCQUFlYyxPQUFPZixXQUFXO0FBQUEsSUFDbkMsU0FBU21CLEtBQUs7QUFDWlgsZUFBU1csZUFBZUMsUUFBUUQsSUFBSUUsVUFBVSxnQ0FBZ0M7QUFBQSxJQUNoRixVQUFDO0FBQ0NsQixzQkFBZ0IsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLFFBQU1tQixtQkFBbUIsT0FBT0MsWUFBNEJDLFVBQWtCO0FBQzVFLFFBQUk7QUFDRixZQUFNYixXQUFXO0FBQUEsUUFDZmQsV0FBV0EsYUFBYW1CO0FBQUFBLFFBQ3hCUyxPQUFPRixXQUFXRTtBQUFBQSxRQUNsQkMsYUFBYSxHQUFHSCxXQUFXRyxXQUFXO0FBQUE7QUFBQSx5QkFBOEJILFdBQVdJLFNBQVM7QUFBQSxRQUN4RkMsTUFBTUwsV0FBV0s7QUFBQUEsUUFDakJDLFVBQVVOLFdBQVdNO0FBQUFBLFFBQ3JCQyxRQUFRO0FBQUEsTUFDVixDQUFDO0FBQ0R6QixzQkFBZ0IsQ0FBQzBCLFNBQVMsSUFBSXpCLElBQUl5QixJQUFJLEVBQUVDLElBQUlSLEtBQUssQ0FBQztBQUFBLElBQ3BELFNBQVNMLEtBQUs7QUFDWmMsY0FBUTFCLE1BQU0sMEJBQTBCWSxHQUFHO0FBQUEsSUFDN0M7QUFBQSxFQUNGO0FBRUEsUUFBTWUsa0JBQWtCLFlBQVk7QUFDbEMsYUFBU0MsSUFBSSxHQUFHQSxJQUFJbkMsWUFBWW9DLFFBQVFELEtBQUs7QUFDM0MsVUFBSSxDQUFDL0IsYUFBYWlDLElBQUlGLENBQUMsR0FBRztBQUN4QixjQUFNYixpQkFBaUJ0QixZQUFZbUMsQ0FBQyxHQUFHQSxDQUFDO0FBQUEsTUFDMUM7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBN0QsWUFBVSxNQUFNO0FBQ2QsU0FBS3dDLGVBQWU7QUFBQSxFQUV0QixHQUFHLEVBQUU7QUFFTCxTQUNFLHVCQUFDLFNBQU0sTUFBSSxNQUFDLGNBQWMsQ0FBQ3dCLFNBQVM7QUFBRSxRQUFJLENBQUNBLEtBQU14QyxTQUFRO0FBQUEsRUFBRyxHQUMxRCxpQ0FBQyxnQkFBYSxNQUFLLFNBQVEsV0FBVSw4QkFDbkMsaUNBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsMkJBQUMsZUFBWSxXQUFVLDhDQUNyQixpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSw2QkFBQyxZQUFTLFdBQVUsOEJBQTZCLGFBQWEsUUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRTtBQUFBLE1BQ25FLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxjQUFXLHFDQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUM7QUFBQSxRQUNqQyx1QkFBQyxvQkFBZ0Isc0VBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUVBLHVCQUFDLGNBQVcsV0FBVSxVQUNwQixpQ0FBQyxTQUFJLFdBQVUsdUJBQ1pJO0FBQUFBLHNCQUNDLHVCQUFDLFNBQUksV0FBVSwrREFDYjtBQUFBLCtCQUFDLFdBQVEsV0FBVSw0Q0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRDtBQUFBLFFBQzNELHVCQUFDLE9BQUUsV0FBVSxpQ0FBK0IsOERBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFHREssU0FDQyx1QkFBQyxRQUFLLFdBQVUsOENBQ2Q7QUFBQSwrQkFBQyxPQUFFLFdBQVUsNEJBQTRCQSxtQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQztBQUFBLFFBQy9DO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixNQUFLO0FBQUEsWUFDTCxXQUFVO0FBQUEsWUFDVixTQUFTTztBQUFBQSxZQUFlO0FBQUE7QUFBQSxVQUoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFdBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFHRCxDQUFDWixnQkFBZ0JGLFlBQVlvQyxXQUFXLEtBQUssQ0FBQzdCLFNBQzdDLHVCQUFDLFFBQUssV0FBVSxtQkFDZDtBQUFBLCtCQUFDLFlBQVMsV0FBVSxxREFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRTtBQUFBLFFBQ3JFLHVCQUFDLE9BQUUsV0FBVSxzQ0FBcUMsNkNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0U7QUFBQSxRQUMvRSx1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFTTyxnQkFBZ0Isb0NBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0Q7QUFBQSxXQUhqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUdELENBQUNaLGdCQUFnQkYsWUFBWW9DLFNBQVMsS0FDckMsdUJBQUMsU0FBSSxXQUFVLGFBQ1pwQyxzQkFBWXVDLElBQUksQ0FBQ2hCLFlBQVlDLFVBQVU7QUFDdEMsY0FBTWdCLFlBQVlwQyxhQUFhaUMsSUFBSWIsS0FBSztBQUN4QyxjQUFNaUIsZUFBZWpELGdCQUFnQitCLFdBQVdNLFFBQVE7QUFFeEQsZUFDRSx1QkFBQyxRQUFpQixXQUFVLE9BQzFCO0FBQUEsaUNBQUMsU0FBSSxXQUFVLCtDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEscUNBQUMsUUFBRyxXQUFVLDhDQUNYTixxQkFBV0UsU0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFRO0FBQUEsb0JBQ1IsV0FBVzlCO0FBQUFBLG9CQUVWNEIscUJBQVdLLEtBQUtjLFFBQVEsTUFBTSxHQUFHO0FBQUE7QUFBQSxrQkFKcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsVUFBSyxXQUFXLHVCQUF1QkQsYUFBYS9DLE9BQU8sSUFDekQrQyx1QkFBYWhELFNBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQzhCLFdBQVdvQixxQkFDVix1QkFBQyxVQUFLLFdBQVUsaUNBQStCO0FBQUE7QUFBQSxrQkFDMUNwQixXQUFXb0I7QUFBQUEscUJBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFiSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWVBO0FBQUEsaUJBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVNILFlBQVksY0FBYztBQUFBLGdCQUNuQyxNQUFLO0FBQUEsZ0JBQ0wsVUFBVUE7QUFBQUEsZ0JBQ1YsU0FBUyxNQUFNbEIsaUJBQWlCQyxZQUFZQyxLQUFLO0FBQUEsZ0JBQ2pELGNBQVlnQixZQUFZLGlCQUFpQjtBQUFBLGdCQUV4Q0Esc0JBQ0MsdUJBQUMsZ0JBQWEsV0FBVSwwQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEMsSUFFOUMsdUJBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlCO0FBQUE7QUFBQSxjQVY3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZQTtBQUFBLGVBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUNBO0FBQUEsVUFFQSx1QkFBQyxPQUFFLFdBQVUsc0RBQ1ZqQixxQkFBV0csZUFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUseURBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsOENBQTZDLGlDQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRTtBQUFBLFlBQzNFLHVCQUFDLE9BQUUsV0FBVSxpREFDVkgscUJBQVdJLGFBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLGFBL0NTSCxPQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnREE7QUFBQSxNQUVKLENBQUMsS0F4REg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlEQTtBQUFBLFNBMUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0RkEsS0E3RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThGQTtBQUFBLElBRUMsQ0FBQ3RCLGdCQUFnQkYsWUFBWW9DLFNBQVMsS0FDckMsdUJBQUMsU0FBSSxXQUFVLHNFQUNiO0FBQUEsNkJBQUMsVUFBTyxTQUFRLFNBQVEsTUFBSyxNQUFLLFNBQVN0QixnQkFBZSwwQkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FBU29CO0FBQUFBLFVBQ1QsVUFBVTlCLGFBQWF3QyxTQUFTNUMsWUFBWW9DO0FBQUFBLFVBQzVDLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlCO0FBQUE7QUFBQSxZQUNacEMsWUFBWW9DLFNBQVNoQyxhQUFhd0M7QUFBQUEsWUFBSztBQUFBO0FBQUE7QUFBQSxRQVB0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFRQTtBQUFBLFNBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsT0EzSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZIQSxLQTlIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0hBLEtBaElGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpSUE7QUFFSjtBQUFDN0MsR0E3TGVILDBCQUF3QjtBQUFBLFVBTWhCbkIsV0FDSEQsV0FBVztBQUFBO0FBQUEsS0FQaEJvQjtBQUF3QixJQUFBaUQ7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsInVzZUFjdGlvbiIsImFwaSIsIlBsdXMiLCJTcGFya2xlcyIsIkNoZWNrQ2lyY2xlMiIsIkxvYWRlcjIiLCJCYWRnZSIsIkJ1dHRvbiIsIkNhcmQiLCJTY3JvbGxBcmVhIiwiU2hlZXQiLCJTaGVldENvbnRlbnQiLCJTaGVldERlc2NyaXB0aW9uIiwiU2hlZXRIZWFkZXIiLCJTaGVldFRpdGxlIiwiUFJJT1JJVFlfTEFCRUxTIiwibGFiZWwiLCJjbGFzc2VzIiwiVFlQRV9CQURHRV9DTEFTU0VTIiwiTWlzc2lvblN1Z2dlc3Rpb25zRHJhd2VyIiwicHJvamVjdElkIiwib25DbG9zZSIsIl9zIiwic3VnZ2VzdGlvbnMiLCJzZXRTdWdnZXN0aW9ucyIsImlzR2VuZXJhdGluZyIsInNldElzR2VuZXJhdGluZyIsImNyZWF0ZWRUYXNrcyIsInNldENyZWF0ZWRUYXNrcyIsIlNldCIsImVycm9yIiwic2V0RXJyb3IiLCJyZXZlcnNlUHJvbXB0IiwibWlzc2lvbiIsImNyZWF0ZVRhc2siLCJ0YXNrcyIsImNyZWF0ZSIsImhhbmRsZUdlbmVyYXRlIiwicmVzdWx0IiwidW5kZWZpbmVkIiwiYXV0b0NyZWF0ZSIsIm1heFN1Z2dlc3Rpb25zIiwiZXJyIiwiRXJyb3IiLCJtZXNzYWdlIiwiaGFuZGxlQ3JlYXRlVGFzayIsInN1Z2dlc3Rpb24iLCJpbmRleCIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJyZWFzb25pbmciLCJ0eXBlIiwicHJpb3JpdHkiLCJzb3VyY2UiLCJwcmV2IiwiYWRkIiwiY29uc29sZSIsImhhbmRsZUNyZWF0ZUFsbCIsImkiLCJsZW5ndGgiLCJoYXMiLCJvcGVuIiwibWFwIiwiaXNDcmVhdGVkIiwicHJpb3JpdHlJbmZvIiwicmVwbGFjZSIsInN1Z2dlc3RlZEFzc2lnbmVlIiwic2l6ZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1pc3Npb25TdWdnZXN0aW9uc0RyYXdlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZUFjdGlvbiB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB0eXBlIHsgSWQgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvZGF0YU1vZGVsXCI7XG5pbXBvcnQgeyBQbHVzLCBTcGFya2xlcywgQ2hlY2tDaXJjbGUyLCBMb2FkZXIyIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgQmFkZ2UgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2JhZGdlXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuaW1wb3J0IHsgQ2FyZCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvY2FyZFwiO1xuaW1wb3J0IHsgU2Nyb2xsQXJlYSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvc2Nyb2xsLWFyZWFcIjtcbmltcG9ydCB7XG4gIFNoZWV0LFxuICBTaGVldENvbnRlbnQsXG4gIFNoZWV0RGVzY3JpcHRpb24sXG4gIFNoZWV0SGVhZGVyLFxuICBTaGVldFRpdGxlLFxufSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL3NoZWV0XCI7XG5cbmludGVyZmFjZSBNaXNzaW9uU3VnZ2VzdGlvbnNEcmF3ZXJQcm9wcyB7XG4gIHByb2plY3RJZDogSWQ8XCJwcm9qZWN0c1wiPiB8IG51bGw7XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG59XG5cbnR5cGUgVGFza1N1Z2dlc3Rpb24gPSB7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG4gIHR5cGU6XG4gICAgfCBcIkNPTlRFTlRcIlxuICAgIHwgXCJTT0NJQUxcIlxuICAgIHwgXCJFTUFJTF9NQVJLRVRJTkdcIlxuICAgIHwgXCJDVVNUT01FUl9SRVNFQVJDSFwiXG4gICAgfCBcIlNFT19SRVNFQVJDSFwiXG4gICAgfCBcIkVOR0lORUVSSU5HXCJcbiAgICB8IFwiRE9DU1wiXG4gICAgfCBcIk9QU1wiO1xuICBwcmlvcml0eTogMSB8IDIgfCAzIHwgNDtcbiAgc3VnZ2VzdGVkQXNzaWduZWU/OiBzdHJpbmc7XG4gIHJlYXNvbmluZzogc3RyaW5nO1xufTtcblxuY29uc3QgUFJJT1JJVFlfTEFCRUxTOiBSZWNvcmQ8bnVtYmVyLCB7IGxhYmVsOiBzdHJpbmc7IGNsYXNzZXM6IHN0cmluZyB9PiA9IHtcbiAgMTogeyBsYWJlbDogXCJDcml0aWNhbFwiLCBjbGFzc2VzOiBcInRleHQtZXJyXCIgfSxcbiAgMjogeyBsYWJlbDogXCJIaWdoXCIsIGNsYXNzZXM6IFwidGV4dC13YXJuXCIgfSxcbiAgMzogeyBsYWJlbDogXCJOb3JtYWxcIiwgY2xhc3NlczogXCJ0ZXh0LWluay1zZWNvbmRhcnlcIiB9LFxuICA0OiB7IGxhYmVsOiBcIkxvd1wiLCBjbGFzc2VzOiBcInRleHQtaW5rLW11dGVkXCIgfSxcbn07XG5cbi8qKiBUYXNrIHR5cGUgaXMgYSBjYXRlZ29yeSwgbm90IGEgc3RhdHVzIOKAlCBhbHdheXMgdGhlIG5ldXRyYWwgY2hpcC4gKi9cbmNvbnN0IFRZUEVfQkFER0VfQ0xBU1NFUyA9IFwiYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yIHRleHQtaW5rLXNlY29uZGFyeVwiO1xuXG5leHBvcnQgZnVuY3Rpb24gTWlzc2lvblN1Z2dlc3Rpb25zRHJhd2VyKHsgcHJvamVjdElkLCBvbkNsb3NlIH06IE1pc3Npb25TdWdnZXN0aW9uc0RyYXdlclByb3BzKSB7XG4gIGNvbnN0IFtzdWdnZXN0aW9ucywgc2V0U3VnZ2VzdGlvbnNdID0gdXNlU3RhdGU8VGFza1N1Z2dlc3Rpb25bXT4oW10pO1xuICBjb25zdCBbaXNHZW5lcmF0aW5nLCBzZXRJc0dlbmVyYXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbY3JlYXRlZFRhc2tzLCBzZXRDcmVhdGVkVGFza3NdID0gdXNlU3RhdGU8U2V0PG51bWJlcj4+KG5ldyBTZXQoKSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgcmV2ZXJzZVByb21wdCA9IHVzZUFjdGlvbihhcGkubWlzc2lvbi5yZXZlcnNlUHJvbXB0KTtcbiAgY29uc3QgY3JlYXRlVGFzayA9IHVzZU11dGF0aW9uKGFwaS50YXNrcy5jcmVhdGUpO1xuXG4gIGNvbnN0IGhhbmRsZUdlbmVyYXRlID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldElzR2VuZXJhdGluZyh0cnVlKTtcbiAgICBzZXRFcnJvcihudWxsKTtcbiAgICBzZXRTdWdnZXN0aW9ucyhbXSk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmV2ZXJzZVByb21wdCh7XG4gICAgICAgIHByb2plY3RJZDogcHJvamVjdElkID8/IHVuZGVmaW5lZCxcbiAgICAgICAgYXV0b0NyZWF0ZTogZmFsc2UsXG4gICAgICAgIG1heFN1Z2dlc3Rpb25zOiAzLFxuICAgICAgfSk7XG4gICAgICBzZXRTdWdnZXN0aW9ucyhyZXN1bHQuc3VnZ2VzdGlvbnMpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6IFwiRmFpbGVkIHRvIGdlbmVyYXRlIHN1Z2dlc3Rpb25zXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0dlbmVyYXRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVDcmVhdGVUYXNrID0gYXN5bmMgKHN1Z2dlc3Rpb246IFRhc2tTdWdnZXN0aW9uLCBpbmRleDogbnVtYmVyKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGNyZWF0ZVRhc2soe1xuICAgICAgICBwcm9qZWN0SWQ6IHByb2plY3RJZCA/PyB1bmRlZmluZWQsXG4gICAgICAgIHRpdGxlOiBzdWdnZXN0aW9uLnRpdGxlLFxuICAgICAgICBkZXNjcmlwdGlvbjogYCR7c3VnZ2VzdGlvbi5kZXNjcmlwdGlvbn1cXG5cXG4qKk1pc3Npb24gQWxpZ25tZW50OioqICR7c3VnZ2VzdGlvbi5yZWFzb25pbmd9YCxcbiAgICAgICAgdHlwZTogc3VnZ2VzdGlvbi50eXBlLFxuICAgICAgICBwcmlvcml0eTogc3VnZ2VzdGlvbi5wcmlvcml0eSxcbiAgICAgICAgc291cmNlOiBcIk1JU1NJT05fUFJPTVBUXCIsXG4gICAgICB9KTtcbiAgICAgIHNldENyZWF0ZWRUYXNrcygocHJldikgPT4gbmV3IFNldChwcmV2KS5hZGQoaW5kZXgpKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gY3JlYXRlIHRhc2s6XCIsIGVycik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZUFsbCA9IGFzeW5jICgpID0+IHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHN1Z2dlc3Rpb25zLmxlbmd0aDsgaSsrKSB7XG4gICAgICBpZiAoIWNyZWF0ZWRUYXNrcy5oYXMoaSkpIHtcbiAgICAgICAgYXdhaXQgaGFuZGxlQ3JlYXRlVGFzayhzdWdnZXN0aW9uc1tpXSwgaSk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgdm9pZCBoYW5kbGVHZW5lcmF0ZSgpO1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gIH0sIFtdKTtcblxuICByZXR1cm4gKFxuICAgIDxTaGVldCBvcGVuIG9uT3BlbkNoYW5nZT17KG9wZW4pID0+IHsgaWYgKCFvcGVuKSBvbkNsb3NlKCk7IH19PlxuICAgICAgPFNoZWV0Q29udGVudCBzaWRlPVwicmlnaHRcIiBjbGFzc05hbWU9XCJ3LVs2MjBweF0gbWF4LXctWzkydnddIHAtMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1mdWxsIGZsZXgtY29sXCI+XG4gICAgICAgICAgPFNoZWV0SGVhZGVyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ib3JkZXIgcHgtNiBweS00IHRleHQtbGVmdFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWluay1zZWNvbmRhcnlcIiBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8U2hlZXRUaXRsZT5NaXNzaW9uLUFsaWduZWQgVGFza3M8L1NoZWV0VGl0bGU+XG4gICAgICAgICAgICAgICAgPFNoZWV0RGVzY3JpcHRpb24+XG4gICAgICAgICAgICAgICAgICBTdWdnZXN0ZWQgdGFza3MgdG8gbW92ZSBjdXJyZW50IG1pc3Npb24gZ29hbHMgZm9yd2FyZC5cbiAgICAgICAgICAgICAgICA8L1NoZWV0RGVzY3JpcHRpb24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9TaGVldEhlYWRlcj5cblxuICAgICAgICAgIDxTY3JvbGxBcmVhIGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTQgcHgtNiBweS01XCI+XG4gICAgICAgICAgICAgIHtpc0dlbmVyYXRpbmcgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktMTIgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cIm1iLTQgaC04IHctOCBhbmltYXRlLXNwaW4gdGV4dC1wcmltYXJ5XCIgLz5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgIEdlbmVyYXRpbmcgbWlzc2lvbi1hbGlnbmVkIHRhc2sgc3VnZ2VzdGlvbnMuLi5cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cImJvcmRlci1kZXN0cnVjdGl2ZS8zMCBiZy1kZXN0cnVjdGl2ZS81IHAtNFwiPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWRlc3RydWN0aXZlXCI+e2Vycm9yfTwvcD5cbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImxpbmtcIlxuICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGgtYXV0byBwLTAgdGV4dC1kZXN0cnVjdGl2ZVwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUdlbmVyYXRlfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBUcnkgYWdhaW5cbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7IWlzR2VuZXJhdGluZyAmJiBzdWdnZXN0aW9ucy5sZW5ndGggPT09IDAgJiYgIWVycm9yICYmIChcbiAgICAgICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTggdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJteC1hdXRvIG1iLTMgaC0xMCB3LTEwIHRleHQtbXV0ZWQtZm9yZWdyb3VuZC81MFwiIC8+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi00IHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+Tm8gc3VnZ2VzdGlvbnMgYXZhaWxhYmxlIHlldC48L3A+XG4gICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIG9uQ2xpY2s9e2hhbmRsZUdlbmVyYXRlfT5HZW5lcmF0ZSBTdWdnZXN0aW9uczwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7IWlzR2VuZXJhdGluZyAmJiBzdWdnZXN0aW9ucy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAge3N1Z2dlc3Rpb25zLm1hcCgoc3VnZ2VzdGlvbiwgaW5kZXgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNDcmVhdGVkID0gY3JlYXRlZFRhc2tzLmhhcyhpbmRleCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHByaW9yaXR5SW5mbyA9IFBSSU9SSVRZX0xBQkVMU1tzdWdnZXN0aW9uLnByaW9yaXR5XTtcblxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxDYXJkIGtleT17aW5kZXh9IGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItMSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3VnZ2VzdGlvbi50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFkZ2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e1RZUEVfQkFER0VfQ0xBU1NFU31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N1Z2dlc3Rpb24udHlwZS5yZXBsYWNlKC9fL2csIFwiIFwiKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXhzIGZvbnQtbWVkaXVtICR7cHJpb3JpdHlJbmZvLmNsYXNzZXN9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwcmlvcml0eUluZm8ubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3VnZ2VzdGlvbi5zdWdnZXN0ZWRBc3NpZ25lZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oaSIHtzdWdnZXN0aW9uLnN1Z2dlc3RlZEFzc2lnbmVlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9e2lzQ3JlYXRlZCA/IFwic2Vjb25kYXJ5XCIgOiBcIm91dGxpbmVcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwiaWNvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzQ3JlYXRlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDcmVhdGVUYXNrKHN1Z2dlc3Rpb24sIGluZGV4KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtpc0NyZWF0ZWQgPyBcIlRhc2sgY3JlYXRlZFwiIDogXCJDcmVhdGUgdGFza1wifVxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzQ3JlYXRlZCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LXByaW1hcnlcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi0zIHRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7c3VnZ2VzdGlvbi5kZXNjcmlwdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLW11dGVkLzQwIHB4LTMgcHktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi0xIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWZvcmVncm91bmRcIj5NaXNzaW9uIEFsaWdubWVudDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3N1Z2dlc3Rpb24ucmVhc29uaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvU2Nyb2xsQXJlYT5cblxuICAgICAgICAgIHshaXNHZW5lcmF0aW5nICYmIHN1Z2dlc3Rpb25zLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLXQgYm9yZGVyLWJvcmRlciBweC02IHB5LTRcIj5cbiAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBzaXplPVwic21cIiBvbkNsaWNrPXtoYW5kbGVHZW5lcmF0ZX0+XG4gICAgICAgICAgICAgICAgUmVnZW5lcmF0ZVxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ3JlYXRlQWxsfVxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjcmVhdGVkVGFza3Muc2l6ZSA9PT0gc3VnZ2VzdGlvbnMubGVuZ3RofVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdhcC0yXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxQbHVzIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgIENyZWF0ZSBBbGwgKHtzdWdnZXN0aW9ucy5sZW5ndGggLSBjcmVhdGVkVGFza3Muc2l6ZX0pXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L1NoZWV0Q29udGVudD5cbiAgICA8L1NoZWV0PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvTWlzc2lvblN1Z2dlc3Rpb25zRHJhd2VyLnRzeCJ9