import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shellV2/AppShellV2.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=83faf592";
import { BellRing, Menu, MessageSquare } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { Sidebar } from "/src/shellV2/Sidebar.tsx";
import { ChatDock } from "/src/shellV2/ChatDock.tsx";
import { ResizerHandle } from "/src/shellV2/ResizerHandle.tsx";
import { useResizableColumns } from "/src/shellV2/useResizableColumns.ts";
import { groupForView, itemForView, allNavViews, NAV_GROUPS } from "/src/shellV2/navConfig.ts";
import { EOS_NAV_GROUPS } from "/src/shellV2/eosNavConfig.ts";
import { filterNavGroups } from "/src/shellV2/navFilter.ts";
import { isRouteVisible, routeBadge } from "/src/shellV2/routeCapabilities.ts";
import { useNavGroupsWithCounts } from "/src/shellV2/useNavGroupsWithCounts.ts";
import { useFlag } from "/src/hooks/useFlag.ts";
import { Breadcrumbs } from "/src/components/factory/Breadcrumbs.tsx";
import { useHarnessAnimation } from "/src/components/schematic/useHarnessAnimation.ts";
import { cn } from "/src/lib/utils.ts";
const ROUTE_PREFIX = "/v2";
const COMPACT_SHELL_QUERY = "(max-width: 899px)";
export function viewFromPath(pathname, validViews) {
  if (!pathname.startsWith(`${ROUTE_PREFIX}/`)) return null;
  const candidate = pathname.slice(ROUTE_PREFIX.length + 1).split("/")[0];
  return validViews.includes(candidate) ? candidate : null;
}
export function shouldDeferRouteWrite(pathname, validViews, activeView) {
  const pathView = viewFromPath(pathname, validViews);
  return pathView !== null && pathView !== activeView;
}
export function AppShellV2({
  activeView,
  onNavigate,
  workspaceSwitcher,
  onOpenSearch,
  pendingApprovals,
  onOpenApprovals,
  headerActions,
  footer,
  projectId,
  children
}) {
  _s();
  const navigate = useNavigate();
  const location = useLocation();
  const syncingFromUrl = useRef(false);
  const [compactShell, setCompactShell] = useState(
    () => typeof window !== "undefined" && window.matchMedia(COMPACT_SHELL_QUERY).matches
  );
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [mobileDockOpen, setMobileDockOpen] = useState(false);
  const columns = useResizableColumns();
  const { statusLabel } = useHarnessAnimation(projectId ?? void 0);
  const eosPreview = useFlag("eos.command-center-preview");
  const showControlStubs = useFlag("ui.control.stubs");
  const showPreviewRoutes = useFlag("ui.navigation.previews");
  const showDemoRoutes = useFlag("ui.navigation.demo-routes");
  const baseNavGroups = eosPreview ? EOS_NAV_GROUPS : NAV_GROUPS;
  const filteredGroups = filterNavGroups(baseNavGroups, {
    showControlStubs,
    enforceRouteCapabilities: eosPreview,
    showPreviewRoutes,
    showDemoRoutes
  });
  const navGroups = useNavGroupsWithCounts(filteredGroups, projectId);
  const validViews = [
    .../* @__PURE__ */ new Set(
      [
        ...baseNavGroups.flatMap((g) => g.items.map((i) => i.view)),
        ...allNavViews(),
        "automation-runs"
      ]
    )
  ];
  const group = navGroups.find((g) => g.items.some((i) => i.view === activeView)) ?? groupForView(activeView);
  const item = navGroups.flatMap((g) => g.items).find((i) => i.view === activeView) ?? itemForView(activeView);
  const crumbs = [
    ...group ? [{ label: group.label }] : [],
    ...item ? [{ label: item.label, current: true }] : []
  ];
  const activeRouteBadge = eosPreview ? routeBadge(activeView) : void 0;
  useEffect(() => {
    const pathView = viewFromPath(location.pathname, validViews);
    if (pathView && pathView !== activeView) {
      syncingFromUrl.current = true;
      onNavigate(pathView);
    }
  }, [location.pathname, validViews.join(",")]);
  useEffect(
    () => {
      if (shouldDeferRouteWrite(location.pathname, validViews, activeView)) {
        return;
      }
      if (eosPreview && !isRouteVisible(activeView, { showPreviewRoutes, showDemoRoutes })) {
        onNavigate("command-center");
        return;
      }
      if (syncingFromUrl.current) {
        syncingFromUrl.current = false;
        return;
      }
      const isAutomationDetail = activeView === "automations" && location.pathname.startsWith(`${ROUTE_PREFIX}/automations/`);
      const isAutomationRunDetail = activeView === "automation-runs" && location.pathname.startsWith(`${ROUTE_PREFIX}/automation-runs/`);
      if (isAutomationDetail || isAutomationRunDetail) return;
      const expected = `${ROUTE_PREFIX}/${activeView}`;
      if (location.pathname !== expected) {
        navigate({ pathname: expected, search: location.search }, { replace: true });
      }
    },
    [
      activeView,
      eosPreview,
      location.pathname,
      location.search,
      showDemoRoutes,
      showPreviewRoutes
    ]
  );
  useEffect(() => {
    document.body.classList.toggle("shell-resizing", columns.resizing);
    return () => document.body.classList.remove("shell-resizing");
  }, [columns.resizing]);
  useEffect(() => {
    const media = window.matchMedia(COMPACT_SHELL_QUERY);
    const sync = (event) => {
      setCompactShell(event.matches);
      if (!event.matches) {
        setMobileNavOpen(false);
        setMobileDockOpen(false);
      }
    };
    sync(media);
    media.addEventListener("change", sync);
    return () => media.removeEventListener("change", sync);
  }, []);
  const navigateFromSidebar = (view) => {
    onNavigate(view);
    const expected = `${ROUTE_PREFIX}/${view}`;
    if (location.pathname !== expected) {
      navigate({ pathname: expected, search: location.search });
    }
    setMobileNavOpen(false);
  };
  const archStatus = statusLabel ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("span", { className: "schematic-live-dot", "aria-hidden": true }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
      lineNumber: 205,
      columnNumber: 7
    }, this),
    statusLabel
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
    lineNumber: 204,
    columnNumber: 3
  }, this) : null;
  return /* @__PURE__ */ jsxDEV("div", { className: "shell-v2 flex h-screen overflow-hidden", children: [
    compactShell ? mobileNavOpen ? /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          "aria-label": "Close navigation",
          className: "absolute inset-0 bg-black/65",
          onClick: () => setMobileNavOpen(false)
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
          lineNumber: 215,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "relative z-10 h-full w-[min(86vw,320px)] shadow-2xl", children: /* @__PURE__ */ jsxDEV(
        Sidebar,
        {
          width: Math.min(columns.navWidth, 320),
          groups: navGroups,
          activeView,
          onNavigate: navigateFromSidebar,
          onOpenSearch: () => {
            setMobileNavOpen(false);
            onOpenSearch();
          },
          workspaceSwitcher,
          footer,
          onHide: () => setMobileNavOpen(false)
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
          lineNumber: 222,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
        lineNumber: 221,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
      lineNumber: 214,
      columnNumber: 7
    }, this) : null : !columns.navHidden ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(
        Sidebar,
        {
          width: columns.navWidth,
          groups: navGroups,
          activeView,
          onNavigate: navigateFromSidebar,
          onOpenSearch,
          workspaceSwitcher,
          footer,
          onHide: () => columns.setNavHidden(true)
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
          lineNumber: 240,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        ResizerHandle,
        {
          onResize: columns.onNavResize,
          onBegin: columns.beginResize,
          onEnd: columns.endResize,
          title: "Drag to resize sidebar"
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
          lineNumber: 250,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
      lineNumber: 239,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: () => columns.setNavHidden(false),
        className: "fixed left-3 top-3 z-30 flex h-[30px] w-[34px] items-center justify-center rounded-lg border border-line bg-surface-1 text-ink-secondary shadow-sm hover:text-ink",
        title: "Show sidebar",
        "aria-label": "Show sidebar",
        children: /* @__PURE__ */ jsxDEV(Menu, { size: 16, "aria-hidden": true }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
          lineNumber: 265,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
        lineNumber: 258,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex min-w-0 flex-1 flex-col", children: [
      /* @__PURE__ */ jsxDEV("header", { className: "flex h-12 shrink-0 items-center justify-between gap-2 border-b border-line bg-app px-3 sm:px-5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex min-w-0 items-center gap-2", children: [
          compactShell ? /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setMobileNavOpen(true),
              className: "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-line bg-surface-1 text-ink-secondary hover:text-ink",
              "aria-label": "Open navigation",
              "aria-expanded": mobileNavOpen,
              children: /* @__PURE__ */ jsxDEV(Menu, { size: 16, "aria-hidden": true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
                lineNumber: 280,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
              lineNumber: 273,
              columnNumber: 13
            },
            this
          ) : null,
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 overflow-hidden", children: /* @__PURE__ */ jsxDEV(Breadcrumbs, { items: crumbs }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
            lineNumber: 284,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
            lineNumber: 283,
            columnNumber: 13
          }, this),
          activeRouteBadge ? /* @__PURE__ */ jsxDEV("span", { className: "shrink-0 rounded border border-line bg-surface-1 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-[0.06em] text-ink-muted", children: activeRouteBadge }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
            lineNumber: 287,
            columnNumber: 13
          }, this) : null
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
          lineNumber: 271,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex shrink-0 items-center gap-2", children: [
          headerActions,
          compactShell ? /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setMobileDockOpen(true),
              className: "flex h-8 w-8 items-center justify-center rounded-lg border border-line bg-surface-1 text-ink-secondary hover:text-ink",
              "aria-label": "Open chat",
              "aria-expanded": mobileDockOpen,
              children: /* @__PURE__ */ jsxDEV(MessageSquare, { size: 14, "aria-hidden": true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
                lineNumber: 302,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
              lineNumber: 295,
              columnNumber: 13
            },
            this
          ) : null,
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: onOpenApprovals,
              className: cn(
                "flex h-8 items-center gap-1.5 rounded-lg border px-2.5 text-[12.5px] transition-colors duration-150",
                pendingApprovals > 0 ? "border-line-strong bg-warn-soft text-warn" : "border-line text-ink-muted hover:text-ink-secondary"
              ),
              "aria-label": pendingApprovals > 0 ? `${pendingApprovals} pending approval${pendingApprovals === 1 ? "" : "s"}` : "Open approvals",
              children: [
                /* @__PURE__ */ jsxDEV(BellRing, { size: 13, "aria-hidden": true }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
                  lineNumber: 320,
                  columnNumber: 15
                }, this),
                compactShell ? pendingApprovals || null : pendingApprovals > 0 ? `${pendingApprovals} approval${pendingApprovals === 1 ? "" : "s"}` : "Approvals"
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
              lineNumber: 305,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
          lineNumber: 292,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
        lineNumber: 270,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("main", { className: "flex min-h-0 flex-1 overflow-hidden bg-app", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "shell-main factory-page min-h-0 min-w-0 flex-1 overflow-y-auto", children }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
          lineNumber: 330,
          columnNumber: 11
        }, this),
        !compactShell && !columns.dockClosed ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(
            ResizerHandle,
            {
              onResize: columns.onDockResize,
              onBegin: columns.beginResize,
              onEnd: columns.endResize,
              title: "Drag to resize chat"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
              lineNumber: 335,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            ChatDock,
            {
              width: columns.dockWidth,
              onClose: () => columns.setDockClosed(true),
              projectId,
              archStatus,
              onNavigate
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
              lineNumber: 341,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
          lineNumber: 334,
          columnNumber: 11
        }, this) : !compactShell ? /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => columns.setDockClosed(false),
            className: "fixed right-3 top-14 z-30 flex items-center gap-1 rounded-lg border border-line bg-surface-1 px-3 py-1.5 text-[12px] text-ink-secondary shadow-sm hover:text-ink",
            title: "Open chat",
            "aria-label": "Open chat",
            children: [
              /* @__PURE__ */ jsxDEV(MessageSquare, { size: 14, "aria-hidden": true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
                lineNumber: 357,
                columnNumber: 15
              }, this),
              "Chat"
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
            lineNumber: 350,
            columnNumber: 11
          },
          this
        ) : null
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
        lineNumber: 329,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
      lineNumber: 269,
      columnNumber: 7
    }, this),
    compactShell && mobileDockOpen ? /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex justify-end", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          "aria-label": "Close chat",
          className: "absolute inset-0 bg-black/65",
          onClick: () => setMobileDockOpen(false)
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
          lineNumber: 366,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "relative z-10 h-full w-full max-w-[440px] shadow-2xl", children: /* @__PURE__ */ jsxDEV(
        ChatDock,
        {
          width: "100%",
          onClose: () => setMobileDockOpen(false),
          projectId,
          archStatus,
          onNavigate: (view) => {
            setMobileDockOpen(false);
            onNavigate(view);
          }
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
          lineNumber: 373,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
        lineNumber: 372,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
      lineNumber: 365,
      columnNumber: 7
    }, this) : null
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx",
    lineNumber: 211,
    columnNumber: 5
  }, this);
}
_s(AppShellV2, "iCWhJv4xbG3TZiIFgX96i8tRDXQ=", false, function() {
  return [useNavigate, useLocation, useResizableColumns, useHarnessAnimation, useFlag, useFlag, useFlag, useFlag, useNavGroupsWithCounts];
});
_c = AppShellV2;
var _c;
$RefreshReg$(_c, "AppShellV2");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/AppShellV2.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0xJLG1CQUNFLGNBREY7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBeExKLFNBQVNBLFdBQVdDLFFBQVFDLGdCQUFnQztBQUM1RCxTQUFTQyxhQUFhQyxtQkFBbUI7QUFDekMsU0FBU0MsVUFBVUMsTUFBTUMscUJBQXFCO0FBRTlDLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsY0FBY0MsYUFBYUMsYUFBYUMsa0JBQWtCO0FBQ25FLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsZ0JBQWdCQyxrQkFBa0I7QUFDM0MsU0FBU0MsOEJBQThCO0FBQ3ZDLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQyxVQUFVO0FBR25CLE1BQU1DLGVBQWU7QUFDckIsTUFBTUMsc0JBQXNCO0FBRXJCLGdCQUFTQyxhQUFhQyxVQUFrQkMsWUFBdUM7QUFDcEYsTUFBSSxDQUFDRCxTQUFTRSxXQUFXLEdBQUdMLFlBQVksR0FBRyxFQUFHLFFBQU87QUFDckQsUUFBTU0sWUFBWUgsU0FBU0ksTUFBTVAsYUFBYVEsU0FBUyxDQUFDLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDdEUsU0FBT0wsV0FBV00sU0FBU0osU0FBUyxJQUFLQSxZQUF5QjtBQUNwRTtBQUVPLGdCQUFTSyxzQkFDZFIsVUFDQUMsWUFDQVEsWUFDUztBQUNULFFBQU1DLFdBQVdYLGFBQWFDLFVBQVVDLFVBQVU7QUFDbEQsU0FBT1MsYUFBYSxRQUFRQSxhQUFhRDtBQUMzQztBQWtCTyxnQkFBU0UsV0FBVztBQUFBLEVBQ3pCRjtBQUFBQSxFQUNBRztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNlLEdBQWdCO0FBQUFDLEtBQUE7QUFDL0IsUUFBTUMsV0FBVzlDLFlBQVk7QUFDN0IsUUFBTStDLFdBQVdoRCxZQUFZO0FBQzdCLFFBQU1pRCxpQkFBaUJuRCxPQUFPLEtBQUs7QUFDbkMsUUFBTSxDQUFDb0QsY0FBY0MsZUFBZSxJQUFJcEQ7QUFBQUEsSUFBUyxNQUMvQyxPQUFPcUQsV0FBVyxlQUFlQSxPQUFPQyxXQUFXOUIsbUJBQW1CLEVBQUUrQjtBQUFBQSxFQUMxRTtBQUNBLFFBQU0sQ0FBQ0MsZUFBZUMsZ0JBQWdCLElBQUl6RCxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDMEQsZ0JBQWdCQyxpQkFBaUIsSUFBSTNELFNBQVMsS0FBSztBQUUxRCxRQUFNNEQsVUFBVW5ELG9CQUFvQjtBQUNwQyxRQUFNLEVBQUVvRCxZQUFZLElBQUl4QyxvQkFBb0J3QixhQUFhaUIsTUFBUztBQUVsRSxRQUFNQyxhQUFhNUMsUUFBUSw0QkFBNEI7QUFDdkQsUUFBTTZDLG1CQUFtQjdDLFFBQVEsa0JBQWtCO0FBQ25ELFFBQU04QyxvQkFBb0I5QyxRQUFRLHdCQUF3QjtBQUMxRCxRQUFNK0MsaUJBQWlCL0MsUUFBUSwyQkFBMkI7QUFDMUQsUUFBTWdELGdCQUFnQkosYUFBYWpELGlCQUFpQkQ7QUFDcEQsUUFBTXVELGlCQUFpQnJELGdCQUFnQm9ELGVBQWU7QUFBQSxJQUNwREg7QUFBQUEsSUFDQUssMEJBQTBCTjtBQUFBQSxJQUMxQkU7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixDQUFDO0FBQ0QsUUFBTUksWUFBWXBELHVCQUF1QmtELGdCQUFnQnZCLFNBQVM7QUFDbEUsUUFBTWxCLGFBQWE7QUFBQSxJQUNqQixHQUFHLG9CQUFJNEM7QUFBQUEsTUFBSTtBQUFBLFFBQ1QsR0FBR0osY0FBY0ssUUFBUSxDQUFDQyxNQUFNQSxFQUFFQyxNQUFNQyxJQUFJLENBQUNDLE1BQU1BLEVBQUVDLElBQWMsQ0FBQztBQUFBLFFBQ3BFLEdBQUdqRSxZQUFZO0FBQUEsUUFDZjtBQUFBLE1BQWlCO0FBQUEsSUFDbEI7QUFBQSxFQUFDO0FBRUosUUFBTWtFLFFBQ0pSLFVBQVVTLEtBQUssQ0FBQ04sTUFBTUEsRUFBRUMsTUFBTU0sS0FBSyxDQUFDSixNQUFNQSxFQUFFQyxTQUFTMUMsVUFBVSxDQUFDLEtBQ2hFekIsYUFBYXlCLFVBQVU7QUFDekIsUUFBTThDLE9BQ0pYLFVBQVVFLFFBQVEsQ0FBQ0MsTUFBTUEsRUFBRUMsS0FBSyxFQUFFSyxLQUFLLENBQUNILE1BQU1BLEVBQUVDLFNBQVMxQyxVQUFVLEtBQ25FeEIsWUFBWXdCLFVBQVU7QUFDeEIsUUFBTStDLFNBQVM7QUFBQSxJQUNiLEdBQUlKLFFBQVEsQ0FBQyxFQUFFSyxPQUFPTCxNQUFNSyxNQUFNLENBQUMsSUFBSTtBQUFBLElBQ3ZDLEdBQUlGLE9BQU8sQ0FBQyxFQUFFRSxPQUFPRixLQUFLRSxPQUFPQyxTQUFTLEtBQUssQ0FBQyxJQUFJO0FBQUEsRUFBRztBQUV6RCxRQUFNQyxtQkFBbUJ0QixhQUFhOUMsV0FBV2tCLFVBQVUsSUFBSTJCO0FBRS9EaEUsWUFBVSxNQUFNO0FBQ2QsVUFBTXNDLFdBQVdYLGFBQWF3QixTQUFTdkIsVUFBVUMsVUFBVTtBQUMzRCxRQUFJUyxZQUFZQSxhQUFhRCxZQUFZO0FBQ3ZDZSxxQkFBZWtDLFVBQVU7QUFDekI5QyxpQkFBV0YsUUFBUTtBQUFBLElBQ3JCO0FBQUEsRUFFRixHQUFHLENBQUNhLFNBQVN2QixVQUFVQyxXQUFXMkQsS0FBSyxHQUFHLENBQUMsQ0FBQztBQUU1Q3hGO0FBQUFBLElBQVUsTUFBTTtBQUlkLFVBQUlvQyxzQkFBc0JlLFNBQVN2QixVQUFVQyxZQUFZUSxVQUFVLEdBQUc7QUFDcEU7QUFBQSxNQUNGO0FBQ0EsVUFDRTRCLGNBQ0EsQ0FBQy9DLGVBQWVtQixZQUFZLEVBQUU4QixtQkFBbUJDLGVBQWUsQ0FBQyxHQUNqRTtBQUNBNUIsbUJBQVcsZ0JBQWdCO0FBQzNCO0FBQUEsTUFDRjtBQUNBLFVBQUlZLGVBQWVrQyxTQUFTO0FBQzFCbEMsdUJBQWVrQyxVQUFVO0FBQ3pCO0FBQUEsTUFDRjtBQUNBLFlBQU1HLHFCQUFxQnBELGVBQWUsaUJBQ3JDYyxTQUFTdkIsU0FBU0UsV0FBVyxHQUFHTCxZQUFZLGVBQWU7QUFDaEUsWUFBTWlFLHdCQUF3QnJELGVBQWUscUJBQ3hDYyxTQUFTdkIsU0FBU0UsV0FBVyxHQUFHTCxZQUFZLG1CQUFtQjtBQUNwRSxVQUFJZ0Usc0JBQXNCQyxzQkFBdUI7QUFDakQsWUFBTUMsV0FBVyxHQUFHbEUsWUFBWSxJQUFJWSxVQUFVO0FBQzlDLFVBQUljLFNBQVN2QixhQUFhK0QsVUFBVTtBQUNsQ3pDLGlCQUFTLEVBQUV0QixVQUFVK0QsVUFBVUMsUUFBUXpDLFNBQVN5QyxPQUFPLEdBQUcsRUFBRUMsU0FBUyxLQUFLLENBQUM7QUFBQSxNQUM3RTtBQUFBLElBRUY7QUFBQSxJQUFHO0FBQUEsTUFDRHhEO0FBQUFBLE1BQ0E0QjtBQUFBQSxNQUNBZCxTQUFTdkI7QUFBQUEsTUFDVHVCLFNBQVN5QztBQUFBQSxNQUNUeEI7QUFBQUEsTUFDQUQ7QUFBQUEsSUFBaUI7QUFBQSxFQUNsQjtBQUVEbkUsWUFBVSxNQUFNO0FBQ2Q4RixhQUFTQyxLQUFLQyxVQUFVQyxPQUFPLGtCQUFrQm5DLFFBQVFvQyxRQUFRO0FBQ2pFLFdBQU8sTUFBTUosU0FBU0MsS0FBS0MsVUFBVUcsT0FBTyxnQkFBZ0I7QUFBQSxFQUM5RCxHQUFHLENBQUNyQyxRQUFRb0MsUUFBUSxDQUFDO0FBRXJCbEcsWUFBVSxNQUFNO0FBQ2QsVUFBTW9HLFFBQVE3QyxPQUFPQyxXQUFXOUIsbUJBQW1CO0FBQ25ELFVBQU0yRSxPQUFPQSxDQUFDQyxVQUFnRDtBQUM1RGhELHNCQUFnQmdELE1BQU03QyxPQUFPO0FBQzdCLFVBQUksQ0FBQzZDLE1BQU03QyxTQUFTO0FBQ2xCRSx5QkFBaUIsS0FBSztBQUN0QkUsMEJBQWtCLEtBQUs7QUFBQSxNQUN6QjtBQUFBLElBQ0Y7QUFFQXdDLFNBQUtELEtBQUs7QUFDVkEsVUFBTUcsaUJBQWlCLFVBQVVGLElBQUk7QUFDckMsV0FBTyxNQUFNRCxNQUFNSSxvQkFBb0IsVUFBVUgsSUFBSTtBQUFBLEVBQ3ZELEdBQUcsRUFBRTtBQUVMLFFBQU1JLHNCQUFzQkEsQ0FBQzFCLFNBQW1CO0FBQzlDdkMsZUFBV3VDLElBQUk7QUFDZixVQUFNWSxXQUFXLEdBQUdsRSxZQUFZLElBQUlzRCxJQUFJO0FBQ3hDLFFBQUk1QixTQUFTdkIsYUFBYStELFVBQVU7QUFDbEN6QyxlQUFTLEVBQUV0QixVQUFVK0QsVUFBVUMsUUFBUXpDLFNBQVN5QyxPQUFPLENBQUM7QUFBQSxJQUMxRDtBQUNBakMscUJBQWlCLEtBQUs7QUFBQSxFQUN4QjtBQUVBLFFBQU0rQyxhQUFhM0MsY0FDakIsbUNBQ0U7QUFBQSwyQkFBQyxVQUFLLFdBQVUsc0JBQXFCLGVBQVcsUUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRDtBQUFBLElBQy9DQTtBQUFBQSxPQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQSxJQUNFO0FBRUosU0FDRSx1QkFBQyxTQUFJLFdBQVUsMENBQ1pWO0FBQUFBLG1CQUNDSyxnQkFDRSx1QkFBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsY0FBVztBQUFBLFVBQ1gsV0FBVTtBQUFBLFVBQ1YsU0FBUyxNQUFNQyxpQkFBaUIsS0FBSztBQUFBO0FBQUEsUUFKdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSXlDO0FBQUEsTUFFekMsdUJBQUMsU0FBSSxXQUFVLHVEQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFPZ0QsS0FBS0MsSUFBSTlDLFFBQVErQyxVQUFVLEdBQUc7QUFBQSxVQUNyQyxRQUFRckM7QUFBQUEsVUFDUjtBQUFBLFVBQ0EsWUFBWWlDO0FBQUFBLFVBQ1osY0FBYyxNQUFNO0FBQ2xCOUMsNkJBQWlCLEtBQUs7QUFDdEJqQix5QkFBYTtBQUFBLFVBQ2Y7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0EsUUFBUSxNQUFNaUIsaUJBQWlCLEtBQUs7QUFBQTtBQUFBLFFBWHRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVd3QyxLQVoxQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxTQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0JBLElBQ0UsT0FDRixDQUFDRyxRQUFRZ0QsWUFDWCxtQ0FDRTtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFPaEQsUUFBUStDO0FBQUFBLFVBQ2YsUUFBUXJDO0FBQUFBLFVBQ1I7QUFBQSxVQUNBLFlBQVlpQztBQUFBQSxVQUNaO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBLFFBQVEsTUFBTTNDLFFBQVFpRCxhQUFhLElBQUk7QUFBQTtBQUFBLFFBUnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVEyQztBQUFBLE1BRTNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxVQUFVakQsUUFBUWtEO0FBQUFBLFVBQ2xCLFNBQVNsRCxRQUFRbUQ7QUFBQUEsVUFDakIsT0FBT25ELFFBQVFvRDtBQUFBQSxVQUNmLE9BQU07QUFBQTtBQUFBLFFBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSWdDO0FBQUEsU0FmbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxTQUFTLE1BQU1wRCxRQUFRaUQsYUFBYSxLQUFLO0FBQUEsUUFDekMsV0FBVTtBQUFBLFFBQ1YsT0FBTTtBQUFBLFFBQ04sY0FBVztBQUFBLFFBRVgsaUNBQUMsUUFBSyxNQUFNLElBQUksZUFBVyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCO0FBQUE7QUFBQSxNQVA3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFRQTtBQUFBLElBR0YsdUJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsNkJBQUMsWUFBTyxXQUFVLGtHQUNoQjtBQUFBLCtCQUFDLFNBQUksV0FBVSxtQ0FDWjFEO0FBQUFBLHlCQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU1NLGlCQUFpQixJQUFJO0FBQUEsY0FDcEMsV0FBVTtBQUFBLGNBQ1YsY0FBVztBQUFBLGNBQ1gsaUJBQWVEO0FBQUFBLGNBRWYsaUNBQUMsUUFBSyxNQUFNLElBQUksZUFBVyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQjtBQUFBO0FBQUEsWUFQN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUEsSUFDRTtBQUFBLFVBQ0osdUJBQUMsU0FBSSxXQUFVLDJCQUNiLGlDQUFDLGVBQVksT0FBTzBCLFVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJCLEtBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDRyxtQkFDQyx1QkFBQyxVQUFLLFdBQVUsc0lBQ2JBLDhCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsSUFDRTtBQUFBLGFBbkJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxvQ0FDWjFDO0FBQUFBO0FBQUFBLFVBQ0FRLGVBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTVEsa0JBQWtCLElBQUk7QUFBQSxjQUNyQyxXQUFVO0FBQUEsY0FDVixjQUFXO0FBQUEsY0FDWCxpQkFBZUQ7QUFBQUEsY0FFZixpQ0FBQyxpQkFBYyxNQUFNLElBQUksZUFBVyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQztBQUFBO0FBQUEsWUFQdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUEsSUFDRTtBQUFBLFVBQ0o7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVNoQjtBQUFBQSxjQUNULFdBQVdwQjtBQUFBQSxnQkFDVDtBQUFBLGdCQUNBbUIsbUJBQW1CLElBQ2YsOENBQ0E7QUFBQSxjQUNOO0FBQUEsY0FDQSxjQUNFQSxtQkFBbUIsSUFDZixHQUFHQSxnQkFBZ0Isb0JBQW9CQSxxQkFBcUIsSUFBSSxLQUFLLEdBQUcsS0FDeEU7QUFBQSxjQUdOO0FBQUEsdUNBQUMsWUFBUyxNQUFNLElBQUksZUFBVyxRQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErQjtBQUFBLGdCQUM5QlUsZUFDR1Ysb0JBQW9CLE9BQ3BCQSxtQkFBbUIsSUFDakIsR0FBR0EsZ0JBQWdCLFlBQVlBLHFCQUFxQixJQUFJLEtBQUssR0FBRyxLQUNoRTtBQUFBO0FBQUE7QUFBQSxZQXBCUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFxQkE7QUFBQSxhQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUNBO0FBQUEsV0F6REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBEQTtBQUFBLE1BQ0EsdUJBQUMsVUFBSyxXQUFVLDhDQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGtFQUNaSyxZQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0MsQ0FBQ0ssZ0JBQWdCLENBQUNTLFFBQVFxRCxhQUN6QixtQ0FDRTtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxVQUFVckQsUUFBUXNEO0FBQUFBLGNBQ2xCLFNBQVN0RCxRQUFRbUQ7QUFBQUEsY0FDakIsT0FBT25ELFFBQVFvRDtBQUFBQSxjQUNmLE9BQU07QUFBQTtBQUFBLFlBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSTZCO0FBQUEsVUFFN0I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU9wRCxRQUFRdUQ7QUFBQUEsY0FDZixTQUFTLE1BQU12RCxRQUFRd0QsY0FBYyxJQUFJO0FBQUEsY0FDekM7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBO0FBQUEsWUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLeUI7QUFBQSxhQVozQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0EsSUFDRSxDQUFDakUsZUFDSDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNUyxRQUFRd0QsY0FBYyxLQUFLO0FBQUEsWUFDMUMsV0FBVTtBQUFBLFlBQ1YsT0FBTTtBQUFBLFlBQ04sY0FBVztBQUFBLFlBRVg7QUFBQSxxQ0FBQyxpQkFBYyxNQUFNLElBQUksZUFBVyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUHRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBLElBQ0U7QUFBQSxXQS9CTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0NBO0FBQUEsU0E1RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZGQTtBQUFBLElBRUNqRSxnQkFBZ0JPLGlCQUNmLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxjQUFXO0FBQUEsVUFDWCxXQUFVO0FBQUEsVUFDVixTQUFTLE1BQU1DLGtCQUFrQixLQUFLO0FBQUE7QUFBQSxRQUp4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJMEM7QUFBQSxNQUUxQyx1QkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU07QUFBQSxVQUNOLFNBQVMsTUFBTUEsa0JBQWtCLEtBQUs7QUFBQSxVQUN0QztBQUFBLFVBQ0E7QUFBQSxVQUNBLFlBQVksQ0FBQ2tCLFNBQVM7QUFDcEJsQiw4QkFBa0IsS0FBSztBQUN2QnJCLHVCQUFXdUMsSUFBSTtBQUFBLFVBQ2pCO0FBQUE7QUFBQSxRQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFJLEtBVE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsU0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQSxJQUNFO0FBQUEsT0E5S047QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStLQTtBQUVKO0FBQUM5QixHQTNUZVYsWUFBVTtBQUFBLFVBWVBuQyxhQUNBRCxhQVFEUSxxQkFDUVkscUJBRUxGLFNBQ01BLFNBQ0NBLFNBQ0hBLFNBUUxELHNCQUFzQjtBQUFBO0FBQUEsS0FuQzFCbUI7QUFBVSxJQUFBZ0Y7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlUmVmIiwidXNlU3RhdGUiLCJ1c2VMb2NhdGlvbiIsInVzZU5hdmlnYXRlIiwiQmVsbFJpbmciLCJNZW51IiwiTWVzc2FnZVNxdWFyZSIsIlNpZGViYXIiLCJDaGF0RG9jayIsIlJlc2l6ZXJIYW5kbGUiLCJ1c2VSZXNpemFibGVDb2x1bW5zIiwiZ3JvdXBGb3JWaWV3IiwiaXRlbUZvclZpZXciLCJhbGxOYXZWaWV3cyIsIk5BVl9HUk9VUFMiLCJFT1NfTkFWX0dST1VQUyIsImZpbHRlck5hdkdyb3VwcyIsImlzUm91dGVWaXNpYmxlIiwicm91dGVCYWRnZSIsInVzZU5hdkdyb3Vwc1dpdGhDb3VudHMiLCJ1c2VGbGFnIiwiQnJlYWRjcnVtYnMiLCJ1c2VIYXJuZXNzQW5pbWF0aW9uIiwiY24iLCJST1VURV9QUkVGSVgiLCJDT01QQUNUX1NIRUxMX1FVRVJZIiwidmlld0Zyb21QYXRoIiwicGF0aG5hbWUiLCJ2YWxpZFZpZXdzIiwic3RhcnRzV2l0aCIsImNhbmRpZGF0ZSIsInNsaWNlIiwibGVuZ3RoIiwic3BsaXQiLCJpbmNsdWRlcyIsInNob3VsZERlZmVyUm91dGVXcml0ZSIsImFjdGl2ZVZpZXciLCJwYXRoVmlldyIsIkFwcFNoZWxsVjIiLCJvbk5hdmlnYXRlIiwid29ya3NwYWNlU3dpdGNoZXIiLCJvbk9wZW5TZWFyY2giLCJwZW5kaW5nQXBwcm92YWxzIiwib25PcGVuQXBwcm92YWxzIiwiaGVhZGVyQWN0aW9ucyIsImZvb3RlciIsInByb2plY3RJZCIsImNoaWxkcmVuIiwiX3MiLCJuYXZpZ2F0ZSIsImxvY2F0aW9uIiwic3luY2luZ0Zyb21VcmwiLCJjb21wYWN0U2hlbGwiLCJzZXRDb21wYWN0U2hlbGwiLCJ3aW5kb3ciLCJtYXRjaE1lZGlhIiwibWF0Y2hlcyIsIm1vYmlsZU5hdk9wZW4iLCJzZXRNb2JpbGVOYXZPcGVuIiwibW9iaWxlRG9ja09wZW4iLCJzZXRNb2JpbGVEb2NrT3BlbiIsImNvbHVtbnMiLCJzdGF0dXNMYWJlbCIsInVuZGVmaW5lZCIsImVvc1ByZXZpZXciLCJzaG93Q29udHJvbFN0dWJzIiwic2hvd1ByZXZpZXdSb3V0ZXMiLCJzaG93RGVtb1JvdXRlcyIsImJhc2VOYXZHcm91cHMiLCJmaWx0ZXJlZEdyb3VwcyIsImVuZm9yY2VSb3V0ZUNhcGFiaWxpdGllcyIsIm5hdkdyb3VwcyIsIlNldCIsImZsYXRNYXAiLCJnIiwiaXRlbXMiLCJtYXAiLCJpIiwidmlldyIsImdyb3VwIiwiZmluZCIsInNvbWUiLCJpdGVtIiwiY3J1bWJzIiwibGFiZWwiLCJjdXJyZW50IiwiYWN0aXZlUm91dGVCYWRnZSIsImpvaW4iLCJpc0F1dG9tYXRpb25EZXRhaWwiLCJpc0F1dG9tYXRpb25SdW5EZXRhaWwiLCJleHBlY3RlZCIsInNlYXJjaCIsInJlcGxhY2UiLCJkb2N1bWVudCIsImJvZHkiLCJjbGFzc0xpc3QiLCJ0b2dnbGUiLCJyZXNpemluZyIsInJlbW92ZSIsIm1lZGlhIiwic3luYyIsImV2ZW50IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJuYXZpZ2F0ZUZyb21TaWRlYmFyIiwiYXJjaFN0YXR1cyIsIk1hdGgiLCJtaW4iLCJuYXZXaWR0aCIsIm5hdkhpZGRlbiIsInNldE5hdkhpZGRlbiIsIm9uTmF2UmVzaXplIiwiYmVnaW5SZXNpemUiLCJlbmRSZXNpemUiLCJkb2NrQ2xvc2VkIiwib25Eb2NrUmVzaXplIiwiZG9ja1dpZHRoIiwic2V0RG9ja0Nsb3NlZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFwcFNoZWxsVjIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSwgdHlwZSBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBCZWxsUmluZywgTWVudSwgTWVzc2FnZVNxdWFyZSB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB0eXBlIHsgTWFpblZpZXcgfSBmcm9tIFwiLi4vVG9wTmF2XCI7XG5pbXBvcnQgeyBTaWRlYmFyIH0gZnJvbSBcIi4vU2lkZWJhclwiO1xuaW1wb3J0IHsgQ2hhdERvY2sgfSBmcm9tIFwiLi9DaGF0RG9ja1wiO1xuaW1wb3J0IHsgUmVzaXplckhhbmRsZSB9IGZyb20gXCIuL1Jlc2l6ZXJIYW5kbGVcIjtcbmltcG9ydCB7IHVzZVJlc2l6YWJsZUNvbHVtbnMgfSBmcm9tIFwiLi91c2VSZXNpemFibGVDb2x1bW5zXCI7XG5pbXBvcnQgeyBncm91cEZvclZpZXcsIGl0ZW1Gb3JWaWV3LCBhbGxOYXZWaWV3cywgTkFWX0dST1VQUyB9IGZyb20gXCIuL25hdkNvbmZpZ1wiO1xuaW1wb3J0IHsgRU9TX05BVl9HUk9VUFMgfSBmcm9tIFwiLi9lb3NOYXZDb25maWdcIjtcbmltcG9ydCB7IGZpbHRlck5hdkdyb3VwcyB9IGZyb20gXCIuL25hdkZpbHRlclwiO1xuaW1wb3J0IHsgaXNSb3V0ZVZpc2libGUsIHJvdXRlQmFkZ2UgfSBmcm9tIFwiLi9yb3V0ZUNhcGFiaWxpdGllc1wiO1xuaW1wb3J0IHsgdXNlTmF2R3JvdXBzV2l0aENvdW50cyB9IGZyb20gXCIuL3VzZU5hdkdyb3Vwc1dpdGhDb3VudHNcIjtcbmltcG9ydCB7IHVzZUZsYWcgfSBmcm9tIFwiLi4vaG9va3MvdXNlRmxhZ1wiO1xuaW1wb3J0IHsgQnJlYWRjcnVtYnMgfSBmcm9tIFwiLi4vY29tcG9uZW50cy9mYWN0b3J5L0JyZWFkY3J1bWJzXCI7XG5pbXBvcnQgeyB1c2VIYXJuZXNzQW5pbWF0aW9uIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvc2NoZW1hdGljL3VzZUhhcm5lc3NBbmltYXRpb25cIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIi4uL2xpYi91dGlsc1wiO1xuaW1wb3J0IHR5cGUgeyBJZCB9IGZyb20gXCIuLi8uLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9kYXRhTW9kZWxcIjtcblxuY29uc3QgUk9VVEVfUFJFRklYID0gXCIvdjJcIjtcbmNvbnN0IENPTVBBQ1RfU0hFTExfUVVFUlkgPSBcIihtYXgtd2lkdGg6IDg5OXB4KVwiO1xuXG5leHBvcnQgZnVuY3Rpb24gdmlld0Zyb21QYXRoKHBhdGhuYW1lOiBzdHJpbmcsIHZhbGlkVmlld3M6IHN0cmluZ1tdKTogTWFpblZpZXcgfCBudWxsIHtcbiAgaWYgKCFwYXRobmFtZS5zdGFydHNXaXRoKGAke1JPVVRFX1BSRUZJWH0vYCkpIHJldHVybiBudWxsO1xuICBjb25zdCBjYW5kaWRhdGUgPSBwYXRobmFtZS5zbGljZShST1VURV9QUkVGSVgubGVuZ3RoICsgMSkuc3BsaXQoXCIvXCIpWzBdO1xuICByZXR1cm4gdmFsaWRWaWV3cy5pbmNsdWRlcyhjYW5kaWRhdGUpID8gKGNhbmRpZGF0ZSBhcyBNYWluVmlldykgOiBudWxsO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gc2hvdWxkRGVmZXJSb3V0ZVdyaXRlKFxuICBwYXRobmFtZTogc3RyaW5nLFxuICB2YWxpZFZpZXdzOiBzdHJpbmdbXSxcbiAgYWN0aXZlVmlldzogTWFpblZpZXdcbik6IGJvb2xlYW4ge1xuICBjb25zdCBwYXRoVmlldyA9IHZpZXdGcm9tUGF0aChwYXRobmFtZSwgdmFsaWRWaWV3cyk7XG4gIHJldHVybiBwYXRoVmlldyAhPT0gbnVsbCAmJiBwYXRoVmlldyAhPT0gYWN0aXZlVmlldztcbn1cblxuaW50ZXJmYWNlIEFwcFNoZWxsVjJQcm9wcyB7XG4gIGFjdGl2ZVZpZXc6IE1haW5WaWV3O1xuICBvbk5hdmlnYXRlOiAodmlldzogTWFpblZpZXcpID0+IHZvaWQ7XG4gIHdvcmtzcGFjZVN3aXRjaGVyOiBSZWFjdE5vZGU7XG4gIG9uT3BlblNlYXJjaDogKCkgPT4gdm9pZDtcbiAgcGVuZGluZ0FwcHJvdmFsczogbnVtYmVyO1xuICBvbk9wZW5BcHByb3ZhbHM6ICgpID0+IHZvaWQ7XG4gIGhlYWRlckFjdGlvbnM/OiBSZWFjdE5vZGU7XG4gIGZvb3Rlcj86IFJlYWN0Tm9kZTtcbiAgcHJvamVjdElkPzogSWQ8XCJwcm9qZWN0c1wiPiB8IG51bGw7XG4gIGNoaWxkcmVuOiBSZWFjdE5vZGU7XG59XG5cbi8qKlxuICogU29mdHdhcmUgRmFjdG9yeSBzaGVsbDogcmVzaXphYmxlIG5hdiB8IG1haW4gfCBjaGF0IGRvY2sgKHdha3UtYWdlbnQgMy1jb2x1bW4pLlxuICovXG5leHBvcnQgZnVuY3Rpb24gQXBwU2hlbGxWMih7XG4gIGFjdGl2ZVZpZXcsXG4gIG9uTmF2aWdhdGUsXG4gIHdvcmtzcGFjZVN3aXRjaGVyLFxuICBvbk9wZW5TZWFyY2gsXG4gIHBlbmRpbmdBcHByb3ZhbHMsXG4gIG9uT3BlbkFwcHJvdmFscyxcbiAgaGVhZGVyQWN0aW9ucyxcbiAgZm9vdGVyLFxuICBwcm9qZWN0SWQsXG4gIGNoaWxkcmVuLFxufTogQXBwU2hlbGxWMlByb3BzKTogSlNYLkVsZW1lbnQge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcbiAgY29uc3Qgc3luY2luZ0Zyb21VcmwgPSB1c2VSZWYoZmFsc2UpO1xuICBjb25zdCBbY29tcGFjdFNoZWxsLCBzZXRDb21wYWN0U2hlbGxdID0gdXNlU3RhdGUoKCkgPT5cbiAgICB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHdpbmRvdy5tYXRjaE1lZGlhKENPTVBBQ1RfU0hFTExfUVVFUlkpLm1hdGNoZXNcbiAgKTtcbiAgY29uc3QgW21vYmlsZU5hdk9wZW4sIHNldE1vYmlsZU5hdk9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbbW9iaWxlRG9ja09wZW4sIHNldE1vYmlsZURvY2tPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBjb2x1bW5zID0gdXNlUmVzaXphYmxlQ29sdW1ucygpO1xuICBjb25zdCB7IHN0YXR1c0xhYmVsIH0gPSB1c2VIYXJuZXNzQW5pbWF0aW9uKHByb2plY3RJZCA/PyB1bmRlZmluZWQpO1xuXG4gIGNvbnN0IGVvc1ByZXZpZXcgPSB1c2VGbGFnKFwiZW9zLmNvbW1hbmQtY2VudGVyLXByZXZpZXdcIik7XG4gIGNvbnN0IHNob3dDb250cm9sU3R1YnMgPSB1c2VGbGFnKFwidWkuY29udHJvbC5zdHVic1wiKTtcbiAgY29uc3Qgc2hvd1ByZXZpZXdSb3V0ZXMgPSB1c2VGbGFnKFwidWkubmF2aWdhdGlvbi5wcmV2aWV3c1wiKTtcbiAgY29uc3Qgc2hvd0RlbW9Sb3V0ZXMgPSB1c2VGbGFnKFwidWkubmF2aWdhdGlvbi5kZW1vLXJvdXRlc1wiKTtcbiAgY29uc3QgYmFzZU5hdkdyb3VwcyA9IGVvc1ByZXZpZXcgPyBFT1NfTkFWX0dST1VQUyA6IE5BVl9HUk9VUFM7XG4gIGNvbnN0IGZpbHRlcmVkR3JvdXBzID0gZmlsdGVyTmF2R3JvdXBzKGJhc2VOYXZHcm91cHMsIHtcbiAgICBzaG93Q29udHJvbFN0dWJzLFxuICAgIGVuZm9yY2VSb3V0ZUNhcGFiaWxpdGllczogZW9zUHJldmlldyxcbiAgICBzaG93UHJldmlld1JvdXRlcyxcbiAgICBzaG93RGVtb1JvdXRlcyxcbiAgfSk7XG4gIGNvbnN0IG5hdkdyb3VwcyA9IHVzZU5hdkdyb3Vwc1dpdGhDb3VudHMoZmlsdGVyZWRHcm91cHMsIHByb2plY3RJZCk7XG4gIGNvbnN0IHZhbGlkVmlld3MgPSBbXG4gICAgLi4ubmV3IFNldChbXG4gICAgICAuLi5iYXNlTmF2R3JvdXBzLmZsYXRNYXAoKGcpID0+IGcuaXRlbXMubWFwKChpKSA9PiBpLnZpZXcgYXMgc3RyaW5nKSksXG4gICAgICAuLi5hbGxOYXZWaWV3cygpLFxuICAgICAgXCJhdXRvbWF0aW9uLXJ1bnNcIixcbiAgICBdKSxcbiAgXTtcbiAgY29uc3QgZ3JvdXAgPVxuICAgIG5hdkdyb3Vwcy5maW5kKChnKSA9PiBnLml0ZW1zLnNvbWUoKGkpID0+IGkudmlldyA9PT0gYWN0aXZlVmlldykpID8/XG4gICAgZ3JvdXBGb3JWaWV3KGFjdGl2ZVZpZXcpO1xuICBjb25zdCBpdGVtID1cbiAgICBuYXZHcm91cHMuZmxhdE1hcCgoZykgPT4gZy5pdGVtcykuZmluZCgoaSkgPT4gaS52aWV3ID09PSBhY3RpdmVWaWV3KSA/P1xuICAgIGl0ZW1Gb3JWaWV3KGFjdGl2ZVZpZXcpO1xuICBjb25zdCBjcnVtYnMgPSBbXG4gICAgLi4uKGdyb3VwID8gW3sgbGFiZWw6IGdyb3VwLmxhYmVsIH1dIDogW10pLFxuICAgIC4uLihpdGVtID8gW3sgbGFiZWw6IGl0ZW0ubGFiZWwsIGN1cnJlbnQ6IHRydWUgfV0gOiBbXSksXG4gIF07XG4gIGNvbnN0IGFjdGl2ZVJvdXRlQmFkZ2UgPSBlb3NQcmV2aWV3ID8gcm91dGVCYWRnZShhY3RpdmVWaWV3KSA6IHVuZGVmaW5lZDtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHBhdGhWaWV3ID0gdmlld0Zyb21QYXRoKGxvY2F0aW9uLnBhdGhuYW1lLCB2YWxpZFZpZXdzKTtcbiAgICBpZiAocGF0aFZpZXcgJiYgcGF0aFZpZXcgIT09IGFjdGl2ZVZpZXcpIHtcbiAgICAgIHN5bmNpbmdGcm9tVXJsLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgb25OYXZpZ2F0ZShwYXRoVmlldyk7XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgW2xvY2F0aW9uLnBhdGhuYW1lLCB2YWxpZFZpZXdzLmpvaW4oXCIsXCIpXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAvLyBMZXQgdGhlIFVSTCDihpIgc3RhdGUgZWZmZWN0IHNldHRsZSBiZWZvcmUgd3JpdGluZyBzdGF0ZSBiYWNrIHRvIHRoZSBVUkwuXG4gICAgLy8gV2l0aG91dCB0aGlzIGd1YXJkIGEgcGVyc2lzdGVkIHZpZXcgY2FuIHJlcGxhY2UgYSBkaXJlY3QgZGVlcCBsaW5rIG9uXG4gICAgLy8gaW5pdGlhbCByZW5kZXIgKGZvciBleGFtcGxlIC92Mi9hZ2VudHMgYmVjb21pbmcgL3YyL2NvbW1hbmQtY2VudGVyKS5cbiAgICBpZiAoc2hvdWxkRGVmZXJSb3V0ZVdyaXRlKGxvY2F0aW9uLnBhdGhuYW1lLCB2YWxpZFZpZXdzLCBhY3RpdmVWaWV3KSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoXG4gICAgICBlb3NQcmV2aWV3ICYmXG4gICAgICAhaXNSb3V0ZVZpc2libGUoYWN0aXZlVmlldywgeyBzaG93UHJldmlld1JvdXRlcywgc2hvd0RlbW9Sb3V0ZXMgfSlcbiAgICApIHtcbiAgICAgIG9uTmF2aWdhdGUoXCJjb21tYW5kLWNlbnRlclwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHN5bmNpbmdGcm9tVXJsLmN1cnJlbnQpIHtcbiAgICAgIHN5bmNpbmdGcm9tVXJsLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgaXNBdXRvbWF0aW9uRGV0YWlsID0gYWN0aXZlVmlldyA9PT0gXCJhdXRvbWF0aW9uc1wiXG4gICAgICAmJiBsb2NhdGlvbi5wYXRobmFtZS5zdGFydHNXaXRoKGAke1JPVVRFX1BSRUZJWH0vYXV0b21hdGlvbnMvYCk7XG4gICAgY29uc3QgaXNBdXRvbWF0aW9uUnVuRGV0YWlsID0gYWN0aXZlVmlldyA9PT0gXCJhdXRvbWF0aW9uLXJ1bnNcIlxuICAgICAgJiYgbG9jYXRpb24ucGF0aG5hbWUuc3RhcnRzV2l0aChgJHtST1VURV9QUkVGSVh9L2F1dG9tYXRpb24tcnVucy9gKTtcbiAgICBpZiAoaXNBdXRvbWF0aW9uRGV0YWlsIHx8IGlzQXV0b21hdGlvblJ1bkRldGFpbCkgcmV0dXJuO1xuICAgIGNvbnN0IGV4cGVjdGVkID0gYCR7Uk9VVEVfUFJFRklYfS8ke2FjdGl2ZVZpZXd9YDtcbiAgICBpZiAobG9jYXRpb24ucGF0aG5hbWUgIT09IGV4cGVjdGVkKSB7XG4gICAgICBuYXZpZ2F0ZSh7IHBhdGhuYW1lOiBleHBlY3RlZCwgc2VhcmNoOiBsb2NhdGlvbi5zZWFyY2ggfSwgeyByZXBsYWNlOiB0cnVlIH0pO1xuICAgIH1cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gIH0sIFtcbiAgICBhY3RpdmVWaWV3LFxuICAgIGVvc1ByZXZpZXcsXG4gICAgbG9jYXRpb24ucGF0aG5hbWUsXG4gICAgbG9jYXRpb24uc2VhcmNoLFxuICAgIHNob3dEZW1vUm91dGVzLFxuICAgIHNob3dQcmV2aWV3Um91dGVzLFxuICBdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnRvZ2dsZShcInNoZWxsLXJlc2l6aW5nXCIsIGNvbHVtbnMucmVzaXppbmcpO1xuICAgIHJldHVybiAoKSA9PiBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5yZW1vdmUoXCJzaGVsbC1yZXNpemluZ1wiKTtcbiAgfSwgW2NvbHVtbnMucmVzaXppbmddKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IG1lZGlhID0gd2luZG93Lm1hdGNoTWVkaWEoQ09NUEFDVF9TSEVMTF9RVUVSWSk7XG4gICAgY29uc3Qgc3luYyA9IChldmVudDogTWVkaWFRdWVyeUxpc3RFdmVudCB8IE1lZGlhUXVlcnlMaXN0KSA9PiB7XG4gICAgICBzZXRDb21wYWN0U2hlbGwoZXZlbnQubWF0Y2hlcyk7XG4gICAgICBpZiAoIWV2ZW50Lm1hdGNoZXMpIHtcbiAgICAgICAgc2V0TW9iaWxlTmF2T3BlbihmYWxzZSk7XG4gICAgICAgIHNldE1vYmlsZURvY2tPcGVuKGZhbHNlKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgc3luYyhtZWRpYSk7XG4gICAgbWVkaWEuYWRkRXZlbnRMaXN0ZW5lcihcImNoYW5nZVwiLCBzeW5jKTtcbiAgICByZXR1cm4gKCkgPT4gbWVkaWEucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImNoYW5nZVwiLCBzeW5jKTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IG5hdmlnYXRlRnJvbVNpZGViYXIgPSAodmlldzogTWFpblZpZXcpID0+IHtcbiAgICBvbk5hdmlnYXRlKHZpZXcpO1xuICAgIGNvbnN0IGV4cGVjdGVkID0gYCR7Uk9VVEVfUFJFRklYfS8ke3ZpZXd9YDtcbiAgICBpZiAobG9jYXRpb24ucGF0aG5hbWUgIT09IGV4cGVjdGVkKSB7XG4gICAgICBuYXZpZ2F0ZSh7IHBhdGhuYW1lOiBleHBlY3RlZCwgc2VhcmNoOiBsb2NhdGlvbi5zZWFyY2ggfSk7XG4gICAgfVxuICAgIHNldE1vYmlsZU5hdk9wZW4oZmFsc2UpO1xuICB9O1xuXG4gIGNvbnN0IGFyY2hTdGF0dXMgPSBzdGF0dXNMYWJlbCA/IChcbiAgICA8PlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2NoZW1hdGljLWxpdmUtZG90XCIgYXJpYS1oaWRkZW4gLz5cbiAgICAgIHtzdGF0dXNMYWJlbH1cbiAgICA8Lz5cbiAgKSA6IG51bGw7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNoZWxsLXYyIGZsZXggaC1zY3JlZW4gb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICB7Y29tcGFjdFNoZWxsID8gKFxuICAgICAgICBtb2JpbGVOYXZPcGVuID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiQ2xvc2UgbmF2aWdhdGlvblwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctYmxhY2svNjVcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNb2JpbGVOYXZPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgaC1mdWxsIHctW21pbig4NnZ3LDMyMHB4KV0gc2hhZG93LTJ4bFwiPlxuICAgICAgICAgICAgICA8U2lkZWJhclxuICAgICAgICAgICAgICAgIHdpZHRoPXtNYXRoLm1pbihjb2x1bW5zLm5hdldpZHRoLCAzMjApfVxuICAgICAgICAgICAgICAgIGdyb3Vwcz17bmF2R3JvdXBzfVxuICAgICAgICAgICAgICAgIGFjdGl2ZVZpZXc9e2FjdGl2ZVZpZXd9XG4gICAgICAgICAgICAgICAgb25OYXZpZ2F0ZT17bmF2aWdhdGVGcm9tU2lkZWJhcn1cbiAgICAgICAgICAgICAgICBvbk9wZW5TZWFyY2g9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIHNldE1vYmlsZU5hdk9wZW4oZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgb25PcGVuU2VhcmNoKCk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICB3b3Jrc3BhY2VTd2l0Y2hlcj17d29ya3NwYWNlU3dpdGNoZXJ9XG4gICAgICAgICAgICAgICAgZm9vdGVyPXtmb290ZXJ9XG4gICAgICAgICAgICAgICAgb25IaWRlPXsoKSA9PiBzZXRNb2JpbGVOYXZPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogbnVsbFxuICAgICAgKSA6ICFjb2x1bW5zLm5hdkhpZGRlbiA/IChcbiAgICAgICAgPD5cbiAgICAgICAgICA8U2lkZWJhclxuICAgICAgICAgICAgd2lkdGg9e2NvbHVtbnMubmF2V2lkdGh9XG4gICAgICAgICAgICBncm91cHM9e25hdkdyb3Vwc31cbiAgICAgICAgICAgIGFjdGl2ZVZpZXc9e2FjdGl2ZVZpZXd9XG4gICAgICAgICAgICBvbk5hdmlnYXRlPXtuYXZpZ2F0ZUZyb21TaWRlYmFyfVxuICAgICAgICAgICAgb25PcGVuU2VhcmNoPXtvbk9wZW5TZWFyY2h9XG4gICAgICAgICAgICB3b3Jrc3BhY2VTd2l0Y2hlcj17d29ya3NwYWNlU3dpdGNoZXJ9XG4gICAgICAgICAgICBmb290ZXI9e2Zvb3Rlcn1cbiAgICAgICAgICAgIG9uSGlkZT17KCkgPT4gY29sdW1ucy5zZXROYXZIaWRkZW4odHJ1ZSl9XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8UmVzaXplckhhbmRsZVxuICAgICAgICAgICAgb25SZXNpemU9e2NvbHVtbnMub25OYXZSZXNpemV9XG4gICAgICAgICAgICBvbkJlZ2luPXtjb2x1bW5zLmJlZ2luUmVzaXplfVxuICAgICAgICAgICAgb25FbmQ9e2NvbHVtbnMuZW5kUmVzaXplfVxuICAgICAgICAgICAgdGl0bGU9XCJEcmFnIHRvIHJlc2l6ZSBzaWRlYmFyXCJcbiAgICAgICAgICAvPlxuICAgICAgICA8Lz5cbiAgICAgICkgOiAoXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBjb2x1bW5zLnNldE5hdkhpZGRlbihmYWxzZSl9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgbGVmdC0zIHRvcC0zIHotMzAgZmxleCBoLVszMHB4XSB3LVszNHB4XSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xIHRleHQtaW5rLXNlY29uZGFyeSBzaGFkb3ctc20gaG92ZXI6dGV4dC1pbmtcIlxuICAgICAgICAgIHRpdGxlPVwiU2hvdyBzaWRlYmFyXCJcbiAgICAgICAgICBhcmlhLWxhYmVsPVwiU2hvdyBzaWRlYmFyXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxNZW51IHNpemU9ezE2fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICl9XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4tdy0wIGZsZXgtMSBmbGV4LWNvbFwiPlxuICAgICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImZsZXggaC0xMiBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yIGJvcmRlci1iIGJvcmRlci1saW5lIGJnLWFwcCBweC0zIHNtOnB4LTVcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLXctMCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIHtjb21wYWN0U2hlbGwgPyAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNb2JpbGVOYXZPcGVuKHRydWUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaC04IHctOCBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xIHRleHQtaW5rLXNlY29uZGFyeSBob3Zlcjp0ZXh0LWlua1wiXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIk9wZW4gbmF2aWdhdGlvblwiXG4gICAgICAgICAgICAgICAgYXJpYS1leHBhbmRlZD17bW9iaWxlTmF2T3Blbn1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxNZW51IHNpemU9ezE2fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICA8QnJlYWRjcnVtYnMgaXRlbXM9e2NydW1ic30gLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAge2FjdGl2ZVJvdXRlQmFkZ2UgPyAoXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNocmluay0wIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMSBweC0xLjUgcHktMC41IHRleHQtWzlweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMDZlbV0gdGV4dC1pbmstbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICB7YWN0aXZlUm91dGVCYWRnZX1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNocmluay0wIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAge2hlYWRlckFjdGlvbnN9XG4gICAgICAgICAgICB7Y29tcGFjdFNoZWxsID8gKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TW9iaWxlRG9ja09wZW4odHJ1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBoLTggdy04IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgdGV4dC1pbmstc2Vjb25kYXJ5IGhvdmVyOnRleHQtaW5rXCJcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiT3BlbiBjaGF0XCJcbiAgICAgICAgICAgICAgICBhcmlhLWV4cGFuZGVkPXttb2JpbGVEb2NrT3Blbn1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxNZXNzYWdlU3F1YXJlIHNpemU9ezE0fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgb25DbGljaz17b25PcGVuQXBwcm92YWxzfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgIFwiZmxleCBoLTggaXRlbXMtY2VudGVyIGdhcC0xLjUgcm91bmRlZC1sZyBib3JkZXIgcHgtMi41IHRleHQtWzEyLjVweF0gdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCIsXG4gICAgICAgICAgICAgICAgcGVuZGluZ0FwcHJvdmFscyA+IDBcbiAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItbGluZS1zdHJvbmcgYmctd2Fybi1zb2Z0IHRleHQtd2FyblwiXG4gICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLWxpbmUgdGV4dC1pbmstbXV0ZWQgaG92ZXI6dGV4dC1pbmstc2Vjb25kYXJ5XCJcbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD17XG4gICAgICAgICAgICAgICAgcGVuZGluZ0FwcHJvdmFscyA+IDBcbiAgICAgICAgICAgICAgICAgID8gYCR7cGVuZGluZ0FwcHJvdmFsc30gcGVuZGluZyBhcHByb3ZhbCR7cGVuZGluZ0FwcHJvdmFscyA9PT0gMSA/IFwiXCIgOiBcInNcIn1gXG4gICAgICAgICAgICAgICAgICA6IFwiT3BlbiBhcHByb3ZhbHNcIlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxCZWxsUmluZyBzaXplPXsxM30gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAge2NvbXBhY3RTaGVsbFxuICAgICAgICAgICAgICAgID8gcGVuZGluZ0FwcHJvdmFscyB8fCBudWxsXG4gICAgICAgICAgICAgICAgOiBwZW5kaW5nQXBwcm92YWxzID4gMFxuICAgICAgICAgICAgICAgICAgPyBgJHtwZW5kaW5nQXBwcm92YWxzfSBhcHByb3ZhbCR7cGVuZGluZ0FwcHJvdmFscyA9PT0gMSA/IFwiXCIgOiBcInNcIn1gXG4gICAgICAgICAgICAgICAgICA6IFwiQXBwcm92YWxzXCJ9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9oZWFkZXI+XG4gICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXggbWluLWgtMCBmbGV4LTEgb3ZlcmZsb3ctaGlkZGVuIGJnLWFwcFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2hlbGwtbWFpbiBmYWN0b3J5LXBhZ2UgbWluLWgtMCBtaW4tdy0wIGZsZXgtMSBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgICAgIHtjaGlsZHJlbn1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICB7IWNvbXBhY3RTaGVsbCAmJiAhY29sdW1ucy5kb2NrQ2xvc2VkID8gKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgPFJlc2l6ZXJIYW5kbGVcbiAgICAgICAgICAgICAgICBvblJlc2l6ZT17Y29sdW1ucy5vbkRvY2tSZXNpemV9XG4gICAgICAgICAgICAgICAgb25CZWdpbj17Y29sdW1ucy5iZWdpblJlc2l6ZX1cbiAgICAgICAgICAgICAgICBvbkVuZD17Y29sdW1ucy5lbmRSZXNpemV9XG4gICAgICAgICAgICAgICAgdGl0bGU9XCJEcmFnIHRvIHJlc2l6ZSBjaGF0XCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPENoYXREb2NrXG4gICAgICAgICAgICAgICAgd2lkdGg9e2NvbHVtbnMuZG9ja1dpZHRofVxuICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IGNvbHVtbnMuc2V0RG9ja0Nsb3NlZCh0cnVlKX1cbiAgICAgICAgICAgICAgICBwcm9qZWN0SWQ9e3Byb2plY3RJZH1cbiAgICAgICAgICAgICAgICBhcmNoU3RhdHVzPXthcmNoU3RhdHVzfVxuICAgICAgICAgICAgICAgIG9uTmF2aWdhdGU9e29uTmF2aWdhdGV9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApIDogIWNvbXBhY3RTaGVsbCA/IChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNvbHVtbnMuc2V0RG9ja0Nsb3NlZChmYWxzZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIHJpZ2h0LTMgdG9wLTE0IHotMzAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xIHB4LTMgcHktMS41IHRleHQtWzEycHhdIHRleHQtaW5rLXNlY29uZGFyeSBzaGFkb3ctc20gaG92ZXI6dGV4dC1pbmtcIlxuICAgICAgICAgICAgICB0aXRsZT1cIk9wZW4gY2hhdFwiXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJPcGVuIGNoYXRcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8TWVzc2FnZVNxdWFyZSBzaXplPXsxNH0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgQ2hhdFxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgIDwvbWFpbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7Y29tcGFjdFNoZWxsICYmIG1vYmlsZURvY2tPcGVuID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwiQ2xvc2UgY2hhdFwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWJsYWNrLzY1XCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vYmlsZURvY2tPcGVuKGZhbHNlKX1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCBoLWZ1bGwgdy1mdWxsIG1heC13LVs0NDBweF0gc2hhZG93LTJ4bFwiPlxuICAgICAgICAgICAgPENoYXREb2NrXG4gICAgICAgICAgICAgIHdpZHRoPVwiMTAwJVwiXG4gICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldE1vYmlsZURvY2tPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgcHJvamVjdElkPXtwcm9qZWN0SWR9XG4gICAgICAgICAgICAgIGFyY2hTdGF0dXM9e2FyY2hTdGF0dXN9XG4gICAgICAgICAgICAgIG9uTmF2aWdhdGU9eyh2aWV3KSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0TW9iaWxlRG9ja09wZW4oZmFsc2UpO1xuICAgICAgICAgICAgICAgIG9uTmF2aWdhdGUodmlldyk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiBudWxsfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvc2hlbGxWMi9BcHBTaGVsbFYyLnRzeCJ9