import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/TelemetryView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { Button } from "/src/components/ui/button.tsx";
import { Card } from "/src/components/ui/card.tsx";
import { PageHeader } from "/src/components/PageHeader.tsx";
import { StatusBadge } from "/src/components/factory/badges.tsx";
import { useToast } from "/src/Toast.tsx";
import { Activity, Zap, Filter, Radio, CheckCircle2 } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
function fmtTime(ts) {
  if (!ts) return "n/a";
  return new Date(ts).toLocaleString();
}
function compactJson(value) {
  if (value === void 0 || value === null) return "n/a";
  const s = JSON.stringify(value);
  return s.length <= 100 ? s : `${s.slice(0, 100)}…`;
}
function eventPillTone(type) {
  if (type.includes("FAILED") || type.includes("BLOCKED")) return "error";
  if (type.includes("STARTED") || type.includes("STEP")) return "info";
  if (type.includes("COMPLETED") || type.includes("DONE")) return "success";
  if (type.includes("DECISION")) return "info";
  return "neutral";
}
function EventTypePill({ value }) {
  return /* @__PURE__ */ jsxDEV(StatusBadge, { tone: eventPillTone(value), className: "whitespace-nowrap", children: value }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
    lineNumber: 53,
    columnNumber: 5
  }, this);
}
_c = EventTypePill;
export function TelemetryView({ projectId }) {
  _s();
  const { toast } = useToast();
  const [typeFilter, setTypeFilter] = useState("");
  const [windowMinutes, setWindowMinutes] = useState(60);
  const agents = useQuery(api.agents.listAll, projectId ? { projectId } : "skip");
  const events = useQuery(
    api["operations/opEvents"].listOpEvents,
    projectId ? { projectId, type: typeFilter || void 0, limit: 200 } : "skip"
  );
  const stats = useQuery(
    api["operations/opEvents"].getOpEventStats,
    projectId ? { projectId, windowMinutes } : "skip"
  );
  const evaluateWithARM = useMutation(api.policy.evaluateWithARM);
  const handleEmitTestEvent = async () => {
    const agent = (agents ?? [])[0];
    if (!agent) {
      toast("No agents available to emit telemetry.", true);
      return;
    }
    try {
      await evaluateWithARM({
        agentId: agent._id,
        actionType: "TOOL_CALL",
        toolName: "shell",
        toolArgs: { command: "echo telemetry_probe" },
        context: { source: "telemetry.ui" }
      });
      toast("Telemetry probe emitted via ARM policy evaluator.");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Failed to emit telemetry probe", true);
    }
  };
  const topTypes = stats?.topTypes ?? [];
  const totalEvents = stats?.total ?? 0;
  const inWindow = stats?.inWindow ?? 0;
  return /* @__PURE__ */ jsxDEV("section", { className: "flex min-h-0 flex-1 flex-col overflow-hidden bg-app", children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: "ARM Telemetry",
        description: inWindow > 0 ? `Live stream · ${inWindow} events in last ${windowMinutes}m` : "Operational events stream for runs, tool calls, workflow steps, and decision traces.",
        eyebrow: "Operations",
        actions: /* @__PURE__ */ jsxDEV(Button, { size: "sm", onClick: handleEmitTestEvent, variant: "outline", children: [
          /* @__PURE__ */ jsxDEV(Zap, { className: "h-3.5 w-3.5 mr-1.5", strokeWidth: 1.7 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
            lineNumber: 110,
            columnNumber: 13
          }, this),
          "Emit Test Event"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
          lineNumber: 109,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
        lineNumber: 100,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "mx-auto flex min-h-0 w-full max-w-[1200px] flex-1 flex-col gap-4 overflow-hidden px-6 pb-6 pt-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid shrink-0 grid-cols-2 gap-3 sm:grid-cols-4", children: [
        { icon: Activity, label: "Total Events", value: totalEvents },
        { icon: Radio, label: `Last ${windowMinutes}m`, value: inWindow },
        { icon: Filter, label: "Filtered Rows", value: (events ?? []).length },
        { icon: CheckCircle2, label: "Latest Event", value: stats?.latestTimestamp ? 1 : 0 }
      ].map(
        ({ icon: Icon, label, value }) => /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 mb-1.5", children: [
            /* @__PURE__ */ jsxDEV(Icon, { className: "h-3.5 w-3.5 text-ink-muted", strokeWidth: 1.6 }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
              lineNumber: 127,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[12.5px] font-medium text-ink-secondary", children: label }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
              lineNumber: 128,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
            lineNumber: 126,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[20px] font-semibold leading-none tabular-nums text-ink", children: value }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
            lineNumber: 130,
            columnNumber: 13
          }, this)
        ] }, label, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
          lineNumber: 125,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
        lineNumber: 118,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid min-h-0 flex-1 gap-4 overflow-hidden xl:grid-cols-[minmax(0,1fr)_320px]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto", children: [
          /* @__PURE__ */ jsxDEV(Card, { className: "overflow-hidden", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex shrink-0 items-center justify-between gap-3 overflow-x-auto flex-nowrap border-b border-line px-5 py-3", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "shrink-0 text-[15px] font-semibold text-ink", children: "Event Type Breakdown" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                lineNumber: 140,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex shrink-0 items-center gap-3 overflow-x-auto flex-nowrap", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(Filter, { className: "h-3 w-3 text-ink-muted", strokeWidth: 1.6 }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                    lineNumber: 143,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      className: "h-9 rounded-lg border border-line bg-surface-1 px-3 text-[13.5px] text-ink placeholder:text-ink-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring w-36",
                      placeholder: "Filter type…",
                      "aria-label": "Filter events by type",
                      value: typeFilter,
                      onChange: (e) => setTypeFilter(e.target.value)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                      lineNumber: 144,
                      columnNumber: 17
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                  lineNumber: 142,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    className: "h-9 rounded-lg border border-line bg-surface-1 px-3 text-[13.5px] text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                    "aria-label": "Time window",
                    value: windowMinutes,
                    onChange: (e) => setWindowMinutes(Number(e.target.value)),
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: 15, children: "Last 15m" }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                        lineNumber: 158,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: 60, children: "Last 60m" }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                        lineNumber: 159,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: 240, children: "Last 4h" }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                        lineNumber: 160,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: 1440, children: "Last 24h" }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                        lineNumber: 161,
                        columnNumber: 17
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                    lineNumber: 152,
                    columnNumber: 15
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                lineNumber: 141,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
              lineNumber: 139,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: topTypes.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-[13.5px] text-ink-muted text-center py-6", children: "No events captured yet." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
              lineNumber: 167,
              columnNumber: 17
            }, this) : /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3", children: topTypes.map(
              (row) => /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-line bg-surface-2 px-3 py-2.5", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-[11.5px] text-ink-muted font-medium mb-1 truncate", children: row.type }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                  lineNumber: 172,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-[20px] font-semibold leading-none text-ink tabular-nums", children: row.count }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                  lineNumber: 173,
                  columnNumber: 21
                }, this)
              ] }, row.type, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                lineNumber: 171,
                columnNumber: 19
              }, this)
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
              lineNumber: 169,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
              lineNumber: 165,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
            lineNumber: 138,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(Card, { className: "overflow-hidden", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-3 border-b border-line", children: /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-ink", children: "Recent Events" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
              lineNumber: 184,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
              lineNumber: 183,
              columnNumber: 11
            }, this),
            (events ?? []).length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "py-12 text-center", children: [
              /* @__PURE__ */ jsxDEV(Activity, { className: "h-8 w-8 text-ink-muted/30 mx-auto mb-2", strokeWidth: 1.6 }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                lineNumber: 188,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[13.5px] text-ink-muted", children: "No op events found." }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                lineNumber: 189,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
              lineNumber: 187,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV("div", { className: "overflow-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full min-w-[960px] border-collapse text-left text-[13px]", children: [
              /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-line", children: ["Timestamp", "Type", "Run", "Instance", "Version", "Payload"].map(
                (h) => /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2.5 text-[11.5px] font-medium uppercase tracking-[0.06em] text-ink-muted", children: h }, h, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                  lineNumber: 197,
                  columnNumber: 23
                }, this)
              ) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                lineNumber: 195,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                lineNumber: 194,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { children: (events ?? []).map(
                (event) => /* @__PURE__ */ jsxDEV(
                  "tr",
                  {
                    className: "border-b border-line last:border-b-0 hover:bg-surface-2 transition-colors duration-150",
                    children: [
                      /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5 font-mono text-ink-muted whitespace-nowrap", children: fmtTime(event.timestamp) }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                        lineNumber: 207,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5", children: /* @__PURE__ */ jsxDEV(EventTypePill, { value: event.type }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                        lineNumber: 208,
                        columnNumber: 51
                      }, this) }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                        lineNumber: 208,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5 font-mono text-ink-muted truncate max-w-[120px]", children: event.runId ?? "n/a" }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                        lineNumber: 209,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5 font-mono text-ink-muted truncate max-w-[120px]", children: event.instanceId ?? "n/a" }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                        lineNumber: 210,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5 font-mono text-ink-muted truncate max-w-[120px]", children: event.versionId ?? "n/a" }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                        lineNumber: 211,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5 text-ink-muted truncate max-w-[240px] font-mono", children: compactJson(event.payload) }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                        lineNumber: 212,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  event._id,
                  true,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                    lineNumber: 203,
                    columnNumber: 21
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
                lineNumber: 201,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
              lineNumber: 193,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
              lineNumber: 192,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
            lineNumber: 182,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
          lineNumber: 136,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-[15px] font-semibold text-ink", children: "Telemetry guidance" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
            lineNumber: 223,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-2 space-y-3 text-[13.5px] leading-relaxed text-ink-secondary", children: [
            /* @__PURE__ */ jsxDEV("p", { children: "Telemetry is useful only when it helps explain a decision, a failure, or a bottleneck. Treat spikes without narrative as a sign of poor instrumentation." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
              lineNumber: 225,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "Use the time window to isolate operator incidents first, then widen the window only when you need trend context." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
              lineNumber: 226,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
            lineNumber: 224,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
          lineNumber: 222,
          columnNumber: 7
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
        lineNumber: 135,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
      lineNumber: 117,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx",
    lineNumber: 99,
    columnNumber: 5
  }, this);
}
_s(TelemetryView, "XVlcN404uzwFCTClR3LyaqiDPPo=", false, function() {
  return [useToast, useQuery, useQuery, useQuery, useMutation];
});
_c2 = TelemetryView;
var _c, _c2;
$RefreshReg$(_c, "EventTypePill");
$RefreshReg$(_c2, "TelemetryView");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TelemetryView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUNJOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpDSixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLFdBQVc7QUFFcEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxtQkFBMEM7QUFDbkQsU0FBU0MsZ0JBQWdCO0FBRXpCLFNBQVNDLFVBQVVDLEtBQUtDLFFBQVFDLE9BQU9DLG9CQUFvQjtBQUUzRCxTQUFTQyxRQUFRQyxJQUFhO0FBQzVCLE1BQUksQ0FBQ0EsR0FBSSxRQUFPO0FBQ2hCLFNBQU8sSUFBSUMsS0FBS0QsRUFBRSxFQUFFRSxlQUFlO0FBQ3JDO0FBRUEsU0FBU0MsWUFBWUMsT0FBZ0I7QUFDbkMsTUFBSUEsVUFBVUMsVUFBYUQsVUFBVSxLQUFNLFFBQU87QUFDbEQsUUFBTUUsSUFBSUMsS0FBS0MsVUFBVUosS0FBSztBQUM5QixTQUFPRSxFQUFFRyxVQUFVLE1BQU1ILElBQUksR0FBR0EsRUFBRUksTUFBTSxHQUFHLEdBQUcsQ0FBQztBQUNqRDtBQUVBLFNBQVNDLGNBQWNDLE1BQXdDO0FBQzdELE1BQUlBLEtBQUtDLFNBQVMsUUFBUSxLQUFLRCxLQUFLQyxTQUFTLFNBQVMsRUFBRyxRQUFPO0FBQ2hFLE1BQUlELEtBQUtDLFNBQVMsU0FBUyxLQUFLRCxLQUFLQyxTQUFTLE1BQU0sRUFBRyxRQUFPO0FBQzlELE1BQUlELEtBQUtDLFNBQVMsV0FBVyxLQUFLRCxLQUFLQyxTQUFTLE1BQU0sRUFBRyxRQUFPO0FBQ2hFLE1BQUlELEtBQUtDLFNBQVMsVUFBVSxFQUFHLFFBQU87QUFDdEMsU0FBTztBQUNUO0FBRUEsU0FBU0MsY0FBYyxFQUFFVixNQUF5QixHQUFHO0FBQ25ELFNBQ0UsdUJBQUMsZUFBWSxNQUFNTyxjQUFjUCxLQUFLLEdBQUcsV0FBVSxxQkFDaERBLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUNXLEtBTlFEO0FBUUYsZ0JBQVNFLGNBQWMsRUFBRUMsVUFBZ0QsR0FBRztBQUFBQyxLQUFBO0FBQ2pGLFFBQU0sRUFBRUMsTUFBTSxJQUFJMUIsU0FBUztBQUMzQixRQUFNLENBQUMyQixZQUFZQyxhQUFhLElBQUlwQyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDcUMsZUFBZUMsZ0JBQWdCLElBQUl0QyxTQUFTLEVBQUU7QUFFckQsUUFBTXVDLFNBQVNyQyxTQUFTQyxJQUFJb0MsT0FBT0MsU0FBU1IsWUFBWSxFQUFFQSxVQUFVLElBQUksTUFBTTtBQUM5RSxRQUFNUyxTQUFTdkM7QUFBQUEsSUFDYkMsSUFBSSxxQkFBcUIsRUFBRXVDO0FBQUFBLElBQzNCVixZQUNJLEVBQUVBLFdBQVdMLE1BQU1RLGNBQWNmLFFBQVd1QixPQUFPLElBQUksSUFDdkQ7QUFBQSxFQUNOO0FBQ0EsUUFBTUMsUUFBUTFDO0FBQUFBLElBQ1pDLElBQUkscUJBQXFCLEVBQUUwQztBQUFBQSxJQUMzQmIsWUFBWSxFQUFFQSxXQUFXSyxjQUFjLElBQUk7QUFBQSxFQUM3QztBQUNBLFFBQU1TLGtCQUFrQjdDLFlBQVlFLElBQUk0QyxPQUFPRCxlQUFlO0FBRTlELFFBQU1FLHNCQUFzQixZQUFZO0FBQ3RDLFVBQU1DLFNBQVNWLFVBQVUsSUFBSSxDQUFDO0FBQzlCLFFBQUksQ0FBQ1UsT0FBTztBQUFFZixZQUFNLDBDQUEwQyxJQUFJO0FBQUc7QUFBQSxJQUFRO0FBQzdFLFFBQUk7QUFDRixZQUFNWSxnQkFBZ0I7QUFBQSxRQUNwQkksU0FBU0QsTUFBTUU7QUFBQUEsUUFDZkMsWUFBWTtBQUFBLFFBQ1pDLFVBQVU7QUFBQSxRQUNWQyxVQUFVLEVBQUVDLFNBQVMsdUJBQXVCO0FBQUEsUUFDNUNDLFNBQVMsRUFBRUMsUUFBUSxlQUFlO0FBQUEsTUFDcEMsQ0FBQztBQUNEdkIsWUFBTSxtREFBbUQ7QUFBQSxJQUMzRCxTQUFTd0IsR0FBRztBQUNWeEIsWUFBTXdCLGFBQWFDLFFBQVFELEVBQUVFLFVBQVUsa0NBQWtDLElBQUk7QUFBQSxJQUMvRTtBQUFBLEVBQ0Y7QUFFQSxRQUFNQyxXQUE4Q2pCLE9BQU9pQixZQUFZO0FBQ3ZFLFFBQU1DLGNBQWNsQixPQUFPbUIsU0FBUztBQUNwQyxRQUFNQyxXQUFjcEIsT0FBT29CLFlBQVk7QUFFdkMsU0FDRSx1QkFBQyxhQUFRLFdBQVUsdURBQ2pCO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLGFBQ0VBLFdBQVcsSUFDUCxpQkFBaUJBLFFBQVEsbUJBQW1CM0IsYUFBYSxNQUN6RDtBQUFBLFFBRU4sU0FBUTtBQUFBLFFBQ1IsU0FDRSx1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFTVyxxQkFBcUIsU0FBUSxXQUN0RDtBQUFBLGlDQUFDLE9BQUksV0FBVSxzQkFBcUIsYUFBYSxPQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRDtBQUFBO0FBQUEsYUFEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUE7QUFBQSxNQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWFHO0FBQUEsSUFJSCx1QkFBQyxTQUFJLFdBQVUsbUdBQ2Y7QUFBQSw2QkFBQyxTQUFJLFdBQVUsa0RBQ1o7QUFBQSxRQUNDLEVBQUVpQixNQUFNeEQsVUFBY3lELE9BQU8sZ0JBQW9CL0MsT0FBTzJDLFlBQVk7QUFBQSxRQUNwRSxFQUFFRyxNQUFNckQsT0FBY3NELE9BQU8sUUFBUTdCLGFBQWEsS0FBS2xCLE9BQU82QyxTQUFTO0FBQUEsUUFDdkUsRUFBRUMsTUFBTXRELFFBQWN1RCxPQUFPLGlCQUFvQi9DLFFBQVFzQixVQUFVLElBQUlqQixPQUFPO0FBQUEsUUFDOUUsRUFBRXlDLE1BQU1wRCxjQUFjcUQsT0FBTyxnQkFBb0IvQyxPQUFPeUIsT0FBT3VCLGtCQUFrQixJQUFJLEVBQUU7QUFBQSxNQUFDLEVBQ3hGQztBQUFBQSxRQUFJLENBQUMsRUFBRUgsTUFBTUksTUFBTUgsT0FBTy9DLE1BQU0sTUFDaEMsdUJBQUMsUUFBaUIsV0FBVSxPQUMxQjtBQUFBLGlDQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLG1DQUFDLFFBQUssV0FBVSw4QkFBNkIsYUFBYSxPQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RDtBQUFBLFlBQzlELHVCQUFDLFVBQUssV0FBVSxnREFBZ0QrQyxtQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0U7QUFBQSxlQUZ4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsZ0VBQWdFL0MsbUJBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1GO0FBQUEsYUFMMUUrQyxPQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLE1BQ0QsS0FkSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxnRkFDZjtBQUFBLCtCQUFDLFNBQUksV0FBVSxzREFFYjtBQUFBLGlDQUFDLFFBQUssV0FBVSxtQkFDZDtBQUFBLG1DQUFDLFNBQUksV0FBVSwrR0FDYjtBQUFBLHFDQUFDLE9BQUUsV0FBVSwrQ0FBOEMsb0NBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStFO0FBQUEsY0FDL0UsdUJBQUMsU0FBSSxXQUFVLGdFQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEseUNBQUMsVUFBTyxXQUFVLDBCQUF5QixhQUFhLE9BQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTREO0FBQUEsa0JBQzVEO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixhQUFZO0FBQUEsc0JBQ1osY0FBVztBQUFBLHNCQUNYLE9BQU8vQjtBQUFBQSxzQkFDUCxVQUFVLENBQUN1QixNQUFNdEIsY0FBY3NCLEVBQUVZLE9BQU9uRCxLQUFLO0FBQUE7QUFBQSxvQkFML0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtpRDtBQUFBLHFCQVBuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVNBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLGNBQVc7QUFBQSxvQkFDWCxPQUFPa0I7QUFBQUEsb0JBQ1AsVUFBVSxDQUFDcUIsTUFBTXBCLGlCQUFpQmlDLE9BQU9iLEVBQUVZLE9BQU9uRCxLQUFLLENBQUM7QUFBQSxvQkFFeEQ7QUFBQSw2Q0FBQyxZQUFPLE9BQU8sSUFBSSx3QkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBMkI7QUFBQSxzQkFDM0IsdUJBQUMsWUFBTyxPQUFPLElBQUksd0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTJCO0FBQUEsc0JBQzNCLHVCQUFDLFlBQU8sT0FBTyxLQUFLLHVCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEyQjtBQUFBLHNCQUMzQix1QkFBQyxZQUFPLE9BQU8sTUFBTSx3QkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkI7QUFBQTtBQUFBO0FBQUEsa0JBVC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFVQTtBQUFBLG1CQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGlCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLE9BQ1owQyxtQkFBU3JDLFdBQVcsSUFDbkIsdUJBQUMsT0FBRSxXQUFVLGlEQUFnRCx1Q0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0YsSUFFcEYsdUJBQUMsU0FBSSxXQUFVLHlDQUNacUMsbUJBQVNPO0FBQUFBLGNBQUksQ0FBQ0ksUUFDYix1QkFBQyxTQUFtQixXQUFVLDBEQUM1QjtBQUFBLHVDQUFDLE9BQUUsV0FBVSwwREFBMERBLGNBQUk3QyxRQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnRjtBQUFBLGdCQUNoRix1QkFBQyxPQUFFLFdBQVUsZ0VBQWdFNkMsY0FBSUMsU0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUY7QUFBQSxtQkFGL0VELElBQUk3QyxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxZQUNELEtBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQSxLQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYUE7QUFBQSxlQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlDQTtBQUFBLFVBR0EsdUJBQUMsUUFBSyxXQUFVLG1CQUNkO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGtDQUNiLGlDQUFDLE9BQUUsV0FBVSxzQ0FBcUMsNkJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStELEtBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxhQUNFYyxVQUFVLElBQUlqQixXQUFXLElBQ3pCLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFlBQVMsV0FBVSwwQ0FBeUMsYUFBYSxPQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4RTtBQUFBLGNBQzlFLHVCQUFDLE9BQUUsV0FBVSxnQ0FBK0IsbUNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStEO0FBQUEsaUJBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsSUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2IsaUNBQUMsV0FBTSxXQUFVLDhEQUNmO0FBQUEscUNBQUMsV0FDQyxpQ0FBQyxRQUFHLFdBQVUsd0JBQ1gsV0FBQyxhQUFhLFFBQVEsT0FBTyxZQUFZLFdBQVcsU0FBUyxFQUFFNEM7QUFBQUEsZ0JBQUksQ0FBQ00sTUFDbkUsdUJBQUMsUUFBVyxXQUFVLG9GQUFvRkEsZUFBakdBLEdBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEc7QUFBQSxjQUM3RyxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUEsS0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BO0FBQUEsY0FDQSx1QkFBQyxXQUNHakMscUJBQVUsSUFBSTJCO0FBQUFBLGdCQUFJLENBQUNPLFVBQ25CO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUVDLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFFBQUcsV0FBVSwwREFBMEQ3RCxrQkFBUTZELE1BQU1DLFNBQVMsS0FBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUc7QUFBQSxzQkFDakcsdUJBQUMsUUFBRyxXQUFVLGVBQWMsaUNBQUMsaUJBQWMsT0FBT0QsTUFBTWhELFFBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDLEtBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdFO0FBQUEsc0JBQ2hFLHVCQUFDLFFBQUcsV0FBVSwrREFBK0RnRCxnQkFBTUUsU0FBUyxTQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFrRztBQUFBLHNCQUNsRyx1QkFBQyxRQUFHLFdBQVUsK0RBQStERixnQkFBTUcsY0FBYyxTQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF1RztBQUFBLHNCQUN2Ryx1QkFBQyxRQUFHLFdBQVUsK0RBQStESCxnQkFBTUksYUFBYSxTQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFzRztBQUFBLHNCQUN0Ryx1QkFBQyxRQUFHLFdBQVUsK0RBQStEN0Qsc0JBQVl5RCxNQUFNSyxPQUFPLEtBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXdHO0FBQUE7QUFBQTtBQUFBLGtCQVJuR0wsTUFBTXhCO0FBQUFBLGtCQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVUE7QUFBQSxjQUNELEtBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFjQTtBQUFBLGlCQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVCQSxLQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlCQTtBQUFBLGVBbkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUNBO0FBQUEsYUFuRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9GQTtBQUFBLFFBRUEsdUJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsc0NBQXFDLGtDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRTtBQUFBLFVBQ3RFLHVCQUFDLFNBQUksV0FBVSxtRUFDYjtBQUFBLG1DQUFDLE9BQUUsd0tBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMko7QUFBQSxZQUMzSix1QkFBQyxPQUFFLGdJQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1IO0FBQUEsZUFGckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsV0E3RkE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThGQTtBQUFBLFNBaEhBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpSEE7QUFBQSxPQW5JRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0lBO0FBRUo7QUFBQ2xCLEdBOUtlRixlQUFhO0FBQUEsVUFDVHZCLFVBSUhOLFVBQ0FBLFVBTURBLFVBSVVELFdBQVc7QUFBQTtBQUFBLE1BaEJyQjhCO0FBQWEsSUFBQUQsSUFBQW1EO0FBQUEsYUFBQW5ELElBQUE7QUFBQSxhQUFBbUQsS0FBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsImFwaSIsIkJ1dHRvbiIsIkNhcmQiLCJQYWdlSGVhZGVyIiwiU3RhdHVzQmFkZ2UiLCJ1c2VUb2FzdCIsIkFjdGl2aXR5IiwiWmFwIiwiRmlsdGVyIiwiUmFkaW8iLCJDaGVja0NpcmNsZTIiLCJmbXRUaW1lIiwidHMiLCJEYXRlIiwidG9Mb2NhbGVTdHJpbmciLCJjb21wYWN0SnNvbiIsInZhbHVlIiwidW5kZWZpbmVkIiwicyIsIkpTT04iLCJzdHJpbmdpZnkiLCJsZW5ndGgiLCJzbGljZSIsImV2ZW50UGlsbFRvbmUiLCJ0eXBlIiwiaW5jbHVkZXMiLCJFdmVudFR5cGVQaWxsIiwiX2MiLCJUZWxlbWV0cnlWaWV3IiwicHJvamVjdElkIiwiX3MiLCJ0b2FzdCIsInR5cGVGaWx0ZXIiLCJzZXRUeXBlRmlsdGVyIiwid2luZG93TWludXRlcyIsInNldFdpbmRvd01pbnV0ZXMiLCJhZ2VudHMiLCJsaXN0QWxsIiwiZXZlbnRzIiwibGlzdE9wRXZlbnRzIiwibGltaXQiLCJzdGF0cyIsImdldE9wRXZlbnRTdGF0cyIsImV2YWx1YXRlV2l0aEFSTSIsInBvbGljeSIsImhhbmRsZUVtaXRUZXN0RXZlbnQiLCJhZ2VudCIsImFnZW50SWQiLCJfaWQiLCJhY3Rpb25UeXBlIiwidG9vbE5hbWUiLCJ0b29sQXJncyIsImNvbW1hbmQiLCJjb250ZXh0Iiwic291cmNlIiwiZSIsIkVycm9yIiwibWVzc2FnZSIsInRvcFR5cGVzIiwidG90YWxFdmVudHMiLCJ0b3RhbCIsImluV2luZG93IiwiaWNvbiIsImxhYmVsIiwibGF0ZXN0VGltZXN0YW1wIiwibWFwIiwiSWNvbiIsInRhcmdldCIsIk51bWJlciIsInJvdyIsImNvdW50IiwiaCIsImV2ZW50IiwidGltZXN0YW1wIiwicnVuSWQiLCJpbnN0YW5jZUlkIiwidmVyc2lvbklkIiwicGF5bG9hZCIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUZWxlbWV0cnlWaWV3LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5IH0gZnJvbSBcImNvbnZleC9yZWFjdFwiO1xuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2FwaVwiO1xuaW1wb3J0IHR5cGUgeyBJZCB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9kYXRhTW9kZWxcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQgeyBDYXJkIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9jYXJkXCI7XG5pbXBvcnQgeyBQYWdlSGVhZGVyIH0gZnJvbSBcIi4vY29tcG9uZW50cy9QYWdlSGVhZGVyXCI7XG5pbXBvcnQgeyBTdGF0dXNCYWRnZSwgdHlwZSBTdGF0dXNCYWRnZVByb3BzIH0gZnJvbSBcIkAvY29tcG9uZW50cy9mYWN0b3J5L2JhZGdlc1wiO1xuaW1wb3J0IHsgdXNlVG9hc3QgfSBmcm9tIFwiLi9Ub2FzdFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcbmltcG9ydCB7IEFjdGl2aXR5LCBaYXAsIEZpbHRlciwgUmFkaW8sIENoZWNrQ2lyY2xlMiB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcblxuZnVuY3Rpb24gZm10VGltZSh0cz86IG51bWJlcikge1xuICBpZiAoIXRzKSByZXR1cm4gXCJuL2FcIjtcbiAgcmV0dXJuIG5ldyBEYXRlKHRzKS50b0xvY2FsZVN0cmluZygpO1xufVxuXG5mdW5jdGlvbiBjb21wYWN0SnNvbih2YWx1ZTogdW5rbm93bikge1xuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCB8fCB2YWx1ZSA9PT0gbnVsbCkgcmV0dXJuIFwibi9hXCI7XG4gIGNvbnN0IHMgPSBKU09OLnN0cmluZ2lmeSh2YWx1ZSk7XG4gIHJldHVybiBzLmxlbmd0aCA8PSAxMDAgPyBzIDogYCR7cy5zbGljZSgwLCAxMDApfeKApmA7XG59XG5cbmZ1bmN0aW9uIGV2ZW50UGlsbFRvbmUodHlwZTogc3RyaW5nKTogU3RhdHVzQmFkZ2VQcm9wc1tcInRvbmVcIl0ge1xuICBpZiAodHlwZS5pbmNsdWRlcyhcIkZBSUxFRFwiKSB8fCB0eXBlLmluY2x1ZGVzKFwiQkxPQ0tFRFwiKSkgcmV0dXJuIFwiZXJyb3JcIjtcbiAgaWYgKHR5cGUuaW5jbHVkZXMoXCJTVEFSVEVEXCIpIHx8IHR5cGUuaW5jbHVkZXMoXCJTVEVQXCIpKSByZXR1cm4gXCJpbmZvXCI7XG4gIGlmICh0eXBlLmluY2x1ZGVzKFwiQ09NUExFVEVEXCIpIHx8IHR5cGUuaW5jbHVkZXMoXCJET05FXCIpKSByZXR1cm4gXCJzdWNjZXNzXCI7XG4gIGlmICh0eXBlLmluY2x1ZGVzKFwiREVDSVNJT05cIikpIHJldHVybiBcImluZm9cIjtcbiAgcmV0dXJuIFwibmV1dHJhbFwiO1xufVxuXG5mdW5jdGlvbiBFdmVudFR5cGVQaWxsKHsgdmFsdWUgfTogeyB2YWx1ZTogc3RyaW5nIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8U3RhdHVzQmFkZ2UgdG9uZT17ZXZlbnRQaWxsVG9uZSh2YWx1ZSl9IGNsYXNzTmFtZT1cIndoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICB7dmFsdWV9XG4gICAgPC9TdGF0dXNCYWRnZT5cbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFRlbGVtZXRyeVZpZXcoeyBwcm9qZWN0SWQgfTogeyBwcm9qZWN0SWQ6IElkPFwicHJvamVjdHNcIj4gfCBudWxsIH0pIHtcbiAgY29uc3QgeyB0b2FzdCB9ID0gdXNlVG9hc3QoKTtcbiAgY29uc3QgW3R5cGVGaWx0ZXIsIHNldFR5cGVGaWx0ZXJdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFt3aW5kb3dNaW51dGVzLCBzZXRXaW5kb3dNaW51dGVzXSA9IHVzZVN0YXRlKDYwKTtcblxuICBjb25zdCBhZ2VudHMgPSB1c2VRdWVyeShhcGkuYWdlbnRzLmxpc3RBbGwsIHByb2plY3RJZCA/IHsgcHJvamVjdElkIH0gOiBcInNraXBcIik7XG4gIGNvbnN0IGV2ZW50cyA9IHVzZVF1ZXJ5KFxuICAgIGFwaVtcIm9wZXJhdGlvbnMvb3BFdmVudHNcIl0ubGlzdE9wRXZlbnRzLFxuICAgIHByb2plY3RJZFxuICAgICAgPyB7IHByb2plY3RJZCwgdHlwZTogdHlwZUZpbHRlciB8fCB1bmRlZmluZWQsIGxpbWl0OiAyMDAgfVxuICAgICAgOiBcInNraXBcIlxuICApO1xuICBjb25zdCBzdGF0cyA9IHVzZVF1ZXJ5KFxuICAgIGFwaVtcIm9wZXJhdGlvbnMvb3BFdmVudHNcIl0uZ2V0T3BFdmVudFN0YXRzLFxuICAgIHByb2plY3RJZCA/IHsgcHJvamVjdElkLCB3aW5kb3dNaW51dGVzIH0gOiBcInNraXBcIlxuICApO1xuICBjb25zdCBldmFsdWF0ZVdpdGhBUk0gPSB1c2VNdXRhdGlvbihhcGkucG9saWN5LmV2YWx1YXRlV2l0aEFSTSk7XG5cbiAgY29uc3QgaGFuZGxlRW1pdFRlc3RFdmVudCA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBhZ2VudCA9IChhZ2VudHMgPz8gW10pWzBdO1xuICAgIGlmICghYWdlbnQpIHsgdG9hc3QoXCJObyBhZ2VudHMgYXZhaWxhYmxlIHRvIGVtaXQgdGVsZW1ldHJ5LlwiLCB0cnVlKTsgcmV0dXJuOyB9XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGV2YWx1YXRlV2l0aEFSTSh7XG4gICAgICAgIGFnZW50SWQ6IGFnZW50Ll9pZCxcbiAgICAgICAgYWN0aW9uVHlwZTogXCJUT09MX0NBTExcIixcbiAgICAgICAgdG9vbE5hbWU6IFwic2hlbGxcIixcbiAgICAgICAgdG9vbEFyZ3M6IHsgY29tbWFuZDogXCJlY2hvIHRlbGVtZXRyeV9wcm9iZVwiIH0sXG4gICAgICAgIGNvbnRleHQ6IHsgc291cmNlOiBcInRlbGVtZXRyeS51aVwiIH0sXG4gICAgICB9KTtcbiAgICAgIHRvYXN0KFwiVGVsZW1ldHJ5IHByb2JlIGVtaXR0ZWQgdmlhIEFSTSBwb2xpY3kgZXZhbHVhdG9yLlwiKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICB0b2FzdChlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiBcIkZhaWxlZCB0byBlbWl0IHRlbGVtZXRyeSBwcm9iZVwiLCB0cnVlKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgdG9wVHlwZXM6IHsgdHlwZTogc3RyaW5nOyBjb3VudDogbnVtYmVyIH1bXSA9IHN0YXRzPy50b3BUeXBlcyA/PyBbXTtcbiAgY29uc3QgdG90YWxFdmVudHMgPSBzdGF0cz8udG90YWwgPz8gMDtcbiAgY29uc3QgaW5XaW5kb3cgICAgPSBzdGF0cz8uaW5XaW5kb3cgPz8gMDtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImZsZXggbWluLWgtMCBmbGV4LTEgZmxleC1jb2wgb3ZlcmZsb3ctaGlkZGVuIGJnLWFwcFwiPlxuICAgICAgPFBhZ2VIZWFkZXJcbiAgICAgICAgdGl0bGU9XCJBUk0gVGVsZW1ldHJ5XCJcbiAgICAgICAgZGVzY3JpcHRpb249e1xuICAgICAgICAgIGluV2luZG93ID4gMFxuICAgICAgICAgICAgPyBgTGl2ZSBzdHJlYW0gwrcgJHtpbldpbmRvd30gZXZlbnRzIGluIGxhc3QgJHt3aW5kb3dNaW51dGVzfW1gXG4gICAgICAgICAgICA6IFwiT3BlcmF0aW9uYWwgZXZlbnRzIHN0cmVhbSBmb3IgcnVucywgdG9vbCBjYWxscywgd29ya2Zsb3cgc3RlcHMsIGFuZCBkZWNpc2lvbiB0cmFjZXMuXCJcbiAgICAgICAgfVxuICAgICAgICBleWVicm93PVwiT3BlcmF0aW9uc1wiXG4gICAgICAgIGFjdGlvbnM9e1xuICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgb25DbGljaz17aGFuZGxlRW1pdFRlc3RFdmVudH0gdmFyaWFudD1cIm91dGxpbmVcIj5cbiAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgbXItMS41XCIgc3Ryb2tlV2lkdGg9ezEuN30gLz5cbiAgICAgICAgICAgIEVtaXQgVGVzdCBFdmVudFxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICB9XG4gICAgICAvPlxuXG4gICAgICB7LyogU3VtbWFyeSBzdGF0cyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXgtYXV0byBmbGV4IG1pbi1oLTAgdy1mdWxsIG1heC13LVsxMjAwcHhdIGZsZXgtMSBmbGV4LWNvbCBnYXAtNCBvdmVyZmxvdy1oaWRkZW4gcHgtNiBwYi02IHB0LTRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBzaHJpbmstMCBncmlkLWNvbHMtMiBnYXAtMyBzbTpncmlkLWNvbHMtNFwiPlxuICAgICAgICB7W1xuICAgICAgICAgIHsgaWNvbjogQWN0aXZpdHksICAgICBsYWJlbDogXCJUb3RhbCBFdmVudHNcIiwgICAgIHZhbHVlOiB0b3RhbEV2ZW50cyB9LFxuICAgICAgICAgIHsgaWNvbjogUmFkaW8sICAgICAgICBsYWJlbDogYExhc3QgJHt3aW5kb3dNaW51dGVzfW1gLCB2YWx1ZTogaW5XaW5kb3cgfSxcbiAgICAgICAgICB7IGljb246IEZpbHRlciwgICAgICAgbGFiZWw6IFwiRmlsdGVyZWQgUm93c1wiLCAgICB2YWx1ZTogKGV2ZW50cyA/PyBbXSkubGVuZ3RoIH0sXG4gICAgICAgICAgeyBpY29uOiBDaGVja0NpcmNsZTIsIGxhYmVsOiBcIkxhdGVzdCBFdmVudFwiLCAgICAgdmFsdWU6IHN0YXRzPy5sYXRlc3RUaW1lc3RhbXAgPyAxIDogMCB9LFxuICAgICAgICBdLm1hcCgoeyBpY29uOiBJY29uLCBsYWJlbCwgdmFsdWUgfSkgPT4gKFxuICAgICAgICAgIDxDYXJkIGtleT17bGFiZWx9IGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IG1iLTEuNVwiPlxuICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSB0ZXh0LWluay1tdXRlZFwiIHN0cm9rZVdpZHRoPXsxLjZ9IC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEyLjVweF0gZm9udC1tZWRpdW0gdGV4dC1pbmstc2Vjb25kYXJ5XCI+e2xhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMjBweF0gZm9udC1zZW1pYm9sZCBsZWFkaW5nLW5vbmUgdGFidWxhci1udW1zIHRleHQtaW5rXCI+e3ZhbHVlfTwvcD5cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBtaW4taC0wIGZsZXgtMSBnYXAtNCBvdmVyZmxvdy1oaWRkZW4geGw6Z3JpZC1jb2xzLVttaW5tYXgoMCwxZnIpXzMyMHB4XVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLTAgZmxleC0xIGZsZXgtY29sIGdhcC00IG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICB7LyogRmlsdGVycyArIEV2ZW50IHR5cGUgYnJlYWtkb3duICovfVxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggc2hyaW5rLTAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBvdmVyZmxvdy14LWF1dG8gZmxleC1ub3dyYXAgYm9yZGVyLWIgYm9yZGVyLWxpbmUgcHgtNSBweS0zXCI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJzaHJpbmstMCB0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+RXZlbnQgVHlwZSBCcmVha2Rvd248L3A+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggc2hyaW5rLTAgaXRlbXMtY2VudGVyIGdhcC0zIG92ZXJmbG93LXgtYXV0byBmbGV4LW5vd3JhcFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPEZpbHRlciBjbGFzc05hbWU9XCJoLTMgdy0zIHRleHQtaW5rLW11dGVkXCIgc3Ryb2tlV2lkdGg9ezEuNn0gLz5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgcHgtMyB0ZXh0LVsxMy41cHhdIHRleHQtaW5rIHBsYWNlaG9sZGVyOnRleHQtaW5rLW11dGVkIGZvY3VzLXZpc2libGU6b3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy1yaW5nIHctMzZcIlxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJGaWx0ZXIgdHlwZeKAplwiXG4gICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiRmlsdGVyIGV2ZW50cyBieSB0eXBlXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt0eXBlRmlsdGVyfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUeXBlRmlsdGVyKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgcHgtMyB0ZXh0LVsxMy41cHhdIHRleHQtaW5rIGZvY3VzLXZpc2libGU6b3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy1yaW5nXCJcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiVGltZSB3aW5kb3dcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXt3aW5kb3dNaW51dGVzfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0V2luZG93TWludXRlcyhOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ezE1fT5MYXN0IDE1bTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ezYwfT5MYXN0IDYwbTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ezI0MH0+TGFzdCA0aDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ezE0NDB9Pkxhc3QgMjRoPC9vcHRpb24+XG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTRcIj5cbiAgICAgICAgICAgIHt0b3BUeXBlcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzLjVweF0gdGV4dC1pbmstbXV0ZWQgdGV4dC1jZW50ZXIgcHktNlwiPk5vIGV2ZW50cyBjYXB0dXJlZCB5ZXQuPC9wPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC0zXCI+XG4gICAgICAgICAgICAgICAge3RvcFR5cGVzLm1hcCgocm93KSA9PiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17cm93LnR5cGV9IGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMiBweC0zIHB5LTIuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMS41cHhdIHRleHQtaW5rLW11dGVkIGZvbnQtbWVkaXVtIG1iLTEgdHJ1bmNhdGVcIj57cm93LnR5cGV9PC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsyMHB4XSBmb250LXNlbWlib2xkIGxlYWRpbmctbm9uZSB0ZXh0LWluayB0YWJ1bGFyLW51bXNcIj57cm93LmNvdW50fTwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZD5cblxuICAgICAgICB7LyogUmVjZW50IGV2ZW50cyB0YWJsZSAqL31cbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwib3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC01IHB5LTMgYm9yZGVyLWIgYm9yZGVyLWxpbmVcIj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj5SZWNlbnQgRXZlbnRzPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHsoZXZlbnRzID8/IFtdKS5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTEyIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxBY3Rpdml0eSBjbGFzc05hbWU9XCJoLTggdy04IHRleHQtaW5rLW11dGVkLzMwIG14LWF1dG8gbWItMlwiIHN0cm9rZVdpZHRoPXsxLjZ9IC8+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzLjVweF0gdGV4dC1pbmstbXV0ZWRcIj5ObyBvcCBldmVudHMgZm91bmQuPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3ctYXV0b1wiPlxuICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIG1pbi13LVs5NjBweF0gYm9yZGVyLWNvbGxhcHNlIHRleHQtbGVmdCB0ZXh0LVsxM3B4XVwiPlxuICAgICAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItbGluZVwiPlxuICAgICAgICAgICAgICAgICAgICB7W1wiVGltZXN0YW1wXCIsIFwiVHlwZVwiLCBcIlJ1blwiLCBcIkluc3RhbmNlXCIsIFwiVmVyc2lvblwiLCBcIlBheWxvYWRcIl0ubWFwKChoKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGtleT17aH0gY2xhc3NOYW1lPVwicHgtNCBweS0yLjUgdGV4dC1bMTEuNXB4XSBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMDZlbV0gdGV4dC1pbmstbXV0ZWRcIj57aH08L3RoPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgICAgICB7KGV2ZW50cyA/PyBbXSkubWFwKChldmVudCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8dHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2V2ZW50Ll9pZH1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItbGluZSBsYXN0OmJvcmRlci1iLTAgaG92ZXI6Ymctc3VyZmFjZS0yIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zLjUgZm9udC1tb25vIHRleHQtaW5rLW11dGVkIHdoaXRlc3BhY2Utbm93cmFwXCI+e2ZtdFRpbWUoZXZlbnQudGltZXN0YW1wKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMuNVwiPjxFdmVudFR5cGVQaWxsIHZhbHVlPXtldmVudC50eXBlfSAvPjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMy41IGZvbnQtbW9ubyB0ZXh0LWluay1tdXRlZCB0cnVuY2F0ZSBtYXgtdy1bMTIwcHhdXCI+e2V2ZW50LnJ1bklkID8/IFwibi9hXCJ9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zLjUgZm9udC1tb25vIHRleHQtaW5rLW11dGVkIHRydW5jYXRlIG1heC13LVsxMjBweF1cIj57ZXZlbnQuaW5zdGFuY2VJZCA/PyBcIm4vYVwifTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMy41IGZvbnQtbW9ubyB0ZXh0LWluay1tdXRlZCB0cnVuY2F0ZSBtYXgtdy1bMTIwcHhdXCI+e2V2ZW50LnZlcnNpb25JZCA/PyBcIm4vYVwifTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMy41IHRleHQtaW5rLW11dGVkIHRydW5jYXRlIG1heC13LVsyNDBweF0gZm9udC1tb25vXCI+e2NvbXBhY3RKc29uKGV2ZW50LnBheWxvYWQpfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9DYXJkPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj5UZWxlbWV0cnkgZ3VpZGFuY2U8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIHNwYWNlLXktMyB0ZXh0LVsxMy41cHhdIGxlYWRpbmctcmVsYXhlZCB0ZXh0LWluay1zZWNvbmRhcnlcIj5cbiAgICAgICAgICA8cD5UZWxlbWV0cnkgaXMgdXNlZnVsIG9ubHkgd2hlbiBpdCBoZWxwcyBleHBsYWluIGEgZGVjaXNpb24sIGEgZmFpbHVyZSwgb3IgYSBib3R0bGVuZWNrLiBUcmVhdCBzcGlrZXMgd2l0aG91dCBuYXJyYXRpdmUgYXMgYSBzaWduIG9mIHBvb3IgaW5zdHJ1bWVudGF0aW9uLjwvcD5cbiAgICAgICAgICA8cD5Vc2UgdGhlIHRpbWUgd2luZG93IHRvIGlzb2xhdGUgb3BlcmF0b3IgaW5jaWRlbnRzIGZpcnN0LCB0aGVuIHdpZGVuIHRoZSB3aW5kb3cgb25seSB3aGVuIHlvdSBuZWVkIHRyZW5kIGNvbnRleHQuPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZD5cbiAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9zZWN0aW9uPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvVGVsZW1ldHJ5Vmlldy50c3gifQ==