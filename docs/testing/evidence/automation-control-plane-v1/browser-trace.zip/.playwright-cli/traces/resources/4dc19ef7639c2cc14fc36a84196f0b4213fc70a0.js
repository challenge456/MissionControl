import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/empty-state.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/empty-state.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { cn } from "/src/lib/utils.ts";
export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
  className
}) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: cn(
        "flex flex-col items-center justify-center rounded-xl border border-line bg-surface-1 px-6 py-12 text-center",
        className
      ),
      children: [
        Icon && /* @__PURE__ */ jsxDEV("div", { className: "mb-6 flex h-14 w-14 items-center justify-center rounded-xl border border-line bg-surface-2 text-ink-muted", children: /* @__PURE__ */ jsxDEV(Icon, { className: "h-7 w-7", strokeWidth: 1.5 }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/empty-state.tsx",
          lineNumber: 47,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/empty-state.tsx",
          lineNumber: 46,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "mb-2 text-[15px] font-semibold text-ink", children: title }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/empty-state.tsx",
          lineNumber: 50,
          columnNumber: 7
        }, this),
        description && /* @__PURE__ */ jsxDEV("p", { className: "mb-6 max-w-sm text-sm leading-relaxed text-muted-foreground", children: description }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/empty-state.tsx",
          lineNumber: 52,
          columnNumber: 7
        }, this),
        action && /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: action }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/empty-state.tsx",
          lineNumber: 56,
          columnNumber: 18
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/empty-state.tsx",
      lineNumber: 39,
      columnNumber: 5
    },
    this
  );
}
_c = EmptyState;
var _c;
$RefreshReg$(_c, "EmptyState");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/empty-state.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/empty-state.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJVOzs7Ozs7Ozs7Ozs7Ozs7O0FBMUJWLFNBQVNBLFVBQVU7QUFVWixnQkFBU0MsV0FBVztBQUFBLEVBQ3pCQyxNQUFNQztBQUFBQSxFQUNOQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNlLEdBQUc7QUFDbEIsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBV1A7QUFBQUEsUUFDVDtBQUFBLFFBQ0FPO0FBQUFBLE1BQ0Y7QUFBQSxNQUVDSjtBQUFBQSxnQkFDQyx1QkFBQyxTQUFJLFdBQVUsNkdBQ2IsaUNBQUMsUUFBSyxXQUFVLFdBQVUsYUFBYSxPQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJDLEtBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUYsdUJBQUMsUUFBRyxXQUFVLDJDQUEyQ0MsbUJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0Q7QUFBQSxRQUM5REMsZUFDQyx1QkFBQyxPQUFFLFdBQVUsK0RBQ1ZBLHlCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRURDLFVBQVUsdUJBQUMsU0FBSSxXQUFVLFFBQVFBLG9CQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThCO0FBQUE7QUFBQTtBQUFBLElBakIzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFrQkE7QUFFSjtBQUFDRSxLQTVCZVA7QUFBVSxJQUFBTztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJjbiIsIkVtcHR5U3RhdGUiLCJpY29uIiwiSWNvbiIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJhY3Rpb24iLCJjbGFzc05hbWUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJlbXB0eS1zdGF0ZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdHlwZSBMdWNpZGVJY29uIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcblxuZXhwb3J0IGludGVyZmFjZSBFbXB0eVN0YXRlUHJvcHMge1xuICBpY29uPzogTHVjaWRlSWNvbjtcbiAgdGl0bGU6IHN0cmluZztcbiAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gIGFjdGlvbj86IFJlYWN0LlJlYWN0Tm9kZTtcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gRW1wdHlTdGF0ZSh7XG4gIGljb246IEljb24sXG4gIHRpdGxlLFxuICBkZXNjcmlwdGlvbixcbiAgYWN0aW9uLFxuICBjbGFzc05hbWUsXG59OiBFbXB0eVN0YXRlUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMSBweC02IHB5LTEyIHRleHQtY2VudGVyXCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICA+XG4gICAgICB7SWNvbiAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBmbGV4IGgtMTQgdy0xNCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwiaC03IHctN1wiIHN0cm9rZVdpZHRoPXsxLjV9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi0yIHRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj57dGl0bGV9PC9oMz5cbiAgICAgIHtkZXNjcmlwdGlvbiAmJiAoXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTYgbWF4LXctc20gdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAge2Rlc2NyaXB0aW9ufVxuICAgICAgICA8L3A+XG4gICAgICApfVxuICAgICAge2FjdGlvbiAmJiA8ZGl2IGNsYXNzTmFtZT1cIm10LTJcIj57YWN0aW9ufTwvZGl2Pn1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL2NvbXBvbmVudHMvdWkvZW1wdHktc3RhdGUudHN4In0=