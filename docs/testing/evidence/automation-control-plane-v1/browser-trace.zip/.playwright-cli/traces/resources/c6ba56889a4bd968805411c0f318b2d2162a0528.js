import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/automations/AutomationDefinitions.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { Pause, Play, ShieldCheck } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { Badge } from "/src/components/ui/badge.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Card } from "/src/components/ui/card.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "/src/components/ui/dialog.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { Textarea } from "/src/components/ui/textarea.tsx";
import { formatDate, statusTone } from "/src/automations/automationModel.ts";
export function AutomationDefinitions({
  projectId,
  definitions,
  onSelect
}) {
  _s();
  const activate = useMutation(api.automations.activate);
  const pause = useMutation(api.automations.pause);
  const [action, setAction] = useState(null);
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState(null);
  async function confirm() {
    if (!action || reason.trim().length < 5) return;
    setBusy(true);
    setMessage(null);
    try {
      const args = {
        projectId,
        automationDefinitionId: action.definition._id,
        actorId: "operator",
        reason: reason.trim(),
        policyVersion: "automation-v1"
      };
      if (action.type === "activate") await activate(args);
      else
        await pause(args);
      setMessage({ tone: "ok", text: `${action.definition.name} ${action.type === "activate" ? "activated" : "paused"}.` });
      setAction(null);
      setReason("");
    } catch (error) {
      setMessage({ tone: "error", text: error instanceof Error ? error.message : "Automation transition failed" });
    } finally {
      setBusy(false);
    }
  }
  if (definitions.length === 0) {
    return /* @__PURE__ */ jsxDEV(Card, { className: "border-dashed p-8 text-center text-sm text-muted-foreground", children: "No Automation Definitions yet. Accept an evidenced candidate to create a disabled definition." }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
      lineNumber: 76,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
    /* @__PURE__ */ jsxDEV("div", { "aria-live": "polite", children: message ? /* @__PURE__ */ jsxDEV("p", { className: message.tone === "ok" ? "text-sm text-emerald-300" : "text-sm text-red-300", children: message.text }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
      lineNumber: 82,
      columnNumber: 20
    }, this) : null }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
      lineNumber: 81,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto rounded-xl border border-[var(--panel-line)]", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-[1120px] w-full text-left text-sm", children: [
      /* @__PURE__ */ jsxDEV("thead", { className: "bg-card/70 text-[11px] uppercase tracking-[0.13em] text-muted-foreground", children: /* @__PURE__ */ jsxDEV("tr", { children: ["Name", "Status", "Reliability", "Workflow", "Trigger", "Scope", "Risk", "Approval", "Next run", "Health", "Action"].map((label) => /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 font-medium", children: label }, label, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
        lineNumber: 87,
        columnNumber: 151
      }, this)) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
        lineNumber: 87,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
        lineNumber: 86,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-[var(--panel-line)]", children: definitions.map(
        (definition) => /* @__PURE__ */ jsxDEV("tr", { className: "bg-card/30 align-top", children: [
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3", children: [
            /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => onSelect(definition._id), className: "font-medium text-foreground hover:text-registry-accent", children: definition.name }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
              lineNumber: 93,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: definition.ownerId }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
              lineNumber: 94,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
            lineNumber: 92,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3", children: /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", className: statusTone(definition.status), children: definition.status }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
            lineNumber: 96,
            columnNumber: 43
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
            lineNumber: 96,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3 text-muted-foreground", children: definition.reliabilityState }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
            lineNumber: 97,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3 text-muted-foreground", children: [
            definition.workflowId,
            "@",
            definition.workflowVersion
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
            lineNumber: 98,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3 text-muted-foreground", children: [
            definition.triggerType,
            /* @__PURE__ */ jsxDEV("div", { className: "text-xs", children: definition.triggerConfig?.cron }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
              lineNumber: 99,
              columnNumber: 89
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
            lineNumber: 99,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3 text-muted-foreground", children: definition.scope }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
            lineNumber: 100,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3", children: definition.riskLevel }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
            lineNumber: 101,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3 text-muted-foreground", children: definition.requiredApprovalTypes.join(", ") }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
            lineNumber: 102,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3 text-muted-foreground", children: formatDate(definition.nextRunAt) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
            lineNumber: 103,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3", children: /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", className: statusTone(definition.health), children: definition.health }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
            lineNumber: 104,
            columnNumber: 43
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
            lineNumber: 104,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3", children: definition.status === "ACTIVE" ? /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", onClick: () => setAction({ type: "pause", definition }), children: [
            /* @__PURE__ */ jsxDEV(Pause, { className: "h-3.5 w-3.5" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
              lineNumber: 107,
              columnNumber: 110
            }, this),
            " Pause"
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
            lineNumber: 107,
            columnNumber: 17
          }, this) : ["DISABLED", "PAUSED"].includes(definition.status) ? /* @__PURE__ */ jsxDEV(Button, { size: "sm", onClick: () => setAction({ type: "activate", definition }), children: [
            /* @__PURE__ */ jsxDEV(Play, { className: "h-3.5 w-3.5" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
              lineNumber: 109,
              columnNumber: 95
            }, this),
            " ",
            definition.status === "PAUSED" ? "Resume" : "Activate"
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
            lineNumber: 109,
            columnNumber: 17
          }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-muted-foreground", children: "Review required" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
            lineNumber: 110,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
            lineNumber: 105,
            columnNumber: 17
          }, this)
        ] }, definition._id, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
          lineNumber: 91,
          columnNumber: 13
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
        lineNumber: 89,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
      lineNumber: 85,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
      lineNumber: 84,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Dialog, { open: !!action, onOpenChange: (open) => {
      if (!open) {
        setAction(null);
        setReason("");
      }
    }, children: /* @__PURE__ */ jsxDEV(DialogContent, { children: [
      /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
        /* @__PURE__ */ jsxDEV(DialogTitle, { children: [
          action?.type === "activate" ? "Activate" : "Pause",
          " ",
          action?.definition.name
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
          lineNumber: 120,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(DialogDescription, { children: action?.type === "activate" ? "Activation creates approval-gated review WorkOrders only. It does not approve or dispatch them." : "Pausing stops future review gates and leaves existing WorkOrders unchanged." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
          lineNumber: 121,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
        lineNumber: 119,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: "automation-decision-reason", children: "Decision reason" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
          lineNumber: 128,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Textarea, { id: "automation-decision-reason", value: reason, onChange: (event) => setReason(event.target.value), placeholder: "Why is this transition appropriate?" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
          lineNumber: 129,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "flex items-center gap-1.5 text-xs text-muted-foreground", children: [
          /* @__PURE__ */ jsxDEV(ShieldCheck, { className: "h-3.5 w-3.5" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
            lineNumber: 130,
            columnNumber: 84
          }, this),
          " Recorded with actor, policy version, time, and definition version."
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
          lineNumber: 130,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
        lineNumber: 127,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "outline", onClick: () => setAction(null), children: "Cancel" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
          lineNumber: 133,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { disabled: busy || reason.trim().length < 5, onClick: () => void confirm(), children: busy ? "Recording…" : `Confirm ${action?.type}` }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
          lineNumber: 134,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
        lineNumber: 132,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
      lineNumber: 118,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
      lineNumber: 117,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx",
    lineNumber: 80,
    columnNumber: 5
  }, this);
}
_s(AutomationDefinitions, "84TCD1BJ6B3KCivQB+t4/JBuHpA=", false, function() {
  return [useMutation, useMutation];
});
_c = AutomationDefinitions;
var _c;
$RefreshReg$(_c, "AutomationDefinitions");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationDefinitions.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0RXOzs7Ozs7Ozs7Ozs7Ozs7OztBQXhEWCxTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLE9BQU9DLE1BQU1DLG1CQUFtQjtBQUN6QyxTQUFTQyxXQUFXO0FBRXBCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxZQUFZO0FBQ3JCO0FBQUEsRUFDRUM7QUFBQUEsRUFBUUM7QUFBQUEsRUFBZUM7QUFBQUEsRUFBbUJDO0FBQUFBLEVBQWNDO0FBQUFBLEVBQWNDO0FBQUFBLE9BQ2pFO0FBQ1AsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWUMsa0JBQWtCO0FBRWhDLGdCQUFTQyxzQkFBc0I7QUFBQSxFQUNwQ0M7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFLRixHQUFHO0FBQUFDLEtBQUE7QUFDRCxRQUFNQyxXQUFXdkIsWUFBWUksSUFBSW9CLFlBQVlELFFBQVE7QUFDckQsUUFBTUUsUUFBUXpCLFlBQVlJLElBQUlvQixZQUFZQyxLQUFLO0FBQy9DLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJNUIsU0FBaUUsSUFBSTtBQUNqRyxRQUFNLENBQUM2QixRQUFRQyxTQUFTLElBQUk5QixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDK0IsTUFBTUMsT0FBTyxJQUFJaEMsU0FBUyxLQUFLO0FBQ3RDLFFBQU0sQ0FBQ2lDLFNBQVNDLFVBQVUsSUFBSWxDLFNBQXdELElBQUk7QUFFMUYsaUJBQWVtQyxVQUFVO0FBQ3ZCLFFBQUksQ0FBQ1IsVUFBVUUsT0FBT08sS0FBSyxFQUFFQyxTQUFTLEVBQUc7QUFDekNMLFlBQVEsSUFBSTtBQUNaRSxlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0YsWUFBTUksT0FBTztBQUFBLFFBQ1hsQjtBQUFBQSxRQUNBbUIsd0JBQXdCWixPQUFPYSxXQUFXQztBQUFBQSxRQUMxQ0MsU0FBUztBQUFBLFFBQ1RiLFFBQVFBLE9BQU9PLEtBQUs7QUFBQSxRQUNwQk8sZUFBZTtBQUFBLE1BQ2pCO0FBQ0EsVUFBSWhCLE9BQU9pQixTQUFTLFdBQVksT0FBTXBCLFNBQVNjLElBQUk7QUFBQTtBQUM5QyxjQUFNWixNQUFNWSxJQUFJO0FBQ3JCSixpQkFBVyxFQUFFVyxNQUFNLE1BQU1DLE1BQU0sR0FBR25CLE9BQU9hLFdBQVdPLElBQUksSUFBSXBCLE9BQU9pQixTQUFTLGFBQWEsY0FBYyxRQUFRLElBQUksQ0FBQztBQUNwSGhCLGdCQUFVLElBQUk7QUFDZEUsZ0JBQVUsRUFBRTtBQUFBLElBQ2QsU0FBU2tCLE9BQU87QUFDZGQsaUJBQVcsRUFBRVcsTUFBTSxTQUFTQyxNQUFNRSxpQkFBaUJDLFFBQVFELE1BQU1mLFVBQVUsK0JBQStCLENBQUM7QUFBQSxJQUM3RyxVQUFDO0FBQ0NELGNBQVEsS0FBSztBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBRUEsTUFBSVgsWUFBWWdCLFdBQVcsR0FBRztBQUM1QixXQUFPLHVCQUFDLFFBQUssV0FBVSwrREFBOEQsNkdBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMks7QUFBQSxFQUNwTDtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwyQkFBQyxTQUFJLGFBQVUsVUFDWkosb0JBQVUsdUJBQUMsT0FBRSxXQUFXQSxRQUFRWSxTQUFTLE9BQU8sNkJBQTZCLHdCQUF5Qlosa0JBQVFhLFFBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUcsSUFBTyxRQUQ3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSxnRUFDYixpQ0FBQyxXQUFNLFdBQVUsMkNBQ2Y7QUFBQSw2QkFBQyxXQUFNLFdBQVUsNEVBQ2YsaUNBQUMsUUFBSSxXQUFDLFFBQVEsVUFBVSxlQUFlLFlBQVksV0FBVyxTQUFTLFFBQVEsWUFBWSxZQUFZLFVBQVUsUUFBUSxFQUFFSSxJQUFJLENBQUNDLFVBQVUsdUJBQUMsUUFBZSxXQUFVLHlCQUF5QkEsbUJBQTFDQSxPQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUQsQ0FBSyxLQUF4TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBNLEtBRDVNO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsV0FBTSxXQUFVLHVDQUNkOUIsc0JBQVk2QjtBQUFBQSxRQUFJLENBQUNWLGVBQ2hCLHVCQUFDLFFBQXdCLFdBQVUsd0JBQ2pDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGFBQ1o7QUFBQSxtQ0FBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU1sQixTQUFTa0IsV0FBV0MsR0FBRyxHQUFHLFdBQVUsMERBQTBERCxxQkFBV08sUUFBOUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUo7QUFBQSxZQUNuSix1QkFBQyxTQUFJLFdBQVUsc0NBQXNDUCxxQkFBV1ksV0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0U7QUFBQSxlQUYxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxRQUFHLFdBQVUsYUFBWSxpQ0FBQyxTQUFNLFNBQVEsV0FBVSxXQUFXbEMsV0FBV3NCLFdBQVdhLE1BQU0sR0FBSWIscUJBQVdhLFVBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGLEtBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdIO0FBQUEsVUFDeEgsdUJBQUMsUUFBRyxXQUFVLG1DQUFtQ2IscUJBQVdjLG9CQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RTtBQUFBLFVBQzdFLHVCQUFDLFFBQUcsV0FBVSxtQ0FBbUNkO0FBQUFBLHVCQUFXZTtBQUFBQSxZQUFXO0FBQUEsWUFBRWYsV0FBV2dCO0FBQUFBLGVBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9HO0FBQUEsVUFDcEcsdUJBQUMsUUFBRyxXQUFVLG1DQUFtQ2hCO0FBQUFBLHVCQUFXaUI7QUFBQUEsWUFBWSx1QkFBQyxTQUFJLFdBQVUsV0FBV2pCLHFCQUFXa0IsZUFBZUMsUUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUQ7QUFBQSxlQUFqSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1STtBQUFBLFVBQ3ZJLHVCQUFDLFFBQUcsV0FBVSxtQ0FBbUNuQixxQkFBV29CLFNBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtFO0FBQUEsVUFDbEUsdUJBQUMsUUFBRyxXQUFVLGFBQWFwQixxQkFBV3FCLGFBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdEO0FBQUEsVUFDaEQsdUJBQUMsUUFBRyxXQUFVLG1DQUFtQ3JCLHFCQUFXc0Isc0JBQXNCQyxLQUFLLElBQUksS0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkY7QUFBQSxVQUM3Rix1QkFBQyxRQUFHLFdBQVUsbUNBQW1DOUMscUJBQVd1QixXQUFXd0IsU0FBUyxLQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRjtBQUFBLFVBQ2xGLHVCQUFDLFFBQUcsV0FBVSxhQUFZLGlDQUFDLFNBQU0sU0FBUSxXQUFVLFdBQVc5QyxXQUFXc0IsV0FBV3lCLE1BQU0sR0FBSXpCLHFCQUFXeUIsVUFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0YsS0FBaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0g7QUFBQSxVQUN4SCx1QkFBQyxRQUFHLFdBQVUsYUFDWHpCLHFCQUFXYSxXQUFXLFdBQ3JCLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsV0FBVSxTQUFTLE1BQU16QixVQUFVLEVBQUVnQixNQUFNLFNBQVNKLFdBQVcsQ0FBQyxHQUFHO0FBQUEsbUNBQUMsU0FBTSxXQUFVLGlCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QjtBQUFBLFlBQUc7QUFBQSxlQUE5SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvSSxJQUNsSSxDQUFDLFlBQVksUUFBUSxFQUFFMEIsU0FBUzFCLFdBQVdhLE1BQU0sSUFDbkQsdUJBQUMsVUFBTyxNQUFLLE1BQUssU0FBUyxNQUFNekIsVUFBVSxFQUFFZ0IsTUFBTSxZQUFZSixXQUFXLENBQUMsR0FBRztBQUFBLG1DQUFDLFFBQUssV0FBVSxpQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkI7QUFBQSxZQUFHO0FBQUEsWUFBRUEsV0FBV2EsV0FBVyxXQUFXLFdBQVc7QUFBQSxlQUE1SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1SyxJQUNySyx1QkFBQyxVQUFLLFdBQVUsaUNBQWdDLCtCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRCxLQUxyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsYUFwQk9iLFdBQVdDLEtBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxQkE7QUFBQSxNQUNELEtBeEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5QkE7QUFBQSxTQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEJBLEtBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQ0E7QUFBQSxJQUNBLHVCQUFDLFVBQU8sTUFBTSxDQUFDLENBQUNkLFFBQVEsY0FBYyxDQUFDd0MsU0FBUztBQUFFLFVBQUksQ0FBQ0EsTUFBTTtBQUFFdkMsa0JBQVUsSUFBSTtBQUFHRSxrQkFBVSxFQUFFO0FBQUEsTUFBRztBQUFBLElBQUUsR0FDL0YsaUNBQUMsaUJBQ0M7QUFBQSw2QkFBQyxnQkFDQztBQUFBLCtCQUFDLGVBQWFIO0FBQUFBLGtCQUFRaUIsU0FBUyxhQUFhLGFBQWE7QUFBQSxVQUFRO0FBQUEsVUFBRWpCLFFBQVFhLFdBQVdPO0FBQUFBLGFBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkY7QUFBQSxRQUMzRix1QkFBQyxxQkFDRXBCLGtCQUFRaUIsU0FBUyxhQUNkLG9HQUNBLGlGQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFNBQU0sU0FBUSw4QkFBNkIsK0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQ7QUFBQSxRQUMzRCx1QkFBQyxZQUFTLElBQUcsOEJBQTZCLE9BQU9mLFFBQVEsVUFBVSxDQUFDdUMsVUFBVXRDLFVBQVVzQyxNQUFNQyxPQUFPQyxLQUFLLEdBQUcsYUFBWSx5Q0FBekg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4SjtBQUFBLFFBQzlKLHVCQUFDLE9BQUUsV0FBVSwyREFBMEQ7QUFBQSxpQ0FBQyxlQUFZLFdBQVUsaUJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9DO0FBQUEsVUFBRztBQUFBLGFBQTlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUw7QUFBQSxXQUhuTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUNBLHVCQUFDLGdCQUNDO0FBQUEsK0JBQUMsVUFBTyxTQUFRLFdBQVUsU0FBUyxNQUFNMUMsVUFBVSxJQUFJLEdBQUcsc0JBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0U7QUFBQSxRQUNoRSx1QkFBQyxVQUFPLFVBQVVHLFFBQVFGLE9BQU9PLEtBQUssRUFBRUMsU0FBUyxHQUFHLFNBQVMsTUFBTSxLQUFLRixRQUFRLEdBQUlKLGlCQUFPLGVBQWUsV0FBV0osUUFBUWlCLElBQUksTUFBakk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvSTtBQUFBLFdBRnRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQkEsS0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CQTtBQUFBLE9BekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwREE7QUFFSjtBQUFDckIsR0F6R2VKLHVCQUFxQjtBQUFBLFVBU2xCbEIsYUFDSEEsV0FBVztBQUFBO0FBQUEsS0FWWGtCO0FBQXFCLElBQUFvRDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZU11dGF0aW9uIiwiUGF1c2UiLCJQbGF5IiwiU2hpZWxkQ2hlY2siLCJhcGkiLCJCYWRnZSIsIkJ1dHRvbiIsIkNhcmQiLCJEaWFsb2ciLCJEaWFsb2dDb250ZW50IiwiRGlhbG9nRGVzY3JpcHRpb24iLCJEaWFsb2dGb290ZXIiLCJEaWFsb2dIZWFkZXIiLCJEaWFsb2dUaXRsZSIsIkxhYmVsIiwiVGV4dGFyZWEiLCJmb3JtYXREYXRlIiwic3RhdHVzVG9uZSIsIkF1dG9tYXRpb25EZWZpbml0aW9ucyIsInByb2plY3RJZCIsImRlZmluaXRpb25zIiwib25TZWxlY3QiLCJfcyIsImFjdGl2YXRlIiwiYXV0b21hdGlvbnMiLCJwYXVzZSIsImFjdGlvbiIsInNldEFjdGlvbiIsInJlYXNvbiIsInNldFJlYXNvbiIsImJ1c3kiLCJzZXRCdXN5IiwibWVzc2FnZSIsInNldE1lc3NhZ2UiLCJjb25maXJtIiwidHJpbSIsImxlbmd0aCIsImFyZ3MiLCJhdXRvbWF0aW9uRGVmaW5pdGlvbklkIiwiZGVmaW5pdGlvbiIsIl9pZCIsImFjdG9ySWQiLCJwb2xpY3lWZXJzaW9uIiwidHlwZSIsInRvbmUiLCJ0ZXh0IiwibmFtZSIsImVycm9yIiwiRXJyb3IiLCJtYXAiLCJsYWJlbCIsIm93bmVySWQiLCJzdGF0dXMiLCJyZWxpYWJpbGl0eVN0YXRlIiwid29ya2Zsb3dJZCIsIndvcmtmbG93VmVyc2lvbiIsInRyaWdnZXJUeXBlIiwidHJpZ2dlckNvbmZpZyIsImNyb24iLCJzY29wZSIsInJpc2tMZXZlbCIsInJlcXVpcmVkQXBwcm92YWxUeXBlcyIsImpvaW4iLCJuZXh0UnVuQXQiLCJoZWFsdGgiLCJpbmNsdWRlcyIsIm9wZW4iLCJldmVudCIsInRhcmdldCIsInZhbHVlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXV0b21hdGlvbkRlZmluaXRpb25zLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlTXV0YXRpb24gfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBQYXVzZSwgUGxheSwgU2hpZWxkQ2hlY2sgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgQmFkZ2UgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2JhZGdlXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuaW1wb3J0IHsgQ2FyZCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvY2FyZFwiO1xuaW1wb3J0IHtcbiAgRGlhbG9nLCBEaWFsb2dDb250ZW50LCBEaWFsb2dEZXNjcmlwdGlvbiwgRGlhbG9nRm9vdGVyLCBEaWFsb2dIZWFkZXIsIERpYWxvZ1RpdGxlLFxufSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2RpYWxvZ1wiO1xuaW1wb3J0IHsgTGFiZWwgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2xhYmVsXCI7XG5pbXBvcnQgeyBUZXh0YXJlYSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvdGV4dGFyZWFcIjtcbmltcG9ydCB7IGZvcm1hdERhdGUsIHN0YXR1c1RvbmUgfSBmcm9tIFwiLi9hdXRvbWF0aW9uTW9kZWxcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIEF1dG9tYXRpb25EZWZpbml0aW9ucyh7XG4gIHByb2plY3RJZCxcbiAgZGVmaW5pdGlvbnMsXG4gIG9uU2VsZWN0LFxufToge1xuICBwcm9qZWN0SWQ6IElkPFwicHJvamVjdHNcIj47XG4gIGRlZmluaXRpb25zOiBhbnlbXTtcbiAgb25TZWxlY3Q6IChkZWZpbml0aW9uSWQ6IHN0cmluZykgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgYWN0aXZhdGUgPSB1c2VNdXRhdGlvbihhcGkuYXV0b21hdGlvbnMuYWN0aXZhdGUpO1xuICBjb25zdCBwYXVzZSA9IHVzZU11dGF0aW9uKGFwaS5hdXRvbWF0aW9ucy5wYXVzZSk7XG4gIGNvbnN0IFthY3Rpb24sIHNldEFjdGlvbl0gPSB1c2VTdGF0ZTx7IHR5cGU6IFwiYWN0aXZhdGVcIiB8IFwicGF1c2VcIjsgZGVmaW5pdGlvbjogYW55IH0gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3JlYXNvbiwgc2V0UmVhc29uXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbYnVzeSwgc2V0QnVzeV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlPHsgdG9uZTogXCJva1wiIHwgXCJlcnJvclwiOyB0ZXh0OiBzdHJpbmcgfSB8IG51bGw+KG51bGwpO1xuXG4gIGFzeW5jIGZ1bmN0aW9uIGNvbmZpcm0oKSB7XG4gICAgaWYgKCFhY3Rpb24gfHwgcmVhc29uLnRyaW0oKS5sZW5ndGggPCA1KSByZXR1cm47XG4gICAgc2V0QnVzeSh0cnVlKTtcbiAgICBzZXRNZXNzYWdlKG51bGwpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBhcmdzID0ge1xuICAgICAgICBwcm9qZWN0SWQsXG4gICAgICAgIGF1dG9tYXRpb25EZWZpbml0aW9uSWQ6IGFjdGlvbi5kZWZpbml0aW9uLl9pZCxcbiAgICAgICAgYWN0b3JJZDogXCJvcGVyYXRvclwiLFxuICAgICAgICByZWFzb246IHJlYXNvbi50cmltKCksXG4gICAgICAgIHBvbGljeVZlcnNpb246IFwiYXV0b21hdGlvbi12MVwiLFxuICAgICAgfTtcbiAgICAgIGlmIChhY3Rpb24udHlwZSA9PT0gXCJhY3RpdmF0ZVwiKSBhd2FpdCBhY3RpdmF0ZShhcmdzKTtcbiAgICAgIGVsc2UgYXdhaXQgcGF1c2UoYXJncyk7XG4gICAgICBzZXRNZXNzYWdlKHsgdG9uZTogXCJva1wiLCB0ZXh0OiBgJHthY3Rpb24uZGVmaW5pdGlvbi5uYW1lfSAke2FjdGlvbi50eXBlID09PSBcImFjdGl2YXRlXCIgPyBcImFjdGl2YXRlZFwiIDogXCJwYXVzZWRcIn0uYCB9KTtcbiAgICAgIHNldEFjdGlvbihudWxsKTtcbiAgICAgIHNldFJlYXNvbihcIlwiKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgc2V0TWVzc2FnZSh7IHRvbmU6IFwiZXJyb3JcIiwgdGV4dDogZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIkF1dG9tYXRpb24gdHJhbnNpdGlvbiBmYWlsZWRcIiB9KTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0QnVzeShmYWxzZSk7XG4gICAgfVxuICB9XG5cbiAgaWYgKGRlZmluaXRpb25zLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiA8Q2FyZCBjbGFzc05hbWU9XCJib3JkZXItZGFzaGVkIHAtOCB0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPk5vIEF1dG9tYXRpb24gRGVmaW5pdGlvbnMgeWV0LiBBY2NlcHQgYW4gZXZpZGVuY2VkIGNhbmRpZGF0ZSB0byBjcmVhdGUgYSBkaXNhYmxlZCBkZWZpbml0aW9uLjwvQ2FyZD47XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICA8ZGl2IGFyaWEtbGl2ZT1cInBvbGl0ZVwiPlxuICAgICAgICB7bWVzc2FnZSA/IDxwIGNsYXNzTmFtZT17bWVzc2FnZS50b25lID09PSBcIm9rXCIgPyBcInRleHQtc20gdGV4dC1lbWVyYWxkLTMwMFwiIDogXCJ0ZXh0LXNtIHRleHQtcmVkLTMwMFwifT57bWVzc2FnZS50ZXh0fTwvcD4gOiBudWxsfVxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0byByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItW3ZhcigtLXBhbmVsLWxpbmUpXVwiPlxuICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctWzExMjBweF0gdy1mdWxsIHRleHQtbGVmdCB0ZXh0LXNtXCI+XG4gICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWNhcmQvNzAgdGV4dC1bMTFweF0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjEzZW1dIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgPHRyPntbXCJOYW1lXCIsIFwiU3RhdHVzXCIsIFwiUmVsaWFiaWxpdHlcIiwgXCJXb3JrZmxvd1wiLCBcIlRyaWdnZXJcIiwgXCJTY29wZVwiLCBcIlJpc2tcIiwgXCJBcHByb3ZhbFwiLCBcIk5leHQgcnVuXCIsIFwiSGVhbHRoXCIsIFwiQWN0aW9uXCJdLm1hcCgobGFiZWwpID0+IDx0aCBrZXk9e2xhYmVsfSBjbGFzc05hbWU9XCJweC0zIHB5LTMgZm9udC1tZWRpdW1cIj57bGFiZWx9PC90aD4pfTwvdHI+XG4gICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLVt2YXIoLS1wYW5lbC1saW5lKV1cIj5cbiAgICAgICAgICAgIHtkZWZpbml0aW9ucy5tYXAoKGRlZmluaXRpb24pID0+IChcbiAgICAgICAgICAgICAgPHRyIGtleT17ZGVmaW5pdGlvbi5faWR9IGNsYXNzTmFtZT1cImJnLWNhcmQvMzAgYWxpZ24tdG9wXCI+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktM1wiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gb25TZWxlY3QoZGVmaW5pdGlvbi5faWQpfSBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmQgaG92ZXI6dGV4dC1yZWdpc3RyeS1hY2NlbnRcIj57ZGVmaW5pdGlvbi5uYW1lfTwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e2RlZmluaXRpb24ub3duZXJJZH08L2Rpdj5cbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTNcIj48QmFkZ2UgdmFyaWFudD1cIm91dGxpbmVcIiBjbGFzc05hbWU9e3N0YXR1c1RvbmUoZGVmaW5pdGlvbi5zdGF0dXMpfT57ZGVmaW5pdGlvbi5zdGF0dXN9PC9CYWRnZT48L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e2RlZmluaXRpb24ucmVsaWFiaWxpdHlTdGF0ZX08L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e2RlZmluaXRpb24ud29ya2Zsb3dJZH1Ae2RlZmluaXRpb24ud29ya2Zsb3dWZXJzaW9ufTwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57ZGVmaW5pdGlvbi50cmlnZ2VyVHlwZX08ZGl2IGNsYXNzTmFtZT1cInRleHQteHNcIj57ZGVmaW5pdGlvbi50cmlnZ2VyQ29uZmlnPy5jcm9ufTwvZGl2PjwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57ZGVmaW5pdGlvbi5zY29wZX08L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTNcIj57ZGVmaW5pdGlvbi5yaXNrTGV2ZWx9PC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntkZWZpbml0aW9uLnJlcXVpcmVkQXBwcm92YWxUeXBlcy5qb2luKFwiLCBcIil9PC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntmb3JtYXREYXRlKGRlZmluaXRpb24ubmV4dFJ1bkF0KX08L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTNcIj48QmFkZ2UgdmFyaWFudD1cIm91dGxpbmVcIiBjbGFzc05hbWU9e3N0YXR1c1RvbmUoZGVmaW5pdGlvbi5oZWFsdGgpfT57ZGVmaW5pdGlvbi5oZWFsdGh9PC9CYWRnZT48L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTNcIj5cbiAgICAgICAgICAgICAgICAgIHtkZWZpbml0aW9uLnN0YXR1cyA9PT0gXCJBQ1RJVkVcIiA/IChcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9eygpID0+IHNldEFjdGlvbih7IHR5cGU6IFwicGF1c2VcIiwgZGVmaW5pdGlvbiB9KX0+PFBhdXNlIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz4gUGF1c2U8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICkgOiBbXCJESVNBQkxFRFwiLCBcIlBBVVNFRFwiXS5pbmNsdWRlcyhkZWZpbml0aW9uLnN0YXR1cykgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4gc2V0QWN0aW9uKHsgdHlwZTogXCJhY3RpdmF0ZVwiLCBkZWZpbml0aW9uIH0pfT48UGxheSBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+IHtkZWZpbml0aW9uLnN0YXR1cyA9PT0gXCJQQVVTRURcIiA/IFwiUmVzdW1lXCIgOiBcIkFjdGl2YXRlXCJ9PC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICApIDogPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5SZXZpZXcgcmVxdWlyZWQ8L3NwYW4+fVxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICA8L3RhYmxlPlxuICAgICAgPC9kaXY+XG4gICAgICA8RGlhbG9nIG9wZW49eyEhYWN0aW9ufSBvbk9wZW5DaGFuZ2U9eyhvcGVuKSA9PiB7IGlmICghb3BlbikgeyBzZXRBY3Rpb24obnVsbCk7IHNldFJlYXNvbihcIlwiKTsgfSB9fT5cbiAgICAgICAgPERpYWxvZ0NvbnRlbnQ+XG4gICAgICAgICAgPERpYWxvZ0hlYWRlcj5cbiAgICAgICAgICAgIDxEaWFsb2dUaXRsZT57YWN0aW9uPy50eXBlID09PSBcImFjdGl2YXRlXCIgPyBcIkFjdGl2YXRlXCIgOiBcIlBhdXNlXCJ9IHthY3Rpb24/LmRlZmluaXRpb24ubmFtZX08L0RpYWxvZ1RpdGxlPlxuICAgICAgICAgICAgPERpYWxvZ0Rlc2NyaXB0aW9uPlxuICAgICAgICAgICAgICB7YWN0aW9uPy50eXBlID09PSBcImFjdGl2YXRlXCJcbiAgICAgICAgICAgICAgICA/IFwiQWN0aXZhdGlvbiBjcmVhdGVzIGFwcHJvdmFsLWdhdGVkIHJldmlldyBXb3JrT3JkZXJzIG9ubHkuIEl0IGRvZXMgbm90IGFwcHJvdmUgb3IgZGlzcGF0Y2ggdGhlbS5cIlxuICAgICAgICAgICAgICAgIDogXCJQYXVzaW5nIHN0b3BzIGZ1dHVyZSByZXZpZXcgZ2F0ZXMgYW5kIGxlYXZlcyBleGlzdGluZyBXb3JrT3JkZXJzIHVuY2hhbmdlZC5cIn1cbiAgICAgICAgICAgIDwvRGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgICAgPC9EaWFsb2dIZWFkZXI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwiYXV0b21hdGlvbi1kZWNpc2lvbi1yZWFzb25cIj5EZWNpc2lvbiByZWFzb248L0xhYmVsPlxuICAgICAgICAgICAgPFRleHRhcmVhIGlkPVwiYXV0b21hdGlvbi1kZWNpc2lvbi1yZWFzb25cIiB2YWx1ZT17cmVhc29ufSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRSZWFzb24oZXZlbnQudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJXaHkgaXMgdGhpcyB0cmFuc2l0aW9uIGFwcHJvcHJpYXRlP1wiIC8+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+PFNoaWVsZENoZWNrIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz4gUmVjb3JkZWQgd2l0aCBhY3RvciwgcG9saWN5IHZlcnNpb24sIHRpbWUsIGFuZCBkZWZpbml0aW9uIHZlcnNpb24uPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxEaWFsb2dGb290ZXI+XG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17KCkgPT4gc2V0QWN0aW9uKG51bGwpfT5DYW5jZWw8L0J1dHRvbj5cbiAgICAgICAgICAgIDxCdXR0b24gZGlzYWJsZWQ9e2J1c3kgfHwgcmVhc29uLnRyaW0oKS5sZW5ndGggPCA1fSBvbkNsaWNrPXsoKSA9PiB2b2lkIGNvbmZpcm0oKX0+e2J1c3kgPyBcIlJlY29yZGluZ+KAplwiIDogYENvbmZpcm0gJHthY3Rpb24/LnR5cGV9YH08L0J1dHRvbj5cbiAgICAgICAgICA8L0RpYWxvZ0Zvb3Rlcj5cbiAgICAgICAgPC9EaWFsb2dDb250ZW50PlxuICAgICAgPC9EaWFsb2c+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9hdXRvbWF0aW9ucy9BdXRvbWF0aW9uRGVmaW5pdGlvbnMudHN4In0=