import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/operator/ToolCallRow.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ToolCallRow.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { cn } from "/src/lib/utils.ts";
export function ToolCallRow({ call, className }) {
  const status = call.status ?? "ok";
  return /* @__PURE__ */ jsxDEV("div", { className: cn("schematic-tool", `schematic-tool-${status}`, className), children: [
    /* @__PURE__ */ jsxDEV("div", { className: "schematic-tool-head", children: [
      /* @__PURE__ */ jsxDEV("span", { className: cn("schematic-dot", `schematic-dot-${status}`), "aria-hidden": true }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ToolCallRow.tsx",
        lineNumber: 41,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("code", { className: "font-mono text-[12.5px]", children: call.tool }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ToolCallRow.tsx",
        lineNumber: 42,
        columnNumber: 9
      }, this),
      call.summary ? /* @__PURE__ */ jsxDEV("span", { className: "text-[12.5px] text-ink-secondary", children: call.summary }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ToolCallRow.tsx",
        lineNumber: 44,
        columnNumber: 9
      }, this) : null
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ToolCallRow.tsx",
      lineNumber: 40,
      columnNumber: 7
    }, this),
    call.output !== void 0 ? /* @__PURE__ */ jsxDEV("details", { className: "mt-1.5", children: [
      /* @__PURE__ */ jsxDEV("summary", { className: "schematic-tool-summary", children: "args & raw output" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ToolCallRow.tsx",
        lineNumber: 49,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("pre", { className: "schematic-tool-pre", children: [
        call.tool,
        "(",
        JSON.stringify(call.args ?? {}, null, 1),
        call.output
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ToolCallRow.tsx",
        lineNumber: 50,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ToolCallRow.tsx",
      lineNumber: 48,
      columnNumber: 7
    }, this) : null
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ToolCallRow.tsx",
    lineNumber: 39,
    columnNumber: 5
  }, this);
}
_c = ToolCallRow;
var _c;
$RefreshReg$(_c, "ToolCallRow");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ToolCallRow.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ToolCallRow.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJROzs7Ozs7Ozs7Ozs7Ozs7O0FBckJSLFNBQVNBLFVBQVU7QUFnQlosZ0JBQVNDLFlBQVksRUFBRUMsTUFBTUMsVUFBNEIsR0FBZ0I7QUFDOUUsUUFBTUMsU0FBU0YsS0FBS0UsVUFBVTtBQUM5QixTQUNFLHVCQUFDLFNBQUksV0FBV0osR0FBRyxrQkFBa0Isa0JBQWtCSSxNQUFNLElBQUlELFNBQVMsR0FDeEU7QUFBQSwyQkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSw2QkFBQyxVQUFLLFdBQVdILEdBQUcsaUJBQWlCLGlCQUFpQkksTUFBTSxFQUFFLEdBQUcsZUFBVyxRQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRFO0FBQUEsTUFDNUUsdUJBQUMsVUFBSyxXQUFVLDJCQUEyQkYsZUFBS0csUUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRDtBQUFBLE1BQ3BESCxLQUFLSSxVQUNKLHVCQUFDLFVBQUssV0FBVSxvQ0FBb0NKLGVBQUtJLFdBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUUsSUFDL0Q7QUFBQSxTQUxOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBQ0NKLEtBQUtLLFdBQVdDLFNBQ2YsdUJBQUMsYUFBUSxXQUFVLFVBQ2pCO0FBQUEsNkJBQUMsYUFBUSxXQUFVLDBCQUF5QixpQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRTtBQUFBLE1BQ2pFLHVCQUFDLFNBQUksV0FBVSxzQkFDWk47QUFBQUEsYUFBS0c7QUFBQUEsUUFBSztBQUFBLFFBQUVJLEtBQUtDLFVBQVVSLEtBQUtTLFFBQVEsQ0FBQyxHQUFHLE1BQU0sQ0FBQztBQUFBLFFBRW5EVCxLQUFLSztBQUFBQSxXQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLFNBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BLElBQ0U7QUFBQSxPQWpCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0JBO0FBRUo7QUFBQ0ssS0F2QmVYO0FBQVcsSUFBQVc7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiY24iLCJUb29sQ2FsbFJvdyIsImNhbGwiLCJjbGFzc05hbWUiLCJzdGF0dXMiLCJ0b29sIiwic3VtbWFyeSIsIm91dHB1dCIsInVuZGVmaW5lZCIsIkpTT04iLCJzdHJpbmdpZnkiLCJhcmdzIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVG9vbENhbGxSb3cudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgVG9vbENhbGxEYXRhIHtcbiAgdG9vbDogc3RyaW5nO1xuICBzdGF0dXM/OiBcIm9rXCIgfCBcImVycm9yXCIgfCBcIndhcm5cIjtcbiAgc3VtbWFyeT86IHN0cmluZztcbiAgYXJncz86IHVua25vd247XG4gIG91dHB1dD86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBUb29sQ2FsbFJvd1Byb3BzIHtcbiAgY2FsbDogVG9vbENhbGxEYXRhO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59XG5cbi8qKiBXYWt1LXN0eWxlIGV4cGFuZGFibGUgdG9vbCByb3cgd2l0aCBzdGF0dXMgZG90LiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFRvb2xDYWxsUm93KHsgY2FsbCwgY2xhc3NOYW1lIH06IFRvb2xDYWxsUm93UHJvcHMpOiBKU1guRWxlbWVudCB7XG4gIGNvbnN0IHN0YXR1cyA9IGNhbGwuc3RhdHVzID8/IFwib2tcIjtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17Y24oXCJzY2hlbWF0aWMtdG9vbFwiLCBgc2NoZW1hdGljLXRvb2wtJHtzdGF0dXN9YCwgY2xhc3NOYW1lKX0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNjaGVtYXRpYy10b29sLWhlYWRcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtjbihcInNjaGVtYXRpYy1kb3RcIiwgYHNjaGVtYXRpYy1kb3QtJHtzdGF0dXN9YCl9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgIDxjb2RlIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LVsxMi41cHhdXCI+e2NhbGwudG9vbH08L2NvZGU+XG4gICAgICAgIHtjYWxsLnN1bW1hcnkgPyAoXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTIuNXB4XSB0ZXh0LWluay1zZWNvbmRhcnlcIj57Y2FsbC5zdW1tYXJ5fTwvc3Bhbj5cbiAgICAgICAgKSA6IG51bGx9XG4gICAgICA8L2Rpdj5cbiAgICAgIHtjYWxsLm91dHB1dCAhPT0gdW5kZWZpbmVkID8gKFxuICAgICAgICA8ZGV0YWlscyBjbGFzc05hbWU9XCJtdC0xLjVcIj5cbiAgICAgICAgICA8c3VtbWFyeSBjbGFzc05hbWU9XCJzY2hlbWF0aWMtdG9vbC1zdW1tYXJ5XCI+YXJncyAmYW1wOyByYXcgb3V0cHV0PC9zdW1tYXJ5PlxuICAgICAgICAgIDxwcmUgY2xhc3NOYW1lPVwic2NoZW1hdGljLXRvb2wtcHJlXCI+XG4gICAgICAgICAgICB7Y2FsbC50b29sfSh7SlNPTi5zdHJpbmdpZnkoY2FsbC5hcmdzID8/IHt9LCBudWxsLCAxKX1cblxuICAgICAgICAgICAge2NhbGwub3V0cHV0fVxuICAgICAgICAgIDwvcHJlPlxuICAgICAgICA8L2RldGFpbHM+XG4gICAgICApIDogbnVsbH1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL2NvbXBvbmVudHMvb3BlcmF0b3IvVG9vbENhbGxSb3cudHN4In0=