import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/automations/AutomationRuns.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Badge } from "/src/components/ui/badge.tsx";
import { Card } from "/src/components/ui/card.tsx";
import { formatDate, statusTone } from "/src/automations/automationModel.ts";
export function AutomationRuns({ runs }) {
  if (runs.length === 0) return /* @__PURE__ */ jsxDEV(Card, { className: "border-dashed p-8 text-center text-sm text-muted-foreground", children: "No Automation Runs yet. LEVEL_1 begins with an approval-gated WorkOrder." }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx",
    lineNumber: 25,
    columnNumber: 33
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto rounded-xl border border-[var(--panel-line)]", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-[980px] w-full text-left text-sm", children: [
    /* @__PURE__ */ jsxDEV("thead", { className: "bg-card/70 text-[11px] uppercase tracking-[0.13em] text-muted-foreground", children: /* @__PURE__ */ jsxDEV("tr", { children: ["Automation", "WorkOrder", "Created", "State", "Workflow", "Approval", "Verification", "Receipt"].map((label) => /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-3 font-medium", children: label }, label, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx",
      lineNumber: 30,
      columnNumber: 130
    }, this)) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx",
      lineNumber: 30,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx",
      lineNumber: 29,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-[var(--panel-line)]", children: runs.map((run) => /* @__PURE__ */ jsxDEV("tr", { className: "bg-card/30", children: [
      /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3 font-medium text-foreground", children: run.definition?.name ?? "Unknown Automation" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx",
        lineNumber: 34,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3 text-muted-foreground", children: run.workOrder.title }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx",
        lineNumber: 35,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3 text-muted-foreground", children: formatDate(run.workOrder.createdAt) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx",
        lineNumber: 36,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3", children: /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", className: statusTone(run.workOrder.state), children: run.workOrder.state }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx",
        lineNumber: 37,
        columnNumber: 39
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx",
        lineNumber: 37,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3 text-muted-foreground", children: [
        run.workOrder.workflowId,
        "@",
        run.workOrder.metadata?.automationWorkflowVersion
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx",
        lineNumber: 38,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3", children: run.workOrder.approvalStatus }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx",
        lineNumber: 39,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3", children: run.workOrder.verificationStatus }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx",
        lineNumber: 40,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-3", children: run.receipts.length ? `${run.receipts.length} attached` : "Missing" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx",
        lineNumber: 41,
        columnNumber: 13
      }, this)
    ] }, run.workOrder._id, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx",
      lineNumber: 33,
      columnNumber: 30
    }, this)) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx",
      lineNumber: 32,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx",
    lineNumber: 28,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx",
    lineNumber: 27,
    columnNumber: 5
  }, this);
}
_c = AutomationRuns;
var _c;
$RefreshReg$(_c, "AutomationRuns");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationRuns.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS2dDOzs7Ozs7Ozs7Ozs7Ozs7O0FBTGhDLFNBQVNBLGFBQWE7QUFDdEIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxZQUFZQyxrQkFBa0I7QUFFaEMsZ0JBQVNDLGVBQWUsRUFBRUMsS0FBc0IsR0FBRztBQUN4RCxNQUFJQSxLQUFLQyxXQUFXLEVBQUcsUUFBTyx1QkFBQyxRQUFLLFdBQVUsK0RBQThELHdGQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXNKO0FBQ3BMLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGdFQUNiLGlDQUFDLFdBQU0sV0FBVSwwQ0FDZjtBQUFBLDJCQUFDLFdBQU0sV0FBVSw0RUFDZixpQ0FBQyxRQUFJLFdBQUMsY0FBYyxhQUFhLFdBQVcsU0FBUyxZQUFZLFlBQVksZ0JBQWdCLFNBQVMsRUFBRUMsSUFBSSxDQUFDQyxVQUFVLHVCQUFDLFFBQWUsV0FBVSx5QkFBeUJBLG1CQUExQ0EsT0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlELENBQUssS0FBckw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1TCxLQUR6TDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFdBQU0sV0FBVSx1Q0FDZEgsZUFBS0UsSUFBSSxDQUFDRSxRQUFRLHVCQUFDLFFBQTJCLFdBQVUsY0FDdkQ7QUFBQSw2QkFBQyxRQUFHLFdBQVUseUNBQXlDQSxjQUFJQyxZQUFZQyxRQUFRLHdCQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9HO0FBQUEsTUFDcEcsdUJBQUMsUUFBRyxXQUFVLG1DQUFtQ0YsY0FBSUcsVUFBVUMsU0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRTtBQUFBLE1BQ3JFLHVCQUFDLFFBQUcsV0FBVSxtQ0FBbUNYLHFCQUFXTyxJQUFJRyxVQUFVRSxTQUFTLEtBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUY7QUFBQSxNQUNyRix1QkFBQyxRQUFHLFdBQVUsYUFBWSxpQ0FBQyxTQUFNLFNBQVEsV0FBVSxXQUFXWCxXQUFXTSxJQUFJRyxVQUFVRyxLQUFLLEdBQUlOLGNBQUlHLFVBQVVHLFNBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEYsS0FBcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0SDtBQUFBLE1BQzVILHVCQUFDLFFBQUcsV0FBVSxtQ0FBbUNOO0FBQUFBLFlBQUlHLFVBQVVJO0FBQUFBLFFBQVc7QUFBQSxRQUFFUCxJQUFJRyxVQUFVSyxVQUFVQztBQUFBQSxXQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThIO0FBQUEsTUFDOUgsdUJBQUMsUUFBRyxXQUFVLGFBQWFULGNBQUlHLFVBQVVPLGtCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdEO0FBQUEsTUFDeEQsdUJBQUMsUUFBRyxXQUFVLGFBQWFWLGNBQUlHLFVBQVVRLHNCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTREO0FBQUEsTUFDNUQsdUJBQUMsUUFBRyxXQUFVLGFBQWFYLGNBQUlZLFNBQVNmLFNBQVMsR0FBR0csSUFBSVksU0FBU2YsTUFBTSxjQUFjLGFBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0Y7QUFBQSxTQVJyRUcsSUFBSUcsVUFBVVUsS0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNuQixDQUFLLEtBVlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsT0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0JBLEtBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQkE7QUFFSjtBQUFDQyxLQXZCZW5CO0FBQWMsSUFBQW1CO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkJhZGdlIiwiQ2FyZCIsImZvcm1hdERhdGUiLCJzdGF0dXNUb25lIiwiQXV0b21hdGlvblJ1bnMiLCJydW5zIiwibGVuZ3RoIiwibWFwIiwibGFiZWwiLCJydW4iLCJkZWZpbml0aW9uIiwibmFtZSIsIndvcmtPcmRlciIsInRpdGxlIiwiY3JlYXRlZEF0Iiwic3RhdGUiLCJ3b3JrZmxvd0lkIiwibWV0YWRhdGEiLCJhdXRvbWF0aW9uV29ya2Zsb3dWZXJzaW9uIiwiYXBwcm92YWxTdGF0dXMiLCJ2ZXJpZmljYXRpb25TdGF0dXMiLCJyZWNlaXB0cyIsIl9pZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkF1dG9tYXRpb25SdW5zLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCYWRnZSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYmFkZ2VcIjtcbmltcG9ydCB7IENhcmQgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2NhcmRcIjtcbmltcG9ydCB7IGZvcm1hdERhdGUsIHN0YXR1c1RvbmUgfSBmcm9tIFwiLi9hdXRvbWF0aW9uTW9kZWxcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIEF1dG9tYXRpb25SdW5zKHsgcnVucyB9OiB7IHJ1bnM6IGFueVtdIH0pIHtcbiAgaWYgKHJ1bnMubGVuZ3RoID09PSAwKSByZXR1cm4gPENhcmQgY2xhc3NOYW1lPVwiYm9yZGVyLWRhc2hlZCBwLTggdGV4dC1jZW50ZXIgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5ObyBBdXRvbWF0aW9uIFJ1bnMgeWV0LiBMRVZFTF8xIGJlZ2lucyB3aXRoIGFuIGFwcHJvdmFsLWdhdGVkIFdvcmtPcmRlci48L0NhcmQ+O1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1bdmFyKC0tcGFuZWwtbGluZSldXCI+XG4gICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctWzk4MHB4XSB3LWZ1bGwgdGV4dC1sZWZ0IHRleHQtc21cIj5cbiAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWNhcmQvNzAgdGV4dC1bMTFweF0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjEzZW1dIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgIDx0cj57W1wiQXV0b21hdGlvblwiLCBcIldvcmtPcmRlclwiLCBcIkNyZWF0ZWRcIiwgXCJTdGF0ZVwiLCBcIldvcmtmbG93XCIsIFwiQXBwcm92YWxcIiwgXCJWZXJpZmljYXRpb25cIiwgXCJSZWNlaXB0XCJdLm1hcCgobGFiZWwpID0+IDx0aCBrZXk9e2xhYmVsfSBjbGFzc05hbWU9XCJweC0zIHB5LTMgZm9udC1tZWRpdW1cIj57bGFiZWx9PC90aD4pfTwvdHI+XG4gICAgICAgIDwvdGhlYWQ+XG4gICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtW3ZhcigtLXBhbmVsLWxpbmUpXVwiPlxuICAgICAgICAgIHtydW5zLm1hcCgocnVuKSA9PiA8dHIga2V5PXtydW4ud29ya09yZGVyLl9pZH0gY2xhc3NOYW1lPVwiYmctY2FyZC8zMFwiPlxuICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMyBmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmRcIj57cnVuLmRlZmluaXRpb24/Lm5hbWUgPz8gXCJVbmtub3duIEF1dG9tYXRpb25cIn08L3RkPlxuICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57cnVuLndvcmtPcmRlci50aXRsZX08L3RkPlxuICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57Zm9ybWF0RGF0ZShydW4ud29ya09yZGVyLmNyZWF0ZWRBdCl9PC90ZD5cbiAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTNcIj48QmFkZ2UgdmFyaWFudD1cIm91dGxpbmVcIiBjbGFzc05hbWU9e3N0YXR1c1RvbmUocnVuLndvcmtPcmRlci5zdGF0ZSl9PntydW4ud29ya09yZGVyLnN0YXRlfTwvQmFkZ2U+PC90ZD5cbiAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e3J1bi53b3JrT3JkZXIud29ya2Zsb3dJZH1Ae3J1bi53b3JrT3JkZXIubWV0YWRhdGE/LmF1dG9tYXRpb25Xb3JrZmxvd1ZlcnNpb259PC90ZD5cbiAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTNcIj57cnVuLndvcmtPcmRlci5hcHByb3ZhbFN0YXR1c308L3RkPlxuICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktM1wiPntydW4ud29ya09yZGVyLnZlcmlmaWNhdGlvblN0YXR1c308L3RkPlxuICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktM1wiPntydW4ucmVjZWlwdHMubGVuZ3RoID8gYCR7cnVuLnJlY2VpcHRzLmxlbmd0aH0gYXR0YWNoZWRgIDogXCJNaXNzaW5nXCJ9PC90ZD5cbiAgICAgICAgICA8L3RyPil9XG4gICAgICAgIDwvdGJvZHk+XG4gICAgICA8L3RhYmxlPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvYXV0b21hdGlvbnMvQXV0b21hdGlvblJ1bnMudHN4In0=