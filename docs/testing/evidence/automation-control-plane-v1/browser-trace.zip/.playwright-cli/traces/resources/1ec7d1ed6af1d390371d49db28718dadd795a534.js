import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/automations/AutomationSchedule.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { CalendarClock, PlayCircle } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { Badge } from "/src/components/ui/badge.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Card } from "/src/components/ui/card.tsx";
import { formatDate, statusTone } from "/src/automations/automationModel.ts";
export function AutomationSchedule({ projectId, definitions }) {
  _s();
  const evaluate = useMutation(api.automationScheduler.evaluateNow);
  const [busyId, setBusyId] = useState(null);
  const [message, setMessage] = useState(null);
  const scheduled = definitions.filter((definition) => definition.triggerType === "SCHEDULE");
  async function evaluateNow(definition) {
    setBusyId(definition._id);
    setMessage(null);
    try {
      const result = await evaluate({ projectId, automationDefinitionId: definition._id, actorId: "operator" });
      setMessage(result.created === 1 ? "One review-gate WorkOrder created." : `No duplicate created (${result.skipped} skipped).`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Evaluation failed");
    } finally {
      setBusyId(null);
    }
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxDEV("p", { role: "status", className: "min-h-5 text-sm text-muted-foreground", children: message }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
      lineNumber: 49,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(CalendarClock, { className: "h-4 w-4 text-registry-accent" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
          lineNumber: 52,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-sm font-semibold text-foreground", children: "Upcoming review gates" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
          lineNumber: 53,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-xs text-muted-foreground", children: "List view is authoritative. Times use each Automation’s configured timezone." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
        lineNumber: 55,
        columnNumber: 9
      }, this),
      scheduled.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-sm text-muted-foreground", children: "No scheduled Automation Definitions." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
        lineNumber: 56,
        columnNumber: 35
      }, this) : /* @__PURE__ */ jsxDEV("ul", { className: "mt-4 divide-y divide-[var(--panel-line)]", children: scheduled.map(
        (definition) => /* @__PURE__ */ jsxDEV("li", { className: "flex flex-wrap items-center justify-between gap-4 py-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-foreground", children: definition.name }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
                lineNumber: 61,
                columnNumber: 60
              }, this),
              /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", className: statusTone(definition.status), children: definition.status }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
                lineNumber: 61,
                columnNumber: 130
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
              lineNumber: 61,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-muted-foreground", children: [
              definition.triggerConfig?.cron,
              " · ",
              definition.triggerConfig?.timezone ?? "UTC"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
              lineNumber: 62,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-muted-foreground", children: [
              "Next: ",
              formatDate(definition.nextRunAt),
              " · Last: ",
              formatDate(definition.lastRunAt),
              " · Catch-up: ",
              definition.catchUpPolicy
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
              lineNumber: 63,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
            lineNumber: 60,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", disabled: definition.status !== "ACTIVE" || busyId === definition._id, onClick: () => void evaluateNow(definition), children: [
            /* @__PURE__ */ jsxDEV(PlayCircle, { className: "h-3.5 w-3.5" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
              lineNumber: 66,
              columnNumber: 19
            }, this),
            " ",
            busyId === definition._id ? "Evaluating…" : "Evaluate due gate"
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
            lineNumber: 65,
            columnNumber: 17
          }, this)
        ] }, definition._id, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
          lineNumber: 59,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
        lineNumber: 57,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
      lineNumber: 50,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx",
    lineNumber: 48,
    columnNumber: 5
  }, this);
}
_s(AutomationSchedule, "iDhTewPcFl5yV5aFq4yLun2/RTM=", false, function() {
  return [useMutation];
});
_c = AutomationSchedule;
var _c;
$RefreshReg$(_c, "AutomationSchedule");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationSchedule.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTdCTixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGVBQWVDLGtCQUFrQjtBQUMxQyxTQUFTQyxXQUFXO0FBRXBCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLFlBQVlDLGtCQUFrQjtBQUVoQyxnQkFBU0MsbUJBQW1CLEVBQUVDLFdBQVdDLFlBQStELEdBQUc7QUFBQUMsS0FBQTtBQUNoSCxRQUFNQyxXQUFXYixZQUFZRyxJQUFJVyxvQkFBb0JDLFdBQVc7QUFDaEUsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlsQixTQUF3QixJQUFJO0FBQ3hELFFBQU0sQ0FBQ21CLFNBQVNDLFVBQVUsSUFBSXBCLFNBQXdCLElBQUk7QUFDMUQsUUFBTXFCLFlBQVlULFlBQVlVLE9BQU8sQ0FBQ0MsZUFBZUEsV0FBV0MsZ0JBQWdCLFVBQVU7QUFDMUYsaUJBQWVSLFlBQVlPLFlBQWlCO0FBQzFDTCxjQUFVSyxXQUFXRSxHQUFHO0FBQ3hCTCxlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0YsWUFBTU0sU0FBUyxNQUFNWixTQUFTLEVBQUVILFdBQVdnQix3QkFBd0JKLFdBQVdFLEtBQUtHLFNBQVMsV0FBVyxDQUFDO0FBQ3hHUixpQkFBV00sT0FBT0csWUFBWSxJQUFJLHVDQUF1Qyx5QkFBeUJILE9BQU9JLE9BQU8sWUFBWTtBQUFBLElBQzlILFNBQVNDLE9BQU87QUFDZFgsaUJBQVdXLGlCQUFpQkMsUUFBUUQsTUFBTVosVUFBVSxtQkFBbUI7QUFBQSxJQUN6RSxVQUFDO0FBQ0NELGdCQUFVLElBQUk7QUFBQSxJQUNoQjtBQUFBLEVBQ0Y7QUFDQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsMkJBQUMsT0FBRSxNQUFLLFVBQVMsV0FBVSx5Q0FBeUNDLHFCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRFO0FBQUEsSUFDNUUsdUJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwrQkFBQyxpQkFBYyxXQUFVLGtDQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVEO0FBQUEsUUFDdkQsdUJBQUMsUUFBRyxXQUFVLHlDQUF3QyxxQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRTtBQUFBLFdBRjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLHNDQUFxQyw0RkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4SDtBQUFBLE1BQzdIRSxVQUFVWSxXQUFXLElBQUksdUJBQUMsT0FBRSxXQUFVLHNDQUFxQyxvREFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRixJQUM5Ryx1QkFBQyxRQUFHLFdBQVUsNENBQ1haLG9CQUFVYTtBQUFBQSxRQUFJLENBQUNYLGVBQ2QsdUJBQUMsUUFBd0IsV0FBVSwwREFDakM7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDJCQUEwQjtBQUFBLHFDQUFDLFVBQUssV0FBVSwrQkFBK0JBLHFCQUFXWSxRQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErRDtBQUFBLGNBQU8sdUJBQUMsU0FBTSxTQUFRLFdBQVUsV0FBVzFCLFdBQVdjLFdBQVdhLE1BQU0sR0FBSWIscUJBQVdhLFVBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNGO0FBQUEsaUJBQXJNO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZNO0FBQUEsWUFDN00sdUJBQUMsT0FBRSxXQUFVLHNDQUFzQ2I7QUFBQUEseUJBQVdjLGVBQWVDO0FBQUFBLGNBQUs7QUFBQSxjQUFJZixXQUFXYyxlQUFlRSxZQUFZO0FBQUEsaUJBQTVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtJO0FBQUEsWUFDbEksdUJBQUMsT0FBRSxXQUFVLHNDQUFxQztBQUFBO0FBQUEsY0FBTy9CLFdBQVdlLFdBQVdpQixTQUFTO0FBQUEsY0FBRTtBQUFBLGNBQVVoQyxXQUFXZSxXQUFXa0IsU0FBUztBQUFBLGNBQUU7QUFBQSxjQUFjbEIsV0FBV21CO0FBQUFBLGlCQUE5SjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0SztBQUFBLGVBSDlLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUNBLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsV0FBVSxVQUFVbkIsV0FBV2EsV0FBVyxZQUFZbkIsV0FBV00sV0FBV0UsS0FBSyxTQUFTLE1BQU0sS0FBS1QsWUFBWU8sVUFBVSxHQUNuSjtBQUFBLG1DQUFDLGNBQVcsV0FBVSxpQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUM7QUFBQSxZQUFHO0FBQUEsWUFBRU4sV0FBV00sV0FBV0UsTUFBTSxnQkFBZ0I7QUFBQSxlQUR0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFST0YsV0FBV0UsS0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsTUFDRCxLQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLFNBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQkE7QUFBQSxPQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUJBO0FBRUo7QUFBQ1osR0E3Q2VILG9CQUFrQjtBQUFBLFVBQ2ZULFdBQVc7QUFBQTtBQUFBLEtBRGRTO0FBQWtCLElBQUFpQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZU11dGF0aW9uIiwiQ2FsZW5kYXJDbG9jayIsIlBsYXlDaXJjbGUiLCJhcGkiLCJCYWRnZSIsIkJ1dHRvbiIsIkNhcmQiLCJmb3JtYXREYXRlIiwic3RhdHVzVG9uZSIsIkF1dG9tYXRpb25TY2hlZHVsZSIsInByb2plY3RJZCIsImRlZmluaXRpb25zIiwiX3MiLCJldmFsdWF0ZSIsImF1dG9tYXRpb25TY2hlZHVsZXIiLCJldmFsdWF0ZU5vdyIsImJ1c3lJZCIsInNldEJ1c3lJZCIsIm1lc3NhZ2UiLCJzZXRNZXNzYWdlIiwic2NoZWR1bGVkIiwiZmlsdGVyIiwiZGVmaW5pdGlvbiIsInRyaWdnZXJUeXBlIiwiX2lkIiwicmVzdWx0IiwiYXV0b21hdGlvbkRlZmluaXRpb25JZCIsImFjdG9ySWQiLCJjcmVhdGVkIiwic2tpcHBlZCIsImVycm9yIiwiRXJyb3IiLCJsZW5ndGgiLCJtYXAiLCJuYW1lIiwic3RhdHVzIiwidHJpZ2dlckNvbmZpZyIsImNyb24iLCJ0aW1lem9uZSIsIm5leHRSdW5BdCIsImxhc3RSdW5BdCIsImNhdGNoVXBQb2xpY3kiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBdXRvbWF0aW9uU2NoZWR1bGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VNdXRhdGlvbiB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IENhbGVuZGFyQ2xvY2ssIFBsYXlDaXJjbGUgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgQmFkZ2UgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2JhZGdlXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuaW1wb3J0IHsgQ2FyZCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvY2FyZFwiO1xuaW1wb3J0IHsgZm9ybWF0RGF0ZSwgc3RhdHVzVG9uZSB9IGZyb20gXCIuL2F1dG9tYXRpb25Nb2RlbFwiO1xuXG5leHBvcnQgZnVuY3Rpb24gQXV0b21hdGlvblNjaGVkdWxlKHsgcHJvamVjdElkLCBkZWZpbml0aW9ucyB9OiB7IHByb2plY3RJZDogSWQ8XCJwcm9qZWN0c1wiPjsgZGVmaW5pdGlvbnM6IGFueVtdIH0pIHtcbiAgY29uc3QgZXZhbHVhdGUgPSB1c2VNdXRhdGlvbihhcGkuYXV0b21hdGlvblNjaGVkdWxlci5ldmFsdWF0ZU5vdyk7XG4gIGNvbnN0IFtidXN5SWQsIHNldEJ1c3lJZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHNjaGVkdWxlZCA9IGRlZmluaXRpb25zLmZpbHRlcigoZGVmaW5pdGlvbikgPT4gZGVmaW5pdGlvbi50cmlnZ2VyVHlwZSA9PT0gXCJTQ0hFRFVMRVwiKTtcbiAgYXN5bmMgZnVuY3Rpb24gZXZhbHVhdGVOb3coZGVmaW5pdGlvbjogYW55KSB7XG4gICAgc2V0QnVzeUlkKGRlZmluaXRpb24uX2lkKTtcbiAgICBzZXRNZXNzYWdlKG51bGwpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBldmFsdWF0ZSh7IHByb2plY3RJZCwgYXV0b21hdGlvbkRlZmluaXRpb25JZDogZGVmaW5pdGlvbi5faWQsIGFjdG9ySWQ6IFwib3BlcmF0b3JcIiB9KTtcbiAgICAgIHNldE1lc3NhZ2UocmVzdWx0LmNyZWF0ZWQgPT09IDEgPyBcIk9uZSByZXZpZXctZ2F0ZSBXb3JrT3JkZXIgY3JlYXRlZC5cIiA6IGBObyBkdXBsaWNhdGUgY3JlYXRlZCAoJHtyZXN1bHQuc2tpcHBlZH0gc2tpcHBlZCkuYCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHNldE1lc3NhZ2UoZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIkV2YWx1YXRpb24gZmFpbGVkXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRCdXN5SWQobnVsbCk7XG4gICAgfVxuICB9XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgIDxwIHJvbGU9XCJzdGF0dXNcIiBjbGFzc05hbWU9XCJtaW4taC01IHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e21lc3NhZ2V9PC9wPlxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC00XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICA8Q2FsZW5kYXJDbG9jayBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtcmVnaXN0cnktYWNjZW50XCIgLz5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZm9yZWdyb3VuZFwiPlVwY29taW5nIHJldmlldyBnYXRlczwvaDI+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+TGlzdCB2aWV3IGlzIGF1dGhvcml0YXRpdmUuIFRpbWVzIHVzZSBlYWNoIEF1dG9tYXRpb27igJlzIGNvbmZpZ3VyZWQgdGltZXpvbmUuPC9wPlxuICAgICAgICB7c2NoZWR1bGVkLmxlbmd0aCA9PT0gMCA/IDxwIGNsYXNzTmFtZT1cIm10LTQgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5ObyBzY2hlZHVsZWQgQXV0b21hdGlvbiBEZWZpbml0aW9ucy48L3A+IDogKFxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJtdC00IGRpdmlkZS15IGRpdmlkZS1bdmFyKC0tcGFuZWwtbGluZSldXCI+XG4gICAgICAgICAgICB7c2NoZWR1bGVkLm1hcCgoZGVmaW5pdGlvbikgPT4gKFxuICAgICAgICAgICAgICA8bGkga2V5PXtkZWZpbml0aW9uLl9pZH0gY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBweS00XCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj48c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmRcIj57ZGVmaW5pdGlvbi5uYW1lfTwvc3Bhbj48QmFkZ2UgdmFyaWFudD1cIm91dGxpbmVcIiBjbGFzc05hbWU9e3N0YXR1c1RvbmUoZGVmaW5pdGlvbi5zdGF0dXMpfT57ZGVmaW5pdGlvbi5zdGF0dXN9PC9CYWRnZT48L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57ZGVmaW5pdGlvbi50cmlnZ2VyQ29uZmlnPy5jcm9ufSDCtyB7ZGVmaW5pdGlvbi50cmlnZ2VyQ29uZmlnPy50aW1lem9uZSA/PyBcIlVUQ1wifTwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5OZXh0OiB7Zm9ybWF0RGF0ZShkZWZpbml0aW9uLm5leHRSdW5BdCl9IMK3IExhc3Q6IHtmb3JtYXREYXRlKGRlZmluaXRpb24ubGFzdFJ1bkF0KX0gwrcgQ2F0Y2gtdXA6IHtkZWZpbml0aW9uLmNhdGNoVXBQb2xpY3l9PC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cIm91dGxpbmVcIiBkaXNhYmxlZD17ZGVmaW5pdGlvbi5zdGF0dXMgIT09IFwiQUNUSVZFXCIgfHwgYnVzeUlkID09PSBkZWZpbml0aW9uLl9pZH0gb25DbGljaz17KCkgPT4gdm9pZCBldmFsdWF0ZU5vdyhkZWZpbml0aW9uKX0+XG4gICAgICAgICAgICAgICAgICA8UGxheUNpcmNsZSBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+IHtidXN5SWQgPT09IGRlZmluaXRpb24uX2lkID8gXCJFdmFsdWF0aW5n4oCmXCIgOiBcIkV2YWx1YXRlIGR1ZSBnYXRlXCJ9XG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L3VsPlxuICAgICAgICApfVxuICAgICAgPC9DYXJkPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvYXV0b21hdGlvbnMvQXV0b21hdGlvblNjaGVkdWxlLnRzeCJ9