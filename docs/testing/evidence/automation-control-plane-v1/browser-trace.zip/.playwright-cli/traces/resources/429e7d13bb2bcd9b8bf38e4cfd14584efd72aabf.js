import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/MonitoringDashboard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport5_react["useState"];
import { X } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { cn } from "/src/lib/utils.ts";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "/src/components/ui/table.tsx";
import { MetricBlock, MetricRow } from "/src/components/factory/MetricBlock.tsx";
import { StatusBadge } from "/src/components/factory/badges.tsx";
function severityTone(severity) {
  switch (severity) {
    case "CRITICAL":
    case "ERROR":
      return "error";
    case "WARNING":
      return "warning";
    case "INFO":
      return "info";
    default:
      return "neutral";
  }
}
export function MonitoringDashboard({ onClose }) {
  _s();
  const [selectedTab, setSelectedTab] = useState("errors");
  const recentErrors = useQuery(api.monitoring.listRecentErrors, { limit: 50 });
  const performanceStats = useQuery(api.monitoring.getPerformanceStats, {});
  const auditLog = useQuery(api.monitoring.getAuditLog, { limit: 100 });
  if (!recentErrors || !performanceStats || !auditLog) {
    return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[1000] flex items-center justify-center bg-black/70", children: /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-line bg-surface-1 p-10 text-[13px] text-ink-secondary", children: "Loading monitoring data..." }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
      lineNumber: 63,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
      lineNumber: 62,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "fixed inset-0 z-[1000] flex items-center justify-center overflow-auto bg-black/70 p-5",
      onClick: onClose,
      children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "max-h-[90vh] w-full max-w-[1400px] overflow-auto rounded-xl border border-line bg-surface-1",
          onClick: (e) => e.stopPropagation(),
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-line p-6", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-[19px] font-semibold text-ink", children: "Monitoring" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
                  lineNumber: 82,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-[13px] text-ink-secondary", children: "Real-time system monitoring and audit logs" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
                  lineNumber: 83,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
                lineNumber: 81,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: onClose,
                  "aria-label": "Close monitoring",
                  className: "rounded-md p-1.5 text-ink-muted transition-colors duration-150 hover:bg-surface-2 hover:text-ink",
                  children: /* @__PURE__ */ jsxDEV(X, { size: 16, strokeWidth: 1.75 }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
                    lineNumber: 92,
                    columnNumber: 13
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
                  lineNumber: 87,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
              lineNumber: 80,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 border-b border-line px-6", role: "tablist", children: [
              /* @__PURE__ */ jsxDEV(
                TabButton,
                {
                  label: "Errors",
                  active: selectedTab === "errors",
                  onClick: () => setSelectedTab("errors"),
                  count: recentErrors.length
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
                  lineNumber: 98,
                  columnNumber: 11
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                TabButton,
                {
                  label: "Performance",
                  active: selectedTab === "performance",
                  onClick: () => setSelectedTab("performance")
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
                  lineNumber: 104,
                  columnNumber: 11
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                TabButton,
                {
                  label: "Audit log",
                  active: selectedTab === "audit",
                  onClick: () => setSelectedTab("audit"),
                  count: auditLog.length
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
                  lineNumber: 109,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
              lineNumber: 97,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: [
              selectedTab === "errors" && /* @__PURE__ */ jsxDEV(ErrorsTab, { errors: recentErrors }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
                lineNumber: 119,
                columnNumber: 40
              }, this),
              selectedTab === "performance" && /* @__PURE__ */ jsxDEV(PerformanceTab, { stats: performanceStats }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
                lineNumber: 120,
                columnNumber: 45
              }, this),
              selectedTab === "audit" && /* @__PURE__ */ jsxDEV(AuditTab, { logs: auditLog }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
                lineNumber: 121,
                columnNumber: 39
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
              lineNumber: 118,
              columnNumber: 9
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
          lineNumber: 75,
          columnNumber: 7
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
      lineNumber: 71,
      columnNumber: 5
    },
    this
  );
}
_s(MonitoringDashboard, "dupgQOR3btXi7JzusafDUPVcfok=", false, function() {
  return [useQuery, useQuery, useQuery];
});
_c = MonitoringDashboard;
function TabButton({
  label,
  active,
  onClick,
  count
}) {
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      role: "tab",
      "aria-selected": active,
      onClick,
      className: cn(
        "-mb-px flex items-center gap-1.5 border-b-2 px-3 py-2.5 text-[13px] transition-colors duration-150",
        active ? "border-ink text-ink" : "border-transparent text-ink-muted hover:text-ink-secondary"
      ),
      children: [
        label,
        count !== void 0 && /* @__PURE__ */ jsxDEV("span", { className: "rounded-md border border-line bg-surface-2 px-1.5 py-0.5 text-[11.5px] font-medium leading-none text-ink-secondary", children: count }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
          lineNumber: 153,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
      lineNumber: 140,
      columnNumber: 5
    },
    this
  );
}
_c2 = TabButton;
const SENSITIVE_KEYS = /* @__PURE__ */ new Set(
  [
    "token",
    "access_token",
    "refresh_token",
    "id_token",
    "password",
    "passwd",
    "secret",
    "api_key",
    "apikey",
    "apiKey",
    "auth",
    "authorization",
    "credentials",
    "private_key",
    "privateKey",
    "ssn",
    "email",
    "cookie",
    "session",
    "jwt",
    "bearer",
    "client_secret",
    "clientSecret",
    "connection_string",
    "connectionString"
  ]
);
const SENSITIVE_PATTERNS = [
  /^sk[-_]/i,
  // Stripe/OpenAI secret keys
  /^ghp_/i,
  // GitHub PATs
  /^xoxb-/i,
  // Slack tokens
  /bearer\s+\S+/i
];
function isSensitiveValue(value) {
  if (typeof value !== "string") return false;
  return SENSITIVE_PATTERNS.some((pattern) => pattern.test(value));
}
function sanitizeMetadata(obj) {
  if (obj === null || obj === void 0) return obj;
  if (typeof obj === "string") {
    return isSensitiveValue(obj) ? "[REDACTED]" : obj;
  }
  if (Array.isArray(obj)) {
    return obj.map(sanitizeMetadata);
  }
  if (typeof obj === "object") {
    const result = {};
    for (const [key, value] of Object.entries(obj)) {
      if (SENSITIVE_KEYS.has(key.toLowerCase())) {
        result[key] = "[REDACTED]";
      } else {
        result[key] = sanitizeMetadata(value);
      }
    }
    return result;
  }
  return obj;
}
function ErrorsTab({ errors }) {
  if (errors.length === 0) {
    return /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-10 text-center text-ink-muted", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-[15px] font-semibold text-ink", children: "No errors" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 207,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-[13px]", children: "System is running smoothly" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 208,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
      lineNumber: 206,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3", children: errors.map((error, idx) => {
    const errorType = error.metadata?.errorType || "ERROR";
    const severity = errorType === "CRITICAL" || errorType === "DATABASE_ERROR" || errorType === "API_ERROR" ? "CRITICAL" : errorType === "WARNING" ? "WARNING" : "ERROR";
    return /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-line bg-surface-2 p-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-2 flex items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxDEV(StatusBadge, { tone: severityTone(severity), children: severity }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
          lineNumber: 227,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-[12px] text-ink-muted", children: new Date(error._creationTime).toLocaleString() }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
          lineNumber: 228,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 226,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-2 text-[13.5px] text-ink", children: error.description }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 232,
        columnNumber: 13
      }, this),
      error.metadata && /* @__PURE__ */ jsxDEV("div", { className: "overflow-auto rounded-md bg-surface-1 p-2 font-mono text-[12px] text-ink-muted", children: JSON.stringify(sanitizeMetadata(error.metadata), null, 2) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 234,
        columnNumber: 13
      }, this)
    ] }, idx, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
      lineNumber: 225,
      columnNumber: 11
    }, this);
  }) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
    lineNumber: 214,
    columnNumber: 5
  }, this);
}
_c3 = ErrorsTab;
function PerformanceTab({ stats }) {
  const logs = stats.recentLogs || [];
  const slowest = [...logs].sort((a, b) => (b.metadata?.durationMs || 0) - (a.metadata?.durationMs || 0)).slice(0, 8);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(MetricRow, { className: "mb-6", children: [
      /* @__PURE__ */ jsxDEV(MetricBlock, { label: "Average duration", value: `${Math.round(stats.avgDurationMs || 0)}ms` }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 254,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(MetricBlock, { label: "Min duration", value: `${Math.round(stats.minDurationMs || 0)}ms` }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 255,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        MetricBlock,
        {
          label: "Max duration",
          value: `${Math.round(stats.maxDurationMs || 0)}ms`,
          adornment: (stats.maxDurationMs || 0) > 5e3 ? /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "warning", children: "Slow" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
            lineNumber: 260,
            columnNumber: 47
          }, this) : void 0
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
          lineNumber: 256,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(MetricBlock, { label: "Sample count", value: stats.count || 0 }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 263,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
      lineNumber: 253,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-line bg-surface-1 p-5", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-[15px] font-semibold text-ink", children: "Recent slow operations" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 267,
        columnNumber: 9
      }, this),
      slowest.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: slowest.map((log, idx) => {
        const duration = log.metadata?.durationMs || 0;
        const operation = log.metadata?.operation || "Unknown operation";
        return /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "flex items-center justify-between border-b border-line px-1 py-2 last:border-b-0",
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] text-ink-secondary", children: operation }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
                lineNumber: 278,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: cn(
                    "font-mono text-[13px]",
                    duration > 1e3 ? "text-err" : "text-ink-muted"
                  ),
                  children: [
                    Math.round(duration),
                    "ms"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
                  lineNumber: 279,
                  columnNumber: 19
                },
                this
              )
            ]
          },
          idx,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
            lineNumber: 274,
            columnNumber: 15
          },
          this
        );
      }) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 269,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-5 text-center text-[13px] text-ink-muted", children: "No performance data yet" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 292,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
      lineNumber: 266,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
    lineNumber: 252,
    columnNumber: 5
  }, this);
}
_c4 = PerformanceTab;
function AuditTab({ logs }) {
  if (logs.length === 0) {
    return /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-10 text-center text-ink-muted", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-[15px] font-semibold text-ink", children: "No audit logs" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 305,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-[13px]", children: "Activity will appear here" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 306,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
      lineNumber: 304,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "max-h-[600px] overflow-auto rounded-xl border border-line", children: /* @__PURE__ */ jsxDEV(Table, { children: [
    /* @__PURE__ */ jsxDEV(TableHeader, { children: /* @__PURE__ */ jsxDEV(TableRow, { className: "border-b border-line hover:bg-transparent", children: [
      /* @__PURE__ */ jsxDEV(TableHead, { className: "px-4 py-2.5 text-[11.5px] font-medium uppercase tracking-[0.06em] text-ink-muted", children: "Time" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 316,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TableHead, { className: "px-4 py-2.5 text-[11.5px] font-medium uppercase tracking-[0.06em] text-ink-muted", children: "Actor" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 317,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TableHead, { className: "px-4 py-2.5 text-[11.5px] font-medium uppercase tracking-[0.06em] text-ink-muted", children: "Action" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 318,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TableHead, { className: "px-4 py-2.5 text-[11.5px] font-medium uppercase tracking-[0.06em] text-ink-muted", children: "Target" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 319,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
      lineNumber: 315,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
      lineNumber: 314,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(TableBody, { children: logs.map(
      (log, idx) => /* @__PURE__ */ jsxDEV(TableRow, { className: "border-b border-line last:border-b-0 hover:bg-surface-2", children: [
        /* @__PURE__ */ jsxDEV(TableCell, { className: "px-4 py-3 text-[12.5px] text-ink-muted", children: new Date(log._creationTime).toLocaleTimeString() }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
          lineNumber: 325,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { className: "px-4 py-3 text-[12.5px] text-ink-secondary", children: [
          log.actorType,
          ": ",
          log.actorId || "System"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
          lineNumber: 328,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { className: "px-4 py-3 text-[12.5px] font-medium text-ink", children: log.action }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
          lineNumber: 331,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { className: "px-4 py-3 text-[12.5px] text-ink-muted", children: [
          log.targetType,
          ": ",
          log.targetId
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
          lineNumber: 334,
          columnNumber: 15
        }, this)
      ] }, idx, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
        lineNumber: 324,
        columnNumber: 11
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
      lineNumber: 322,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
    lineNumber: 313,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx",
    lineNumber: 312,
    columnNumber: 5
  }, this);
}
_c5 = AuditTab;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "MonitoringDashboard");
$RefreshReg$(_c2, "TabButton");
$RefreshReg$(_c3, "ErrorsTab");
$RefreshReg$(_c4, "PerformanceTab");
$RefreshReg$(_c5, "AuditTab");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MonitoringDashboard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNROzs7Ozs7Ozs7Ozs7Ozs7OztBQTNDUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsV0FBVztBQUNwQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsU0FBUztBQUNsQixTQUFTQyxVQUFVO0FBQ25CO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLGFBQWFDLGlCQUFpQjtBQUN2QyxTQUFTQyxtQkFBMEM7QUFNbkQsU0FBU0MsYUFBYUMsVUFBNEM7QUFDaEUsVUFBUUEsVUFBUTtBQUFBLElBQ2QsS0FBSztBQUFBLElBQ0wsS0FBSztBQUNILGFBQU87QUFBQSxJQUNULEtBQUs7QUFDSCxhQUFPO0FBQUEsSUFDVCxLQUFLO0FBQ0gsYUFBTztBQUFBLElBQ1Q7QUFDRSxhQUFPO0FBQUEsRUFDWDtBQUNGO0FBRU8sZ0JBQVNDLG9CQUFvQixFQUFFQyxRQUFrQyxHQUFHO0FBQUFDLEtBQUE7QUFDekUsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUlsQixTQUE2QyxRQUFRO0FBQzNGLFFBQU1tQixlQUFlckIsU0FBU0MsSUFBSXFCLFdBQVdDLGtCQUFrQixFQUFFQyxPQUFPLEdBQUcsQ0FBQztBQUM1RSxRQUFNQyxtQkFBbUJ6QixTQUFTQyxJQUFJcUIsV0FBV0kscUJBQXFCLENBQUMsQ0FBQztBQUN4RSxRQUFNQyxXQUFXM0IsU0FBU0MsSUFBSXFCLFdBQVdNLGFBQWEsRUFBRUosT0FBTyxJQUFJLENBQUM7QUFFcEUsTUFBSSxDQUFDSCxnQkFBZ0IsQ0FBQ0ksb0JBQW9CLENBQUNFLFVBQVU7QUFDbkQsV0FDRSx1QkFBQyxTQUFJLFdBQVUsdUVBQ2IsaUNBQUMsU0FBSSxXQUFVLGtGQUFnRiwwQ0FBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsRUFFSjtBQUVBLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVU7QUFBQSxNQUNWLFNBQVNWO0FBQUFBLE1BRVQ7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVU7QUFBQSxVQUNWLFNBQVMsQ0FBQ1ksTUFBTUEsRUFBRUMsZ0JBQWdCO0FBQUEsVUFHbEM7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsOERBQ2I7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHNDQUFxQywwQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkQ7QUFBQSxnQkFDN0QsdUJBQUMsT0FBRSxXQUFVLHVDQUFxQywwREFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVNiO0FBQUFBLGtCQUNULGNBQVc7QUFBQSxrQkFDWCxXQUFVO0FBQUEsa0JBRVYsaUNBQUMsS0FBRSxNQUFNLElBQUksYUFBYSxRQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQjtBQUFBO0FBQUEsZ0JBTGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsaUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLHFEQUFvRCxNQUFLLFdBQ3RFO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTTtBQUFBLGtCQUNOLFFBQVFFLGdCQUFnQjtBQUFBLGtCQUN4QixTQUFTLE1BQU1DLGVBQWUsUUFBUTtBQUFBLGtCQUN0QyxPQUFPQyxhQUFhVTtBQUFBQTtBQUFBQSxnQkFKdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSTZCO0FBQUEsY0FFN0I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTTtBQUFBLGtCQUNOLFFBQVFaLGdCQUFnQjtBQUFBLGtCQUN4QixTQUFTLE1BQU1DLGVBQWUsYUFBYTtBQUFBO0FBQUEsZ0JBSDdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUcrQztBQUFBLGNBRS9DO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU07QUFBQSxrQkFDTixRQUFRRCxnQkFBZ0I7QUFBQSxrQkFDeEIsU0FBUyxNQUFNQyxlQUFlLE9BQU87QUFBQSxrQkFDckMsT0FBT08sU0FBU0k7QUFBQUE7QUFBQUEsZ0JBSmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUl5QjtBQUFBLGlCQWhCM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrQkE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSxPQUNaWjtBQUFBQSw4QkFBZ0IsWUFBWSx1QkFBQyxhQUFVLFFBQVFFLGdCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGNBQzVERixnQkFBZ0IsaUJBQWlCLHVCQUFDLGtCQUFlLE9BQU9NLG9CQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QztBQUFBLGNBQ3pFTixnQkFBZ0IsV0FBVyx1QkFBQyxZQUFTLE1BQU1RLFlBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlCO0FBQUEsaUJBSHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQTtBQUFBO0FBQUEsUUEvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BZ0RBO0FBQUE7QUFBQSxJQXBERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFxREE7QUFFSjtBQUFDVCxHQXhFZUYscUJBQW1CO0FBQUEsVUFFWmhCLFVBQ0lBLFVBQ1JBLFFBQVE7QUFBQTtBQUFBLEtBSlhnQjtBQTBFaEIsU0FBU2dCLFVBQVU7QUFBQSxFQUNqQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFNRixHQUFHO0FBQ0QsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsTUFBSztBQUFBLE1BQ0wsaUJBQWVGO0FBQUFBLE1BQ2Y7QUFBQSxNQUNBLFdBQVc5QjtBQUFBQSxRQUNUO0FBQUEsUUFDQThCLFNBQ0ksd0JBQ0E7QUFBQSxNQUNOO0FBQUEsTUFFQ0Q7QUFBQUE7QUFBQUEsUUFDQUcsVUFBVUMsVUFDVCx1QkFBQyxVQUFLLFdBQVUsc0hBQ2JELG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBO0FBQUE7QUFBQSxJQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWlCQTtBQUVKO0FBQUNFLE1BL0JRTjtBQWlDVCxNQUFNTyxpQkFBaUIsb0JBQUlDO0FBQUFBLEVBQUk7QUFBQSxJQUM3QjtBQUFBLElBQVM7QUFBQSxJQUFnQjtBQUFBLElBQWlCO0FBQUEsSUFDMUM7QUFBQSxJQUFZO0FBQUEsSUFBVTtBQUFBLElBQVU7QUFBQSxJQUFXO0FBQUEsSUFBVTtBQUFBLElBQ3JEO0FBQUEsSUFBUTtBQUFBLElBQWlCO0FBQUEsSUFBZTtBQUFBLElBQWU7QUFBQSxJQUN2RDtBQUFBLElBQU87QUFBQSxJQUFTO0FBQUEsSUFBVTtBQUFBLElBQVc7QUFBQSxJQUFPO0FBQUEsSUFDNUM7QUFBQSxJQUFpQjtBQUFBLElBQWdCO0FBQUEsSUFBcUI7QUFBQSxFQUFrQjtBQUN6RTtBQUVELE1BQU1DLHFCQUFxQjtBQUFBLEVBQ3pCO0FBQUE7QUFBQSxFQUNBO0FBQUE7QUFBQSxFQUNBO0FBQUE7QUFBQSxFQUNBO0FBQWU7QUFHakIsU0FBU0MsaUJBQWlCQyxPQUF5QjtBQUNqRCxNQUFJLE9BQU9BLFVBQVUsU0FBVSxRQUFPO0FBQ3RDLFNBQU9GLG1CQUFtQkcsS0FBSyxDQUFDQyxZQUFZQSxRQUFRQyxLQUFLSCxLQUFLLENBQUM7QUFDakU7QUFFQSxTQUFTSSxpQkFBaUJDLEtBQXVCO0FBQy9DLE1BQUlBLFFBQVEsUUFBUUEsUUFBUVgsT0FBVyxRQUFPVztBQUM5QyxNQUFJLE9BQU9BLFFBQVEsVUFBVTtBQUMzQixXQUFPTixpQkFBaUJNLEdBQUcsSUFBSSxlQUFlQTtBQUFBQSxFQUNoRDtBQUNBLE1BQUlDLE1BQU1DLFFBQVFGLEdBQUcsR0FBRztBQUN0QixXQUFPQSxJQUFJRyxJQUFJSixnQkFBZ0I7QUFBQSxFQUNqQztBQUNBLE1BQUksT0FBT0MsUUFBUSxVQUFVO0FBQzNCLFVBQU1JLFNBQWtDLENBQUM7QUFDekMsZUFBVyxDQUFDQyxLQUFLVixLQUFLLEtBQUtXLE9BQU9DLFFBQVFQLEdBQThCLEdBQUc7QUFDekUsVUFBSVQsZUFBZWlCLElBQUlILElBQUlJLFlBQVksQ0FBQyxHQUFHO0FBQ3pDTCxlQUFPQyxHQUFHLElBQUk7QUFBQSxNQUNoQixPQUFPO0FBQ0xELGVBQU9DLEdBQUcsSUFBSU4saUJBQWlCSixLQUFLO0FBQUEsTUFDdEM7QUFBQSxJQUNGO0FBQ0EsV0FBT1M7QUFBQUEsRUFDVDtBQUNBLFNBQU9KO0FBQ1Q7QUFFQSxTQUFTVSxVQUFVLEVBQUVDLE9BQVksR0FBRztBQUNsQyxNQUFJQSxPQUFPNUIsV0FBVyxHQUFHO0FBQ3ZCLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHNDQUFxQyx5QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLE1BQzdELHVCQUFDLFNBQUksV0FBVSxvQkFBbUIsMENBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEQ7QUFBQSxTQUY5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsdUJBQ1o0QixpQkFBT1IsSUFBSSxDQUFDUyxPQUFZQyxRQUFnQjtBQUN2QyxVQUFNQyxZQUFZRixNQUFNRyxVQUFVRCxhQUFhO0FBQy9DLFVBQU0vQyxXQUNKK0MsY0FBYyxjQUFjQSxjQUFjLG9CQUFvQkEsY0FBYyxjQUN4RSxhQUNBQSxjQUFjLFlBQ1osWUFDQTtBQUVSLFdBQ0UsdUJBQUMsU0FBYyxXQUFVLGtEQUN2QjtBQUFBLDZCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLCtCQUFDLGVBQVksTUFBTWhELGFBQWFDLFFBQVEsR0FBSUEsc0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUQ7QUFBQSxRQUNyRCx1QkFBQyxTQUFJLFdBQVUsOEJBQ1osY0FBSWlELEtBQUtKLE1BQU1LLGFBQWEsRUFBRUMsZUFBZSxLQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLCtCQUErQk4sZ0JBQU1PLGVBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0U7QUFBQSxNQUMvRFAsTUFBTUcsWUFDTCx1QkFBQyxTQUFJLFdBQVUsa0ZBQ1pLLGVBQUtDLFVBQVV0QixpQkFBaUJhLE1BQU1HLFFBQVEsR0FBRyxNQUFNLENBQUMsS0FEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FYTUYsS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxFQUVKLENBQUMsS0ExQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJCQTtBQUVKO0FBQUNTLE1BeENRWjtBQTBDVCxTQUFTYSxlQUFlLEVBQUVDLE1BQVcsR0FBRztBQUN0QyxRQUFNQyxPQUFPRCxNQUFNRSxjQUFjO0FBQ2pDLFFBQU1DLFVBQVUsQ0FBQyxHQUFHRixJQUFJLEVBQ3JCRyxLQUFLLENBQUNDLEdBQVFDLE9BQVlBLEVBQUVmLFVBQVVnQixjQUFjLE1BQU1GLEVBQUVkLFVBQVVnQixjQUFjLEVBQUUsRUFDdEZDLE1BQU0sR0FBRyxDQUFDO0FBRWIsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsYUFBVSxXQUFVLFFBQ25CO0FBQUEsNkJBQUMsZUFBWSxPQUFNLG9CQUFtQixPQUFPLEdBQUdDLEtBQUtDLE1BQU1WLE1BQU1XLGlCQUFpQixDQUFDLENBQUMsUUFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RjtBQUFBLE1BQ3pGLHVCQUFDLGVBQVksT0FBTSxnQkFBZSxPQUFPLEdBQUdGLEtBQUtDLE1BQU1WLE1BQU1ZLGlCQUFpQixDQUFDLENBQUMsUUFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRjtBQUFBLE1BQ3JGO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFNO0FBQUEsVUFDTixPQUFPLEdBQUdILEtBQUtDLE1BQU1WLE1BQU1hLGlCQUFpQixDQUFDLENBQUM7QUFBQSxVQUM5QyxZQUNHYixNQUFNYSxpQkFBaUIsS0FBSyxNQUFPLHVCQUFDLGVBQVksTUFBSyxXQUFVLG9CQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQyxJQUFpQmhEO0FBQUFBO0FBQUFBLFFBSnpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtHO0FBQUEsTUFFSCx1QkFBQyxlQUFZLE9BQU0sZ0JBQWUsT0FBT21DLE1BQU1wQyxTQUFTLEtBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEQ7QUFBQSxTQVY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxrREFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSwyQ0FBMEMsc0NBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEU7QUFBQSxNQUM3RXVDLFFBQVE1QyxTQUFTLElBQ2hCLHVCQUFDLFNBQUksV0FBVSxpQkFDWjRDLGtCQUFReEIsSUFBSSxDQUFDbUMsS0FBVXpCLFFBQWdCO0FBQ3RDLGNBQU0wQixXQUFXRCxJQUFJdkIsVUFBVWdCLGNBQWM7QUFDN0MsY0FBTVMsWUFBWUYsSUFBSXZCLFVBQVV5QixhQUFhO0FBQzdDLGVBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsVUFBSyxXQUFVLGtDQUFrQ0EsdUJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTREO0FBQUEsY0FDNUQ7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBV3BGO0FBQUFBLG9CQUNUO0FBQUEsb0JBQ0FtRixXQUFXLE1BQU8sYUFBYTtBQUFBLGtCQUNqQztBQUFBLGtCQUVDTjtBQUFBQSx5QkFBS0MsTUFBTUssUUFBUTtBQUFBLG9CQUFFO0FBQUE7QUFBQTtBQUFBLGdCQU54QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBO0FBQUE7QUFBQSxVQVhLMUI7QUFBQUEsVUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBYUE7QUFBQSxNQUVKLENBQUMsS0FwQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxvREFBa0QsdUNBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBNUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4QkE7QUFBQSxPQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkNBO0FBRUo7QUFBQzRCLE1BdERRbEI7QUF3RFQsU0FBU21CLFNBQVMsRUFBRWpCLEtBQVUsR0FBRztBQUMvQixNQUFJQSxLQUFLMUMsV0FBVyxHQUFHO0FBQ3JCLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHNDQUFxQyw2QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRTtBQUFBLE1BQ2pFLHVCQUFDLFNBQUksV0FBVSxvQkFBbUIseUNBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkQ7QUFBQSxTQUY3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsNkRBQ2IsaUNBQUMsU0FDQztBQUFBLDJCQUFDLGVBQ0MsaUNBQUMsWUFBUyxXQUFVLDZDQUNsQjtBQUFBLDZCQUFDLGFBQVUsV0FBVSxvRkFBbUYsb0JBQXhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEc7QUFBQSxNQUM1Ryx1QkFBQyxhQUFVLFdBQVUsb0ZBQW1GLHFCQUF4RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZHO0FBQUEsTUFDN0csdUJBQUMsYUFBVSxXQUFVLG9GQUFtRixzQkFBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RztBQUFBLE1BQzlHLHVCQUFDLGFBQVUsV0FBVSxvRkFBbUYsc0JBQXhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEc7QUFBQSxTQUpoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUNBLHVCQUFDLGFBQ0UwQyxlQUFLdEI7QUFBQUEsTUFBSSxDQUFDbUMsS0FBVXpCLFFBQ25CLHVCQUFDLFlBQW1CLFdBQVUsMkRBQzVCO0FBQUEsK0JBQUMsYUFBVSxXQUFVLDBDQUNsQixjQUFJRyxLQUFLc0IsSUFBSXJCLGFBQWEsRUFBRTBCLG1CQUFtQixLQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLGFBQVUsV0FBVSw4Q0FDbEJMO0FBQUFBLGNBQUlNO0FBQUFBLFVBQVU7QUFBQSxVQUFHTixJQUFJTyxXQUFXO0FBQUEsYUFEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxhQUFVLFdBQVUsZ0RBQ2xCUCxjQUFJUSxVQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsYUFBVSxXQUFVLDBDQUNsQlI7QUFBQUEsY0FBSVM7QUFBQUEsVUFBVztBQUFBLFVBQUdULElBQUlVO0FBQUFBLGFBRHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBWmFuQyxLQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLElBQ0QsS0FoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLE9BMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyQkEsS0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZCQTtBQUVKO0FBQUNvQyxNQTFDUVA7QUFBUSxJQUFBUSxJQUFBNUQsS0FBQWdDLEtBQUFtQixLQUFBUTtBQUFBLGFBQUFDLElBQUE7QUFBQSxhQUFBNUQsS0FBQTtBQUFBLGFBQUFnQyxLQUFBO0FBQUEsYUFBQW1CLEtBQUE7QUFBQSxhQUFBUSxLQUFBIiwibmFtZXMiOlsidXNlUXVlcnkiLCJhcGkiLCJ1c2VTdGF0ZSIsIlgiLCJjbiIsIlRhYmxlIiwiVGFibGVCb2R5IiwiVGFibGVDZWxsIiwiVGFibGVIZWFkIiwiVGFibGVIZWFkZXIiLCJUYWJsZVJvdyIsIk1ldHJpY0Jsb2NrIiwiTWV0cmljUm93IiwiU3RhdHVzQmFkZ2UiLCJzZXZlcml0eVRvbmUiLCJzZXZlcml0eSIsIk1vbml0b3JpbmdEYXNoYm9hcmQiLCJvbkNsb3NlIiwiX3MiLCJzZWxlY3RlZFRhYiIsInNldFNlbGVjdGVkVGFiIiwicmVjZW50RXJyb3JzIiwibW9uaXRvcmluZyIsImxpc3RSZWNlbnRFcnJvcnMiLCJsaW1pdCIsInBlcmZvcm1hbmNlU3RhdHMiLCJnZXRQZXJmb3JtYW5jZVN0YXRzIiwiYXVkaXRMb2ciLCJnZXRBdWRpdExvZyIsImUiLCJzdG9wUHJvcGFnYXRpb24iLCJsZW5ndGgiLCJUYWJCdXR0b24iLCJsYWJlbCIsImFjdGl2ZSIsIm9uQ2xpY2siLCJjb3VudCIsInVuZGVmaW5lZCIsIl9jMiIsIlNFTlNJVElWRV9LRVlTIiwiU2V0IiwiU0VOU0lUSVZFX1BBVFRFUk5TIiwiaXNTZW5zaXRpdmVWYWx1ZSIsInZhbHVlIiwic29tZSIsInBhdHRlcm4iLCJ0ZXN0Iiwic2FuaXRpemVNZXRhZGF0YSIsIm9iaiIsIkFycmF5IiwiaXNBcnJheSIsIm1hcCIsInJlc3VsdCIsImtleSIsIk9iamVjdCIsImVudHJpZXMiLCJoYXMiLCJ0b0xvd2VyQ2FzZSIsIkVycm9yc1RhYiIsImVycm9ycyIsImVycm9yIiwiaWR4IiwiZXJyb3JUeXBlIiwibWV0YWRhdGEiLCJEYXRlIiwiX2NyZWF0aW9uVGltZSIsInRvTG9jYWxlU3RyaW5nIiwiZGVzY3JpcHRpb24iLCJKU09OIiwic3RyaW5naWZ5IiwiX2MzIiwiUGVyZm9ybWFuY2VUYWIiLCJzdGF0cyIsImxvZ3MiLCJyZWNlbnRMb2dzIiwic2xvd2VzdCIsInNvcnQiLCJhIiwiYiIsImR1cmF0aW9uTXMiLCJzbGljZSIsIk1hdGgiLCJyb3VuZCIsImF2Z0R1cmF0aW9uTXMiLCJtaW5EdXJhdGlvbk1zIiwibWF4RHVyYXRpb25NcyIsImxvZyIsImR1cmF0aW9uIiwib3BlcmF0aW9uIiwiX2M0IiwiQXVkaXRUYWIiLCJ0b0xvY2FsZVRpbWVTdHJpbmciLCJhY3RvclR5cGUiLCJhY3RvcklkIiwiYWN0aW9uIiwidGFyZ2V0VHlwZSIsInRhcmdldElkIiwiX2M1IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTW9uaXRvcmluZ0Rhc2hib2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgWCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5pbXBvcnQge1xuICBUYWJsZSxcbiAgVGFibGVCb2R5LFxuICBUYWJsZUNlbGwsXG4gIFRhYmxlSGVhZCxcbiAgVGFibGVIZWFkZXIsXG4gIFRhYmxlUm93LFxufSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL3RhYmxlXCI7XG5pbXBvcnQgeyBNZXRyaWNCbG9jaywgTWV0cmljUm93IH0gZnJvbSBcIi4vY29tcG9uZW50cy9mYWN0b3J5L01ldHJpY0Jsb2NrXCI7XG5pbXBvcnQgeyBTdGF0dXNCYWRnZSwgdHlwZSBTdGF0dXNCYWRnZVByb3BzIH0gZnJvbSBcIi4vY29tcG9uZW50cy9mYWN0b3J5L2JhZGdlc1wiO1xuXG5pbnRlcmZhY2UgTW9uaXRvcmluZ0Rhc2hib2FyZFByb3BzIHtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbn1cblxuZnVuY3Rpb24gc2V2ZXJpdHlUb25lKHNldmVyaXR5OiBzdHJpbmcpOiBTdGF0dXNCYWRnZVByb3BzW1widG9uZVwiXSB7XG4gIHN3aXRjaCAoc2V2ZXJpdHkpIHtcbiAgICBjYXNlIFwiQ1JJVElDQUxcIjpcbiAgICBjYXNlIFwiRVJST1JcIjpcbiAgICAgIHJldHVybiBcImVycm9yXCI7XG4gICAgY2FzZSBcIldBUk5JTkdcIjpcbiAgICAgIHJldHVybiBcIndhcm5pbmdcIjtcbiAgICBjYXNlIFwiSU5GT1wiOlxuICAgICAgcmV0dXJuIFwiaW5mb1wiO1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gXCJuZXV0cmFsXCI7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIE1vbml0b3JpbmdEYXNoYm9hcmQoeyBvbkNsb3NlIH06IE1vbml0b3JpbmdEYXNoYm9hcmRQcm9wcykge1xuICBjb25zdCBbc2VsZWN0ZWRUYWIsIHNldFNlbGVjdGVkVGFiXSA9IHVzZVN0YXRlPFwiZXJyb3JzXCIgfCBcInBlcmZvcm1hbmNlXCIgfCBcImF1ZGl0XCI+KFwiZXJyb3JzXCIpO1xuICBjb25zdCByZWNlbnRFcnJvcnMgPSB1c2VRdWVyeShhcGkubW9uaXRvcmluZy5saXN0UmVjZW50RXJyb3JzLCB7IGxpbWl0OiA1MCB9KTtcbiAgY29uc3QgcGVyZm9ybWFuY2VTdGF0cyA9IHVzZVF1ZXJ5KGFwaS5tb25pdG9yaW5nLmdldFBlcmZvcm1hbmNlU3RhdHMsIHt9KTtcbiAgY29uc3QgYXVkaXRMb2cgPSB1c2VRdWVyeShhcGkubW9uaXRvcmluZy5nZXRBdWRpdExvZywgeyBsaW1pdDogMTAwIH0pO1xuXG4gIGlmICghcmVjZW50RXJyb3JzIHx8ICFwZXJmb3JtYW5jZVN0YXRzIHx8ICFhdWRpdExvZykge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bMTAwMF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYmxhY2svNzBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgcC0xMCB0ZXh0LVsxM3B4XSB0ZXh0LWluay1zZWNvbmRhcnlcIj5cbiAgICAgICAgICBMb2FkaW5nIG1vbml0b3JpbmcgZGF0YS4uLlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bMTAwMF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgb3ZlcmZsb3ctYXV0byBiZy1ibGFjay83MCBwLTVcIlxuICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICA+XG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzTmFtZT1cIm1heC1oLVs5MHZoXSB3LWZ1bGwgbWF4LXctWzE0MDBweF0gb3ZlcmZsb3ctYXV0byByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTFcIlxuICAgICAgICBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX1cbiAgICAgID5cbiAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLWxpbmUgcC02XCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsxOXB4XSBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+TW9uaXRvcmluZzwvaDI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtWzEzcHhdIHRleHQtaW5rLXNlY29uZGFyeVwiPlxuICAgICAgICAgICAgICBSZWFsLXRpbWUgc3lzdGVtIG1vbml0b3JpbmcgYW5kIGF1ZGl0IGxvZ3NcbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkNsb3NlIG1vbml0b3JpbmdcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBwLTEuNSB0ZXh0LWluay1tdXRlZCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgaG92ZXI6Ymctc3VyZmFjZS0yIGhvdmVyOnRleHQtaW5rXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8WCBzaXplPXsxNn0gc3Ryb2tlV2lkdGg9ezEuNzV9IC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBUYWJzICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGJvcmRlci1iIGJvcmRlci1saW5lIHB4LTZcIiByb2xlPVwidGFibGlzdFwiPlxuICAgICAgICAgIDxUYWJCdXR0b25cbiAgICAgICAgICAgIGxhYmVsPVwiRXJyb3JzXCJcbiAgICAgICAgICAgIGFjdGl2ZT17c2VsZWN0ZWRUYWIgPT09IFwiZXJyb3JzXCJ9XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZFRhYihcImVycm9yc1wiKX1cbiAgICAgICAgICAgIGNvdW50PXtyZWNlbnRFcnJvcnMubGVuZ3RofVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFRhYkJ1dHRvblxuICAgICAgICAgICAgbGFiZWw9XCJQZXJmb3JtYW5jZVwiXG4gICAgICAgICAgICBhY3RpdmU9e3NlbGVjdGVkVGFiID09PSBcInBlcmZvcm1hbmNlXCJ9XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZFRhYihcInBlcmZvcm1hbmNlXCIpfVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFRhYkJ1dHRvblxuICAgICAgICAgICAgbGFiZWw9XCJBdWRpdCBsb2dcIlxuICAgICAgICAgICAgYWN0aXZlPXtzZWxlY3RlZFRhYiA9PT0gXCJhdWRpdFwifVxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRUYWIoXCJhdWRpdFwiKX1cbiAgICAgICAgICAgIGNvdW50PXthdWRpdExvZy5sZW5ndGh9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIENvbnRlbnQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XG4gICAgICAgICAge3NlbGVjdGVkVGFiID09PSBcImVycm9yc1wiICYmIDxFcnJvcnNUYWIgZXJyb3JzPXtyZWNlbnRFcnJvcnN9IC8+fVxuICAgICAgICAgIHtzZWxlY3RlZFRhYiA9PT0gXCJwZXJmb3JtYW5jZVwiICYmIDxQZXJmb3JtYW5jZVRhYiBzdGF0cz17cGVyZm9ybWFuY2VTdGF0c30gLz59XG4gICAgICAgICAge3NlbGVjdGVkVGFiID09PSBcImF1ZGl0XCIgJiYgPEF1ZGl0VGFiIGxvZ3M9e2F1ZGl0TG9nfSAvPn1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gVGFiQnV0dG9uKHtcbiAgbGFiZWwsXG4gIGFjdGl2ZSxcbiAgb25DbGljayxcbiAgY291bnQsXG59OiB7XG4gIGxhYmVsOiBzdHJpbmc7XG4gIGFjdGl2ZTogYm9vbGVhbjtcbiAgb25DbGljazogKCkgPT4gdm9pZDtcbiAgY291bnQ/OiBudW1iZXI7XG59KSB7XG4gIHJldHVybiAoXG4gICAgPGJ1dHRvblxuICAgICAgcm9sZT1cInRhYlwiXG4gICAgICBhcmlhLXNlbGVjdGVkPXthY3RpdmV9XG4gICAgICBvbkNsaWNrPXtvbkNsaWNrfVxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCItbWItcHggZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBib3JkZXItYi0yIHB4LTMgcHktMi41IHRleHQtWzEzcHhdIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiLFxuICAgICAgICBhY3RpdmVcbiAgICAgICAgICA/IFwiYm9yZGVyLWluayB0ZXh0LWlua1wiXG4gICAgICAgICAgOiBcImJvcmRlci10cmFuc3BhcmVudCB0ZXh0LWluay1tdXRlZCBob3Zlcjp0ZXh0LWluay1zZWNvbmRhcnlcIlxuICAgICAgKX1cbiAgICA+XG4gICAgICB7bGFiZWx9XG4gICAgICB7Y291bnQgIT09IHVuZGVmaW5lZCAmJiAoXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMiBweC0xLjUgcHktMC41IHRleHQtWzExLjVweF0gZm9udC1tZWRpdW0gbGVhZGluZy1ub25lIHRleHQtaW5rLXNlY29uZGFyeVwiPlxuICAgICAgICAgIHtjb3VudH1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgKX1cbiAgICA8L2J1dHRvbj5cbiAgKTtcbn1cblxuY29uc3QgU0VOU0lUSVZFX0tFWVMgPSBuZXcgU2V0KFtcbiAgXCJ0b2tlblwiLCBcImFjY2Vzc190b2tlblwiLCBcInJlZnJlc2hfdG9rZW5cIiwgXCJpZF90b2tlblwiLFxuICBcInBhc3N3b3JkXCIsIFwicGFzc3dkXCIsIFwic2VjcmV0XCIsIFwiYXBpX2tleVwiLCBcImFwaWtleVwiLCBcImFwaUtleVwiLFxuICBcImF1dGhcIiwgXCJhdXRob3JpemF0aW9uXCIsIFwiY3JlZGVudGlhbHNcIiwgXCJwcml2YXRlX2tleVwiLCBcInByaXZhdGVLZXlcIixcbiAgXCJzc25cIiwgXCJlbWFpbFwiLCBcImNvb2tpZVwiLCBcInNlc3Npb25cIiwgXCJqd3RcIiwgXCJiZWFyZXJcIixcbiAgXCJjbGllbnRfc2VjcmV0XCIsIFwiY2xpZW50U2VjcmV0XCIsIFwiY29ubmVjdGlvbl9zdHJpbmdcIiwgXCJjb25uZWN0aW9uU3RyaW5nXCIsXG5dKTtcblxuY29uc3QgU0VOU0lUSVZFX1BBVFRFUk5TID0gW1xuICAvXnNrWy1fXS9pLCAvLyBTdHJpcGUvT3BlbkFJIHNlY3JldCBrZXlzXG4gIC9eZ2hwXy9pLCAvLyBHaXRIdWIgUEFUc1xuICAvXnhveGItL2ksIC8vIFNsYWNrIHRva2Vuc1xuICAvYmVhcmVyXFxzK1xcUysvaSxcbl07XG5cbmZ1bmN0aW9uIGlzU2Vuc2l0aXZlVmFsdWUodmFsdWU6IHVua25vd24pOiBib29sZWFuIHtcbiAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gXCJzdHJpbmdcIikgcmV0dXJuIGZhbHNlO1xuICByZXR1cm4gU0VOU0lUSVZFX1BBVFRFUk5TLnNvbWUoKHBhdHRlcm4pID0+IHBhdHRlcm4udGVzdCh2YWx1ZSkpO1xufVxuXG5mdW5jdGlvbiBzYW5pdGl6ZU1ldGFkYXRhKG9iajogdW5rbm93bik6IHVua25vd24ge1xuICBpZiAob2JqID09PSBudWxsIHx8IG9iaiA9PT0gdW5kZWZpbmVkKSByZXR1cm4gb2JqO1xuICBpZiAodHlwZW9mIG9iaiA9PT0gXCJzdHJpbmdcIikge1xuICAgIHJldHVybiBpc1NlbnNpdGl2ZVZhbHVlKG9iaikgPyBcIltSRURBQ1RFRF1cIiA6IG9iajtcbiAgfVxuICBpZiAoQXJyYXkuaXNBcnJheShvYmopKSB7XG4gICAgcmV0dXJuIG9iai5tYXAoc2FuaXRpemVNZXRhZGF0YSk7XG4gIH1cbiAgaWYgKHR5cGVvZiBvYmogPT09IFwib2JqZWN0XCIpIHtcbiAgICBjb25zdCByZXN1bHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge307XG4gICAgZm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMob2JqIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkge1xuICAgICAgaWYgKFNFTlNJVElWRV9LRVlTLmhhcyhrZXkudG9Mb3dlckNhc2UoKSkpIHtcbiAgICAgICAgcmVzdWx0W2tleV0gPSBcIltSRURBQ1RFRF1cIjtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc3VsdFtrZXldID0gc2FuaXRpemVNZXRhZGF0YSh2YWx1ZSk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbiAgcmV0dXJuIG9iajtcbn1cblxuZnVuY3Rpb24gRXJyb3JzVGFiKHsgZXJyb3JzIH06IGFueSkge1xuICBpZiAoZXJyb3JzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktMTAgdGV4dC1jZW50ZXIgdGV4dC1pbmstbXV0ZWRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+Tm8gZXJyb3JzPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LVsxM3B4XVwiPlN5c3RlbSBpcyBydW5uaW5nIHNtb290aGx5PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTNcIj5cbiAgICAgIHtlcnJvcnMubWFwKChlcnJvcjogYW55LCBpZHg6IG51bWJlcikgPT4ge1xuICAgICAgICBjb25zdCBlcnJvclR5cGUgPSBlcnJvci5tZXRhZGF0YT8uZXJyb3JUeXBlIHx8IFwiRVJST1JcIjtcbiAgICAgICAgY29uc3Qgc2V2ZXJpdHkgPVxuICAgICAgICAgIGVycm9yVHlwZSA9PT0gXCJDUklUSUNBTFwiIHx8IGVycm9yVHlwZSA9PT0gXCJEQVRBQkFTRV9FUlJPUlwiIHx8IGVycm9yVHlwZSA9PT0gXCJBUElfRVJST1JcIlxuICAgICAgICAgICAgPyBcIkNSSVRJQ0FMXCJcbiAgICAgICAgICAgIDogZXJyb3JUeXBlID09PSBcIldBUk5JTkdcIlxuICAgICAgICAgICAgICA/IFwiV0FSTklOR1wiXG4gICAgICAgICAgICAgIDogXCJFUlJPUlwiO1xuXG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPGRpdiBrZXk9e2lkeH0gY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yIHAtNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgICAgICA8U3RhdHVzQmFkZ2UgdG9uZT17c2V2ZXJpdHlUb25lKHNldmVyaXR5KX0+e3NldmVyaXR5fTwvU3RhdHVzQmFkZ2U+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1pbmstbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICB7bmV3IERhdGUoZXJyb3IuX2NyZWF0aW9uVGltZSkudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMiB0ZXh0LVsxMy41cHhdIHRleHQtaW5rXCI+e2Vycm9yLmRlc2NyaXB0aW9ufTwvZGl2PlxuICAgICAgICAgICAge2Vycm9yLm1ldGFkYXRhICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy1hdXRvIHJvdW5kZWQtbWQgYmctc3VyZmFjZS0xIHAtMiBmb250LW1vbm8gdGV4dC1bMTJweF0gdGV4dC1pbmstbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICB7SlNPTi5zdHJpbmdpZnkoc2FuaXRpemVNZXRhZGF0YShlcnJvci5tZXRhZGF0YSksIG51bGwsIDIpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICk7XG4gICAgICB9KX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gUGVyZm9ybWFuY2VUYWIoeyBzdGF0cyB9OiBhbnkpIHtcbiAgY29uc3QgbG9ncyA9IHN0YXRzLnJlY2VudExvZ3MgfHwgW107XG4gIGNvbnN0IHNsb3dlc3QgPSBbLi4ubG9nc11cbiAgICAuc29ydCgoYTogYW55LCBiOiBhbnkpID0+IChiLm1ldGFkYXRhPy5kdXJhdGlvbk1zIHx8IDApIC0gKGEubWV0YWRhdGE/LmR1cmF0aW9uTXMgfHwgMCkpXG4gICAgLnNsaWNlKDAsIDgpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxNZXRyaWNSb3cgY2xhc3NOYW1lPVwibWItNlwiPlxuICAgICAgICA8TWV0cmljQmxvY2sgbGFiZWw9XCJBdmVyYWdlIGR1cmF0aW9uXCIgdmFsdWU9e2Ake01hdGgucm91bmQoc3RhdHMuYXZnRHVyYXRpb25NcyB8fCAwKX1tc2B9IC8+XG4gICAgICAgIDxNZXRyaWNCbG9jayBsYWJlbD1cIk1pbiBkdXJhdGlvblwiIHZhbHVlPXtgJHtNYXRoLnJvdW5kKHN0YXRzLm1pbkR1cmF0aW9uTXMgfHwgMCl9bXNgfSAvPlxuICAgICAgICA8TWV0cmljQmxvY2tcbiAgICAgICAgICBsYWJlbD1cIk1heCBkdXJhdGlvblwiXG4gICAgICAgICAgdmFsdWU9e2Ake01hdGgucm91bmQoc3RhdHMubWF4RHVyYXRpb25NcyB8fCAwKX1tc2B9XG4gICAgICAgICAgYWRvcm5tZW50PXtcbiAgICAgICAgICAgIChzdGF0cy5tYXhEdXJhdGlvbk1zIHx8IDApID4gNTAwMCA/IDxTdGF0dXNCYWRnZSB0b25lPVwid2FybmluZ1wiPlNsb3c8L1N0YXR1c0JhZGdlPiA6IHVuZGVmaW5lZFxuICAgICAgICAgIH1cbiAgICAgICAgLz5cbiAgICAgICAgPE1ldHJpY0Jsb2NrIGxhYmVsPVwiU2FtcGxlIGNvdW50XCIgdmFsdWU9e3N0YXRzLmNvdW50IHx8IDB9IC8+XG4gICAgICA8L01ldHJpY1Jvdz5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgcC01XCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj5SZWNlbnQgc2xvdyBvcGVyYXRpb25zPC9oMz5cbiAgICAgICAge3Nsb3dlc3QubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgICAgIHtzbG93ZXN0Lm1hcCgobG9nOiBhbnksIGlkeDogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGR1cmF0aW9uID0gbG9nLm1ldGFkYXRhPy5kdXJhdGlvbk1zIHx8IDA7XG4gICAgICAgICAgICAgIGNvbnN0IG9wZXJhdGlvbiA9IGxvZy5tZXRhZGF0YT8ub3BlcmF0aW9uIHx8IFwiVW5rbm93biBvcGVyYXRpb25cIjtcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICBrZXk9e2lkeH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItbGluZSBweC0xIHB5LTIgbGFzdDpib3JkZXItYi0wXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWluay1zZWNvbmRhcnlcIj57b3BlcmF0aW9ufTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgXCJmb250LW1vbm8gdGV4dC1bMTNweF1cIixcbiAgICAgICAgICAgICAgICAgICAgICBkdXJhdGlvbiA+IDEwMDAgPyBcInRleHQtZXJyXCIgOiBcInRleHQtaW5rLW11dGVkXCJcbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge01hdGgucm91bmQoZHVyYXRpb24pfW1zXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgcHktNSB0ZXh0LWNlbnRlciB0ZXh0LVsxM3B4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgTm8gcGVyZm9ybWFuY2UgZGF0YSB5ZXRcbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5mdW5jdGlvbiBBdWRpdFRhYih7IGxvZ3MgfTogYW55KSB7XG4gIGlmIChsb2dzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktMTAgdGV4dC1jZW50ZXIgdGV4dC1pbmstbXV0ZWRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+Tm8gYXVkaXQgbG9nczwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgdGV4dC1bMTNweF1cIj5BY3Rpdml0eSB3aWxsIGFwcGVhciBoZXJlPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC1oLVs2MDBweF0gb3ZlcmZsb3ctYXV0byByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItbGluZVwiPlxuICAgICAgPFRhYmxlPlxuICAgICAgICA8VGFibGVIZWFkZXI+XG4gICAgICAgICAgPFRhYmxlUm93IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1saW5lIGhvdmVyOmJnLXRyYW5zcGFyZW50XCI+XG4gICAgICAgICAgICA8VGFibGVIZWFkIGNsYXNzTmFtZT1cInB4LTQgcHktMi41IHRleHQtWzExLjVweF0gZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjA2ZW1dIHRleHQtaW5rLW11dGVkXCI+VGltZTwvVGFibGVIZWFkPlxuICAgICAgICAgICAgPFRhYmxlSGVhZCBjbGFzc05hbWU9XCJweC00IHB5LTIuNSB0ZXh0LVsxMS41cHhdIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy1bMC4wNmVtXSB0ZXh0LWluay1tdXRlZFwiPkFjdG9yPC9UYWJsZUhlYWQ+XG4gICAgICAgICAgICA8VGFibGVIZWFkIGNsYXNzTmFtZT1cInB4LTQgcHktMi41IHRleHQtWzExLjVweF0gZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjA2ZW1dIHRleHQtaW5rLW11dGVkXCI+QWN0aW9uPC9UYWJsZUhlYWQ+XG4gICAgICAgICAgICA8VGFibGVIZWFkIGNsYXNzTmFtZT1cInB4LTQgcHktMi41IHRleHQtWzExLjVweF0gZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjA2ZW1dIHRleHQtaW5rLW11dGVkXCI+VGFyZ2V0PC9UYWJsZUhlYWQ+XG4gICAgICAgICAgPC9UYWJsZVJvdz5cbiAgICAgICAgPC9UYWJsZUhlYWRlcj5cbiAgICAgICAgPFRhYmxlQm9keT5cbiAgICAgICAgICB7bG9ncy5tYXAoKGxvZzogYW55LCBpZHg6IG51bWJlcikgPT4gKFxuICAgICAgICAgICAgPFRhYmxlUm93IGtleT17aWR4fSBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItbGluZSBsYXN0OmJvcmRlci1iLTAgaG92ZXI6Ymctc3VyZmFjZS0yXCI+XG4gICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtWzEyLjVweF0gdGV4dC1pbmstbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICB7bmV3IERhdGUobG9nLl9jcmVhdGlvblRpbWUpLnRvTG9jYWxlVGltZVN0cmluZygpfVxuICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1bMTIuNXB4XSB0ZXh0LWluay1zZWNvbmRhcnlcIj5cbiAgICAgICAgICAgICAgICB7bG9nLmFjdG9yVHlwZX06IHtsb2cuYWN0b3JJZCB8fCBcIlN5c3RlbVwifVxuICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1bMTIuNXB4XSBmb250LW1lZGl1bSB0ZXh0LWlua1wiPlxuICAgICAgICAgICAgICAgIHtsb2cuYWN0aW9ufVxuICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgIHtsb2cudGFyZ2V0VHlwZX06IHtsb2cudGFyZ2V0SWR9XG4gICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgPC9UYWJsZVJvdz5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9UYWJsZUJvZHk+XG4gICAgICA8L1RhYmxlPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvTW9uaXRvcmluZ0Rhc2hib2FyZC50c3gifQ==