import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/operator/StreamingTurnCard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/StreamingTurnCard.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { cn } from "/src/lib/utils.ts";
import { ToolCallRow } from "/src/components/operator/ToolCallRow.tsx";
function StagesRow({
  gate,
  tools,
  streaming
}) {
  const gateDone = Boolean(gate);
  return /* @__PURE__ */ jsxDEV("div", { className: "schematic-stages mb-1.5", children: [
    /* @__PURE__ */ jsxDEV("span", { className: cn("schematic-stage", gateDone ? "schematic-stage-done" : "schematic-stage-on"), children: [
      "gate",
      gate ? ` · ${gate.decision}` : ""
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/StreamingTurnCard.tsx",
      lineNumber: 49,
      columnNumber: 7
    }, this),
    (tools ?? []).map(
      (t, i) => /* @__PURE__ */ jsxDEV("span", { className: "schematic-stage schematic-stage-done", children: t.tool }, `${t.tool}-${i}`, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/StreamingTurnCard.tsx",
        lineNumber: 53,
        columnNumber: 7
      }, this)
    ),
    /* @__PURE__ */ jsxDEV(
      "span",
      {
        className: cn(
          "schematic-stage",
          streaming ? "schematic-stage-on" : gateDone ? "schematic-stage-done" : ""
        ),
        children: "reply"
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/StreamingTurnCard.tsx",
        lineNumber: 57,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/StreamingTurnCard.tsx",
    lineNumber: 48,
    columnNumber: 5
  }, this);
}
_c = StagesRow;
export function StreamingTurnCard({ turn, className }) {
  const elapsed = turn.startedAt && turn.pending && !turn.stream ? Math.round((Date.now() - turn.startedAt) / 1e3) : null;
  return /* @__PURE__ */ jsxDEV("div", { className: cn("schematic-card", className), children: [
    /* @__PURE__ */ jsxDEV(StagesRow, { gate: turn.gate, tools: turn.tools, streaming: Boolean(turn.stream) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/StreamingTurnCard.tsx",
      lineNumber: 78,
      columnNumber: 7
    }, this),
    turn.gate?.reason ? /* @__PURE__ */ jsxDEV("div", { className: "schematic-meta mb-1.5", children: turn.gate.reason }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/StreamingTurnCard.tsx",
      lineNumber: 80,
      columnNumber: 7
    }, this) : null,
    (turn.tools ?? []).map(
      (t, i) => /* @__PURE__ */ jsxDEV(ToolCallRow, { call: t }, `${t.tool}-${i}`, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/StreamingTurnCard.tsx",
        lineNumber: 83,
        columnNumber: 7
      }, this)
    ),
    turn.stream ? /* @__PURE__ */ jsxDEV("div", { className: "schematic-reply mt-2 whitespace-pre-wrap", children: [
      turn.stream,
      /* @__PURE__ */ jsxDEV("span", { className: "schematic-caret", "aria-hidden": true }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/StreamingTurnCard.tsx",
        lineNumber: 88,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/StreamingTurnCard.tsx",
      lineNumber: 86,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "schematic-meta", children: [
      "thinking…",
      elapsed != null ? ` ${elapsed}s` : ""
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/StreamingTurnCard.tsx",
      lineNumber: 91,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/StreamingTurnCard.tsx",
    lineNumber: 77,
    columnNumber: 5
  }, this);
}
_c2 = StreamingTurnCard;
var _c, _c2;
$RefreshReg$(_c, "StagesRow");
$RefreshReg$(_c2, "StreamingTurnCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/StreamingTurnCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/StreamingTurnCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJNOzs7Ozs7Ozs7Ozs7Ozs7O0FBN0JOLFNBQVNBLFVBQVU7QUFDbkIsU0FBU0MsbUJBQXNDO0FBZ0IvQyxTQUFTQyxVQUFVO0FBQUEsRUFDakJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBS0YsR0FBZ0I7QUFDZCxRQUFNQyxXQUFXQyxRQUFRSixJQUFJO0FBQzdCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsMkJBQUMsVUFBSyxXQUFXSCxHQUFHLG1CQUFtQk0sV0FBVyx5QkFBeUIsb0JBQW9CLEdBQUU7QUFBQTtBQUFBLE1BQzFGSCxPQUFPLE1BQU1BLEtBQUtLLFFBQVEsS0FBSztBQUFBLFNBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEtBQ0VKLFNBQVMsSUFBSUs7QUFBQUEsTUFBSSxDQUFDQyxHQUFHQyxNQUNyQix1QkFBQyxVQUE0QixXQUFVLHdDQUNwQ0QsWUFBRUUsUUFETSxHQUFHRixFQUFFRSxJQUFJLElBQUlELENBQUMsSUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsSUFDRDtBQUFBLElBQ0Q7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVdYO0FBQUFBLFVBQ1Q7QUFBQSxVQUNBSyxZQUFZLHVCQUF1QkMsV0FBVyx5QkFBeUI7QUFBQSxRQUN6RTtBQUFBLFFBQUU7QUFBQTtBQUFBLE1BSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT0E7QUFBQSxPQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUJBO0FBRUo7QUFFQU8sS0FoQ1NYO0FBaUNGLGdCQUFTWSxrQkFBa0IsRUFBRUMsTUFBTUMsVUFBa0MsR0FBZ0I7QUFDMUYsUUFBTUMsVUFDSkYsS0FBS0csYUFBYUgsS0FBS0ksV0FBVyxDQUFDSixLQUFLSyxTQUNwQ0MsS0FBS0MsT0FBT0MsS0FBS0MsSUFBSSxJQUFJVCxLQUFLRyxhQUFhLEdBQUksSUFDL0M7QUFFTixTQUNFLHVCQUFDLFNBQUksV0FBV2xCLEdBQUcsa0JBQWtCZ0IsU0FBUyxHQUM1QztBQUFBLDJCQUFDLGFBQVUsTUFBTUQsS0FBS1osTUFBTSxPQUFPWSxLQUFLWCxPQUFPLFdBQVdHLFFBQVFRLEtBQUtLLE1BQU0sS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRTtBQUFBLElBQzlFTCxLQUFLWixNQUFNc0IsU0FDVix1QkFBQyxTQUFJLFdBQVUseUJBQXlCVixlQUFLWixLQUFLc0IsVUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5RCxJQUN2RDtBQUFBLEtBQ0ZWLEtBQUtYLFNBQVMsSUFBSUs7QUFBQUEsTUFBSSxDQUFDQyxHQUFHQyxNQUMxQix1QkFBQyxlQUFtQyxNQUFNRCxLQUF4QixHQUFHQSxFQUFFRSxJQUFJLElBQUlELENBQUMsSUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QztBQUFBLElBQzdDO0FBQUEsSUFDQUksS0FBS0ssU0FDSix1QkFBQyxTQUFJLFdBQVUsNENBQ1pMO0FBQUFBLFdBQUtLO0FBQUFBLE1BQ04sdUJBQUMsVUFBSyxXQUFVLG1CQUFrQixlQUFXLFFBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkM7QUFBQSxTQUYvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0EsSUFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQWdCO0FBQUE7QUFBQSxNQUNuQkgsV0FBVyxPQUFPLElBQUlBLE9BQU8sTUFBTTtBQUFBLFNBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQkE7QUFFSjtBQUFDUyxNQTNCZVo7QUFBaUIsSUFBQUQsSUFBQWE7QUFBQSxhQUFBYixJQUFBO0FBQUEsYUFBQWEsS0FBQSIsIm5hbWVzIjpbImNuIiwiVG9vbENhbGxSb3ciLCJTdGFnZXNSb3ciLCJnYXRlIiwidG9vbHMiLCJzdHJlYW1pbmciLCJnYXRlRG9uZSIsIkJvb2xlYW4iLCJkZWNpc2lvbiIsIm1hcCIsInQiLCJpIiwidG9vbCIsIl9jIiwiU3RyZWFtaW5nVHVybkNhcmQiLCJ0dXJuIiwiY2xhc3NOYW1lIiwiZWxhcHNlZCIsInN0YXJ0ZWRBdCIsInBlbmRpbmciLCJzdHJlYW0iLCJNYXRoIiwicm91bmQiLCJEYXRlIiwibm93IiwicmVhc29uIiwiX2MyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlN0cmVhbWluZ1R1cm5DYXJkLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiO1xuaW1wb3J0IHsgVG9vbENhbGxSb3csIHR5cGUgVG9vbENhbGxEYXRhIH0gZnJvbSBcIi4vVG9vbENhbGxSb3dcIjtcbmltcG9ydCB0eXBlIHsgR2F0ZURlY2lzaW9uIH0gZnJvbSBcIi4vVHVybkNhcmRcIjtcblxuZXhwb3J0IGludGVyZmFjZSBTdHJlYW1pbmdUdXJuUHJvcHMge1xuICBnYXRlPzogR2F0ZURlY2lzaW9uO1xuICB0b29scz86IFRvb2xDYWxsRGF0YVtdO1xuICBzdHJlYW0/OiBzdHJpbmc7XG4gIHBlbmRpbmc/OiBib29sZWFuO1xuICBzdGFydGVkQXQ/OiBudW1iZXI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgU3RyZWFtaW5nVHVybkNhcmRQcm9wcyB7XG4gIHR1cm46IFN0cmVhbWluZ1R1cm5Qcm9wcztcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xufVxuXG5mdW5jdGlvbiBTdGFnZXNSb3coe1xuICBnYXRlLFxuICB0b29scyxcbiAgc3RyZWFtaW5nLFxufToge1xuICBnYXRlPzogR2F0ZURlY2lzaW9uO1xuICB0b29scz86IFRvb2xDYWxsRGF0YVtdO1xuICBzdHJlYW1pbmc/OiBib29sZWFuO1xufSk6IEpTWC5FbGVtZW50IHtcbiAgY29uc3QgZ2F0ZURvbmUgPSBCb29sZWFuKGdhdGUpO1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic2NoZW1hdGljLXN0YWdlcyBtYi0xLjVcIj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT17Y24oXCJzY2hlbWF0aWMtc3RhZ2VcIiwgZ2F0ZURvbmUgPyBcInNjaGVtYXRpYy1zdGFnZS1kb25lXCIgOiBcInNjaGVtYXRpYy1zdGFnZS1vblwiKX0+XG4gICAgICAgIGdhdGV7Z2F0ZSA/IGAgwrcgJHtnYXRlLmRlY2lzaW9ufWAgOiBcIlwifVxuICAgICAgPC9zcGFuPlxuICAgICAgeyh0b29scyA/PyBbXSkubWFwKCh0LCBpKSA9PiAoXG4gICAgICAgIDxzcGFuIGtleT17YCR7dC50b29sfS0ke2l9YH0gY2xhc3NOYW1lPVwic2NoZW1hdGljLXN0YWdlIHNjaGVtYXRpYy1zdGFnZS1kb25lXCI+XG4gICAgICAgICAge3QudG9vbH1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgKSl9XG4gICAgICA8c3BhblxuICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgIFwic2NoZW1hdGljLXN0YWdlXCIsXG4gICAgICAgICAgc3RyZWFtaW5nID8gXCJzY2hlbWF0aWMtc3RhZ2Utb25cIiA6IGdhdGVEb25lID8gXCJzY2hlbWF0aWMtc3RhZ2UtZG9uZVwiIDogXCJcIlxuICAgICAgICApfVxuICAgICAgPlxuICAgICAgICByZXBseVxuICAgICAgPC9zcGFuPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG4vKiogTGl2ZSBzdHJlYW1pbmcgdHVybiBjYXJkIHdpdGggc3RhZ2VzIHN0cmlwIGFuZCBjYXJldCAod2FrdSBzdHJlYW1pbmdDYXJkKS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBTdHJlYW1pbmdUdXJuQ2FyZCh7IHR1cm4sIGNsYXNzTmFtZSB9OiBTdHJlYW1pbmdUdXJuQ2FyZFByb3BzKTogSlNYLkVsZW1lbnQge1xuICBjb25zdCBlbGFwc2VkID1cbiAgICB0dXJuLnN0YXJ0ZWRBdCAmJiB0dXJuLnBlbmRpbmcgJiYgIXR1cm4uc3RyZWFtXG4gICAgICA/IE1hdGgucm91bmQoKERhdGUubm93KCkgLSB0dXJuLnN0YXJ0ZWRBdCkgLyAxMDAwKVxuICAgICAgOiBudWxsO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2NuKFwic2NoZW1hdGljLWNhcmRcIiwgY2xhc3NOYW1lKX0+XG4gICAgICA8U3RhZ2VzUm93IGdhdGU9e3R1cm4uZ2F0ZX0gdG9vbHM9e3R1cm4udG9vbHN9IHN0cmVhbWluZz17Qm9vbGVhbih0dXJuLnN0cmVhbSl9IC8+XG4gICAgICB7dHVybi5nYXRlPy5yZWFzb24gPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2NoZW1hdGljLW1ldGEgbWItMS41XCI+e3R1cm4uZ2F0ZS5yZWFzb259PC9kaXY+XG4gICAgICApIDogbnVsbH1cbiAgICAgIHsodHVybi50b29scyA/PyBbXSkubWFwKCh0LCBpKSA9PiAoXG4gICAgICAgIDxUb29sQ2FsbFJvdyBrZXk9e2Ake3QudG9vbH0tJHtpfWB9IGNhbGw9e3R9IC8+XG4gICAgICApKX1cbiAgICAgIHt0dXJuLnN0cmVhbSA/IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzY2hlbWF0aWMtcmVwbHkgbXQtMiB3aGl0ZXNwYWNlLXByZS13cmFwXCI+XG4gICAgICAgICAge3R1cm4uc3RyZWFtfVxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNjaGVtYXRpYy1jYXJldFwiIGFyaWEtaGlkZGVuIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzY2hlbWF0aWMtbWV0YVwiPlxuICAgICAgICAgIHRoaW5raW5n4oCme2VsYXBzZWQgIT0gbnVsbCA/IGAgJHtlbGFwc2VkfXNgIDogXCJcIn1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvY29tcG9uZW50cy9vcGVyYXRvci9TdHJlYW1pbmdUdXJuQ2FyZC50c3gifQ==