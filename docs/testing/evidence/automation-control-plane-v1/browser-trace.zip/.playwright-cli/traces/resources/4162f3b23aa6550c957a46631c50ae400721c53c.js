import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ModalLayer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useMutation } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { Button } from "/src/components/ui/button.tsx";
import { CreateAgentModal } from "/src/CreateAgentModal.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "/src/components/ui/dialog.tsx";
import { CreateTaskModal } from "/src/CreateTaskModal.tsx";
import { ApprovalsModal } from "/src/ApprovalsModal.tsx";
import { PolicyModal } from "/src/PolicyModal.tsx";
import { OperatorControlsModal } from "/src/OperatorControlsModal.tsx";
import { NotificationsModal } from "/src/NotificationsModal.tsx";
import { StandupModal } from "/src/StandupModal.tsx";
import { AgentDashboard } from "/src/AgentDashboard.tsx";
import { CostAnalytics } from "/src/CostAnalytics.tsx";
import { BudgetBurnDown } from "/src/BudgetBurnDown.tsx";
import { AnalyticsDashboard } from "/src/AnalyticsDashboard.tsx";
import { HealthDashboard } from "/src/HealthDashboard.tsx";
import { MonitoringDashboard } from "/src/MonitoringDashboard.tsx";
import { CommandPalette } from "/src/CommandPalette.tsx";
import { KeyboardShortcutsHelp } from "/src/KeyboardShortcuts.tsx";
import { ActivityFeedModal } from "/src/ActivityFeed.tsx";
import { AgentsFlyout } from "/src/AgentsFlyout.tsx";
import { AgentDetailFlyout } from "/src/AgentDetailFlyout.tsx";
import { MissionModal } from "/src/MissionModal.tsx";
import { MissionSuggestionsDrawer } from "/src/MissionSuggestionsDrawer.tsx";
import { ImportPrdModal } from "/src/ImportPrdModal.tsx";
import { StartQcRunModal } from "/src/StartQcRunModal.tsx";
import { AlertRulesModal } from "/src/AlertRulesModal.tsx";
export function ModalLayer({
  projectId,
  modals,
  open,
  close,
  selectedTaskId: _selectedTaskId,
  setSelectedTaskId,
  sidebarSelectedAgentId,
  setSidebarSelectedAgentId,
  sidebarWidth,
  onNavigate,
  onConfirmPauseSquad,
  onResumeSquad,
  onToast,
  onNavigateToGateway
}) {
  _s();
  const registerAgent = useMutation(api.agents.register);
  const handleCreateAgentSubmit = async (form) => {
    const meta = {};
    if (form.email) meta.email = form.email;
    if (form.telegram) meta.telegram = form.telegram;
    if (form.whatsapp) meta.whatsapp = form.whatsapp;
    if (form.discord) meta.discord = form.discord;
    try {
      await registerAgent({
        projectId: projectId ?? void 0,
        name: form.name,
        emoji: form.emoji || void 0,
        role: form.role,
        workspacePath: form.workspacePath,
        allowedTaskTypes: form.allowedTaskTypes ? form.allowedTaskTypes.split(",").map((s) => s.trim()).filter(Boolean) : void 0,
        allowedTools: form.allowedTools ? form.allowedTools.split(",").map((s) => s.trim()).filter(Boolean) : void 0,
        budgetDaily: form.budgetDaily ? Number(form.budgetDaily) : void 0,
        budgetPerRun: form.budgetPerRun ? Number(form.budgetPerRun) : void 0,
        canSpawn: form.canSpawn,
        maxSubAgents: form.canSpawn ? Number(form.maxSubAgents || 0) : 0,
        parentAgentId: void 0,
        metadata: Object.keys(meta).length > 0 ? meta : void 0
      });
      close("createAgent");
      onToast("Agent created");
    } catch (err) {
      const message = err instanceof Error ? err.message : "Failed to create agent.";
      onToast(message, true);
      throw err;
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Dialog, { open: modals.pauseConfirm, onOpenChange: (open2) => !open2 && close("pauseConfirm"), children: /* @__PURE__ */ jsxDEV(
      DialogContent,
      {
        "aria-describedby": "pause-confirm-description",
        onPointerDownOutside: () => close("pauseConfirm"),
        onEscapeKeyDown: () => close("pauseConfirm"),
        children: [
          /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
            /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Pause all active agents?" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
              lineNumber: 140,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(DialogDescription, { id: "pause-confirm-description", children: "Active agents will stop until resumed. This action can be reversed with Resume." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
              lineNumber: 141,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
            lineNumber: 139,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(DialogFooter, { className: "gap-2 sm:gap-0", children: [
            /* @__PURE__ */ jsxDEV(Button, { variant: "outline", size: "sm", onClick: () => close("pauseConfirm"), children: "Cancel" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
              lineNumber: 146,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { variant: "destructive", size: "sm", onClick: onConfirmPauseSquad, children: "Pause Squad" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
              lineNumber: 149,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
            lineNumber: 145,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
        lineNumber: 134,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
      lineNumber: 133,
      columnNumber: 7
    }, this),
    modals.createTask && /* @__PURE__ */ jsxDEV(
      CreateTaskModal,
      {
        projectId,
        onClose: () => close("createTask"),
        onCreated: () => onToast("Task created")
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
        lineNumber: 157,
        columnNumber: 7
      },
      this
    ),
    modals.importPrd && /* @__PURE__ */ jsxDEV(
      ImportPrdModal,
      {
        projectId,
        onClose: () => close("importPrd"),
        onCreated: (count) => onToast(
          count > 0 ? `${count} tasks created from PRD` : "This PRD was already imported; no duplicate tasks were created"
        )
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
        lineNumber: 165,
        columnNumber: 7
      },
      this
    ),
    modals.startQcRun && /* @__PURE__ */ jsxDEV(
      StartQcRunModal,
      {
        projectId,
        onClose: () => close("startQcRun"),
        onStarted: (runId) => onToast(`QC run ${runId} started`)
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
        lineNumber: 179,
        columnNumber: 7
      },
      this
    ),
    modals.approvals && /* @__PURE__ */ jsxDEV(ApprovalsModal, { projectId, onClose: () => close("approvals") }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
      lineNumber: 187,
      columnNumber: 7
    }, this),
    modals.policy && /* @__PURE__ */ jsxDEV(PolicyModal, { onClose: () => close("policy") }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
      lineNumber: 190,
      columnNumber: 25
    }, this),
    modals.operatorControls && /* @__PURE__ */ jsxDEV(
      OperatorControlsModal,
      {
        projectId,
        onClose: () => close("operatorControls")
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
        lineNumber: 193,
        columnNumber: 7
      },
      this
    ),
    modals.notifications && /* @__PURE__ */ jsxDEV(
      NotificationsModal,
      {
        onClose: () => close("notifications"),
        onSelectTask: setSelectedTaskId
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
        lineNumber: 200,
        columnNumber: 7
      },
      this
    ),
    modals.standup && /* @__PURE__ */ jsxDEV(StandupModal, { projectId, onClose: () => close("standup") }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
      lineNumber: 207,
      columnNumber: 7
    }, this),
    modals.agentDashboard && /* @__PURE__ */ jsxDEV(
      AgentDashboard,
      {
        projectId,
        onClose: () => close("agentDashboard"),
        onSelectAgent: (id) => {
          setSidebarSelectedAgentId(id);
          close("agentDashboard");
          open("agentsFlyout");
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
        lineNumber: 211,
        columnNumber: 7
      },
      this
    ),
    modals.costAnalytics && /* @__PURE__ */ jsxDEV(CostAnalytics, { projectId, onClose: () => close("costAnalytics") }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
      lineNumber: 223,
      columnNumber: 7
    }, this),
    modals.createAgent && /* @__PURE__ */ jsxDEV(
      CreateAgentModal,
      {
        open: modals.createAgent,
        projectId,
        onClose: () => close("createAgent"),
        onCreate: handleCreateAgentSubmit
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
        lineNumber: 227,
        columnNumber: 7
      },
      this
    ),
    modals.alertRules && /* @__PURE__ */ jsxDEV(AlertRulesModal, { projectId, onClose: () => close("alertRules") }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
      lineNumber: 236,
      columnNumber: 7
    }, this),
    modals.budgetBurnDown && /* @__PURE__ */ jsxDEV(Dialog, { open: true, onOpenChange: (open2) => !open2 && close("budgetBurnDown"), children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "max-w-[800px] max-h-[85vh] overflow-auto", children: [
      /* @__PURE__ */ jsxDEV(DialogHeader, { children: /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Budget burn-down" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
        lineNumber: 243,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
        lineNumber: 242,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(BudgetBurnDown, { projectId }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
        lineNumber: 245,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
      lineNumber: 241,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
      lineNumber: 240,
      columnNumber: 7
    }, this),
    modals.advancedAnalytics && /* @__PURE__ */ jsxDEV(
      AnalyticsDashboard,
      {
        projectId,
        onClose: () => close("advancedAnalytics")
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
        lineNumber: 251,
        columnNumber: 7
      },
      this
    ),
    modals.healthDashboard && /* @__PURE__ */ jsxDEV(HealthDashboard, { projectId, onClose: () => close("healthDashboard") }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
      lineNumber: 258,
      columnNumber: 7
    }, this),
    modals.monitoringDashboard && /* @__PURE__ */ jsxDEV(MonitoringDashboard, { onClose: () => close("monitoringDashboard") }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
      lineNumber: 262,
      columnNumber: 7
    }, this),
    modals.commandPalette && /* @__PURE__ */ jsxDEV(
      CommandPalette,
      {
        projectId,
        onClose: () => close("commandPalette"),
        onSelectTask: setSelectedTaskId,
        onCreateTask: () => {
          close("commandPalette");
          open("createTask");
        },
        onOpenApprovals: () => {
          close("commandPalette");
          open("approvals");
        },
        onOpenAgents: () => {
          close("commandPalette");
          setSidebarSelectedAgentId(null);
          open("agentsFlyout");
        },
        onOpenControls: () => {
          close("commandPalette");
          open("operatorControls");
        },
        onOpenCostAnalytics: () => {
          close("commandPalette");
          open("costAnalytics");
        },
        onOpenCreateAgent: () => {
          close("commandPalette");
          open("createAgent");
        },
        onNavigateToGateway,
        onNavigateView: (view) => {
          close("commandPalette");
          onNavigate(view);
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
        lineNumber: 266,
        columnNumber: 7
      },
      this
    ),
    modals.keyboardHelp && /* @__PURE__ */ jsxDEV(KeyboardShortcutsHelp, { onClose: () => close("keyboardHelp") }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
      lineNumber: 304,
      columnNumber: 7
    }, this),
    modals.activityFeed && /* @__PURE__ */ jsxDEV(ActivityFeedModal, { projectId, onClose: () => close("activityFeed") }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
      lineNumber: 308,
      columnNumber: 7
    }, this),
    modals.missionModal && /* @__PURE__ */ jsxDEV(MissionModal, { projectId, onClose: () => close("missionModal") }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
      lineNumber: 312,
      columnNumber: 7
    }, this),
    modals.suggestionsDrawer && /* @__PURE__ */ jsxDEV(
      MissionSuggestionsDrawer,
      {
        projectId,
        onClose: () => close("suggestionsDrawer")
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
        lineNumber: 316,
        columnNumber: 7
      },
      this
    ),
    modals.agentsFlyout && /* @__PURE__ */ jsxDEV(
      AgentsFlyout,
      {
        projectId,
        onClose: () => close("agentsFlyout"),
        onOpenApprovals: () => {
          close("agentsFlyout");
          open("approvals");
        },
        onOpenPolicy: () => {
          close("agentsFlyout");
          open("policy");
        },
        onOpenOperatorControls: () => {
          close("agentsFlyout");
          open("operatorControls");
        },
        onOpenNotifications: () => {
          close("agentsFlyout");
          open("notifications");
        },
        onOpenStandup: () => {
          close("agentsFlyout");
          open("standup");
        },
        onPauseSquad: () => open("pauseConfirm"),
        onResumeSquad,
        onOpenOrg: (agentId) => {
          window.localStorage.setItem("mc.org.focusAgentId", agentId);
          close("agentsFlyout");
          onNavigate("org");
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
        lineNumber: 323,
        columnNumber: 7
      },
      this
    ),
    sidebarSelectedAgentId && /* @__PURE__ */ jsxDEV(
      AgentDetailFlyout,
      {
        agentId: sidebarSelectedAgentId,
        onClose: () => setSidebarSelectedAgentId(null),
        onEdit: (agentId) => {
          window.localStorage.setItem("mc.org.focusAgentId", agentId);
          setSidebarSelectedAgentId(null);
          onNavigate("org");
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
        lineNumber: 357,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx",
    lineNumber: 131,
    columnNumber: 5
  }, this);
}
_s(ModalLayer, "xMkQm8Pioy2/OsBplnWqv6AaQOc=", false, function() {
  return [useMutation];
});
_c = ModalLayer;
var _c;
$RefreshReg$(_c, "ModalLayer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ModalLayer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0dJLG1CQVNRLGNBVFI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBL0dKLFNBQVNBLG1CQUFtQjtBQUM1QixTQUFTQyxXQUFXO0FBSXBCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0Msd0JBQXdCO0FBQ2pDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLDZCQUE2QjtBQUN0QyxTQUFTQywwQkFBMEI7QUFDbkMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsMkJBQTJCO0FBQ3BDLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyw2QkFBNkI7QUFDdEMsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGdDQUFnQztBQUN6QyxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLHVCQUF1QjtBQXlCekIsZ0JBQVNDLFdBQVc7QUFBQSxFQUN6QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsZ0JBQWdCQztBQUFBQSxFQUNoQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDZSxHQUFHO0FBQUFDLEtBQUE7QUFDbEIsUUFBTUMsZ0JBQWdCakQsWUFBWUMsSUFBSWlELE9BQU9DLFFBQVE7QUFFckQsUUFBTUMsMEJBQTBCLE9BQU9DLFNBQXVEO0FBQzVGLFVBQU1DLE9BQStCLENBQUM7QUFDdEMsUUFBSUQsS0FBS0UsTUFBT0QsTUFBS0MsUUFBUUYsS0FBS0U7QUFDbEMsUUFBSUYsS0FBS0csU0FBVUYsTUFBS0UsV0FBV0gsS0FBS0c7QUFDeEMsUUFBSUgsS0FBS0ksU0FBVUgsTUFBS0csV0FBV0osS0FBS0k7QUFDeEMsUUFBSUosS0FBS0ssUUFBU0osTUFBS0ksVUFBVUwsS0FBS0s7QUFDdEMsUUFBSTtBQUNGLFlBQU1ULGNBQWM7QUFBQSxRQUNsQmhCLFdBQVdBLGFBQWEwQjtBQUFBQSxRQUN4QkMsTUFBTVAsS0FBS087QUFBQUEsUUFDWEMsT0FBT1IsS0FBS1EsU0FBU0Y7QUFBQUEsUUFDckJHLE1BQU1ULEtBQUtTO0FBQUFBLFFBQ1hDLGVBQWVWLEtBQUtVO0FBQUFBLFFBQ3BCQyxrQkFBa0JYLEtBQUtXLG1CQUFtQlgsS0FBS1csaUJBQWlCQyxNQUFNLEdBQUcsRUFBRUMsSUFBSSxDQUFDQyxNQUFNQSxFQUFFQyxLQUFLLENBQUMsRUFBRUMsT0FBT0MsT0FBTyxJQUFJWDtBQUFBQSxRQUNsSFksY0FBY2xCLEtBQUtrQixlQUFlbEIsS0FBS2tCLGFBQWFOLE1BQU0sR0FBRyxFQUFFQyxJQUFJLENBQUNDLE1BQU1BLEVBQUVDLEtBQUssQ0FBQyxFQUFFQyxPQUFPQyxPQUFPLElBQUlYO0FBQUFBLFFBQ3RHYSxhQUFhbkIsS0FBS21CLGNBQWNDLE9BQU9wQixLQUFLbUIsV0FBVyxJQUFJYjtBQUFBQSxRQUMzRGUsY0FBY3JCLEtBQUtxQixlQUFlRCxPQUFPcEIsS0FBS3FCLFlBQVksSUFBSWY7QUFBQUEsUUFDOURnQixVQUFVdEIsS0FBS3NCO0FBQUFBLFFBQ2ZDLGNBQWN2QixLQUFLc0IsV0FBV0YsT0FBT3BCLEtBQUt1QixnQkFBZ0IsQ0FBQyxJQUFJO0FBQUEsUUFDL0RDLGVBQWVsQjtBQUFBQSxRQUNmbUIsVUFBVUMsT0FBT0MsS0FBSzFCLElBQUksRUFBRTJCLFNBQVMsSUFBSTNCLE9BQU9LO0FBQUFBLE1BQ2xELENBQUM7QUFDRHZCLFlBQU0sYUFBYTtBQUNuQlUsY0FBUSxlQUFlO0FBQUEsSUFDekIsU0FBU29DLEtBQUs7QUFDWixZQUFNQyxVQUFVRCxlQUFlRSxRQUFRRixJQUFJQyxVQUFVO0FBQ3JEckMsY0FBUXFDLFNBQVMsSUFBSTtBQUNyQixZQUFNRDtBQUFBQSxJQUNSO0FBQUEsRUFDRjtBQUVBLFNBQ0UsbUNBRUU7QUFBQSwyQkFBQyxVQUFPLE1BQU1oRCxPQUFPbUQsY0FBYyxjQUFjLENBQUNsRCxVQUFTLENBQUNBLFNBQVFDLE1BQU0sY0FBYyxHQUN0RjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0Msb0JBQWlCO0FBQUEsUUFDakIsc0JBQXNCLE1BQU1BLE1BQU0sY0FBYztBQUFBLFFBQ2hELGlCQUFpQixNQUFNQSxNQUFNLGNBQWM7QUFBQSxRQUUzQztBQUFBLGlDQUFDLGdCQUNDO0FBQUEsbUNBQUMsZUFBWSx3Q0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQztBQUFBLFlBQ3JDLHVCQUFDLHFCQUFrQixJQUFHLDZCQUEyQiwrRkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsZ0JBQWEsV0FBVSxrQkFDdEI7QUFBQSxtQ0FBQyxVQUFPLFNBQVEsV0FBVSxNQUFLLE1BQUssU0FBUyxNQUFNQSxNQUFNLGNBQWMsR0FBRSxzQkFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsVUFBTyxTQUFRLGVBQWMsTUFBSyxNQUFLLFNBQVNRLHFCQUFvQiwyQkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBO0FBQUE7QUFBQSxNQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFtQkEsS0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFCQTtBQUFBLElBRUNWLE9BQU9vRCxjQUNOO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsU0FBUyxNQUFNbEQsTUFBTSxZQUFZO0FBQUEsUUFDakMsV0FBVyxNQUFNVSxRQUFRLGNBQWM7QUFBQTtBQUFBLE1BSHpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUcyQztBQUFBLElBSTVDWixPQUFPcUQsYUFDTjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFNBQVMsTUFBTW5ELE1BQU0sV0FBVztBQUFBLFFBQ2hDLFdBQVcsQ0FBQ29ELFVBQ1YxQztBQUFBQSxVQUNFMEMsUUFBUSxJQUNKLEdBQUdBLEtBQUssNEJBQ1I7QUFBQSxRQUNOO0FBQUE7QUFBQSxNQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVNHO0FBQUEsSUFJSnRELE9BQU91RCxjQUNOO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsU0FBUyxNQUFNckQsTUFBTSxZQUFZO0FBQUEsUUFDakMsV0FBVyxDQUFDc0QsVUFBVTVDLFFBQVEsVUFBVTRDLEtBQUssVUFBVTtBQUFBO0FBQUEsTUFIekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRzJEO0FBQUEsSUFJNUR4RCxPQUFPeUQsYUFDTix1QkFBQyxrQkFBZSxXQUFzQixTQUFTLE1BQU12RCxNQUFNLFdBQVcsS0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RTtBQUFBLElBR3pFRixPQUFPMEQsVUFBVSx1QkFBQyxlQUFZLFNBQVMsTUFBTXhELE1BQU0sUUFBUSxLQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRDO0FBQUEsSUFFN0RGLE9BQU8yRCxvQkFDTjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFNBQVMsTUFBTXpELE1BQU0sa0JBQWtCO0FBQUE7QUFBQSxNQUZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFMkM7QUFBQSxJQUk1Q0YsT0FBTzRELGlCQUNOO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFTLE1BQU0xRCxNQUFNLGVBQWU7QUFBQSxRQUNwQyxjQUFjRztBQUFBQTtBQUFBQSxNQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFa0M7QUFBQSxJQUluQ0wsT0FBTzZELFdBQ04sdUJBQUMsZ0JBQWEsV0FBc0IsU0FBUyxNQUFNM0QsTUFBTSxTQUFTLEtBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0U7QUFBQSxJQUdyRUYsT0FBTzhELGtCQUNOO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsU0FBUyxNQUFNNUQsTUFBTSxnQkFBZ0I7QUFBQSxRQUNyQyxlQUFlLENBQUM2RCxPQUFPO0FBQ3JCeEQsb0NBQTBCd0QsRUFBRTtBQUM1QjdELGdCQUFNLGdCQUFnQjtBQUN0QkQsZUFBSyxjQUFjO0FBQUEsUUFDckI7QUFBQTtBQUFBLE1BUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT0k7QUFBQSxJQUlMRCxPQUFPZ0UsaUJBQ04sdUJBQUMsaUJBQWMsV0FBc0IsU0FBUyxNQUFNOUQsTUFBTSxlQUFlLEtBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkU7QUFBQSxJQUc1RUYsT0FBT2lFLGVBQ047QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU1qRSxPQUFPaUU7QUFBQUEsUUFDYjtBQUFBLFFBQ0EsU0FBUyxNQUFNL0QsTUFBTSxhQUFhO0FBQUEsUUFDbEMsVUFBVWdCO0FBQUFBO0FBQUFBLE1BSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSW9DO0FBQUEsSUFJckNsQixPQUFPa0UsY0FDTix1QkFBQyxtQkFBZ0IsV0FBc0IsU0FBUyxNQUFNaEUsTUFBTSxZQUFZLEtBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEU7QUFBQSxJQUczRUYsT0FBT21FLGtCQUNOLHVCQUFDLFVBQU8sTUFBSSxNQUFDLGNBQWMsQ0FBQ2xFLFVBQVMsQ0FBQ0EsU0FBUUMsTUFBTSxnQkFBZ0IsR0FDbEUsaUNBQUMsaUJBQWMsV0FBVSw0Q0FDdkI7QUFBQSw2QkFBQyxnQkFDQyxpQ0FBQyxlQUFZLGdDQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkIsS0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxrQkFBZSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFDO0FBQUEsU0FKdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFHREYsT0FBT29FLHFCQUNOO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsU0FBUyxNQUFNbEUsTUFBTSxtQkFBbUI7QUFBQTtBQUFBLE1BRjFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUU0QztBQUFBLElBSTdDRixPQUFPcUUsbUJBQ04sdUJBQUMsbUJBQWdCLFdBQXNCLFNBQVMsTUFBTW5FLE1BQU0saUJBQWlCLEtBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0U7QUFBQSxJQUdoRkYsT0FBT3NFLHVCQUNOLHVCQUFDLHVCQUFvQixTQUFTLE1BQU1wRSxNQUFNLHFCQUFxQixLQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlFO0FBQUEsSUFHbEVGLE9BQU91RSxrQkFDTjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFNBQVMsTUFBTXJFLE1BQU0sZ0JBQWdCO0FBQUEsUUFDckMsY0FBY0c7QUFBQUEsUUFDZCxjQUFjLE1BQU07QUFDbEJILGdCQUFNLGdCQUFnQjtBQUN0QkQsZUFBSyxZQUFZO0FBQUEsUUFDbkI7QUFBQSxRQUNBLGlCQUFpQixNQUFNO0FBQ3JCQyxnQkFBTSxnQkFBZ0I7QUFDdEJELGVBQUssV0FBVztBQUFBLFFBQ2xCO0FBQUEsUUFDQSxjQUFjLE1BQU07QUFDbEJDLGdCQUFNLGdCQUFnQjtBQUN0Qkssb0NBQTBCLElBQUk7QUFDOUJOLGVBQUssY0FBYztBQUFBLFFBQ3JCO0FBQUEsUUFDQSxnQkFBZ0IsTUFBTTtBQUNwQkMsZ0JBQU0sZ0JBQWdCO0FBQ3RCRCxlQUFLLGtCQUFrQjtBQUFBLFFBQ3pCO0FBQUEsUUFDQSxxQkFBcUIsTUFBTTtBQUN6QkMsZ0JBQU0sZ0JBQWdCO0FBQ3RCRCxlQUFLLGVBQWU7QUFBQSxRQUN0QjtBQUFBLFFBQ0EsbUJBQW1CLE1BQU07QUFDdkJDLGdCQUFNLGdCQUFnQjtBQUN0QkQsZUFBSyxhQUFhO0FBQUEsUUFDcEI7QUFBQSxRQUNBO0FBQUEsUUFDQSxnQkFBZ0IsQ0FBQ3VFLFNBQVM7QUFDeEJ0RSxnQkFBTSxnQkFBZ0I7QUFDdEJPLHFCQUFXK0QsSUFBSTtBQUFBLFFBQ2pCO0FBQUE7QUFBQSxNQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFpQ0k7QUFBQSxJQUlMeEUsT0FBT3lFLGdCQUNOLHVCQUFDLHlCQUFzQixTQUFTLE1BQU12RSxNQUFNLGNBQWMsS0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0RDtBQUFBLElBRzdERixPQUFPMEUsZ0JBQ04sdUJBQUMscUJBQWtCLFdBQXNCLFNBQVMsTUFBTXhFLE1BQU0sY0FBYyxLQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThFO0FBQUEsSUFHL0VGLE9BQU8yRSxnQkFDTix1QkFBQyxnQkFBYSxXQUFzQixTQUFTLE1BQU16RSxNQUFNLGNBQWMsS0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5RTtBQUFBLElBRzFFRixPQUFPNEUscUJBQ047QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQSxTQUFTLE1BQU0xRSxNQUFNLG1CQUFtQjtBQUFBO0FBQUEsTUFGMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRTRDO0FBQUEsSUFJN0NGLE9BQU82RSxnQkFDTjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFNBQVMsTUFBTTNFLE1BQU0sY0FBYztBQUFBLFFBQ25DLGlCQUFpQixNQUFNO0FBQ3JCQSxnQkFBTSxjQUFjO0FBQ3BCRCxlQUFLLFdBQVc7QUFBQSxRQUNsQjtBQUFBLFFBQ0EsY0FBYyxNQUFNO0FBQ2xCQyxnQkFBTSxjQUFjO0FBQ3BCRCxlQUFLLFFBQVE7QUFBQSxRQUNmO0FBQUEsUUFDQSx3QkFBd0IsTUFBTTtBQUM1QkMsZ0JBQU0sY0FBYztBQUNwQkQsZUFBSyxrQkFBa0I7QUFBQSxRQUN6QjtBQUFBLFFBQ0EscUJBQXFCLE1BQU07QUFDekJDLGdCQUFNLGNBQWM7QUFDcEJELGVBQUssZUFBZTtBQUFBLFFBQ3RCO0FBQUEsUUFDQSxlQUFlLE1BQU07QUFDbkJDLGdCQUFNLGNBQWM7QUFDcEJELGVBQUssU0FBUztBQUFBLFFBQ2hCO0FBQUEsUUFDQSxjQUFjLE1BQU1BLEtBQUssY0FBYztBQUFBLFFBQ3ZDO0FBQUEsUUFDQSxXQUFXLENBQUM2RSxZQUFZO0FBQ3RCQyxpQkFBT0MsYUFBYUMsUUFBUSx1QkFBdUJILE9BQU87QUFDMUQ1RSxnQkFBTSxjQUFjO0FBQ3BCTyxxQkFBVyxLQUFLO0FBQUEsUUFDbEI7QUFBQTtBQUFBLE1BN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTZCSTtBQUFBLElBSUxILDBCQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFTQTtBQUFBQSxRQUNULFNBQVMsTUFBTUMsMEJBQTBCLElBQUk7QUFBQSxRQUM3QyxRQUFRLENBQUN1RSxZQUFZO0FBQ25CQyxpQkFBT0MsYUFBYUMsUUFBUSx1QkFBdUJILE9BQU87QUFDMUR2RSxvQ0FBMEIsSUFBSTtBQUM5QkUscUJBQVcsS0FBSztBQUFBLFFBQ2xCO0FBQUE7QUFBQSxNQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9JO0FBQUEsT0F6T1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRPQTtBQUVKO0FBQUNLLEdBaFNlaEIsWUFBVTtBQUFBLFVBZ0JGaEMsV0FBVztBQUFBO0FBQUEsS0FoQm5CZ0M7QUFBVSxJQUFBb0Y7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlTXV0YXRpb24iLCJhcGkiLCJCdXR0b24iLCJDcmVhdGVBZ2VudE1vZGFsIiwiRGlhbG9nIiwiRGlhbG9nQ29udGVudCIsIkRpYWxvZ0Rlc2NyaXB0aW9uIiwiRGlhbG9nRm9vdGVyIiwiRGlhbG9nSGVhZGVyIiwiRGlhbG9nVGl0bGUiLCJDcmVhdGVUYXNrTW9kYWwiLCJBcHByb3ZhbHNNb2RhbCIsIlBvbGljeU1vZGFsIiwiT3BlcmF0b3JDb250cm9sc01vZGFsIiwiTm90aWZpY2F0aW9uc01vZGFsIiwiU3RhbmR1cE1vZGFsIiwiQWdlbnREYXNoYm9hcmQiLCJDb3N0QW5hbHl0aWNzIiwiQnVkZ2V0QnVybkRvd24iLCJBbmFseXRpY3NEYXNoYm9hcmQiLCJIZWFsdGhEYXNoYm9hcmQiLCJNb25pdG9yaW5nRGFzaGJvYXJkIiwiQ29tbWFuZFBhbGV0dGUiLCJLZXlib2FyZFNob3J0Y3V0c0hlbHAiLCJBY3Rpdml0eUZlZWRNb2RhbCIsIkFnZW50c0ZseW91dCIsIkFnZW50RGV0YWlsRmx5b3V0IiwiTWlzc2lvbk1vZGFsIiwiTWlzc2lvblN1Z2dlc3Rpb25zRHJhd2VyIiwiSW1wb3J0UHJkTW9kYWwiLCJTdGFydFFjUnVuTW9kYWwiLCJBbGVydFJ1bGVzTW9kYWwiLCJNb2RhbExheWVyIiwicHJvamVjdElkIiwibW9kYWxzIiwib3BlbiIsImNsb3NlIiwic2VsZWN0ZWRUYXNrSWQiLCJfc2VsZWN0ZWRUYXNrSWQiLCJzZXRTZWxlY3RlZFRhc2tJZCIsInNpZGViYXJTZWxlY3RlZEFnZW50SWQiLCJzZXRTaWRlYmFyU2VsZWN0ZWRBZ2VudElkIiwic2lkZWJhcldpZHRoIiwib25OYXZpZ2F0ZSIsIm9uQ29uZmlybVBhdXNlU3F1YWQiLCJvblJlc3VtZVNxdWFkIiwib25Ub2FzdCIsIm9uTmF2aWdhdGVUb0dhdGV3YXkiLCJfcyIsInJlZ2lzdGVyQWdlbnQiLCJhZ2VudHMiLCJyZWdpc3RlciIsImhhbmRsZUNyZWF0ZUFnZW50U3VibWl0IiwiZm9ybSIsIm1ldGEiLCJlbWFpbCIsInRlbGVncmFtIiwid2hhdHNhcHAiLCJkaXNjb3JkIiwidW5kZWZpbmVkIiwibmFtZSIsImVtb2ppIiwicm9sZSIsIndvcmtzcGFjZVBhdGgiLCJhbGxvd2VkVGFza1R5cGVzIiwic3BsaXQiLCJtYXAiLCJzIiwidHJpbSIsImZpbHRlciIsIkJvb2xlYW4iLCJhbGxvd2VkVG9vbHMiLCJidWRnZXREYWlseSIsIk51bWJlciIsImJ1ZGdldFBlclJ1biIsImNhblNwYXduIiwibWF4U3ViQWdlbnRzIiwicGFyZW50QWdlbnRJZCIsIm1ldGFkYXRhIiwiT2JqZWN0Iiwia2V5cyIsImxlbmd0aCIsImVyciIsIm1lc3NhZ2UiLCJFcnJvciIsInBhdXNlQ29uZmlybSIsImNyZWF0ZVRhc2siLCJpbXBvcnRQcmQiLCJjb3VudCIsInN0YXJ0UWNSdW4iLCJydW5JZCIsImFwcHJvdmFscyIsInBvbGljeSIsIm9wZXJhdG9yQ29udHJvbHMiLCJub3RpZmljYXRpb25zIiwic3RhbmR1cCIsImFnZW50RGFzaGJvYXJkIiwiaWQiLCJjb3N0QW5hbHl0aWNzIiwiY3JlYXRlQWdlbnQiLCJhbGVydFJ1bGVzIiwiYnVkZ2V0QnVybkRvd24iLCJhZHZhbmNlZEFuYWx5dGljcyIsImhlYWx0aERhc2hib2FyZCIsIm1vbml0b3JpbmdEYXNoYm9hcmQiLCJjb21tYW5kUGFsZXR0ZSIsInZpZXciLCJrZXlib2FyZEhlbHAiLCJhY3Rpdml0eUZlZWQiLCJtaXNzaW9uTW9kYWwiLCJzdWdnZXN0aW9uc0RyYXdlciIsImFnZW50c0ZseW91dCIsImFnZW50SWQiLCJ3aW5kb3ciLCJsb2NhbFN0b3JhZ2UiLCJzZXRJdGVtIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTW9kYWxMYXllci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTXV0YXRpb24gfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHR5cGUgeyBNYWluVmlldyB9IGZyb20gXCIuL1RvcE5hdlwiO1xuaW1wb3J0IHR5cGUgeyBNb2RhbHMsIE1vZGFsS2V5IH0gZnJvbSBcIi4vaG9va3MvdXNlTW9kYWxTdGF0ZVwiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9idXR0b25cIjtcbmltcG9ydCB7IENyZWF0ZUFnZW50TW9kYWwgfSBmcm9tIFwiLi9DcmVhdGVBZ2VudE1vZGFsXCI7XG5pbXBvcnQge1xuICBEaWFsb2csXG4gIERpYWxvZ0NvbnRlbnQsXG4gIERpYWxvZ0Rlc2NyaXB0aW9uLFxuICBEaWFsb2dGb290ZXIsXG4gIERpYWxvZ0hlYWRlcixcbiAgRGlhbG9nVGl0bGUsXG59IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvZGlhbG9nXCI7XG5pbXBvcnQgeyBDcmVhdGVUYXNrTW9kYWwgfSBmcm9tIFwiLi9DcmVhdGVUYXNrTW9kYWxcIjtcbmltcG9ydCB7IEFwcHJvdmFsc01vZGFsIH0gZnJvbSBcIi4vQXBwcm92YWxzTW9kYWxcIjtcbmltcG9ydCB7IFBvbGljeU1vZGFsIH0gZnJvbSBcIi4vUG9saWN5TW9kYWxcIjtcbmltcG9ydCB7IE9wZXJhdG9yQ29udHJvbHNNb2RhbCB9IGZyb20gXCIuL09wZXJhdG9yQ29udHJvbHNNb2RhbFwiO1xuaW1wb3J0IHsgTm90aWZpY2F0aW9uc01vZGFsIH0gZnJvbSBcIi4vTm90aWZpY2F0aW9uc01vZGFsXCI7XG5pbXBvcnQgeyBTdGFuZHVwTW9kYWwgfSBmcm9tIFwiLi9TdGFuZHVwTW9kYWxcIjtcbmltcG9ydCB7IEFnZW50RGFzaGJvYXJkIH0gZnJvbSBcIi4vQWdlbnREYXNoYm9hcmRcIjtcbmltcG9ydCB7IENvc3RBbmFseXRpY3MgfSBmcm9tIFwiLi9Db3N0QW5hbHl0aWNzXCI7XG5pbXBvcnQgeyBCdWRnZXRCdXJuRG93biB9IGZyb20gXCIuL0J1ZGdldEJ1cm5Eb3duXCI7XG5pbXBvcnQgeyBBbmFseXRpY3NEYXNoYm9hcmQgfSBmcm9tIFwiLi9BbmFseXRpY3NEYXNoYm9hcmRcIjtcbmltcG9ydCB7IEhlYWx0aERhc2hib2FyZCB9IGZyb20gXCIuL0hlYWx0aERhc2hib2FyZFwiO1xuaW1wb3J0IHsgTW9uaXRvcmluZ0Rhc2hib2FyZCB9IGZyb20gXCIuL01vbml0b3JpbmdEYXNoYm9hcmRcIjtcbmltcG9ydCB7IENvbW1hbmRQYWxldHRlIH0gZnJvbSBcIi4vQ29tbWFuZFBhbGV0dGVcIjtcbmltcG9ydCB7IEtleWJvYXJkU2hvcnRjdXRzSGVscCB9IGZyb20gXCIuL0tleWJvYXJkU2hvcnRjdXRzXCI7XG5pbXBvcnQgeyBBY3Rpdml0eUZlZWRNb2RhbCB9IGZyb20gXCIuL0FjdGl2aXR5RmVlZFwiO1xuaW1wb3J0IHsgQWdlbnRzRmx5b3V0IH0gZnJvbSBcIi4vQWdlbnRzRmx5b3V0XCI7XG5pbXBvcnQgeyBBZ2VudERldGFpbEZseW91dCB9IGZyb20gXCIuL0FnZW50RGV0YWlsRmx5b3V0XCI7XG5pbXBvcnQgeyBNaXNzaW9uTW9kYWwgfSBmcm9tIFwiLi9NaXNzaW9uTW9kYWxcIjtcbmltcG9ydCB7IE1pc3Npb25TdWdnZXN0aW9uc0RyYXdlciB9IGZyb20gXCIuL01pc3Npb25TdWdnZXN0aW9uc0RyYXdlclwiO1xuaW1wb3J0IHsgSW1wb3J0UHJkTW9kYWwgfSBmcm9tIFwiLi9JbXBvcnRQcmRNb2RhbFwiO1xuaW1wb3J0IHsgU3RhcnRRY1J1bk1vZGFsIH0gZnJvbSBcIi4vU3RhcnRRY1J1bk1vZGFsXCI7XG5pbXBvcnQgeyBBbGVydFJ1bGVzTW9kYWwgfSBmcm9tIFwiLi9BbGVydFJ1bGVzTW9kYWxcIjtcblxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gTU9EQUwgTEFZRVJcbi8vIFJlbmRlcnMgYWxsIGZsb2F0aW5nIG92ZXJsYXlzIOKAlCBtb2RhbHMsIGZseW91dHMsIGRyYXdlcnMg4oCUIGluIGEgc2luZ2xlXG4vLyBkZWNsYXJhdGl2ZSBjb21wb25lbnQsIGtlZXBpbmcgQXBwLnRzeCBmcmVlIG9mIG1vZGFsIEpTWC5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuaW50ZXJmYWNlIE1vZGFsTGF5ZXJQcm9wcyB7XG4gIHByb2plY3RJZDogSWQ8XCJwcm9qZWN0c1wiPiB8IG51bGw7XG4gIG1vZGFsczogTW9kYWxzO1xuICBvcGVuOiAoa2V5OiBNb2RhbEtleSkgPT4gdm9pZDtcbiAgY2xvc2U6IChrZXk6IE1vZGFsS2V5KSA9PiB2b2lkO1xuICBzZWxlY3RlZFRhc2tJZDogSWQ8XCJ0YXNrc1wiPiB8IG51bGw7XG4gIHNldFNlbGVjdGVkVGFza0lkOiAoaWQ6IElkPFwidGFza3NcIj4gfCBudWxsKSA9PiB2b2lkO1xuICBzaWRlYmFyU2VsZWN0ZWRBZ2VudElkOiBJZDxcImFnZW50c1wiPiB8IG51bGw7XG4gIHNldFNpZGViYXJTZWxlY3RlZEFnZW50SWQ6IChpZDogSWQ8XCJhZ2VudHNcIj4gfCBudWxsKSA9PiB2b2lkO1xuICBzaWRlYmFyV2lkdGg6IG51bWJlcjtcbiAgb25OYXZpZ2F0ZTogKHZpZXc6IE1haW5WaWV3KSA9PiB2b2lkO1xuICBvbkNvbmZpcm1QYXVzZVNxdWFkOiAoKSA9PiB2b2lkO1xuICBvblJlc3VtZVNxdWFkOiAoKSA9PiB2b2lkO1xuICBvblRvYXN0OiAobXNnOiBzdHJpbmcsIGVycm9yPzogYm9vbGVhbikgPT4gdm9pZDtcbiAgb25OYXZpZ2F0ZVRvR2F0ZXdheT86ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBNb2RhbExheWVyKHtcbiAgcHJvamVjdElkLFxuICBtb2RhbHMsXG4gIG9wZW4sXG4gIGNsb3NlLFxuICBzZWxlY3RlZFRhc2tJZDogX3NlbGVjdGVkVGFza0lkLFxuICBzZXRTZWxlY3RlZFRhc2tJZCxcbiAgc2lkZWJhclNlbGVjdGVkQWdlbnRJZCxcbiAgc2V0U2lkZWJhclNlbGVjdGVkQWdlbnRJZCxcbiAgc2lkZWJhcldpZHRoLFxuICBvbk5hdmlnYXRlLFxuICBvbkNvbmZpcm1QYXVzZVNxdWFkLFxuICBvblJlc3VtZVNxdWFkLFxuICBvblRvYXN0LFxuICBvbk5hdmlnYXRlVG9HYXRld2F5LFxufTogTW9kYWxMYXllclByb3BzKSB7XG4gIGNvbnN0IHJlZ2lzdGVyQWdlbnQgPSB1c2VNdXRhdGlvbihhcGkuYWdlbnRzLnJlZ2lzdGVyKTtcblxuICBjb25zdCBoYW5kbGVDcmVhdGVBZ2VudFN1Ym1pdCA9IGFzeW5jIChmb3JtOiBpbXBvcnQoXCIuL0NyZWF0ZUFnZW50TW9kYWxcIikuQ3JlYXRlQWdlbnRGb3JtKSA9PiB7XG4gICAgY29uc3QgbWV0YTogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHt9O1xuICAgIGlmIChmb3JtLmVtYWlsKSBtZXRhLmVtYWlsID0gZm9ybS5lbWFpbDtcbiAgICBpZiAoZm9ybS50ZWxlZ3JhbSkgbWV0YS50ZWxlZ3JhbSA9IGZvcm0udGVsZWdyYW07XG4gICAgaWYgKGZvcm0ud2hhdHNhcHApIG1ldGEud2hhdHNhcHAgPSBmb3JtLndoYXRzYXBwO1xuICAgIGlmIChmb3JtLmRpc2NvcmQpIG1ldGEuZGlzY29yZCA9IGZvcm0uZGlzY29yZDtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgcmVnaXN0ZXJBZ2VudCh7XG4gICAgICAgIHByb2plY3RJZDogcHJvamVjdElkID8/IHVuZGVmaW5lZCxcbiAgICAgICAgbmFtZTogZm9ybS5uYW1lLFxuICAgICAgICBlbW9qaTogZm9ybS5lbW9qaSB8fCB1bmRlZmluZWQsXG4gICAgICAgIHJvbGU6IGZvcm0ucm9sZSxcbiAgICAgICAgd29ya3NwYWNlUGF0aDogZm9ybS53b3Jrc3BhY2VQYXRoLFxuICAgICAgICBhbGxvd2VkVGFza1R5cGVzOiBmb3JtLmFsbG93ZWRUYXNrVHlwZXMgPyBmb3JtLmFsbG93ZWRUYXNrVHlwZXMuc3BsaXQoXCIsXCIpLm1hcCgocykgPT4gcy50cmltKCkpLmZpbHRlcihCb29sZWFuKSA6IHVuZGVmaW5lZCxcbiAgICAgICAgYWxsb3dlZFRvb2xzOiBmb3JtLmFsbG93ZWRUb29scyA/IGZvcm0uYWxsb3dlZFRvb2xzLnNwbGl0KFwiLFwiKS5tYXAoKHMpID0+IHMudHJpbSgpKS5maWx0ZXIoQm9vbGVhbikgOiB1bmRlZmluZWQsXG4gICAgICAgIGJ1ZGdldERhaWx5OiBmb3JtLmJ1ZGdldERhaWx5ID8gTnVtYmVyKGZvcm0uYnVkZ2V0RGFpbHkpIDogdW5kZWZpbmVkLFxuICAgICAgICBidWRnZXRQZXJSdW46IGZvcm0uYnVkZ2V0UGVyUnVuID8gTnVtYmVyKGZvcm0uYnVkZ2V0UGVyUnVuKSA6IHVuZGVmaW5lZCxcbiAgICAgICAgY2FuU3Bhd246IGZvcm0uY2FuU3Bhd24sXG4gICAgICAgIG1heFN1YkFnZW50czogZm9ybS5jYW5TcGF3biA/IE51bWJlcihmb3JtLm1heFN1YkFnZW50cyB8fCAwKSA6IDAsXG4gICAgICAgIHBhcmVudEFnZW50SWQ6IHVuZGVmaW5lZCxcbiAgICAgICAgbWV0YWRhdGE6IE9iamVjdC5rZXlzKG1ldGEpLmxlbmd0aCA+IDAgPyBtZXRhIDogdW5kZWZpbmVkLFxuICAgICAgfSk7XG4gICAgICBjbG9zZShcImNyZWF0ZUFnZW50XCIpO1xuICAgICAgb25Ub2FzdChcIkFnZW50IGNyZWF0ZWRcIik7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zdCBtZXNzYWdlID0gZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6IFwiRmFpbGVkIHRvIGNyZWF0ZSBhZ2VudC5cIjtcbiAgICAgIG9uVG9hc3QobWVzc2FnZSwgdHJ1ZSk7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHsvKiDilIDilIAgUGF1c2UgY29uZmlybWF0aW9uIChzaGFyZWQgRGlhbG9nIGZvciBmb2N1cy9lc2NhcGUpIOKUgOKUgCAqL31cbiAgICAgIDxEaWFsb2cgb3Blbj17bW9kYWxzLnBhdXNlQ29uZmlybX0gb25PcGVuQ2hhbmdlPXsob3BlbikgPT4gIW9wZW4gJiYgY2xvc2UoXCJwYXVzZUNvbmZpcm1cIil9PlxuICAgICAgICA8RGlhbG9nQ29udGVudFxuICAgICAgICAgIGFyaWEtZGVzY3JpYmVkYnk9XCJwYXVzZS1jb25maXJtLWRlc2NyaXB0aW9uXCJcbiAgICAgICAgICBvblBvaW50ZXJEb3duT3V0c2lkZT17KCkgPT4gY2xvc2UoXCJwYXVzZUNvbmZpcm1cIil9XG4gICAgICAgICAgb25Fc2NhcGVLZXlEb3duPXsoKSA9PiBjbG9zZShcInBhdXNlQ29uZmlybVwiKX1cbiAgICAgICAgPlxuICAgICAgICAgIDxEaWFsb2dIZWFkZXI+XG4gICAgICAgICAgICA8RGlhbG9nVGl0bGU+UGF1c2UgYWxsIGFjdGl2ZSBhZ2VudHM/PC9EaWFsb2dUaXRsZT5cbiAgICAgICAgICAgIDxEaWFsb2dEZXNjcmlwdGlvbiBpZD1cInBhdXNlLWNvbmZpcm0tZGVzY3JpcHRpb25cIj5cbiAgICAgICAgICAgICAgQWN0aXZlIGFnZW50cyB3aWxsIHN0b3AgdW50aWwgcmVzdW1lZC4gVGhpcyBhY3Rpb24gY2FuIGJlIHJldmVyc2VkIHdpdGggUmVzdW1lLlxuICAgICAgICAgICAgPC9EaWFsb2dEZXNjcmlwdGlvbj5cbiAgICAgICAgICA8L0RpYWxvZ0hlYWRlcj5cbiAgICAgICAgICA8RGlhbG9nRm9vdGVyIGNsYXNzTmFtZT1cImdhcC0yIHNtOmdhcC0wXCI+XG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4gY2xvc2UoXCJwYXVzZUNvbmZpcm1cIil9PlxuICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZGVzdHJ1Y3RpdmVcIiBzaXplPVwic21cIiBvbkNsaWNrPXtvbkNvbmZpcm1QYXVzZVNxdWFkfT5cbiAgICAgICAgICAgICAgUGF1c2UgU3F1YWRcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvRGlhbG9nRm9vdGVyPlxuICAgICAgICA8L0RpYWxvZ0NvbnRlbnQ+XG4gICAgICA8L0RpYWxvZz5cblxuICAgICAge21vZGFscy5jcmVhdGVUYXNrICYmIChcbiAgICAgICAgPENyZWF0ZVRhc2tNb2RhbFxuICAgICAgICAgIHByb2plY3RJZD17cHJvamVjdElkfVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IGNsb3NlKFwiY3JlYXRlVGFza1wiKX1cbiAgICAgICAgICBvbkNyZWF0ZWQ9eygpID0+IG9uVG9hc3QoXCJUYXNrIGNyZWF0ZWRcIil9XG4gICAgICAgIC8+XG4gICAgICApfVxuXG4gICAgICB7bW9kYWxzLmltcG9ydFByZCAmJiAoXG4gICAgICAgIDxJbXBvcnRQcmRNb2RhbFxuICAgICAgICAgIHByb2plY3RJZD17cHJvamVjdElkfVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IGNsb3NlKFwiaW1wb3J0UHJkXCIpfVxuICAgICAgICAgIG9uQ3JlYXRlZD17KGNvdW50KSA9PlxuICAgICAgICAgICAgb25Ub2FzdChcbiAgICAgICAgICAgICAgY291bnQgPiAwXG4gICAgICAgICAgICAgICAgPyBgJHtjb3VudH0gdGFza3MgY3JlYXRlZCBmcm9tIFBSRGBcbiAgICAgICAgICAgICAgICA6IFwiVGhpcyBQUkQgd2FzIGFscmVhZHkgaW1wb3J0ZWQ7IG5vIGR1cGxpY2F0ZSB0YXNrcyB3ZXJlIGNyZWF0ZWRcIlxuICAgICAgICAgICAgKVxuICAgICAgICAgIH1cbiAgICAgICAgLz5cbiAgICAgICl9XG5cbiAgICAgIHttb2RhbHMuc3RhcnRRY1J1biAmJiAoXG4gICAgICAgIDxTdGFydFFjUnVuTW9kYWxcbiAgICAgICAgICBwcm9qZWN0SWQ9e3Byb2plY3RJZH1cbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBjbG9zZShcInN0YXJ0UWNSdW5cIil9XG4gICAgICAgICAgb25TdGFydGVkPXsocnVuSWQpID0+IG9uVG9hc3QoYFFDIHJ1biAke3J1bklkfSBzdGFydGVkYCl9XG4gICAgICAgIC8+XG4gICAgICApfVxuXG4gICAgICB7bW9kYWxzLmFwcHJvdmFscyAmJiAoXG4gICAgICAgIDxBcHByb3ZhbHNNb2RhbCBwcm9qZWN0SWQ9e3Byb2plY3RJZH0gb25DbG9zZT17KCkgPT4gY2xvc2UoXCJhcHByb3ZhbHNcIil9IC8+XG4gICAgICApfVxuXG4gICAgICB7bW9kYWxzLnBvbGljeSAmJiA8UG9saWN5TW9kYWwgb25DbG9zZT17KCkgPT4gY2xvc2UoXCJwb2xpY3lcIil9IC8+fVxuXG4gICAgICB7bW9kYWxzLm9wZXJhdG9yQ29udHJvbHMgJiYgKFxuICAgICAgICA8T3BlcmF0b3JDb250cm9sc01vZGFsXG4gICAgICAgICAgcHJvamVjdElkPXtwcm9qZWN0SWR9XG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gY2xvc2UoXCJvcGVyYXRvckNvbnRyb2xzXCIpfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAge21vZGFscy5ub3RpZmljYXRpb25zICYmIChcbiAgICAgICAgPE5vdGlmaWNhdGlvbnNNb2RhbFxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IGNsb3NlKFwibm90aWZpY2F0aW9uc1wiKX1cbiAgICAgICAgICBvblNlbGVjdFRhc2s9e3NldFNlbGVjdGVkVGFza0lkfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAge21vZGFscy5zdGFuZHVwICYmIChcbiAgICAgICAgPFN0YW5kdXBNb2RhbCBwcm9qZWN0SWQ9e3Byb2plY3RJZH0gb25DbG9zZT17KCkgPT4gY2xvc2UoXCJzdGFuZHVwXCIpfSAvPlxuICAgICAgKX1cblxuICAgICAge21vZGFscy5hZ2VudERhc2hib2FyZCAmJiAoXG4gICAgICAgIDxBZ2VudERhc2hib2FyZFxuICAgICAgICAgIHByb2plY3RJZD17cHJvamVjdElkfVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IGNsb3NlKFwiYWdlbnREYXNoYm9hcmRcIil9XG4gICAgICAgICAgb25TZWxlY3RBZ2VudD17KGlkKSA9PiB7XG4gICAgICAgICAgICBzZXRTaWRlYmFyU2VsZWN0ZWRBZ2VudElkKGlkKTtcbiAgICAgICAgICAgIGNsb3NlKFwiYWdlbnREYXNoYm9hcmRcIik7XG4gICAgICAgICAgICBvcGVuKFwiYWdlbnRzRmx5b3V0XCIpO1xuICAgICAgICAgIH19XG4gICAgICAgIC8+XG4gICAgICApfVxuXG4gICAgICB7bW9kYWxzLmNvc3RBbmFseXRpY3MgJiYgKFxuICAgICAgICA8Q29zdEFuYWx5dGljcyBwcm9qZWN0SWQ9e3Byb2plY3RJZH0gb25DbG9zZT17KCkgPT4gY2xvc2UoXCJjb3N0QW5hbHl0aWNzXCIpfSAvPlxuICAgICAgKX1cblxuICAgICAge21vZGFscy5jcmVhdGVBZ2VudCAmJiAoXG4gICAgICAgIDxDcmVhdGVBZ2VudE1vZGFsXG4gICAgICAgICAgb3Blbj17bW9kYWxzLmNyZWF0ZUFnZW50fVxuICAgICAgICAgIHByb2plY3RJZD17cHJvamVjdElkfVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IGNsb3NlKFwiY3JlYXRlQWdlbnRcIil9XG4gICAgICAgICAgb25DcmVhdGU9e2hhbmRsZUNyZWF0ZUFnZW50U3VibWl0fVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAge21vZGFscy5hbGVydFJ1bGVzICYmIChcbiAgICAgICAgPEFsZXJ0UnVsZXNNb2RhbCBwcm9qZWN0SWQ9e3Byb2plY3RJZH0gb25DbG9zZT17KCkgPT4gY2xvc2UoXCJhbGVydFJ1bGVzXCIpfSAvPlxuICAgICAgKX1cblxuICAgICAge21vZGFscy5idWRnZXRCdXJuRG93biAmJiAoXG4gICAgICAgIDxEaWFsb2cgb3BlbiBvbk9wZW5DaGFuZ2U9eyhvcGVuKSA9PiAhb3BlbiAmJiBjbG9zZShcImJ1ZGdldEJ1cm5Eb3duXCIpfT5cbiAgICAgICAgICA8RGlhbG9nQ29udGVudCBjbGFzc05hbWU9XCJtYXgtdy1bODAwcHhdIG1heC1oLVs4NXZoXSBvdmVyZmxvdy1hdXRvXCI+XG4gICAgICAgICAgICA8RGlhbG9nSGVhZGVyPlxuICAgICAgICAgICAgICA8RGlhbG9nVGl0bGU+QnVkZ2V0IGJ1cm4tZG93bjwvRGlhbG9nVGl0bGU+XG4gICAgICAgICAgICA8L0RpYWxvZ0hlYWRlcj5cbiAgICAgICAgICAgIDxCdWRnZXRCdXJuRG93biBwcm9qZWN0SWQ9e3Byb2plY3RJZH0gLz5cbiAgICAgICAgICA8L0RpYWxvZ0NvbnRlbnQ+XG4gICAgICAgIDwvRGlhbG9nPlxuICAgICAgKX1cblxuICAgICAge21vZGFscy5hZHZhbmNlZEFuYWx5dGljcyAmJiAoXG4gICAgICAgIDxBbmFseXRpY3NEYXNoYm9hcmRcbiAgICAgICAgICBwcm9qZWN0SWQ9e3Byb2plY3RJZH1cbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBjbG9zZShcImFkdmFuY2VkQW5hbHl0aWNzXCIpfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAge21vZGFscy5oZWFsdGhEYXNoYm9hcmQgJiYgKFxuICAgICAgICA8SGVhbHRoRGFzaGJvYXJkIHByb2plY3RJZD17cHJvamVjdElkfSBvbkNsb3NlPXsoKSA9PiBjbG9zZShcImhlYWx0aERhc2hib2FyZFwiKX0gLz5cbiAgICAgICl9XG5cbiAgICAgIHttb2RhbHMubW9uaXRvcmluZ0Rhc2hib2FyZCAmJiAoXG4gICAgICAgIDxNb25pdG9yaW5nRGFzaGJvYXJkIG9uQ2xvc2U9eygpID0+IGNsb3NlKFwibW9uaXRvcmluZ0Rhc2hib2FyZFwiKX0gLz5cbiAgICAgICl9XG5cbiAgICAgIHttb2RhbHMuY29tbWFuZFBhbGV0dGUgJiYgKFxuICAgICAgICA8Q29tbWFuZFBhbGV0dGVcbiAgICAgICAgICBwcm9qZWN0SWQ9e3Byb2plY3RJZH1cbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBjbG9zZShcImNvbW1hbmRQYWxldHRlXCIpfVxuICAgICAgICAgIG9uU2VsZWN0VGFzaz17c2V0U2VsZWN0ZWRUYXNrSWR9XG4gICAgICAgICAgb25DcmVhdGVUYXNrPXsoKSA9PiB7XG4gICAgICAgICAgICBjbG9zZShcImNvbW1hbmRQYWxldHRlXCIpO1xuICAgICAgICAgICAgb3BlbihcImNyZWF0ZVRhc2tcIik7XG4gICAgICAgICAgfX1cbiAgICAgICAgICBvbk9wZW5BcHByb3ZhbHM9eygpID0+IHtcbiAgICAgICAgICAgIGNsb3NlKFwiY29tbWFuZFBhbGV0dGVcIik7XG4gICAgICAgICAgICBvcGVuKFwiYXBwcm92YWxzXCIpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgb25PcGVuQWdlbnRzPXsoKSA9PiB7XG4gICAgICAgICAgICBjbG9zZShcImNvbW1hbmRQYWxldHRlXCIpO1xuICAgICAgICAgICAgc2V0U2lkZWJhclNlbGVjdGVkQWdlbnRJZChudWxsKTtcbiAgICAgICAgICAgIG9wZW4oXCJhZ2VudHNGbHlvdXRcIik7XG4gICAgICAgICAgfX1cbiAgICAgICAgICBvbk9wZW5Db250cm9scz17KCkgPT4ge1xuICAgICAgICAgICAgY2xvc2UoXCJjb21tYW5kUGFsZXR0ZVwiKTtcbiAgICAgICAgICAgIG9wZW4oXCJvcGVyYXRvckNvbnRyb2xzXCIpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgb25PcGVuQ29zdEFuYWx5dGljcz17KCkgPT4ge1xuICAgICAgICAgICAgY2xvc2UoXCJjb21tYW5kUGFsZXR0ZVwiKTtcbiAgICAgICAgICAgIG9wZW4oXCJjb3N0QW5hbHl0aWNzXCIpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgb25PcGVuQ3JlYXRlQWdlbnQ9eygpID0+IHtcbiAgICAgICAgICAgIGNsb3NlKFwiY29tbWFuZFBhbGV0dGVcIik7XG4gICAgICAgICAgICBvcGVuKFwiY3JlYXRlQWdlbnRcIik7XG4gICAgICAgICAgfX1cbiAgICAgICAgICBvbk5hdmlnYXRlVG9HYXRld2F5PXtvbk5hdmlnYXRlVG9HYXRld2F5fVxuICAgICAgICAgIG9uTmF2aWdhdGVWaWV3PXsodmlldykgPT4ge1xuICAgICAgICAgICAgY2xvc2UoXCJjb21tYW5kUGFsZXR0ZVwiKTtcbiAgICAgICAgICAgIG9uTmF2aWdhdGUodmlldyk7XG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgICl9XG5cbiAgICAgIHttb2RhbHMua2V5Ym9hcmRIZWxwICYmIChcbiAgICAgICAgPEtleWJvYXJkU2hvcnRjdXRzSGVscCBvbkNsb3NlPXsoKSA9PiBjbG9zZShcImtleWJvYXJkSGVscFwiKX0gLz5cbiAgICAgICl9XG5cbiAgICAgIHttb2RhbHMuYWN0aXZpdHlGZWVkICYmIChcbiAgICAgICAgPEFjdGl2aXR5RmVlZE1vZGFsIHByb2plY3RJZD17cHJvamVjdElkfSBvbkNsb3NlPXsoKSA9PiBjbG9zZShcImFjdGl2aXR5RmVlZFwiKX0gLz5cbiAgICAgICl9XG5cbiAgICAgIHttb2RhbHMubWlzc2lvbk1vZGFsICYmIChcbiAgICAgICAgPE1pc3Npb25Nb2RhbCBwcm9qZWN0SWQ9e3Byb2plY3RJZH0gb25DbG9zZT17KCkgPT4gY2xvc2UoXCJtaXNzaW9uTW9kYWxcIil9IC8+XG4gICAgICApfVxuXG4gICAgICB7bW9kYWxzLnN1Z2dlc3Rpb25zRHJhd2VyICYmIChcbiAgICAgICAgPE1pc3Npb25TdWdnZXN0aW9uc0RyYXdlclxuICAgICAgICAgIHByb2plY3RJZD17cHJvamVjdElkfVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IGNsb3NlKFwic3VnZ2VzdGlvbnNEcmF3ZXJcIil9XG4gICAgICAgIC8+XG4gICAgICApfVxuXG4gICAgICB7bW9kYWxzLmFnZW50c0ZseW91dCAmJiAoXG4gICAgICAgIDxBZ2VudHNGbHlvdXRcbiAgICAgICAgICBwcm9qZWN0SWQ9e3Byb2plY3RJZH1cbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBjbG9zZShcImFnZW50c0ZseW91dFwiKX1cbiAgICAgICAgICBvbk9wZW5BcHByb3ZhbHM9eygpID0+IHtcbiAgICAgICAgICAgIGNsb3NlKFwiYWdlbnRzRmx5b3V0XCIpO1xuICAgICAgICAgICAgb3BlbihcImFwcHJvdmFsc1wiKTtcbiAgICAgICAgICB9fVxuICAgICAgICAgIG9uT3BlblBvbGljeT17KCkgPT4ge1xuICAgICAgICAgICAgY2xvc2UoXCJhZ2VudHNGbHlvdXRcIik7XG4gICAgICAgICAgICBvcGVuKFwicG9saWN5XCIpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgb25PcGVuT3BlcmF0b3JDb250cm9scz17KCkgPT4ge1xuICAgICAgICAgICAgY2xvc2UoXCJhZ2VudHNGbHlvdXRcIik7XG4gICAgICAgICAgICBvcGVuKFwib3BlcmF0b3JDb250cm9sc1wiKTtcbiAgICAgICAgICB9fVxuICAgICAgICAgIG9uT3Blbk5vdGlmaWNhdGlvbnM9eygpID0+IHtcbiAgICAgICAgICAgIGNsb3NlKFwiYWdlbnRzRmx5b3V0XCIpO1xuICAgICAgICAgICAgb3BlbihcIm5vdGlmaWNhdGlvbnNcIik7XG4gICAgICAgICAgfX1cbiAgICAgICAgICBvbk9wZW5TdGFuZHVwPXsoKSA9PiB7XG4gICAgICAgICAgICBjbG9zZShcImFnZW50c0ZseW91dFwiKTtcbiAgICAgICAgICAgIG9wZW4oXCJzdGFuZHVwXCIpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgb25QYXVzZVNxdWFkPXsoKSA9PiBvcGVuKFwicGF1c2VDb25maXJtXCIpfVxuICAgICAgICAgIG9uUmVzdW1lU3F1YWQ9e29uUmVzdW1lU3F1YWR9XG4gICAgICAgICAgb25PcGVuT3JnPXsoYWdlbnRJZCkgPT4ge1xuICAgICAgICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibWMub3JnLmZvY3VzQWdlbnRJZFwiLCBhZ2VudElkKTtcbiAgICAgICAgICAgIGNsb3NlKFwiYWdlbnRzRmx5b3V0XCIpO1xuICAgICAgICAgICAgb25OYXZpZ2F0ZShcIm9yZ1wiKTtcbiAgICAgICAgICB9fVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAge3NpZGViYXJTZWxlY3RlZEFnZW50SWQgJiYgKFxuICAgICAgICA8QWdlbnREZXRhaWxGbHlvdXRcbiAgICAgICAgICBhZ2VudElkPXtzaWRlYmFyU2VsZWN0ZWRBZ2VudElkfVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNpZGViYXJTZWxlY3RlZEFnZW50SWQobnVsbCl9XG4gICAgICAgICAgb25FZGl0PXsoYWdlbnRJZCkgPT4ge1xuICAgICAgICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibWMub3JnLmZvY3VzQWdlbnRJZFwiLCBhZ2VudElkKTtcbiAgICAgICAgICAgIHNldFNpZGViYXJTZWxlY3RlZEFnZW50SWQobnVsbCk7XG4gICAgICAgICAgICBvbk5hdmlnYXRlKFwib3JnXCIpO1xuICAgICAgICAgIH19XG4gICAgICAgIC8+XG4gICAgICApfVxuICAgIDwvPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvTW9kYWxMYXllci50c3gifQ==