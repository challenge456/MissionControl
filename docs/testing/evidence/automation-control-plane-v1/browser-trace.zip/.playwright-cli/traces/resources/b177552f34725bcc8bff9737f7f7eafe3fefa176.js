import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PriorityChip.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PriorityChip.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { cn } from "/src/lib/utils.ts";
import { StatusBadge } from "/src/components/factory/badges.tsx";
const PRIORITY_CONFIG = {
  1: { label: "Critical", tone: "error" },
  2: { label: "High", tone: "warning" },
  3: { label: "Normal", tone: "info" },
  4: { label: "Low", tone: "neutral" }
};
export function PriorityChip({ priority, size = "sm", className }) {
  const config = PRIORITY_CONFIG[priority] || PRIORITY_CONFIG[3];
  const sizeClass = size === "md" ? "text-[12.5px]" : void 0;
  return /* @__PURE__ */ jsxDEV(StatusBadge, { tone: config.tone, className: cn(sizeClass, className), children: config.label }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PriorityChip.tsx",
    lineNumber: 41,
    columnNumber: 5
  }, this);
}
_c = PriorityChip;
var _c;
$RefreshReg$(_c, "PriorityChip");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PriorityChip.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PriorityChip.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJJOzs7Ozs7Ozs7Ozs7Ozs7O0FBckJKLFNBQVNBLFVBQVU7QUFDbkIsU0FBU0MsbUJBQTBDO0FBRW5ELE1BQU1DLGtCQUFxRjtBQUFBLEVBQ3pGLEdBQUcsRUFBRUMsT0FBTyxZQUFZQyxNQUFNLFFBQVE7QUFBQSxFQUN0QyxHQUFHLEVBQUVELE9BQU8sUUFBUUMsTUFBTSxVQUFVO0FBQUEsRUFDcEMsR0FBRyxFQUFFRCxPQUFPLFVBQVVDLE1BQU0sT0FBTztBQUFBLEVBQ25DLEdBQUcsRUFBRUQsT0FBTyxPQUFPQyxNQUFNLFVBQVU7QUFDckM7QUFRTyxnQkFBU0MsYUFBYSxFQUFFQyxVQUFVQyxPQUFPLE1BQU1DLFVBQTZCLEdBQWdCO0FBQ2pHLFFBQU1DLFNBQVNQLGdCQUFnQkksUUFBUSxLQUFLSixnQkFBZ0IsQ0FBQztBQUM3RCxRQUFNUSxZQUFZSCxTQUFTLE9BQU8sa0JBQWtCSTtBQUVwRCxTQUNFLHVCQUFDLGVBQVksTUFBTUYsT0FBT0wsTUFBTSxXQUFXSixHQUFHVSxXQUFXRixTQUFTLEdBQy9EQyxpQkFBT04sU0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDUyxLQVRlUDtBQUFZLElBQUFPO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbImNuIiwiU3RhdHVzQmFkZ2UiLCJQUklPUklUWV9DT05GSUciLCJsYWJlbCIsInRvbmUiLCJQcmlvcml0eUNoaXAiLCJwcmlvcml0eSIsInNpemUiLCJjbGFzc05hbWUiLCJjb25maWciLCJzaXplQ2xhc3MiLCJ1bmRlZmluZWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcmlvcml0eUNoaXAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5pbXBvcnQgeyBTdGF0dXNCYWRnZSwgdHlwZSBTdGF0dXNCYWRnZVByb3BzIH0gZnJvbSBcIkAvY29tcG9uZW50cy9mYWN0b3J5L2JhZGdlc1wiO1xuXG5jb25zdCBQUklPUklUWV9DT05GSUc6IFJlY29yZDxudW1iZXIsIHsgbGFiZWw6IHN0cmluZzsgdG9uZTogU3RhdHVzQmFkZ2VQcm9wc1tcInRvbmVcIl0gfT4gPSB7XG4gIDE6IHsgbGFiZWw6IFwiQ3JpdGljYWxcIiwgdG9uZTogXCJlcnJvclwiIH0sXG4gIDI6IHsgbGFiZWw6IFwiSGlnaFwiLCB0b25lOiBcIndhcm5pbmdcIiB9LFxuICAzOiB7IGxhYmVsOiBcIk5vcm1hbFwiLCB0b25lOiBcImluZm9cIiB9LFxuICA0OiB7IGxhYmVsOiBcIkxvd1wiLCB0b25lOiBcIm5ldXRyYWxcIiB9LFxufTtcblxuaW50ZXJmYWNlIFByaW9yaXR5Q2hpcFByb3BzIHtcbiAgcHJpb3JpdHk6IG51bWJlcjtcbiAgc2l6ZT86IFwic21cIiB8IFwibWRcIjtcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gUHJpb3JpdHlDaGlwKHsgcHJpb3JpdHksIHNpemUgPSBcInNtXCIsIGNsYXNzTmFtZSB9OiBQcmlvcml0eUNoaXBQcm9wcyk6IEpTWC5FbGVtZW50IHtcbiAgY29uc3QgY29uZmlnID0gUFJJT1JJVFlfQ09ORklHW3ByaW9yaXR5XSB8fCBQUklPUklUWV9DT05GSUdbM107XG4gIGNvbnN0IHNpemVDbGFzcyA9IHNpemUgPT09IFwibWRcIiA/IFwidGV4dC1bMTIuNXB4XVwiIDogdW5kZWZpbmVkO1xuXG4gIHJldHVybiAoXG4gICAgPFN0YXR1c0JhZGdlIHRvbmU9e2NvbmZpZy50b25lfSBjbGFzc05hbWU9e2NuKHNpemVDbGFzcywgY2xhc3NOYW1lKX0+XG4gICAgICB7Y29uZmlnLmxhYmVsfVxuICAgIDwvU3RhdHVzQmFkZ2U+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9jb21wb25lbnRzL1ByaW9yaXR5Q2hpcC50c3gifQ==