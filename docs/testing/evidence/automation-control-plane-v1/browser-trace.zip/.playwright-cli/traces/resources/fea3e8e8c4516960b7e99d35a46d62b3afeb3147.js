import {
  clsx,
  clsx_default
} from "/node_modules/.vite/deps/chunk-XNYI3VHL.js?v=738cb978";
import "/node_modules/.vite/deps/chunk-G3PMV62Z.js?v=738cb978";
export {
  clsx,
  clsx_default as default
};
//# sourceMappingURL=clsx.js.map
