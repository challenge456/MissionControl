import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/operator/ChatSessionBar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { cn } from "/src/lib/utils.ts";
const TELE_KEY = "mc.chat.telemetry";
export function ChatSessionBar({
  sessions,
  activeSessionId,
  onNewChat,
  onSelectSession,
  onViewAllHistory,
  modelLabel
}) {
  _s();
  const [menuOpen, setMenuOpen] = useState(false);
  const [showTelemetry, setShowTelemetry] = useState(() => {
    if (typeof window === "undefined") return true;
    return localStorage.getItem(TELE_KEY) !== "0";
  });
  useEffect(() => {
    document.body.classList.toggle("schematic-no-tele", !showTelemetry);
    localStorage.setItem(TELE_KEY, showTelemetry ? "1" : "0");
  }, [showTelemetry]);
  const toggleTelemetry = useCallback(() => {
    setShowTelemetry((v) => !v);
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2 px-2 pb-2 pt-2", children: [
    /* @__PURE__ */ jsxDEV("button", { type: "button", className: "schematic-sessbtn", onClick: onNewChat, children: "+ New chat" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
      lineNumber: 67,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "schematic-sessbtn",
          onClick: () => setMenuOpen((o) => !o),
          "aria-expanded": menuOpen,
          children: "History ▾"
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
          lineNumber: 71,
          columnNumber: 9
        },
        this
      ),
      menuOpen ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "fixed inset-0 z-20",
            onClick: () => setMenuOpen(false),
            "aria-hidden": true
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
            lineNumber: 81,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "schematic-sessmenu z-30", children: [
          onViewAllHistory ? /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: cn(
                "schematic-sessitem w-full text-left",
                activeSessionId === "__all__" && "schematic-sessitem-active"
              ),
              onClick: () => {
                onViewAllHistory();
                setMenuOpen(false);
              },
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("b", { children: "All messages" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
                    lineNumber: 100,
                    columnNumber: 21
                  }, this),
                  " — full timeline"
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
                  lineNumber: 99,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-ink-muted", children: "every thread together, newest last" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
                  lineNumber: 102,
                  columnNumber: 19
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
              lineNumber: 88,
              columnNumber: 13
            },
            this
          ) : null,
          sessions.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "schematic-sessitem text-ink-muted", children: "No past conversations yet" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
            lineNumber: 108,
            columnNumber: 13
          }, this) : sessions.map(
            (s) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: cn(
                  "schematic-sessitem w-full text-left",
                  s.id === activeSessionId && "schematic-sessitem-active"
                ),
                onClick: () => {
                  onSelectSession(s.id);
                  setMenuOpen(false);
                },
                children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    s.title,
                    s.channel ? /* @__PURE__ */ jsxDEV("span", { className: "schematic-gwtag ml-1", children: s.channel }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
                      lineNumber: 126,
                      columnNumber: 17
                    }, this) : null
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
                    lineNumber: 123,
                    columnNumber: 21
                  }, this),
                  s.messageCount != null ? /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-ink-muted", children: [
                    s.messageCount,
                    " message",
                    s.messageCount === 1 ? "" : "s"
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
                    lineNumber: 130,
                    columnNumber: 15
                  }, this) : null
                ]
              },
              s.id,
              true,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
                lineNumber: 111,
                columnNumber: 13
              },
              this
            )
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
          lineNumber: 86,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
        lineNumber: 80,
        columnNumber: 9
      }, this) : null
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
      lineNumber: 70,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        className: cn("schematic-sessbtn", showTelemetry && "schematic-sessbtn-on"),
        onClick: toggleTelemetry,
        title: "Show/hide per-turn stats",
        children: "stats"
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
        lineNumber: 141,
        columnNumber: 7
      },
      this
    ),
    modelLabel ? /* @__PURE__ */ jsxDEV("span", { className: "schematic-modelchip ml-auto truncate", title: "Active model", children: modelLabel }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
      lineNumber: 150,
      columnNumber: 7
    }, this) : null
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx",
    lineNumber: 66,
    columnNumber: 5
  }, this);
}
_s(ChatSessionBar, "7mZu2QcGSqV4pkKHDRfvaTjx10Y=");
_c = ChatSessionBar;
var _c;
$RefreshReg$(_c, "ChatSessionBar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/ChatSessionBar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0NNLFNBYUksVUFiSjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEvQ04sU0FBU0EsYUFBYUMsV0FBV0MsZ0JBQWdCO0FBQ2pELFNBQVNDLFVBQVU7QUFFbkIsTUFBTUMsV0FBVztBQW1CVixnQkFBU0MsZUFBZTtBQUFBLEVBQzdCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNtQixHQUFnQjtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJWixTQUFTLEtBQUs7QUFDOUMsUUFBTSxDQUFDYSxlQUFlQyxnQkFBZ0IsSUFBSWQsU0FBUyxNQUFNO0FBQ3ZELFFBQUksT0FBT2UsV0FBVyxZQUFhLFFBQU87QUFDMUMsV0FBT0MsYUFBYUMsUUFBUWYsUUFBUSxNQUFNO0FBQUEsRUFDNUMsQ0FBQztBQUVESCxZQUFVLE1BQU07QUFDZG1CLGFBQVNDLEtBQUtDLFVBQVVDLE9BQU8scUJBQXFCLENBQUNSLGFBQWE7QUFDbEVHLGlCQUFhTSxRQUFRcEIsVUFBVVcsZ0JBQWdCLE1BQU0sR0FBRztBQUFBLEVBQzFELEdBQUcsQ0FBQ0EsYUFBYSxDQUFDO0FBRWxCLFFBQU1VLGtCQUFrQnpCLFlBQVksTUFBTTtBQUN4Q2dCLHFCQUFpQixDQUFDVSxNQUFNLENBQUNBLENBQUM7QUFBQSxFQUM1QixHQUFHLEVBQUU7QUFFTCxTQUNFLHVCQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLDJCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUscUJBQW9CLFNBQVNsQixXQUFVLDBCQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFdBQVU7QUFBQSxVQUNWLFNBQVMsTUFBTU0sWUFBWSxDQUFDYSxNQUFNLENBQUNBLENBQUM7QUFBQSxVQUNwQyxpQkFBZWQ7QUFBQUEsVUFBUztBQUFBO0FBQUEsUUFKMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxNQUNDQSxXQUNDLG1DQUNFO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLFNBQVMsTUFBTUMsWUFBWSxLQUFLO0FBQUEsWUFDaEMsZUFBVztBQUFBO0FBQUEsVUFIYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHYTtBQUFBLFFBRWIsdUJBQUMsU0FBSSxXQUFVLDJCQUNaSjtBQUFBQSw2QkFDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBV1A7QUFBQUEsZ0JBQ1Q7QUFBQSxnQkFDQUksb0JBQW9CLGFBQWE7QUFBQSxjQUNuQztBQUFBLGNBQ0EsU0FBUyxNQUFNO0FBQ2JHLGlDQUFpQjtBQUNqQkksNEJBQVksS0FBSztBQUFBLGNBQ25CO0FBQUEsY0FFQTtBQUFBLHVDQUFDLFNBQ0M7QUFBQSx5Q0FBQyxPQUFFLDRCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWU7QUFBQSxrQkFBSTtBQUFBLHFCQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDhCQUE0QixrREFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBO0FBQUE7QUFBQSxZQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFpQkEsSUFDRTtBQUFBLFVBQ0hSLFNBQVNzQixXQUFXLElBQ25CLHVCQUFDLFNBQUksV0FBVSxxQ0FBb0MseUNBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRFLElBRTVFdEIsU0FBU3VCO0FBQUFBLFlBQUksQ0FBQ0MsTUFDWjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUVDLE1BQUs7QUFBQSxnQkFDTCxXQUFXM0I7QUFBQUEsa0JBQ1Q7QUFBQSxrQkFDQTJCLEVBQUVDLE9BQU94QixtQkFBbUI7QUFBQSxnQkFDOUI7QUFBQSxnQkFDQSxTQUFTLE1BQU07QUFDYkUsa0NBQWdCcUIsRUFBRUMsRUFBRTtBQUNwQmpCLDhCQUFZLEtBQUs7QUFBQSxnQkFDbkI7QUFBQSxnQkFFQTtBQUFBLHlDQUFDLFNBQ0VnQjtBQUFBQSxzQkFBRUU7QUFBQUEsb0JBQ0ZGLEVBQUVHLFVBQ0QsdUJBQUMsVUFBSyxXQUFVLHdCQUF3QkgsWUFBRUcsV0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0QsSUFDaEQ7QUFBQSx1QkFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBQ0NILEVBQUVJLGdCQUFnQixPQUNqQix1QkFBQyxTQUFJLFdBQVUsOEJBQ1pKO0FBQUFBLHNCQUFFSTtBQUFBQSxvQkFBYTtBQUFBLG9CQUFTSixFQUFFSSxpQkFBaUIsSUFBSSxLQUFLO0FBQUEsdUJBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUEsSUFDRTtBQUFBO0FBQUE7QUFBQSxjQXJCQ0osRUFBRUM7QUFBQUEsY0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBdUJBO0FBQUEsVUFDRDtBQUFBLGFBakRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtREE7QUFBQSxXQXpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMERBLElBQ0U7QUFBQSxTQXJFTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0VBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsV0FBVzVCLEdBQUcscUJBQXFCWSxpQkFBaUIsc0JBQXNCO0FBQUEsUUFDMUUsU0FBU1U7QUFBQUEsUUFDVCxPQUFNO0FBQUEsUUFBMEI7QUFBQTtBQUFBLE1BSmxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9BO0FBQUEsSUFDQ2QsYUFDQyx1QkFBQyxVQUFLLFdBQVUsd0NBQXVDLE9BQU0sZ0JBQzFEQSx3QkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsSUFDRTtBQUFBLE9BdkZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3RkE7QUFFSjtBQUFDQyxHQWxIZVAsZ0JBQWM7QUFBQSxLQUFkQTtBQUFjLElBQUE4QjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiY24iLCJURUxFX0tFWSIsIkNoYXRTZXNzaW9uQmFyIiwic2Vzc2lvbnMiLCJhY3RpdmVTZXNzaW9uSWQiLCJvbk5ld0NoYXQiLCJvblNlbGVjdFNlc3Npb24iLCJvblZpZXdBbGxIaXN0b3J5IiwibW9kZWxMYWJlbCIsIl9zIiwibWVudU9wZW4iLCJzZXRNZW51T3BlbiIsInNob3dUZWxlbWV0cnkiLCJzZXRTaG93VGVsZW1ldHJ5Iiwid2luZG93IiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsImRvY3VtZW50IiwiYm9keSIsImNsYXNzTGlzdCIsInRvZ2dsZSIsInNldEl0ZW0iLCJ0b2dnbGVUZWxlbWV0cnkiLCJ2IiwibyIsImxlbmd0aCIsIm1hcCIsInMiLCJpZCIsInRpdGxlIiwiY2hhbm5lbCIsIm1lc3NhZ2VDb3VudCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNoYXRTZXNzaW9uQmFyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcblxuY29uc3QgVEVMRV9LRVkgPSBcIm1jLmNoYXQudGVsZW1ldHJ5XCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ2hhdFNlc3Npb24ge1xuICBpZDogc3RyaW5nO1xuICB0aXRsZTogc3RyaW5nO1xuICBjaGFubmVsPzogc3RyaW5nO1xuICBtZXNzYWdlQ291bnQ/OiBudW1iZXI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ2hhdFNlc3Npb25CYXJQcm9wcyB7XG4gIHNlc3Npb25zOiBDaGF0U2Vzc2lvbltdO1xuICBhY3RpdmVTZXNzaW9uSWQ6IHN0cmluZztcbiAgb25OZXdDaGF0OiAoKSA9PiB2b2lkO1xuICBvblNlbGVjdFNlc3Npb246IChpZDogc3RyaW5nKSA9PiB2b2lkO1xuICBvblZpZXdBbGxIaXN0b3J5PzogKCkgPT4gdm9pZDtcbiAgbW9kZWxMYWJlbD86IHN0cmluZztcbn1cblxuLyoqIFNlc3Npb24gcGlja2VyICsgc3RhdHMgdG9nZ2xlICh3YWt1IGRvY2sgc2Vzc2hlYWQpLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIENoYXRTZXNzaW9uQmFyKHtcbiAgc2Vzc2lvbnMsXG4gIGFjdGl2ZVNlc3Npb25JZCxcbiAgb25OZXdDaGF0LFxuICBvblNlbGVjdFNlc3Npb24sXG4gIG9uVmlld0FsbEhpc3RvcnksXG4gIG1vZGVsTGFiZWwsXG59OiBDaGF0U2Vzc2lvbkJhclByb3BzKTogSlNYLkVsZW1lbnQge1xuICBjb25zdCBbbWVudU9wZW4sIHNldE1lbnVPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Nob3dUZWxlbWV0cnksIHNldFNob3dUZWxlbWV0cnldID0gdXNlU3RhdGUoKCkgPT4ge1xuICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gdHJ1ZTtcbiAgICByZXR1cm4gbG9jYWxTdG9yYWdlLmdldEl0ZW0oVEVMRV9LRVkpICE9PSBcIjBcIjtcbiAgfSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC50b2dnbGUoXCJzY2hlbWF0aWMtbm8tdGVsZVwiLCAhc2hvd1RlbGVtZXRyeSk7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oVEVMRV9LRVksIHNob3dUZWxlbWV0cnkgPyBcIjFcIiA6IFwiMFwiKTtcbiAgfSwgW3Nob3dUZWxlbWV0cnldKTtcblxuICBjb25zdCB0b2dnbGVUZWxlbWV0cnkgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgc2V0U2hvd1RlbGVtZXRyeSgodikgPT4gIXYpO1xuICB9LCBbXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMiBweC0yIHBiLTIgcHQtMlwiPlxuICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwic2NoZW1hdGljLXNlc3NidG5cIiBvbkNsaWNrPXtvbk5ld0NoYXR9PlxuICAgICAgICArIE5ldyBjaGF0XG4gICAgICA8L2J1dHRvbj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIGNsYXNzTmFtZT1cInNjaGVtYXRpYy1zZXNzYnRuXCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNZW51T3BlbigobykgPT4gIW8pfVxuICAgICAgICAgIGFyaWEtZXhwYW5kZWQ9e21lbnVPcGVufVxuICAgICAgICA+XG4gICAgICAgICAgSGlzdG9yeSDilr5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIHttZW51T3BlbiA/IChcbiAgICAgICAgICA8PlxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotMjBcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNZW51T3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgIGFyaWEtaGlkZGVuXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzY2hlbWF0aWMtc2Vzc21lbnUgei0zMFwiPlxuICAgICAgICAgICAgICB7b25WaWV3QWxsSGlzdG9yeSA/IChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgIFwic2NoZW1hdGljLXNlc3NpdGVtIHctZnVsbCB0ZXh0LWxlZnRcIixcbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlU2Vzc2lvbklkID09PSBcIl9fYWxsX19cIiAmJiBcInNjaGVtYXRpYy1zZXNzaXRlbS1hY3RpdmVcIlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgb25WaWV3QWxsSGlzdG9yeSgpO1xuICAgICAgICAgICAgICAgICAgICBzZXRNZW51T3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxiPkFsbCBtZXNzYWdlczwvYj4g4oCUIGZ1bGwgdGltZWxpbmVcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgICBldmVyeSB0aHJlYWQgdG9nZXRoZXIsIG5ld2VzdCBsYXN0XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgICAgIHtzZXNzaW9ucy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzY2hlbWF0aWMtc2Vzc2l0ZW0gdGV4dC1pbmstbXV0ZWRcIj5ObyBwYXN0IGNvbnZlcnNhdGlvbnMgeWV0PC9kaXY+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgc2Vzc2lvbnMubWFwKChzKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIGtleT17cy5pZH1cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgXCJzY2hlbWF0aWMtc2Vzc2l0ZW0gdy1mdWxsIHRleHQtbGVmdFwiLFxuICAgICAgICAgICAgICAgICAgICAgIHMuaWQgPT09IGFjdGl2ZVNlc3Npb25JZCAmJiBcInNjaGVtYXRpYy1zZXNzaXRlbS1hY3RpdmVcIlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgb25TZWxlY3RTZXNzaW9uKHMuaWQpO1xuICAgICAgICAgICAgICAgICAgICAgIHNldE1lbnVPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICB7cy50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgICB7cy5jaGFubmVsID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2NoZW1hdGljLWd3dGFnIG1sLTFcIj57cy5jaGFubmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHtzLm1lc3NhZ2VDb3VudCAhPSBudWxsID8gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1pbmstbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtzLm1lc3NhZ2VDb3VudH0gbWVzc2FnZXtzLm1lc3NhZ2VDb3VudCA9PT0gMSA/IFwiXCIgOiBcInNcIn1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC8+XG4gICAgICAgICkgOiBudWxsfVxuICAgICAgPC9kaXY+XG4gICAgICA8YnV0dG9uXG4gICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICBjbGFzc05hbWU9e2NuKFwic2NoZW1hdGljLXNlc3NidG5cIiwgc2hvd1RlbGVtZXRyeSAmJiBcInNjaGVtYXRpYy1zZXNzYnRuLW9uXCIpfVxuICAgICAgICBvbkNsaWNrPXt0b2dnbGVUZWxlbWV0cnl9XG4gICAgICAgIHRpdGxlPVwiU2hvdy9oaWRlIHBlci10dXJuIHN0YXRzXCJcbiAgICAgID5cbiAgICAgICAgc3RhdHNcbiAgICAgIDwvYnV0dG9uPlxuICAgICAge21vZGVsTGFiZWwgPyAoXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNjaGVtYXRpYy1tb2RlbGNoaXAgbWwtYXV0byB0cnVuY2F0ZVwiIHRpdGxlPVwiQWN0aXZlIG1vZGVsXCI+XG4gICAgICAgICAge21vZGVsTGFiZWx9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICkgOiBudWxsfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvY29tcG9uZW50cy9vcGVyYXRvci9DaGF0U2Vzc2lvbkJhci50c3gifQ==