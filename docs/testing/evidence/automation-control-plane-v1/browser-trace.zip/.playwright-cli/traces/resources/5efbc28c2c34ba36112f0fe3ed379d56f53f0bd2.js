import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/StartQcRunModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { Button } from "/src/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "/src/components/ui/dialog.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { Input } from "/src/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
import { Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
const ENVIRONMENTS = [
  { value: "local", label: "Local" },
  { value: "dev", label: "Dev" },
  { value: "staging", label: "Staging" },
  { value: "pilot", label: "Pilot" },
  { value: "production", label: "Production" }
];
const CHECK_TYPES = [
  { value: "FULL_SUITE", label: "Full Suite" },
  { value: "CODE_REVIEW", label: "Code Review" },
  { value: "AGENT_OUTPUT", label: "Agent Output" },
  { value: "SECURITY", label: "Security" },
  { value: "COVERAGE", label: "Coverage" }
];
const SCOPE_TYPES = [
  { value: "FULL_REPO", label: "Full Repo" },
  { value: "BRANCH_DIFF", label: "Branch Diff" },
  { value: "DIRECTORY", label: "Directory" },
  { value: "FILE_LIST", label: "File List" }
];
export function StartQcRunModal({
  projectId,
  onClose,
  onStarted
}) {
  _s();
  const [environment, setEnvironment] = useState("dev");
  const [checkType, setCheckType] = useState("FULL_SUITE");
  const [scopeType, setScopeType] = useState("FULL_REPO");
  const [repoUrl, setRepoUrl] = useState("https://github.com/org/repo");
  const [branch, setBranch] = useState("main");
  const [commitSha, setCommitSha] = useState("");
  const [scopeSpec, setScopeSpec] = useState("");
  const [rulesetId, setRulesetId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const startRun = useMutation(api.qcRuns.start);
  const rulesets = useQuery(api.qcRulesets.list, { projectId: projectId ?? void 0 });
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      let spec = void 0;
      if (scopeType === "FILE_LIST") {
        spec = scopeSpec.trim() ? scopeSpec.split(/\s*,\s*/).map((s) => s.trim()).filter(Boolean) : [];
        if (Array.isArray(spec) && spec.length === 0) {
          setError("File list cannot be empty");
          setLoading(false);
          return;
        }
      } else if (scopeType === "DIRECTORY") {
        spec = scopeSpec.trim() || void 0;
        if (!spec) {
          setError("Directory path is required");
          setLoading(false);
          return;
        }
      } else if (scopeType === "BRANCH_DIFF") {
        const [base, head] = scopeSpec.split(/\s+/).map((s) => s.trim());
        spec = base && head ? { base, head } : void 0;
        if (!spec || typeof spec !== "object" || !("base" in spec)) {
          setError("Enter base and head branches (e.g. main feature-branch)");
          setLoading(false);
          return;
        }
      }
      const idempotencyKey = `qc-start-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      const result = await startRun({
        projectId: projectId ?? void 0,
        repoUrl,
        commitSha: commitSha.trim() || void 0,
        branch: branch.trim() || void 0,
        scopeType,
        scopeSpec: spec,
        rulesetId: rulesetId ? rulesetId : void 0,
        initiatorType: "HUMAN",
        idempotencyKey,
        environment,
        checkType
      });
      onStarted?.(result.runId);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to start QC run");
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(Dialog, { open: true, onOpenChange: (open) => !open && onClose(), children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "max-w-lg", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Start QC Run" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
        lineNumber: 153,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Configure environment, check type, scope, and ruleset for a new quality control run." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
        lineNumber: 154,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
      lineNumber: 152,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Environment" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
          lineNumber: 160,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Select, { value: environment, onValueChange: setEnvironment, children: [
          /* @__PURE__ */ jsxDEV(SelectTrigger, { children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 163,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 162,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(SelectContent, { children: ENVIRONMENTS.map(
            (e) => /* @__PURE__ */ jsxDEV(SelectItem, { value: e.value, children: e.label }, e.value, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
              lineNumber: 167,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 165,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
          lineNumber: 161,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
        lineNumber: 159,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Check type" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
          lineNumber: 175,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Select, { value: checkType, onValueChange: setCheckType, children: [
          /* @__PURE__ */ jsxDEV(SelectTrigger, { children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 178,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 177,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(SelectContent, { children: CHECK_TYPES.map(
            (c) => /* @__PURE__ */ jsxDEV(SelectItem, { value: c.value, children: c.label }, c.value, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
              lineNumber: 182,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 180,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
          lineNumber: 176,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
        lineNumber: 174,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Repo URL" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
          lineNumber: 190,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            value: repoUrl,
            onChange: (e) => setRepoUrl(e.target.value),
            placeholder: "https://github.com/org/repo",
            required: true
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 191,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
        lineNumber: 189,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Branch" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 200,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: branch, onChange: (e) => setBranch(e.target.value), placeholder: "main" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 201,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
          lineNumber: 199,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Commit SHA (optional)" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 204,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: commitSha, onChange: (e) => setCommitSha(e.target.value), placeholder: "abc123" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 205,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
          lineNumber: 203,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
        lineNumber: 198,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Scope" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
          lineNumber: 209,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            value: scopeType,
            onValueChange: (v) => setScopeType(v),
            children: [
              /* @__PURE__ */ jsxDEV(SelectTrigger, { children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
                lineNumber: 215,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
                lineNumber: 214,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(SelectContent, { children: SCOPE_TYPES.map(
                (s) => /* @__PURE__ */ jsxDEV(SelectItem, { value: s.value, children: s.label }, s.value, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
                  lineNumber: 219,
                  columnNumber: 17
                }, this)
              ) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
                lineNumber: 217,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 210,
            columnNumber: 13
          },
          this
        ),
        scopeType === "DIRECTORY" && /* @__PURE__ */ jsxDEV(
          Input,
          {
            value: scopeSpec,
            onChange: (e) => setScopeSpec(e.target.value),
            placeholder: "e.g. src/app"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 226,
            columnNumber: 13
          },
          this
        ),
        scopeType === "FILE_LIST" && /* @__PURE__ */ jsxDEV(
          Input,
          {
            value: scopeSpec,
            onChange: (e) => setScopeSpec(e.target.value),
            placeholder: "path/to/a.ts, path/to/b.ts"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 233,
            columnNumber: 13
          },
          this
        ),
        scopeType === "BRANCH_DIFF" && /* @__PURE__ */ jsxDEV(
          Input,
          {
            value: scopeSpec,
            onChange: (e) => setScopeSpec(e.target.value),
            placeholder: "main feature-branch"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 240,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
        lineNumber: 208,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Ruleset (optional)" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
          lineNumber: 248,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Select, { value: rulesetId ?? "none", onValueChange: (v) => setRulesetId(v === "none" ? null : v), children: [
          /* @__PURE__ */ jsxDEV(SelectTrigger, { children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Default" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 251,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 250,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(SelectContent, { children: [
            /* @__PURE__ */ jsxDEV(SelectItem, { value: "none", children: "Default" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
              lineNumber: 254,
              columnNumber: 17
            }, this),
            rulesets?.map(
              (r) => /* @__PURE__ */ jsxDEV(SelectItem, { value: r._id, children: [
                r.name,
                " ",
                r.preset ? `(${r.preset})` : ""
              ] }, r._id, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
                lineNumber: 256,
                columnNumber: 17
              }, this)
            )
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 253,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
          lineNumber: 249,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
        lineNumber: 247,
        columnNumber: 11
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-destructive", children: error }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
        lineNumber: 264,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
        /* @__PURE__ */ jsxDEV(Button, { type: "button", variant: "outline", onClick: onClose, disabled: loading, children: "Cancel" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
          lineNumber: 267,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { type: "submit", disabled: loading, children: loading ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(Loader2, { className: "mr-2 h-4 w-4 animate-spin" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
            lineNumber: 273,
            columnNumber: 19
          }, this),
          "Starting…"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
          lineNumber: 272,
          columnNumber: 15
        }, this) : "Start QC Run" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
          lineNumber: 270,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
        lineNumber: 266,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
      lineNumber: 158,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
    lineNumber: 151,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx",
    lineNumber: 150,
    columnNumber: 5
  }, this);
}
_s(StartQcRunModal, "qcPmT5KjcrXKS+2R9Txar+l9dto=", false, function() {
  return [useMutation, useQuery];
});
_c = StartQcRunModal;
var _c;
$RefreshReg$(_c, "StartQcRunModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StartQcRunModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUlVLFNBdUhNLFVBdkhOOzs7Ozs7Ozs7Ozs7Ozs7OztBQS9IVixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLFdBQVc7QUFFcEIsU0FBU0MsY0FBYztBQUN2QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGFBQWE7QUFDdEI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MsZUFBZTtBQUV4QixNQUFNQyxlQUFlO0FBQUEsRUFDbkIsRUFBRUMsT0FBTyxTQUFTQyxPQUFPLFFBQVE7QUFBQSxFQUNqQyxFQUFFRCxPQUFPLE9BQU9DLE9BQU8sTUFBTTtBQUFBLEVBQzdCLEVBQUVELE9BQU8sV0FBV0MsT0FBTyxVQUFVO0FBQUEsRUFDckMsRUFBRUQsT0FBTyxTQUFTQyxPQUFPLFFBQVE7QUFBQSxFQUNqQyxFQUFFRCxPQUFPLGNBQWNDLE9BQU8sYUFBYTtBQUFDO0FBRzlDLE1BQU1DLGNBQWM7QUFBQSxFQUNsQixFQUFFRixPQUFPLGNBQWNDLE9BQU8sYUFBYTtBQUFBLEVBQzNDLEVBQUVELE9BQU8sZUFBZUMsT0FBTyxjQUFjO0FBQUEsRUFDN0MsRUFBRUQsT0FBTyxnQkFBZ0JDLE9BQU8sZUFBZTtBQUFBLEVBQy9DLEVBQUVELE9BQU8sWUFBWUMsT0FBTyxXQUFXO0FBQUEsRUFDdkMsRUFBRUQsT0FBTyxZQUFZQyxPQUFPLFdBQVc7QUFBQztBQUcxQyxNQUFNRSxjQUFjO0FBQUEsRUFDbEIsRUFBRUgsT0FBTyxhQUFhQyxPQUFPLFlBQVk7QUFBQSxFQUN6QyxFQUFFRCxPQUFPLGVBQWVDLE9BQU8sY0FBYztBQUFBLEVBQzdDLEVBQUVELE9BQU8sYUFBYUMsT0FBTyxZQUFZO0FBQUEsRUFDekMsRUFBRUQsT0FBTyxhQUFhQyxPQUFPLFlBQVk7QUFBQztBQUdyQyxnQkFBU0csZ0JBQWdCO0FBQUEsRUFDOUJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBS0YsR0FBRztBQUFBQyxLQUFBO0FBQ0QsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUk5QixTQUFpQixLQUFLO0FBQzVELFFBQU0sQ0FBQytCLFdBQVdDLFlBQVksSUFBSWhDLFNBQWlCLFlBQVk7QUFDL0QsUUFBTSxDQUFDaUMsV0FBV0MsWUFBWSxJQUFJbEMsU0FBa0UsV0FBVztBQUMvRyxRQUFNLENBQUNtQyxTQUFTQyxVQUFVLElBQUlwQyxTQUFTLDZCQUE2QjtBQUNwRSxRQUFNLENBQUNxQyxRQUFRQyxTQUFTLElBQUl0QyxTQUFTLE1BQU07QUFDM0MsUUFBTSxDQUFDdUMsV0FBV0MsWUFBWSxJQUFJeEMsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3lDLFdBQVdDLFlBQVksSUFBSTFDLFNBQWlCLEVBQUU7QUFDckQsUUFBTSxDQUFDMkMsV0FBV0MsWUFBWSxJQUFJNUMsU0FBd0IsSUFBSTtBQUM5RCxRQUFNLENBQUM2QyxTQUFTQyxVQUFVLElBQUk5QyxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDK0MsT0FBT0MsUUFBUSxJQUFJaEQsU0FBd0IsSUFBSTtBQUV0RCxRQUFNaUQsV0FBV2hELFlBQVlFLElBQUkrQyxPQUFPQyxLQUFLO0FBQzdDLFFBQU1DLFdBQVdsRCxTQUFTQyxJQUFJa0QsV0FBV0MsTUFBTSxFQUFFN0IsV0FBV0EsYUFBYThCLE9BQVUsQ0FBQztBQUVwRixRQUFNQyxlQUFlLE9BQU9DLE1BQXVCO0FBQ2pEQSxNQUFFQyxlQUFlO0FBQ2pCVixhQUFTLElBQUk7QUFDYkYsZUFBVyxJQUFJO0FBQ2YsUUFBSTtBQUNGLFVBQUlhLE9BQWdCSjtBQUNwQixVQUFJdEIsY0FBYyxhQUFhO0FBQzdCMEIsZUFBT2xCLFVBQVVtQixLQUFLLElBQUluQixVQUFVb0IsTUFBTSxTQUFTLEVBQUVDLElBQUksQ0FBQ0MsTUFBTUEsRUFBRUgsS0FBSyxDQUFDLEVBQUVJLE9BQU9DLE9BQU8sSUFBSTtBQUM1RixZQUFJQyxNQUFNQyxRQUFRUixJQUFJLEtBQUtBLEtBQUtTLFdBQVcsR0FBRztBQUM1Q3BCLG1CQUFTLDJCQUEyQjtBQUNwQ0YscUJBQVcsS0FBSztBQUNoQjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLFdBQVdiLGNBQWMsYUFBYTtBQUNwQzBCLGVBQU9sQixVQUFVbUIsS0FBSyxLQUFLTDtBQUMzQixZQUFJLENBQUNJLE1BQU07QUFDVFgsbUJBQVMsNEJBQTRCO0FBQ3JDRixxQkFBVyxLQUFLO0FBQ2hCO0FBQUEsUUFDRjtBQUFBLE1BQ0YsV0FBV2IsY0FBYyxlQUFlO0FBQ3RDLGNBQU0sQ0FBQ29DLE1BQU1DLElBQUksSUFBSTdCLFVBQVVvQixNQUFNLEtBQUssRUFBRUMsSUFBSSxDQUFDQyxNQUFNQSxFQUFFSCxLQUFLLENBQUM7QUFDL0RELGVBQU9VLFFBQVFDLE9BQU8sRUFBRUQsTUFBTUMsS0FBSyxJQUFJZjtBQUN2QyxZQUFJLENBQUNJLFFBQVEsT0FBT0EsU0FBUyxZQUFZLEVBQUUsVUFBVUEsT0FBTztBQUMxRFgsbUJBQVMseURBQXlEO0FBQ2xFRixxQkFBVyxLQUFLO0FBQ2hCO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFFQSxZQUFNeUIsaUJBQWlCLFlBQVlDLEtBQUtDLElBQUksQ0FBQyxJQUFJQyxLQUFLQyxPQUFPLEVBQUVDLFNBQVMsRUFBRSxFQUFFQyxNQUFNLENBQUMsQ0FBQztBQUNwRixZQUFNQyxTQUFTLE1BQU03QixTQUFTO0FBQUEsUUFDNUJ4QixXQUFXQSxhQUFhOEI7QUFBQUEsUUFDeEJwQjtBQUFBQSxRQUNBSSxXQUFXQSxVQUFVcUIsS0FBSyxLQUFLTDtBQUFBQSxRQUMvQmxCLFFBQVFBLE9BQU91QixLQUFLLEtBQUtMO0FBQUFBLFFBQ3pCdEI7QUFBQUEsUUFDQVEsV0FBV2tCO0FBQUFBLFFBQ1hoQixXQUFXQSxZQUFhQSxZQUFpQ1k7QUFBQUEsUUFDekR3QixlQUFlO0FBQUEsUUFDZlI7QUFBQUEsUUFDQTFDO0FBQUFBLFFBQ0FFO0FBQUFBLE1BQ0YsQ0FBQztBQUNESixrQkFBWW1ELE9BQU9FLEtBQUs7QUFDeEJ0RCxjQUFRO0FBQUEsSUFDVixTQUFTdUQsS0FBYztBQUNyQmpDLGVBQVNpQyxlQUFlQyxRQUFRRCxJQUFJRSxVQUFVLHdCQUF3QjtBQUFBLElBQ3hFLFVBQUM7QUFDQ3JDLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFVBQU8sTUFBSSxNQUFDLGNBQWMsQ0FBQ3NDLFNBQVMsQ0FBQ0EsUUFBUTFELFFBQVEsR0FDcEQsaUNBQUMsaUJBQWMsV0FBVSxZQUN2QjtBQUFBLDJCQUFDLGdCQUNDO0FBQUEsNkJBQUMsZUFBWSw0QkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDekIsdUJBQUMscUJBQWlCLG9HQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0EsdUJBQUMsVUFBSyxVQUFVOEIsY0FBYyxXQUFVLGFBQ3RDO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxTQUFNLDJCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0I7QUFBQSxRQUNsQix1QkFBQyxVQUFPLE9BQU8zQixhQUFhLGVBQWVDLGdCQUN6QztBQUFBLGlDQUFDLGlCQUNDLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVksS0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxpQkFDRVgsdUJBQWEyQztBQUFBQSxZQUFJLENBQUNMLE1BQ2pCLHVCQUFDLGNBQXlCLE9BQU9BLEVBQUVyQyxPQUNoQ3FDLFlBQUVwQyxTQURZb0MsRUFBRXJDLE9BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxVQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLGFBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBTSwwQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlCO0FBQUEsUUFDakIsdUJBQUMsVUFBTyxPQUFPVyxXQUFXLGVBQWVDLGNBQ3ZDO0FBQUEsaUNBQUMsaUJBQ0MsaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBWSxLQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLGlCQUNFVixzQkFBWXdDO0FBQUFBLFlBQUksQ0FBQ3VCLE1BQ2hCLHVCQUFDLGNBQXlCLE9BQU9BLEVBQUVqRSxPQUNoQ2lFLFlBQUVoRSxTQURZZ0UsRUFBRWpFLE9BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxVQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLGFBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBTSx3QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWU7QUFBQSxRQUNmO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPZTtBQUFBQSxZQUNQLFVBQVUsQ0FBQ3NCLE1BQU1yQixXQUFXcUIsRUFBRTZCLE9BQU9sRSxLQUFLO0FBQUEsWUFDMUMsYUFBWTtBQUFBLFlBQ1osVUFBUTtBQUFBO0FBQUEsVUFKVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJVTtBQUFBLFdBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFNBQU0sc0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYTtBQUFBLFVBQ2IsdUJBQUMsU0FBTSxPQUFPaUIsUUFBUSxVQUFVLENBQUNvQixNQUFNbkIsVUFBVW1CLEVBQUU2QixPQUFPbEUsS0FBSyxHQUFHLGFBQVksVUFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Y7QUFBQSxhQUZ0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsU0FBTSxxQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QjtBQUFBLFVBQzVCLHVCQUFDLFNBQU0sT0FBT21CLFdBQVcsVUFBVSxDQUFDa0IsTUFBTWpCLGFBQWFpQixFQUFFNkIsT0FBT2xFLEtBQUssR0FBRyxhQUFZLFlBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRGO0FBQUEsYUFGOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBTSxxQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVk7QUFBQSxRQUNaO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPYTtBQUFBQSxZQUNQLGVBQWUsQ0FBQ3NELE1BQU1yRCxhQUFhcUQsQ0FBcUI7QUFBQSxZQUV4RDtBQUFBLHFDQUFDLGlCQUNDLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQVksS0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxpQkFDRWhFLHNCQUFZdUM7QUFBQUEsZ0JBQUksQ0FBQ0MsTUFDaEIsdUJBQUMsY0FBeUIsT0FBT0EsRUFBRTNDLE9BQ2hDMkMsWUFBRTFDLFNBRFkwQyxFQUFFM0MsT0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGNBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BO0FBQUE7QUFBQTtBQUFBLFVBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBY0E7QUFBQSxRQUNDYSxjQUFjLGVBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU9RO0FBQUFBLFlBQ1AsVUFBVSxDQUFDZ0IsTUFBTWYsYUFBYWUsRUFBRTZCLE9BQU9sRSxLQUFLO0FBQUEsWUFDNUMsYUFBWTtBQUFBO0FBQUEsVUFIZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHNEI7QUFBQSxRQUc3QmEsY0FBYyxlQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPUTtBQUFBQSxZQUNQLFVBQVUsQ0FBQ2dCLE1BQU1mLGFBQWFlLEVBQUU2QixPQUFPbEUsS0FBSztBQUFBLFlBQzVDLGFBQVk7QUFBQTtBQUFBLFVBSGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRzBDO0FBQUEsUUFHM0NhLGNBQWMsaUJBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU9RO0FBQUFBLFlBQ1AsVUFBVSxDQUFDZ0IsTUFBTWYsYUFBYWUsRUFBRTZCLE9BQU9sRSxLQUFLO0FBQUEsWUFDNUMsYUFBWTtBQUFBO0FBQUEsVUFIZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHbUM7QUFBQSxXQW5DdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNDQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxTQUFNLGtDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUI7QUFBQSxRQUN6Qix1QkFBQyxVQUFPLE9BQU91QixhQUFhLFFBQVEsZUFBZSxDQUFDNEMsTUFBTTNDLGFBQWEyQyxNQUFNLFNBQVMsT0FBT0EsQ0FBQyxHQUM1RjtBQUFBLGlDQUFDLGlCQUNDLGlDQUFDLGVBQVksYUFBWSxhQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQyxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxpQkFDQztBQUFBLG1DQUFDLGNBQVcsT0FBTSxRQUFPLHVCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLFlBQy9CbkMsVUFBVVU7QUFBQUEsY0FBSSxDQUFDMEIsTUFDZCx1QkFBQyxjQUF1QixPQUFPQSxFQUFFQyxLQUM5QkQ7QUFBQUEsa0JBQUVFO0FBQUFBLGdCQUFLO0FBQUEsZ0JBQUVGLEVBQUVHLFNBQVMsSUFBSUgsRUFBRUcsTUFBTSxNQUFNO0FBQUEsbUJBRHhCSCxFQUFFQyxLQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsWUFDRDtBQUFBLGVBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsV0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxNQUNDMUMsU0FDQyx1QkFBQyxPQUFFLFdBQVUsNEJBQTRCQSxtQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQztBQUFBLE1BRWpELHVCQUFDLGdCQUNDO0FBQUEsK0JBQUMsVUFBTyxNQUFLLFVBQVMsU0FBUSxXQUFVLFNBQVNyQixTQUFTLFVBQVVtQixTQUFRLHNCQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFVBQU8sTUFBSyxVQUFTLFVBQVVBLFNBQzdCQSxvQkFDQyxtQ0FDRTtBQUFBLGlDQUFDLFdBQVEsV0FBVSwrQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQTtBQUFBLGFBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxJQUVBLGtCQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFdBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsU0ExSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJIQTtBQUFBLE9BbElGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtSUEsS0FwSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFJQTtBQUVKO0FBQUNqQixHQXBOZUosaUJBQWU7QUFBQSxVQW9CWnZCLGFBQ0FDLFFBQVE7QUFBQTtBQUFBLEtBckJYc0I7QUFBZSxJQUFBb0U7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsInVzZVF1ZXJ5IiwiYXBpIiwiQnV0dG9uIiwiRGlhbG9nIiwiRGlhbG9nQ29udGVudCIsIkRpYWxvZ0Rlc2NyaXB0aW9uIiwiRGlhbG9nRm9vdGVyIiwiRGlhbG9nSGVhZGVyIiwiRGlhbG9nVGl0bGUiLCJMYWJlbCIsIklucHV0IiwiU2VsZWN0IiwiU2VsZWN0Q29udGVudCIsIlNlbGVjdEl0ZW0iLCJTZWxlY3RUcmlnZ2VyIiwiU2VsZWN0VmFsdWUiLCJMb2FkZXIyIiwiRU5WSVJPTk1FTlRTIiwidmFsdWUiLCJsYWJlbCIsIkNIRUNLX1RZUEVTIiwiU0NPUEVfVFlQRVMiLCJTdGFydFFjUnVuTW9kYWwiLCJwcm9qZWN0SWQiLCJvbkNsb3NlIiwib25TdGFydGVkIiwiX3MiLCJlbnZpcm9ubWVudCIsInNldEVudmlyb25tZW50IiwiY2hlY2tUeXBlIiwic2V0Q2hlY2tUeXBlIiwic2NvcGVUeXBlIiwic2V0U2NvcGVUeXBlIiwicmVwb1VybCIsInNldFJlcG9VcmwiLCJicmFuY2giLCJzZXRCcmFuY2giLCJjb21taXRTaGEiLCJzZXRDb21taXRTaGEiLCJzY29wZVNwZWMiLCJzZXRTY29wZVNwZWMiLCJydWxlc2V0SWQiLCJzZXRSdWxlc2V0SWQiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJzdGFydFJ1biIsInFjUnVucyIsInN0YXJ0IiwicnVsZXNldHMiLCJxY1J1bGVzZXRzIiwibGlzdCIsInVuZGVmaW5lZCIsImhhbmRsZVN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInNwZWMiLCJ0cmltIiwic3BsaXQiLCJtYXAiLCJzIiwiZmlsdGVyIiwiQm9vbGVhbiIsIkFycmF5IiwiaXNBcnJheSIsImxlbmd0aCIsImJhc2UiLCJoZWFkIiwiaWRlbXBvdGVuY3lLZXkiLCJEYXRlIiwibm93IiwiTWF0aCIsInJhbmRvbSIsInRvU3RyaW5nIiwic2xpY2UiLCJyZXN1bHQiLCJpbml0aWF0b3JUeXBlIiwicnVuSWQiLCJlcnIiLCJFcnJvciIsIm1lc3NhZ2UiLCJvcGVuIiwiYyIsInRhcmdldCIsInYiLCJyIiwiX2lkIiwibmFtZSIsInByZXNldCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlN0YXJ0UWNSdW5Nb2RhbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBTdGFydCBRQyBSdW4gTW9kYWxcbiAqXG4gKiBFbnZpcm9ubWVudCBzZWxlY3RvciwgY2hlY2sgdHlwZSwgc2NvcGUsIHJ1bGVzZXQgcGlja2VyOyB3aXJlZCB0byBhcGkucWNSdW5zLnN0YXJ0LlxuICovXG5cbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnkgfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9idXR0b25cIjtcbmltcG9ydCB7XG4gIERpYWxvZyxcbiAgRGlhbG9nQ29udGVudCxcbiAgRGlhbG9nRGVzY3JpcHRpb24sXG4gIERpYWxvZ0Zvb3RlcixcbiAgRGlhbG9nSGVhZGVyLFxuICBEaWFsb2dUaXRsZSxcbn0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9kaWFsb2dcIjtcbmltcG9ydCB7IExhYmVsIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9sYWJlbFwiO1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2lucHV0XCI7XG5pbXBvcnQge1xuICBTZWxlY3QsXG4gIFNlbGVjdENvbnRlbnQsXG4gIFNlbGVjdEl0ZW0sXG4gIFNlbGVjdFRyaWdnZXIsXG4gIFNlbGVjdFZhbHVlLFxufSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL3NlbGVjdFwiO1xuaW1wb3J0IHsgTG9hZGVyMiB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcblxuY29uc3QgRU5WSVJPTk1FTlRTID0gW1xuICB7IHZhbHVlOiBcImxvY2FsXCIsIGxhYmVsOiBcIkxvY2FsXCIgfSxcbiAgeyB2YWx1ZTogXCJkZXZcIiwgbGFiZWw6IFwiRGV2XCIgfSxcbiAgeyB2YWx1ZTogXCJzdGFnaW5nXCIsIGxhYmVsOiBcIlN0YWdpbmdcIiB9LFxuICB7IHZhbHVlOiBcInBpbG90XCIsIGxhYmVsOiBcIlBpbG90XCIgfSxcbiAgeyB2YWx1ZTogXCJwcm9kdWN0aW9uXCIsIGxhYmVsOiBcIlByb2R1Y3Rpb25cIiB9LFxuXSBhcyBjb25zdDtcblxuY29uc3QgQ0hFQ0tfVFlQRVMgPSBbXG4gIHsgdmFsdWU6IFwiRlVMTF9TVUlURVwiLCBsYWJlbDogXCJGdWxsIFN1aXRlXCIgfSxcbiAgeyB2YWx1ZTogXCJDT0RFX1JFVklFV1wiLCBsYWJlbDogXCJDb2RlIFJldmlld1wiIH0sXG4gIHsgdmFsdWU6IFwiQUdFTlRfT1VUUFVUXCIsIGxhYmVsOiBcIkFnZW50IE91dHB1dFwiIH0sXG4gIHsgdmFsdWU6IFwiU0VDVVJJVFlcIiwgbGFiZWw6IFwiU2VjdXJpdHlcIiB9LFxuICB7IHZhbHVlOiBcIkNPVkVSQUdFXCIsIGxhYmVsOiBcIkNvdmVyYWdlXCIgfSxcbl0gYXMgY29uc3Q7XG5cbmNvbnN0IFNDT1BFX1RZUEVTID0gW1xuICB7IHZhbHVlOiBcIkZVTExfUkVQT1wiLCBsYWJlbDogXCJGdWxsIFJlcG9cIiB9LFxuICB7IHZhbHVlOiBcIkJSQU5DSF9ESUZGXCIsIGxhYmVsOiBcIkJyYW5jaCBEaWZmXCIgfSxcbiAgeyB2YWx1ZTogXCJESVJFQ1RPUllcIiwgbGFiZWw6IFwiRGlyZWN0b3J5XCIgfSxcbiAgeyB2YWx1ZTogXCJGSUxFX0xJU1RcIiwgbGFiZWw6IFwiRmlsZSBMaXN0XCIgfSxcbl0gYXMgY29uc3Q7XG5cbmV4cG9ydCBmdW5jdGlvbiBTdGFydFFjUnVuTW9kYWwoe1xuICBwcm9qZWN0SWQsXG4gIG9uQ2xvc2UsXG4gIG9uU3RhcnRlZCxcbn06IHtcbiAgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+IHwgbnVsbDtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbiAgb25TdGFydGVkPzogKHJ1bklkOiBzdHJpbmcpID0+IHZvaWQ7XG59KSB7XG4gIGNvbnN0IFtlbnZpcm9ubWVudCwgc2V0RW52aXJvbm1lbnRdID0gdXNlU3RhdGU8c3RyaW5nPihcImRldlwiKTtcbiAgY29uc3QgW2NoZWNrVHlwZSwgc2V0Q2hlY2tUeXBlXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJGVUxMX1NVSVRFXCIpO1xuICBjb25zdCBbc2NvcGVUeXBlLCBzZXRTY29wZVR5cGVdID0gdXNlU3RhdGU8XCJGVUxMX1JFUE9cIiB8IFwiQlJBTkNIX0RJRkZcIiB8IFwiRElSRUNUT1JZXCIgfCBcIkZJTEVfTElTVFwiPihcIkZVTExfUkVQT1wiKTtcbiAgY29uc3QgW3JlcG9VcmwsIHNldFJlcG9VcmxdID0gdXNlU3RhdGUoXCJodHRwczovL2dpdGh1Yi5jb20vb3JnL3JlcG9cIik7XG4gIGNvbnN0IFticmFuY2gsIHNldEJyYW5jaF0gPSB1c2VTdGF0ZShcIm1haW5cIik7XG4gIGNvbnN0IFtjb21taXRTaGEsIHNldENvbW1pdFNoYV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3Njb3BlU3BlYywgc2V0U2NvcGVTcGVjXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG4gIGNvbnN0IFtydWxlc2V0SWQsIHNldFJ1bGVzZXRJZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IHN0YXJ0UnVuID0gdXNlTXV0YXRpb24oYXBpLnFjUnVucy5zdGFydCk7XG4gIGNvbnN0IHJ1bGVzZXRzID0gdXNlUXVlcnkoYXBpLnFjUnVsZXNldHMubGlzdCwgeyBwcm9qZWN0SWQ6IHByb2plY3RJZCA/PyB1bmRlZmluZWQgfSk7XG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRFcnJvcihudWxsKTtcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBsZXQgc3BlYzogdW5rbm93biA9IHVuZGVmaW5lZDtcbiAgICAgIGlmIChzY29wZVR5cGUgPT09IFwiRklMRV9MSVNUXCIpIHtcbiAgICAgICAgc3BlYyA9IHNjb3BlU3BlYy50cmltKCkgPyBzY29wZVNwZWMuc3BsaXQoL1xccyosXFxzKi8pLm1hcCgocykgPT4gcy50cmltKCkpLmZpbHRlcihCb29sZWFuKSA6IFtdO1xuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShzcGVjKSAmJiBzcGVjLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgIHNldEVycm9yKFwiRmlsZSBsaXN0IGNhbm5vdCBiZSBlbXB0eVwiKTtcbiAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoc2NvcGVUeXBlID09PSBcIkRJUkVDVE9SWVwiKSB7XG4gICAgICAgIHNwZWMgPSBzY29wZVNwZWMudHJpbSgpIHx8IHVuZGVmaW5lZDtcbiAgICAgICAgaWYgKCFzcGVjKSB7XG4gICAgICAgICAgc2V0RXJyb3IoXCJEaXJlY3RvcnkgcGF0aCBpcyByZXF1aXJlZFwiKTtcbiAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoc2NvcGVUeXBlID09PSBcIkJSQU5DSF9ESUZGXCIpIHtcbiAgICAgICAgY29uc3QgW2Jhc2UsIGhlYWRdID0gc2NvcGVTcGVjLnNwbGl0KC9cXHMrLykubWFwKChzKSA9PiBzLnRyaW0oKSk7XG4gICAgICAgIHNwZWMgPSBiYXNlICYmIGhlYWQgPyB7IGJhc2UsIGhlYWQgfSA6IHVuZGVmaW5lZDtcbiAgICAgICAgaWYgKCFzcGVjIHx8IHR5cGVvZiBzcGVjICE9PSBcIm9iamVjdFwiIHx8ICEoXCJiYXNlXCIgaW4gc3BlYykpIHtcbiAgICAgICAgICBzZXRFcnJvcihcIkVudGVyIGJhc2UgYW5kIGhlYWQgYnJhbmNoZXMgKGUuZy4gbWFpbiBmZWF0dXJlLWJyYW5jaClcIik7XG4gICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGlkZW1wb3RlbmN5S2V5ID0gYHFjLXN0YXJ0LSR7RGF0ZS5ub3coKX0tJHtNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zbGljZSgyKX1gO1xuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgc3RhcnRSdW4oe1xuICAgICAgICBwcm9qZWN0SWQ6IHByb2plY3RJZCA/PyB1bmRlZmluZWQsXG4gICAgICAgIHJlcG9VcmwsXG4gICAgICAgIGNvbW1pdFNoYTogY29tbWl0U2hhLnRyaW0oKSB8fCB1bmRlZmluZWQsXG4gICAgICAgIGJyYW5jaDogYnJhbmNoLnRyaW0oKSB8fCB1bmRlZmluZWQsXG4gICAgICAgIHNjb3BlVHlwZSxcbiAgICAgICAgc2NvcGVTcGVjOiBzcGVjLFxuICAgICAgICBydWxlc2V0SWQ6IHJ1bGVzZXRJZCA/IChydWxlc2V0SWQgYXMgSWQ8XCJxY1J1bGVzZXRzXCI+KSA6IHVuZGVmaW5lZCxcbiAgICAgICAgaW5pdGlhdG9yVHlwZTogXCJIVU1BTlwiLFxuICAgICAgICBpZGVtcG90ZW5jeUtleSxcbiAgICAgICAgZW52aXJvbm1lbnQ6IGVudmlyb25tZW50IGFzIFwibG9jYWxcIiB8IFwiZGV2XCIgfCBcInN0YWdpbmdcIiB8IFwicGlsb3RcIiB8IFwicHJvZHVjdGlvblwiLFxuICAgICAgICBjaGVja1R5cGU6IGNoZWNrVHlwZSBhcyBcIkZVTExfU1VJVEVcIiB8IFwiQ09ERV9SRVZJRVdcIiB8IFwiQUdFTlRfT1VUUFVUXCIgfCBcIlNFQ1VSSVRZXCIgfCBcIkNPVkVSQUdFXCIsXG4gICAgICB9KTtcbiAgICAgIG9uU3RhcnRlZD8uKHJlc3VsdC5ydW5JZCk7XG4gICAgICBvbkNsb3NlKCk7XG4gICAgfSBjYXRjaCAoZXJyOiB1bmtub3duKSB7XG4gICAgICBzZXRFcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogXCJGYWlsZWQgdG8gc3RhcnQgUUMgcnVuXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8RGlhbG9nIG9wZW4gb25PcGVuQ2hhbmdlPXsob3BlbikgPT4gIW9wZW4gJiYgb25DbG9zZSgpfT5cbiAgICAgIDxEaWFsb2dDb250ZW50IGNsYXNzTmFtZT1cIm1heC13LWxnXCI+XG4gICAgICAgIDxEaWFsb2dIZWFkZXI+XG4gICAgICAgICAgPERpYWxvZ1RpdGxlPlN0YXJ0IFFDIFJ1bjwvRGlhbG9nVGl0bGU+XG4gICAgICAgICAgPERpYWxvZ0Rlc2NyaXB0aW9uPlxuICAgICAgICAgICAgQ29uZmlndXJlIGVudmlyb25tZW50LCBjaGVjayB0eXBlLCBzY29wZSwgYW5kIHJ1bGVzZXQgZm9yIGEgbmV3IHF1YWxpdHkgY29udHJvbCBydW4uXG4gICAgICAgICAgPC9EaWFsb2dEZXNjcmlwdGlvbj5cbiAgICAgICAgPC9EaWFsb2dIZWFkZXI+XG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICA8TGFiZWw+RW52aXJvbm1lbnQ8L0xhYmVsPlxuICAgICAgICAgICAgPFNlbGVjdCB2YWx1ZT17ZW52aXJvbm1lbnR9IG9uVmFsdWVDaGFuZ2U9e3NldEVudmlyb25tZW50fT5cbiAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIC8+XG4gICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAge0VOVklST05NRU5UUy5tYXAoKGUpID0+IChcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17ZS52YWx1ZX0gdmFsdWU9e2UudmFsdWV9PlxuICAgICAgICAgICAgICAgICAgICB7ZS5sYWJlbH1cbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgIDxMYWJlbD5DaGVjayB0eXBlPC9MYWJlbD5cbiAgICAgICAgICAgIDxTZWxlY3QgdmFsdWU9e2NoZWNrVHlwZX0gb25WYWx1ZUNoYW5nZT17c2V0Q2hlY2tUeXBlfT5cbiAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIC8+XG4gICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAge0NIRUNLX1RZUEVTLm1hcCgoYykgPT4gKFxuICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXtjLnZhbHVlfSB2YWx1ZT17Yy52YWx1ZX0+XG4gICAgICAgICAgICAgICAgICAgIHtjLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgPExhYmVsPlJlcG8gVVJMPC9MYWJlbD5cbiAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICB2YWx1ZT17cmVwb1VybH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZXBvVXJsKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJodHRwczovL2dpdGh1Yi5jb20vb3JnL3JlcG9cIlxuICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxMYWJlbD5CcmFuY2g8L0xhYmVsPlxuICAgICAgICAgICAgICA8SW5wdXQgdmFsdWU9e2JyYW5jaH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRCcmFuY2goZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIm1haW5cIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICA8TGFiZWw+Q29tbWl0IFNIQSAob3B0aW9uYWwpPC9MYWJlbD5cbiAgICAgICAgICAgICAgPElucHV0IHZhbHVlPXtjb21taXRTaGF9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q29tbWl0U2hhKGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJhYmMxMjNcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgIDxMYWJlbD5TY29wZTwvTGFiZWw+XG4gICAgICAgICAgICA8U2VsZWN0XG4gICAgICAgICAgICAgIHZhbHVlPXtzY29wZVR5cGV9XG4gICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2KSA9PiBzZXRTY29wZVR5cGUodiBhcyB0eXBlb2Ygc2NvcGVUeXBlKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIC8+XG4gICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAge1NDT1BFX1RZUEVTLm1hcCgocykgPT4gKFxuICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXtzLnZhbHVlfSB2YWx1ZT17cy52YWx1ZX0+XG4gICAgICAgICAgICAgICAgICAgIHtzLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICAgIHtzY29wZVR5cGUgPT09IFwiRElSRUNUT1JZXCIgJiYgKFxuICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICB2YWx1ZT17c2NvcGVTcGVjfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2NvcGVTcGVjKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gc3JjL2FwcFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAge3Njb3BlVHlwZSA9PT0gXCJGSUxFX0xJU1RcIiAmJiAoXG4gICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgIHZhbHVlPXtzY29wZVNwZWN9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTY29wZVNwZWMoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwicGF0aC90by9hLnRzLCBwYXRoL3RvL2IudHNcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHtzY29wZVR5cGUgPT09IFwiQlJBTkNIX0RJRkZcIiAmJiAoXG4gICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgIHZhbHVlPXtzY29wZVNwZWN9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTY29wZVNwZWMoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwibWFpbiBmZWF0dXJlLWJyYW5jaFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICA8TGFiZWw+UnVsZXNldCAob3B0aW9uYWwpPC9MYWJlbD5cbiAgICAgICAgICAgIDxTZWxlY3QgdmFsdWU9e3J1bGVzZXRJZCA/PyBcIm5vbmVcIn0gb25WYWx1ZUNoYW5nZT17KHYpID0+IHNldFJ1bGVzZXRJZCh2ID09PSBcIm5vbmVcIiA/IG51bGwgOiB2KX0+XG4gICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIkRlZmF1bHRcIiAvPlxuICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwibm9uZVwiPkRlZmF1bHQ8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAge3J1bGVzZXRzPy5tYXAoKHIpID0+IChcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17ci5faWR9IHZhbHVlPXtyLl9pZH0+XG4gICAgICAgICAgICAgICAgICAgIHtyLm5hbWV9IHtyLnByZXNldCA/IGAoJHtyLnByZXNldH0pYCA6IFwiXCJ9XG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgIDwvU2VsZWN0PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHtlcnJvciAmJiAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZGVzdHJ1Y3RpdmVcIj57ZXJyb3J9PC9wPlxuICAgICAgICAgICl9XG4gICAgICAgICAgPERpYWxvZ0Zvb3Rlcj5cbiAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17b25DbG9zZX0gZGlzYWJsZWQ9e2xvYWRpbmd9PlxuICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e2xvYWRpbmd9PlxuICAgICAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPExvYWRlcjIgY2xhc3NOYW1lPVwibXItMiBoLTQgdy00IGFuaW1hdGUtc3BpblwiIC8+XG4gICAgICAgICAgICAgICAgICBTdGFydGluZ+KAplxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIFwiU3RhcnQgUUMgUnVuXCJcbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvRGlhbG9nRm9vdGVyPlxuICAgICAgICA8L2Zvcm0+XG4gICAgICA8L0RpYWxvZ0NvbnRlbnQ+XG4gICAgPC9EaWFsb2c+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9TdGFydFFjUnVuTW9kYWwudHN4In0=