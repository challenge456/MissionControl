import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/factory/Breadcrumbs.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/Breadcrumbs.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const Fragment = __vite__cjsImport3_react["Fragment"];
import { cn } from "/src/lib/utils.ts";
export function Breadcrumbs({ items }) {
  if (items.length === 0) return null;
  return /* @__PURE__ */ jsxDEV("nav", { "aria-label": "Breadcrumb", className: "flex items-center gap-1.5 text-[12.5px]", children: items.map(
    (crumb, i) => /* @__PURE__ */ jsxDEV(Fragment, { children: [
      i > 0 && /* @__PURE__ */ jsxDEV("span", { "aria-hidden": true, className: "text-ink-muted", children: "/" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/Breadcrumbs.tsx",
        lineNumber: 36,
        columnNumber: 9
      }, this),
      crumb.onClick && !crumb.current ? /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: crumb.onClick,
          className: "rounded text-ink-muted transition-colors duration-150 hover:text-ink-secondary",
          children: crumb.label
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/Breadcrumbs.tsx",
          lineNumber: 41,
          columnNumber: 9
        },
        this
      ) : /* @__PURE__ */ jsxDEV(
        "span",
        {
          "aria-current": crumb.current ? "page" : void 0,
          className: cn(crumb.current ? "text-ink" : "text-ink-muted"),
          children: crumb.label
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/Breadcrumbs.tsx",
          lineNumber: 49,
          columnNumber: 9
        },
        this
      )
    ] }, `${crumb.label}-${i}`, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/Breadcrumbs.tsx",
      lineNumber: 34,
      columnNumber: 7
    }, this)
  ) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/Breadcrumbs.tsx",
    lineNumber: 32,
    columnNumber: 5
  }, this);
}
_c = Breadcrumbs;
var _c;
$RefreshReg$(_c, "Breadcrumbs");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/Breadcrumbs.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/Breadcrumbs.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JZOzs7Ozs7Ozs7Ozs7Ozs7O0FBaEJaLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxVQUFVO0FBUVosZ0JBQVNDLFlBQVksRUFBRUMsTUFBMEIsR0FBdUI7QUFDN0UsTUFBSUEsTUFBTUMsV0FBVyxFQUFHLFFBQU87QUFDL0IsU0FDRSx1QkFBQyxTQUFJLGNBQVcsY0FBYSxXQUFVLDJDQUNwQ0QsZ0JBQU1FO0FBQUFBLElBQUksQ0FBQ0MsT0FBT0MsTUFDakIsdUJBQUMsWUFDRUE7QUFBQUEsVUFBSSxLQUNILHVCQUFDLFVBQUssZUFBVyxNQUFDLFdBQVUsa0JBQWdCLGlCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVERCxNQUFNRSxXQUFXLENBQUNGLE1BQU1HLFVBQ3ZCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUFTSCxNQUFNRTtBQUFBQSxVQUNmLFdBQVU7QUFBQSxVQUVURixnQkFBTUk7QUFBQUE7QUFBQUEsUUFMVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQSxJQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxnQkFBY0osTUFBTUcsVUFBVSxTQUFTRTtBQUFBQSxVQUN2QyxXQUFXVixHQUFHSyxNQUFNRyxVQUFVLGFBQWEsZ0JBQWdCO0FBQUEsVUFFMURILGdCQUFNSTtBQUFBQTtBQUFBQSxRQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsU0FwQlcsR0FBR0osTUFBTUksS0FBSyxJQUFJSCxDQUFDLElBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQkE7QUFBQSxFQUNELEtBekJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwQkE7QUFFSjtBQUFDSyxLQS9CZVY7QUFBVyxJQUFBVTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJGcmFnbWVudCIsImNuIiwiQnJlYWRjcnVtYnMiLCJpdGVtcyIsImxlbmd0aCIsIm1hcCIsImNydW1iIiwiaSIsIm9uQ2xpY2siLCJjdXJyZW50IiwibGFiZWwiLCJ1bmRlZmluZWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJCcmVhZGNydW1icy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRnJhZ21lbnQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIi4uLy4uL2xpYi91dGlsc1wiO1xuXG5leHBvcnQgaW50ZXJmYWNlIENydW1iIHtcbiAgbGFiZWw6IHN0cmluZztcbiAgb25DbGljaz86ICgpID0+IHZvaWQ7XG4gIGN1cnJlbnQ/OiBib29sZWFuO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQnJlYWRjcnVtYnMoeyBpdGVtcyB9OiB7IGl0ZW1zOiBDcnVtYltdIH0pOiBKU1guRWxlbWVudCB8IG51bGwge1xuICBpZiAoaXRlbXMubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIChcbiAgICA8bmF2IGFyaWEtbGFiZWw9XCJCcmVhZGNydW1iXCIgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LVsxMi41cHhdXCI+XG4gICAgICB7aXRlbXMubWFwKChjcnVtYiwgaSkgPT4gKFxuICAgICAgICA8RnJhZ21lbnQga2V5PXtgJHtjcnVtYi5sYWJlbH0tJHtpfWB9PlxuICAgICAgICAgIHtpID4gMCAmJiAoXG4gICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbiBjbGFzc05hbWU9XCJ0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAvXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgKX1cbiAgICAgICAgICB7Y3J1bWIub25DbGljayAmJiAhY3J1bWIuY3VycmVudCA/IChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2NydW1iLm9uQ2xpY2t9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQgdGV4dC1pbmstbXV0ZWQgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGhvdmVyOnRleHQtaW5rLXNlY29uZGFyeVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtjcnVtYi5sYWJlbH1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICBhcmlhLWN1cnJlbnQ9e2NydW1iLmN1cnJlbnQgPyBcInBhZ2VcIiA6IHVuZGVmaW5lZH1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihjcnVtYi5jdXJyZW50ID8gXCJ0ZXh0LWlua1wiIDogXCJ0ZXh0LWluay1tdXRlZFwiKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2NydW1iLmxhYmVsfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvRnJhZ21lbnQ+XG4gICAgICApKX1cbiAgICA8L25hdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL2NvbXBvbmVudHMvZmFjdG9yeS9CcmVhZGNydW1icy50c3gifQ==