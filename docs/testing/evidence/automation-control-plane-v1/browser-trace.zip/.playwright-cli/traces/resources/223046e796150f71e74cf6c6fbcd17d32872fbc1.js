import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/controlPlane/ExecutionRunInspector.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { Badge } from "/src/components/ui/badge.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Card } from "/src/components/ui/card.tsx";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "/src/components/ui/dialog.tsx";
import { orderTimelineEvents, latestHumanAttention, filterEvidenceArtifacts } from "/src/controlPlane/runInspectorModel.ts";
import { RunRecoveryPanel } from "/src/controlPlane/RunRecoveryPanel.tsx";
import { EvidenceLineagePanel } from "/src/controlPlane/EvidenceLineagePanel.tsx";
export function ExecutionRunInspector({
  open,
  workflowRunId,
  verificationReceiptId,
  acceptanceCriterionId,
  retrying = false,
  onRetryFailedRun,
  onClose
}) {
  _s();
  const inspector = useQuery(
    api.workflowRuns.getInspector,
    open && workflowRunId ? {
      workflowRunId,
      verificationReceiptId: verificationReceiptId ?? void 0,
      acceptanceCriterionId: acceptanceCriterionId ?? void 0
    } : "skip"
  );
  const routingDecision = useQuery(
    api.modelRoutingDecisions.getForWorkflowRun,
    open && workflowRunId ? { workflowRunId } : "skip"
  );
  const orderedEvents = useMemo(() => orderTimelineEvents(inspector?.events ?? []), [inspector?.events]);
  const attention = useMemo(() => latestHumanAttention(inspector?.events ?? []), [inspector?.events]);
  const evidenceArtifacts = useMemo(
    () => filterEvidenceArtifacts(inspector?.artifacts ?? [], { verificationReceiptId: verificationReceiptId ?? void 0, acceptanceCriterionId: acceptanceCriterionId ?? void 0 }),
    [inspector?.artifacts, verificationReceiptId, acceptanceCriterionId]
  );
  const navigateToRecords = (target) => {
    document.getElementById(`run-${target}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  return /* @__PURE__ */ jsxDEV(Dialog, { open, onOpenChange: (next) => !next && onClose(), children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "max-h-[90vh] max-w-[1100px] overflow-hidden p-0", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { className: "border-b border-[var(--panel-line)] px-6 py-4", children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Execution Run Inspector" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
        lineNumber: 84,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { className: "sr-only", children: "Inspect execution state, continuous evidence lineage, artifacts, verification, and recovery history." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
        lineNumber: 85,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
      lineNumber: 83,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "max-h-[80vh] overflow-y-auto p-6", children: !workflowRunId ? /* @__PURE__ */ jsxDEV(Card, { className: "p-6 text-sm text-muted-foreground", children: "Select a run to inspect." }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
      lineNumber: 92,
      columnNumber: 11
    }, this) : !inspector ? /* @__PURE__ */ jsxDEV(Card, { className: "p-6 text-sm text-muted-foreground", children: "Loading run inspector…" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
      lineNumber: 94,
      columnNumber: 11
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
      /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-start justify-between gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-semibold text-foreground", children: inspector.run.runId }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 100,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-sm text-muted-foreground", children: inspector.workOrder?.title ?? inspector.run.initialInput }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 101,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 99,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: [
            /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: inspector.run.status }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 104,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: inspector.run.workflowId }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 105,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 103,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
          lineNumber: 98,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-4 grid gap-3 text-sm md:grid-cols-2 xl:grid-cols-4", children: [
          /* @__PURE__ */ jsxDEV(Meta, { label: "WorkOrder", value: inspector.workOrder?._id }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 109,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Meta, { label: "Runtime / model", value: [inspector.run.runtime, inspector.run.model].filter(Boolean).join(" / ") || "—" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 110,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Meta, { label: "Current step", value: inspector.summary.currentStep ?? "—" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 111,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Meta, { label: "Retry count", value: `${inspector.summary.retryCount}` }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 112,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Meta, { label: "Started", value: new Date(inspector.run.startedAt).toLocaleString() }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 113,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Meta, { label: "Duration", value: `${Math.max(0, Math.round(inspector.summary.durationMs / 1e3))}s` }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 114,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Meta, { label: "Blocking issue", value: inspector.summary.blockingIssue ?? "—" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 115,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Meta, { label: "Human intervention", value: attention ?? (inspector.summary.humanInterventionRequired ? "Required" : "Not required") }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 116,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
          lineNumber: 108,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
        lineNumber: 97,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-start justify-between gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-foreground", children: "Model routing evidence" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 123,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: "The exact policy decision captured before provider execution." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 124,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 122,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: routingDecision?.mode ?? "Route unknown (legacy)" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 128,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
          lineNumber: 121,
          columnNumber: 17
        }, this),
        routingDecision ? /* @__PURE__ */ jsxDEV("div", { className: "mt-4 grid gap-3 text-sm md:grid-cols-2 xl:grid-cols-4", children: [
          /* @__PURE__ */ jsxDEV(Meta, { label: "Selected model", value: routingDecision.selectedModelId ?? "No safe route" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 134,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(Meta, { label: "Provider", value: routingDecision.selectedProvider ?? "—" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 135,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(Meta, { label: "Source", value: routingDecision.source }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 136,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(Meta, { label: "Policy version", value: `v${routingDecision.policyVersion}` }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 137,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2 xl:col-span-4", children: /* @__PURE__ */ jsxDEV(Meta, { label: "Explanation", value: routingDecision.explanation }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 139,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 138,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
          lineNumber: 133,
          columnNumber: 15
        }, this) : /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-sm text-muted-foreground", children: "This run predates routing evidence or was created outside Work Order dispatch." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
          lineNumber: 143,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
        lineNumber: 120,
        columnNumber: 15
      }, this),
      inspector.run.status === "FAILED" ? /* @__PURE__ */ jsxDEV(
        RunRecoveryPanel,
        {
          runId: inspector.run.runId,
          failureSummary: inspector.summary.failureSummary,
          busy: retrying,
          onRetry: onRetryFailedRun ? (reason) => onRetryFailedRun({
            workflowRunId: inspector.run._id,
            reason,
            runtime: inspector.run.runtime,
            model: inspector.run.model,
            worktree: inspector.run.worktree
          }) : void 0
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
          lineNumber: 150,
          columnNumber: 13
        },
        this
      ) : null,
      /* @__PURE__ */ jsxDEV(
        EvidenceLineagePanel,
        {
          stages: inspector.continuousEvidenceLineage ?? [],
          onNavigate: navigateToRecords
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
          lineNumber: 166,
          columnNumber: 15
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-start justify-between gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-foreground", children: "Operational observability" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 174,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: "Fixed, non-sensitive workflow and usage totals linked by a typed run reference." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 175,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 173,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: inspector.observability.usageComplete ? "Complete rollup" : "Bounded partial rollup" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 179,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
          lineNumber: 172,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-4 grid gap-3 text-sm md:grid-cols-2 xl:grid-cols-4", children: [
          /* @__PURE__ */ jsxDEV(Meta, { label: "Correlation ID", value: inspector.observability.correlationId }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 184,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Meta, { label: "Status", value: inspector.observability.status }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 185,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Meta, { label: "Attempts / retries", value: `${inspector.observability.attempts} / ${inspector.observability.retries}` }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 186,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Meta, { label: "Duration", value: `${Math.max(0, Math.round(inspector.observability.durationMs / 1e3))}s` }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 187,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Meta, { label: "Input tokens", value: inspector.observability.inputTokens.toLocaleString() }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 188,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Meta, { label: "Output tokens", value: inspector.observability.outputTokens.toLocaleString() }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 189,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Meta, { label: "Cost", value: `$${inspector.observability.costUsd.toFixed(4)}` }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 190,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
          lineNumber: 183,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
        lineNumber: 171,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-foreground", children: "Graph execution plan" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 197,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: "Dependencies, isolation, and node state from the durable run record." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 198,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 196,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: [
            /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: inspector.run.topology ?? "LINEAR" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 203,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: [
              "Max concurrency ",
              inspector.run.maxConcurrency ?? 1
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 204,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: [
              (inspector.run.steps ?? []).filter(
                (step) => ["DONE", "SKIPPED"].includes(step.status)
              ).length,
              "/",
              inspector.run.steps?.length ?? 0,
              " complete"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 207,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 202,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
          lineNumber: 195,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("ol", { className: "mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3", children: (inspector.run.steps ?? []).map(
          (step, index) => /* @__PURE__ */ jsxDEV(
            "li",
            {
              className: "rounded-lg border border-[var(--panel-line)] bg-background/30 p-3",
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] uppercase tracking-[0.14em] text-muted-foreground", children: [
                      "Node ",
                      index + 1
                    ] }, void 0, true, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                      lineNumber: 223,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "mt-1 font-mono text-sm text-foreground", children: step.stepId }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                      lineNumber: 226,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 222,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: step.status }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 230,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                  lineNumber: 221,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("dl", { className: "mt-3 space-y-1.5 text-xs", children: [
                  /* @__PURE__ */ jsxDEV(GraphMeta, { label: "Kind", value: step.kind ?? "AGENT" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 233,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    GraphMeta,
                    {
                      label: "Depends on",
                      value: step.dependsOn?.length ? step.dependsOn.join(", ") : "Ready at start"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                      lineNumber: 234,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(GraphMeta, { label: "Isolation", value: step.isolation ?? "SHARED" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 238,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(GraphMeta, { label: "Failure", value: step.failurePolicy ?? "RETRY" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 239,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                  lineNumber: 232,
                  columnNumber: 23
                }, this),
                step.error ? /* @__PURE__ */ jsxDEV("div", { className: "mt-3 rounded border border-red-500/20 bg-red-500/5 p-2 text-xs text-red-200", children: step.error }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                  lineNumber: 242,
                  columnNumber: 19
                }, this) : null
              ]
            },
            step.stepId,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 217,
              columnNumber: 17
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
          lineNumber: 215,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
        lineNumber: 194,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-6 xl:grid-cols-[minmax(0,1.2fr)_minmax(360px,0.8fr)]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsxDEV(Card, { id: "run-timeline", className: "scroll-mt-4 p-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 text-sm font-medium text-foreground", children: "Timeline" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 254,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: orderedEvents.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "No structured run events recorded yet." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 256,
              columnNumber: 53
            }, this) : orderedEvents.map((event) => {
              const highlighted = verificationReceiptId && event.verificationReceiptId === verificationReceiptId || acceptanceCriterionId && event.metadata?.acceptanceCriterionId === acceptanceCriterionId;
              return /* @__PURE__ */ jsxDEV("div", { className: `rounded-lg border px-3 py-3 ${highlighted ? "border-registry-accent/40 bg-registry-accent-soft" : "border-[var(--panel-line)] bg-background/30"}`, children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: [
                      "#",
                      event.sequenceNumber
                    ] }, void 0, true, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                      lineNumber: 263,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-foreground", children: event.eventType }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                      lineNumber: 264,
                      columnNumber: 33
                    }, this),
                    event.workflowStep ? /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: event.workflowStep }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                      lineNumber: 265,
                      columnNumber: 55
                    }, this) : null,
                    event.status ? /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: event.status }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                      lineNumber: 266,
                      columnNumber: 49
                    }, this) : null
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 262,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-muted-foreground", children: event.durationMs ? `${Math.round(event.durationMs)}ms` : "—" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 268,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                  lineNumber: 261,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-sm text-muted-foreground", children: event.commandSummary ?? event.errorSummary ?? event.toolName ?? "No summary" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                  lineNumber: 270,
                  columnNumber: 29
                }, this),
                event.toolName || event.retryNumber || event.errorCategory ? /* @__PURE__ */ jsxDEV("div", { className: "mt-2 flex flex-wrap gap-3 text-xs text-muted-foreground", children: [
                  event.toolName ? /* @__PURE__ */ jsxDEV("span", { children: [
                    "Tool: ",
                    event.toolName
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 273,
                    columnNumber: 51
                  }, this) : null,
                  event.retryNumber ? /* @__PURE__ */ jsxDEV("span", { children: [
                    "Retry: ",
                    event.retryNumber
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 274,
                    columnNumber: 54
                  }, this) : null,
                  event.errorCategory ? /* @__PURE__ */ jsxDEV("span", { children: [
                    "Error: ",
                    event.errorCategory
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 275,
                    columnNumber: 56
                  }, this) : null
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                  lineNumber: 272,
                  columnNumber: 27
                }, this) : null,
                event.metadata ? /* @__PURE__ */ jsxDEV("details", { className: "mt-2 text-xs text-muted-foreground", children: [
                  /* @__PURE__ */ jsxDEV("summary", { className: "cursor-pointer", children: "More context" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 280,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("pre", { className: "mt-2 overflow-x-auto rounded bg-background/60 p-2", children: JSON.stringify(event.metadata, null, 2) }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 281,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                  lineNumber: 279,
                  columnNumber: 27
                }, this) : null
              ] }, event._id ?? `${event.sequenceNumber}-${event.eventType}`, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                lineNumber: 260,
                columnNumber: 25
              }, this);
            }) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 255,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 253,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Card, { id: "run-files", className: "scroll-mt-4 p-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 text-sm font-medium text-foreground", children: "Files changed" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 291,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: (inspector.fileChanges ?? []).length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "No structured file changes recorded." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 293,
              columnNumber: 69
            }, this) : inspector.fileChanges.map(
              (change) => /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-[var(--panel-line)] bg-background/30 px-3 py-3 text-sm", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-2", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-foreground", children: change.repositoryPath ?? "Unknown path" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 296,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: change.changeType }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 297,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                  lineNumber: 295,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-xs text-muted-foreground", children: [
                  "Event #",
                  change.sequenceNumber,
                  " · ",
                  change.workflowStep ?? "—"
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                  lineNumber: 299,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-1 flex flex-wrap gap-3 text-xs text-registry-accent", children: [
                  change.diffLocation ? /* @__PURE__ */ jsxDEV("span", { children: [
                    "Diff: ",
                    change.diffLocation
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 301,
                    columnNumber: 52
                  }, this) : null,
                  change.pullRequestUrl ? /* @__PURE__ */ jsxDEV("span", { children: [
                    "PR: ",
                    change.pullRequestUrl
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 302,
                    columnNumber: 54
                  }, this) : null
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                  lineNumber: 300,
                  columnNumber: 27
                }, this)
              ] }, `${change.sequenceNumber}-${change.repositoryPath}`, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                lineNumber: 294,
                columnNumber: 21
              }, this)
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 292,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 290,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
          lineNumber: 252,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsxDEV(Card, { id: "run-artifacts", className: "scroll-mt-4 p-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 text-sm font-medium text-foreground", children: "Artifacts" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 312,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: (inspector.artifacts ?? []).length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "No artifacts recorded yet." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 314,
              columnNumber: 67
            }, this) : inspector.artifacts.map((artifact) => {
              const highlighted = evidenceArtifacts.some((item) => item._id === artifact._id);
              return /* @__PURE__ */ jsxDEV("div", { className: `rounded-lg border px-3 py-3 ${highlighted ? "border-registry-accent/40 bg-registry-accent-soft" : "border-[var(--panel-line)] bg-background/30"}`, children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-foreground", children: artifact.name }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                      lineNumber: 320,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: [
                      artifact.artifactType,
                      " · ",
                      artifact.producer ?? "unknown producer"
                    ] }, void 0, true, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                      lineNumber: 321,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 319,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: new Date(artifact.createdAt).toLocaleString() }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 323,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                  lineNumber: 318,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-xs text-muted-foreground", children: [
                  "Criterion: ",
                  artifact.acceptanceCriterionId ?? "—"
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                  lineNumber: 325,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-2 flex flex-wrap gap-2", children: [
                  artifact.externalLocation ? /* @__PURE__ */ jsxDEV(Button, { asChild: true, size: "sm", variant: "outline", children: /* @__PURE__ */ jsxDEV("a", { href: artifact.externalLocation, target: "_blank", rel: "noreferrer", children: "Open" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 327,
                    columnNumber: 104
                  }, this) }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 327,
                    columnNumber: 60
                  }, this) : null,
                  artifact.repositoryPath ? /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: artifact.repositoryPath }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 328,
                    columnNumber: 58
                  }, this) : null
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                  lineNumber: 326,
                  columnNumber: 29
                }, this)
              ] }, artifact._id, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                lineNumber: 317,
                columnNumber: 25
              }, this);
            }) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 313,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 311,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 text-sm font-medium text-foreground", children: "Retry and recovery" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 337,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: (inspector.retryTimeline ?? []).length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "No retries recorded." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 339,
              columnNumber: 71
            }, this) : inspector.retryTimeline.map(
              (retry) => /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-[var(--panel-line)] bg-background/30 px-3 py-3 text-sm", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-2", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-foreground", children: [
                    "Retry ",
                    retry.retryNumber
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 342,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: retry.outcome ?? "pending" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                    lineNumber: 343,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                  lineNumber: 341,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-xs text-muted-foreground", children: [
                  "Step: ",
                  retry.workflowStep ?? "—"
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                  lineNumber: 345,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: [
                  "Reason: ",
                  retry.reason ?? "—"
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                  lineNumber: 346,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-muted-foreground", children: [
                  "Checkpoint: ",
                  retry.checkpointArtifactId ?? "—"
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                  lineNumber: 347,
                  columnNumber: 27
                }, this)
              ] }, `${retry.retryNumber}-${retry.workflowStep}`, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                lineNumber: 340,
                columnNumber: 21
              }, this)
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 338,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 336,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Card, { id: "run-receipts", className: "scroll-mt-4 p-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 text-sm font-medium text-foreground", children: "Evidence drill-down" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 354,
              columnNumber: 21
            }, this),
            verificationReceiptId || acceptanceCriterionId ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 text-sm text-muted-foreground", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                "Focused receipt: ",
                verificationReceiptId ?? "—"
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                lineNumber: 357,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                "Focused criterion: ",
                acceptanceCriterionId ?? "—"
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                lineNumber: 358,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                "Linked events: ",
                inspector.evidenceLineage?.events?.length ?? 0
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                lineNumber: 359,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                "Linked artifacts: ",
                inspector.evidenceLineage?.artifacts?.length ?? 0
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
                lineNumber: 360,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 356,
              columnNumber: 19
            }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "Open this inspector from a verification receipt to jump straight to evidence lineage." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
              lineNumber: 363,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
            lineNumber: 353,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
          lineNumber: 310,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
        lineNumber: 251,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
      lineNumber: 96,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
      lineNumber: 90,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
    lineNumber: 82,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
    lineNumber: 81,
    columnNumber: 5
  }, this);
}
_s(ExecutionRunInspector, "HHlONfyualLHmZATiivkMZTaSbk=", false, function() {
  return [useQuery, useQuery];
});
_c = ExecutionRunInspector;
function Meta({ label, value }) {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground", children: label }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
      lineNumber: 379,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-sm text-foreground", children: value ?? "—" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
      lineNumber: 380,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
    lineNumber: 378,
    columnNumber: 5
  }, this);
}
_c2 = Meta;
function GraphMeta({ label, value }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-3", children: [
    /* @__PURE__ */ jsxDEV("dt", { className: "text-muted-foreground", children: label }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
      lineNumber: 388,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("dd", { className: "text-right text-foreground/85", children: value }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
      lineNumber: 389,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx",
    lineNumber: 387,
    columnNumber: 5
  }, this);
}
_c3 = GraphMeta;
var _c, _c2, _c3;
$RefreshReg$(_c, "ExecutionRunInspector");
$RefreshReg$(_c2, "Meta");
$RefreshReg$(_c3, "GraphMeta");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/ExecutionRunInspector.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0VVOzs7Ozs7Ozs7Ozs7Ozs7OztBQWhFVixTQUFTQSxlQUFlO0FBQ3hCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxXQUFXO0FBRXBCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLFFBQVFDLGVBQWVDLG1CQUFtQkMsY0FBY0MsbUJBQW1CO0FBQ3BGLFNBQVNDLHFCQUFxQkMsc0JBQXNCQywrQkFBK0I7QUFDbkYsU0FBU0Msd0JBQXdCO0FBQ2pDLFNBQVNDLDRCQUF1RDtBQUV6RCxnQkFBU0Msc0JBQXNCO0FBQUEsRUFDcENDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLFdBQVc7QUFBQSxFQUNYQztBQUFBQSxFQUNBQztBQWVGLEdBQUc7QUFBQUMsS0FBQTtBQUNELFFBQU1DLFlBQVl4QjtBQUFBQSxJQUNoQkMsSUFBSXdCLGFBQWFDO0FBQUFBLElBQ2pCVixRQUFRQyxnQkFDSjtBQUFBLE1BQ0VBO0FBQUFBLE1BQ0FDLHVCQUF1QkEseUJBQXlCUztBQUFBQSxNQUNoRFIsdUJBQXVCQSx5QkFBeUJRO0FBQUFBLElBQ2xELElBQ0E7QUFBQSxFQUNOO0FBQ0EsUUFBTUMsa0JBQWtCNUI7QUFBQUEsSUFDdEJDLElBQUk0QixzQkFBc0JDO0FBQUFBLElBQzFCZCxRQUFRQyxnQkFBZ0IsRUFBRUEsY0FBYyxJQUFJO0FBQUEsRUFDOUM7QUFFQSxRQUFNYyxnQkFBZ0JoQyxRQUFRLE1BQU1XLG9CQUFxQmMsV0FBV1EsVUFBVSxFQUFVLEdBQUcsQ0FBQ1IsV0FBV1EsTUFBTSxDQUFDO0FBQzlHLFFBQU1DLFlBQVlsQyxRQUFRLE1BQU1ZLHFCQUFzQmEsV0FBV1EsVUFBVSxFQUFVLEdBQUcsQ0FBQ1IsV0FBV1EsTUFBTSxDQUFDO0FBQzNHLFFBQU1FLG9CQUFvQm5DO0FBQUFBLElBQ3hCLE1BQU1hLHdCQUF5QlksV0FBV1csYUFBYSxJQUFZLEVBQUVqQix1QkFBdUJBLHlCQUF5QlMsUUFBV1IsdUJBQXVCQSx5QkFBeUJRLE9BQVUsQ0FBQztBQUFBLElBQzNMLENBQUNILFdBQVdXLFdBQVdqQix1QkFBdUJDLHFCQUFxQjtBQUFBLEVBQ3JFO0FBQ0EsUUFBTWlCLG9CQUFvQkEsQ0FBQ0MsV0FBMkM7QUFDcEVDLGFBQVNDLGVBQWUsT0FBT0YsTUFBTSxFQUFFLEdBQUdHLGVBQWUsRUFBRUMsVUFBVSxVQUFVQyxPQUFPLFFBQVEsQ0FBQztBQUFBLEVBQ2pHO0FBRUEsU0FDRSx1QkFBQyxVQUFPLE1BQVksY0FBYyxDQUFDQyxTQUFTLENBQUNBLFFBQVFyQixRQUFRLEdBQzNELGlDQUFDLGlCQUFjLFdBQVUsbURBQ3ZCO0FBQUEsMkJBQUMsZ0JBQWEsV0FBVSxpREFDdEI7QUFBQSw2QkFBQyxlQUFZLHVDQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0M7QUFBQSxNQUNwQyx1QkFBQyxxQkFBa0IsV0FBVSxXQUFTLG9IQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLG9DQUNaLFdBQUNMLGdCQUNBLHVCQUFDLFFBQUssV0FBVSxxQ0FBb0Msd0NBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEUsSUFDMUUsQ0FBQ08sWUFDSCx1QkFBQyxRQUFLLFdBQVUscUNBQW9DLHNDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBFLElBRTFFLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsNkJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUsb0RBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHlDQUF5Q0Esb0JBQVVvQixJQUFJQyxTQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RTtBQUFBLFlBQzVFLHVCQUFDLFNBQUksV0FBVSxzQ0FBc0NyQixvQkFBVXNCLFdBQVdDLFNBQVN2QixVQUFVb0IsSUFBSUksZ0JBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThHO0FBQUEsZUFGaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsbUNBQUMsU0FBTSxTQUFRLFdBQVd4QixvQkFBVW9CLElBQUlLLFVBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStDO0FBQUEsWUFDL0MsdUJBQUMsU0FBTSxTQUFRLFdBQVd6QixvQkFBVW9CLElBQUlNLGNBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1EO0FBQUEsZUFGckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUseURBQ2I7QUFBQSxpQ0FBQyxRQUFLLE9BQU0sYUFBWSxPQUFPMUIsVUFBVXNCLFdBQVdLLE9BQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdEO0FBQUEsVUFDeEQsdUJBQUMsUUFBSyxPQUFNLG1CQUFrQixPQUFPLENBQUMzQixVQUFVb0IsSUFBSVEsU0FBUzVCLFVBQVVvQixJQUFJUyxLQUFLLEVBQUVDLE9BQU9DLE9BQU8sRUFBRUMsS0FBSyxLQUFLLEtBQUssT0FBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUg7QUFBQSxVQUNySCx1QkFBQyxRQUFLLE9BQU0sZ0JBQWUsT0FBT2hDLFVBQVVpQyxRQUFRQyxlQUFlLE9BQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVFO0FBQUEsVUFDdkUsdUJBQUMsUUFBSyxPQUFNLGVBQWMsT0FBTyxHQUFHbEMsVUFBVWlDLFFBQVFFLFVBQVUsTUFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUU7QUFBQSxVQUNuRSx1QkFBQyxRQUFLLE9BQU0sV0FBVSxPQUFPLElBQUlDLEtBQUtwQyxVQUFVb0IsSUFBSWlCLFNBQVMsRUFBRUMsZUFBZSxLQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRjtBQUFBLFVBQ2hGLHVCQUFDLFFBQUssT0FBTSxZQUFXLE9BQU8sR0FBR0MsS0FBS0MsSUFBSSxHQUFHRCxLQUFLRSxNQUFNekMsVUFBVWlDLFFBQVFTLGFBQWEsR0FBSSxDQUFDLENBQUMsT0FBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUc7QUFBQSxVQUNqRyx1QkFBQyxRQUFLLE9BQU0sa0JBQWlCLE9BQU8xQyxVQUFVaUMsUUFBUVUsaUJBQWlCLE9BQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsVUFDM0UsdUJBQUMsUUFBSyxPQUFNLHNCQUFxQixPQUFPbEMsY0FBY1QsVUFBVWlDLFFBQVFXLDRCQUE0QixhQUFhLG1CQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpSTtBQUFBLGFBUm5JO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFdBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxNQUVBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG9EQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFNBQUksV0FBVSx1Q0FBc0Msc0NBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJFO0FBQUEsWUFDM0UsdUJBQUMsU0FBSSxXQUFVLHNDQUFvQyw2RUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsU0FBTSxTQUFRLFdBQ1p4QywyQkFBaUJ5QyxRQUFRLDRCQUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUNDekMsa0JBQ0MsdUJBQUMsU0FBSSxXQUFVLHlEQUNiO0FBQUEsaUNBQUMsUUFBSyxPQUFNLGtCQUFpQixPQUFPQSxnQkFBZ0IwQyxtQkFBbUIsbUJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVGO0FBQUEsVUFDdkYsdUJBQUMsUUFBSyxPQUFNLFlBQVcsT0FBTzFDLGdCQUFnQjJDLG9CQUFvQixPQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRTtBQUFBLFVBQ3RFLHVCQUFDLFFBQUssT0FBTSxVQUFTLE9BQU8zQyxnQkFBZ0I0QyxVQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRDtBQUFBLFVBQ25ELHVCQUFDLFFBQUssT0FBTSxrQkFBaUIsT0FBTyxJQUFJNUMsZ0JBQWdCNkMsYUFBYSxNQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RTtBQUFBLFVBQ3hFLHVCQUFDLFNBQUksV0FBVSwrQkFDYixpQ0FBQyxRQUFLLE9BQU0sZUFBYyxPQUFPN0MsZ0JBQWdCOEMsZUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkQsS0FEL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBLElBRUEsdUJBQUMsT0FBRSxXQUFVLHNDQUFvQyw4RkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0F6Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJCQTtBQUFBLE1BRUNsRCxVQUFVb0IsSUFBSUssV0FBVyxXQUN4QjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBT3pCLFVBQVVvQixJQUFJQztBQUFBQSxVQUNyQixnQkFBZ0JyQixVQUFVaUMsUUFBUWtCO0FBQUFBLFVBQ2xDLE1BQU12RDtBQUFBQSxVQUNOLFNBQVNDLG1CQUNMLENBQUN1RCxXQUFXdkQsaUJBQWlCO0FBQUEsWUFDM0JKLGVBQWVPLFVBQVVvQixJQUFJTztBQUFBQSxZQUM3QnlCO0FBQUFBLFlBQ0F4QixTQUFTNUIsVUFBVW9CLElBQUlRO0FBQUFBLFlBQ3ZCQyxPQUFPN0IsVUFBVW9CLElBQUlTO0FBQUFBLFlBQ3JCd0IsVUFBVXJELFVBQVVvQixJQUFJaUM7QUFBQUEsVUFDMUIsQ0FBQyxJQUNEbEQ7QUFBQUE7QUFBQUEsUUFaTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFZZ0IsSUFFZDtBQUFBLE1BRUo7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFFBQVNILFVBQVVzRCw2QkFBNkI7QUFBQSxVQUNoRCxZQUFZMUM7QUFBQUE7QUFBQUEsUUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFZ0M7QUFBQSxNQUdoQyx1QkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLCtCQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsdUNBQXNDLHlDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RTtBQUFBLFlBQzlFLHVCQUFDLFNBQUksV0FBVSxzQ0FBb0MsK0ZBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLFNBQU0sU0FBUSxXQUNaWixvQkFBVXVELGNBQWNDLGdCQUFnQixvQkFBb0IsNEJBRC9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHlEQUNiO0FBQUEsaUNBQUMsUUFBSyxPQUFNLGtCQUFpQixPQUFPeEQsVUFBVXVELGNBQWNFLGlCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRTtBQUFBLFVBQzFFLHVCQUFDLFFBQUssT0FBTSxVQUFTLE9BQU96RCxVQUFVdUQsY0FBYzlCLFVBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJEO0FBQUEsVUFDM0QsdUJBQUMsUUFBSyxPQUFNLHNCQUFxQixPQUFPLEdBQUd6QixVQUFVdUQsY0FBY0csUUFBUSxNQUFNMUQsVUFBVXVELGNBQWNJLE9BQU8sTUFBaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUg7QUFBQSxVQUNuSCx1QkFBQyxRQUFLLE9BQU0sWUFBVyxPQUFPLEdBQUdwQixLQUFLQyxJQUFJLEdBQUdELEtBQUtFLE1BQU16QyxVQUFVdUQsY0FBY2IsYUFBYSxHQUFJLENBQUMsQ0FBQyxPQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RztBQUFBLFVBQ3ZHLHVCQUFDLFFBQUssT0FBTSxnQkFBZSxPQUFPMUMsVUFBVXVELGNBQWNLLFlBQVl0QixlQUFlLEtBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVGO0FBQUEsVUFDdkYsdUJBQUMsUUFBSyxPQUFNLGlCQUFnQixPQUFPdEMsVUFBVXVELGNBQWNNLGFBQWF2QixlQUFlLEtBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlGO0FBQUEsVUFDekYsdUJBQUMsUUFBSyxPQUFNLFFBQU8sT0FBTyxJQUFJdEMsVUFBVXVELGNBQWNPLFFBQVFDLFFBQVEsQ0FBQyxDQUFDLE1BQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsYUFQN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCQTtBQUFBLE1BRUEsdUJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUscURBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHVDQUFzQyxvQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUU7QUFBQSxZQUN6RSx1QkFBQyxTQUFJLFdBQVUsc0NBQW9DLG9GQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxtQ0FBQyxTQUFNLFNBQVEsV0FBVy9ELG9CQUFVb0IsSUFBSTRDLFlBQVksWUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkQ7QUFBQSxZQUM3RCx1QkFBQyxTQUFNLFNBQVEsV0FBUztBQUFBO0FBQUEsY0FDTGhFLFVBQVVvQixJQUFJNkMsa0JBQWtCO0FBQUEsaUJBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQU0sU0FBUSxXQUNYakU7QUFBQUEseUJBQVVvQixJQUFJOEMsU0FBUyxJQUFJcEM7QUFBQUEsZ0JBQU8sQ0FBQ3FDLFNBQ25DLENBQUMsUUFBUSxTQUFTLEVBQUVDLFNBQVNELEtBQUsxQyxNQUFNO0FBQUEsY0FDMUMsRUFBRTRDO0FBQUFBLGNBQU07QUFBQSxjQUNOckUsVUFBVW9CLElBQUk4QyxPQUFPRyxVQUFVO0FBQUEsY0FBRTtBQUFBLGlCQUpyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsYUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFFBQ0EsdUJBQUMsUUFBRyxXQUFVLGlEQUNWckUscUJBQVVvQixJQUFJOEMsU0FBUyxJQUFJSTtBQUFBQSxVQUFJLENBQUNILE1BQVdJLFVBQzNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHlDQUFDLFNBQ0M7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsaUVBQStEO0FBQUE7QUFBQSxzQkFDdEVBLFFBQVE7QUFBQSx5QkFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSwwQ0FDWkosZUFBS0ssVUFEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBLGtCQUNBLHVCQUFDLFNBQU0sU0FBUSxXQUFXTCxlQUFLMUMsVUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0M7QUFBQSxxQkFUeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUNBLHVCQUFDLFFBQUcsV0FBVSw0QkFDWjtBQUFBLHlDQUFDLGFBQVUsT0FBTSxRQUFPLE9BQU8wQyxLQUFLTSxRQUFRLFdBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9EO0FBQUEsa0JBQ3BEO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU07QUFBQSxzQkFDTixPQUFPTixLQUFLTyxXQUFXTCxTQUFTRixLQUFLTyxVQUFVMUMsS0FBSyxJQUFJLElBQUk7QUFBQTtBQUFBLG9CQUY5RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRStFO0FBQUEsa0JBRS9FLHVCQUFDLGFBQVUsT0FBTSxhQUFZLE9BQU9tQyxLQUFLUSxhQUFhLFlBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStEO0FBQUEsa0JBQy9ELHVCQUFDLGFBQVUsT0FBTSxXQUFVLE9BQU9SLEtBQUtTLGlCQUFpQixXQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnRTtBQUFBLHFCQVBsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVFBO0FBQUEsZ0JBQ0NULEtBQUtVLFFBQ0osdUJBQUMsU0FBSSxXQUFVLCtFQUNaVixlQUFLVSxTQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUEsSUFDRTtBQUFBO0FBQUE7QUFBQSxZQTNCQ1YsS0FBS0s7QUFBQUEsWUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBNkJBO0FBQUEsUUFDRCxLQWhDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUNBO0FBQUEsV0F0REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVEQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxRQUFLLElBQUcsZ0JBQWUsV0FBVSxtQkFDaEM7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsNENBQTJDLHdCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRTtBQUFBLFlBQ2xFLHVCQUFDLFNBQUksV0FBVSxhQUNaakUsd0JBQWM4RCxXQUFXLElBQUksdUJBQUMsT0FBRSxXQUFVLGlDQUFnQyxzREFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUYsSUFBTzlELGNBQWMrRCxJQUFJLENBQUNRLFVBQWU7QUFDeEosb0JBQU1DLGNBQWVyRix5QkFBeUJvRixNQUFNcEYsMEJBQTBCQSx5QkFDeEVDLHlCQUF5Qm1GLE1BQU1FLFVBQVVyRiwwQkFBMEJBO0FBQ3pFLHFCQUNFLHVCQUFDLFNBQW9FLFdBQVcsK0JBQStCb0YsY0FBYyxzREFBc0QsNkNBQTZDLElBQzlOO0FBQUEsdUNBQUMsU0FBSSxXQUFVLHFEQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsMkNBQUMsU0FBTSxTQUFRLFdBQVU7QUFBQTtBQUFBLHNCQUFFRCxNQUFNRztBQUFBQSx5QkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0Q7QUFBQSxvQkFDaEQsdUJBQUMsVUFBSyxXQUFVLHVDQUF1Q0gsZ0JBQU1JLGFBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVFO0FBQUEsb0JBQ3RFSixNQUFNSyxlQUFlLHVCQUFDLFNBQU0sU0FBUSxXQUFXTCxnQkFBTUssZ0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZDLElBQVc7QUFBQSxvQkFDN0VMLE1BQU1yRCxTQUFTLHVCQUFDLFNBQU0sU0FBUSxXQUFXcUQsZ0JBQU1yRCxVQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1QyxJQUFXO0FBQUEsdUJBSnBFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsaUNBQWlDcUQsZ0JBQU1wQyxhQUFhLEdBQUdILEtBQUtFLE1BQU1xQyxNQUFNcEMsVUFBVSxDQUFDLE9BQU8sT0FBekc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkc7QUFBQSxxQkFQL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxzQ0FBc0NvQyxnQkFBTU0sa0JBQWtCTixNQUFNTyxnQkFBZ0JQLE1BQU1RLFlBQVksZ0JBQXJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtJO0FBQUEsZ0JBQ2hJUixNQUFNUSxZQUFZUixNQUFNUyxlQUFlVCxNQUFNVSxnQkFDN0MsdUJBQUMsU0FBSSxXQUFVLDJEQUNaVjtBQUFBQSx3QkFBTVEsV0FBVyx1QkFBQyxVQUFLO0FBQUE7QUFBQSxvQkFBT1IsTUFBTVE7QUFBQUEsdUJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTRCLElBQVU7QUFBQSxrQkFDdkRSLE1BQU1TLGNBQWMsdUJBQUMsVUFBSztBQUFBO0FBQUEsb0JBQVFULE1BQU1TO0FBQUFBLHVCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQyxJQUFVO0FBQUEsa0JBQzlEVCxNQUFNVSxnQkFBZ0IsdUJBQUMsVUFBSztBQUFBO0FBQUEsb0JBQVFWLE1BQU1VO0FBQUFBLHVCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrQyxJQUFVO0FBQUEscUJBSHJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUEsSUFDRTtBQUFBLGdCQUNIVixNQUFNRSxXQUNMLHVCQUFDLGFBQVEsV0FBVSxzQ0FDakI7QUFBQSx5Q0FBQyxhQUFRLFdBQVUsa0JBQWlCLDRCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnRDtBQUFBLGtCQUNoRCx1QkFBQyxTQUFJLFdBQVUscURBQXFEUyxlQUFLQyxVQUFVWixNQUFNRSxVQUFVLE1BQU0sQ0FBQyxLQUExRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0RztBQUFBLHFCQUY5RztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBLElBQ0U7QUFBQSxtQkF2QklGLE1BQU1uRCxPQUFPLEdBQUdtRCxNQUFNRyxjQUFjLElBQUlILE1BQU1JLFNBQVMsSUFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF3QkE7QUFBQSxZQUVKLENBQUMsS0EvQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQ0E7QUFBQSxlQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1DQTtBQUFBLFVBRUEsdUJBQUMsUUFBSyxJQUFHLGFBQVksV0FBVSxtQkFDN0I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsNENBQTJDLDZCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RTtBQUFBLFlBQ3ZFLHVCQUFDLFNBQUksV0FBVSxhQUNYbEYscUJBQVUyRixlQUFlLElBQUl0QixXQUFXLElBQUksdUJBQUMsT0FBRSxXQUFVLGlDQUFnQyxvREFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUYsSUFBT3JFLFVBQVUyRixZQUFZckI7QUFBQUEsY0FBSSxDQUFDc0IsV0FDL0osdUJBQUMsU0FBOEQsV0FBVSxtRkFDdkU7QUFBQSx1Q0FBQyxTQUFJLFdBQVUscURBQ2I7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsNkJBQTZCQSxpQkFBT0Msa0JBQWtCLGtCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxRjtBQUFBLGtCQUNyRix1QkFBQyxTQUFNLFNBQVEsV0FBV0QsaUJBQU9FLGNBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTRDO0FBQUEscUJBRjlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsc0NBQXFDO0FBQUE7QUFBQSxrQkFBUUYsT0FBT1g7QUFBQUEsa0JBQWU7QUFBQSxrQkFBSVcsT0FBT1QsZ0JBQWdCO0FBQUEscUJBQTdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlIO0FBQUEsZ0JBQ2pILHVCQUFDLFNBQUksV0FBVSwwREFDWlM7QUFBQUEseUJBQU9HLGVBQWUsdUJBQUMsVUFBSztBQUFBO0FBQUEsb0JBQU9ILE9BQU9HO0FBQUFBLHVCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQyxJQUFVO0FBQUEsa0JBQ2pFSCxPQUFPSSxpQkFBaUIsdUJBQUMsVUFBSztBQUFBO0FBQUEsb0JBQUtKLE9BQU9JO0FBQUFBLHVCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQyxJQUFVO0FBQUEscUJBRnRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkFUUSxHQUFHSixPQUFPWCxjQUFjLElBQUlXLE9BQU9DLGNBQWMsSUFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLFlBQ0QsS0FiSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBO0FBQUEsZUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkE7QUFBQSxhQXZERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0RBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFFBQUssSUFBRyxpQkFBZ0IsV0FBVSxtQkFDakM7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsNENBQTJDLHlCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRTtBQUFBLFlBQ25FLHVCQUFDLFNBQUksV0FBVSxhQUNYN0YscUJBQVVXLGFBQWEsSUFBSTBELFdBQVcsSUFBSSx1QkFBQyxPQUFFLFdBQVUsaUNBQWdDLDBDQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RSxJQUFPckUsVUFBVVcsVUFBVTJELElBQUksQ0FBQzJCLGFBQWtCO0FBQ25LLG9CQUFNbEIsY0FBY3JFLGtCQUFrQndGLEtBQUssQ0FBQ0MsU0FBY0EsS0FBS3hFLFFBQVFzRSxTQUFTdEUsR0FBRztBQUNuRixxQkFDRSx1QkFBQyxTQUF1QixXQUFXLCtCQUErQm9ELGNBQWMsc0RBQXNELDZDQUE2QyxJQUNqTDtBQUFBLHVDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHlDQUFDLFNBQ0M7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsdUNBQXVDa0IsbUJBQVNHLFFBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9FO0FBQUEsb0JBQ3BFLHVCQUFDLFNBQUksV0FBVSxzQ0FBc0NIO0FBQUFBLCtCQUFTSTtBQUFBQSxzQkFBYTtBQUFBLHNCQUFJSixTQUFTSyxZQUFZO0FBQUEseUJBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVIO0FBQUEsdUJBRnpIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFNLFNBQVEsV0FBVyxjQUFJbEUsS0FBSzZELFNBQVNNLFNBQVMsRUFBRWpFLGVBQWUsS0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0U7QUFBQSxxQkFMMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxzQ0FBcUM7QUFBQTtBQUFBLGtCQUFZMkQsU0FBU3RHLHlCQUF5QjtBQUFBLHFCQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzRztBQUFBLGdCQUN0Ryx1QkFBQyxTQUFJLFdBQVUsNkJBQ1pzRztBQUFBQSwyQkFBU08sbUJBQW1CLHVCQUFDLFVBQU8sU0FBTyxNQUFDLE1BQUssTUFBSyxTQUFRLFdBQVUsaUNBQUMsT0FBRSxNQUFNUCxTQUFTTyxrQkFBa0IsUUFBTyxVQUFTLEtBQUksY0FBYSxvQkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUUsS0FBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUgsSUFBWTtBQUFBLGtCQUNqS1AsU0FBU0osaUJBQWlCLHVCQUFDLFNBQU0sU0FBUSxXQUFXSSxtQkFBU0osa0JBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtELElBQVc7QUFBQSxxQkFGMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQVpRSSxTQUFTdEUsS0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFhQTtBQUFBLFlBRUosQ0FBQyxLQW5CSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLGVBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUJBO0FBQUEsVUFFQSx1QkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLG1DQUFDLFNBQUksV0FBVSw0Q0FBMkMsa0NBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRFO0FBQUEsWUFDNUUsdUJBQUMsU0FBSSxXQUFVLGFBQ1gzQixxQkFBVXlHLGlCQUFpQixJQUFJcEMsV0FBVyxJQUFJLHVCQUFDLE9BQUUsV0FBVSxpQ0FBZ0Msb0NBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlFLElBQU9yRSxVQUFVeUcsY0FBY25DO0FBQUFBLGNBQUksQ0FBQ29DLFVBQ25KLHVCQUFDLFNBQXVELFdBQVUsbUZBQ2hFO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLCtCQUE4QjtBQUFBO0FBQUEsb0JBQU9BLE1BQU1uQjtBQUFBQSx1QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUU7QUFBQSxrQkFDdkUsdUJBQUMsU0FBTSxTQUFRLFdBQVdtQixnQkFBTUMsV0FBVyxhQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxRDtBQUFBLHFCQUZ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHNDQUFxQztBQUFBO0FBQUEsa0JBQU9ELE1BQU12QixnQkFBZ0I7QUFBQSxxQkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUY7QUFBQSxnQkFDckYsdUJBQUMsU0FBSSxXQUFVLHNDQUFxQztBQUFBO0FBQUEsa0JBQVN1QixNQUFNdEQsVUFBVTtBQUFBLHFCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRjtBQUFBLGdCQUNqRix1QkFBQyxTQUFJLFdBQVUsc0NBQXFDO0FBQUE7QUFBQSxrQkFBYXNELE1BQU1FLHdCQUF3QjtBQUFBLHFCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRztBQUFBLG1CQVAzRixHQUFHRixNQUFNbkIsV0FBVyxJQUFJbUIsTUFBTXZCLFlBQVksSUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLFlBQ0QsS0FYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsZUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsVUFFQSx1QkFBQyxRQUFLLElBQUcsZ0JBQWUsV0FBVSxtQkFDaEM7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsNENBQTJDLG1DQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RTtBQUFBLFlBQzNFekYseUJBQXlCQyx3QkFDekIsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSTtBQUFBO0FBQUEsZ0JBQWtCRCx5QkFBeUI7QUFBQSxtQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0Q7QUFBQSxjQUNwRCx1QkFBQyxTQUFJO0FBQUE7QUFBQSxnQkFBb0JDLHlCQUF5QjtBQUFBLG1CQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRDtBQUFBLGNBQ3RELHVCQUFDLFNBQUk7QUFBQTtBQUFBLGdCQUFnQkssVUFBVTZHLGlCQUFpQnJHLFFBQVE2RCxVQUFVO0FBQUEsbUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9FO0FBQUEsY0FDcEUsdUJBQUMsU0FBSTtBQUFBO0FBQUEsZ0JBQW1CckUsVUFBVTZHLGlCQUFpQmxHLFdBQVcwRCxVQUFVO0FBQUEsbUJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBFO0FBQUEsaUJBSjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0EsSUFFQSx1QkFBQyxPQUFFLFdBQVUsaUNBQWdDLHFHQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrSTtBQUFBLGVBVnRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxhQXZERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0RBO0FBQUEsV0FuSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9IQTtBQUFBLFNBL1FGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnUkEsS0F0Uko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdSQTtBQUFBLE9BaFNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpU0EsS0FsU0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1TQTtBQUVKO0FBQUN0RSxHQXRWZVIsdUJBQXFCO0FBQUEsVUF1QmpCZixVQVVNQSxRQUFRO0FBQUE7QUFBQSxLQWpDbEJlO0FBd1ZoQixTQUFTdUgsS0FBSyxFQUFFQyxPQUFPQyxNQUFnRCxHQUFHO0FBQ3hFLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFNBQUksV0FBVSxpRUFBaUVELG1CQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNGO0FBQUEsSUFDdEYsdUJBQUMsU0FBSSxXQUFVLGdDQUFnQ0MsbUJBQVMsT0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0RDtBQUFBLE9BRjlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQTtBQUVKO0FBQUNDLE1BUFFIO0FBU1QsU0FBU0ksVUFBVSxFQUFFSCxPQUFPQyxNQUF3QyxHQUFHO0FBQ3JFLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsMkJBQUMsUUFBRyxXQUFVLHlCQUF5QkQsbUJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkM7QUFBQSxJQUM3Qyx1QkFBQyxRQUFHLFdBQVUsaUNBQWlDQyxtQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRDtBQUFBLE9BRnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQTtBQUVKO0FBQUNHLE1BUFFEO0FBQVMsSUFBQUUsSUFBQUgsS0FBQUU7QUFBQSxhQUFBQyxJQUFBO0FBQUEsYUFBQUgsS0FBQTtBQUFBLGFBQUFFLEtBQUEiLCJuYW1lcyI6WyJ1c2VNZW1vIiwidXNlUXVlcnkiLCJhcGkiLCJCYWRnZSIsIkJ1dHRvbiIsIkNhcmQiLCJEaWFsb2ciLCJEaWFsb2dDb250ZW50IiwiRGlhbG9nRGVzY3JpcHRpb24iLCJEaWFsb2dIZWFkZXIiLCJEaWFsb2dUaXRsZSIsIm9yZGVyVGltZWxpbmVFdmVudHMiLCJsYXRlc3RIdW1hbkF0dGVudGlvbiIsImZpbHRlckV2aWRlbmNlQXJ0aWZhY3RzIiwiUnVuUmVjb3ZlcnlQYW5lbCIsIkV2aWRlbmNlTGluZWFnZVBhbmVsIiwiRXhlY3V0aW9uUnVuSW5zcGVjdG9yIiwib3BlbiIsIndvcmtmbG93UnVuSWQiLCJ2ZXJpZmljYXRpb25SZWNlaXB0SWQiLCJhY2NlcHRhbmNlQ3JpdGVyaW9uSWQiLCJyZXRyeWluZyIsIm9uUmV0cnlGYWlsZWRSdW4iLCJvbkNsb3NlIiwiX3MiLCJpbnNwZWN0b3IiLCJ3b3JrZmxvd1J1bnMiLCJnZXRJbnNwZWN0b3IiLCJ1bmRlZmluZWQiLCJyb3V0aW5nRGVjaXNpb24iLCJtb2RlbFJvdXRpbmdEZWNpc2lvbnMiLCJnZXRGb3JXb3JrZmxvd1J1biIsIm9yZGVyZWRFdmVudHMiLCJldmVudHMiLCJhdHRlbnRpb24iLCJldmlkZW5jZUFydGlmYWN0cyIsImFydGlmYWN0cyIsIm5hdmlnYXRlVG9SZWNvcmRzIiwidGFyZ2V0IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInNjcm9sbEludG9WaWV3IiwiYmVoYXZpb3IiLCJibG9jayIsIm5leHQiLCJydW4iLCJydW5JZCIsIndvcmtPcmRlciIsInRpdGxlIiwiaW5pdGlhbElucHV0Iiwic3RhdHVzIiwid29ya2Zsb3dJZCIsIl9pZCIsInJ1bnRpbWUiLCJtb2RlbCIsImZpbHRlciIsIkJvb2xlYW4iLCJqb2luIiwic3VtbWFyeSIsImN1cnJlbnRTdGVwIiwicmV0cnlDb3VudCIsIkRhdGUiLCJzdGFydGVkQXQiLCJ0b0xvY2FsZVN0cmluZyIsIk1hdGgiLCJtYXgiLCJyb3VuZCIsImR1cmF0aW9uTXMiLCJibG9ja2luZ0lzc3VlIiwiaHVtYW5JbnRlcnZlbnRpb25SZXF1aXJlZCIsIm1vZGUiLCJzZWxlY3RlZE1vZGVsSWQiLCJzZWxlY3RlZFByb3ZpZGVyIiwic291cmNlIiwicG9saWN5VmVyc2lvbiIsImV4cGxhbmF0aW9uIiwiZmFpbHVyZVN1bW1hcnkiLCJyZWFzb24iLCJ3b3JrdHJlZSIsImNvbnRpbnVvdXNFdmlkZW5jZUxpbmVhZ2UiLCJvYnNlcnZhYmlsaXR5IiwidXNhZ2VDb21wbGV0ZSIsImNvcnJlbGF0aW9uSWQiLCJhdHRlbXB0cyIsInJldHJpZXMiLCJpbnB1dFRva2VucyIsIm91dHB1dFRva2VucyIsImNvc3RVc2QiLCJ0b0ZpeGVkIiwidG9wb2xvZ3kiLCJtYXhDb25jdXJyZW5jeSIsInN0ZXBzIiwic3RlcCIsImluY2x1ZGVzIiwibGVuZ3RoIiwibWFwIiwiaW5kZXgiLCJzdGVwSWQiLCJraW5kIiwiZGVwZW5kc09uIiwiaXNvbGF0aW9uIiwiZmFpbHVyZVBvbGljeSIsImVycm9yIiwiZXZlbnQiLCJoaWdobGlnaHRlZCIsIm1ldGFkYXRhIiwic2VxdWVuY2VOdW1iZXIiLCJldmVudFR5cGUiLCJ3b3JrZmxvd1N0ZXAiLCJjb21tYW5kU3VtbWFyeSIsImVycm9yU3VtbWFyeSIsInRvb2xOYW1lIiwicmV0cnlOdW1iZXIiLCJlcnJvckNhdGVnb3J5IiwiSlNPTiIsInN0cmluZ2lmeSIsImZpbGVDaGFuZ2VzIiwiY2hhbmdlIiwicmVwb3NpdG9yeVBhdGgiLCJjaGFuZ2VUeXBlIiwiZGlmZkxvY2F0aW9uIiwicHVsbFJlcXVlc3RVcmwiLCJhcnRpZmFjdCIsInNvbWUiLCJpdGVtIiwibmFtZSIsImFydGlmYWN0VHlwZSIsInByb2R1Y2VyIiwiY3JlYXRlZEF0IiwiZXh0ZXJuYWxMb2NhdGlvbiIsInJldHJ5VGltZWxpbmUiLCJyZXRyeSIsIm91dGNvbWUiLCJjaGVja3BvaW50QXJ0aWZhY3RJZCIsImV2aWRlbmNlTGluZWFnZSIsIk1ldGEiLCJsYWJlbCIsInZhbHVlIiwiX2MyIiwiR3JhcGhNZXRhIiwiX2MzIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRXhlY3V0aW9uUnVuSW5zcGVjdG9yLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VNZW1vIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB0eXBlIHsgSWQgfSBmcm9tIFwiLi4vLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvZGF0YU1vZGVsXCI7XG5pbXBvcnQgeyBCYWRnZSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYmFkZ2VcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQgeyBDYXJkIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9jYXJkXCI7XG5pbXBvcnQgeyBEaWFsb2csIERpYWxvZ0NvbnRlbnQsIERpYWxvZ0Rlc2NyaXB0aW9uLCBEaWFsb2dIZWFkZXIsIERpYWxvZ1RpdGxlIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9kaWFsb2dcIjtcbmltcG9ydCB7IG9yZGVyVGltZWxpbmVFdmVudHMsIGxhdGVzdEh1bWFuQXR0ZW50aW9uLCBmaWx0ZXJFdmlkZW5jZUFydGlmYWN0cyB9IGZyb20gXCIuL3J1bkluc3BlY3Rvck1vZGVsXCI7XG5pbXBvcnQgeyBSdW5SZWNvdmVyeVBhbmVsIH0gZnJvbSBcIi4vUnVuUmVjb3ZlcnlQYW5lbFwiO1xuaW1wb3J0IHsgRXZpZGVuY2VMaW5lYWdlUGFuZWwsIHR5cGUgRXZpZGVuY2VMaW5lYWdlU3RhZ2UgfSBmcm9tIFwiLi9FdmlkZW5jZUxpbmVhZ2VQYW5lbFwiO1xuXG5leHBvcnQgZnVuY3Rpb24gRXhlY3V0aW9uUnVuSW5zcGVjdG9yKHtcbiAgb3BlbixcbiAgd29ya2Zsb3dSdW5JZCxcbiAgdmVyaWZpY2F0aW9uUmVjZWlwdElkLFxuICBhY2NlcHRhbmNlQ3JpdGVyaW9uSWQsXG4gIHJldHJ5aW5nID0gZmFsc2UsXG4gIG9uUmV0cnlGYWlsZWRSdW4sXG4gIG9uQ2xvc2UsXG59OiB7XG4gIG9wZW46IGJvb2xlYW47XG4gIHdvcmtmbG93UnVuSWQ6IElkPFwid29ya2Zsb3dSdW5zXCI+IHwgbnVsbDtcbiAgdmVyaWZpY2F0aW9uUmVjZWlwdElkPzogSWQ8XCJ2ZXJpZmljYXRpb25SZWNlaXB0c1wiPiB8IG51bGw7XG4gIGFjY2VwdGFuY2VDcml0ZXJpb25JZD86IHN0cmluZyB8IG51bGw7XG4gIHJldHJ5aW5nPzogYm9vbGVhbjtcbiAgb25SZXRyeUZhaWxlZFJ1bj86IChpbnB1dDoge1xuICAgIHdvcmtmbG93UnVuSWQ6IElkPFwid29ya2Zsb3dSdW5zXCI+O1xuICAgIHJlYXNvbjogc3RyaW5nO1xuICAgIHJ1bnRpbWU/OiBzdHJpbmc7XG4gICAgbW9kZWw/OiBzdHJpbmc7XG4gICAgd29ya3RyZWU/OiBzdHJpbmc7XG4gIH0pID0+IFByb21pc2U8dm9pZD47XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG59KSB7XG4gIGNvbnN0IGluc3BlY3RvciA9IHVzZVF1ZXJ5KFxuICAgIGFwaS53b3JrZmxvd1J1bnMuZ2V0SW5zcGVjdG9yLFxuICAgIG9wZW4gJiYgd29ya2Zsb3dSdW5JZFxuICAgICAgPyB7XG4gICAgICAgICAgd29ya2Zsb3dSdW5JZCxcbiAgICAgICAgICB2ZXJpZmljYXRpb25SZWNlaXB0SWQ6IHZlcmlmaWNhdGlvblJlY2VpcHRJZCA/PyB1bmRlZmluZWQsXG4gICAgICAgICAgYWNjZXB0YW5jZUNyaXRlcmlvbklkOiBhY2NlcHRhbmNlQ3JpdGVyaW9uSWQgPz8gdW5kZWZpbmVkLFxuICAgICAgICB9XG4gICAgICA6IFwic2tpcFwiXG4gICk7XG4gIGNvbnN0IHJvdXRpbmdEZWNpc2lvbiA9IHVzZVF1ZXJ5KFxuICAgIGFwaS5tb2RlbFJvdXRpbmdEZWNpc2lvbnMuZ2V0Rm9yV29ya2Zsb3dSdW4sXG4gICAgb3BlbiAmJiB3b3JrZmxvd1J1bklkID8geyB3b3JrZmxvd1J1bklkIH0gOiBcInNraXBcIlxuICApO1xuXG4gIGNvbnN0IG9yZGVyZWRFdmVudHMgPSB1c2VNZW1vKCgpID0+IG9yZGVyVGltZWxpbmVFdmVudHMoKGluc3BlY3Rvcj8uZXZlbnRzID8/IFtdKSBhcyBhbnkpLCBbaW5zcGVjdG9yPy5ldmVudHNdKTtcbiAgY29uc3QgYXR0ZW50aW9uID0gdXNlTWVtbygoKSA9PiBsYXRlc3RIdW1hbkF0dGVudGlvbigoaW5zcGVjdG9yPy5ldmVudHMgPz8gW10pIGFzIGFueSksIFtpbnNwZWN0b3I/LmV2ZW50c10pO1xuICBjb25zdCBldmlkZW5jZUFydGlmYWN0cyA9IHVzZU1lbW8oXG4gICAgKCkgPT4gZmlsdGVyRXZpZGVuY2VBcnRpZmFjdHMoKGluc3BlY3Rvcj8uYXJ0aWZhY3RzID8/IFtdKSBhcyBhbnksIHsgdmVyaWZpY2F0aW9uUmVjZWlwdElkOiB2ZXJpZmljYXRpb25SZWNlaXB0SWQgPz8gdW5kZWZpbmVkLCBhY2NlcHRhbmNlQ3JpdGVyaW9uSWQ6IGFjY2VwdGFuY2VDcml0ZXJpb25JZCA/PyB1bmRlZmluZWQgfSksXG4gICAgW2luc3BlY3Rvcj8uYXJ0aWZhY3RzLCB2ZXJpZmljYXRpb25SZWNlaXB0SWQsIGFjY2VwdGFuY2VDcml0ZXJpb25JZF1cbiAgKTtcbiAgY29uc3QgbmF2aWdhdGVUb1JlY29yZHMgPSAodGFyZ2V0OiBFdmlkZW5jZUxpbmVhZ2VTdGFnZVtcInRhcmdldFwiXSkgPT4ge1xuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGBydW4tJHt0YXJnZXR9YCk/LnNjcm9sbEludG9WaWV3KHsgYmVoYXZpb3I6IFwic21vb3RoXCIsIGJsb2NrOiBcInN0YXJ0XCIgfSk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8RGlhbG9nIG9wZW49e29wZW59IG9uT3BlbkNoYW5nZT17KG5leHQpID0+ICFuZXh0ICYmIG9uQ2xvc2UoKX0+XG4gICAgICA8RGlhbG9nQ29udGVudCBjbGFzc05hbWU9XCJtYXgtaC1bOTB2aF0gbWF4LXctWzExMDBweF0gb3ZlcmZsb3ctaGlkZGVuIHAtMFwiPlxuICAgICAgICA8RGlhbG9nSGVhZGVyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1bdmFyKC0tcGFuZWwtbGluZSldIHB4LTYgcHktNFwiPlxuICAgICAgICAgIDxEaWFsb2dUaXRsZT5FeGVjdXRpb24gUnVuIEluc3BlY3RvcjwvRGlhbG9nVGl0bGU+XG4gICAgICAgICAgPERpYWxvZ0Rlc2NyaXB0aW9uIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5cbiAgICAgICAgICAgIEluc3BlY3QgZXhlY3V0aW9uIHN0YXRlLCBjb250aW51b3VzIGV2aWRlbmNlIGxpbmVhZ2UsIGFydGlmYWN0cywgdmVyaWZpY2F0aW9uLCBhbmQgcmVjb3ZlcnkgaGlzdG9yeS5cbiAgICAgICAgICA8L0RpYWxvZ0Rlc2NyaXB0aW9uPlxuICAgICAgICA8L0RpYWxvZ0hlYWRlcj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC1oLVs4MHZoXSBvdmVyZmxvdy15LWF1dG8gcC02XCI+XG4gICAgICAgICAgeyF3b3JrZmxvd1J1bklkID8gKFxuICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC02IHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+U2VsZWN0IGEgcnVuIHRvIGluc3BlY3QuPC9DYXJkPlxuICAgICAgICAgICkgOiAhaW5zcGVjdG9yID8gKFxuICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC02IHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+TG9hZGluZyBydW4gaW5zcGVjdG9y4oCmPC9DYXJkPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+e2luc3BlY3Rvci5ydW4ucnVuSWR9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntpbnNwZWN0b3Iud29ya09yZGVyPy50aXRsZSA/PyBpbnNwZWN0b3IucnVuLmluaXRpYWxJbnB1dH08L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cIm91dGxpbmVcIj57aW5zcGVjdG9yLnJ1bi5zdGF0dXN9PC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCI+e2luc3BlY3Rvci5ydW4ud29ya2Zsb3dJZH08L0JhZGdlPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IGdyaWQgZ2FwLTMgdGV4dC1zbSBtZDpncmlkLWNvbHMtMiB4bDpncmlkLWNvbHMtNFwiPlxuICAgICAgICAgICAgICAgICAgPE1ldGEgbGFiZWw9XCJXb3JrT3JkZXJcIiB2YWx1ZT17aW5zcGVjdG9yLndvcmtPcmRlcj8uX2lkfSAvPlxuICAgICAgICAgICAgICAgICAgPE1ldGEgbGFiZWw9XCJSdW50aW1lIC8gbW9kZWxcIiB2YWx1ZT17W2luc3BlY3Rvci5ydW4ucnVudGltZSwgaW5zcGVjdG9yLnJ1bi5tb2RlbF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgLyBcIikgfHwgXCLigJRcIn0gLz5cbiAgICAgICAgICAgICAgICAgIDxNZXRhIGxhYmVsPVwiQ3VycmVudCBzdGVwXCIgdmFsdWU9e2luc3BlY3Rvci5zdW1tYXJ5LmN1cnJlbnRTdGVwID8/IFwi4oCUXCJ9IC8+XG4gICAgICAgICAgICAgICAgICA8TWV0YSBsYWJlbD1cIlJldHJ5IGNvdW50XCIgdmFsdWU9e2Ake2luc3BlY3Rvci5zdW1tYXJ5LnJldHJ5Q291bnR9YH0gLz5cbiAgICAgICAgICAgICAgICAgIDxNZXRhIGxhYmVsPVwiU3RhcnRlZFwiIHZhbHVlPXtuZXcgRGF0ZShpbnNwZWN0b3IucnVuLnN0YXJ0ZWRBdCkudG9Mb2NhbGVTdHJpbmcoKX0gLz5cbiAgICAgICAgICAgICAgICAgIDxNZXRhIGxhYmVsPVwiRHVyYXRpb25cIiB2YWx1ZT17YCR7TWF0aC5tYXgoMCwgTWF0aC5yb3VuZChpbnNwZWN0b3Iuc3VtbWFyeS5kdXJhdGlvbk1zIC8gMTAwMCkpfXNgfSAvPlxuICAgICAgICAgICAgICAgICAgPE1ldGEgbGFiZWw9XCJCbG9ja2luZyBpc3N1ZVwiIHZhbHVlPXtpbnNwZWN0b3Iuc3VtbWFyeS5ibG9ja2luZ0lzc3VlID8/IFwi4oCUXCJ9IC8+XG4gICAgICAgICAgICAgICAgICA8TWV0YSBsYWJlbD1cIkh1bWFuIGludGVydmVudGlvblwiIHZhbHVlPXthdHRlbnRpb24gPz8gKGluc3BlY3Rvci5zdW1tYXJ5Lmh1bWFuSW50ZXJ2ZW50aW9uUmVxdWlyZWQgPyBcIlJlcXVpcmVkXCIgOiBcIk5vdCByZXF1aXJlZFwiKX0gLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9DYXJkPlxuXG4gICAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mb3JlZ3JvdW5kXCI+TW9kZWwgcm91dGluZyBldmlkZW5jZTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICBUaGUgZXhhY3QgcG9saWN5IGRlY2lzaW9uIGNhcHR1cmVkIGJlZm9yZSBwcm92aWRlciBleGVjdXRpb24uXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cIm91dGxpbmVcIj5cbiAgICAgICAgICAgICAgICAgICAge3JvdXRpbmdEZWNpc2lvbj8ubW9kZSA/PyBcIlJvdXRlIHVua25vd24gKGxlZ2FjeSlcIn1cbiAgICAgICAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAge3JvdXRpbmdEZWNpc2lvbiA/IChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBncmlkIGdhcC0zIHRleHQtc20gbWQ6Z3JpZC1jb2xzLTIgeGw6Z3JpZC1jb2xzLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPE1ldGEgbGFiZWw9XCJTZWxlY3RlZCBtb2RlbFwiIHZhbHVlPXtyb3V0aW5nRGVjaXNpb24uc2VsZWN0ZWRNb2RlbElkID8/IFwiTm8gc2FmZSByb3V0ZVwifSAvPlxuICAgICAgICAgICAgICAgICAgICA8TWV0YSBsYWJlbD1cIlByb3ZpZGVyXCIgdmFsdWU9e3JvdXRpbmdEZWNpc2lvbi5zZWxlY3RlZFByb3ZpZGVyID8/IFwi4oCUXCJ9IC8+XG4gICAgICAgICAgICAgICAgICAgIDxNZXRhIGxhYmVsPVwiU291cmNlXCIgdmFsdWU9e3JvdXRpbmdEZWNpc2lvbi5zb3VyY2V9IC8+XG4gICAgICAgICAgICAgICAgICAgIDxNZXRhIGxhYmVsPVwiUG9saWN5IHZlcnNpb25cIiB2YWx1ZT17YHYke3JvdXRpbmdEZWNpc2lvbi5wb2xpY3lWZXJzaW9ufWB9IC8+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMiB4bDpjb2wtc3Bhbi00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPE1ldGEgbGFiZWw9XCJFeHBsYW5hdGlvblwiIHZhbHVlPXtyb3V0aW5nRGVjaXNpb24uZXhwbGFuYXRpb259IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgVGhpcyBydW4gcHJlZGF0ZXMgcm91dGluZyBldmlkZW5jZSBvciB3YXMgY3JlYXRlZCBvdXRzaWRlIFdvcmsgT3JkZXIgZGlzcGF0Y2guXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9DYXJkPlxuXG4gICAgICAgICAgICAgIHtpbnNwZWN0b3IucnVuLnN0YXR1cyA9PT0gXCJGQUlMRURcIiA/IChcbiAgICAgICAgICAgICAgICA8UnVuUmVjb3ZlcnlQYW5lbFxuICAgICAgICAgICAgICAgICAgcnVuSWQ9e2luc3BlY3Rvci5ydW4ucnVuSWR9XG4gICAgICAgICAgICAgICAgICBmYWlsdXJlU3VtbWFyeT17aW5zcGVjdG9yLnN1bW1hcnkuZmFpbHVyZVN1bW1hcnl9XG4gICAgICAgICAgICAgICAgICBidXN5PXtyZXRyeWluZ31cbiAgICAgICAgICAgICAgICAgIG9uUmV0cnk9e29uUmV0cnlGYWlsZWRSdW5cbiAgICAgICAgICAgICAgICAgICAgPyAocmVhc29uKSA9PiBvblJldHJ5RmFpbGVkUnVuKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdvcmtmbG93UnVuSWQ6IGluc3BlY3Rvci5ydW4uX2lkLFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVhc29uLFxuICAgICAgICAgICAgICAgICAgICAgICAgcnVudGltZTogaW5zcGVjdG9yLnJ1bi5ydW50aW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgbW9kZWw6IGluc3BlY3Rvci5ydW4ubW9kZWwsXG4gICAgICAgICAgICAgICAgICAgICAgICB3b3JrdHJlZTogaW5zcGVjdG9yLnJ1bi53b3JrdHJlZSxcbiAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICA6IHVuZGVmaW5lZH1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICApIDogbnVsbH1cblxuICAgICAgICAgICAgICA8RXZpZGVuY2VMaW5lYWdlUGFuZWxcbiAgICAgICAgICAgICAgICBzdGFnZXM9eyhpbnNwZWN0b3IuY29udGludW91c0V2aWRlbmNlTGluZWFnZSA/PyBbXSkgYXMgRXZpZGVuY2VMaW5lYWdlU3RhZ2VbXX1cbiAgICAgICAgICAgICAgICBvbk5hdmlnYXRlPXtuYXZpZ2F0ZVRvUmVjb3Jkc31cbiAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZm9yZWdyb3VuZFwiPk9wZXJhdGlvbmFsIG9ic2VydmFiaWxpdHk8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgRml4ZWQsIG5vbi1zZW5zaXRpdmUgd29ya2Zsb3cgYW5kIHVzYWdlIHRvdGFscyBsaW5rZWQgYnkgYSB0eXBlZCBydW4gcmVmZXJlbmNlLlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCI+XG4gICAgICAgICAgICAgICAgICAgIHtpbnNwZWN0b3Iub2JzZXJ2YWJpbGl0eS51c2FnZUNvbXBsZXRlID8gXCJDb21wbGV0ZSByb2xsdXBcIiA6IFwiQm91bmRlZCBwYXJ0aWFsIHJvbGx1cFwifVxuICAgICAgICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZ3JpZCBnYXAtMyB0ZXh0LXNtIG1kOmdyaWQtY29scy0yIHhsOmdyaWQtY29scy00XCI+XG4gICAgICAgICAgICAgICAgICA8TWV0YSBsYWJlbD1cIkNvcnJlbGF0aW9uIElEXCIgdmFsdWU9e2luc3BlY3Rvci5vYnNlcnZhYmlsaXR5LmNvcnJlbGF0aW9uSWR9IC8+XG4gICAgICAgICAgICAgICAgICA8TWV0YSBsYWJlbD1cIlN0YXR1c1wiIHZhbHVlPXtpbnNwZWN0b3Iub2JzZXJ2YWJpbGl0eS5zdGF0dXN9IC8+XG4gICAgICAgICAgICAgICAgICA8TWV0YSBsYWJlbD1cIkF0dGVtcHRzIC8gcmV0cmllc1wiIHZhbHVlPXtgJHtpbnNwZWN0b3Iub2JzZXJ2YWJpbGl0eS5hdHRlbXB0c30gLyAke2luc3BlY3Rvci5vYnNlcnZhYmlsaXR5LnJldHJpZXN9YH0gLz5cbiAgICAgICAgICAgICAgICAgIDxNZXRhIGxhYmVsPVwiRHVyYXRpb25cIiB2YWx1ZT17YCR7TWF0aC5tYXgoMCwgTWF0aC5yb3VuZChpbnNwZWN0b3Iub2JzZXJ2YWJpbGl0eS5kdXJhdGlvbk1zIC8gMTAwMCkpfXNgfSAvPlxuICAgICAgICAgICAgICAgICAgPE1ldGEgbGFiZWw9XCJJbnB1dCB0b2tlbnNcIiB2YWx1ZT17aW5zcGVjdG9yLm9ic2VydmFiaWxpdHkuaW5wdXRUb2tlbnMudG9Mb2NhbGVTdHJpbmcoKX0gLz5cbiAgICAgICAgICAgICAgICAgIDxNZXRhIGxhYmVsPVwiT3V0cHV0IHRva2Vuc1wiIHZhbHVlPXtpbnNwZWN0b3Iub2JzZXJ2YWJpbGl0eS5vdXRwdXRUb2tlbnMudG9Mb2NhbGVTdHJpbmcoKX0gLz5cbiAgICAgICAgICAgICAgICAgIDxNZXRhIGxhYmVsPVwiQ29zdFwiIHZhbHVlPXtgJCR7aW5zcGVjdG9yLm9ic2VydmFiaWxpdHkuY29zdFVzZC50b0ZpeGVkKDQpfWB9IC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvQ2FyZD5cblxuICAgICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmRcIj5HcmFwaCBleGVjdXRpb24gcGxhbjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICBEZXBlbmRlbmNpZXMsIGlzb2xhdGlvbiwgYW5kIG5vZGUgc3RhdGUgZnJvbSB0aGUgZHVyYWJsZSBydW4gcmVjb3JkLlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cIm91dGxpbmVcIj57aW5zcGVjdG9yLnJ1bi50b3BvbG9neSA/PyBcIkxJTkVBUlwifTwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwib3V0bGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgIE1heCBjb25jdXJyZW5jeSB7aW5zcGVjdG9yLnJ1bi5tYXhDb25jdXJyZW5jeSA/PyAxfVxuICAgICAgICAgICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cIm91dGxpbmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7KGluc3BlY3Rvci5ydW4uc3RlcHMgPz8gW10pLmZpbHRlcigoc3RlcDogYW55KSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgW1wiRE9ORVwiLCBcIlNLSVBQRURcIl0uaW5jbHVkZXMoc3RlcC5zdGF0dXMpXG4gICAgICAgICAgICAgICAgICAgICAgKS5sZW5ndGh9XG4gICAgICAgICAgICAgICAgICAgICAgL3tpbnNwZWN0b3IucnVuLnN0ZXBzPy5sZW5ndGggPz8gMH0gY29tcGxldGVcbiAgICAgICAgICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxvbCBjbGFzc05hbWU9XCJtdC00IGdyaWQgZ2FwLTMgbWQ6Z3JpZC1jb2xzLTIgeGw6Z3JpZC1jb2xzLTNcIj5cbiAgICAgICAgICAgICAgICAgIHsoaW5zcGVjdG9yLnJ1bi5zdGVwcyA/PyBbXSkubWFwKChzdGVwOiBhbnksIGluZGV4OiBudW1iZXIpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGxpXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtzdGVwLnN0ZXBJZH1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItW3ZhcigtLXBhbmVsLWxpbmUpXSBiZy1iYWNrZ3JvdW5kLzMwIHAtM1wiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0cmFja2luZy1bMC4xNGVtXSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBOb2RlIHtpbmRleCArIDF9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgZm9udC1tb25vIHRleHQtc20gdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0ZXAuc3RlcElkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCI+e3N0ZXAuc3RhdHVzfTwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRsIGNsYXNzTmFtZT1cIm10LTMgc3BhY2UteS0xLjUgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEdyYXBoTWV0YSBsYWJlbD1cIktpbmRcIiB2YWx1ZT17c3RlcC5raW5kID8/IFwiQUdFTlRcIn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxHcmFwaE1ldGFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJEZXBlbmRzIG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3N0ZXAuZGVwZW5kc09uPy5sZW5ndGggPyBzdGVwLmRlcGVuZHNPbi5qb2luKFwiLCBcIikgOiBcIlJlYWR5IGF0IHN0YXJ0XCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEdyYXBoTWV0YSBsYWJlbD1cIklzb2xhdGlvblwiIHZhbHVlPXtzdGVwLmlzb2xhdGlvbiA/PyBcIlNIQVJFRFwifSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEdyYXBoTWV0YSBsYWJlbD1cIkZhaWx1cmVcIiB2YWx1ZT17c3RlcC5mYWlsdXJlUG9saWN5ID8/IFwiUkVUUllcIn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2RsPlxuICAgICAgICAgICAgICAgICAgICAgIHtzdGVwLmVycm9yID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1yZWQtNTAwLzIwIGJnLXJlZC01MDAvNSBwLTIgdGV4dC14cyB0ZXh0LXJlZC0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3N0ZXAuZXJyb3J9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvb2w+XG4gICAgICAgICAgICAgIDwvQ2FyZD5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTYgeGw6Z3JpZC1jb2xzLVttaW5tYXgoMCwxLjJmcilfbWlubWF4KDM2MHB4LDAuOGZyKV1cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICAgICAgPENhcmQgaWQ9XCJydW4tdGltZWxpbmVcIiBjbGFzc05hbWU9XCJzY3JvbGwtbXQtNCBwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mb3JlZ3JvdW5kXCI+VGltZWxpbmU8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7b3JkZXJlZEV2ZW50cy5sZW5ndGggPT09IDAgPyA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPk5vIHN0cnVjdHVyZWQgcnVuIGV2ZW50cyByZWNvcmRlZCB5ZXQuPC9wPiA6IG9yZGVyZWRFdmVudHMubWFwKChldmVudDogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBoaWdobGlnaHRlZCA9ICh2ZXJpZmljYXRpb25SZWNlaXB0SWQgJiYgZXZlbnQudmVyaWZpY2F0aW9uUmVjZWlwdElkID09PSB2ZXJpZmljYXRpb25SZWNlaXB0SWQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHx8IChhY2NlcHRhbmNlQ3JpdGVyaW9uSWQgJiYgZXZlbnQubWV0YWRhdGE/LmFjY2VwdGFuY2VDcml0ZXJpb25JZCA9PT0gYWNjZXB0YW5jZUNyaXRlcmlvbklkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtldmVudC5faWQgPz8gYCR7ZXZlbnQuc2VxdWVuY2VOdW1iZXJ9LSR7ZXZlbnQuZXZlbnRUeXBlfWB9IGNsYXNzTmFtZT17YHJvdW5kZWQtbGcgYm9yZGVyIHB4LTMgcHktMyAke2hpZ2hsaWdodGVkID8gXCJib3JkZXItcmVnaXN0cnktYWNjZW50LzQwIGJnLXJlZ2lzdHJ5LWFjY2VudC1zb2Z0XCIgOiBcImJvcmRlci1bdmFyKC0tcGFuZWwtbGluZSldIGJnLWJhY2tncm91bmQvMzBcIn1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwib3V0bGluZVwiPiN7ZXZlbnQuc2VxdWVuY2VOdW1iZXJ9PC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmRcIj57ZXZlbnQuZXZlbnRUeXBlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2V2ZW50LndvcmtmbG93U3RlcCA/IDxCYWRnZSB2YXJpYW50PVwib3V0bGluZVwiPntldmVudC53b3JrZmxvd1N0ZXB9PC9CYWRnZT4gOiBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXZlbnQuc3RhdHVzID8gPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCI+e2V2ZW50LnN0YXR1c308L0JhZGdlPiA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57ZXZlbnQuZHVyYXRpb25NcyA/IGAke01hdGgucm91bmQoZXZlbnQuZHVyYXRpb25Ncyl9bXNgIDogXCLigJRcIn08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57ZXZlbnQuY29tbWFuZFN1bW1hcnkgPz8gZXZlbnQuZXJyb3JTdW1tYXJ5ID8/IGV2ZW50LnRvb2xOYW1lID8/IFwiTm8gc3VtbWFyeVwifTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsoZXZlbnQudG9vbE5hbWUgfHwgZXZlbnQucmV0cnlOdW1iZXIgfHwgZXZlbnQuZXJyb3JDYXRlZ29yeSkgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgZmxleCBmbGV4LXdyYXAgZ2FwLTMgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2V2ZW50LnRvb2xOYW1lID8gPHNwYW4+VG9vbDoge2V2ZW50LnRvb2xOYW1lfTwvc3Bhbj4gOiBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXZlbnQucmV0cnlOdW1iZXIgPyA8c3Bhbj5SZXRyeToge2V2ZW50LnJldHJ5TnVtYmVyfTwvc3Bhbj4gOiBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXZlbnQuZXJyb3JDYXRlZ29yeSA/IDxzcGFuPkVycm9yOiB7ZXZlbnQuZXJyb3JDYXRlZ29yeX08L3NwYW4+IDogbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtldmVudC5tZXRhZGF0YSA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkZXRhaWxzIGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN1bW1hcnkgY2xhc3NOYW1lPVwiY3Vyc29yLXBvaW50ZXJcIj5Nb3JlIGNvbnRleHQ8L3N1bW1hcnk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwcmUgY2xhc3NOYW1lPVwibXQtMiBvdmVyZmxvdy14LWF1dG8gcm91bmRlZCBiZy1iYWNrZ3JvdW5kLzYwIHAtMlwiPntKU09OLnN0cmluZ2lmeShldmVudC5tZXRhZGF0YSwgbnVsbCwgMil9PC9wcmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2RldGFpbHM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L0NhcmQ+XG5cbiAgICAgICAgICAgICAgICAgIDxDYXJkIGlkPVwicnVuLWZpbGVzXCIgY2xhc3NOYW1lPVwic2Nyb2xsLW10LTQgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZm9yZWdyb3VuZFwiPkZpbGVzIGNoYW5nZWQ8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7KGluc3BlY3Rvci5maWxlQ2hhbmdlcyA/PyBbXSkubGVuZ3RoID09PSAwID8gPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5ObyBzdHJ1Y3R1cmVkIGZpbGUgY2hhbmdlcyByZWNvcmRlZC48L3A+IDogaW5zcGVjdG9yLmZpbGVDaGFuZ2VzLm1hcCgoY2hhbmdlOiBhbnkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtgJHtjaGFuZ2Uuc2VxdWVuY2VOdW1iZXJ9LSR7Y2hhbmdlLnJlcG9zaXRvcnlQYXRofWB9IGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1bdmFyKC0tcGFuZWwtbGluZSldIGJnLWJhY2tncm91bmQvMzAgcHgtMyBweS0zIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtZm9yZWdyb3VuZFwiPntjaGFuZ2UucmVwb3NpdG9yeVBhdGggPz8gXCJVbmtub3duIHBhdGhcIn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCI+e2NoYW5nZS5jaGFuZ2VUeXBlfTwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5FdmVudCAje2NoYW5nZS5zZXF1ZW5jZU51bWJlcn0gwrcge2NoYW5nZS53b3JrZmxvd1N0ZXAgPz8gXCLigJRcIn08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIGZsZXggZmxleC13cmFwIGdhcC0zIHRleHQteHMgdGV4dC1yZWdpc3RyeS1hY2NlbnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2hhbmdlLmRpZmZMb2NhdGlvbiA/IDxzcGFuPkRpZmY6IHtjaGFuZ2UuZGlmZkxvY2F0aW9ufTwvc3Bhbj4gOiBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjaGFuZ2UucHVsbFJlcXVlc3RVcmwgPyA8c3Bhbj5QUjoge2NoYW5nZS5wdWxsUmVxdWVzdFVybH08L3NwYW4+IDogbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICAgICAgPENhcmQgaWQ9XCJydW4tYXJ0aWZhY3RzXCIgY2xhc3NOYW1lPVwic2Nyb2xsLW10LTQgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZm9yZWdyb3VuZFwiPkFydGlmYWN0czwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIHsoaW5zcGVjdG9yLmFydGlmYWN0cyA/PyBbXSkubGVuZ3RoID09PSAwID8gPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5ObyBhcnRpZmFjdHMgcmVjb3JkZWQgeWV0LjwvcD4gOiBpbnNwZWN0b3IuYXJ0aWZhY3RzLm1hcCgoYXJ0aWZhY3Q6IGFueSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaGlnaGxpZ2h0ZWQgPSBldmlkZW5jZUFydGlmYWN0cy5zb21lKChpdGVtOiBhbnkpID0+IGl0ZW0uX2lkID09PSBhcnRpZmFjdC5faWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2FydGlmYWN0Ll9pZH0gY2xhc3NOYW1lPXtgcm91bmRlZC1sZyBib3JkZXIgcHgtMyBweS0zICR7aGlnaGxpZ2h0ZWQgPyBcImJvcmRlci1yZWdpc3RyeS1hY2NlbnQvNDAgYmctcmVnaXN0cnktYWNjZW50LXNvZnRcIiA6IFwiYm9yZGVyLVt2YXIoLS1wYW5lbC1saW5lKV0gYmctYmFja2dyb3VuZC8zMFwifWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmRcIj57YXJ0aWZhY3QubmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e2FydGlmYWN0LmFydGlmYWN0VHlwZX0gwrcge2FydGlmYWN0LnByb2R1Y2VyID8/IFwidW5rbm93biBwcm9kdWNlclwifTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cIm91dGxpbmVcIj57bmV3IERhdGUoYXJ0aWZhY3QuY3JlYXRlZEF0KS50b0xvY2FsZVN0cmluZygpfTwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+Q3JpdGVyaW9uOiB7YXJ0aWZhY3QuYWNjZXB0YW5jZUNyaXRlcmlvbklkID8/IFwi4oCUXCJ9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIGZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YXJ0aWZhY3QuZXh0ZXJuYWxMb2NhdGlvbiA/IDxCdXR0b24gYXNDaGlsZCBzaXplPVwic21cIiB2YXJpYW50PVwib3V0bGluZVwiPjxhIGhyZWY9e2FydGlmYWN0LmV4dGVybmFsTG9jYXRpb259IHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vcmVmZXJyZXJcIj5PcGVuPC9hPjwvQnV0dG9uPiA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YXJ0aWZhY3QucmVwb3NpdG9yeVBhdGggPyA8QmFkZ2UgdmFyaWFudD1cIm91dGxpbmVcIj57YXJ0aWZhY3QucmVwb3NpdG9yeVBhdGh9PC9CYWRnZT4gOiBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9DYXJkPlxuXG4gICAgICAgICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mb3JlZ3JvdW5kXCI+UmV0cnkgYW5kIHJlY292ZXJ5PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgeyhpbnNwZWN0b3IucmV0cnlUaW1lbGluZSA/PyBbXSkubGVuZ3RoID09PSAwID8gPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5ObyByZXRyaWVzIHJlY29yZGVkLjwvcD4gOiBpbnNwZWN0b3IucmV0cnlUaW1lbGluZS5tYXAoKHJldHJ5OiBhbnkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtgJHtyZXRyeS5yZXRyeU51bWJlcn0tJHtyZXRyeS53b3JrZmxvd1N0ZXB9YH0gY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLVt2YXIoLS1wYW5lbC1saW5lKV0gYmctYmFja2dyb3VuZC8zMCBweC0zIHB5LTMgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZm9yZWdyb3VuZFwiPlJldHJ5IHtyZXRyeS5yZXRyeU51bWJlcn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCI+e3JldHJ5Lm91dGNvbWUgPz8gXCJwZW5kaW5nXCJ9PC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlN0ZXA6IHtyZXRyeS53b3JrZmxvd1N0ZXAgPz8gXCLigJRcIn08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+UmVhc29uOiB7cmV0cnkucmVhc29uID8/IFwi4oCUXCJ9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPkNoZWNrcG9pbnQ6IHtyZXRyeS5jaGVja3BvaW50QXJ0aWZhY3RJZCA/PyBcIuKAlFwifTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9DYXJkPlxuXG4gICAgICAgICAgICAgICAgICA8Q2FyZCBpZD1cInJ1bi1yZWNlaXB0c1wiIGNsYXNzTmFtZT1cInNjcm9sbC1tdC00IHAtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmRcIj5FdmlkZW5jZSBkcmlsbC1kb3duPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHsodmVyaWZpY2F0aW9uUmVjZWlwdElkIHx8IGFjY2VwdGFuY2VDcml0ZXJpb25JZCkgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+Rm9jdXNlZCByZWNlaXB0OiB7dmVyaWZpY2F0aW9uUmVjZWlwdElkID8/IFwi4oCUXCJ9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PkZvY3VzZWQgY3JpdGVyaW9uOiB7YWNjZXB0YW5jZUNyaXRlcmlvbklkID8/IFwi4oCUXCJ9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PkxpbmtlZCBldmVudHM6IHtpbnNwZWN0b3IuZXZpZGVuY2VMaW5lYWdlPy5ldmVudHM/Lmxlbmd0aCA/PyAwfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5MaW5rZWQgYXJ0aWZhY3RzOiB7aW5zcGVjdG9yLmV2aWRlbmNlTGluZWFnZT8uYXJ0aWZhY3RzPy5sZW5ndGggPz8gMH08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPk9wZW4gdGhpcyBpbnNwZWN0b3IgZnJvbSBhIHZlcmlmaWNhdGlvbiByZWNlaXB0IHRvIGp1bXAgc3RyYWlnaHQgdG8gZXZpZGVuY2UgbGluZWFnZS48L3A+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0RpYWxvZ0NvbnRlbnQ+XG4gICAgPC9EaWFsb2c+XG4gICk7XG59XG5cbmZ1bmN0aW9uIE1ldGEoeyBsYWJlbCwgdmFsdWUgfTogeyBsYWJlbDogc3RyaW5nOyB2YWx1ZT86IHN0cmluZyB8IG51bGwgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHVwcGVyY2FzZSB0cmFja2luZy1bMC4xNGVtXSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57bGFiZWx9PC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWZvcmVncm91bmRcIj57dmFsdWUgPz8gXCLigJRcIn08L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gR3JhcGhNZXRhKHsgbGFiZWwsIHZhbHVlIH06IHsgbGFiZWw6IHN0cmluZzsgdmFsdWU6IHN0cmluZyB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntsYWJlbH08L2R0PlxuICAgICAgPGRkIGNsYXNzTmFtZT1cInRleHQtcmlnaHQgdGV4dC1mb3JlZ3JvdW5kLzg1XCI+e3ZhbHVlfTwvZGQ+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9jb250cm9sUGxhbmUvRXhlY3V0aW9uUnVuSW5zcGVjdG9yLnRzeCJ9