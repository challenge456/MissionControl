import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/SetupMessage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export function SetupMessage() {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      style: {
        minHeight: "100vh",
        background: "#0f172a",
        color: "#e2e8f0",
        padding: 24,
        fontFamily: "system-ui, sans-serif"
      },
      children: [
        /* @__PURE__ */ jsxDEV("h1", { style: { margin: "0 0 8px", fontSize: "1.25rem" }, children: "Mission Control" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx",
          lineNumber: 31,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("p", { style: { margin: "0 0 16px", color: "#94a3b8" }, children: "Convex is not configured. The UI needs a backend URL to load tasks." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx",
          lineNumber: 32,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "ol",
          {
            style: {
              margin: 0,
              paddingLeft: 20,
              color: "#cbd5e1",
              fontSize: "0.875rem",
              lineHeight: 1.8
            },
            children: [
              /* @__PURE__ */ jsxDEV("li", { children: [
                "Run ",
                /* @__PURE__ */ jsxDEV("code", { style: { background: "#1e293b", padding: "2px 6px", borderRadius: 4 }, children: "npx convex dev" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx",
                  lineNumber: 44,
                  columnNumber: 17
                }, this),
                " in the project root and sign in if prompted."
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx",
                lineNumber: 44,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: [
                "In the repo root, create or edit ",
                /* @__PURE__ */ jsxDEV("code", { style: { background: "#1e293b", padding: "2px 6px", borderRadius: 4 }, children: ".env.local" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx",
                  lineNumber: 45,
                  columnNumber: 46
                }, this),
                "."
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx",
                lineNumber: 45,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: [
                "Add ",
                /* @__PURE__ */ jsxDEV("code", { style: { background: "#1e293b", padding: "2px 6px", borderRadius: 4 }, children: "VITE_CONVEX_URL=https://your-deployment.convex.cloud" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx",
                  lineNumber: 46,
                  columnNumber: 17
                }, this),
                " (use the URL from the Convex dashboard or ",
                /* @__PURE__ */ jsxDEV("code", { children: ".env.local" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx",
                  lineNumber: 46,
                  columnNumber: 196
                }, this),
                " after ",
                /* @__PURE__ */ jsxDEV("code", { children: "convex dev" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx",
                  lineNumber: 46,
                  columnNumber: 226
                }, this),
                ")."
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx",
                lineNumber: 46,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: [
                "Restart the dev server: ",
                /* @__PURE__ */ jsxDEV("code", { style: { background: "#1e293b", padding: "2px 6px", borderRadius: 4 }, children: "pnpm run dev:ui" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx",
                  lineNumber: 47,
                  columnNumber: 37
                }, this),
                "."
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx",
                lineNumber: 47,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx",
            lineNumber: 35,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("p", { style: { marginTop: 24, color: "#64748b", fontSize: "0.8rem" }, children: [
          "If you already set VITE_CONVEX_URL, make sure it’s in the repo root ",
          /* @__PURE__ */ jsxDEV("code", { children: ".env.local" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx",
            lineNumber: 50,
            columnNumber: 77
          }, this),
          " and that you restarted the UI after adding it."
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx",
          lineNumber: 49,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx",
      lineNumber: 22,
      columnNumber: 5
    },
    this
  );
}
_c = SetupMessage;
var _c;
$RefreshReg$(_c, "SetupMessage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SetupMessage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV007Ozs7Ozs7Ozs7Ozs7Ozs7QUFYQyxnQkFBU0EsZUFBZTtBQUM3QixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxPQUFPO0FBQUEsUUFDTEMsV0FBVztBQUFBLFFBQ1hDLFlBQVk7QUFBQSxRQUNaQyxPQUFPO0FBQUEsUUFDUEMsU0FBUztBQUFBLFFBQ1RDLFlBQVk7QUFBQSxNQUNkO0FBQUEsTUFFQTtBQUFBLCtCQUFDLFFBQUcsT0FBTyxFQUFFQyxRQUFRLFdBQVdDLFVBQVUsVUFBVSxHQUFHLCtCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNFO0FBQUEsUUFDdEUsdUJBQUMsT0FBRSxPQUFPLEVBQUVELFFBQVEsWUFBWUgsT0FBTyxVQUFVLEdBQUUsbUZBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU87QUFBQSxjQUNMRyxRQUFRO0FBQUEsY0FDUkUsYUFBYTtBQUFBLGNBQ2JMLE9BQU87QUFBQSxjQUNQSSxVQUFVO0FBQUEsY0FDVkUsWUFBWTtBQUFBLFlBQ2Q7QUFBQSxZQUVBO0FBQUEscUNBQUMsUUFBRztBQUFBO0FBQUEsZ0JBQUksdUJBQUMsVUFBSyxPQUFPLEVBQUVQLFlBQVksV0FBV0UsU0FBUyxXQUFXTSxjQUFjLEVBQUUsR0FBRyw4QkFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkY7QUFBQSxnQkFBTztBQUFBLG1CQUExRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1SjtBQUFBLGNBQ3ZKLHVCQUFDLFFBQUc7QUFBQTtBQUFBLGdCQUFpQyx1QkFBQyxVQUFLLE9BQU8sRUFBRVIsWUFBWSxXQUFXRSxTQUFTLFdBQVdNLGNBQWMsRUFBRSxHQUFHLDBCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RjtBQUFBLGdCQUFPO0FBQUEsbUJBQW5JO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9JO0FBQUEsY0FDcEksdUJBQUMsUUFBRztBQUFBO0FBQUEsZ0JBQUksdUJBQUMsVUFBSyxPQUFPLEVBQUVSLFlBQVksV0FBV0UsU0FBUyxXQUFXTSxjQUFjLEVBQUUsR0FBRyxvRUFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUk7QUFBQSxnQkFBTztBQUFBLGdCQUEyQyx1QkFBQyxVQUFLLDBCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdCO0FBQUEsZ0JBQU87QUFBQSxnQkFBTyx1QkFBQyxVQUFLLDBCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdCO0FBQUEsZ0JBQU87QUFBQSxtQkFBaFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa1A7QUFBQSxjQUNsUCx1QkFBQyxRQUFHO0FBQUE7QUFBQSxnQkFBd0IsdUJBQUMsVUFBSyxPQUFPLEVBQUVSLFlBQVksV0FBV0UsU0FBUyxXQUFXTSxjQUFjLEVBQUUsR0FBRywrQkFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEY7QUFBQSxnQkFBTztBQUFBLG1CQUEvSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnSTtBQUFBO0FBQUE7QUFBQSxVQVpsSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFhQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxPQUFPLEVBQUVDLFdBQVcsSUFBSVIsT0FBTyxXQUFXSSxVQUFVLFNBQVMsR0FBRTtBQUFBO0FBQUEsVUFDSSx1QkFBQyxVQUFLLDBCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdCO0FBQUEsVUFBTztBQUFBLGFBRDdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBO0FBQUE7QUFBQSxJQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUE4QkE7QUFFSjtBQUFDSyxLQWxDZVo7QUFBWSxJQUFBWTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJTZXR1cE1lc3NhZ2UiLCJtaW5IZWlnaHQiLCJiYWNrZ3JvdW5kIiwiY29sb3IiLCJwYWRkaW5nIiwiZm9udEZhbWlseSIsIm1hcmdpbiIsImZvbnRTaXplIiwicGFkZGluZ0xlZnQiLCJsaW5lSGVpZ2h0IiwiYm9yZGVyUmFkaXVzIiwibWFyZ2luVG9wIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2V0dXBNZXNzYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZnVuY3Rpb24gU2V0dXBNZXNzYWdlKCkge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIHN0eWxlPXt7XG4gICAgICAgIG1pbkhlaWdodDogXCIxMDB2aFwiLFxuICAgICAgICBiYWNrZ3JvdW5kOiBcIiMwZjE3MmFcIixcbiAgICAgICAgY29sb3I6IFwiI2UyZThmMFwiLFxuICAgICAgICBwYWRkaW5nOiAyNCxcbiAgICAgICAgZm9udEZhbWlseTogXCJzeXN0ZW0tdWksIHNhbnMtc2VyaWZcIixcbiAgICAgIH19XG4gICAgPlxuICAgICAgPGgxIHN0eWxlPXt7IG1hcmdpbjogXCIwIDAgOHB4XCIsIGZvbnRTaXplOiBcIjEuMjVyZW1cIiB9fT5NaXNzaW9uIENvbnRyb2w8L2gxPlxuICAgICAgPHAgc3R5bGU9e3sgbWFyZ2luOiBcIjAgMCAxNnB4XCIsIGNvbG9yOiBcIiM5NGEzYjhcIiB9fT5cbiAgICAgICAgQ29udmV4IGlzIG5vdCBjb25maWd1cmVkLiBUaGUgVUkgbmVlZHMgYSBiYWNrZW5kIFVSTCB0byBsb2FkIHRhc2tzLlxuICAgICAgPC9wPlxuICAgICAgPG9sXG4gICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgbWFyZ2luOiAwLFxuICAgICAgICAgIHBhZGRpbmdMZWZ0OiAyMCxcbiAgICAgICAgICBjb2xvcjogXCIjY2JkNWUxXCIsXG4gICAgICAgICAgZm9udFNpemU6IFwiMC44NzVyZW1cIixcbiAgICAgICAgICBsaW5lSGVpZ2h0OiAxLjgsXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxsaT5SdW4gPGNvZGUgc3R5bGU9e3sgYmFja2dyb3VuZDogXCIjMWUyOTNiXCIsIHBhZGRpbmc6IFwiMnB4IDZweFwiLCBib3JkZXJSYWRpdXM6IDQgfX0+bnB4IGNvbnZleCBkZXY8L2NvZGU+IGluIHRoZSBwcm9qZWN0IHJvb3QgYW5kIHNpZ24gaW4gaWYgcHJvbXB0ZWQuPC9saT5cbiAgICAgICAgPGxpPkluIHRoZSByZXBvIHJvb3QsIGNyZWF0ZSBvciBlZGl0IDxjb2RlIHN0eWxlPXt7IGJhY2tncm91bmQ6IFwiIzFlMjkzYlwiLCBwYWRkaW5nOiBcIjJweCA2cHhcIiwgYm9yZGVyUmFkaXVzOiA0IH19Pi5lbnYubG9jYWw8L2NvZGU+LjwvbGk+XG4gICAgICAgIDxsaT5BZGQgPGNvZGUgc3R5bGU9e3sgYmFja2dyb3VuZDogXCIjMWUyOTNiXCIsIHBhZGRpbmc6IFwiMnB4IDZweFwiLCBib3JkZXJSYWRpdXM6IDQgfX0+VklURV9DT05WRVhfVVJMPWh0dHBzOi8veW91ci1kZXBsb3ltZW50LmNvbnZleC5jbG91ZDwvY29kZT4gKHVzZSB0aGUgVVJMIGZyb20gdGhlIENvbnZleCBkYXNoYm9hcmQgb3IgPGNvZGU+LmVudi5sb2NhbDwvY29kZT4gYWZ0ZXIgPGNvZGU+Y29udmV4IGRldjwvY29kZT4pLjwvbGk+XG4gICAgICAgIDxsaT5SZXN0YXJ0IHRoZSBkZXYgc2VydmVyOiA8Y29kZSBzdHlsZT17eyBiYWNrZ3JvdW5kOiBcIiMxZTI5M2JcIiwgcGFkZGluZzogXCIycHggNnB4XCIsIGJvcmRlclJhZGl1czogNCB9fT5wbnBtIHJ1biBkZXY6dWk8L2NvZGU+LjwvbGk+XG4gICAgICA8L29sPlxuICAgICAgPHAgc3R5bGU9e3sgbWFyZ2luVG9wOiAyNCwgY29sb3I6IFwiIzY0NzQ4YlwiLCBmb250U2l6ZTogXCIwLjhyZW1cIiB9fT5cbiAgICAgICAgSWYgeW91IGFscmVhZHkgc2V0IFZJVEVfQ09OVkVYX1VSTCwgbWFrZSBzdXJlIGl04oCZcyBpbiB0aGUgcmVwbyByb290IDxjb2RlPi5lbnYubG9jYWw8L2NvZGU+IGFuZCB0aGF0IHlvdSByZXN0YXJ0ZWQgdGhlIFVJIGFmdGVyIGFkZGluZyBpdC5cbiAgICAgIDwvcD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL1NldHVwTWVzc2FnZS50c3gifQ==