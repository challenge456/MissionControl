import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/factory/badges.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/badges.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { cva } from "/node_modules/.vite/deps/class-variance-authority.js?v=257b6f3a";
import { ArrowDownRight, ArrowUpRight } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { cn } from "/src/lib/utils.ts";
const statusBadge = cva(
  "inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[11.5px] font-medium leading-none",
  {
    variants: {
      tone: {
        neutral: "border-line bg-surface-2 text-ink-secondary",
        success: "border-transparent bg-ok-soft text-ok",
        warning: "border-transparent bg-warn-soft text-warn",
        error: "border-transparent bg-err-soft text-err",
        info: "border-transparent bg-info-soft text-info-accent"
      }
    },
    defaultVariants: { tone: "neutral" }
  }
);
export function StatusBadge({ tone, children, className }) {
  return /* @__PURE__ */ jsxDEV("span", { className: cn(statusBadge({ tone }), className), children }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/badges.tsx",
    lineNumber: 51,
    columnNumber: 10
  }, this);
}
_c = StatusBadge;
const RISK_TONE = {
  LOW: "success",
  GREEN: "success",
  MEDIUM: "warning",
  YELLOW: "warning",
  HIGH: "error",
  RED: "error",
  CRITICAL: "error"
};
export function RiskBadge({ level, className }) {
  return /* @__PURE__ */ jsxDEV(StatusBadge, { tone: RISK_TONE[level], className, children: level }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/badges.tsx",
    lineNumber: 68,
    columnNumber: 5
  }, this);
}
_c2 = RiskBadge;
function scoreTone(score) {
  if (score >= 90) return "bg-ok-soft text-ok border-transparent";
  if (score >= 70) return "bg-warn-soft text-warn border-transparent";
  return "bg-err-soft text-err border-transparent";
}
export function ScoreBadge({ score, size = "sm", className }) {
  return /* @__PURE__ */ jsxDEV(
    "span",
    {
      role: "img",
      "aria-label": `Score ${score} out of 100`,
      className: cn(
        "inline-flex items-center justify-center rounded-lg border font-mono font-semibold",
        size === "lg" ? "h-12 min-w-12 px-2 text-[20px]" : "h-6 min-w-8 px-1.5 text-[12.5px]",
        scoreTone(score),
        className
      ),
      children: Math.round(score)
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/badges.tsx",
      lineNumber: 90,
      columnNumber: 5
    },
    this
  );
}
_c3 = ScoreBadge;
export function TrendBadge({ multiplier, className }) {
  const up = multiplier >= 1;
  return /* @__PURE__ */ jsxDEV(
    "span",
    {
      className: cn(
        "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-[11.5px] font-medium leading-none",
        up ? "bg-ok-soft text-ok" : "bg-err-soft text-err",
        className
      ),
      children: [
        up ? /* @__PURE__ */ jsxDEV(ArrowUpRight, { size: 11, "aria-hidden": true }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/badges.tsx",
          lineNumber: 122,
          columnNumber: 7
        }, this) : /* @__PURE__ */ jsxDEV(ArrowDownRight, { size: 11, "aria-hidden": true }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/badges.tsx",
          lineNumber: 124,
          columnNumber: 7
        }, this),
        multiplier.toFixed(2),
        "x"
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/badges.tsx",
      lineNumber: 114,
      columnNumber: 5
    },
    this
  );
}
_c4 = TrendBadge;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "StatusBadge");
$RefreshReg$(_c2, "RiskBadge");
$RefreshReg$(_c3, "ScoreBadge");
$RefreshReg$(_c4, "TrendBadge");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/badges.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/badges.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JTOzs7Ozs7Ozs7Ozs7Ozs7O0FBL0JULFNBQVNBLFdBQThCO0FBQ3ZDLFNBQVNDLGdCQUFnQkMsb0JBQW9CO0FBQzdDLFNBQVNDLFVBQVU7QUFPbkIsTUFBTUMsY0FBY0o7QUFBQUEsRUFDbEI7QUFBQSxFQUNBO0FBQUEsSUFDRUssVUFBVTtBQUFBLE1BQ1JDLE1BQU07QUFBQSxRQUNKQyxTQUFTO0FBQUEsUUFDVEMsU0FBUztBQUFBLFFBQ1RDLFNBQVM7QUFBQSxRQUNUQyxPQUFPO0FBQUEsUUFDUEMsTUFBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUEsSUFDQUMsaUJBQWlCLEVBQUVOLE1BQU0sVUFBVTtBQUFBLEVBQ3JDO0FBQ0Y7QUFPTyxnQkFBU08sWUFBWSxFQUFFUCxNQUFNUSxVQUFVQyxVQUE0QixHQUFnQjtBQUN4RixTQUFPLHVCQUFDLFVBQUssV0FBV1osR0FBR0MsWUFBWSxFQUFFRSxLQUFLLENBQUMsR0FBR1MsU0FBUyxHQUFJRCxZQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWlFO0FBQzFFO0FBQUNFLEtBRmVIO0FBTWhCLE1BQU1JLFlBQXlEO0FBQUEsRUFDN0RDLEtBQUs7QUFBQSxFQUNMQyxPQUFPO0FBQUEsRUFDUEMsUUFBUTtBQUFBLEVBQ1JDLFFBQVE7QUFBQSxFQUNSQyxNQUFNO0FBQUEsRUFDTkMsS0FBSztBQUFBLEVBQ0xDLFVBQVU7QUFDWjtBQUVPLGdCQUFTQyxVQUFVLEVBQUVDLE9BQU9YLFVBQW9ELEdBQWdCO0FBQ3JHLFNBQ0UsdUJBQUMsZUFBWSxNQUFNRSxVQUFVUyxLQUFLLEdBQUcsV0FDbENBLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUNDLE1BTmVGO0FBZWhCLFNBQVNHLFVBQVVDLE9BQXVCO0FBQ3hDLE1BQUlBLFNBQVMsR0FBSSxRQUFPO0FBQ3hCLE1BQUlBLFNBQVMsR0FBSSxRQUFPO0FBQ3hCLFNBQU87QUFDVDtBQUdPLGdCQUFTQyxXQUFXLEVBQUVELE9BQU9FLE9BQU8sTUFBTWhCLFVBQTJCLEdBQWdCO0FBQzFGLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE1BQUs7QUFBQSxNQUNMLGNBQVksU0FBU2MsS0FBSztBQUFBLE1BQzFCLFdBQVcxQjtBQUFBQSxRQUNUO0FBQUEsUUFDQTRCLFNBQVMsT0FBTyxtQ0FBbUM7QUFBQSxRQUNuREgsVUFBVUMsS0FBSztBQUFBLFFBQ2ZkO0FBQUFBLE1BQ0Y7QUFBQSxNQUVDaUIsZUFBS0MsTUFBTUosS0FBSztBQUFBO0FBQUEsSUFWbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBV0E7QUFFSjtBQUFDSyxNQWZlSjtBQXVCVCxnQkFBU0ssV0FBVyxFQUFFQyxZQUFZckIsVUFBMkIsR0FBZ0I7QUFDbEYsUUFBTXNCLEtBQUtELGNBQWM7QUFDekIsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBV2pDO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBa0MsS0FBSyx1QkFBdUI7QUFBQSxRQUM1QnRCO0FBQUFBLE1BQ0Y7QUFBQSxNQUVDc0I7QUFBQUEsYUFDQyx1QkFBQyxnQkFBYSxNQUFNLElBQUksZUFBVyxRQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1DLElBRW5DLHVCQUFDLGtCQUFlLE1BQU0sSUFBSSxlQUFXLFFBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUM7QUFBQSxRQUV0Q0QsV0FBV0UsUUFBUSxDQUFDO0FBQUEsUUFBRTtBQUFBO0FBQUE7QUFBQSxJQVp6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFhQTtBQUVKO0FBQUNDLE1BbEJlSjtBQUFVLElBQUFuQixJQUFBVyxLQUFBTyxLQUFBSztBQUFBLGFBQUF2QixJQUFBO0FBQUEsYUFBQVcsS0FBQTtBQUFBLGFBQUFPLEtBQUE7QUFBQSxhQUFBSyxLQUFBIiwibmFtZXMiOlsiY3ZhIiwiQXJyb3dEb3duUmlnaHQiLCJBcnJvd1VwUmlnaHQiLCJjbiIsInN0YXR1c0JhZGdlIiwidmFyaWFudHMiLCJ0b25lIiwibmV1dHJhbCIsInN1Y2Nlc3MiLCJ3YXJuaW5nIiwiZXJyb3IiLCJpbmZvIiwiZGVmYXVsdFZhcmlhbnRzIiwiU3RhdHVzQmFkZ2UiLCJjaGlsZHJlbiIsImNsYXNzTmFtZSIsIl9jIiwiUklTS19UT05FIiwiTE9XIiwiR1JFRU4iLCJNRURJVU0iLCJZRUxMT1ciLCJISUdIIiwiUkVEIiwiQ1JJVElDQUwiLCJSaXNrQmFkZ2UiLCJsZXZlbCIsIl9jMiIsInNjb3JlVG9uZSIsInNjb3JlIiwiU2NvcmVCYWRnZSIsInNpemUiLCJNYXRoIiwicm91bmQiLCJfYzMiLCJUcmVuZEJhZGdlIiwibXVsdGlwbGllciIsInVwIiwidG9GaXhlZCIsIl9jNCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJiYWRnZXMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGN2YSwgdHlwZSBWYXJpYW50UHJvcHMgfSBmcm9tIFwiY2xhc3MtdmFyaWFuY2UtYXV0aG9yaXR5XCI7XG5pbXBvcnQgeyBBcnJvd0Rvd25SaWdodCwgQXJyb3dVcFJpZ2h0IH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiLi4vLi4vbGliL3V0aWxzXCI7XG5cbi8qKlxuICogQ29uc29saWRhdGVkIFNvZnR3YXJlIEZhY3RvcnkgYmFkZ2Ugc3lzdGVtIChzdXBlcnNlZGVzIFN0YXR1c0NoaXAgL1xuICogUHJpb3JpdHlDaGlwIC8gUmlza0NoaXAgLyBOZW9uIGJhZGdlcyBmb3IgdjIgc3VyZmFjZXMpLlxuICovXG5cbmNvbnN0IHN0YXR1c0JhZGdlID0gY3ZhKFxuICBcImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSByb3VuZGVkLW1kIGJvcmRlciBweC0xLjUgcHktMC41IHRleHQtWzExLjVweF0gZm9udC1tZWRpdW0gbGVhZGluZy1ub25lXCIsXG4gIHtcbiAgICB2YXJpYW50czoge1xuICAgICAgdG9uZToge1xuICAgICAgICBuZXV0cmFsOiBcImJvcmRlci1saW5lIGJnLXN1cmZhY2UtMiB0ZXh0LWluay1zZWNvbmRhcnlcIixcbiAgICAgICAgc3VjY2VzczogXCJib3JkZXItdHJhbnNwYXJlbnQgYmctb2stc29mdCB0ZXh0LW9rXCIsXG4gICAgICAgIHdhcm5pbmc6IFwiYm9yZGVyLXRyYW5zcGFyZW50IGJnLXdhcm4tc29mdCB0ZXh0LXdhcm5cIixcbiAgICAgICAgZXJyb3I6IFwiYm9yZGVyLXRyYW5zcGFyZW50IGJnLWVyci1zb2Z0IHRleHQtZXJyXCIsXG4gICAgICAgIGluZm86IFwiYm9yZGVyLXRyYW5zcGFyZW50IGJnLWluZm8tc29mdCB0ZXh0LWluZm8tYWNjZW50XCIsXG4gICAgICB9LFxuICAgIH0sXG4gICAgZGVmYXVsdFZhcmlhbnRzOiB7IHRvbmU6IFwibmV1dHJhbFwiIH0sXG4gIH1cbik7XG5cbmV4cG9ydCBpbnRlcmZhY2UgU3RhdHVzQmFkZ2VQcm9wcyBleHRlbmRzIFZhcmlhbnRQcm9wczx0eXBlb2Ygc3RhdHVzQmFkZ2U+IHtcbiAgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZTtcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gU3RhdHVzQmFkZ2UoeyB0b25lLCBjaGlsZHJlbiwgY2xhc3NOYW1lIH06IFN0YXR1c0JhZGdlUHJvcHMpOiBKU1guRWxlbWVudCB7XG4gIHJldHVybiA8c3BhbiBjbGFzc05hbWU9e2NuKHN0YXR1c0JhZGdlKHsgdG9uZSB9KSwgY2xhc3NOYW1lKX0+e2NoaWxkcmVufTwvc3Bhbj47XG59XG5cbmV4cG9ydCB0eXBlIFJpc2tMZXZlbCA9IFwiTE9XXCIgfCBcIk1FRElVTVwiIHwgXCJISUdIXCIgfCBcIkNSSVRJQ0FMXCIgfCBcIkdSRUVOXCIgfCBcIllFTExPV1wiIHwgXCJSRURcIjtcblxuY29uc3QgUklTS19UT05FOiBSZWNvcmQ8Umlza0xldmVsLCBTdGF0dXNCYWRnZVByb3BzW1widG9uZVwiXT4gPSB7XG4gIExPVzogXCJzdWNjZXNzXCIsXG4gIEdSRUVOOiBcInN1Y2Nlc3NcIixcbiAgTUVESVVNOiBcIndhcm5pbmdcIixcbiAgWUVMTE9XOiBcIndhcm5pbmdcIixcbiAgSElHSDogXCJlcnJvclwiLFxuICBSRUQ6IFwiZXJyb3JcIixcbiAgQ1JJVElDQUw6IFwiZXJyb3JcIixcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBSaXNrQmFkZ2UoeyBsZXZlbCwgY2xhc3NOYW1lIH06IHsgbGV2ZWw6IFJpc2tMZXZlbDsgY2xhc3NOYW1lPzogc3RyaW5nIH0pOiBKU1guRWxlbWVudCB7XG4gIHJldHVybiAoXG4gICAgPFN0YXR1c0JhZGdlIHRvbmU9e1JJU0tfVE9ORVtsZXZlbF19IGNsYXNzTmFtZT17Y2xhc3NOYW1lfT5cbiAgICAgIHtsZXZlbH1cbiAgICA8L1N0YXR1c0JhZGdlPlxuICApO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNjb3JlQmFkZ2VQcm9wcyB7XG4gIC8qKiAw4oCTMTAwICovXG4gIHNjb3JlOiBudW1iZXI7XG4gIHNpemU/OiBcInNtXCIgfCBcImxnXCI7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbn1cblxuZnVuY3Rpb24gc2NvcmVUb25lKHNjb3JlOiBudW1iZXIpOiBzdHJpbmcge1xuICBpZiAoc2NvcmUgPj0gOTApIHJldHVybiBcImJnLW9rLXNvZnQgdGV4dC1vayBib3JkZXItdHJhbnNwYXJlbnRcIjtcbiAgaWYgKHNjb3JlID49IDcwKSByZXR1cm4gXCJiZy13YXJuLXNvZnQgdGV4dC13YXJuIGJvcmRlci10cmFuc3BhcmVudFwiO1xuICByZXR1cm4gXCJiZy1lcnItc29mdCB0ZXh0LWVyciBib3JkZXItdHJhbnNwYXJlbnRcIjtcbn1cblxuLyoqIE51bWVyaWMgcXVhbGl0eS9pbXBhY3Qgc2NvcmUgY2hpcC4gOTArIGdyZWVuLCA3MOKAkzg5IHllbGxvdywgPDcwIHJlZC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBTY29yZUJhZGdlKHsgc2NvcmUsIHNpemUgPSBcInNtXCIsIGNsYXNzTmFtZSB9OiBTY29yZUJhZGdlUHJvcHMpOiBKU1guRWxlbWVudCB7XG4gIHJldHVybiAoXG4gICAgPHNwYW5cbiAgICAgIHJvbGU9XCJpbWdcIlxuICAgICAgYXJpYS1sYWJlbD17YFNjb3JlICR7c2NvcmV9IG91dCBvZiAxMDBgfVxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBib3JkZXIgZm9udC1tb25vIGZvbnQtc2VtaWJvbGRcIixcbiAgICAgICAgc2l6ZSA9PT0gXCJsZ1wiID8gXCJoLTEyIG1pbi13LTEyIHB4LTIgdGV4dC1bMjBweF1cIiA6IFwiaC02IG1pbi13LTggcHgtMS41IHRleHQtWzEyLjVweF1cIixcbiAgICAgICAgc2NvcmVUb25lKHNjb3JlKSxcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgID5cbiAgICAgIHtNYXRoLnJvdW5kKHNjb3JlKX1cbiAgICA8L3NwYW4+XG4gICk7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVHJlbmRCYWRnZVByb3BzIHtcbiAgLyoqIE11bHRpcGxpZXIgb3IgZGVsdGEsIGUuZy4gMS4zMyByZW5kZXJzIFwi4oaRIDEuMzN4XCI7IGJlbG93IDEgcmVuZGVycyBkb3duLiAqL1xuICBtdWx0aXBsaWVyOiBudW1iZXI7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFRyZW5kQmFkZ2UoeyBtdWx0aXBsaWVyLCBjbGFzc05hbWUgfTogVHJlbmRCYWRnZVByb3BzKTogSlNYLkVsZW1lbnQge1xuICBjb25zdCB1cCA9IG11bHRpcGxpZXIgPj0gMTtcbiAgcmV0dXJuIChcbiAgICA8c3BhblxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTAuNSByb3VuZGVkLW1kIHB4LTEuNSBweS0wLjUgdGV4dC1bMTEuNXB4XSBmb250LW1lZGl1bSBsZWFkaW5nLW5vbmVcIixcbiAgICAgICAgdXAgPyBcImJnLW9rLXNvZnQgdGV4dC1va1wiIDogXCJiZy1lcnItc29mdCB0ZXh0LWVyclwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgPlxuICAgICAge3VwID8gKFxuICAgICAgICA8QXJyb3dVcFJpZ2h0IHNpemU9ezExfSBhcmlhLWhpZGRlbiAvPlxuICAgICAgKSA6IChcbiAgICAgICAgPEFycm93RG93blJpZ2h0IHNpemU9ezExfSBhcmlhLWhpZGRlbiAvPlxuICAgICAgKX1cbiAgICAgIHttdWx0aXBsaWVyLnRvRml4ZWQoMil9eFxuICAgIDwvc3Bhbj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL2NvbXBvbmVudHMvZmFjdG9yeS9iYWRnZXMudHN4In0=