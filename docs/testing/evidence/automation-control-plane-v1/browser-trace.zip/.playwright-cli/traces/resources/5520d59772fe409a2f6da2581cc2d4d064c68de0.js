import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shellV2/ResizerHandle.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ResizerHandle.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import { cn } from "/src/lib/utils.ts";
export function ResizerHandle({
  onResize,
  onBegin,
  onEnd,
  title = "Drag to resize",
  className
}) {
  _s();
  const dragging = useRef(false);
  const lastX = useRef(0);
  const onPointerDown = useCallback(
    (e) => {
      dragging.current = true;
      lastX.current = e.clientX;
      onBegin();
      e.target.setPointerCapture(e.pointerId);
    },
    [onBegin]
  );
  const onPointerMove = useCallback(
    (e) => {
      if (!dragging.current) return;
      const delta = e.clientX - lastX.current;
      lastX.current = e.clientX;
      onResize(delta);
    },
    [onResize]
  );
  const onPointerUp = useCallback(
    (e) => {
      if (!dragging.current) return;
      dragging.current = false;
      onEnd();
      e.target.releasePointerCapture(e.pointerId);
    },
    [onEnd]
  );
  useEffect(() => {
    const stop = () => {
      if (dragging.current) {
        dragging.current = false;
        onEnd();
      }
    };
    window.addEventListener("pointerup", stop);
    return () => window.removeEventListener("pointerup", stop);
  }, [onEnd]);
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      role: "separator",
      "aria-orientation": "vertical",
      title,
      onPointerDown,
      onPointerMove,
      onPointerUp,
      className: cn(
        "shell-resizer w-[5px] shrink-0 cursor-col-resize bg-transparent transition-colors hover:bg-schematic-accent-soft",
        className
      )
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ResizerHandle.tsx",
      lineNumber: 84,
      columnNumber: 5
    },
    this
  );
}
_s(ResizerHandle, "dvlp82UozVJNnbV3gRL9eLEfJyQ=");
_c = ResizerHandle;
var _c;
$RefreshReg$(_c, "ResizerHandle");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ResizerHandle.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ResizerHandle.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0VJOzs7Ozs7Ozs7Ozs7Ozs7OztBQWhFSixTQUFTQSxhQUFhQyxXQUFXQyxjQUFjO0FBQy9DLFNBQVNDLFVBQVU7QUFXWixnQkFBU0MsY0FBYztBQUFBLEVBQzVCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxRQUFRO0FBQUEsRUFDUkM7QUFDa0IsR0FBZ0I7QUFBQUMsS0FBQTtBQUNsQyxRQUFNQyxXQUFXVCxPQUFPLEtBQUs7QUFDN0IsUUFBTVUsUUFBUVYsT0FBTyxDQUFDO0FBRXRCLFFBQU1XLGdCQUFnQmI7QUFBQUEsSUFDcEIsQ0FBQ2MsTUFBMEI7QUFDekJILGVBQVNJLFVBQVU7QUFDbkJILFlBQU1HLFVBQVVELEVBQUVFO0FBQ2xCVixjQUFRO0FBQ1IsTUFBQ1EsRUFBRUcsT0FBdUJDLGtCQUFrQkosRUFBRUssU0FBUztBQUFBLElBQ3pEO0FBQUEsSUFDQSxDQUFDYixPQUFPO0FBQUEsRUFDVjtBQUVBLFFBQU1jLGdCQUFnQnBCO0FBQUFBLElBQ3BCLENBQUNjLE1BQTBCO0FBQ3pCLFVBQUksQ0FBQ0gsU0FBU0ksUUFBUztBQUN2QixZQUFNTSxRQUFRUCxFQUFFRSxVQUFVSixNQUFNRztBQUNoQ0gsWUFBTUcsVUFBVUQsRUFBRUU7QUFDbEJYLGVBQVNnQixLQUFLO0FBQUEsSUFDaEI7QUFBQSxJQUNBLENBQUNoQixRQUFRO0FBQUEsRUFDWDtBQUVBLFFBQU1pQixjQUFjdEI7QUFBQUEsSUFDbEIsQ0FBQ2MsTUFBMEI7QUFDekIsVUFBSSxDQUFDSCxTQUFTSSxRQUFTO0FBQ3ZCSixlQUFTSSxVQUFVO0FBQ25CUixZQUFNO0FBQ04sTUFBQ08sRUFBRUcsT0FBdUJNLHNCQUFzQlQsRUFBRUssU0FBUztBQUFBLElBQzdEO0FBQUEsSUFDQSxDQUFDWixLQUFLO0FBQUEsRUFDUjtBQUVBTixZQUFVLE1BQU07QUFDZCxVQUFNdUIsT0FBT0EsTUFBTTtBQUNqQixVQUFJYixTQUFTSSxTQUFTO0FBQ3BCSixpQkFBU0ksVUFBVTtBQUNuQlIsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQ0FrQixXQUFPQyxpQkFBaUIsYUFBYUYsSUFBSTtBQUN6QyxXQUFPLE1BQU1DLE9BQU9FLG9CQUFvQixhQUFhSCxJQUFJO0FBQUEsRUFDM0QsR0FBRyxDQUFDakIsS0FBSyxDQUFDO0FBRVYsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsTUFBSztBQUFBLE1BQ0wsb0JBQWlCO0FBQUEsTUFDakI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBLFdBQVdKO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBTTtBQUFBQSxNQUNGO0FBQUE7QUFBQSxJQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVVJO0FBR1I7QUFBQ0MsR0FqRWVOLGVBQWE7QUFBQSxLQUFiQTtBQUFhLElBQUF3QjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZVJlZiIsImNuIiwiUmVzaXplckhhbmRsZSIsIm9uUmVzaXplIiwib25CZWdpbiIsIm9uRW5kIiwidGl0bGUiLCJjbGFzc05hbWUiLCJfcyIsImRyYWdnaW5nIiwibGFzdFgiLCJvblBvaW50ZXJEb3duIiwiZSIsImN1cnJlbnQiLCJjbGllbnRYIiwidGFyZ2V0Iiwic2V0UG9pbnRlckNhcHR1cmUiLCJwb2ludGVySWQiLCJvblBvaW50ZXJNb3ZlIiwiZGVsdGEiLCJvblBvaW50ZXJVcCIsInJlbGVhc2VQb2ludGVyQ2FwdHVyZSIsInN0b3AiLCJ3aW5kb3ciLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJlc2l6ZXJIYW5kbGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcblxuaW50ZXJmYWNlIFJlc2l6ZXJIYW5kbGVQcm9wcyB7XG4gIG9uUmVzaXplOiAoZGVsdGE6IG51bWJlcikgPT4gdm9pZDtcbiAgb25CZWdpbjogKCkgPT4gdm9pZDtcbiAgb25FbmQ6ICgpID0+IHZvaWQ7XG4gIHRpdGxlPzogc3RyaW5nO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59XG5cbi8qKiBEcmFnIGhhbmRsZSBiZXR3ZWVuIHNoZWxsIGNvbHVtbnMgKHdha3UtYWdlbnQgcmVzaXplciBwYXR0ZXJuKS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBSZXNpemVySGFuZGxlKHtcbiAgb25SZXNpemUsXG4gIG9uQmVnaW4sXG4gIG9uRW5kLFxuICB0aXRsZSA9IFwiRHJhZyB0byByZXNpemVcIixcbiAgY2xhc3NOYW1lLFxufTogUmVzaXplckhhbmRsZVByb3BzKTogSlNYLkVsZW1lbnQge1xuICBjb25zdCBkcmFnZ2luZyA9IHVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IGxhc3RYID0gdXNlUmVmKDApO1xuXG4gIGNvbnN0IG9uUG9pbnRlckRvd24gPSB1c2VDYWxsYmFjayhcbiAgICAoZTogUmVhY3QuUG9pbnRlckV2ZW50KSA9PiB7XG4gICAgICBkcmFnZ2luZy5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgIGxhc3RYLmN1cnJlbnQgPSBlLmNsaWVudFg7XG4gICAgICBvbkJlZ2luKCk7XG4gICAgICAoZS50YXJnZXQgYXMgSFRNTEVsZW1lbnQpLnNldFBvaW50ZXJDYXB0dXJlKGUucG9pbnRlcklkKTtcbiAgICB9LFxuICAgIFtvbkJlZ2luXVxuICApO1xuXG4gIGNvbnN0IG9uUG9pbnRlck1vdmUgPSB1c2VDYWxsYmFjayhcbiAgICAoZTogUmVhY3QuUG9pbnRlckV2ZW50KSA9PiB7XG4gICAgICBpZiAoIWRyYWdnaW5nLmN1cnJlbnQpIHJldHVybjtcbiAgICAgIGNvbnN0IGRlbHRhID0gZS5jbGllbnRYIC0gbGFzdFguY3VycmVudDtcbiAgICAgIGxhc3RYLmN1cnJlbnQgPSBlLmNsaWVudFg7XG4gICAgICBvblJlc2l6ZShkZWx0YSk7XG4gICAgfSxcbiAgICBbb25SZXNpemVdXG4gICk7XG5cbiAgY29uc3Qgb25Qb2ludGVyVXAgPSB1c2VDYWxsYmFjayhcbiAgICAoZTogUmVhY3QuUG9pbnRlckV2ZW50KSA9PiB7XG4gICAgICBpZiAoIWRyYWdnaW5nLmN1cnJlbnQpIHJldHVybjtcbiAgICAgIGRyYWdnaW5nLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIG9uRW5kKCk7XG4gICAgICAoZS50YXJnZXQgYXMgSFRNTEVsZW1lbnQpLnJlbGVhc2VQb2ludGVyQ2FwdHVyZShlLnBvaW50ZXJJZCk7XG4gICAgfSxcbiAgICBbb25FbmRdXG4gICk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBzdG9wID0gKCkgPT4ge1xuICAgICAgaWYgKGRyYWdnaW5nLmN1cnJlbnQpIHtcbiAgICAgICAgZHJhZ2dpbmcuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICBvbkVuZCgpO1xuICAgICAgfVxuICAgIH07XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJwb2ludGVydXBcIiwgc3RvcCk7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwicG9pbnRlcnVwXCIsIHN0b3ApO1xuICB9LCBbb25FbmRdKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIHJvbGU9XCJzZXBhcmF0b3JcIlxuICAgICAgYXJpYS1vcmllbnRhdGlvbj1cInZlcnRpY2FsXCJcbiAgICAgIHRpdGxlPXt0aXRsZX1cbiAgICAgIG9uUG9pbnRlckRvd249e29uUG9pbnRlckRvd259XG4gICAgICBvblBvaW50ZXJNb3ZlPXtvblBvaW50ZXJNb3ZlfVxuICAgICAgb25Qb2ludGVyVXA9e29uUG9pbnRlclVwfVxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJzaGVsbC1yZXNpemVyIHctWzVweF0gc2hyaW5rLTAgY3Vyc29yLWNvbC1yZXNpemUgYmctdHJhbnNwYXJlbnQgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6Ymctc2NoZW1hdGljLWFjY2VudC1zb2Z0XCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAvPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvc2hlbGxWMi9SZXNpemVySGFuZGxlLnRzeCJ9