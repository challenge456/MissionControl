import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/automations/AutomationsView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { useLocation, useNavigate, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=83faf592";
import { Bot, RefreshCw } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { PageHeader } from "/src/components/PageHeader.tsx";
import { Card } from "/src/components/ui/card.tsx";
import { AutomationCandidates } from "/src/automations/AutomationCandidates.tsx";
import { AutomationDefinitions } from "/src/automations/AutomationDefinitions.tsx";
import { AutomationOverview } from "/src/automations/AutomationOverview.tsx";
import { AutomationReceipts } from "/src/automations/AutomationReceipts.tsx";
import { AutomationRuns } from "/src/automations/AutomationRuns.tsx";
import { AutomationSchedule } from "/src/automations/AutomationSchedule.tsx";
import { AUTOMATION_TABS, normalizeAutomationTab } from "/src/automations/automationModel.ts";
const TAB_LABELS = {
  overview: "Overview",
  definitions: "Definitions",
  runs: "Runs",
  schedule: "Schedule",
  candidates: "Candidates",
  receipts: "Receipts"
};
export function AutomationsView({
  projectId,
  forceRuns = false
}) {
  _s();
  const location = useLocation();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const tab = forceRuns ? "runs" : normalizeAutomationTab(searchParams.get("tab"));
  const data = useQuery(api.automations.getControlPlane, projectId ? { projectId } : "skip");
  const pathSegments = location.pathname.split("/").filter(Boolean);
  const selectedDefinitionId = pathSegments[1] === "automations" && pathSegments[2] ? pathSegments[2] : null;
  const selectedDefinition = data?.definitions.find((definition) => definition._id === selectedDefinitionId);
  const selectedDecisions = (data?.decisions ?? []).filter((decision) => decision.automationDefinitionId === selectedDefinitionId);
  useEffect(() => {
    if (!forceRuns || searchParams.get("tab") === "runs") return;
    const next = new URLSearchParams(searchParams);
    next.set("tab", "runs");
    setSearchParams(next, { replace: true });
  }, [forceRuns, searchParams, setSearchParams]);
  function setTab(nextTab) {
    const next = new URLSearchParams(searchParams);
    next.set("tab", nextTab);
    setSearchParams(next);
  }
  function selectDefinition(definitionId) {
    const next = new URLSearchParams(searchParams);
    next.set("tab", "definitions");
    navigate({ pathname: `/v2/automations/${definitionId}`, search: `?${next.toString()}` });
  }
  if (!projectId) {
    return /* @__PURE__ */ jsxDEV(StateCard, { title: "Workspace required", body: "Select a workspace before opening Automations.", tone: "error" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
      lineNumber: 82,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("section", { className: "flex min-h-0 flex-1 flex-col overflow-y-auto bg-app", children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        eyebrow: "Operations",
        title: "Automations",
        description: "Governed repetition of versioned Workflows. Skills reason, Tools act, Workflows orchestrate, Automations repeat, Receipts prove, Policies control.",
        icon: /* @__PURE__ */ jsxDEV(Bot, { className: "h-5 w-5" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
          lineNumber: 91,
          columnNumber: 15
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
        lineNumber: 87,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "mx-auto w-full max-w-[1500px] space-y-5 px-4 py-5 sm:px-6", children: [
      /* @__PURE__ */ jsxDEV("div", { role: "tablist", "aria-label": "Automation control plane", className: "flex gap-1 overflow-x-auto rounded-xl border border-[var(--panel-line)] bg-card/40 p-1", children: AUTOMATION_TABS.map(
        (item) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            role: "tab",
            "aria-selected": tab === item,
            "aria-controls": `automation-panel-${item}`,
            onClick: () => setTab(item),
            className: `shrink-0 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${tab === item ? "bg-registry-accent-soft text-foreground" : "text-muted-foreground hover:text-foreground"}`,
            children: TAB_LABELS[item]
          },
          item,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
            lineNumber: 96,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
        lineNumber: 94,
        columnNumber: 9
      }, this),
      selectedDefinitionId ? selectedDefinition ? /* @__PURE__ */ jsxDEV(Card, { className: "border-registry-accent/25 p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-start justify-between gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-xs uppercase tracking-[0.14em] text-registry-accent", children: "Selected Automation" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
              lineNumber: 115,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { className: "mt-1 text-lg font-semibold text-foreground", children: selectedDefinition.name }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
              lineNumber: 116,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-muted-foreground", children: [
              selectedDefinition.workflowId,
              "@",
              selectedDefinition.workflowVersion,
              " · ",
              selectedDefinition.scope
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
              lineNumber: 117,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
            lineNumber: 114,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => navigate({ pathname: "/v2/automations", search: location.search }), className: "text-sm text-muted-foreground hover:text-foreground", children: "Close details" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
            lineNumber: 119,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
          lineNumber: 113,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("dl", { className: "mt-4 grid gap-3 text-sm sm:grid-cols-2 lg:grid-cols-4", children: [
          /* @__PURE__ */ jsxDEV(Detail, { label: "Status", value: selectedDefinition.status }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
            lineNumber: 122,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Detail, { label: "Autonomy", value: selectedDefinition.autonomyLevel }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
            lineNumber: 123,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Detail, { label: "Approval", value: selectedDefinition.requiredApprovalTypes.join(", ") }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
            lineNumber: 124,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Detail, { label: "Verification", value: selectedDefinition.verificationContract?.receiptRequired ? "Receipt required" : "Not configured" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
            lineNumber: 125,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
          lineNumber: 121,
          columnNumber: 15
        }, this),
        selectedDecisions[0] ? /* @__PURE__ */ jsxDEV("div", { className: "mt-4 rounded-lg border border-border bg-muted/20 p-3 text-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-foreground", children: "Latest governed decision" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
            lineNumber: 129,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-2 grid gap-2 text-muted-foreground sm:grid-cols-2 lg:grid-cols-4", children: [
            /* @__PURE__ */ jsxDEV("span", { children: [
              selectedDecisions[0].decisionType,
              " by ",
              selectedDecisions[0].actorId
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
              lineNumber: 131,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: selectedDecisions[0].policyVersion }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
              lineNumber: 132,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: [
              "Definition v",
              selectedDecisions[0].definitionVersion
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
              lineNumber: 133,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: new Date(selectedDecisions[0].decidedAt).toLocaleString() }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
              lineNumber: 134,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
            lineNumber: 130,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-muted-foreground", children: selectedDecisions[0].reason }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
            lineNumber: 136,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
          lineNumber: 128,
          columnNumber: 11
        }, this) : null
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
        lineNumber: 112,
        columnNumber: 9
      }, this) : data ? /* @__PURE__ */ jsxDEV(StateCard, { title: "Automation scope error", body: "This Automation does not exist in the selected workspace.", tone: "error" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
        lineNumber: 140,
        columnNumber: 16
      }, this) : null : null,
      !data ? /* @__PURE__ */ jsxDEV(StateCard, { title: "Loading Automations", body: "Reading workspace definitions, candidates, review gates, and receipts." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
        lineNumber: 144,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { id: `automation-panel-${tab}`, role: "tabpanel", "aria-label": TAB_LABELS[tab], tabIndex: 0, children: [
        tab === "overview" ? /* @__PURE__ */ jsxDEV(AutomationOverview, { data, onTabChange: setTab }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
          lineNumber: 147,
          columnNumber: 35
        }, this) : null,
        tab === "definitions" ? /* @__PURE__ */ jsxDEV(AutomationDefinitions, { projectId, definitions: data.definitions, onSelect: selectDefinition }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
          lineNumber: 148,
          columnNumber: 38
        }, this) : null,
        tab === "runs" ? /* @__PURE__ */ jsxDEV(AutomationRuns, { runs: data.runs }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
          lineNumber: 149,
          columnNumber: 31
        }, this) : null,
        tab === "schedule" ? /* @__PURE__ */ jsxDEV(AutomationSchedule, { projectId, definitions: data.definitions }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
          lineNumber: 150,
          columnNumber: 35
        }, this) : null,
        tab === "candidates" ? /* @__PURE__ */ jsxDEV(AutomationCandidates, { projectId, candidates: data.candidates }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
          lineNumber: 151,
          columnNumber: 37
        }, this) : null,
        tab === "receipts" ? /* @__PURE__ */ jsxDEV(AutomationReceipts, { receipts: data.receipts }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
          lineNumber: 152,
          columnNumber: 35
        }, this) : null
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
        lineNumber: 146,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
      lineNumber: 93,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
    lineNumber: 86,
    columnNumber: 5
  }, this);
}
_s(AutomationsView, "J+EEKfjW4O+YDbrEB2Rut9HopY4=", false, function() {
  return [useLocation, useNavigate, useSearchParams, useQuery];
});
_c = AutomationsView;
function StateCard({ title, body, tone = "default" }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-1 items-center justify-center bg-app p-6", children: /* @__PURE__ */ jsxDEV(Card, { className: `max-w-lg p-6 text-center ${tone === "error" ? "border-red-500/30" : ""}`, children: [
    /* @__PURE__ */ jsxDEV(RefreshCw, { className: "mx-auto h-5 w-5 text-muted-foreground" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
      lineNumber: 163,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { className: "mt-3 text-lg font-semibold text-foreground", children: title }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
      lineNumber: 164,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-muted-foreground", children: body }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
      lineNumber: 165,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
    lineNumber: 162,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
    lineNumber: 161,
    columnNumber: 10
  }, this);
}
_c2 = StateCard;
function Detail({ label, value }) {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("dt", { className: "text-xs text-muted-foreground", children: label }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
      lineNumber: 171,
      columnNumber: 15
    }, this),
    /* @__PURE__ */ jsxDEV("dd", { className: "mt-1 text-foreground", children: value }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
      lineNumber: 171,
      columnNumber: 73
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx",
    lineNumber: 171,
    columnNumber: 10
  }, this);
}
_c3 = Detail;
var _c, _c2, _c3;
$RefreshReg$(_c, "AutomationsView");
$RefreshReg$(_c2, "StateCard");
$RefreshReg$(_c3, "Detail");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationsView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOERXOzs7Ozs7Ozs7Ozs7Ozs7OztBQTlEWCxTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGFBQWFDLGFBQWFDLHVCQUF1QjtBQUMxRCxTQUFTQyxLQUFLQyxpQkFBaUI7QUFDL0IsU0FBU0MsV0FBVztBQUVwQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MsNkJBQTZCO0FBQ3RDLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQywwQkFBMEI7QUFDbkMsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxpQkFBaUJDLDhCQUFrRDtBQUU1RSxNQUFNQyxhQUE0QztBQUFBLEVBQ2hEQyxVQUFVO0FBQUEsRUFDVkMsYUFBYTtBQUFBLEVBQ2JDLE1BQU07QUFBQSxFQUNOQyxVQUFVO0FBQUEsRUFDVkMsWUFBWTtBQUFBLEVBQ1pDLFVBQVU7QUFDWjtBQUVPLGdCQUFTQyxnQkFBZ0I7QUFBQSxFQUM5QkM7QUFBQUEsRUFDQUMsWUFBWTtBQUlkLEdBQUc7QUFBQUMsS0FBQTtBQUNELFFBQU1DLFdBQVczQixZQUFZO0FBQzdCLFFBQU00QixXQUFXM0IsWUFBWTtBQUM3QixRQUFNLENBQUM0QixjQUFjQyxlQUFlLElBQUk1QixnQkFBZ0I7QUFDeEQsUUFBTTZCLE1BQU1OLFlBQVksU0FBU1YsdUJBQXVCYyxhQUFhRyxJQUFJLEtBQUssQ0FBQztBQUMvRSxRQUFNQyxPQUFPbEMsU0FBU00sSUFBSTZCLFlBQVlDLGlCQUFpQlgsWUFBWSxFQUFFQSxVQUFVLElBQUksTUFBTTtBQUN6RixRQUFNWSxlQUFlVCxTQUFTVSxTQUFTQyxNQUFNLEdBQUcsRUFBRUMsT0FBT0MsT0FBTztBQUNoRSxRQUFNQyx1QkFBdUJMLGFBQWEsQ0FBQyxNQUFNLGlCQUFpQkEsYUFBYSxDQUFDLElBQUlBLGFBQWEsQ0FBQyxJQUFJO0FBQ3RHLFFBQU1NLHFCQUFxQlQsTUFBTWYsWUFBWXlCLEtBQUssQ0FBQ0MsZUFBb0JBLFdBQVdDLFFBQVFKLG9CQUFvQjtBQUM5RyxRQUFNSyxxQkFBcUJiLE1BQU1jLGFBQWEsSUFBSVIsT0FBTyxDQUFDUyxhQUFrQkEsU0FBU0MsMkJBQTJCUixvQkFBb0I7QUFFcEkzQyxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUMyQixhQUFhSSxhQUFhRyxJQUFJLEtBQUssTUFBTSxPQUFRO0FBQ3RELFVBQU1rQixPQUFPLElBQUlDLGdCQUFnQnRCLFlBQVk7QUFDN0NxQixTQUFLRSxJQUFJLE9BQU8sTUFBTTtBQUN0QnRCLG9CQUFnQm9CLE1BQU0sRUFBRUcsU0FBUyxLQUFLLENBQUM7QUFBQSxFQUN6QyxHQUFHLENBQUM1QixXQUFXSSxjQUFjQyxlQUFlLENBQUM7QUFFN0MsV0FBU3dCLE9BQU9DLFNBQXdCO0FBQ3RDLFVBQU1MLE9BQU8sSUFBSUMsZ0JBQWdCdEIsWUFBWTtBQUM3Q3FCLFNBQUtFLElBQUksT0FBT0csT0FBTztBQUN2QnpCLG9CQUFnQm9CLElBQUk7QUFBQSxFQUN0QjtBQUVBLFdBQVNNLGlCQUFpQkMsY0FBc0I7QUFDOUMsVUFBTVAsT0FBTyxJQUFJQyxnQkFBZ0J0QixZQUFZO0FBQzdDcUIsU0FBS0UsSUFBSSxPQUFPLGFBQWE7QUFDN0J4QixhQUFTLEVBQUVTLFVBQVUsbUJBQW1Cb0IsWUFBWSxJQUFJQyxRQUFRLElBQUlSLEtBQUtTLFNBQVMsQ0FBQyxHQUFHLENBQUM7QUFBQSxFQUN6RjtBQUVBLE1BQUksQ0FBQ25DLFdBQVc7QUFDZCxXQUFPLHVCQUFDLGFBQVUsT0FBTSxzQkFBcUIsTUFBSyxrREFBaUQsTUFBSyxXQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdHO0FBQUEsRUFDakg7QUFFQSxTQUNFLHVCQUFDLGFBQVEsV0FBVSx1REFDakI7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsU0FBUTtBQUFBLFFBQ1IsT0FBTTtBQUFBLFFBQ04sYUFBWTtBQUFBLFFBQ1osTUFBTSx1QkFBQyxPQUFJLFdBQVUsYUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdCO0FBQUE7QUFBQSxNQUpoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJb0M7QUFBQSxJQUVwQyx1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSw2QkFBQyxTQUFJLE1BQUssV0FBVSxjQUFXLDRCQUEyQixXQUFVLDBGQUNqRVYsMEJBQWdCOEM7QUFBQUEsUUFBSSxDQUFDQyxTQUNwQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsTUFBSztBQUFBLFlBQ0wsTUFBSztBQUFBLFlBQ0wsaUJBQWU5QixRQUFROEI7QUFBQUEsWUFDdkIsaUJBQWUsb0JBQW9CQSxJQUFJO0FBQUEsWUFDdkMsU0FBUyxNQUFNUCxPQUFPTyxJQUFJO0FBQUEsWUFDMUIsV0FBVyx1RUFBdUU5QixRQUFROEIsT0FBTyw0Q0FBNEMsNkNBQTZDO0FBQUEsWUFFekw3QyxxQkFBVzZDLElBQUk7QUFBQTtBQUFBLFVBUlhBO0FBQUFBLFVBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVVBO0FBQUEsTUFDRCxLQWJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLE1BRUNwQix1QkFDQ0MscUJBQ0UsdUJBQUMsUUFBSyxXQUFVLGlDQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG9EQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFNBQUksV0FBVSw0REFBMkQsbUNBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZGO0FBQUEsWUFDN0YsdUJBQUMsUUFBRyxXQUFVLDhDQUE4Q0EsNkJBQW1Cb0IsUUFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Y7QUFBQSxZQUNwRix1QkFBQyxPQUFFLFdBQVUsc0NBQXNDcEI7QUFBQUEsaUNBQW1CcUI7QUFBQUEsY0FBVztBQUFBLGNBQUVyQixtQkFBbUJzQjtBQUFBQSxjQUFnQjtBQUFBLGNBQUl0QixtQkFBbUJ1QjtBQUFBQSxpQkFBN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUo7QUFBQSxlQUhySjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU1yQyxTQUFTLEVBQUVTLFVBQVUsbUJBQW1CcUIsUUFBUS9CLFNBQVMrQixPQUFPLENBQUMsR0FBRyxXQUFVLHVEQUFzRCw2QkFBeks7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0w7QUFBQSxhQU54TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSx5REFDWjtBQUFBLGlDQUFDLFVBQU8sT0FBTSxVQUFTLE9BQU9oQixtQkFBbUJ3QixVQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLFVBQ3hELHVCQUFDLFVBQU8sT0FBTSxZQUFXLE9BQU94QixtQkFBbUJ5QixpQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUU7QUFBQSxVQUNqRSx1QkFBQyxVQUFPLE9BQU0sWUFBVyxPQUFPekIsbUJBQW1CMEIsc0JBQXNCQyxLQUFLLElBQUksS0FBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Y7QUFBQSxVQUNwRix1QkFBQyxVQUFPLE9BQU0sZ0JBQWUsT0FBTzNCLG1CQUFtQjRCLHNCQUFzQkMsa0JBQWtCLHFCQUFxQixvQkFBcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUk7QUFBQSxhQUp2STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNDekIsa0JBQWtCLENBQUMsSUFDbEIsdUJBQUMsU0FBSSxXQUFVLGdFQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLCtCQUE4Qix3Q0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUU7QUFBQSxVQUNyRSx1QkFBQyxTQUFJLFdBQVUsdUVBQ2I7QUFBQSxtQ0FBQyxVQUFNQTtBQUFBQSxnQ0FBa0IsQ0FBQyxFQUFFMEI7QUFBQUEsY0FBYTtBQUFBLGNBQUsxQixrQkFBa0IsQ0FBQyxFQUFFMkI7QUFBQUEsaUJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJFO0FBQUEsWUFDM0UsdUJBQUMsVUFBTTNCLDRCQUFrQixDQUFDLEVBQUU0QixpQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEM7QUFBQSxZQUMxQyx1QkFBQyxVQUFLO0FBQUE7QUFBQSxjQUFhNUIsa0JBQWtCLENBQUMsRUFBRTZCO0FBQUFBLGlCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRDtBQUFBLFlBQzFELHVCQUFDLFVBQU0sY0FBSUMsS0FBSzlCLGtCQUFrQixDQUFDLEVBQUUrQixTQUFTLEVBQUVDLGVBQWUsS0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUU7QUFBQSxlQUpuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQThCaEMsNEJBQWtCLENBQUMsRUFBRWlDLFVBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVFO0FBQUEsYUFSekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBLElBQ0U7QUFBQSxXQTFCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkJBLElBQ0U5QyxPQUFPLHVCQUFDLGFBQVUsT0FBTSwwQkFBeUIsTUFBSyw2REFBNEQsTUFBSyxXQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVILElBQU0sT0FDdEk7QUFBQSxNQUVILENBQUNBLE9BQ0EsdUJBQUMsYUFBVSxPQUFNLHVCQUFzQixNQUFLLDRFQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9ILElBRXBILHVCQUFDLFNBQUksSUFBSSxvQkFBb0JGLEdBQUcsSUFBSSxNQUFLLFlBQVcsY0FBWWYsV0FBV2UsR0FBRyxHQUFHLFVBQVUsR0FDeEZBO0FBQUFBLGdCQUFRLGFBQWEsdUJBQUMsc0JBQW1CLE1BQVksYUFBYXVCLFVBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0QsSUFBTTtBQUFBLFFBQy9FdkIsUUFBUSxnQkFBZ0IsdUJBQUMseUJBQXNCLFdBQXNCLGFBQWFFLEtBQUtmLGFBQWEsVUFBVXNDLG9CQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVHLElBQU07QUFBQSxRQUNySXpCLFFBQVEsU0FBUyx1QkFBQyxrQkFBZSxNQUFNRSxLQUFLZCxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDLElBQU07QUFBQSxRQUN2RFksUUFBUSxhQUFhLHVCQUFDLHNCQUFtQixXQUFzQixhQUFhRSxLQUFLZixlQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdFLElBQU07QUFBQSxRQUNuR2EsUUFBUSxlQUFlLHVCQUFDLHdCQUFxQixXQUFzQixZQUFZRSxLQUFLWixjQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdFLElBQU07QUFBQSxRQUNyR1UsUUFBUSxhQUFhLHVCQUFDLHNCQUFtQixVQUFVRSxLQUFLWCxZQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRDLElBQU07QUFBQSxXQU4xRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxTQTVESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOERBO0FBQUEsT0FyRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNFQTtBQUVKO0FBQUNJLEdBakhlSCxpQkFBZTtBQUFBLFVBT1p2QixhQUNBQyxhQUN1QkMsaUJBRTNCSCxRQUFRO0FBQUE7QUFBQSxLQVhQd0I7QUFtSGhCLFNBQVN5RCxVQUFVLEVBQUVDLE9BQU9DLE1BQU1DLE9BQU8sVUFBdUUsR0FBRztBQUNqSCxTQUFPLHVCQUFDLFNBQUksV0FBVSxzREFDcEIsaUNBQUMsUUFBSyxXQUFXLDRCQUE0QkEsU0FBUyxVQUFVLHNCQUFzQixFQUFFLElBQ3RGO0FBQUEsMkJBQUMsYUFBVSxXQUFVLDJDQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTREO0FBQUEsSUFDNUQsdUJBQUMsUUFBRyxXQUFVLDhDQUE4Q0YsbUJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0U7QUFBQSxJQUNsRSx1QkFBQyxPQUFFLFdBQVUsc0NBQXNDQyxrQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RDtBQUFBLE9BSDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJQSxLQUxLO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FNUDtBQUNGO0FBQUNFLE1BUlFKO0FBVVQsU0FBU0ssT0FBTyxFQUFFQyxPQUFPQyxNQUF3QyxHQUFHO0FBQ2xFLFNBQU8sdUJBQUMsU0FBSTtBQUFBLDJCQUFDLFFBQUcsV0FBVSxpQ0FBaUNELG1CQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFEO0FBQUEsSUFBSyx1QkFBQyxRQUFHLFdBQVUsd0JBQXdCQyxtQkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0QztBQUFBLE9BQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZ0g7QUFDekg7QUFBQ0MsTUFGUUg7QUFBTSxJQUFBSSxJQUFBTCxLQUFBSTtBQUFBLGFBQUFDLElBQUE7QUFBQSxhQUFBTCxLQUFBO0FBQUEsYUFBQUksS0FBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVF1ZXJ5IiwidXNlTG9jYXRpb24iLCJ1c2VOYXZpZ2F0ZSIsInVzZVNlYXJjaFBhcmFtcyIsIkJvdCIsIlJlZnJlc2hDdyIsImFwaSIsIlBhZ2VIZWFkZXIiLCJDYXJkIiwiQXV0b21hdGlvbkNhbmRpZGF0ZXMiLCJBdXRvbWF0aW9uRGVmaW5pdGlvbnMiLCJBdXRvbWF0aW9uT3ZlcnZpZXciLCJBdXRvbWF0aW9uUmVjZWlwdHMiLCJBdXRvbWF0aW9uUnVucyIsIkF1dG9tYXRpb25TY2hlZHVsZSIsIkFVVE9NQVRJT05fVEFCUyIsIm5vcm1hbGl6ZUF1dG9tYXRpb25UYWIiLCJUQUJfTEFCRUxTIiwib3ZlcnZpZXciLCJkZWZpbml0aW9ucyIsInJ1bnMiLCJzY2hlZHVsZSIsImNhbmRpZGF0ZXMiLCJyZWNlaXB0cyIsIkF1dG9tYXRpb25zVmlldyIsInByb2plY3RJZCIsImZvcmNlUnVucyIsIl9zIiwibG9jYXRpb24iLCJuYXZpZ2F0ZSIsInNlYXJjaFBhcmFtcyIsInNldFNlYXJjaFBhcmFtcyIsInRhYiIsImdldCIsImRhdGEiLCJhdXRvbWF0aW9ucyIsImdldENvbnRyb2xQbGFuZSIsInBhdGhTZWdtZW50cyIsInBhdGhuYW1lIiwic3BsaXQiLCJmaWx0ZXIiLCJCb29sZWFuIiwic2VsZWN0ZWREZWZpbml0aW9uSWQiLCJzZWxlY3RlZERlZmluaXRpb24iLCJmaW5kIiwiZGVmaW5pdGlvbiIsIl9pZCIsInNlbGVjdGVkRGVjaXNpb25zIiwiZGVjaXNpb25zIiwiZGVjaXNpb24iLCJhdXRvbWF0aW9uRGVmaW5pdGlvbklkIiwibmV4dCIsIlVSTFNlYXJjaFBhcmFtcyIsInNldCIsInJlcGxhY2UiLCJzZXRUYWIiLCJuZXh0VGFiIiwic2VsZWN0RGVmaW5pdGlvbiIsImRlZmluaXRpb25JZCIsInNlYXJjaCIsInRvU3RyaW5nIiwibWFwIiwiaXRlbSIsIm5hbWUiLCJ3b3JrZmxvd0lkIiwid29ya2Zsb3dWZXJzaW9uIiwic2NvcGUiLCJzdGF0dXMiLCJhdXRvbm9teUxldmVsIiwicmVxdWlyZWRBcHByb3ZhbFR5cGVzIiwiam9pbiIsInZlcmlmaWNhdGlvbkNvbnRyYWN0IiwicmVjZWlwdFJlcXVpcmVkIiwiZGVjaXNpb25UeXBlIiwiYWN0b3JJZCIsInBvbGljeVZlcnNpb24iLCJkZWZpbml0aW9uVmVyc2lvbiIsIkRhdGUiLCJkZWNpZGVkQXQiLCJ0b0xvY2FsZVN0cmluZyIsInJlYXNvbiIsIlN0YXRlQ2FyZCIsInRpdGxlIiwiYm9keSIsInRvbmUiLCJfYzIiLCJEZXRhaWwiLCJsYWJlbCIsInZhbHVlIiwiX2MzIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXV0b21hdGlvbnNWaWV3LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5IH0gZnJvbSBcImNvbnZleC9yZWFjdFwiO1xuaW1wb3J0IHsgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlLCB1c2VTZWFyY2hQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgQm90LCBSZWZyZXNoQ3cgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgUGFnZUhlYWRlciB9IGZyb20gXCJAL2NvbXBvbmVudHMvUGFnZUhlYWRlclwiO1xuaW1wb3J0IHsgQ2FyZCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvY2FyZFwiO1xuaW1wb3J0IHsgQXV0b21hdGlvbkNhbmRpZGF0ZXMgfSBmcm9tIFwiLi9BdXRvbWF0aW9uQ2FuZGlkYXRlc1wiO1xuaW1wb3J0IHsgQXV0b21hdGlvbkRlZmluaXRpb25zIH0gZnJvbSBcIi4vQXV0b21hdGlvbkRlZmluaXRpb25zXCI7XG5pbXBvcnQgeyBBdXRvbWF0aW9uT3ZlcnZpZXcgfSBmcm9tIFwiLi9BdXRvbWF0aW9uT3ZlcnZpZXdcIjtcbmltcG9ydCB7IEF1dG9tYXRpb25SZWNlaXB0cyB9IGZyb20gXCIuL0F1dG9tYXRpb25SZWNlaXB0c1wiO1xuaW1wb3J0IHsgQXV0b21hdGlvblJ1bnMgfSBmcm9tIFwiLi9BdXRvbWF0aW9uUnVuc1wiO1xuaW1wb3J0IHsgQXV0b21hdGlvblNjaGVkdWxlIH0gZnJvbSBcIi4vQXV0b21hdGlvblNjaGVkdWxlXCI7XG5pbXBvcnQgeyBBVVRPTUFUSU9OX1RBQlMsIG5vcm1hbGl6ZUF1dG9tYXRpb25UYWIsIHR5cGUgQXV0b21hdGlvblRhYiB9IGZyb20gXCIuL2F1dG9tYXRpb25Nb2RlbFwiO1xuXG5jb25zdCBUQUJfTEFCRUxTOiBSZWNvcmQ8QXV0b21hdGlvblRhYiwgc3RyaW5nPiA9IHtcbiAgb3ZlcnZpZXc6IFwiT3ZlcnZpZXdcIixcbiAgZGVmaW5pdGlvbnM6IFwiRGVmaW5pdGlvbnNcIixcbiAgcnVuczogXCJSdW5zXCIsXG4gIHNjaGVkdWxlOiBcIlNjaGVkdWxlXCIsXG4gIGNhbmRpZGF0ZXM6IFwiQ2FuZGlkYXRlc1wiLFxuICByZWNlaXB0czogXCJSZWNlaXB0c1wiLFxufTtcblxuZXhwb3J0IGZ1bmN0aW9uIEF1dG9tYXRpb25zVmlldyh7XG4gIHByb2plY3RJZCxcbiAgZm9yY2VSdW5zID0gZmFsc2UsXG59OiB7XG4gIHByb2plY3RJZDogSWQ8XCJwcm9qZWN0c1wiPiB8IG51bGw7XG4gIGZvcmNlUnVucz86IGJvb2xlYW47XG59KSB7XG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICBjb25zdCBbc2VhcmNoUGFyYW1zLCBzZXRTZWFyY2hQYXJhbXNdID0gdXNlU2VhcmNoUGFyYW1zKCk7XG4gIGNvbnN0IHRhYiA9IGZvcmNlUnVucyA/IFwicnVuc1wiIDogbm9ybWFsaXplQXV0b21hdGlvblRhYihzZWFyY2hQYXJhbXMuZ2V0KFwidGFiXCIpKTtcbiAgY29uc3QgZGF0YSA9IHVzZVF1ZXJ5KGFwaS5hdXRvbWF0aW9ucy5nZXRDb250cm9sUGxhbmUsIHByb2plY3RJZCA/IHsgcHJvamVjdElkIH0gOiBcInNraXBcIik7XG4gIGNvbnN0IHBhdGhTZWdtZW50cyA9IGxvY2F0aW9uLnBhdGhuYW1lLnNwbGl0KFwiL1wiKS5maWx0ZXIoQm9vbGVhbik7XG4gIGNvbnN0IHNlbGVjdGVkRGVmaW5pdGlvbklkID0gcGF0aFNlZ21lbnRzWzFdID09PSBcImF1dG9tYXRpb25zXCIgJiYgcGF0aFNlZ21lbnRzWzJdID8gcGF0aFNlZ21lbnRzWzJdIDogbnVsbDtcbiAgY29uc3Qgc2VsZWN0ZWREZWZpbml0aW9uID0gZGF0YT8uZGVmaW5pdGlvbnMuZmluZCgoZGVmaW5pdGlvbjogYW55KSA9PiBkZWZpbml0aW9uLl9pZCA9PT0gc2VsZWN0ZWREZWZpbml0aW9uSWQpO1xuICBjb25zdCBzZWxlY3RlZERlY2lzaW9ucyA9IChkYXRhPy5kZWNpc2lvbnMgPz8gW10pLmZpbHRlcigoZGVjaXNpb246IGFueSkgPT4gZGVjaXNpb24uYXV0b21hdGlvbkRlZmluaXRpb25JZCA9PT0gc2VsZWN0ZWREZWZpbml0aW9uSWQpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFmb3JjZVJ1bnMgfHwgc2VhcmNoUGFyYW1zLmdldChcInRhYlwiKSA9PT0gXCJydW5zXCIpIHJldHVybjtcbiAgICBjb25zdCBuZXh0ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhzZWFyY2hQYXJhbXMpO1xuICAgIG5leHQuc2V0KFwidGFiXCIsIFwicnVuc1wiKTtcbiAgICBzZXRTZWFyY2hQYXJhbXMobmV4dCwgeyByZXBsYWNlOiB0cnVlIH0pO1xuICB9LCBbZm9yY2VSdW5zLCBzZWFyY2hQYXJhbXMsIHNldFNlYXJjaFBhcmFtc10pO1xuXG4gIGZ1bmN0aW9uIHNldFRhYihuZXh0VGFiOiBBdXRvbWF0aW9uVGFiKSB7XG4gICAgY29uc3QgbmV4dCA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoc2VhcmNoUGFyYW1zKTtcbiAgICBuZXh0LnNldChcInRhYlwiLCBuZXh0VGFiKTtcbiAgICBzZXRTZWFyY2hQYXJhbXMobmV4dCk7XG4gIH1cblxuICBmdW5jdGlvbiBzZWxlY3REZWZpbml0aW9uKGRlZmluaXRpb25JZDogc3RyaW5nKSB7XG4gICAgY29uc3QgbmV4dCA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoc2VhcmNoUGFyYW1zKTtcbiAgICBuZXh0LnNldChcInRhYlwiLCBcImRlZmluaXRpb25zXCIpO1xuICAgIG5hdmlnYXRlKHsgcGF0aG5hbWU6IGAvdjIvYXV0b21hdGlvbnMvJHtkZWZpbml0aW9uSWR9YCwgc2VhcmNoOiBgPyR7bmV4dC50b1N0cmluZygpfWAgfSk7XG4gIH1cblxuICBpZiAoIXByb2plY3RJZCkge1xuICAgIHJldHVybiA8U3RhdGVDYXJkIHRpdGxlPVwiV29ya3NwYWNlIHJlcXVpcmVkXCIgYm9keT1cIlNlbGVjdCBhIHdvcmtzcGFjZSBiZWZvcmUgb3BlbmluZyBBdXRvbWF0aW9ucy5cIiB0b25lPVwiZXJyb3JcIiAvPjtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiZmxleCBtaW4taC0wIGZsZXgtMSBmbGV4LWNvbCBvdmVyZmxvdy15LWF1dG8gYmctYXBwXCI+XG4gICAgICA8UGFnZUhlYWRlclxuICAgICAgICBleWVicm93PVwiT3BlcmF0aW9uc1wiXG4gICAgICAgIHRpdGxlPVwiQXV0b21hdGlvbnNcIlxuICAgICAgICBkZXNjcmlwdGlvbj1cIkdvdmVybmVkIHJlcGV0aXRpb24gb2YgdmVyc2lvbmVkIFdvcmtmbG93cy4gU2tpbGxzIHJlYXNvbiwgVG9vbHMgYWN0LCBXb3JrZmxvd3Mgb3JjaGVzdHJhdGUsIEF1dG9tYXRpb25zIHJlcGVhdCwgUmVjZWlwdHMgcHJvdmUsIFBvbGljaWVzIGNvbnRyb2wuXCJcbiAgICAgICAgaWNvbj17PEJvdCBjbGFzc05hbWU9XCJoLTUgdy01XCIgLz59XG4gICAgICAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIHctZnVsbCBtYXgtdy1bMTUwMHB4XSBzcGFjZS15LTUgcHgtNCBweS01IHNtOnB4LTZcIj5cbiAgICAgICAgPGRpdiByb2xlPVwidGFibGlzdFwiIGFyaWEtbGFiZWw9XCJBdXRvbWF0aW9uIGNvbnRyb2wgcGxhbmVcIiBjbGFzc05hbWU9XCJmbGV4IGdhcC0xIG92ZXJmbG93LXgtYXV0byByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItW3ZhcigtLXBhbmVsLWxpbmUpXSBiZy1jYXJkLzQwIHAtMVwiPlxuICAgICAgICAgIHtBVVRPTUFUSU9OX1RBQlMubWFwKChpdGVtKSA9PiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIGtleT17aXRlbX1cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIHJvbGU9XCJ0YWJcIlxuICAgICAgICAgICAgICBhcmlhLXNlbGVjdGVkPXt0YWIgPT09IGl0ZW19XG4gICAgICAgICAgICAgIGFyaWEtY29udHJvbHM9e2BhdXRvbWF0aW9uLXBhbmVsLSR7aXRlbX1gfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUYWIoaXRlbSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHNocmluay0wIHJvdW5kZWQtbGcgcHgtMyBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgJHt0YWIgPT09IGl0ZW0gPyBcImJnLXJlZ2lzdHJ5LWFjY2VudC1zb2Z0IHRleHQtZm9yZWdyb3VuZFwiIDogXCJ0ZXh0LW11dGVkLWZvcmVncm91bmQgaG92ZXI6dGV4dC1mb3JlZ3JvdW5kXCJ9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge1RBQl9MQUJFTFNbaXRlbV19XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAge3NlbGVjdGVkRGVmaW5pdGlvbklkID8gKFxuICAgICAgICAgIHNlbGVjdGVkRGVmaW5pdGlvbiA/IChcbiAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cImJvcmRlci1yZWdpc3RyeS1hY2NlbnQvMjUgcC00XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMTRlbV0gdGV4dC1yZWdpc3RyeS1hY2NlbnRcIj5TZWxlY3RlZCBBdXRvbWF0aW9uPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+e3NlbGVjdGVkRGVmaW5pdGlvbi5uYW1lfTwvaDI+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e3NlbGVjdGVkRGVmaW5pdGlvbi53b3JrZmxvd0lkfUB7c2VsZWN0ZWREZWZpbml0aW9uLndvcmtmbG93VmVyc2lvbn0gwrcge3NlbGVjdGVkRGVmaW5pdGlvbi5zY29wZX08L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoeyBwYXRobmFtZTogXCIvdjIvYXV0b21hdGlvbnNcIiwgc2VhcmNoOiBsb2NhdGlvbi5zZWFyY2ggfSl9IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGhvdmVyOnRleHQtZm9yZWdyb3VuZFwiPkNsb3NlIGRldGFpbHM8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkbCBjbGFzc05hbWU9XCJtdC00IGdyaWQgZ2FwLTMgdGV4dC1zbSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNFwiPlxuICAgICAgICAgICAgICAgIDxEZXRhaWwgbGFiZWw9XCJTdGF0dXNcIiB2YWx1ZT17c2VsZWN0ZWREZWZpbml0aW9uLnN0YXR1c30gLz5cbiAgICAgICAgICAgICAgICA8RGV0YWlsIGxhYmVsPVwiQXV0b25vbXlcIiB2YWx1ZT17c2VsZWN0ZWREZWZpbml0aW9uLmF1dG9ub215TGV2ZWx9IC8+XG4gICAgICAgICAgICAgICAgPERldGFpbCBsYWJlbD1cIkFwcHJvdmFsXCIgdmFsdWU9e3NlbGVjdGVkRGVmaW5pdGlvbi5yZXF1aXJlZEFwcHJvdmFsVHlwZXMuam9pbihcIiwgXCIpfSAvPlxuICAgICAgICAgICAgICAgIDxEZXRhaWwgbGFiZWw9XCJWZXJpZmljYXRpb25cIiB2YWx1ZT17c2VsZWN0ZWREZWZpbml0aW9uLnZlcmlmaWNhdGlvbkNvbnRyYWN0Py5yZWNlaXB0UmVxdWlyZWQgPyBcIlJlY2VpcHQgcmVxdWlyZWRcIiA6IFwiTm90IGNvbmZpZ3VyZWRcIn0gLz5cbiAgICAgICAgICAgICAgPC9kbD5cbiAgICAgICAgICAgICAge3NlbGVjdGVkRGVjaXNpb25zWzBdID8gKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLW11dGVkLzIwIHAtMyB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZm9yZWdyb3VuZFwiPkxhdGVzdCBnb3Zlcm5lZCBkZWNpc2lvbjwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIGdyaWQgZ2FwLTIgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPntzZWxlY3RlZERlY2lzaW9uc1swXS5kZWNpc2lvblR5cGV9IGJ5IHtzZWxlY3RlZERlY2lzaW9uc1swXS5hY3RvcklkfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3NlbGVjdGVkRGVjaXNpb25zWzBdLnBvbGljeVZlcnNpb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5EZWZpbml0aW9uIHZ7c2VsZWN0ZWREZWNpc2lvbnNbMF0uZGVmaW5pdGlvblZlcnNpb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57bmV3IERhdGUoc2VsZWN0ZWREZWNpc2lvbnNbMF0uZGVjaWRlZEF0KS50b0xvY2FsZVN0cmluZygpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57c2VsZWN0ZWREZWNpc2lvbnNbMF0ucmVhc29ufTwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgKSA6IGRhdGEgPyA8U3RhdGVDYXJkIHRpdGxlPVwiQXV0b21hdGlvbiBzY29wZSBlcnJvclwiIGJvZHk9XCJUaGlzIEF1dG9tYXRpb24gZG9lcyBub3QgZXhpc3QgaW4gdGhlIHNlbGVjdGVkIHdvcmtzcGFjZS5cIiB0b25lPVwiZXJyb3JcIiAvPiA6IG51bGxcbiAgICAgICAgKSA6IG51bGx9XG5cbiAgICAgICAgeyFkYXRhID8gKFxuICAgICAgICAgIDxTdGF0ZUNhcmQgdGl0bGU9XCJMb2FkaW5nIEF1dG9tYXRpb25zXCIgYm9keT1cIlJlYWRpbmcgd29ya3NwYWNlIGRlZmluaXRpb25zLCBjYW5kaWRhdGVzLCByZXZpZXcgZ2F0ZXMsIGFuZCByZWNlaXB0cy5cIiAvPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxkaXYgaWQ9e2BhdXRvbWF0aW9uLXBhbmVsLSR7dGFifWB9IHJvbGU9XCJ0YWJwYW5lbFwiIGFyaWEtbGFiZWw9e1RBQl9MQUJFTFNbdGFiXX0gdGFiSW5kZXg9ezB9PlxuICAgICAgICAgICAge3RhYiA9PT0gXCJvdmVydmlld1wiID8gPEF1dG9tYXRpb25PdmVydmlldyBkYXRhPXtkYXRhfSBvblRhYkNoYW5nZT17c2V0VGFifSAvPiA6IG51bGx9XG4gICAgICAgICAgICB7dGFiID09PSBcImRlZmluaXRpb25zXCIgPyA8QXV0b21hdGlvbkRlZmluaXRpb25zIHByb2plY3RJZD17cHJvamVjdElkfSBkZWZpbml0aW9ucz17ZGF0YS5kZWZpbml0aW9uc30gb25TZWxlY3Q9e3NlbGVjdERlZmluaXRpb259IC8+IDogbnVsbH1cbiAgICAgICAgICAgIHt0YWIgPT09IFwicnVuc1wiID8gPEF1dG9tYXRpb25SdW5zIHJ1bnM9e2RhdGEucnVuc30gLz4gOiBudWxsfVxuICAgICAgICAgICAge3RhYiA9PT0gXCJzY2hlZHVsZVwiID8gPEF1dG9tYXRpb25TY2hlZHVsZSBwcm9qZWN0SWQ9e3Byb2plY3RJZH0gZGVmaW5pdGlvbnM9e2RhdGEuZGVmaW5pdGlvbnN9IC8+IDogbnVsbH1cbiAgICAgICAgICAgIHt0YWIgPT09IFwiY2FuZGlkYXRlc1wiID8gPEF1dG9tYXRpb25DYW5kaWRhdGVzIHByb2plY3RJZD17cHJvamVjdElkfSBjYW5kaWRhdGVzPXtkYXRhLmNhbmRpZGF0ZXN9IC8+IDogbnVsbH1cbiAgICAgICAgICAgIHt0YWIgPT09IFwicmVjZWlwdHNcIiA/IDxBdXRvbWF0aW9uUmVjZWlwdHMgcmVjZWlwdHM9e2RhdGEucmVjZWlwdHN9IC8+IDogbnVsbH1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gU3RhdGVDYXJkKHsgdGl0bGUsIGJvZHksIHRvbmUgPSBcImRlZmF1bHRcIiB9OiB7IHRpdGxlOiBzdHJpbmc7IGJvZHk6IHN0cmluZzsgdG9uZT86IFwiZGVmYXVsdFwiIHwgXCJlcnJvclwiIH0pIHtcbiAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LTEgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWFwcCBwLTZcIj5cbiAgICA8Q2FyZCBjbGFzc05hbWU9e2BtYXgtdy1sZyBwLTYgdGV4dC1jZW50ZXIgJHt0b25lID09PSBcImVycm9yXCIgPyBcImJvcmRlci1yZWQtNTAwLzMwXCIgOiBcIlwifWB9PlxuICAgICAgPFJlZnJlc2hDdyBjbGFzc05hbWU9XCJteC1hdXRvIGgtNSB3LTUgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgLz5cbiAgICAgIDxoMSBjbGFzc05hbWU9XCJtdC0zIHRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWZvcmVncm91bmRcIj57dGl0bGV9PC9oMT5cbiAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57Ym9keX08L3A+XG4gICAgPC9DYXJkPlxuICA8L2Rpdj47XG59XG5cbmZ1bmN0aW9uIERldGFpbCh7IGxhYmVsLCB2YWx1ZSB9OiB7IGxhYmVsOiBzdHJpbmc7IHZhbHVlOiBzdHJpbmcgfSkge1xuICByZXR1cm4gPGRpdj48ZHQgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57bGFiZWx9PC9kdD48ZGQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWZvcmVncm91bmRcIj57dmFsdWV9PC9kZD48L2Rpdj47XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9hdXRvbWF0aW9ucy9BdXRvbWF0aW9uc1ZpZXcudHN4In0=