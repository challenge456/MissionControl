import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/StandupModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription
} from "/src/components/ui/dialog.tsx";
import { ScrollArea } from "/src/components/ui/scroll-area.tsx";
import { RiskBadge } from "/src/components/factory/badges.tsx";
import {
  Users,
  CheckSquare,
  Bell,
  DollarSign,
  Clock
} from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { cn } from "/src/lib/utils.ts";
const TASK_STATUS_CONFIG = [
  { key: "inbox", label: "Inbox", colorClass: "text-ink-secondary" },
  { key: "assigned", label: "Assigned", colorClass: "text-ink-secondary" },
  { key: "inProgress", label: "In Progress", colorClass: "text-info-accent" },
  { key: "review", label: "Review", colorClass: "text-info-accent" },
  { key: "needsApproval", label: "Needs Approval", colorClass: "text-warn" },
  { key: "blocked", label: "Blocked", colorClass: "text-warn" },
  { key: "done", label: "Done", colorClass: "text-ok" }
];
export function StandupModal({
  projectId,
  onClose
}) {
  _s();
  const report = useQuery(api.standup.generate, projectId ? { projectId } : {});
  return /* @__PURE__ */ jsxDEV(Dialog, { open: true, onOpenChange: (open) => {
    if (!open) onClose();
  }, children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "sm:max-w-[580px] max-h-[88vh] flex flex-col gap-0 p-0 overflow-hidden", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { className: "px-6 pt-6 pb-4 border-b border-line shrink-0", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV(Users, { className: "h-5 w-5 text-ink-secondary", strokeWidth: 1.75 }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
        lineNumber: 77,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV(DialogTitle, { className: "text-base font-semibold", children: "Daily Standup" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
          lineNumber: 79,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(DialogDescription, { className: "text-xs mt-0.5", children: "Live snapshot of agent activity and task pipeline" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
          lineNumber: 80,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
        lineNumber: 78,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
      lineNumber: 76,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
      lineNumber: 75,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(ScrollArea, { className: "flex-1 min-h-0", children: report === void 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center py-16 text-sm text-ink-muted", children: "Generating report…" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
      lineNumber: 89,
      columnNumber: 11
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-5 space-y-6", children: [
      /* @__PURE__ */ jsxDEV(Section, { icon: /* @__PURE__ */ jsxDEV(Users, { className: "h-4 w-4" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
        lineNumber: 95,
        columnNumber: 30
      }, this), title: "Agents", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-3 mb-3", children: [
          /* @__PURE__ */ jsxDEV(StatCard, { label: "Total", value: report.agents.total }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
            lineNumber: 97,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(StatCard, { label: "Active", value: report.agents.active, accent: "primary" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
            lineNumber: 98,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(StatCard, { label: "Paused", value: report.agents.paused, accent: "amber" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
            lineNumber: 99,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
          lineNumber: 96,
          columnNumber: 17
        }, this),
        report.agents.list?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1.5", children: report.agents.list.map(
          (a) => /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "flex items-center gap-1.5 rounded-md border border-line bg-surface-2 px-2.5 py-1 text-xs",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: cn(
                  "h-1.5 w-1.5 rounded-full",
                  a.status === "ACTIVE" ? "bg-ok" : "bg-warn"
                ) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
                  lineNumber: 108,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-ink", children: a.name }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
                  lineNumber: 112,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-ink-muted", children: a.role }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
                  lineNumber: 113,
                  columnNumber: 25
                }, this)
              ]
            },
            a.name,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
              lineNumber: 104,
              columnNumber: 17
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
          lineNumber: 102,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
        lineNumber: 95,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(Section, { icon: /* @__PURE__ */ jsxDEV(CheckSquare, { className: "h-4 w-4" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
        lineNumber: 121,
        columnNumber: 30
      }, this), title: "Task Pipeline", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 gap-2", children: [
        TASK_STATUS_CONFIG.map(({ key, label, colorClass }) => {
          const val = report.tasks[key] ?? 0;
          return /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-line bg-surface-2 p-3 text-center", children: [
            /* @__PURE__ */ jsxDEV("div", { className: cn("text-lg font-semibold tabular-nums", colorClass), children: val }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
              lineNumber: 127,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-ink-muted mt-0.5", children: label }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
              lineNumber: 128,
              columnNumber: 25
            }, this)
          ] }, key, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
            lineNumber: 126,
            columnNumber: 21
          }, this);
        }),
        /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-line bg-surface-2 p-3 text-center col-span-4 sm:col-span-1", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-semibold tabular-nums text-ink", children: report.tasks.total }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
            lineNumber: 133,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-ink-muted mt-0.5", children: "Total" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
            lineNumber: 134,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
          lineNumber: 132,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
        lineNumber: 122,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
        lineNumber: 121,
        columnNumber: 15
      }, this),
      (report.approvals.pending > 0 || report.approvals.items?.length > 0) && /* @__PURE__ */ jsxDEV(Section, { icon: /* @__PURE__ */ jsxDEV(Bell, { className: "h-4 w-4" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
        lineNumber: 141,
        columnNumber: 28
      }, this), title: "Pending Approvals", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-semibold tabular-nums text-warn", children: report.approvals.pending }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
            lineNumber: 143,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-ink-muted", children: "awaiting review" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
            lineNumber: 144,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
          lineNumber: 142,
          columnNumber: 19
        }, this),
        report.approvals.items?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          report.approvals.items.slice(0, 5).map(
            (a, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-2 rounded-md border border-line bg-surface-2 px-3 py-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-ink truncate", children: a.actionSummary }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
                lineNumber: 150,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV(RiskBadge, { level: a.riskLevel ?? "GREEN", className: "shrink-0" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
                lineNumber: 151,
                columnNumber: 27
              }, this)
            ] }, i, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
              lineNumber: 149,
              columnNumber: 17
            }, this)
          ),
          report.approvals.items.length > 5 && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted px-1", children: [
            "+",
            report.approvals.items.length - 5,
            " more"
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
            lineNumber: 155,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
          lineNumber: 147,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
        lineNumber: 141,
        columnNumber: 13
      }, this),
      report.burnRate && /* @__PURE__ */ jsxDEV(Section, { icon: /* @__PURE__ */ jsxDEV(DollarSign, { className: "h-4 w-4" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
        lineNumber: 166,
        columnNumber: 28
      }, this), title: "Burn Rate", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-baseline gap-1", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-3xl font-semibold tabular-nums text-ink", children: [
          "$",
          report.burnRate.today.toFixed(2)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
          lineNumber: 168,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-ink-muted", children: "today" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
          lineNumber: 171,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
        lineNumber: 167,
        columnNumber: 19
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
        lineNumber: 166,
        columnNumber: 13
      }, this),
      report.generatedAt && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 text-xs text-ink-muted border-t border-line pt-4", children: [
        /* @__PURE__ */ jsxDEV(Clock, { className: "h-3 w-3" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
          lineNumber: 179,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          "Generated ",
          new Date(report.generatedAt).toLocaleString()
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
          lineNumber: 180,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
        lineNumber: 178,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
      lineNumber: 93,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
      lineNumber: 87,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
    lineNumber: 73,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
    lineNumber: 72,
    columnNumber: 5
  }, this);
}
_s(StandupModal, "xni6kW72S3wIyPQ20T/MXuP/7/A=", false, function() {
  return [useQuery];
});
_c = StandupModal;
function Section({
  icon,
  title,
  children
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-ink-muted", children: icon }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
        lineNumber: 203,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { className: "text-xs font-semibold uppercase tracking-wider text-ink-muted", children: title }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
        lineNumber: 204,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
      lineNumber: 202,
      columnNumber: 7
    }, this),
    children
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
    lineNumber: 201,
    columnNumber: 5
  }, this);
}
_c2 = Section;
function StatCard({
  label,
  value,
  accent
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-line bg-surface-2 p-3 text-center", children: [
    /* @__PURE__ */ jsxDEV("div", { className: cn(
      "text-2xl font-semibold tabular-nums",
      accent === "primary" ? "text-ok" : accent === "amber" ? "text-warn" : "text-ink"
    ), children: value }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
      lineNumber: 222,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-ink-muted mt-0.5", children: label }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
      lineNumber: 230,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx",
    lineNumber: 221,
    columnNumber: 5
  }, this);
}
_c3 = StatCard;
var _c, _c2, _c3;
$RefreshReg$(_c, "StandupModal");
$RefreshReg$(_c2, "Section");
$RefreshReg$(_c3, "StatCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/StandupModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeURZOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpEWixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsV0FBVztBQUVwQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsaUJBQWlDO0FBQzFDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLFVBQVU7QUFhbkIsTUFBTUMscUJBQTJFO0FBQUEsRUFDL0UsRUFBRUMsS0FBSyxTQUFTQyxPQUFPLFNBQVNDLFlBQVkscUJBQXFCO0FBQUEsRUFDakUsRUFBRUYsS0FBSyxZQUFZQyxPQUFPLFlBQVlDLFlBQVkscUJBQXFCO0FBQUEsRUFDdkUsRUFBRUYsS0FBSyxjQUFjQyxPQUFPLGVBQWVDLFlBQVksbUJBQW1CO0FBQUEsRUFDMUUsRUFBRUYsS0FBSyxVQUFVQyxPQUFPLFVBQVVDLFlBQVksbUJBQW1CO0FBQUEsRUFDakUsRUFBRUYsS0FBSyxpQkFBaUJDLE9BQU8sa0JBQWtCQyxZQUFZLFlBQVk7QUFBQSxFQUN6RSxFQUFFRixLQUFLLFdBQVdDLE9BQU8sV0FBV0MsWUFBWSxZQUFZO0FBQUEsRUFDNUQsRUFBRUYsS0FBSyxRQUFRQyxPQUFPLFFBQVFDLFlBQVksVUFBVTtBQUFDO0FBR2hELGdCQUFTQyxhQUFhO0FBQUEsRUFDM0JDO0FBQUFBLEVBQ0FDO0FBSUYsR0FBRztBQUFBQyxLQUFBO0FBQ0QsUUFBTUMsU0FBU3ZCLFNBQVNDLElBQUl1QixRQUFRQyxVQUFVTCxZQUFZLEVBQUVBLFVBQVUsSUFBSSxDQUFDLENBQUM7QUFFNUUsU0FDRSx1QkFBQyxVQUFPLE1BQUksTUFBQyxjQUFjLENBQUNNLFNBQVM7QUFBRSxRQUFJLENBQUNBLEtBQU1MLFNBQVE7QUFBQSxFQUFHLEdBQzNELGlDQUFDLGlCQUFjLFdBQVUseUVBRXZCO0FBQUEsMkJBQUMsZ0JBQWEsV0FBVSxnREFDdEIsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsNkJBQUMsU0FBTSxXQUFVLDhCQUE2QixhQUFhLFFBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0U7QUFBQSxNQUNoRSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsZUFBWSxXQUFVLDJCQUEwQiw2QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RDtBQUFBLFFBQzlELHVCQUFDLHFCQUFrQixXQUFVLGtCQUFnQixpRUFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBRUEsdUJBQUMsY0FBVyxXQUFVLGtCQUNuQkUscUJBQVdJLFNBQ1YsdUJBQUMsU0FBSSxXQUFVLGlFQUErRCxrQ0FBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHVCQUViO0FBQUEsNkJBQUMsV0FBUSxNQUFNLHVCQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBCLEdBQUssT0FBTSxVQUNsRDtBQUFBLCtCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFlBQVMsT0FBTSxTQUFRLE9BQU9KLE9BQU9LLE9BQU9DLFNBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsVUFDbkQsdUJBQUMsWUFBUyxPQUFNLFVBQVMsT0FBT04sT0FBT0ssT0FBT0UsUUFBUSxRQUFPLGFBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNFO0FBQUEsVUFDdEUsdUJBQUMsWUFBUyxPQUFNLFVBQVMsT0FBT1AsT0FBT0ssT0FBT0csUUFBUSxRQUFPLFdBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FO0FBQUEsYUFIdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFDQ1IsT0FBT0ssT0FBT0ksTUFBTUMsU0FBUyxLQUM1Qix1QkFBQyxTQUFJLFdBQVUsMEJBQ1pWLGlCQUFPSyxPQUFPSSxLQUFLRTtBQUFBQSxVQUFJLENBQUNDLE1BQ3ZCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFVBQUssV0FBV3JCO0FBQUFBLGtCQUNmO0FBQUEsa0JBQ0FxQixFQUFFQyxXQUFXLFdBQVcsVUFBVTtBQUFBLGdCQUNwQyxLQUhBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0U7QUFBQSxnQkFDRix1QkFBQyxVQUFLLFdBQVUsd0JBQXdCRCxZQUFFRSxRQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErQztBQUFBLGdCQUMvQyx1QkFBQyxVQUFLLFdBQVUsa0JBQWtCRixZQUFFRyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5QztBQUFBO0FBQUE7QUFBQSxZQVJwQ0gsRUFBRUU7QUFBQUEsWUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxRQUNELEtBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsV0FyQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVCQTtBQUFBLE1BR0EsdUJBQUMsV0FBUSxNQUFNLHVCQUFDLGVBQVksV0FBVSxhQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdDLEdBQUssT0FBTSxpQkFDeEQsaUNBQUMsU0FBSSxXQUFVLDBCQUNadEI7QUFBQUEsMkJBQW1CbUIsSUFBSSxDQUFDLEVBQUVsQixLQUFLQyxPQUFPQyxXQUFXLE1BQU07QUFDdEQsZ0JBQU1xQixNQUFPaEIsT0FBT2lCLE1BQWlDeEIsR0FBRyxLQUFLO0FBQzdELGlCQUNFLHVCQUFDLFNBQWMsV0FBVSw4REFDdkI7QUFBQSxtQ0FBQyxTQUFJLFdBQVdGLEdBQUcsc0NBQXNDSSxVQUFVLEdBQUlxQixpQkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkU7QUFBQSxZQUMzRSx1QkFBQyxTQUFJLFdBQVUscUNBQXFDdEIsbUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsZUFGbERELEtBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFFBRUosQ0FBQztBQUFBLFFBQ0QsdUJBQUMsU0FBSSxXQUFVLHVGQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLCtDQUErQ08saUJBQU9pQixNQUFNWCxTQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRjtBQUFBLFVBQ2pGLHVCQUFDLFNBQUksV0FBVSxxQ0FBb0MscUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdEO0FBQUEsYUFGMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0EsS0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsT0FHRU4sT0FBT2tCLFVBQVVDLFVBQVUsS0FBS25CLE9BQU9rQixVQUFVRSxPQUFPVixTQUFTLE1BQ2pFLHVCQUFDLFdBQVEsTUFBTSx1QkFBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QixHQUFLLE9BQU0scUJBQ2pEO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGlEQUFpRFYsaUJBQU9rQixVQUFVQyxXQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRjtBQUFBLFVBQzFGLHVCQUFDLFVBQUssV0FBVSwwQkFBeUIsK0JBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdEO0FBQUEsYUFGMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQ25CLE9BQU9rQixVQUFVRSxPQUFPVixTQUFTLEtBQ2hDLHVCQUFDLFNBQUksV0FBVSxlQUNaVjtBQUFBQSxpQkFBT2tCLFVBQVVFLE1BQU1DLE1BQU0sR0FBRyxDQUFDLEVBQUVWO0FBQUFBLFlBQUksQ0FBQ0MsR0FBaUJVLE1BQ3hELHVCQUFDLFNBQVksV0FBVSxnR0FDckI7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsNkJBQTZCVixZQUFFVyxpQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkQ7QUFBQSxjQUM3RCx1QkFBQyxhQUFVLE9BQVFYLEVBQUVZLGFBQTJCLFNBQVMsV0FBVSxjQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RTtBQUFBLGlCQUZyRUYsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsVUFDRDtBQUFBLFVBQ0F0QixPQUFPa0IsVUFBVUUsTUFBTVYsU0FBUyxLQUMvQix1QkFBQyxTQUFJLFdBQVUsK0JBQTZCO0FBQUE7QUFBQSxZQUN4Q1YsT0FBT2tCLFVBQVVFLE1BQU1WLFNBQVM7QUFBQSxZQUFFO0FBQUEsZUFEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsV0FsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9CQTtBQUFBLE1BSURWLE9BQU95QixZQUNOLHVCQUFDLFdBQVEsTUFBTSx1QkFBQyxjQUFXLFdBQVUsYUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQixHQUFLLE9BQU0sYUFDdkQsaUNBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsK0JBQUMsVUFBSyxXQUFVLGdEQUE4QztBQUFBO0FBQUEsVUFDMUR6QixPQUFPeUIsU0FBU0MsTUFBTUMsUUFBUSxDQUFDO0FBQUEsYUFEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFLLFdBQVUsMEJBQXlCLHFCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsV0FKaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFJRDNCLE9BQU80QixlQUNOLHVCQUFDLFNBQUksV0FBVSw4RUFDYjtBQUFBLCtCQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBCO0FBQUEsUUFDMUIsdUJBQUMsVUFBSztBQUFBO0FBQUEsVUFBVyxJQUFJQyxLQUFLN0IsT0FBTzRCLFdBQVcsRUFBRUUsZUFBZTtBQUFBLGFBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0Q7QUFBQSxXQUZqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQXhGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEZBLEtBaEdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrR0E7QUFBQSxPQWhIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUhBLEtBbEhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtSEE7QUFFSjtBQUFDL0IsR0EvSGVILGNBQVk7QUFBQSxVQU9YbkIsUUFBUTtBQUFBO0FBQUEsS0FQVG1CO0FBaUloQixTQUFTbUMsUUFBUTtBQUFBLEVBQ2ZDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBS0YsR0FBRztBQUNELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSw2QkFBQyxVQUFLLFdBQVUsa0JBQWtCRixrQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QztBQUFBLE1BQ3ZDLHVCQUFDLFFBQUcsV0FBVSxpRUFBaUVDLG1CQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFGO0FBQUEsU0FGdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQ0M7QUFBQUEsT0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBTUE7QUFFSjtBQUFDQyxNQWxCUUo7QUFvQlQsU0FBU0ssU0FBUztBQUFBLEVBQ2hCMUM7QUFBQUEsRUFDQTJDO0FBQUFBLEVBQ0FDO0FBS0YsR0FBRztBQUNELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDhEQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFXL0M7QUFBQUEsTUFDZDtBQUFBLE1BQ0ErQyxXQUFXLFlBQVksWUFDdkJBLFdBQVcsVUFBVSxjQUNyQjtBQUFBLElBQ0YsR0FDR0QsbUJBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQXFDM0MsbUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEQ7QUFBQSxPQVQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUE7QUFFSjtBQUFDNkMsTUF0QlFIO0FBQVEsSUFBQUksSUFBQUwsS0FBQUk7QUFBQSxhQUFBQyxJQUFBO0FBQUEsYUFBQUwsS0FBQTtBQUFBLGFBQUFJLEtBQUEiLCJuYW1lcyI6WyJ1c2VRdWVyeSIsImFwaSIsIkRpYWxvZyIsIkRpYWxvZ0NvbnRlbnQiLCJEaWFsb2dIZWFkZXIiLCJEaWFsb2dUaXRsZSIsIkRpYWxvZ0Rlc2NyaXB0aW9uIiwiU2Nyb2xsQXJlYSIsIlJpc2tCYWRnZSIsIlVzZXJzIiwiQ2hlY2tTcXVhcmUiLCJCZWxsIiwiRG9sbGFyU2lnbiIsIkNsb2NrIiwiY24iLCJUQVNLX1NUQVRVU19DT05GSUciLCJrZXkiLCJsYWJlbCIsImNvbG9yQ2xhc3MiLCJTdGFuZHVwTW9kYWwiLCJwcm9qZWN0SWQiLCJvbkNsb3NlIiwiX3MiLCJyZXBvcnQiLCJzdGFuZHVwIiwiZ2VuZXJhdGUiLCJvcGVuIiwidW5kZWZpbmVkIiwiYWdlbnRzIiwidG90YWwiLCJhY3RpdmUiLCJwYXVzZWQiLCJsaXN0IiwibGVuZ3RoIiwibWFwIiwiYSIsInN0YXR1cyIsIm5hbWUiLCJyb2xlIiwidmFsIiwidGFza3MiLCJhcHByb3ZhbHMiLCJwZW5kaW5nIiwiaXRlbXMiLCJzbGljZSIsImkiLCJhY3Rpb25TdW1tYXJ5Iiwicmlza0xldmVsIiwiYnVyblJhdGUiLCJ0b2RheSIsInRvRml4ZWQiLCJnZW5lcmF0ZWRBdCIsIkRhdGUiLCJ0b0xvY2FsZVN0cmluZyIsIlNlY3Rpb24iLCJpY29uIiwidGl0bGUiLCJjaGlsZHJlbiIsIl9jMiIsIlN0YXRDYXJkIiwidmFsdWUiLCJhY2NlbnQiLCJfYzMiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTdGFuZHVwTW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVF1ZXJ5IH0gZnJvbSBcImNvbnZleC9yZWFjdFwiO1xuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2FwaVwiO1xuaW1wb3J0IHR5cGUgeyBJZCB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9kYXRhTW9kZWxcIjtcbmltcG9ydCB7XG4gIERpYWxvZyxcbiAgRGlhbG9nQ29udGVudCxcbiAgRGlhbG9nSGVhZGVyLFxuICBEaWFsb2dUaXRsZSxcbiAgRGlhbG9nRGVzY3JpcHRpb24sXG59IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvZGlhbG9nXCI7XG5pbXBvcnQgeyBTY3JvbGxBcmVhIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9zY3JvbGwtYXJlYVwiO1xuaW1wb3J0IHsgUmlza0JhZGdlLCB0eXBlIFJpc2tMZXZlbCB9IGZyb20gXCJAL2NvbXBvbmVudHMvZmFjdG9yeS9iYWRnZXNcIjtcbmltcG9ydCB7XG4gIFVzZXJzLFxuICBDaGVja1NxdWFyZSxcbiAgQmVsbCxcbiAgRG9sbGFyU2lnbixcbiAgQ2xvY2ssXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5cbmludGVyZmFjZSBBZ2VudEl0ZW0ge1xuICBuYW1lOiBzdHJpbmc7XG4gIHJvbGU6IHN0cmluZztcbiAgc3RhdHVzOiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBBcHByb3ZhbEl0ZW0ge1xuICBhY3Rpb25TdW1tYXJ5OiBzdHJpbmc7XG4gIHJpc2tMZXZlbDogc3RyaW5nO1xufVxuXG5jb25zdCBUQVNLX1NUQVRVU19DT05GSUc6IHsga2V5OiBzdHJpbmc7IGxhYmVsOiBzdHJpbmc7IGNvbG9yQ2xhc3M6IHN0cmluZyB9W10gPSBbXG4gIHsga2V5OiBcImluYm94XCIsIGxhYmVsOiBcIkluYm94XCIsIGNvbG9yQ2xhc3M6IFwidGV4dC1pbmstc2Vjb25kYXJ5XCIgfSxcbiAgeyBrZXk6IFwiYXNzaWduZWRcIiwgbGFiZWw6IFwiQXNzaWduZWRcIiwgY29sb3JDbGFzczogXCJ0ZXh0LWluay1zZWNvbmRhcnlcIiB9LFxuICB7IGtleTogXCJpblByb2dyZXNzXCIsIGxhYmVsOiBcIkluIFByb2dyZXNzXCIsIGNvbG9yQ2xhc3M6IFwidGV4dC1pbmZvLWFjY2VudFwiIH0sXG4gIHsga2V5OiBcInJldmlld1wiLCBsYWJlbDogXCJSZXZpZXdcIiwgY29sb3JDbGFzczogXCJ0ZXh0LWluZm8tYWNjZW50XCIgfSxcbiAgeyBrZXk6IFwibmVlZHNBcHByb3ZhbFwiLCBsYWJlbDogXCJOZWVkcyBBcHByb3ZhbFwiLCBjb2xvckNsYXNzOiBcInRleHQtd2FyblwiIH0sXG4gIHsga2V5OiBcImJsb2NrZWRcIiwgbGFiZWw6IFwiQmxvY2tlZFwiLCBjb2xvckNsYXNzOiBcInRleHQtd2FyblwiIH0sXG4gIHsga2V5OiBcImRvbmVcIiwgbGFiZWw6IFwiRG9uZVwiLCBjb2xvckNsYXNzOiBcInRleHQtb2tcIiB9LFxuXTtcblxuZXhwb3J0IGZ1bmN0aW9uIFN0YW5kdXBNb2RhbCh7XG4gIHByb2plY3RJZCxcbiAgb25DbG9zZSxcbn06IHtcbiAgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+IHwgbnVsbDtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgcmVwb3J0ID0gdXNlUXVlcnkoYXBpLnN0YW5kdXAuZ2VuZXJhdGUsIHByb2plY3RJZCA/IHsgcHJvamVjdElkIH0gOiB7fSk7XG5cbiAgcmV0dXJuIChcbiAgICA8RGlhbG9nIG9wZW4gb25PcGVuQ2hhbmdlPXsob3BlbikgPT4geyBpZiAoIW9wZW4pIG9uQ2xvc2UoKTsgfX0+XG4gICAgICA8RGlhbG9nQ29udGVudCBjbGFzc05hbWU9XCJzbTptYXgtdy1bNTgwcHhdIG1heC1oLVs4OHZoXSBmbGV4IGZsZXgtY29sIGdhcC0wIHAtMCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgPERpYWxvZ0hlYWRlciBjbGFzc05hbWU9XCJweC02IHB0LTYgcGItNCBib3JkZXItYiBib3JkZXItbGluZSBzaHJpbmstMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxVc2VycyBjbGFzc05hbWU9XCJoLTUgdy01IHRleHQtaW5rLXNlY29uZGFyeVwiIHN0cm9rZVdpZHRoPXsxLjc1fSAvPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPERpYWxvZ1RpdGxlIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkXCI+RGFpbHkgU3RhbmR1cDwvRGlhbG9nVGl0bGU+XG4gICAgICAgICAgICAgIDxEaWFsb2dEZXNjcmlwdGlvbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgIExpdmUgc25hcHNob3Qgb2YgYWdlbnQgYWN0aXZpdHkgYW5kIHRhc2sgcGlwZWxpbmVcbiAgICAgICAgICAgICAgPC9EaWFsb2dEZXNjcmlwdGlvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L0RpYWxvZ0hlYWRlcj5cblxuICAgICAgICA8U2Nyb2xsQXJlYSBjbGFzc05hbWU9XCJmbGV4LTEgbWluLWgtMFwiPlxuICAgICAgICAgIHtyZXBvcnQgPT09IHVuZGVmaW5lZCA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktMTYgdGV4dC1zbSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICBHZW5lcmF0aW5nIHJlcG9ydOKAplxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS01IHNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICB7LyogQWdlbnRzICovfVxuICAgICAgICAgICAgICA8U2VjdGlvbiBpY29uPXs8VXNlcnMgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+fSB0aXRsZT1cIkFnZW50c1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtMyBtYi0zXCI+XG4gICAgICAgICAgICAgICAgICA8U3RhdENhcmQgbGFiZWw9XCJUb3RhbFwiIHZhbHVlPXtyZXBvcnQuYWdlbnRzLnRvdGFsfSAvPlxuICAgICAgICAgICAgICAgICAgPFN0YXRDYXJkIGxhYmVsPVwiQWN0aXZlXCIgdmFsdWU9e3JlcG9ydC5hZ2VudHMuYWN0aXZlfSBhY2NlbnQ9XCJwcmltYXJ5XCIgLz5cbiAgICAgICAgICAgICAgICAgIDxTdGF0Q2FyZCBsYWJlbD1cIlBhdXNlZFwiIHZhbHVlPXtyZXBvcnQuYWdlbnRzLnBhdXNlZH0gYWNjZW50PVwiYW1iZXJcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIHtyZXBvcnQuYWdlbnRzLmxpc3Q/Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIHtyZXBvcnQuYWdlbnRzLmxpc3QubWFwKChhOiBBZ2VudEl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2EubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yIHB4LTIuNSBweS0xIHRleHQteHNcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiaC0xLjUgdy0xLjUgcm91bmRlZC1mdWxsXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGEuc3RhdHVzID09PSBcIkFDVElWRVwiID8gXCJiZy1va1wiIDogXCJiZy13YXJuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWlua1wiPnthLm5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1pbmstbXV0ZWRcIj57YS5yb2xlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L1NlY3Rpb24+XG5cbiAgICAgICAgICAgICAgey8qIFRhc2tzICovfVxuICAgICAgICAgICAgICA8U2VjdGlvbiBpY29uPXs8Q2hlY2tTcXVhcmUgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+fSB0aXRsZT1cIlRhc2sgUGlwZWxpbmVcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIHtUQVNLX1NUQVRVU19DT05GSUcubWFwKCh7IGtleSwgbGFiZWwsIGNvbG9yQ2xhc3MgfSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSAocmVwb3J0LnRhc2tzIGFzIFJlY29yZDxzdHJpbmcsIG51bWJlcj4pW2tleV0gPz8gMDtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17a2V5fSBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTIgcC0zIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17Y24oXCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGFidWxhci1udW1zXCIsIGNvbG9yQ2xhc3MpfT57dmFsfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWluay1tdXRlZCBtdC0wLjVcIj57bGFiZWx9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yIHAtMyB0ZXh0LWNlbnRlciBjb2wtc3Bhbi00IHNtOmNvbC1zcGFuLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGFidWxhci1udW1zIHRleHQtaW5rXCI+e3JlcG9ydC50YXNrcy50b3RhbH08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWluay1tdXRlZCBtdC0wLjVcIj5Ub3RhbDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvU2VjdGlvbj5cblxuICAgICAgICAgICAgICB7LyogQXBwcm92YWxzICovfVxuICAgICAgICAgICAgICB7KHJlcG9ydC5hcHByb3ZhbHMucGVuZGluZyA+IDAgfHwgcmVwb3J0LmFwcHJvdmFscy5pdGVtcz8ubGVuZ3RoID4gMCkgJiYgKFxuICAgICAgICAgICAgICAgIDxTZWN0aW9uIGljb249ezxCZWxsIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPn0gdGl0bGU9XCJQZW5kaW5nIEFwcHJvdmFsc1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgdGFidWxhci1udW1zIHRleHQtd2FyblwiPntyZXBvcnQuYXBwcm92YWxzLnBlbmRpbmd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtaW5rLW11dGVkXCI+YXdhaXRpbmcgcmV2aWV3PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICB7cmVwb3J0LmFwcHJvdmFscy5pdGVtcz8ubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7cmVwb3J0LmFwcHJvdmFscy5pdGVtcy5zbGljZSgwLCA1KS5tYXAoKGE6IEFwcHJvdmFsSXRlbSwgaTogbnVtYmVyKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMiBweC0zIHB5LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWluayB0cnVuY2F0ZVwiPnthLmFjdGlvblN1bW1hcnl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Umlza0JhZGdlIGxldmVsPXsoYS5yaXNrTGV2ZWwgYXMgUmlza0xldmVsKSA/PyBcIkdSRUVOXCJ9IGNsYXNzTmFtZT1cInNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgIHtyZXBvcnQuYXBwcm92YWxzLml0ZW1zLmxlbmd0aCA+IDUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtaW5rLW11dGVkIHB4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgK3tyZXBvcnQuYXBwcm92YWxzLml0ZW1zLmxlbmd0aCAtIDV9IG1vcmVcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L1NlY3Rpb24+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIEJ1cm4gcmF0ZSAqL31cbiAgICAgICAgICAgICAge3JlcG9ydC5idXJuUmF0ZSAmJiAoXG4gICAgICAgICAgICAgICAgPFNlY3Rpb24gaWNvbj17PERvbGxhclNpZ24gY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+fSB0aXRsZT1cIkJ1cm4gUmF0ZVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWJhc2VsaW5lIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtc2VtaWJvbGQgdGFidWxhci1udW1zIHRleHQtaW5rXCI+XG4gICAgICAgICAgICAgICAgICAgICAgJHtyZXBvcnQuYnVyblJhdGUudG9kYXkudG9GaXhlZCgyKX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtaW5rLW11dGVkXCI+dG9kYXk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L1NlY3Rpb24+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIEZvb3RlciAqL31cbiAgICAgICAgICAgICAge3JlcG9ydC5nZW5lcmF0ZWRBdCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgdGV4dC1pbmstbXV0ZWQgYm9yZGVyLXQgYm9yZGVyLWxpbmUgcHQtNFwiPlxuICAgICAgICAgICAgICAgICAgPENsb2NrIGNsYXNzTmFtZT1cImgtMyB3LTNcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+R2VuZXJhdGVkIHtuZXcgRGF0ZShyZXBvcnQuZ2VuZXJhdGVkQXQpLnRvTG9jYWxlU3RyaW5nKCl9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9TY3JvbGxBcmVhPlxuICAgICAgPC9EaWFsb2dDb250ZW50PlxuICAgIDwvRGlhbG9nPlxuICApO1xufVxuXG5mdW5jdGlvbiBTZWN0aW9uKHtcbiAgaWNvbixcbiAgdGl0bGUsXG4gIGNoaWxkcmVuLFxufToge1xuICBpY29uOiBSZWFjdC5SZWFjdE5vZGU7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG59KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1pbmstbXV0ZWRcIj57aWNvbn08L3NwYW4+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtaW5rLW11dGVkXCI+e3RpdGxlfTwvaDM+XG4gICAgICA8L2Rpdj5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gU3RhdENhcmQoe1xuICBsYWJlbCxcbiAgdmFsdWUsXG4gIGFjY2VudCxcbn06IHtcbiAgbGFiZWw6IHN0cmluZztcbiAgdmFsdWU6IG51bWJlcjtcbiAgYWNjZW50PzogXCJwcmltYXJ5XCIgfCBcImFtYmVyXCI7XG59KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTIgcC0zIHRleHQtY2VudGVyXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCB0YWJ1bGFyLW51bXNcIixcbiAgICAgICAgYWNjZW50ID09PSBcInByaW1hcnlcIiA/IFwidGV4dC1va1wiIDpcbiAgICAgICAgYWNjZW50ID09PSBcImFtYmVyXCIgPyBcInRleHQtd2FyblwiIDpcbiAgICAgICAgXCJ0ZXh0LWlua1wiXG4gICAgICApfT5cbiAgICAgICAge3ZhbHVlfVxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtaW5rLW11dGVkIG10LTAuNVwiPntsYWJlbH08L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL1N0YW5kdXBNb2RhbC50c3gifQ==