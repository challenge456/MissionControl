import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shellV2/ChatDock.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { ChevronRight, Factory, MessageSquare, Mic, Send, User } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { useMutation, useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { cn } from "/src/lib/utils.ts";
import { ChatSessionBar } from "/src/components/operator/ChatSessionBar.tsx";
import { ChatBubble } from "/src/components/operator/ChatBubble.tsx";
import { TurnCard } from "/src/components/operator/TurnCard.tsx";
import { StreamingTurnCard } from "/src/components/operator/StreamingTurnCard.tsx";
const FACTORY_PROMPTS = [
  { label: "Set up code review", view: "harness-code-review-wizard" },
  { label: "Sync PR checks", view: "harness-change-review" },
  { label: "Open meta loop", view: "harness-meta-loop" },
  { label: "Evaluate GitHub skills", view: "skills" },
  { label: "Factory health", view: "harness-health" }
];
export function ChatDock({
  width,
  onClose,
  projectId,
  archStatus,
  onNavigate
}) {
  _s();
  const [mode, setMode] = useState("operator");
  const [sessionId, setSessionId] = useState("default");
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]);
  const [pending, setPending] = useState(false);
  const [selectedThreadId, setSelectedThreadId] = useState(null);
  const [submitError, setSubmitError] = useState(null);
  const logRef = useRef(null);
  const seedMetaLoop = useMutation(api.factory.metaLoop.seedDemoSuggestions);
  const submitChatRequest = useMutation(api.missionChat.submitRequest);
  const chatThreads = useQuery(
    api.missionChat.listThreads,
    projectId ? { projectId, limit: 20 } : "skip"
  );
  const chatSession = useQuery(
    api.missionChat.getSession,
    selectedThreadId ? { threadId: selectedThreadId } : "skip"
  );
  const factoryHealth = useQuery(
    api.factory.health.getFactoryHealth,
    projectId ? { projectId } : "skip"
  );
  const runs = useQuery(
    api.analytics.recentRunTurns,
    projectId ? { projectId, limit: 20 } : { limit: 20 }
  );
  const sessions = mode === "operator" ? [
    {
      id: "new",
      title: "New work request",
      channel: "operator",
      messageCount: 0
    },
    ...(chatThreads ?? []).map((thread) => ({
      id: thread._id,
      title: thread.title,
      channel: "operator",
      messageCount: thread.messageCount
    }))
  ] : [
    {
      id: "default",
      title: "Factory Agent",
      channel: "factory",
      messageCount: messages.length
    },
    ...(runs ?? []).slice(0, 5).map((r) => ({
      id: r.id,
      title: r.label,
      channel: "factory",
      messageCount: r.toolCount
    }))
  ];
  useEffect(() => {
    setSelectedThreadId(null);
    setSessionId(mode === "operator" ? "new" : "default");
    setMessages([]);
    setSubmitError(null);
  }, [mode, projectId]);
  const renderedMessages = mode === "operator" ? [
    ...(chatSession?.messages ?? []).map(
      (message) => message.senderType === "HUMAN" ? { kind: "user", text: message.content } : {
        kind: "turn",
        turn: {
          reply: message.content,
          gate: {
            decision: "allow",
            reason: "Persisted Mission Control work record"
          },
          latencyMs: 0,
          iterations: 1,
          cost: 0,
          model: "mission-control"
        }
      }
    ),
    ...messages.filter((message) => message.kind === "streaming")
  ] : messages;
  useEffect(() => {
    logRef.current?.scrollTo({ top: logRef.current.scrollHeight });
  }, [renderedMessages.length, pending]);
  const factoryReply = useCallback(
    async (text, startedAt) => {
      const lower = text.toLowerCase();
      if (lower.includes("meta loop") || lower.includes("suggestion")) {
        await seedMetaLoop({ projectId: projectId ?? void 0 });
        onNavigate?.("harness-meta-loop");
        return {
          reply: "Seeded meta loop inbox with observed failure patterns. Opening meta loop.",
          gate: { decision: "allow", reason: "factory agent — meta loop" }
        };
      }
      if (lower.includes("code review") || lower.includes("review wizard")) {
        onNavigate?.("harness-code-review-wizard");
        return {
          reply: "Opening the factory-first code review wizard. Start with verifiers, then PR lenses.",
          gate: { decision: "allow", reason: "factory agent — code review" }
        };
      }
      if (lower.includes("pr") || lower.includes("change review") || lower.includes("mutation")) {
        onNavigate?.("harness-change-review");
        return {
          reply: "Navigate to Change Review to sync PR/CI data and mutation testing reports.",
          gate: { decision: "allow", reason: "factory agent — PR checks" }
        };
      }
      if (lower.includes("analyze") || lower.includes("github") || lower.includes("skill")) {
        onNavigate?.("skills");
        return {
          reply: "Open Registry → Evaluate to analyze a public GitHub repo for SKILL.md files.",
          gate: { decision: "allow", reason: "factory agent — registry analyze" }
        };
      }
      if (lower.includes("health") || lower.includes("maturity")) {
        onNavigate?.("harness-health");
        const stage = factoryHealth?.maturityStage ?? "unknown";
        return {
          reply: `Factory maturity: ${stage}. Opening health dashboard for loop coverage and ledger signals.`,
          gate: { decision: "allow", reason: "factory agent — health" }
        };
      }
      if (lower.includes("delegate") || lower.includes("automate")) {
        onNavigate?.("harness-launch");
        return {
          reply: "Use Launch to schedule recurring outer-loop workflows once success rate is high.",
          gate: { decision: "allow", reason: "factory agent — delegation" }
        };
      }
      return {
        reply: `Factory Agent ready. Try: "sync PR checks", "set up code review", "open meta loop", or "analyze github skills". Current project: ${projectId ? "scoped" : "all projects"}.`,
        gate: { decision: "skip", reason: "factory agent — general routing" }
      };
    },
    [factoryHealth?.maturityStage, onNavigate, projectId, seedMetaLoop]
  );
  const send = useCallback(
    () => {
      const text = input.trim();
      if (!text || pending) return;
      setSubmitError(null);
      setInput("");
      if (mode === "factory") {
        setMessages((m) => [...m, { kind: "user", text }]);
      }
      setPending(true);
      const startedAt = Date.now();
      setMessages(
        (m) => [
          ...m,
          { kind: "streaming", pending: true, stream: "", startedAt }
        ]
      );
      const finish = (turn) => {
        setPending(false);
        setMessages((m) => {
          const withoutStream = m.filter((x) => x.kind !== "streaming");
          return [...withoutStream, { kind: "turn", turn }];
        });
      };
      if (mode === "factory") {
        void factoryReply(text, startedAt).then(({ reply, gate }) => {
          finish({
            reply,
            gate,
            latencyMs: Date.now() - startedAt,
            iterations: 1,
            cost: 4e-3,
            model: "factory-agent-router"
          });
        }).catch((error) => {
          setPending(false);
          setMessages((current) => current.filter((item) => item.kind !== "streaming"));
          setSubmitError(error instanceof Error ? error.message : "Factory routing failed.");
        });
        return;
      }
      if (!projectId) {
        setPending(false);
        setMessages([]);
        setSubmitError("Select a workspace before submitting work.");
        return;
      }
      void submitChatRequest({
        projectId,
        threadId: selectedThreadId ?? void 0,
        content: text,
        actorId: "operator",
        idempotencyKey: `mission-chat:${projectId}:${startedAt}`
      }).then((result) => {
        setSelectedThreadId(result.threadId);
        setSessionId(result.threadId);
        setMessages([]);
        setPending(false);
      }).catch((error) => {
        setPending(false);
        setMessages([]);
        setSubmitError(
          error instanceof Error ? error.message : "Mission Control could not create the work."
        );
      });
    },
    [
      factoryReply,
      input,
      mode,
      pending,
      projectId,
      selectedThreadId,
      submitChatRequest
    ]
  );
  const onKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  };
  return /* @__PURE__ */ jsxDEV(
    "aside",
    {
      className: "flex h-full shrink-0 flex-col border-l border-line bg-rail",
      style: { width },
      "aria-label": "Chat dock",
      children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex shrink-0 items-center gap-2 border-b border-line px-3 py-2.5", children: [
          /* @__PURE__ */ jsxDEV(MessageSquare, { size: 14, className: "text-ink-muted", "aria-hidden": true }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
            lineNumber: 308,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-semibold text-ink", children: "Chat" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
            lineNumber: 309,
            columnNumber: 9
          }, this),
          archStatus ? /* @__PURE__ */ jsxDEV("span", { className: "schematic-arch-status ml-1 truncate", children: archStatus }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
            lineNumber: 311,
            columnNumber: 9
          }, this) : null,
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: onClose,
              className: "ml-auto rounded p-1 text-ink-muted hover:text-ink",
              title: "Collapse chat",
              children: /* @__PURE__ */ jsxDEV(ChevronRight, { size: 16, "aria-hidden": true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
                lineNumber: 319,
                columnNumber: 11
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
              lineNumber: 313,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
          lineNumber: 307,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex shrink-0 gap-1 border-b border-line px-3 py-2", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setMode("operator"),
              className: cn(
                "flex flex-1 items-center justify-center gap-1 rounded-md px-2 py-1.5 text-[11px] font-medium",
                mode === "operator" ? "bg-surface-2 text-ink" : "text-ink-muted hover:text-ink"
              ),
              children: [
                /* @__PURE__ */ jsxDEV(User, { size: 12, "aria-hidden": true }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
                  lineNumber: 332,
                  columnNumber: 11
                }, this),
                "Operator"
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
              lineNumber: 324,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setMode("factory"),
              className: cn(
                "flex flex-1 items-center justify-center gap-1 rounded-md px-2 py-1.5 text-[11px] font-medium",
                mode === "factory" ? "bg-surface-2 text-registry-accent" : "text-ink-muted hover:text-ink"
              ),
              children: [
                /* @__PURE__ */ jsxDEV(Factory, { size: 12, "aria-hidden": true }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
                  lineNumber: 343,
                  columnNumber: 11
                }, this),
                "Factory Agent"
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
              lineNumber: 335,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
          lineNumber: 323,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          ChatSessionBar,
          {
            sessions,
            activeSessionId: sessionId,
            onNewChat: () => {
              setSessionId(mode === "operator" ? "new" : `session-${Date.now()}`);
              setSelectedThreadId(null);
              setMessages([]);
              setSubmitError(null);
            },
            onSelectSession: (nextSessionId) => {
              setSessionId(nextSessionId);
              if (mode === "operator") {
                const thread = (chatThreads ?? []).find((candidate) => candidate._id === nextSessionId);
                setSelectedThreadId(thread?._id ?? null);
              }
            },
            onViewAllHistory: () => {
              const first = chatThreads?.[0];
              if (mode === "operator" && first) {
                setSessionId(first._id);
                setSelectedThreadId(first._id);
              }
            },
            modelLabel: mode === "factory" ? "factory-agent" : "factory-router"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
            lineNumber: 348,
            columnNumber: 7
          },
          this
        ),
        mode === "operator" && chatSession?.task && /* @__PURE__ */ jsxDEV("div", { className: "shrink-0 border-b border-line bg-surface-1 px-3 py-2 text-[11px]", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-2", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => onNavigate?.("tasks"),
                className: "truncate font-medium text-ink hover:underline",
                children: chatSession.task.identifier ?? chatSession.task.title
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
                lineNumber: 377,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "rounded border border-line px-1.5 py-0.5 text-ink-secondary", children: chatSession.task.status.replace(/_/g, " ") }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
              lineNumber: 384,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
            lineNumber: 376,
            columnNumber: 11
          }, this),
          chatSession.workOrder && /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => onNavigate?.("control-work-orders"),
              className: "mt-1 text-ink-muted hover:text-ink hover:underline",
              children: [
                "WorkOrder · ",
                chatSession.workOrder.state.replace(/_/g, " "),
                chatSession.workflowRun ? ` · Run ${chatSession.workflowRun.status}` : ""
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
              lineNumber: 389,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
          lineNumber: 375,
          columnNumber: 7
        }, this),
        mode === "factory" ? /* @__PURE__ */ jsxDEV("div", { className: "flex shrink-0 flex-wrap gap-1.5 border-b border-line px-3 py-2", children: FACTORY_PROMPTS.map(
          (p) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => {
                onNavigate?.(p.view);
                setInput(p.label);
              },
              className: "rounded-full border border-line bg-surface-1 px-2.5 py-1 text-[10px] text-ink-secondary hover:border-registry-accent/40 hover:text-ink",
              children: p.label
            },
            p.view,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
              lineNumber: 404,
              columnNumber: 9
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
          lineNumber: 402,
          columnNumber: 7
        }, this) : null,
        /* @__PURE__ */ jsxDEV("div", { ref: logRef, className: "schematic-chatlog min-h-0 flex-1 overflow-y-auto px-3 pb-2", children: renderedMessages.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "px-0.5 py-2 text-[13px] text-ink-muted", children: mode === "factory" ? "Factory Agent routes harness work: code review setup, PR sync, meta loop, and registry analyze." : "Message Mission Control from any tab. Open Overview to watch factory flow, or Gateway for channel conversations." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
          lineNumber: 421,
          columnNumber: 9
        }, this) : renderedMessages.map((m, idx) => {
          if (m.kind === "user") return /* @__PURE__ */ jsxDEV(ChatBubble, { text: m.text }, idx, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
            lineNumber: 428,
            columnNumber: 41
          }, this);
          if (m.kind === "streaming")
            return /* @__PURE__ */ jsxDEV(
              StreamingTurnCard,
              {
                turn: {
                  pending: m.pending,
                  stream: m.stream,
                  startedAt: m.startedAt,
                  gate: m.stream?.includes("gate") ? { decision: "skip", reason: "evaluating retrieval need" } : void 0
                }
              },
              idx,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
                lineNumber: 431,
                columnNumber: 13
              },
              this
            );
          return /* @__PURE__ */ jsxDEV(TurnCard, { turn: m.turn }, idx, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
            lineNumber: 443,
            columnNumber: 18
          }, this);
        }) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
          lineNumber: 419,
          columnNumber: 7
        }, this),
        submitError && /* @__PURE__ */ jsxDEV("div", { role: "alert", className: "shrink-0 border-t border-err/30 bg-err-soft px-3 py-2 text-xs text-err", children: submitError }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
          lineNumber: 449,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex shrink-0 items-center gap-2 border-t border-line px-3 py-2.5", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "dock-msg",
              value: input,
              onChange: (e) => setInput(e.target.value),
              onKeyDown,
              placeholder: mode === "factory" ? "Ask Factory Agent to route harness work…" : "Message Mission Control…",
              autoComplete: "off",
              className: "min-w-0 flex-1 rounded-lg border border-line bg-surface-1 px-3 py-2 text-[13px] text-ink outline-none focus:border-schematic-accent"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
              lineNumber: 455,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "rounded-lg p-2 text-ink-muted hover:text-ink",
              title: "Voice input (coming soon)",
              children: /* @__PURE__ */ jsxDEV(Mic, { size: 15, "aria-hidden": true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
                lineNumber: 473,
                columnNumber: 11
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
              lineNumber: 468,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: send,
              disabled: pending || !input.trim(),
              className: cn(
                "flex items-center gap-1 rounded-lg bg-schematic-accent px-3 py-2 text-[13px] font-semibold text-white",
                "disabled:opacity-40"
              ),
              children: [
                /* @__PURE__ */ jsxDEV(Send, { size: 14, "aria-hidden": true }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
                  lineNumber: 484,
                  columnNumber: 11
                }, this),
                "Send"
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
              lineNumber: 475,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
          lineNumber: 454,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx",
      lineNumber: 302,
      columnNumber: 5
    },
    this
  );
}
_s(ChatDock, "Qr+a3j2i9r4O9gVmKzFzQqqEbHM=", false, function() {
  return [useMutation, useMutation, useQuery, useQuery, useQuery, useQuery];
});
_c = ChatDock;
var _c;
$RefreshReg$(_c, "ChatDock");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/shellV2/ChatDock.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ1NROzs7Ozs7Ozs7Ozs7Ozs7OztBQWhTUixTQUFTQSxhQUFhQyxXQUFXQyxRQUFRQyxnQkFBZ0M7QUFDekUsU0FBU0MsY0FBY0MsU0FBU0MsZUFBZUMsS0FBS0MsTUFBTUMsWUFBWTtBQUN0RSxTQUFTQyxhQUFhQyxnQkFBZ0I7QUFDdEMsU0FBU0MsV0FBVztBQUdwQixTQUFTQyxVQUFVO0FBQ25CLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLHlCQUF5QjtBQVVsQyxNQUFNQyxrQkFBa0I7QUFBQSxFQUN0QixFQUFFQyxPQUFPLHNCQUFzQkMsTUFBTSw2QkFBeUM7QUFBQSxFQUM5RSxFQUFFRCxPQUFPLGtCQUFrQkMsTUFBTSx3QkFBb0M7QUFBQSxFQUNyRSxFQUFFRCxPQUFPLGtCQUFrQkMsTUFBTSxvQkFBZ0M7QUFBQSxFQUNqRSxFQUFFRCxPQUFPLDBCQUEwQkMsTUFBTSxTQUFxQjtBQUFBLEVBQzlELEVBQUVELE9BQU8sa0JBQWtCQyxNQUFNLGlCQUE2QjtBQUFDO0FBWTFELGdCQUFTQyxTQUFTO0FBQUEsRUFDdkJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ2EsR0FBZ0I7QUFBQUMsS0FBQTtBQUM3QixRQUFNLENBQUNDLE1BQU1DLE9BQU8sSUFBSTFCLFNBQW1CLFVBQVU7QUFDckQsUUFBTSxDQUFDMkIsV0FBV0MsWUFBWSxJQUFJNUIsU0FBUyxTQUFTO0FBQ3BELFFBQU0sQ0FBQzZCLE9BQU9DLFFBQVEsSUFBSTlCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUMrQixVQUFVQyxXQUFXLElBQUloQyxTQUFxQixFQUFFO0FBQ3ZELFFBQU0sQ0FBQ2lDLFNBQVNDLFVBQVUsSUFBSWxDLFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUNtQyxrQkFBa0JDLG1CQUFtQixJQUFJcEMsU0FBd0MsSUFBSTtBQUM1RixRQUFNLENBQUNxQyxhQUFhQyxjQUFjLElBQUl0QyxTQUF3QixJQUFJO0FBQ2xFLFFBQU11QyxTQUFTeEMsT0FBdUIsSUFBSTtBQUUxQyxRQUFNeUMsZUFBZWpDLFlBQVlFLElBQUlnQyxRQUFRQyxTQUFTQyxtQkFBbUI7QUFDekUsUUFBTUMsb0JBQW9CckMsWUFBWUUsSUFBSW9DLFlBQVlDLGFBQWE7QUFDbkUsUUFBTUMsY0FBY3ZDO0FBQUFBLElBQ2xCQyxJQUFJb0MsWUFBWUc7QUFBQUEsSUFDaEIzQixZQUFZLEVBQUVBLFdBQVc0QixPQUFPLEdBQUcsSUFBSTtBQUFBLEVBQ3pDO0FBQ0EsUUFBTUMsY0FBYzFDO0FBQUFBLElBQ2xCQyxJQUFJb0MsWUFBWU07QUFBQUEsSUFDaEJoQixtQkFBbUIsRUFBRWlCLFVBQVVqQixpQkFBaUIsSUFBSTtBQUFBLEVBQ3REO0FBQ0EsUUFBTWtCLGdCQUFnQjdDO0FBQUFBLElBQ3BCQyxJQUFJZ0MsUUFBUWEsT0FBT0M7QUFBQUEsSUFDbkJsQyxZQUFZLEVBQUVBLFVBQVUsSUFBSTtBQUFBLEVBQzlCO0FBRUEsUUFBTW1DLE9BQU9oRDtBQUFBQSxJQUNYQyxJQUFJZ0QsVUFBVUM7QUFBQUEsSUFDZHJDLFlBQVksRUFBRUEsV0FBVzRCLE9BQU8sR0FBRyxJQUFJLEVBQUVBLE9BQU8sR0FBRztBQUFBLEVBQ3JEO0FBRUEsUUFBTVUsV0FDSmxDLFNBQVMsYUFDTDtBQUFBLElBQ0U7QUFBQSxNQUNFbUMsSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxTQUFTO0FBQUEsTUFDVEMsY0FBYztBQUFBLElBQ2hCO0FBQUEsSUFDQSxJQUFJaEIsZUFBZSxJQUFJaUIsSUFBSSxDQUFDQyxZQUFZO0FBQUEsTUFDdENMLElBQUlLLE9BQU9DO0FBQUFBLE1BQ1hMLE9BQU9JLE9BQU9KO0FBQUFBLE1BQ2RDLFNBQVM7QUFBQSxNQUNUQyxjQUFjRSxPQUFPRjtBQUFBQSxJQUN2QixFQUFFO0FBQUEsRUFBQyxJQUVMO0FBQUEsSUFDRTtBQUFBLE1BQ0VILElBQUk7QUFBQSxNQUNKQyxPQUFPO0FBQUEsTUFDUEMsU0FBUztBQUFBLE1BQ1RDLGNBQWNoQyxTQUFTb0M7QUFBQUEsSUFDekI7QUFBQSxJQUNBLElBQUlYLFFBQVEsSUFBSVksTUFBTSxHQUFHLENBQUMsRUFBRUosSUFBSSxDQUFDSyxPQUFPO0FBQUEsTUFDdENULElBQUlTLEVBQUVUO0FBQUFBLE1BQ05DLE9BQU9RLEVBQUVyRDtBQUFBQSxNQUNUOEMsU0FBUztBQUFBLE1BQ1RDLGNBQWNNLEVBQUVDO0FBQUFBLElBQ2xCLEVBQUU7QUFBQSxFQUFDO0FBR1h4RSxZQUFVLE1BQU07QUFDZHNDLHdCQUFvQixJQUFJO0FBQ3hCUixpQkFBYUgsU0FBUyxhQUFhLFFBQVEsU0FBUztBQUNwRE8sZ0JBQVksRUFBRTtBQUNkTSxtQkFBZSxJQUFJO0FBQUEsRUFDckIsR0FBRyxDQUFDYixNQUFNSixTQUFTLENBQUM7QUFFcEIsUUFBTWtELG1CQUNKOUMsU0FBUyxhQUNMO0FBQUEsSUFDRSxJQUFJeUIsYUFBYW5CLFlBQVksSUFBSWlDO0FBQUFBLE1BQUksQ0FBQ1EsWUFDcENBLFFBQVFDLGVBQWUsVUFDbkIsRUFBRUMsTUFBTSxRQUFRQyxNQUFNSCxRQUFRSSxRQUFRLElBQ3RDO0FBQUEsUUFDRUYsTUFBTTtBQUFBLFFBQ05HLE1BQU07QUFBQSxVQUNKQyxPQUFPTixRQUFRSTtBQUFBQSxVQUNmRyxNQUFNO0FBQUEsWUFDSkMsVUFBVTtBQUFBLFlBQ1ZDLFFBQVE7QUFBQSxVQUNWO0FBQUEsVUFDQUMsV0FBVztBQUFBLFVBQ1hDLFlBQVk7QUFBQSxVQUNaQyxNQUFNO0FBQUEsVUFDTkMsT0FBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQUEsSUFDTjtBQUFBLElBQ0EsR0FBR3RELFNBQVN1RCxPQUFPLENBQUNkLFlBQVlBLFFBQVFFLFNBQVMsV0FBVztBQUFBLEVBQUMsSUFFL0QzQztBQUVOakMsWUFBVSxNQUFNO0FBQ2R5QyxXQUFPZ0QsU0FBU0MsU0FBUyxFQUFFQyxLQUFLbEQsT0FBT2dELFFBQVFHLGFBQWEsQ0FBQztBQUFBLEVBQy9ELEdBQUcsQ0FBQ25CLGlCQUFpQkosUUFBUWxDLE9BQU8sQ0FBQztBQUVyQyxRQUFNMEQsZUFBZTlGO0FBQUFBLElBQ25CLE9BQU84RSxNQUFjaUIsY0FBc0I7QUFDekMsWUFBTUMsUUFBUWxCLEtBQUttQixZQUFZO0FBQy9CLFVBQUlELE1BQU1FLFNBQVMsV0FBVyxLQUFLRixNQUFNRSxTQUFTLFlBQVksR0FBRztBQUMvRCxjQUFNdkQsYUFBYSxFQUFFbkIsV0FBV0EsYUFBYTJFLE9BQVUsQ0FBQztBQUN4RHpFLHFCQUFhLG1CQUFtQjtBQUNoQyxlQUFPO0FBQUEsVUFDTHVELE9BQU87QUFBQSxVQUNQQyxNQUFNLEVBQUVDLFVBQVUsU0FBa0JDLFFBQVEsNEJBQTRCO0FBQUEsUUFDMUU7QUFBQSxNQUNGO0FBQ0EsVUFBSVksTUFBTUUsU0FBUyxhQUFhLEtBQUtGLE1BQU1FLFNBQVMsZUFBZSxHQUFHO0FBQ3BFeEUscUJBQWEsNEJBQTRCO0FBQ3pDLGVBQU87QUFBQSxVQUNMdUQsT0FBTztBQUFBLFVBQ1BDLE1BQU0sRUFBRUMsVUFBVSxTQUFrQkMsUUFBUSw4QkFBOEI7QUFBQSxRQUM1RTtBQUFBLE1BQ0Y7QUFDQSxVQUFJWSxNQUFNRSxTQUFTLElBQUksS0FBS0YsTUFBTUUsU0FBUyxlQUFlLEtBQUtGLE1BQU1FLFNBQVMsVUFBVSxHQUFHO0FBQ3pGeEUscUJBQWEsdUJBQXVCO0FBQ3BDLGVBQU87QUFBQSxVQUNMdUQsT0FBTztBQUFBLFVBQ1BDLE1BQU0sRUFBRUMsVUFBVSxTQUFrQkMsUUFBUSw0QkFBNEI7QUFBQSxRQUMxRTtBQUFBLE1BQ0Y7QUFDQSxVQUFJWSxNQUFNRSxTQUFTLFNBQVMsS0FBS0YsTUFBTUUsU0FBUyxRQUFRLEtBQUtGLE1BQU1FLFNBQVMsT0FBTyxHQUFHO0FBQ3BGeEUscUJBQWEsUUFBUTtBQUNyQixlQUFPO0FBQUEsVUFDTHVELE9BQU87QUFBQSxVQUNQQyxNQUFNLEVBQUVDLFVBQVUsU0FBa0JDLFFBQVEsbUNBQW1DO0FBQUEsUUFDakY7QUFBQSxNQUNGO0FBQ0EsVUFBSVksTUFBTUUsU0FBUyxRQUFRLEtBQUtGLE1BQU1FLFNBQVMsVUFBVSxHQUFHO0FBQzFEeEUscUJBQWEsZ0JBQWdCO0FBQzdCLGNBQU0wRSxRQUFRNUMsZUFBZTZDLGlCQUFpQjtBQUM5QyxlQUFPO0FBQUEsVUFDTHBCLE9BQU8scUJBQXFCbUIsS0FBSztBQUFBLFVBQ2pDbEIsTUFBTSxFQUFFQyxVQUFVLFNBQWtCQyxRQUFRLHlCQUF5QjtBQUFBLFFBQ3ZFO0FBQUEsTUFDRjtBQUNBLFVBQUlZLE1BQU1FLFNBQVMsVUFBVSxLQUFLRixNQUFNRSxTQUFTLFVBQVUsR0FBRztBQUM1RHhFLHFCQUFhLGdCQUFnQjtBQUM3QixlQUFPO0FBQUEsVUFDTHVELE9BQU87QUFBQSxVQUNQQyxNQUFNLEVBQUVDLFVBQVUsU0FBa0JDLFFBQVEsNkJBQTZCO0FBQUEsUUFDM0U7QUFBQSxNQUNGO0FBQ0EsYUFBTztBQUFBLFFBQ0xILE9BQU8sb0lBQW9JekQsWUFBWSxXQUFXLGNBQWM7QUFBQSxRQUNoTDBELE1BQU0sRUFBRUMsVUFBVSxRQUFpQkMsUUFBUSxrQ0FBa0M7QUFBQSxNQUMvRTtBQUFBLElBQ0Y7QUFBQSxJQUNBLENBQUM1QixlQUFlNkMsZUFBZTNFLFlBQVlGLFdBQVdtQixZQUFZO0FBQUEsRUFDcEU7QUFFQSxRQUFNMkQsT0FBT3RHO0FBQUFBLElBQVksTUFBTTtBQUM3QixZQUFNOEUsT0FBTzlDLE1BQU11RSxLQUFLO0FBQ3hCLFVBQUksQ0FBQ3pCLFFBQVExQyxRQUFTO0FBQ3RCSyxxQkFBZSxJQUFJO0FBQ25CUixlQUFTLEVBQUU7QUFDWCxVQUFJTCxTQUFTLFdBQVc7QUFDdEJPLG9CQUFZLENBQUNxRSxNQUFNLENBQUMsR0FBR0EsR0FBRyxFQUFFM0IsTUFBTSxRQUFRQyxLQUFLLENBQUMsQ0FBQztBQUFBLE1BQ25EO0FBQ0F6QyxpQkFBVyxJQUFJO0FBQ2YsWUFBTTBELFlBQVlVLEtBQUtDLElBQUk7QUFDM0J2RTtBQUFBQSxRQUFZLENBQUNxRSxNQUFNO0FBQUEsVUFDakIsR0FBR0E7QUFBQUEsVUFDSCxFQUFFM0IsTUFBTSxhQUFhekMsU0FBUyxNQUFNdUUsUUFBUSxJQUFJWixVQUFVO0FBQUEsUUFBQztBQUFBLE1BQzVEO0FBRUQsWUFBTWEsU0FBU0EsQ0FBQzVCLFNBQXVCO0FBQ3JDM0MsbUJBQVcsS0FBSztBQUNoQkYsb0JBQVksQ0FBQ3FFLE1BQU07QUFDakIsZ0JBQU1LLGdCQUFnQkwsRUFBRWYsT0FBTyxDQUFDcUIsTUFBTUEsRUFBRWpDLFNBQVMsV0FBVztBQUM1RCxpQkFBTyxDQUFDLEdBQUdnQyxlQUFlLEVBQUVoQyxNQUFNLFFBQVFHLEtBQUssQ0FBQztBQUFBLFFBQ2xELENBQUM7QUFBQSxNQUNIO0FBRUEsVUFBSXBELFNBQVMsV0FBVztBQUN0QixhQUFLa0UsYUFBYWhCLE1BQU1pQixTQUFTLEVBQzlCZ0IsS0FBSyxDQUFDLEVBQUU5QixPQUFPQyxLQUFLLE1BQU07QUFDekIwQixpQkFBTztBQUFBLFlBQ0wzQjtBQUFBQSxZQUNBQztBQUFBQSxZQUNBRyxXQUFXb0IsS0FBS0MsSUFBSSxJQUFJWDtBQUFBQSxZQUN4QlQsWUFBWTtBQUFBLFlBQ1pDLE1BQU07QUFBQSxZQUNOQyxPQUFPO0FBQUEsVUFDVCxDQUFDO0FBQUEsUUFDSCxDQUFDLEVBQ0F3QixNQUFNLENBQUNDLFVBQVU7QUFDaEI1RSxxQkFBVyxLQUFLO0FBQ2hCRixzQkFBWSxDQUFDdUQsWUFBWUEsUUFBUUQsT0FBTyxDQUFDeUIsU0FBU0EsS0FBS3JDLFNBQVMsV0FBVyxDQUFDO0FBQzVFcEMseUJBQWV3RSxpQkFBaUJFLFFBQVFGLE1BQU10QyxVQUFVLHlCQUF5QjtBQUFBLFFBQ25GLENBQUM7QUFDSDtBQUFBLE1BQ0Y7QUFFQSxVQUFJLENBQUNuRCxXQUFXO0FBQ2RhLG1CQUFXLEtBQUs7QUFDaEJGLG9CQUFZLEVBQUU7QUFDZE0sdUJBQWUsNENBQTRDO0FBQzNEO0FBQUEsTUFDRjtBQUNBLFdBQUtNLGtCQUFrQjtBQUFBLFFBQ3JCdkI7QUFBQUEsUUFDQStCLFVBQVVqQixvQkFBb0I2RDtBQUFBQSxRQUM5QnBCLFNBQVNEO0FBQUFBLFFBQ1RzQyxTQUFTO0FBQUEsUUFDVEMsZ0JBQWdCLGdCQUFnQjdGLFNBQVMsSUFBSXVFLFNBQVM7QUFBQSxNQUN4RCxDQUFDLEVBQ0VnQixLQUFLLENBQUNPLFdBQVc7QUFDaEIvRSw0QkFBb0IrRSxPQUFPL0QsUUFBUTtBQUNuQ3hCLHFCQUFhdUYsT0FBTy9ELFFBQVE7QUFDNUJwQixvQkFBWSxFQUFFO0FBQ2RFLG1CQUFXLEtBQUs7QUFBQSxNQUNsQixDQUFDLEVBQ0EyRSxNQUFNLENBQUNDLFVBQVU7QUFDaEI1RSxtQkFBVyxLQUFLO0FBQ2hCRixvQkFBWSxFQUFFO0FBQ2RNO0FBQUFBLFVBQ0V3RSxpQkFBaUJFLFFBQVFGLE1BQU10QyxVQUFVO0FBQUEsUUFDM0M7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNMO0FBQUEsSUFBRztBQUFBLE1BQ0RtQjtBQUFBQSxNQUNBOUQ7QUFBQUEsTUFDQUo7QUFBQUEsTUFDQVE7QUFBQUEsTUFDQVo7QUFBQUEsTUFDQWM7QUFBQUEsTUFDQVM7QUFBQUEsSUFBaUI7QUFBQSxFQUNsQjtBQUVELFFBQU13RSxZQUFZQSxDQUFDQyxNQUEyQjtBQUM1QyxRQUFJQSxFQUFFQyxRQUFRLFdBQVcsQ0FBQ0QsRUFBRUUsVUFBVTtBQUNwQ0YsUUFBRUcsZUFBZTtBQUNqQnJCLFdBQUs7QUFBQSxJQUNQO0FBQUEsRUFDRjtBQUVBLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVU7QUFBQSxNQUNWLE9BQU8sRUFBRWhGLE1BQU07QUFBQSxNQUNmLGNBQVc7QUFBQSxNQUVYO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFFQUNiO0FBQUEsaUNBQUMsaUJBQWMsTUFBTSxJQUFJLFdBQVUsa0JBQWlCLGVBQVcsUUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Q7QUFBQSxVQUMvRCx1QkFBQyxVQUFLLFdBQVUsc0NBQXFDLG9CQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RDtBQUFBLFVBQ3hERyxhQUNDLHVCQUFDLFVBQUssV0FBVSx1Q0FBdUNBLHdCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRSxJQUNoRTtBQUFBLFVBQ0o7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVNGO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBQ1YsT0FBTTtBQUFBLGNBRU4saUNBQUMsZ0JBQWEsTUFBTSxJQUFJLGVBQVcsUUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUM7QUFBQTtBQUFBLFlBTnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsYUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxzREFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU1NLFFBQVEsVUFBVTtBQUFBLGNBQ2pDLFdBQVdoQjtBQUFBQSxnQkFDVDtBQUFBLGdCQUNBZSxTQUFTLGFBQWEsMEJBQTBCO0FBQUEsY0FDbEQ7QUFBQSxjQUVBO0FBQUEsdUNBQUMsUUFBSyxNQUFNLElBQUksZUFBVyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNQyxRQUFRLFNBQVM7QUFBQSxjQUNoQyxXQUFXaEI7QUFBQUEsZ0JBQ1Q7QUFBQSxnQkFDQWUsU0FBUyxZQUFZLHNDQUFzQztBQUFBLGNBQzdEO0FBQUEsY0FFQTtBQUFBLHVDQUFDLFdBQVEsTUFBTSxJQUFJLGVBQVcsUUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVJoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLGFBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1QkE7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsaUJBQWlCRTtBQUFBQSxZQUNqQixXQUFXLE1BQU07QUFDZkMsMkJBQWFILFNBQVMsYUFBYSxRQUFRLFdBQVc2RSxLQUFLQyxJQUFJLENBQUMsRUFBRTtBQUNsRW5FLGtDQUFvQixJQUFJO0FBQ3hCSiwwQkFBWSxFQUFFO0FBQ2RNLDZCQUFlLElBQUk7QUFBQSxZQUNyQjtBQUFBLFlBQ0EsaUJBQWlCLENBQUNtRixrQkFBa0I7QUFDbEM3RiwyQkFBYTZGLGFBQWE7QUFDMUIsa0JBQUloRyxTQUFTLFlBQVk7QUFDdkIsc0JBQU13QyxVQUFVbEIsZUFBZSxJQUFJMkUsS0FBSyxDQUFDQyxjQUFjQSxVQUFVekQsUUFBUXVELGFBQWE7QUFDdEZyRixvQ0FBb0I2QixRQUFRQyxPQUFPLElBQUk7QUFBQSxjQUN6QztBQUFBLFlBQ0Y7QUFBQSxZQUNBLGtCQUFrQixNQUFNO0FBQ3RCLG9CQUFNMEQsUUFBUTdFLGNBQWMsQ0FBQztBQUM3QixrQkFBSXRCLFNBQVMsY0FBY21HLE9BQU87QUFDaENoRyw2QkFBYWdHLE1BQU0xRCxHQUFHO0FBQ3RCOUIsb0NBQW9Cd0YsTUFBTTFELEdBQUc7QUFBQSxjQUMvQjtBQUFBLFlBQ0Y7QUFBQSxZQUNBLFlBQVl6QyxTQUFTLFlBQVksa0JBQWtCO0FBQUE7QUFBQSxVQXZCckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBdUJzRTtBQUFBLFFBR3JFQSxTQUFTLGNBQWN5QixhQUFhMkUsUUFDbkMsdUJBQUMsU0FBSSxXQUFVLG9FQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNdEcsYUFBYSxPQUFPO0FBQUEsZ0JBQ25DLFdBQVU7QUFBQSxnQkFFVDJCLHNCQUFZMkUsS0FBS0MsY0FBYzVFLFlBQVkyRSxLQUFLaEU7QUFBQUE7QUFBQUEsY0FMbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSwrREFDYlgsc0JBQVkyRSxLQUFLRSxPQUFPQyxRQUFRLE1BQU0sR0FBRyxLQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsVUFDQzlFLFlBQVkrRSxhQUNYO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU0xRyxhQUFhLHFCQUFxQjtBQUFBLGNBQ2pELFdBQVU7QUFBQSxjQUFvRDtBQUFBO0FBQUEsZ0JBRWpEMkIsWUFBWStFLFVBQVVDLE1BQU1GLFFBQVEsTUFBTSxHQUFHO0FBQUEsZ0JBQ3pEOUUsWUFBWWlGLGNBQWMsVUFBVWpGLFlBQVlpRixZQUFZSixNQUFNLEtBQUs7QUFBQTtBQUFBO0FBQUEsWUFOMUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxhQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUJBO0FBQUEsUUFHRHRHLFNBQVMsWUFDUix1QkFBQyxTQUFJLFdBQVUsa0VBQ1pWLDBCQUFnQmlEO0FBQUFBLFVBQUksQ0FBQ29FLE1BQ3BCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU07QUFDYjdHLDZCQUFhNkcsRUFBRW5ILElBQUk7QUFDbkJhLHlCQUFTc0csRUFBRXBILEtBQUs7QUFBQSxjQUNsQjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVRvSCxZQUFFcEg7QUFBQUE7QUFBQUEsWUFSRW9ILEVBQUVuSDtBQUFBQSxZQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLFFBQ0QsS0FiSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0EsSUFDRTtBQUFBLFFBRUosdUJBQUMsU0FBSSxLQUFLc0IsUUFBUSxXQUFVLDhEQUN6QmdDLDJCQUFpQkosV0FBVyxJQUMzQix1QkFBQyxPQUFFLFdBQVUsMENBQ1YxQyxtQkFBUyxZQUNOLG9HQUNBLHNIQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQSxJQUVBOEMsaUJBQWlCUCxJQUFJLENBQUNxQyxHQUFHZ0MsUUFBUTtBQUMvQixjQUFJaEMsRUFBRTNCLFNBQVMsT0FBUSxRQUFPLHVCQUFDLGNBQXFCLE1BQU0yQixFQUFFMUIsUUFBYjBELEtBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1DO0FBQ2pFLGNBQUloQyxFQUFFM0IsU0FBUztBQUNiLG1CQUNFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsTUFBTTtBQUFBLGtCQUNKekMsU0FBU29FLEVBQUVwRTtBQUFBQSxrQkFDWHVFLFFBQVFILEVBQUVHO0FBQUFBLGtCQUNWWixXQUFXUyxFQUFFVDtBQUFBQSxrQkFDYmIsTUFBTXNCLEVBQUVHLFFBQVFULFNBQVMsTUFBTSxJQUMzQixFQUFFZixVQUFVLFFBQVFDLFFBQVEsNEJBQTRCLElBQ3hEZTtBQUFBQSxnQkFDTjtBQUFBO0FBQUEsY0FSS3FDO0FBQUFBLGNBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNJO0FBR1IsaUJBQU8sdUJBQUMsWUFBbUIsTUFBTWhDLEVBQUV4QixRQUFid0QsS0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpQztBQUFBLFFBQzFDLENBQUMsS0F6Qkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJCQTtBQUFBLFFBRUNoRyxlQUNDLHVCQUFDLFNBQUksTUFBSyxTQUFRLFdBQVUsMEVBQ3pCQSx5QkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUdGLHVCQUFDLFNBQUksV0FBVSxxRUFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxJQUFHO0FBQUEsY0FDSCxPQUFPUjtBQUFBQSxjQUNQLFVBQVUsQ0FBQ3dGLE1BQU12RixTQUFTdUYsRUFBRWlCLE9BQU9DLEtBQUs7QUFBQSxjQUN4QztBQUFBLGNBQ0EsYUFDRTlHLFNBQVMsWUFDTCw2Q0FDQTtBQUFBLGNBRU4sY0FBYTtBQUFBLGNBQ2IsV0FBVTtBQUFBO0FBQUEsWUFYWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXaUo7QUFBQSxVQUVqSjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsT0FBTTtBQUFBLGNBRU4saUNBQUMsT0FBSSxNQUFNLElBQUksZUFBVyxRQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQjtBQUFBO0FBQUEsWUFMNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTMEU7QUFBQUEsY0FDVCxVQUFVbEUsV0FBVyxDQUFDSixNQUFNdUUsS0FBSztBQUFBLGNBQ2pDLFdBQVcxRjtBQUFBQSxnQkFDVDtBQUFBLGdCQUNBO0FBQUEsY0FDRjtBQUFBLGNBRUE7QUFBQSx1Q0FBQyxRQUFLLE1BQU0sSUFBSSxlQUFXLFFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFUN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0E7QUFBQSxhQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUNBO0FBQUE7QUFBQTtBQUFBLElBekxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTBMQTtBQUVKO0FBQUNjLEdBamJlTixVQUFRO0FBQUEsVUFnQkRYLGFBQ0tBLGFBQ05DLFVBSUFBLFVBSUVBLFVBS1RBLFFBQVE7QUFBQTtBQUFBLEtBL0JQVTtBQUFRLElBQUFzSDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVN0YXRlIiwiQ2hldnJvblJpZ2h0IiwiRmFjdG9yeSIsIk1lc3NhZ2VTcXVhcmUiLCJNaWMiLCJTZW5kIiwiVXNlciIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJhcGkiLCJjbiIsIkNoYXRTZXNzaW9uQmFyIiwiQ2hhdEJ1YmJsZSIsIlR1cm5DYXJkIiwiU3RyZWFtaW5nVHVybkNhcmQiLCJGQUNUT1JZX1BST01QVFMiLCJsYWJlbCIsInZpZXciLCJDaGF0RG9jayIsIndpZHRoIiwib25DbG9zZSIsInByb2plY3RJZCIsImFyY2hTdGF0dXMiLCJvbk5hdmlnYXRlIiwiX3MiLCJtb2RlIiwic2V0TW9kZSIsInNlc3Npb25JZCIsInNldFNlc3Npb25JZCIsImlucHV0Iiwic2V0SW5wdXQiLCJtZXNzYWdlcyIsInNldE1lc3NhZ2VzIiwicGVuZGluZyIsInNldFBlbmRpbmciLCJzZWxlY3RlZFRocmVhZElkIiwic2V0U2VsZWN0ZWRUaHJlYWRJZCIsInN1Ym1pdEVycm9yIiwic2V0U3VibWl0RXJyb3IiLCJsb2dSZWYiLCJzZWVkTWV0YUxvb3AiLCJmYWN0b3J5IiwibWV0YUxvb3AiLCJzZWVkRGVtb1N1Z2dlc3Rpb25zIiwic3VibWl0Q2hhdFJlcXVlc3QiLCJtaXNzaW9uQ2hhdCIsInN1Ym1pdFJlcXVlc3QiLCJjaGF0VGhyZWFkcyIsImxpc3RUaHJlYWRzIiwibGltaXQiLCJjaGF0U2Vzc2lvbiIsImdldFNlc3Npb24iLCJ0aHJlYWRJZCIsImZhY3RvcnlIZWFsdGgiLCJoZWFsdGgiLCJnZXRGYWN0b3J5SGVhbHRoIiwicnVucyIsImFuYWx5dGljcyIsInJlY2VudFJ1blR1cm5zIiwic2Vzc2lvbnMiLCJpZCIsInRpdGxlIiwiY2hhbm5lbCIsIm1lc3NhZ2VDb3VudCIsIm1hcCIsInRocmVhZCIsIl9pZCIsImxlbmd0aCIsInNsaWNlIiwiciIsInRvb2xDb3VudCIsInJlbmRlcmVkTWVzc2FnZXMiLCJtZXNzYWdlIiwic2VuZGVyVHlwZSIsImtpbmQiLCJ0ZXh0IiwiY29udGVudCIsInR1cm4iLCJyZXBseSIsImdhdGUiLCJkZWNpc2lvbiIsInJlYXNvbiIsImxhdGVuY3lNcyIsIml0ZXJhdGlvbnMiLCJjb3N0IiwibW9kZWwiLCJmaWx0ZXIiLCJjdXJyZW50Iiwic2Nyb2xsVG8iLCJ0b3AiLCJzY3JvbGxIZWlnaHQiLCJmYWN0b3J5UmVwbHkiLCJzdGFydGVkQXQiLCJsb3dlciIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ1bmRlZmluZWQiLCJzdGFnZSIsIm1hdHVyaXR5U3RhZ2UiLCJzZW5kIiwidHJpbSIsIm0iLCJEYXRlIiwibm93Iiwic3RyZWFtIiwiZmluaXNoIiwid2l0aG91dFN0cmVhbSIsIngiLCJ0aGVuIiwiY2F0Y2giLCJlcnJvciIsIml0ZW0iLCJFcnJvciIsImFjdG9ySWQiLCJpZGVtcG90ZW5jeUtleSIsInJlc3VsdCIsIm9uS2V5RG93biIsImUiLCJrZXkiLCJzaGlmdEtleSIsInByZXZlbnREZWZhdWx0IiwibmV4dFNlc3Npb25JZCIsImZpbmQiLCJjYW5kaWRhdGUiLCJmaXJzdCIsInRhc2siLCJpZGVudGlmaWVyIiwic3RhdHVzIiwicmVwbGFjZSIsIndvcmtPcmRlciIsInN0YXRlIiwid29ya2Zsb3dSdW4iLCJwIiwiaWR4IiwidGFyZ2V0IiwidmFsdWUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDaGF0RG9jay50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSwgdHlwZSBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IENoZXZyb25SaWdodCwgRmFjdG9yeSwgTWVzc2FnZVNxdWFyZSwgTWljLCBTZW5kLCBVc2VyIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5IH0gZnJvbSBcImNvbnZleC9yZWFjdFwiO1xuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2FwaVwiO1xuaW1wb3J0IHR5cGUgeyBJZCB9IGZyb20gXCIuLi8uLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9kYXRhTW9kZWxcIjtcbmltcG9ydCB0eXBlIHsgTWFpblZpZXcgfSBmcm9tIFwiLi4vVG9wTmF2XCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiO1xuaW1wb3J0IHsgQ2hhdFNlc3Npb25CYXIgfSBmcm9tIFwiQC9jb21wb25lbnRzL29wZXJhdG9yL0NoYXRTZXNzaW9uQmFyXCI7XG5pbXBvcnQgeyBDaGF0QnViYmxlIH0gZnJvbSBcIkAvY29tcG9uZW50cy9vcGVyYXRvci9DaGF0QnViYmxlXCI7XG5pbXBvcnQgeyBUdXJuQ2FyZCB9IGZyb20gXCJAL2NvbXBvbmVudHMvb3BlcmF0b3IvVHVybkNhcmRcIjtcbmltcG9ydCB7IFN0cmVhbWluZ1R1cm5DYXJkIH0gZnJvbSBcIkAvY29tcG9uZW50cy9vcGVyYXRvci9TdHJlYW1pbmdUdXJuQ2FyZFwiO1xuaW1wb3J0IHR5cGUgeyBUdXJuQ2FyZERhdGEgfSBmcm9tIFwiQC9jb21wb25lbnRzL29wZXJhdG9yL1R1cm5DYXJkXCI7XG5cbnR5cGUgQ2hhdE1vZGUgPSBcIm9wZXJhdG9yXCIgfCBcImZhY3RvcnlcIjtcblxudHlwZSBDaGF0SXRlbSA9XG4gIHwgeyBraW5kOiBcInVzZXJcIjsgdGV4dDogc3RyaW5nIH1cbiAgfCB7IGtpbmQ6IFwidHVyblwiOyB0dXJuOiBUdXJuQ2FyZERhdGEgfVxuICB8IHsga2luZDogXCJzdHJlYW1pbmdcIjsgcGVuZGluZzogYm9vbGVhbjsgc3RyZWFtPzogc3RyaW5nOyBzdGFydGVkQXQ6IG51bWJlciB9O1xuXG5jb25zdCBGQUNUT1JZX1BST01QVFMgPSBbXG4gIHsgbGFiZWw6IFwiU2V0IHVwIGNvZGUgcmV2aWV3XCIsIHZpZXc6IFwiaGFybmVzcy1jb2RlLXJldmlldy13aXphcmRcIiBhcyBNYWluVmlldyB9LFxuICB7IGxhYmVsOiBcIlN5bmMgUFIgY2hlY2tzXCIsIHZpZXc6IFwiaGFybmVzcy1jaGFuZ2UtcmV2aWV3XCIgYXMgTWFpblZpZXcgfSxcbiAgeyBsYWJlbDogXCJPcGVuIG1ldGEgbG9vcFwiLCB2aWV3OiBcImhhcm5lc3MtbWV0YS1sb29wXCIgYXMgTWFpblZpZXcgfSxcbiAgeyBsYWJlbDogXCJFdmFsdWF0ZSBHaXRIdWIgc2tpbGxzXCIsIHZpZXc6IFwic2tpbGxzXCIgYXMgTWFpblZpZXcgfSxcbiAgeyBsYWJlbDogXCJGYWN0b3J5IGhlYWx0aFwiLCB2aWV3OiBcImhhcm5lc3MtaGVhbHRoXCIgYXMgTWFpblZpZXcgfSxcbl07XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ2hhdERvY2tQcm9wcyB7XG4gIHdpZHRoOiBudW1iZXIgfCBzdHJpbmc7XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gIHByb2plY3RJZD86IElkPFwicHJvamVjdHNcIj4gfCBudWxsO1xuICBhcmNoU3RhdHVzPzogUmVhY3ROb2RlO1xuICBvbk5hdmlnYXRlPzogKHZpZXc6IE1haW5WaWV3KSA9PiB2b2lkO1xufVxuXG4vKiogUGVyc2lzdGVudCByaWdodCBjaGF0IGRvY2sgKHdha3UgI2RvY2spLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIENoYXREb2NrKHtcbiAgd2lkdGgsXG4gIG9uQ2xvc2UsXG4gIHByb2plY3RJZCxcbiAgYXJjaFN0YXR1cyxcbiAgb25OYXZpZ2F0ZSxcbn06IENoYXREb2NrUHJvcHMpOiBKU1guRWxlbWVudCB7XG4gIGNvbnN0IFttb2RlLCBzZXRNb2RlXSA9IHVzZVN0YXRlPENoYXRNb2RlPihcIm9wZXJhdG9yXCIpO1xuICBjb25zdCBbc2Vzc2lvbklkLCBzZXRTZXNzaW9uSWRdID0gdXNlU3RhdGUoXCJkZWZhdWx0XCIpO1xuICBjb25zdCBbaW5wdXQsIHNldElucHV0XSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbbWVzc2FnZXMsIHNldE1lc3NhZ2VzXSA9IHVzZVN0YXRlPENoYXRJdGVtW10+KFtdKTtcbiAgY29uc3QgW3BlbmRpbmcsIHNldFBlbmRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbc2VsZWN0ZWRUaHJlYWRJZCwgc2V0U2VsZWN0ZWRUaHJlYWRJZF0gPSB1c2VTdGF0ZTxJZDxcInRlbGVncmFwaFRocmVhZHNcIj4gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3N1Ym1pdEVycm9yLCBzZXRTdWJtaXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgbG9nUmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcblxuICBjb25zdCBzZWVkTWV0YUxvb3AgPSB1c2VNdXRhdGlvbihhcGkuZmFjdG9yeS5tZXRhTG9vcC5zZWVkRGVtb1N1Z2dlc3Rpb25zKTtcbiAgY29uc3Qgc3VibWl0Q2hhdFJlcXVlc3QgPSB1c2VNdXRhdGlvbihhcGkubWlzc2lvbkNoYXQuc3VibWl0UmVxdWVzdCk7XG4gIGNvbnN0IGNoYXRUaHJlYWRzID0gdXNlUXVlcnkoXG4gICAgYXBpLm1pc3Npb25DaGF0Lmxpc3RUaHJlYWRzLFxuICAgIHByb2plY3RJZCA/IHsgcHJvamVjdElkLCBsaW1pdDogMjAgfSA6IFwic2tpcFwiXG4gICk7XG4gIGNvbnN0IGNoYXRTZXNzaW9uID0gdXNlUXVlcnkoXG4gICAgYXBpLm1pc3Npb25DaGF0LmdldFNlc3Npb24sXG4gICAgc2VsZWN0ZWRUaHJlYWRJZCA/IHsgdGhyZWFkSWQ6IHNlbGVjdGVkVGhyZWFkSWQgfSA6IFwic2tpcFwiXG4gICk7XG4gIGNvbnN0IGZhY3RvcnlIZWFsdGggPSB1c2VRdWVyeShcbiAgICBhcGkuZmFjdG9yeS5oZWFsdGguZ2V0RmFjdG9yeUhlYWx0aCxcbiAgICBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCB9IDogXCJza2lwXCJcbiAgKTtcblxuICBjb25zdCBydW5zID0gdXNlUXVlcnkoXG4gICAgYXBpLmFuYWx5dGljcy5yZWNlbnRSdW5UdXJucyxcbiAgICBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCwgbGltaXQ6IDIwIH0gOiB7IGxpbWl0OiAyMCB9XG4gICk7XG5cbiAgY29uc3Qgc2Vzc2lvbnMgPVxuICAgIG1vZGUgPT09IFwib3BlcmF0b3JcIlxuICAgICAgPyBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6IFwibmV3XCIsXG4gICAgICAgICAgICB0aXRsZTogXCJOZXcgd29yayByZXF1ZXN0XCIsXG4gICAgICAgICAgICBjaGFubmVsOiBcIm9wZXJhdG9yXCIsXG4gICAgICAgICAgICBtZXNzYWdlQ291bnQ6IDAsXG4gICAgICAgICAgfSxcbiAgICAgICAgICAuLi4oY2hhdFRocmVhZHMgPz8gW10pLm1hcCgodGhyZWFkKSA9PiAoe1xuICAgICAgICAgICAgaWQ6IHRocmVhZC5faWQsXG4gICAgICAgICAgICB0aXRsZTogdGhyZWFkLnRpdGxlLFxuICAgICAgICAgICAgY2hhbm5lbDogXCJvcGVyYXRvclwiLFxuICAgICAgICAgICAgbWVzc2FnZUNvdW50OiB0aHJlYWQubWVzc2FnZUNvdW50LFxuICAgICAgICAgIH0pKSxcbiAgICAgICAgXVxuICAgICAgOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6IFwiZGVmYXVsdFwiLFxuICAgICAgICAgICAgdGl0bGU6IFwiRmFjdG9yeSBBZ2VudFwiLFxuICAgICAgICAgICAgY2hhbm5lbDogXCJmYWN0b3J5XCIsXG4gICAgICAgICAgICBtZXNzYWdlQ291bnQ6IG1lc3NhZ2VzLmxlbmd0aCxcbiAgICAgICAgICB9LFxuICAgICAgICAgIC4uLihydW5zID8/IFtdKS5zbGljZSgwLCA1KS5tYXAoKHIpID0+ICh7XG4gICAgICAgICAgICBpZDogci5pZCxcbiAgICAgICAgICAgIHRpdGxlOiByLmxhYmVsLFxuICAgICAgICAgICAgY2hhbm5lbDogXCJmYWN0b3J5XCIsXG4gICAgICAgICAgICBtZXNzYWdlQ291bnQ6IHIudG9vbENvdW50LFxuICAgICAgICAgIH0pKSxcbiAgICAgICAgXTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNldFNlbGVjdGVkVGhyZWFkSWQobnVsbCk7XG4gICAgc2V0U2Vzc2lvbklkKG1vZGUgPT09IFwib3BlcmF0b3JcIiA/IFwibmV3XCIgOiBcImRlZmF1bHRcIik7XG4gICAgc2V0TWVzc2FnZXMoW10pO1xuICAgIHNldFN1Ym1pdEVycm9yKG51bGwpO1xuICB9LCBbbW9kZSwgcHJvamVjdElkXSk7XG5cbiAgY29uc3QgcmVuZGVyZWRNZXNzYWdlczogQ2hhdEl0ZW1bXSA9XG4gICAgbW9kZSA9PT0gXCJvcGVyYXRvclwiXG4gICAgICA/IFtcbiAgICAgICAgICAuLi4oY2hhdFNlc3Npb24/Lm1lc3NhZ2VzID8/IFtdKS5tYXAoKG1lc3NhZ2UpOiBDaGF0SXRlbSA9PlxuICAgICAgICAgICAgbWVzc2FnZS5zZW5kZXJUeXBlID09PSBcIkhVTUFOXCJcbiAgICAgICAgICAgICAgPyB7IGtpbmQ6IFwidXNlclwiLCB0ZXh0OiBtZXNzYWdlLmNvbnRlbnQgfVxuICAgICAgICAgICAgICA6IHtcbiAgICAgICAgICAgICAgICAgIGtpbmQ6IFwidHVyblwiLFxuICAgICAgICAgICAgICAgICAgdHVybjoge1xuICAgICAgICAgICAgICAgICAgICByZXBseTogbWVzc2FnZS5jb250ZW50LFxuICAgICAgICAgICAgICAgICAgICBnYXRlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgZGVjaXNpb246IFwiYWxsb3dcIixcbiAgICAgICAgICAgICAgICAgICAgICByZWFzb246IFwiUGVyc2lzdGVkIE1pc3Npb24gQ29udHJvbCB3b3JrIHJlY29yZFwiLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBsYXRlbmN5TXM6IDAsXG4gICAgICAgICAgICAgICAgICAgIGl0ZXJhdGlvbnM6IDEsXG4gICAgICAgICAgICAgICAgICAgIGNvc3Q6IDAsXG4gICAgICAgICAgICAgICAgICAgIG1vZGVsOiBcIm1pc3Npb24tY29udHJvbFwiLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgKSxcbiAgICAgICAgICAuLi5tZXNzYWdlcy5maWx0ZXIoKG1lc3NhZ2UpID0+IG1lc3NhZ2Uua2luZCA9PT0gXCJzdHJlYW1pbmdcIiksXG4gICAgICAgIF1cbiAgICAgIDogbWVzc2FnZXM7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsb2dSZWYuY3VycmVudD8uc2Nyb2xsVG8oeyB0b3A6IGxvZ1JlZi5jdXJyZW50LnNjcm9sbEhlaWdodCB9KTtcbiAgfSwgW3JlbmRlcmVkTWVzc2FnZXMubGVuZ3RoLCBwZW5kaW5nXSk7XG5cbiAgY29uc3QgZmFjdG9yeVJlcGx5ID0gdXNlQ2FsbGJhY2soXG4gICAgYXN5bmMgKHRleHQ6IHN0cmluZywgc3RhcnRlZEF0OiBudW1iZXIpID0+IHtcbiAgICAgIGNvbnN0IGxvd2VyID0gdGV4dC50b0xvd2VyQ2FzZSgpO1xuICAgICAgaWYgKGxvd2VyLmluY2x1ZGVzKFwibWV0YSBsb29wXCIpIHx8IGxvd2VyLmluY2x1ZGVzKFwic3VnZ2VzdGlvblwiKSkge1xuICAgICAgICBhd2FpdCBzZWVkTWV0YUxvb3AoeyBwcm9qZWN0SWQ6IHByb2plY3RJZCA/PyB1bmRlZmluZWQgfSk7XG4gICAgICAgIG9uTmF2aWdhdGU/LihcImhhcm5lc3MtbWV0YS1sb29wXCIpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHJlcGx5OiBcIlNlZWRlZCBtZXRhIGxvb3AgaW5ib3ggd2l0aCBvYnNlcnZlZCBmYWlsdXJlIHBhdHRlcm5zLiBPcGVuaW5nIG1ldGEgbG9vcC5cIixcbiAgICAgICAgICBnYXRlOiB7IGRlY2lzaW9uOiBcImFsbG93XCIgYXMgY29uc3QsIHJlYXNvbjogXCJmYWN0b3J5IGFnZW50IOKAlCBtZXRhIGxvb3BcIiB9LFxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgaWYgKGxvd2VyLmluY2x1ZGVzKFwiY29kZSByZXZpZXdcIikgfHwgbG93ZXIuaW5jbHVkZXMoXCJyZXZpZXcgd2l6YXJkXCIpKSB7XG4gICAgICAgIG9uTmF2aWdhdGU/LihcImhhcm5lc3MtY29kZS1yZXZpZXctd2l6YXJkXCIpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHJlcGx5OiBcIk9wZW5pbmcgdGhlIGZhY3RvcnktZmlyc3QgY29kZSByZXZpZXcgd2l6YXJkLiBTdGFydCB3aXRoIHZlcmlmaWVycywgdGhlbiBQUiBsZW5zZXMuXCIsXG4gICAgICAgICAgZ2F0ZTogeyBkZWNpc2lvbjogXCJhbGxvd1wiIGFzIGNvbnN0LCByZWFzb246IFwiZmFjdG9yeSBhZ2VudCDigJQgY29kZSByZXZpZXdcIiB9LFxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgaWYgKGxvd2VyLmluY2x1ZGVzKFwicHJcIikgfHwgbG93ZXIuaW5jbHVkZXMoXCJjaGFuZ2UgcmV2aWV3XCIpIHx8IGxvd2VyLmluY2x1ZGVzKFwibXV0YXRpb25cIikpIHtcbiAgICAgICAgb25OYXZpZ2F0ZT8uKFwiaGFybmVzcy1jaGFuZ2UtcmV2aWV3XCIpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHJlcGx5OiBcIk5hdmlnYXRlIHRvIENoYW5nZSBSZXZpZXcgdG8gc3luYyBQUi9DSSBkYXRhIGFuZCBtdXRhdGlvbiB0ZXN0aW5nIHJlcG9ydHMuXCIsXG4gICAgICAgICAgZ2F0ZTogeyBkZWNpc2lvbjogXCJhbGxvd1wiIGFzIGNvbnN0LCByZWFzb246IFwiZmFjdG9yeSBhZ2VudCDigJQgUFIgY2hlY2tzXCIgfSxcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGlmIChsb3dlci5pbmNsdWRlcyhcImFuYWx5emVcIikgfHwgbG93ZXIuaW5jbHVkZXMoXCJnaXRodWJcIikgfHwgbG93ZXIuaW5jbHVkZXMoXCJza2lsbFwiKSkge1xuICAgICAgICBvbk5hdmlnYXRlPy4oXCJza2lsbHNcIik7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgcmVwbHk6IFwiT3BlbiBSZWdpc3RyeSDihpIgRXZhbHVhdGUgdG8gYW5hbHl6ZSBhIHB1YmxpYyBHaXRIdWIgcmVwbyBmb3IgU0tJTEwubWQgZmlsZXMuXCIsXG4gICAgICAgICAgZ2F0ZTogeyBkZWNpc2lvbjogXCJhbGxvd1wiIGFzIGNvbnN0LCByZWFzb246IFwiZmFjdG9yeSBhZ2VudCDigJQgcmVnaXN0cnkgYW5hbHl6ZVwiIH0sXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBpZiAobG93ZXIuaW5jbHVkZXMoXCJoZWFsdGhcIikgfHwgbG93ZXIuaW5jbHVkZXMoXCJtYXR1cml0eVwiKSkge1xuICAgICAgICBvbk5hdmlnYXRlPy4oXCJoYXJuZXNzLWhlYWx0aFwiKTtcbiAgICAgICAgY29uc3Qgc3RhZ2UgPSBmYWN0b3J5SGVhbHRoPy5tYXR1cml0eVN0YWdlID8/IFwidW5rbm93blwiO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHJlcGx5OiBgRmFjdG9yeSBtYXR1cml0eTogJHtzdGFnZX0uIE9wZW5pbmcgaGVhbHRoIGRhc2hib2FyZCBmb3IgbG9vcCBjb3ZlcmFnZSBhbmQgbGVkZ2VyIHNpZ25hbHMuYCxcbiAgICAgICAgICBnYXRlOiB7IGRlY2lzaW9uOiBcImFsbG93XCIgYXMgY29uc3QsIHJlYXNvbjogXCJmYWN0b3J5IGFnZW50IOKAlCBoZWFsdGhcIiB9LFxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgaWYgKGxvd2VyLmluY2x1ZGVzKFwiZGVsZWdhdGVcIikgfHwgbG93ZXIuaW5jbHVkZXMoXCJhdXRvbWF0ZVwiKSkge1xuICAgICAgICBvbk5hdmlnYXRlPy4oXCJoYXJuZXNzLWxhdW5jaFwiKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICByZXBseTogXCJVc2UgTGF1bmNoIHRvIHNjaGVkdWxlIHJlY3VycmluZyBvdXRlci1sb29wIHdvcmtmbG93cyBvbmNlIHN1Y2Nlc3MgcmF0ZSBpcyBoaWdoLlwiLFxuICAgICAgICAgIGdhdGU6IHsgZGVjaXNpb246IFwiYWxsb3dcIiBhcyBjb25zdCwgcmVhc29uOiBcImZhY3RvcnkgYWdlbnQg4oCUIGRlbGVnYXRpb25cIiB9LFxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgcmVwbHk6IGBGYWN0b3J5IEFnZW50IHJlYWR5LiBUcnk6IFwic3luYyBQUiBjaGVja3NcIiwgXCJzZXQgdXAgY29kZSByZXZpZXdcIiwgXCJvcGVuIG1ldGEgbG9vcFwiLCBvciBcImFuYWx5emUgZ2l0aHViIHNraWxsc1wiLiBDdXJyZW50IHByb2plY3Q6ICR7cHJvamVjdElkID8gXCJzY29wZWRcIiA6IFwiYWxsIHByb2plY3RzXCJ9LmAsXG4gICAgICAgIGdhdGU6IHsgZGVjaXNpb246IFwic2tpcFwiIGFzIGNvbnN0LCByZWFzb246IFwiZmFjdG9yeSBhZ2VudCDigJQgZ2VuZXJhbCByb3V0aW5nXCIgfSxcbiAgICAgIH07XG4gICAgfSxcbiAgICBbZmFjdG9yeUhlYWx0aD8ubWF0dXJpdHlTdGFnZSwgb25OYXZpZ2F0ZSwgcHJvamVjdElkLCBzZWVkTWV0YUxvb3BdXG4gICk7XG5cbiAgY29uc3Qgc2VuZCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBjb25zdCB0ZXh0ID0gaW5wdXQudHJpbSgpO1xuICAgIGlmICghdGV4dCB8fCBwZW5kaW5nKSByZXR1cm47XG4gICAgc2V0U3VibWl0RXJyb3IobnVsbCk7XG4gICAgc2V0SW5wdXQoXCJcIik7XG4gICAgaWYgKG1vZGUgPT09IFwiZmFjdG9yeVwiKSB7XG4gICAgICBzZXRNZXNzYWdlcygobSkgPT4gWy4uLm0sIHsga2luZDogXCJ1c2VyXCIsIHRleHQgfV0pO1xuICAgIH1cbiAgICBzZXRQZW5kaW5nKHRydWUpO1xuICAgIGNvbnN0IHN0YXJ0ZWRBdCA9IERhdGUubm93KCk7XG4gICAgc2V0TWVzc2FnZXMoKG0pID0+IFtcbiAgICAgIC4uLm0sXG4gICAgICB7IGtpbmQ6IFwic3RyZWFtaW5nXCIsIHBlbmRpbmc6IHRydWUsIHN0cmVhbTogXCJcIiwgc3RhcnRlZEF0IH0sXG4gICAgXSk7XG5cbiAgICBjb25zdCBmaW5pc2ggPSAodHVybjogVHVybkNhcmREYXRhKSA9PiB7XG4gICAgICBzZXRQZW5kaW5nKGZhbHNlKTtcbiAgICAgIHNldE1lc3NhZ2VzKChtKSA9PiB7XG4gICAgICAgIGNvbnN0IHdpdGhvdXRTdHJlYW0gPSBtLmZpbHRlcigoeCkgPT4geC5raW5kICE9PSBcInN0cmVhbWluZ1wiKTtcbiAgICAgICAgcmV0dXJuIFsuLi53aXRob3V0U3RyZWFtLCB7IGtpbmQ6IFwidHVyblwiLCB0dXJuIH1dO1xuICAgICAgfSk7XG4gICAgfTtcblxuICAgIGlmIChtb2RlID09PSBcImZhY3RvcnlcIikge1xuICAgICAgdm9pZCBmYWN0b3J5UmVwbHkodGV4dCwgc3RhcnRlZEF0KVxuICAgICAgICAudGhlbigoeyByZXBseSwgZ2F0ZSB9KSA9PiB7XG4gICAgICAgICAgZmluaXNoKHtcbiAgICAgICAgICAgIHJlcGx5LFxuICAgICAgICAgICAgZ2F0ZSxcbiAgICAgICAgICAgIGxhdGVuY3lNczogRGF0ZS5ub3coKSAtIHN0YXJ0ZWRBdCxcbiAgICAgICAgICAgIGl0ZXJhdGlvbnM6IDEsXG4gICAgICAgICAgICBjb3N0OiAwLjAwNCxcbiAgICAgICAgICAgIG1vZGVsOiBcImZhY3RvcnktYWdlbnQtcm91dGVyXCIsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pXG4gICAgICAgIC5jYXRjaCgoZXJyb3IpID0+IHtcbiAgICAgICAgICBzZXRQZW5kaW5nKGZhbHNlKTtcbiAgICAgICAgICBzZXRNZXNzYWdlcygoY3VycmVudCkgPT4gY3VycmVudC5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0ua2luZCAhPT0gXCJzdHJlYW1pbmdcIikpO1xuICAgICAgICAgIHNldFN1Ym1pdEVycm9yKGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJGYWN0b3J5IHJvdXRpbmcgZmFpbGVkLlwiKTtcbiAgICAgICAgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKCFwcm9qZWN0SWQpIHtcbiAgICAgIHNldFBlbmRpbmcoZmFsc2UpO1xuICAgICAgc2V0TWVzc2FnZXMoW10pO1xuICAgICAgc2V0U3VibWl0RXJyb3IoXCJTZWxlY3QgYSB3b3Jrc3BhY2UgYmVmb3JlIHN1Ym1pdHRpbmcgd29yay5cIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHZvaWQgc3VibWl0Q2hhdFJlcXVlc3Qoe1xuICAgICAgcHJvamVjdElkLFxuICAgICAgdGhyZWFkSWQ6IHNlbGVjdGVkVGhyZWFkSWQgPz8gdW5kZWZpbmVkLFxuICAgICAgY29udGVudDogdGV4dCxcbiAgICAgIGFjdG9ySWQ6IFwib3BlcmF0b3JcIixcbiAgICAgIGlkZW1wb3RlbmN5S2V5OiBgbWlzc2lvbi1jaGF0OiR7cHJvamVjdElkfToke3N0YXJ0ZWRBdH1gLFxuICAgIH0pXG4gICAgICAudGhlbigocmVzdWx0KSA9PiB7XG4gICAgICAgIHNldFNlbGVjdGVkVGhyZWFkSWQocmVzdWx0LnRocmVhZElkKTtcbiAgICAgICAgc2V0U2Vzc2lvbklkKHJlc3VsdC50aHJlYWRJZCk7XG4gICAgICAgIHNldE1lc3NhZ2VzKFtdKTtcbiAgICAgICAgc2V0UGVuZGluZyhmYWxzZSk7XG4gICAgICB9KVxuICAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xuICAgICAgICBzZXRQZW5kaW5nKGZhbHNlKTtcbiAgICAgICAgc2V0TWVzc2FnZXMoW10pO1xuICAgICAgICBzZXRTdWJtaXRFcnJvcihcbiAgICAgICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiTWlzc2lvbiBDb250cm9sIGNvdWxkIG5vdCBjcmVhdGUgdGhlIHdvcmsuXCJcbiAgICAgICAgKTtcbiAgICAgIH0pO1xuICB9LCBbXG4gICAgZmFjdG9yeVJlcGx5LFxuICAgIGlucHV0LFxuICAgIG1vZGUsXG4gICAgcGVuZGluZyxcbiAgICBwcm9qZWN0SWQsXG4gICAgc2VsZWN0ZWRUaHJlYWRJZCxcbiAgICBzdWJtaXRDaGF0UmVxdWVzdCxcbiAgXSk7XG5cbiAgY29uc3Qgb25LZXlEb3duID0gKGU6IFJlYWN0LktleWJvYXJkRXZlbnQpID0+IHtcbiAgICBpZiAoZS5rZXkgPT09IFwiRW50ZXJcIiAmJiAhZS5zaGlmdEtleSkge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgc2VuZCgpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxhc2lkZVxuICAgICAgY2xhc3NOYW1lPVwiZmxleCBoLWZ1bGwgc2hyaW5rLTAgZmxleC1jb2wgYm9yZGVyLWwgYm9yZGVyLWxpbmUgYmctcmFpbFwiXG4gICAgICBzdHlsZT17eyB3aWR0aCB9fVxuICAgICAgYXJpYS1sYWJlbD1cIkNoYXQgZG9ja1wiXG4gICAgPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNocmluay0wIGl0ZW1zLWNlbnRlciBnYXAtMiBib3JkZXItYiBib3JkZXItbGluZSBweC0zIHB5LTIuNVwiPlxuICAgICAgICA8TWVzc2FnZVNxdWFyZSBzaXplPXsxNH0gY2xhc3NOYW1lPVwidGV4dC1pbmstbXV0ZWRcIiBhcmlhLWhpZGRlbiAvPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+Q2hhdDwvc3Bhbj5cbiAgICAgICAge2FyY2hTdGF0dXMgPyAoXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2NoZW1hdGljLWFyY2gtc3RhdHVzIG1sLTEgdHJ1bmNhdGVcIj57YXJjaFN0YXR1c308L3NwYW4+XG4gICAgICAgICkgOiBudWxsfVxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJtbC1hdXRvIHJvdW5kZWQgcC0xIHRleHQtaW5rLW11dGVkIGhvdmVyOnRleHQtaW5rXCJcbiAgICAgICAgICB0aXRsZT1cIkNvbGxhcHNlIGNoYXRcIlxuICAgICAgICA+XG4gICAgICAgICAgPENoZXZyb25SaWdodCBzaXplPXsxNn0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNocmluay0wIGdhcC0xIGJvcmRlci1iIGJvcmRlci1saW5lIHB4LTMgcHktMlwiPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TW9kZShcIm9wZXJhdG9yXCIpfVxuICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICBcImZsZXggZmxleC0xIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMSByb3VuZGVkLW1kIHB4LTIgcHktMS41IHRleHQtWzExcHhdIGZvbnQtbWVkaXVtXCIsXG4gICAgICAgICAgICBtb2RlID09PSBcIm9wZXJhdG9yXCIgPyBcImJnLXN1cmZhY2UtMiB0ZXh0LWlua1wiIDogXCJ0ZXh0LWluay1tdXRlZCBob3Zlcjp0ZXh0LWlua1wiXG4gICAgICAgICAgKX1cbiAgICAgICAgPlxuICAgICAgICAgIDxVc2VyIHNpemU9ezEyfSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgIE9wZXJhdG9yXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TW9kZShcImZhY3RvcnlcIil9XG4gICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgIFwiZmxleCBmbGV4LTEgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xIHJvdW5kZWQtbWQgcHgtMiBweS0xLjUgdGV4dC1bMTFweF0gZm9udC1tZWRpdW1cIixcbiAgICAgICAgICAgIG1vZGUgPT09IFwiZmFjdG9yeVwiID8gXCJiZy1zdXJmYWNlLTIgdGV4dC1yZWdpc3RyeS1hY2NlbnRcIiA6IFwidGV4dC1pbmstbXV0ZWQgaG92ZXI6dGV4dC1pbmtcIlxuICAgICAgICAgICl9XG4gICAgICAgID5cbiAgICAgICAgICA8RmFjdG9yeSBzaXplPXsxMn0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICBGYWN0b3J5IEFnZW50XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxDaGF0U2Vzc2lvbkJhclxuICAgICAgICBzZXNzaW9ucz17c2Vzc2lvbnN9XG4gICAgICAgIGFjdGl2ZVNlc3Npb25JZD17c2Vzc2lvbklkfVxuICAgICAgICBvbk5ld0NoYXQ9eygpID0+IHtcbiAgICAgICAgICBzZXRTZXNzaW9uSWQobW9kZSA9PT0gXCJvcGVyYXRvclwiID8gXCJuZXdcIiA6IGBzZXNzaW9uLSR7RGF0ZS5ub3coKX1gKTtcbiAgICAgICAgICBzZXRTZWxlY3RlZFRocmVhZElkKG51bGwpO1xuICAgICAgICAgIHNldE1lc3NhZ2VzKFtdKTtcbiAgICAgICAgICBzZXRTdWJtaXRFcnJvcihudWxsKTtcbiAgICAgICAgfX1cbiAgICAgICAgb25TZWxlY3RTZXNzaW9uPXsobmV4dFNlc3Npb25JZCkgPT4ge1xuICAgICAgICAgIHNldFNlc3Npb25JZChuZXh0U2Vzc2lvbklkKTtcbiAgICAgICAgICBpZiAobW9kZSA9PT0gXCJvcGVyYXRvclwiKSB7XG4gICAgICAgICAgICBjb25zdCB0aHJlYWQgPSAoY2hhdFRocmVhZHMgPz8gW10pLmZpbmQoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLl9pZCA9PT0gbmV4dFNlc3Npb25JZCk7XG4gICAgICAgICAgICBzZXRTZWxlY3RlZFRocmVhZElkKHRocmVhZD8uX2lkID8/IG51bGwpO1xuICAgICAgICAgIH1cbiAgICAgICAgfX1cbiAgICAgICAgb25WaWV3QWxsSGlzdG9yeT17KCkgPT4ge1xuICAgICAgICAgIGNvbnN0IGZpcnN0ID0gY2hhdFRocmVhZHM/LlswXTtcbiAgICAgICAgICBpZiAobW9kZSA9PT0gXCJvcGVyYXRvclwiICYmIGZpcnN0KSB7XG4gICAgICAgICAgICBzZXRTZXNzaW9uSWQoZmlyc3QuX2lkKTtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkVGhyZWFkSWQoZmlyc3QuX2lkKTtcbiAgICAgICAgICB9XG4gICAgICAgIH19XG4gICAgICAgIG1vZGVsTGFiZWw9e21vZGUgPT09IFwiZmFjdG9yeVwiID8gXCJmYWN0b3J5LWFnZW50XCIgOiBcImZhY3Rvcnktcm91dGVyXCJ9XG4gICAgICAvPlxuXG4gICAgICB7bW9kZSA9PT0gXCJvcGVyYXRvclwiICYmIGNoYXRTZXNzaW9uPy50YXNrICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaHJpbmstMCBib3JkZXItYiBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgcHgtMyBweS0yIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGU/LihcInRhc2tzXCIpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0cnVuY2F0ZSBmb250LW1lZGl1bSB0ZXh0LWluayBob3Zlcjp1bmRlcmxpbmVcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7Y2hhdFNlc3Npb24udGFzay5pZGVudGlmaWVyID8/IGNoYXRTZXNzaW9uLnRhc2sudGl0bGV9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJvdW5kZWQgYm9yZGVyIGJvcmRlci1saW5lIHB4LTEuNSBweS0wLjUgdGV4dC1pbmstc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgIHtjaGF0U2Vzc2lvbi50YXNrLnN0YXR1cy5yZXBsYWNlKC9fL2csIFwiIFwiKX1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICB7Y2hhdFNlc3Npb24ud29ya09yZGVyICYmIChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGU/LihcImNvbnRyb2wtd29yay1vcmRlcnNcIil9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1pbmstbXV0ZWQgaG92ZXI6dGV4dC1pbmsgaG92ZXI6dW5kZXJsaW5lXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgV29ya09yZGVyIMK3IHtjaGF0U2Vzc2lvbi53b3JrT3JkZXIuc3RhdGUucmVwbGFjZSgvXy9nLCBcIiBcIil9XG4gICAgICAgICAgICAgIHtjaGF0U2Vzc2lvbi53b3JrZmxvd1J1biA/IGAgwrcgUnVuICR7Y2hhdFNlc3Npb24ud29ya2Zsb3dSdW4uc3RhdHVzfWAgOiBcIlwifVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7bW9kZSA9PT0gXCJmYWN0b3J5XCIgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBzaHJpbmstMCBmbGV4LXdyYXAgZ2FwLTEuNSBib3JkZXItYiBib3JkZXItbGluZSBweC0zIHB5LTJcIj5cbiAgICAgICAgICB7RkFDVE9SWV9QUk9NUFRTLm1hcCgocCkgPT4gKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBrZXk9e3Audmlld31cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICBvbk5hdmlnYXRlPy4ocC52aWV3KTtcbiAgICAgICAgICAgICAgICBzZXRJbnB1dChwLmxhYmVsKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgcHgtMi41IHB5LTEgdGV4dC1bMTBweF0gdGV4dC1pbmstc2Vjb25kYXJ5IGhvdmVyOmJvcmRlci1yZWdpc3RyeS1hY2NlbnQvNDAgaG92ZXI6dGV4dC1pbmtcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7cC5sYWJlbH1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiBudWxsfVxuXG4gICAgICA8ZGl2IHJlZj17bG9nUmVmfSBjbGFzc05hbWU9XCJzY2hlbWF0aWMtY2hhdGxvZyBtaW4taC0wIGZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcHgtMyBwYi0yXCI+XG4gICAgICAgIHtyZW5kZXJlZE1lc3NhZ2VzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJweC0wLjUgcHktMiB0ZXh0LVsxM3B4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAge21vZGUgPT09IFwiZmFjdG9yeVwiXG4gICAgICAgICAgICAgID8gXCJGYWN0b3J5IEFnZW50IHJvdXRlcyBoYXJuZXNzIHdvcms6IGNvZGUgcmV2aWV3IHNldHVwLCBQUiBzeW5jLCBtZXRhIGxvb3AsIGFuZCByZWdpc3RyeSBhbmFseXplLlwiXG4gICAgICAgICAgICAgIDogXCJNZXNzYWdlIE1pc3Npb24gQ29udHJvbCBmcm9tIGFueSB0YWIuIE9wZW4gT3ZlcnZpZXcgdG8gd2F0Y2ggZmFjdG9yeSBmbG93LCBvciBHYXRld2F5IGZvciBjaGFubmVsIGNvbnZlcnNhdGlvbnMuXCJ9XG4gICAgICAgICAgPC9wPlxuICAgICAgICApIDogKFxuICAgICAgICAgIHJlbmRlcmVkTWVzc2FnZXMubWFwKChtLCBpZHgpID0+IHtcbiAgICAgICAgICAgIGlmIChtLmtpbmQgPT09IFwidXNlclwiKSByZXR1cm4gPENoYXRCdWJibGUga2V5PXtpZHh9IHRleHQ9e20udGV4dH0gLz47XG4gICAgICAgICAgICBpZiAobS5raW5kID09PSBcInN0cmVhbWluZ1wiKVxuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxTdHJlYW1pbmdUdXJuQ2FyZFxuICAgICAgICAgICAgICAgICAga2V5PXtpZHh9XG4gICAgICAgICAgICAgICAgICB0dXJuPXt7XG4gICAgICAgICAgICAgICAgICAgIHBlbmRpbmc6IG0ucGVuZGluZyxcbiAgICAgICAgICAgICAgICAgICAgc3RyZWFtOiBtLnN0cmVhbSxcbiAgICAgICAgICAgICAgICAgICAgc3RhcnRlZEF0OiBtLnN0YXJ0ZWRBdCxcbiAgICAgICAgICAgICAgICAgICAgZ2F0ZTogbS5zdHJlYW0/LmluY2x1ZGVzKFwiZ2F0ZVwiKVxuICAgICAgICAgICAgICAgICAgICAgID8geyBkZWNpc2lvbjogXCJza2lwXCIsIHJlYXNvbjogXCJldmFsdWF0aW5nIHJldHJpZXZhbCBuZWVkXCIgfVxuICAgICAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgcmV0dXJuIDxUdXJuQ2FyZCBrZXk9e2lkeH0gdHVybj17bS50dXJufSAvPjtcbiAgICAgICAgICB9KVxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHtzdWJtaXRFcnJvciAmJiAoXG4gICAgICAgIDxkaXYgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwic2hyaW5rLTAgYm9yZGVyLXQgYm9yZGVyLWVyci8zMCBiZy1lcnItc29mdCBweC0zIHB5LTIgdGV4dC14cyB0ZXh0LWVyclwiPlxuICAgICAgICAgIHtzdWJtaXRFcnJvcn1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggc2hyaW5rLTAgaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlci10IGJvcmRlci1saW5lIHB4LTMgcHktMi41XCI+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIGlkPVwiZG9jay1tc2dcIlxuICAgICAgICAgIHZhbHVlPXtpbnB1dH1cbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldElucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICBvbktleURvd249e29uS2V5RG93bn1cbiAgICAgICAgICBwbGFjZWhvbGRlcj17XG4gICAgICAgICAgICBtb2RlID09PSBcImZhY3RvcnlcIlxuICAgICAgICAgICAgICA/IFwiQXNrIEZhY3RvcnkgQWdlbnQgdG8gcm91dGUgaGFybmVzcyB3b3Jr4oCmXCJcbiAgICAgICAgICAgICAgOiBcIk1lc3NhZ2UgTWlzc2lvbiBDb250cm9s4oCmXCJcbiAgICAgICAgICB9XG4gICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgcHgtMyBweS0yIHRleHQtWzEzcHhdIHRleHQtaW5rIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItc2NoZW1hdGljLWFjY2VudFwiXG4gICAgICAgIC8+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIHAtMiB0ZXh0LWluay1tdXRlZCBob3Zlcjp0ZXh0LWlua1wiXG4gICAgICAgICAgdGl0bGU9XCJWb2ljZSBpbnB1dCAoY29taW5nIHNvb24pXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxNaWMgc2l6ZT17MTV9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgb25DbGljaz17c2VuZH1cbiAgICAgICAgICBkaXNhYmxlZD17cGVuZGluZyB8fCAhaW5wdXQudHJpbSgpfVxuICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICBcImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHJvdW5kZWQtbGcgYmctc2NoZW1hdGljLWFjY2VudCBweC0zIHB5LTIgdGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlXCIsXG4gICAgICAgICAgICBcImRpc2FibGVkOm9wYWNpdHktNDBcIlxuICAgICAgICAgICl9XG4gICAgICAgID5cbiAgICAgICAgICA8U2VuZCBzaXplPXsxNH0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICBTZW5kXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9hc2lkZT5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL3NoZWxsVjIvQ2hhdERvY2sudHN4In0=