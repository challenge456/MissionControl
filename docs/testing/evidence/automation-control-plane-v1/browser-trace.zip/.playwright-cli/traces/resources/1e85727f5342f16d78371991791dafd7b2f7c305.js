import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/QuotaFuelGauge.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { useQuery, useMutation } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "/src/components/ui/dialog.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
import { cn } from "/src/lib/utils.ts";
import { Gauge, RefreshCw, Zap } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
const PROVIDERS = ["anthropic", "openai", "google"];
function formatCountdown(resetAt) {
  const now = Date.now();
  if (resetAt <= now) return "Resets soon";
  const d = Math.floor((resetAt - now) / 864e5);
  const h = Math.floor((resetAt - now) % 864e5 / 36e5);
  const m = Math.floor((resetAt - now) % 36e5 / 6e4);
  if (d > 0) return `Resets in ${d}d ${h}h ${m}m`;
  if (h > 0) return `Resets in ${h}h ${m}m`;
  return `Resets in ${m}m`;
}
function gaugeTextClass(pct) {
  if (pct >= 80) return "text-err";
  if (pct >= 60) return "text-warn";
  return "text-ok";
}
function gaugeBarClass(pct) {
  if (pct >= 80) return "bg-err";
  if (pct >= 60) return "bg-warn";
  return "bg-ok";
}
function QuotaBar({ value }) {
  const pct = Math.max(0, Math.min(100, value));
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "relative h-2 w-full overflow-hidden rounded-full bg-surface-2",
      role: "progressbar",
      "aria-valuenow": Math.round(pct),
      "aria-valuemin": 0,
      "aria-valuemax": 100,
      "aria-label": "LLM quota used",
      children: [
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: cn("h-full rounded-full transition-[width] duration-200", gaugeBarClass(pct)),
            style: { width: `${pct}%` }
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
            lineNumber: 86,
            columnNumber: 7
          },
          this
        ),
        [60, 80].map(
          (tick) => /* @__PURE__ */ jsxDEV(
            "span",
            {
              className: "absolute inset-y-0 w-px bg-line-strong",
              style: { left: `${tick}%` },
              "aria-hidden": true
            },
            tick,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
              lineNumber: 91,
              columnNumber: 7
            },
            this
          )
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
      lineNumber: 78,
      columnNumber: 5
    },
    this
  );
}
_c = QuotaBar;
export function QuotaFuelGauge({ compact = false, className }) {
  _s();
  const [updateOpen, setUpdateOpen] = useState(false);
  const [updateUsagePct, setUpdateUsagePct] = useState("");
  const [updateResetAt, setUpdateResetAt] = useState("");
  const [updateProvider, setUpdateProvider] = useState("anthropic");
  const [updatePlanTier, setUpdatePlanTier] = useState("claude_max_200");
  const [updateTokensUsed, setUpdateTokensUsed] = useState("");
  const [updateTokensLimit, setUpdateTokensLimit] = useState("");
  const snapshot = useQuery(api.quotaTracking.getLatestSnapshot, {});
  const projected = useQuery(api.quotaTracking.getProjectedBurnRate, {});
  const upsert = useMutation(api.quotaTracking.upsertQuotaSnapshot);
  const handleUpdate = async () => {
    const pct = Number(updateUsagePct);
    if (!Number.isFinite(pct) || pct < 0 || pct > 100) return;
    let resetAt = Date.now() + 7 * 86400 * 1e3;
    if (updateResetAt.trim()) {
      const parsed = Date.parse(updateResetAt);
      if (!Number.isNaN(parsed)) resetAt = parsed;
    }
    const tokensUsed = updateTokensUsed.trim() ? Number(updateTokensUsed) : 0;
    const tokensLimit = updateTokensLimit.trim() ? Number(updateTokensLimit) : 1;
    try {
      await upsert({
        provider: updateProvider,
        planTier: updatePlanTier.trim() || "default",
        usagePct: pct,
        resetAt,
        tokensUsed,
        tokensLimit: tokensLimit || 1
      });
      setUpdateOpen(false);
      setUpdateUsagePct("");
      setUpdateResetAt("");
    } catch (e) {
      console.error(e);
    }
  };
  if (compact) {
    const pct = snapshot?.usagePct ?? 0;
    return /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setUpdateOpen(true),
          className: cn(
            "flex items-center gap-1.5 rounded-md border border-line px-2 py-1 text-xs text-ink-secondary transition-colors duration-150 hover:border-line-strong hover:text-ink",
            className
          ),
          title: snapshot ? `Quota ${pct.toFixed(0)}% · ${formatCountdown(snapshot.resetAt)}` : "Update quota",
          children: [
            /* @__PURE__ */ jsxDEV(Gauge, { className: cn("h-3.5 w-3.5", snapshot ? gaugeTextClass(pct) : "text-ink-muted"), strokeWidth: 1.75 }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
              lineNumber: 161,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium tabular-nums", children: snapshot ? `${pct.toFixed(0)}%` : "—" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
              lineNumber: 162,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
          lineNumber: 152,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        UpdateQuotaDialog,
        {
          open: updateOpen,
          onOpenChange: setUpdateOpen,
          provider: updateProvider,
          setProvider: setUpdateProvider,
          planTier: updatePlanTier,
          setPlanTier: setUpdatePlanTier,
          usagePct: updateUsagePct,
          setUsagePct: setUpdateUsagePct,
          resetAt: updateResetAt,
          setResetAt: setUpdateResetAt,
          tokensUsed: updateTokensUsed,
          setTokensUsed: setUpdateTokensUsed,
          tokensLimit: updateTokensLimit,
          setTokensLimit: setUpdateTokensLimit,
          onSave: handleUpdate
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
          lineNumber: 164,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
      lineNumber: 151,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: cn("rounded-xl border border-line bg-surface-1 p-4", className), children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex items-center justify-between gap-2", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2 text-[15px] font-semibold text-ink", children: [
        /* @__PURE__ */ jsxDEV(Gauge, { className: "h-4 w-4 text-ink-muted", strokeWidth: 1.75 }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
          lineNumber: 189,
          columnNumber: 11
        }, this),
        "LLM quota"
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
        lineNumber: 188,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "ghost", className: "h-7 text-xs", onClick: () => setUpdateOpen(true), children: [
        /* @__PURE__ */ jsxDEV(RefreshCw, { className: "h-3 w-3 mr-1" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
          lineNumber: 193,
          columnNumber: 11
        }, this),
        "Update"
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
        lineNumber: 192,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
      lineNumber: 187,
      columnNumber: 7
    }, this),
    !snapshot ? /* @__PURE__ */ jsxDEV("div", { className: "py-4 text-center text-[13px] text-ink-muted", children: "No quota data. Click Update and enter usage from your provider dashboard." }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
      lineNumber: 199,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-baseline justify-between gap-3", children: [
        /* @__PURE__ */ jsxDEV("p", { className: cn("text-[20px] font-semibold leading-none tabular-nums", gaugeTextClass(snapshot.usagePct)), children: [
          snapshot.usagePct.toFixed(1),
          "%"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
          lineNumber: 205,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-ink-muted", children: formatCountdown(snapshot.resetAt) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
          lineNumber: 208,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
        lineNumber: 204,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-2.5", children: /* @__PURE__ */ jsxDEV(QuotaBar, { value: snapshot.usagePct }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
        lineNumber: 211,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
        lineNumber: 210,
        columnNumber: 11
      }, this),
      projected && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-[12px] text-ink-muted", children: [
        "Burn rate: ~",
        projected.pctPerDay >= 0 ? projected.pctPerDay.toFixed(1) : "0",
        "% per day",
        projected.projectedAtReset < 100 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          " · Projected ",
          projected.projectedAtReset.toFixed(0),
          "% at reset"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
          lineNumber: 217,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
        lineNumber: 214,
        columnNumber: 9
      }, this),
      snapshot.usagePct < 60 && /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex items-center gap-2 text-[12px] text-ink-secondary", children: [
        /* @__PURE__ */ jsxDEV(Zap, { className: "h-3.5 w-3.5 text-ok", strokeWidth: 1.75 }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
          lineNumber: 223,
          columnNumber: 15
        }, this),
        "Available for background work — scheduler can run low-priority jobs."
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
        lineNumber: 222,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
      lineNumber: 203,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      UpdateQuotaDialog,
      {
        open: updateOpen,
        onOpenChange: setUpdateOpen,
        provider: updateProvider,
        setProvider: setUpdateProvider,
        planTier: updatePlanTier,
        setPlanTier: setUpdatePlanTier,
        usagePct: updateUsagePct,
        setUsagePct: setUpdateUsagePct,
        resetAt: updateResetAt,
        setResetAt: setUpdateResetAt,
        tokensUsed: updateTokensUsed,
        setTokensUsed: setUpdateTokensUsed,
        tokensLimit: updateTokensLimit,
        setTokensLimit: setUpdateTokensLimit,
        onSave: handleUpdate
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
        lineNumber: 230,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
    lineNumber: 186,
    columnNumber: 5
  }, this);
}
_s(QuotaFuelGauge, "uRUMVl+LJy2wV0nbXk/x3u3JDIc=", false, function() {
  return [useQuery, useQuery, useMutation];
});
_c2 = QuotaFuelGauge;
function UpdateQuotaDialog({
  open,
  onOpenChange,
  provider,
  setProvider,
  planTier,
  setPlanTier,
  usagePct,
  setUsagePct,
  resetAt,
  setResetAt,
  tokensUsed,
  setTokensUsed,
  tokensLimit,
  setTokensLimit,
  onSave
}) {
  return /* @__PURE__ */ jsxDEV(Dialog, { open, onOpenChange, children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "sm:max-w-sm", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Update quota" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
        lineNumber: 288,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Enter current usage from your provider dashboard (e.g. Claude usage page). Scheduler uses this for quota-aware runs." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
        lineNumber: 289,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
      lineNumber: 287,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid gap-3 py-2", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV(Label, { className: "text-xs", children: "Provider" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
          lineNumber: 295,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Select, { value: provider, onValueChange: (v) => setProvider(v), children: [
          /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-8", children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
            lineNumber: 297,
            columnNumber: 46
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
            lineNumber: 297,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(SelectContent, { children: PROVIDERS.map(
            (p) => /* @__PURE__ */ jsxDEV(SelectItem, { value: p, children: p }, p, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
              lineNumber: 300,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
            lineNumber: 298,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
          lineNumber: 296,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
        lineNumber: 294,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV(Label, { className: "text-xs", children: "Plan tier" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
          lineNumber: 306,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            value: planTier,
            onChange: (e) => setPlanTier(e.target.value),
            placeholder: "e.g. claude_max_200",
            className: "h-8"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
            lineNumber: 307,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
        lineNumber: 305,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV(Label, { className: "text-xs", children: "Usage % (0–100)" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
          lineNumber: 315,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            type: "number",
            min: 0,
            max: 100,
            value: usagePct,
            onChange: (e) => setUsagePct(e.target.value),
            placeholder: "e.g. 45",
            className: "h-8"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
            lineNumber: 316,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
        lineNumber: 314,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV(Label, { className: "text-xs", children: "Reset at (optional, ISO or date)" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
          lineNumber: 327,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            value: resetAt,
            onChange: (e) => setResetAt(e.target.value),
            placeholder: "e.g. Saturday 10pm or ISO date",
            className: "h-8"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
            lineNumber: 328,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
        lineNumber: 326,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(Label, { className: "text-xs", children: "Tokens used (optional)" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
            lineNumber: 337,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "number",
              value: tokensUsed,
              onChange: (e) => setTokensUsed(e.target.value),
              className: "h-8"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
              lineNumber: 338,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
          lineNumber: 336,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(Label, { className: "text-xs", children: "Tokens limit (optional)" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
            lineNumber: 346,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "number",
              value: tokensLimit,
              onChange: (e) => setTokensLimit(e.target.value),
              className: "h-8"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
              lineNumber: 347,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
          lineNumber: 345,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
        lineNumber: 335,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
      lineNumber: 293,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "outline", size: "sm", onClick: () => onOpenChange(false), children: "Cancel" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
        lineNumber: 357,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { size: "sm", onClick: onSave, children: "Save" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
        lineNumber: 358,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
      lineNumber: 356,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
    lineNumber: 286,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx",
    lineNumber: 285,
    columnNumber: 5
  }, this);
}
_c3 = UpdateQuotaDialog;
var _c, _c2, _c3;
$RefreshReg$(_c, "QuotaBar");
$RefreshReg$(_c2, "QuotaFuelGauge");
$RefreshReg$(_c3, "UpdateQuotaDialog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/QuotaFuelGauge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0VNLFNBaUVBLFVBakVBOzs7Ozs7Ozs7Ozs7Ozs7OztBQTdETixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsVUFBVUMsbUJBQW1CO0FBQ3RDLFNBQVNDLFdBQVc7QUFDcEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGFBQWE7QUFDdEI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1A7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxPQUFPQyxXQUFXQyxXQUFXO0FBRXRDLE1BQU1DLFlBQVksQ0FBQyxhQUFhLFVBQVUsUUFBUTtBQUVsRCxTQUFTQyxnQkFBZ0JDLFNBQXlCO0FBQ2hELFFBQU1DLE1BQU1DLEtBQUtELElBQUk7QUFDckIsTUFBSUQsV0FBV0MsSUFBSyxRQUFPO0FBQzNCLFFBQU1FLElBQUlDLEtBQUtDLE9BQU9MLFVBQVVDLE9BQU8sS0FBUTtBQUMvQyxRQUFNSyxJQUFJRixLQUFLQyxPQUFRTCxVQUFVQyxPQUFPLFFBQVksSUFBTztBQUMzRCxRQUFNTSxJQUFJSCxLQUFLQyxPQUFRTCxVQUFVQyxPQUFPLE9BQVcsR0FBSztBQUN4RCxNQUFJRSxJQUFJLEVBQUcsUUFBTyxhQUFhQSxDQUFDLEtBQUtHLENBQUMsS0FBS0MsQ0FBQztBQUM1QyxNQUFJRCxJQUFJLEVBQUcsUUFBTyxhQUFhQSxDQUFDLEtBQUtDLENBQUM7QUFDdEMsU0FBTyxhQUFhQSxDQUFDO0FBQ3ZCO0FBRUEsU0FBU0MsZUFBZUMsS0FBcUI7QUFDM0MsTUFBSUEsT0FBTyxHQUFJLFFBQU87QUFDdEIsTUFBSUEsT0FBTyxHQUFJLFFBQU87QUFDdEIsU0FBTztBQUNUO0FBRUEsU0FBU0MsY0FBY0QsS0FBcUI7QUFDMUMsTUFBSUEsT0FBTyxHQUFJLFFBQU87QUFDdEIsTUFBSUEsT0FBTyxHQUFJLFFBQU87QUFDdEIsU0FBTztBQUNUO0FBR0EsU0FBU0UsU0FBUyxFQUFFQyxNQUF5QixHQUFnQjtBQUMzRCxRQUFNSCxNQUFNTCxLQUFLUyxJQUFJLEdBQUdULEtBQUtVLElBQUksS0FBS0YsS0FBSyxDQUFDO0FBQzVDLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVU7QUFBQSxNQUNWLE1BQUs7QUFBQSxNQUNMLGlCQUFlUixLQUFLVyxNQUFNTixHQUFHO0FBQUEsTUFDN0IsaUJBQWU7QUFBQSxNQUNmLGlCQUFlO0FBQUEsTUFDZixjQUFXO0FBQUEsTUFFWDtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFXZixHQUFHLHVEQUF1RGdCLGNBQWNELEdBQUcsQ0FBQztBQUFBLFlBQ3ZGLE9BQU8sRUFBRU8sT0FBTyxHQUFHUCxHQUFHLElBQUk7QUFBQTtBQUFBLFVBRjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUU4QjtBQUFBLFFBRTdCLENBQUMsSUFBSSxFQUFFLEVBQUVRO0FBQUFBLFVBQUksQ0FBQ0MsU0FDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsV0FBVTtBQUFBLGNBQ1YsT0FBTyxFQUFFQyxNQUFNLEdBQUdELElBQUksSUFBSTtBQUFBLGNBQzFCLGVBQVc7QUFBQTtBQUFBLFlBSE5BO0FBQUFBLFlBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlhO0FBQUEsUUFFZDtBQUFBO0FBQUE7QUFBQSxJQW5CSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFvQkE7QUFFSjtBQUFDRSxLQXpCUVQ7QUFpQ0YsZ0JBQVNVLGVBQWUsRUFBRUMsVUFBVSxPQUFPQyxVQUErQixHQUFHO0FBQUFDLEtBQUE7QUFDbEYsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUlsRCxTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDbUQsZ0JBQWdCQyxpQkFBaUIsSUFBSXBELFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNxRCxlQUFlQyxnQkFBZ0IsSUFBSXRELFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUN1RCxnQkFBZ0JDLGlCQUFpQixJQUFJeEQsU0FBNEMsV0FBVztBQUNuRyxRQUFNLENBQUN5RCxnQkFBZ0JDLGlCQUFpQixJQUFJMUQsU0FBUyxnQkFBZ0I7QUFDckUsUUFBTSxDQUFDMkQsa0JBQWtCQyxtQkFBbUIsSUFBSTVELFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUM2RCxtQkFBbUJDLG9CQUFvQixJQUFJOUQsU0FBUyxFQUFFO0FBRTdELFFBQU0rRCxXQUFXOUQsU0FBU0UsSUFBSTZELGNBQWNDLG1CQUFtQixDQUFDLENBQUM7QUFDakUsUUFBTUMsWUFBWWpFLFNBQVNFLElBQUk2RCxjQUFjRyxzQkFBc0IsQ0FBQyxDQUFDO0FBQ3JFLFFBQU1DLFNBQVNsRSxZQUFZQyxJQUFJNkQsY0FBY0ssbUJBQW1CO0FBRWhFLFFBQU1DLGVBQWUsWUFBWTtBQUMvQixVQUFNckMsTUFBTXNDLE9BQU9wQixjQUFjO0FBQ2pDLFFBQUksQ0FBQ29CLE9BQU9DLFNBQVN2QyxHQUFHLEtBQUtBLE1BQU0sS0FBS0EsTUFBTSxJQUFLO0FBQ25ELFFBQUlULFVBQVVFLEtBQUtELElBQUksSUFBSSxJQUFJLFFBQVE7QUFDdkMsUUFBSTRCLGNBQWNvQixLQUFLLEdBQUc7QUFDeEIsWUFBTUMsU0FBU2hELEtBQUtpRCxNQUFNdEIsYUFBYTtBQUN2QyxVQUFJLENBQUNrQixPQUFPSyxNQUFNRixNQUFNLEVBQUdsRCxXQUFVa0Q7QUFBQUEsSUFDdkM7QUFDQSxVQUFNRyxhQUFhbEIsaUJBQWlCYyxLQUFLLElBQUlGLE9BQU9aLGdCQUFnQixJQUFJO0FBQ3hFLFVBQU1tQixjQUFjakIsa0JBQWtCWSxLQUFLLElBQUlGLE9BQU9WLGlCQUFpQixJQUFJO0FBQzNFLFFBQUk7QUFDRixZQUFNTyxPQUFPO0FBQUEsUUFDWFcsVUFBVXhCO0FBQUFBLFFBQ1Z5QixVQUFVdkIsZUFBZWdCLEtBQUssS0FBSztBQUFBLFFBQ25DUSxVQUFVaEQ7QUFBQUEsUUFDVlQ7QUFBQUEsUUFDQXFEO0FBQUFBLFFBQ0FDLGFBQWFBLGVBQWU7QUFBQSxNQUM5QixDQUFDO0FBQ0Q1QixvQkFBYyxLQUFLO0FBQ25CRSx3QkFBa0IsRUFBRTtBQUNwQkUsdUJBQWlCLEVBQUU7QUFBQSxJQUNyQixTQUFTNEIsR0FBRztBQUNWQyxjQUFRQyxNQUFNRixDQUFDO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBRUEsTUFBSXBDLFNBQVM7QUFDWCxVQUFNYixNQUFNOEIsVUFBVWtCLFlBQVk7QUFDbEMsV0FDRSxtQ0FDRTtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUFTLE1BQU0vQixjQUFjLElBQUk7QUFBQSxVQUNqQyxXQUFXaEM7QUFBQUEsWUFDVDtBQUFBLFlBQ0E2QjtBQUFBQSxVQUNGO0FBQUEsVUFDQSxPQUFPZ0IsV0FBVyxTQUFTOUIsSUFBSW9ELFFBQVEsQ0FBQyxDQUFDLE9BQU85RCxnQkFBZ0J3QyxTQUFTdkMsT0FBTyxDQUFDLEtBQUs7QUFBQSxVQUV0RjtBQUFBLG1DQUFDLFNBQU0sV0FBV04sR0FBRyxlQUFlNkMsV0FBVy9CLGVBQWVDLEdBQUcsSUFBSSxnQkFBZ0IsR0FBRyxhQUFhLFFBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBHO0FBQUEsWUFDMUcsdUJBQUMsVUFBSyxXQUFVLDRCQUE0QjhCLHFCQUFXLEdBQUc5QixJQUFJb0QsUUFBUSxDQUFDLENBQUMsTUFBTSxPQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRjtBQUFBO0FBQUE7QUFBQSxRQVZwRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFXQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU1wQztBQUFBQSxVQUNOLGNBQWNDO0FBQUFBLFVBQ2QsVUFBVUs7QUFBQUEsVUFDVixhQUFhQztBQUFBQSxVQUNiLFVBQVVDO0FBQUFBLFVBQ1YsYUFBYUM7QUFBQUEsVUFDYixVQUFVUDtBQUFBQSxVQUNWLGFBQWFDO0FBQUFBLFVBQ2IsU0FBU0M7QUFBQUEsVUFDVCxZQUFZQztBQUFBQSxVQUNaLFlBQVlLO0FBQUFBLFVBQ1osZUFBZUM7QUFBQUEsVUFDZixhQUFhQztBQUFBQSxVQUNiLGdCQUFnQkM7QUFBQUEsVUFDaEIsUUFBUVE7QUFBQUE7QUFBQUEsUUFmVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFldUI7QUFBQSxTQTVCekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBV3BELEdBQUcsa0RBQWtENkIsU0FBUyxHQUM1RTtBQUFBLDJCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLDZCQUFDLFVBQUssV0FBVSw4REFDZDtBQUFBLCtCQUFDLFNBQU0sV0FBVSwwQkFBeUIsYUFBYSxRQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTREO0FBQUE7QUFBQSxXQUQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsU0FBUSxXQUFVLGVBQWMsU0FBUyxNQUFNRyxjQUFjLElBQUksR0FDekY7QUFBQSwrQkFBQyxhQUFVLFdBQVUsa0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUM7QUFBQTtBQUFBLFdBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFFQyxDQUFDYSxXQUNBLHVCQUFDLFNBQUksV0FBVSwrQ0FBNkMseUZBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUVBLG1DQUNFO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDZDQUNiO0FBQUEsK0JBQUMsT0FBRSxXQUFXN0MsR0FBRyx1REFBdURjLGVBQWUrQixTQUFTa0IsUUFBUSxDQUFDLEdBQ3RHbEI7QUFBQUEsbUJBQVNrQixTQUFTSSxRQUFRLENBQUM7QUFBQSxVQUFFO0FBQUEsYUFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQThCOUQsMEJBQWdCd0MsU0FBU3ZDLE9BQU8sS0FBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RTtBQUFBLFdBSi9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2IsaUNBQUMsWUFBUyxPQUFPdUMsU0FBU2tCLFlBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUMsS0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQ2YsYUFDQyx1QkFBQyxPQUFFLFdBQVUsbUNBQWlDO0FBQUE7QUFBQSxRQUMvQkEsVUFBVW9CLGFBQWEsSUFBSXBCLFVBQVVvQixVQUFVRCxRQUFRLENBQUMsSUFBSTtBQUFBLFFBQUk7QUFBQSxRQUM1RW5CLFVBQVVxQixtQkFBbUIsT0FDNUIsbUNBQUU7QUFBQTtBQUFBLFVBQWNyQixVQUFVcUIsaUJBQWlCRixRQUFRLENBQUM7QUFBQSxVQUFFO0FBQUEsYUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRTtBQUFBLFdBSHBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BRUR0QixTQUFTa0IsV0FBVyxNQUNuQix1QkFBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSwrQkFBQyxPQUFJLFdBQVUsdUJBQXNCLGFBQWEsUUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RDtBQUFBO0FBQUEsV0FEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0F0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdCQTtBQUFBLElBR0Y7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU1oQztBQUFBQSxRQUNOLGNBQWNDO0FBQUFBLFFBQ2QsVUFBVUs7QUFBQUEsUUFDVixhQUFhQztBQUFBQSxRQUNiLFVBQVVDO0FBQUFBLFFBQ1YsYUFBYUM7QUFBQUEsUUFDYixVQUFVUDtBQUFBQSxRQUNWLGFBQWFDO0FBQUFBLFFBQ2IsU0FBU0M7QUFBQUEsUUFDVCxZQUFZQztBQUFBQSxRQUNaLFlBQVlLO0FBQUFBLFFBQ1osZUFBZUM7QUFBQUEsUUFDZixhQUFhQztBQUFBQSxRQUNiLGdCQUFnQkM7QUFBQUEsUUFDaEIsUUFBUVE7QUFBQUE7QUFBQUEsTUFmVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFldUI7QUFBQSxPQTNEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZEQTtBQUVKO0FBQUN0QixHQTdJZUgsZ0JBQWM7QUFBQSxVQVNYNUMsVUFDQ0EsVUFDSEMsV0FBVztBQUFBO0FBQUEsTUFYWjJDO0FBK0loQixTQUFTMkMsa0JBQWtCO0FBQUEsRUFDekJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FYO0FBQUFBLEVBQ0FZO0FBQUFBLEVBQ0FYO0FBQUFBLEVBQ0FZO0FBQUFBLEVBQ0FYO0FBQUFBLEVBQ0FZO0FBQUFBLEVBQ0FyRTtBQUFBQSxFQUNBc0U7QUFBQUEsRUFDQWpCO0FBQUFBLEVBQ0FrQjtBQUFBQSxFQUNBakI7QUFBQUEsRUFDQWtCO0FBQUFBLEVBQ0FDO0FBaUJGLEdBQUc7QUFDRCxTQUNFLHVCQUFDLFVBQU8sTUFBWSxjQUNsQixpQ0FBQyxpQkFBYyxXQUFVLGVBQ3ZCO0FBQUEsMkJBQUMsZ0JBQ0M7QUFBQSw2QkFBQyxlQUFZLDRCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUN6Qix1QkFBQyxxQkFBaUIsb0lBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsU0FBTSxXQUFVLFdBQVUsd0JBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUM7QUFBQSxRQUNuQyx1QkFBQyxVQUFPLE9BQU9sQixVQUFVLGVBQWUsQ0FBQ21CLE1BQXlDUCxZQUFZTyxDQUFDLEdBQzdGO0FBQUEsaUNBQUMsaUJBQWMsV0FBVSxPQUFNLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVksS0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQSxVQUM5Qyx1QkFBQyxpQkFDRTVFLG9CQUFVbUI7QUFBQUEsWUFBSSxDQUFDMEQsTUFDZCx1QkFBQyxjQUFtQixPQUFPQSxHQUFJQSxlQUFkQSxHQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBLFVBQ2xDLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxTQUFNLFdBQVUsV0FBVSx5QkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQztBQUFBLFFBQ3BDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPbkI7QUFBQUEsWUFDUCxVQUFVLENBQUNFLE1BQU1VLFlBQVlWLEVBQUVrQixPQUFPaEUsS0FBSztBQUFBLFlBQzNDLGFBQVk7QUFBQSxZQUNaLFdBQVU7QUFBQTtBQUFBLFVBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSWlCO0FBQUEsV0FObkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsU0FBTSxXQUFVLFdBQVUsK0JBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEM7QUFBQSxRQUMxQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsS0FBSztBQUFBLFlBQ0wsS0FBSztBQUFBLFlBQ0wsT0FBTzZDO0FBQUFBLFlBQ1AsVUFBVSxDQUFDQyxNQUFNVyxZQUFZWCxFQUFFa0IsT0FBT2hFLEtBQUs7QUFBQSxZQUMzQyxhQUFZO0FBQUEsWUFDWixXQUFVO0FBQUE7QUFBQSxVQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9pQjtBQUFBLFdBVG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLE1BQ0EsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFNBQU0sV0FBVSxXQUFVLGdEQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsUUFDM0Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU9aO0FBQUFBLFlBQ1AsVUFBVSxDQUFDMEQsTUFBTVksV0FBV1osRUFBRWtCLE9BQU9oRSxLQUFLO0FBQUEsWUFDMUMsYUFBWTtBQUFBLFlBQ1osV0FBVTtBQUFBO0FBQUEsVUFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJaUI7QUFBQSxXQU5uQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxTQUFNLFdBQVUsV0FBVSxzQ0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxVQUNqRDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsT0FBT3lDO0FBQUFBLGNBQ1AsVUFBVSxDQUFDSyxNQUFNYSxjQUFjYixFQUFFa0IsT0FBT2hFLEtBQUs7QUFBQSxjQUM3QyxXQUFVO0FBQUE7QUFBQSxZQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlpQjtBQUFBLGFBTm5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFNBQU0sV0FBVSxXQUFVLHVDQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRDtBQUFBLFVBQ2xEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPMEM7QUFBQUEsY0FDUCxVQUFVLENBQUNJLE1BQU1jLGVBQWVkLEVBQUVrQixPQUFPaEUsS0FBSztBQUFBLGNBQzlDLFdBQVU7QUFBQTtBQUFBLFlBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSWlCO0FBQUEsYUFObkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQTtBQUFBLFNBN0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4REE7QUFBQSxJQUNBLHVCQUFDLGdCQUNDO0FBQUEsNkJBQUMsVUFBTyxTQUFRLFdBQVUsTUFBSyxNQUFLLFNBQVMsTUFBTXNELGFBQWEsS0FBSyxHQUFHLHNCQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThFO0FBQUEsTUFDOUUsdUJBQUMsVUFBTyxNQUFLLE1BQUssU0FBU08sUUFBUSxvQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QztBQUFBLFNBRnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLE9BekVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwRUEsS0EzRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRFQTtBQUVKO0FBQUNJLE1BaEhRYjtBQUFpQixJQUFBNUMsSUFBQTBELEtBQUFEO0FBQUEsYUFBQXpELElBQUE7QUFBQSxhQUFBMEQsS0FBQTtBQUFBLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZVF1ZXJ5IiwidXNlTXV0YXRpb24iLCJhcGkiLCJCdXR0b24iLCJJbnB1dCIsIkxhYmVsIiwiRGlhbG9nIiwiRGlhbG9nQ29udGVudCIsIkRpYWxvZ0Rlc2NyaXB0aW9uIiwiRGlhbG9nRm9vdGVyIiwiRGlhbG9nSGVhZGVyIiwiRGlhbG9nVGl0bGUiLCJTZWxlY3QiLCJTZWxlY3RDb250ZW50IiwiU2VsZWN0SXRlbSIsIlNlbGVjdFRyaWdnZXIiLCJTZWxlY3RWYWx1ZSIsImNuIiwiR2F1Z2UiLCJSZWZyZXNoQ3ciLCJaYXAiLCJQUk9WSURFUlMiLCJmb3JtYXRDb3VudGRvd24iLCJyZXNldEF0Iiwibm93IiwiRGF0ZSIsImQiLCJNYXRoIiwiZmxvb3IiLCJoIiwibSIsImdhdWdlVGV4dENsYXNzIiwicGN0IiwiZ2F1Z2VCYXJDbGFzcyIsIlF1b3RhQmFyIiwidmFsdWUiLCJtYXgiLCJtaW4iLCJyb3VuZCIsIndpZHRoIiwibWFwIiwidGljayIsImxlZnQiLCJfYyIsIlF1b3RhRnVlbEdhdWdlIiwiY29tcGFjdCIsImNsYXNzTmFtZSIsIl9zIiwidXBkYXRlT3BlbiIsInNldFVwZGF0ZU9wZW4iLCJ1cGRhdGVVc2FnZVBjdCIsInNldFVwZGF0ZVVzYWdlUGN0IiwidXBkYXRlUmVzZXRBdCIsInNldFVwZGF0ZVJlc2V0QXQiLCJ1cGRhdGVQcm92aWRlciIsInNldFVwZGF0ZVByb3ZpZGVyIiwidXBkYXRlUGxhblRpZXIiLCJzZXRVcGRhdGVQbGFuVGllciIsInVwZGF0ZVRva2Vuc1VzZWQiLCJzZXRVcGRhdGVUb2tlbnNVc2VkIiwidXBkYXRlVG9rZW5zTGltaXQiLCJzZXRVcGRhdGVUb2tlbnNMaW1pdCIsInNuYXBzaG90IiwicXVvdGFUcmFja2luZyIsImdldExhdGVzdFNuYXBzaG90IiwicHJvamVjdGVkIiwiZ2V0UHJvamVjdGVkQnVyblJhdGUiLCJ1cHNlcnQiLCJ1cHNlcnRRdW90YVNuYXBzaG90IiwiaGFuZGxlVXBkYXRlIiwiTnVtYmVyIiwiaXNGaW5pdGUiLCJ0cmltIiwicGFyc2VkIiwicGFyc2UiLCJpc05hTiIsInRva2Vuc1VzZWQiLCJ0b2tlbnNMaW1pdCIsInByb3ZpZGVyIiwicGxhblRpZXIiLCJ1c2FnZVBjdCIsImUiLCJjb25zb2xlIiwiZXJyb3IiLCJ0b0ZpeGVkIiwicGN0UGVyRGF5IiwicHJvamVjdGVkQXRSZXNldCIsIlVwZGF0ZVF1b3RhRGlhbG9nIiwib3BlbiIsIm9uT3BlbkNoYW5nZSIsInNldFByb3ZpZGVyIiwic2V0UGxhblRpZXIiLCJzZXRVc2FnZVBjdCIsInNldFJlc2V0QXQiLCJzZXRUb2tlbnNVc2VkIiwic2V0VG9rZW5zTGltaXQiLCJvblNhdmUiLCJ2IiwicCIsInRhcmdldCIsIl9jMyIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJRdW90YUZ1ZWxHYXVnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBRdW90YSBmdWVsIGdhdWdlIOKAlCBMTE0gdXNhZ2UgJSwgcmVzZXQgY291bnRkb3duLCBidXJuIHJhdGUuXG4gKiBNYW51YWwgdXBkYXRlIGZsb3c6IHVzZXIgcGFzdGVzIHVzYWdlIGZyb20gcHJvdmlkZXIgZGFzaGJvYXJkLlxuICovXG5cbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VRdWVyeSwgdXNlTXV0YXRpb24gfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2lucHV0XCI7XG5pbXBvcnQgeyBMYWJlbCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvbGFiZWxcIjtcbmltcG9ydCB7XG4gIERpYWxvZyxcbiAgRGlhbG9nQ29udGVudCxcbiAgRGlhbG9nRGVzY3JpcHRpb24sXG4gIERpYWxvZ0Zvb3RlcixcbiAgRGlhbG9nSGVhZGVyLFxuICBEaWFsb2dUaXRsZSxcbn0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9kaWFsb2dcIjtcbmltcG9ydCB7XG4gIFNlbGVjdCxcbiAgU2VsZWN0Q29udGVudCxcbiAgU2VsZWN0SXRlbSxcbiAgU2VsZWN0VHJpZ2dlcixcbiAgU2VsZWN0VmFsdWUsXG59IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvc2VsZWN0XCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiO1xuaW1wb3J0IHsgR2F1Z2UsIFJlZnJlc2hDdywgWmFwIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuXG5jb25zdCBQUk9WSURFUlMgPSBbXCJhbnRocm9waWNcIiwgXCJvcGVuYWlcIiwgXCJnb29nbGVcIl0gYXMgY29uc3Q7XG5cbmZ1bmN0aW9uIGZvcm1hdENvdW50ZG93bihyZXNldEF0OiBudW1iZXIpOiBzdHJpbmcge1xuICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICBpZiAocmVzZXRBdCA8PSBub3cpIHJldHVybiBcIlJlc2V0cyBzb29uXCI7XG4gIGNvbnN0IGQgPSBNYXRoLmZsb29yKChyZXNldEF0IC0gbm93KSAvIDg2NDAwMDAwKTtcbiAgY29uc3QgaCA9IE1hdGguZmxvb3IoKChyZXNldEF0IC0gbm93KSAlIDg2NDAwMDAwKSAvIDM2MDAwMDApO1xuICBjb25zdCBtID0gTWF0aC5mbG9vcigoKHJlc2V0QXQgLSBub3cpICUgMzYwMDAwMCkgLyA2MDAwMCk7XG4gIGlmIChkID4gMCkgcmV0dXJuIGBSZXNldHMgaW4gJHtkfWQgJHtofWggJHttfW1gO1xuICBpZiAoaCA+IDApIHJldHVybiBgUmVzZXRzIGluICR7aH1oICR7bX1tYDtcbiAgcmV0dXJuIGBSZXNldHMgaW4gJHttfW1gO1xufVxuXG5mdW5jdGlvbiBnYXVnZVRleHRDbGFzcyhwY3Q6IG51bWJlcik6IHN0cmluZyB7XG4gIGlmIChwY3QgPj0gODApIHJldHVybiBcInRleHQtZXJyXCI7XG4gIGlmIChwY3QgPj0gNjApIHJldHVybiBcInRleHQtd2FyblwiO1xuICByZXR1cm4gXCJ0ZXh0LW9rXCI7XG59XG5cbmZ1bmN0aW9uIGdhdWdlQmFyQ2xhc3MocGN0OiBudW1iZXIpOiBzdHJpbmcge1xuICBpZiAocGN0ID49IDgwKSByZXR1cm4gXCJiZy1lcnJcIjtcbiAgaWYgKHBjdCA+PSA2MCkgcmV0dXJuIFwiYmctd2FyblwiO1xuICByZXR1cm4gXCJiZy1va1wiO1xufVxuXG4vKiogRmxhdCBxdW90YSBiYXIgd2l0aCB0aHJlc2hvbGQgdGlja3MgYXQgNjAlIGFuZCA4MCUuICovXG5mdW5jdGlvbiBRdW90YUJhcih7IHZhbHVlIH06IHsgdmFsdWU6IG51bWJlciB9KTogSlNYLkVsZW1lbnQge1xuICBjb25zdCBwY3QgPSBNYXRoLm1heCgwLCBNYXRoLm1pbigxMDAsIHZhbHVlKSk7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgaC0yIHctZnVsbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1mdWxsIGJnLXN1cmZhY2UtMlwiXG4gICAgICByb2xlPVwicHJvZ3Jlc3NiYXJcIlxuICAgICAgYXJpYS12YWx1ZW5vdz17TWF0aC5yb3VuZChwY3QpfVxuICAgICAgYXJpYS12YWx1ZW1pbj17MH1cbiAgICAgIGFyaWEtdmFsdWVtYXg9ezEwMH1cbiAgICAgIGFyaWEtbGFiZWw9XCJMTE0gcXVvdGEgdXNlZFwiXG4gICAgPlxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9e2NuKFwiaC1mdWxsIHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLVt3aWR0aF0gZHVyYXRpb24tMjAwXCIsIGdhdWdlQmFyQ2xhc3MocGN0KSl9XG4gICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHtwY3R9JWAgfX1cbiAgICAgIC8+XG4gICAgICB7WzYwLCA4MF0ubWFwKCh0aWNrKSA9PiAoXG4gICAgICAgIDxzcGFuXG4gICAgICAgICAga2V5PXt0aWNrfVxuICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCB3LXB4IGJnLWxpbmUtc3Ryb25nXCJcbiAgICAgICAgICBzdHlsZT17eyBsZWZ0OiBgJHt0aWNrfSVgIH19XG4gICAgICAgICAgYXJpYS1oaWRkZW5cbiAgICAgICAgLz5cbiAgICAgICkpfVxuICAgIDwvZGl2PlxuICApO1xufVxuXG5pbnRlcmZhY2UgUXVvdGFGdWVsR2F1Z2VQcm9wcyB7XG4gIC8qKiBDb21wYWN0IG1vZGUgZm9yIFRvcE5hdiBpbmxpbmUgZ2F1Z2UgKi9cbiAgY29tcGFjdD86IGJvb2xlYW47XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFF1b3RhRnVlbEdhdWdlKHsgY29tcGFjdCA9IGZhbHNlLCBjbGFzc05hbWUgfTogUXVvdGFGdWVsR2F1Z2VQcm9wcykge1xuICBjb25zdCBbdXBkYXRlT3Blbiwgc2V0VXBkYXRlT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFt1cGRhdGVVc2FnZVBjdCwgc2V0VXBkYXRlVXNhZ2VQY3RdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFt1cGRhdGVSZXNldEF0LCBzZXRVcGRhdGVSZXNldEF0XSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbdXBkYXRlUHJvdmlkZXIsIHNldFVwZGF0ZVByb3ZpZGVyXSA9IHVzZVN0YXRlPFwiYW50aHJvcGljXCIgfCBcIm9wZW5haVwiIHwgXCJnb29nbGVcIj4oXCJhbnRocm9waWNcIik7XG4gIGNvbnN0IFt1cGRhdGVQbGFuVGllciwgc2V0VXBkYXRlUGxhblRpZXJdID0gdXNlU3RhdGUoXCJjbGF1ZGVfbWF4XzIwMFwiKTtcbiAgY29uc3QgW3VwZGF0ZVRva2Vuc1VzZWQsIHNldFVwZGF0ZVRva2Vuc1VzZWRdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFt1cGRhdGVUb2tlbnNMaW1pdCwgc2V0VXBkYXRlVG9rZW5zTGltaXRdID0gdXNlU3RhdGUoXCJcIik7XG5cbiAgY29uc3Qgc25hcHNob3QgPSB1c2VRdWVyeShhcGkucXVvdGFUcmFja2luZy5nZXRMYXRlc3RTbmFwc2hvdCwge30pO1xuICBjb25zdCBwcm9qZWN0ZWQgPSB1c2VRdWVyeShhcGkucXVvdGFUcmFja2luZy5nZXRQcm9qZWN0ZWRCdXJuUmF0ZSwge30pO1xuICBjb25zdCB1cHNlcnQgPSB1c2VNdXRhdGlvbihhcGkucXVvdGFUcmFja2luZy51cHNlcnRRdW90YVNuYXBzaG90KTtcblxuICBjb25zdCBoYW5kbGVVcGRhdGUgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgcGN0ID0gTnVtYmVyKHVwZGF0ZVVzYWdlUGN0KTtcbiAgICBpZiAoIU51bWJlci5pc0Zpbml0ZShwY3QpIHx8IHBjdCA8IDAgfHwgcGN0ID4gMTAwKSByZXR1cm47XG4gICAgbGV0IHJlc2V0QXQgPSBEYXRlLm5vdygpICsgNyAqIDg2NDAwICogMTAwMDtcbiAgICBpZiAodXBkYXRlUmVzZXRBdC50cmltKCkpIHtcbiAgICAgIGNvbnN0IHBhcnNlZCA9IERhdGUucGFyc2UodXBkYXRlUmVzZXRBdCk7XG4gICAgICBpZiAoIU51bWJlci5pc05hTihwYXJzZWQpKSByZXNldEF0ID0gcGFyc2VkO1xuICAgIH1cbiAgICBjb25zdCB0b2tlbnNVc2VkID0gdXBkYXRlVG9rZW5zVXNlZC50cmltKCkgPyBOdW1iZXIodXBkYXRlVG9rZW5zVXNlZCkgOiAwO1xuICAgIGNvbnN0IHRva2Vuc0xpbWl0ID0gdXBkYXRlVG9rZW5zTGltaXQudHJpbSgpID8gTnVtYmVyKHVwZGF0ZVRva2Vuc0xpbWl0KSA6IDE7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHVwc2VydCh7XG4gICAgICAgIHByb3ZpZGVyOiB1cGRhdGVQcm92aWRlcixcbiAgICAgICAgcGxhblRpZXI6IHVwZGF0ZVBsYW5UaWVyLnRyaW0oKSB8fCBcImRlZmF1bHRcIixcbiAgICAgICAgdXNhZ2VQY3Q6IHBjdCxcbiAgICAgICAgcmVzZXRBdCxcbiAgICAgICAgdG9rZW5zVXNlZCxcbiAgICAgICAgdG9rZW5zTGltaXQ6IHRva2Vuc0xpbWl0IHx8IDEsXG4gICAgICB9KTtcbiAgICAgIHNldFVwZGF0ZU9wZW4oZmFsc2UpO1xuICAgICAgc2V0VXBkYXRlVXNhZ2VQY3QoXCJcIik7XG4gICAgICBzZXRVcGRhdGVSZXNldEF0KFwiXCIpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgfVxuICB9O1xuXG4gIGlmIChjb21wYWN0KSB7XG4gICAgY29uc3QgcGN0ID0gc25hcHNob3Q/LnVzYWdlUGN0ID8/IDA7XG4gICAgcmV0dXJuIChcbiAgICAgIDw+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRVcGRhdGVPcGVuKHRydWUpfVxuICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICBcImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgcHgtMiBweS0xIHRleHQteHMgdGV4dC1pbmstc2Vjb25kYXJ5IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBob3Zlcjpib3JkZXItbGluZS1zdHJvbmcgaG92ZXI6dGV4dC1pbmtcIixcbiAgICAgICAgICAgIGNsYXNzTmFtZVxuICAgICAgICAgICl9XG4gICAgICAgICAgdGl0bGU9e3NuYXBzaG90ID8gYFF1b3RhICR7cGN0LnRvRml4ZWQoMCl9JSDCtyAke2Zvcm1hdENvdW50ZG93bihzbmFwc2hvdC5yZXNldEF0KX1gIDogXCJVcGRhdGUgcXVvdGFcIn1cbiAgICAgICAgPlxuICAgICAgICAgIDxHYXVnZSBjbGFzc05hbWU9e2NuKFwiaC0zLjUgdy0zLjVcIiwgc25hcHNob3QgPyBnYXVnZVRleHRDbGFzcyhwY3QpIDogXCJ0ZXh0LWluay1tdXRlZFwiKX0gc3Ryb2tlV2lkdGg9ezEuNzV9IC8+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGFidWxhci1udW1zXCI+e3NuYXBzaG90ID8gYCR7cGN0LnRvRml4ZWQoMCl9JWAgOiBcIuKAlFwifTwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDxVcGRhdGVRdW90YURpYWxvZ1xuICAgICAgICAgIG9wZW49e3VwZGF0ZU9wZW59XG4gICAgICAgICAgb25PcGVuQ2hhbmdlPXtzZXRVcGRhdGVPcGVufVxuICAgICAgICAgIHByb3ZpZGVyPXt1cGRhdGVQcm92aWRlcn1cbiAgICAgICAgICBzZXRQcm92aWRlcj17c2V0VXBkYXRlUHJvdmlkZXJ9XG4gICAgICAgICAgcGxhblRpZXI9e3VwZGF0ZVBsYW5UaWVyfVxuICAgICAgICAgIHNldFBsYW5UaWVyPXtzZXRVcGRhdGVQbGFuVGllcn1cbiAgICAgICAgICB1c2FnZVBjdD17dXBkYXRlVXNhZ2VQY3R9XG4gICAgICAgICAgc2V0VXNhZ2VQY3Q9e3NldFVwZGF0ZVVzYWdlUGN0fVxuICAgICAgICAgIHJlc2V0QXQ9e3VwZGF0ZVJlc2V0QXR9XG4gICAgICAgICAgc2V0UmVzZXRBdD17c2V0VXBkYXRlUmVzZXRBdH1cbiAgICAgICAgICB0b2tlbnNVc2VkPXt1cGRhdGVUb2tlbnNVc2VkfVxuICAgICAgICAgIHNldFRva2Vuc1VzZWQ9e3NldFVwZGF0ZVRva2Vuc1VzZWR9XG4gICAgICAgICAgdG9rZW5zTGltaXQ9e3VwZGF0ZVRva2Vuc0xpbWl0fVxuICAgICAgICAgIHNldFRva2Vuc0xpbWl0PXtzZXRVcGRhdGVUb2tlbnNMaW1pdH1cbiAgICAgICAgICBvblNhdmU9e2hhbmRsZVVwZGF0ZX1cbiAgICAgICAgLz5cbiAgICAgIDwvPlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtjbihcInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMSBwLTRcIiwgY2xhc3NOYW1lKX0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj5cbiAgICAgICAgICA8R2F1Z2UgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWluay1tdXRlZFwiIHN0cm9rZVdpZHRoPXsxLjc1fSAvPlxuICAgICAgICAgIExMTSBxdW90YVxuICAgICAgICA8L3NwYW4+XG4gICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cImdob3N0XCIgY2xhc3NOYW1lPVwiaC03IHRleHQteHNcIiBvbkNsaWNrPXsoKSA9PiBzZXRVcGRhdGVPcGVuKHRydWUpfT5cbiAgICAgICAgICA8UmVmcmVzaEN3IGNsYXNzTmFtZT1cImgtMyB3LTMgbXItMVwiIC8+XG4gICAgICAgICAgVXBkYXRlXG4gICAgICAgIDwvQnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHshc25hcHNob3QgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNCB0ZXh0LWNlbnRlciB0ZXh0LVsxM3B4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgIE5vIHF1b3RhIGRhdGEuIENsaWNrIFVwZGF0ZSBhbmQgZW50ZXIgdXNhZ2UgZnJvbSB5b3VyIHByb3ZpZGVyIGRhc2hib2FyZC5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogKFxuICAgICAgICA8PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1iYXNlbGluZSBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT17Y24oXCJ0ZXh0LVsyMHB4XSBmb250LXNlbWlib2xkIGxlYWRpbmctbm9uZSB0YWJ1bGFyLW51bXNcIiwgZ2F1Z2VUZXh0Q2xhc3Moc25hcHNob3QudXNhZ2VQY3QpKX0+XG4gICAgICAgICAgICAgIHtzbmFwc2hvdC51c2FnZVBjdC50b0ZpeGVkKDEpfSVcbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtaW5rLW11dGVkXCI+e2Zvcm1hdENvdW50ZG93bihzbmFwc2hvdC5yZXNldEF0KX08L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yLjVcIj5cbiAgICAgICAgICAgIDxRdW90YUJhciB2YWx1ZT17c25hcHNob3QudXNhZ2VQY3R9IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAge3Byb2plY3RlZCAmJiAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtWzEycHhdIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAgICAgIEJ1cm4gcmF0ZTogfntwcm9qZWN0ZWQucGN0UGVyRGF5ID49IDAgPyBwcm9qZWN0ZWQucGN0UGVyRGF5LnRvRml4ZWQoMSkgOiBcIjBcIn0lIHBlciBkYXlcbiAgICAgICAgICAgICAge3Byb2plY3RlZC5wcm9qZWN0ZWRBdFJlc2V0IDwgMTAwICYmIChcbiAgICAgICAgICAgICAgICA8PiDCtyBQcm9qZWN0ZWQge3Byb2plY3RlZC5wcm9qZWN0ZWRBdFJlc2V0LnRvRml4ZWQoMCl9JSBhdCByZXNldDwvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICl9XG4gICAgICAgICAge3NuYXBzaG90LnVzYWdlUGN0IDwgNjAgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtWzEycHhdIHRleHQtaW5rLXNlY29uZGFyeVwiPlxuICAgICAgICAgICAgICA8WmFwIGNsYXNzTmFtZT1cImgtMy41IHctMy41IHRleHQtb2tcIiBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAgICAgICAgQXZhaWxhYmxlIGZvciBiYWNrZ3JvdW5kIHdvcmsg4oCUIHNjaGVkdWxlciBjYW4gcnVuIGxvdy1wcmlvcml0eSBqb2JzLlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC8+XG4gICAgICApfVxuXG4gICAgICA8VXBkYXRlUXVvdGFEaWFsb2dcbiAgICAgICAgb3Blbj17dXBkYXRlT3Blbn1cbiAgICAgICAgb25PcGVuQ2hhbmdlPXtzZXRVcGRhdGVPcGVufVxuICAgICAgICBwcm92aWRlcj17dXBkYXRlUHJvdmlkZXJ9XG4gICAgICAgIHNldFByb3ZpZGVyPXtzZXRVcGRhdGVQcm92aWRlcn1cbiAgICAgICAgcGxhblRpZXI9e3VwZGF0ZVBsYW5UaWVyfVxuICAgICAgICBzZXRQbGFuVGllcj17c2V0VXBkYXRlUGxhblRpZXJ9XG4gICAgICAgIHVzYWdlUGN0PXt1cGRhdGVVc2FnZVBjdH1cbiAgICAgICAgc2V0VXNhZ2VQY3Q9e3NldFVwZGF0ZVVzYWdlUGN0fVxuICAgICAgICByZXNldEF0PXt1cGRhdGVSZXNldEF0fVxuICAgICAgICBzZXRSZXNldEF0PXtzZXRVcGRhdGVSZXNldEF0fVxuICAgICAgICB0b2tlbnNVc2VkPXt1cGRhdGVUb2tlbnNVc2VkfVxuICAgICAgICBzZXRUb2tlbnNVc2VkPXtzZXRVcGRhdGVUb2tlbnNVc2VkfVxuICAgICAgICB0b2tlbnNMaW1pdD17dXBkYXRlVG9rZW5zTGltaXR9XG4gICAgICAgIHNldFRva2Vuc0xpbWl0PXtzZXRVcGRhdGVUb2tlbnNMaW1pdH1cbiAgICAgICAgb25TYXZlPXtoYW5kbGVVcGRhdGV9XG4gICAgICAvPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5mdW5jdGlvbiBVcGRhdGVRdW90YURpYWxvZyh7XG4gIG9wZW4sXG4gIG9uT3BlbkNoYW5nZSxcbiAgcHJvdmlkZXIsXG4gIHNldFByb3ZpZGVyLFxuICBwbGFuVGllcixcbiAgc2V0UGxhblRpZXIsXG4gIHVzYWdlUGN0LFxuICBzZXRVc2FnZVBjdCxcbiAgcmVzZXRBdCxcbiAgc2V0UmVzZXRBdCxcbiAgdG9rZW5zVXNlZCxcbiAgc2V0VG9rZW5zVXNlZCxcbiAgdG9rZW5zTGltaXQsXG4gIHNldFRva2Vuc0xpbWl0LFxuICBvblNhdmUsXG59OiB7XG4gIG9wZW46IGJvb2xlYW47XG4gIG9uT3BlbkNoYW5nZTogKG9wZW46IGJvb2xlYW4pID0+IHZvaWQ7XG4gIHByb3ZpZGVyOiBcImFudGhyb3BpY1wiIHwgXCJvcGVuYWlcIiB8IFwiZ29vZ2xlXCI7XG4gIHNldFByb3ZpZGVyOiAocDogXCJhbnRocm9waWNcIiB8IFwib3BlbmFpXCIgfCBcImdvb2dsZVwiKSA9PiB2b2lkO1xuICBwbGFuVGllcjogc3RyaW5nO1xuICBzZXRQbGFuVGllcjogKHM6IHN0cmluZykgPT4gdm9pZDtcbiAgdXNhZ2VQY3Q6IHN0cmluZztcbiAgc2V0VXNhZ2VQY3Q6IChzOiBzdHJpbmcpID0+IHZvaWQ7XG4gIHJlc2V0QXQ6IHN0cmluZztcbiAgc2V0UmVzZXRBdDogKHM6IHN0cmluZykgPT4gdm9pZDtcbiAgdG9rZW5zVXNlZDogc3RyaW5nO1xuICBzZXRUb2tlbnNVc2VkOiAoczogc3RyaW5nKSA9PiB2b2lkO1xuICB0b2tlbnNMaW1pdDogc3RyaW5nO1xuICBzZXRUb2tlbnNMaW1pdDogKHM6IHN0cmluZykgPT4gdm9pZDtcbiAgb25TYXZlOiAoKSA9PiB2b2lkO1xufSkge1xuICByZXR1cm4gKFxuICAgIDxEaWFsb2cgb3Blbj17b3Blbn0gb25PcGVuQ2hhbmdlPXtvbk9wZW5DaGFuZ2V9PlxuICAgICAgPERpYWxvZ0NvbnRlbnQgY2xhc3NOYW1lPVwic206bWF4LXctc21cIj5cbiAgICAgICAgPERpYWxvZ0hlYWRlcj5cbiAgICAgICAgICA8RGlhbG9nVGl0bGU+VXBkYXRlIHF1b3RhPC9EaWFsb2dUaXRsZT5cbiAgICAgICAgICA8RGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgICAgICBFbnRlciBjdXJyZW50IHVzYWdlIGZyb20geW91ciBwcm92aWRlciBkYXNoYm9hcmQgKGUuZy4gQ2xhdWRlIHVzYWdlIHBhZ2UpLiBTY2hlZHVsZXIgdXNlcyB0aGlzIGZvciBxdW90YS1hd2FyZSBydW5zLlxuICAgICAgICAgIDwvRGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgIDwvRGlhbG9nSGVhZGVyPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTMgcHktMlwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8TGFiZWwgY2xhc3NOYW1lPVwidGV4dC14c1wiPlByb3ZpZGVyPC9MYWJlbD5cbiAgICAgICAgICAgIDxTZWxlY3QgdmFsdWU9e3Byb3ZpZGVyfSBvblZhbHVlQ2hhbmdlPXsodjogXCJhbnRocm9waWNcIiB8IFwib3BlbmFpXCIgfCBcImdvb2dsZVwiKSA9PiBzZXRQcm92aWRlcih2KX0+XG4gICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cImgtOFwiPjxTZWxlY3RWYWx1ZSAvPjwvU2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAge1BST1ZJREVSUy5tYXAoKHApID0+IChcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17cH0gdmFsdWU9e3B9PntwfTwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxMYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+UGxhbiB0aWVyPC9MYWJlbD5cbiAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICB2YWx1ZT17cGxhblRpZXJ9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGxhblRpZXIoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gY2xhdWRlX21heF8yMDBcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLThcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPExhYmVsIGNsYXNzTmFtZT1cInRleHQteHNcIj5Vc2FnZSAlICgw4oCTMTAwKTwvTGFiZWw+XG4gICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgIG1pbj17MH1cbiAgICAgICAgICAgICAgbWF4PXsxMDB9XG4gICAgICAgICAgICAgIHZhbHVlPXt1c2FnZVBjdH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRVc2FnZVBjdChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiA0NVwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8TGFiZWwgY2xhc3NOYW1lPVwidGV4dC14c1wiPlJlc2V0IGF0IChvcHRpb25hbCwgSVNPIG9yIGRhdGUpPC9MYWJlbD5cbiAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICB2YWx1ZT17cmVzZXRBdH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZXNldEF0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIFNhdHVyZGF5IDEwcG0gb3IgSVNPIGRhdGVcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLThcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxMYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+VG9rZW5zIHVzZWQgKG9wdGlvbmFsKTwvTGFiZWw+XG4gICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXt0b2tlbnNVc2VkfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VG9rZW5zVXNlZChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04XCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPExhYmVsIGNsYXNzTmFtZT1cInRleHQteHNcIj5Ub2tlbnMgbGltaXQgKG9wdGlvbmFsKTwvTGFiZWw+XG4gICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXt0b2tlbnNMaW1pdH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRva2Vuc0xpbWl0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLThcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8RGlhbG9nRm9vdGVyPlxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBzaXplPVwic21cIiBvbkNsaWNrPXsoKSA9PiBvbk9wZW5DaGFuZ2UoZmFsc2UpfT5DYW5jZWw8L0J1dHRvbj5cbiAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIG9uQ2xpY2s9e29uU2F2ZX0+U2F2ZTwvQnV0dG9uPlxuICAgICAgICA8L0RpYWxvZ0Zvb3Rlcj5cbiAgICAgIDwvRGlhbG9nQ29udGVudD5cbiAgICA8L0RpYWxvZz5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL2NvbXBvbmVudHMvUXVvdGFGdWVsR2F1Z2UudHN4In0=