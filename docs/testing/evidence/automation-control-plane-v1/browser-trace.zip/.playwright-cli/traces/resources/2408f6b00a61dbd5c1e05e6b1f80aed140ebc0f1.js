import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CommandNav.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/CommandNav.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { cn } from "/src/lib/utils.ts";
import {
  Home,
  Orbit,
  Crosshair,
  Bot,
  MessageSquare,
  FileText,
  Radio,
  BookOpen,
  Code2,
  ShieldCheck,
  LayoutGrid
} from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
const navItems = [
  { id: "home", label: "Home", shortLabel: "Home", icon: Home },
  { id: "control", label: "Control", shortLabel: "Ctrl", icon: Orbit },
  { id: "ops", label: "Operations", shortLabel: "Ops", icon: Crosshair },
  { id: "agents", label: "Agents", shortLabel: "Agents", icon: Bot },
  { id: "chat", label: "Chat", shortLabel: "Chat", icon: MessageSquare },
  { id: "content", label: "Content", shortLabel: "Content", icon: FileText },
  { id: "comms", label: "Comms", shortLabel: "Comms", icon: Radio },
  { id: "knowledge", label: "Knowledge", shortLabel: "KB", icon: BookOpen },
  { id: "code", label: "Code", shortLabel: "Code", icon: Code2 },
  { id: "quality", label: "Quality", shortLabel: "QC", icon: ShieldCheck },
  { id: "platform", label: "Platform", shortLabel: "Platform", icon: LayoutGrid }
];
export function CommandNav({
  activeSection,
  onSectionChange,
  className
}) {
  return /* @__PURE__ */ jsxDEV(
    "nav",
    {
      className: cn(
        "relative flex items-center gap-3 border-b border-line bg-rail px-3 py-2",
        className
      ),
      "aria-label": "Command center navigation",
      children: /* @__PURE__ */ jsxDEV("div", { className: "relative flex min-w-0 flex-1 items-center overflow-x-auto", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "hidden shrink-0 items-center gap-3 rounded-xl border border-line bg-surface-1 px-3 py-2 xl:flex", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex h-9 w-9 items-center justify-center rounded-lg border border-line bg-surface-2 text-ink-secondary", children: /* @__PURE__ */ jsxDEV(Crosshair, { className: "h-4 w-4" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/CommandNav.tsx",
            lineNumber: 80,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/CommandNav.tsx",
            lineNumber: 79,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "leading-none", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-medium text-ink-muted", children: "Command Grid" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/CommandNav.tsx",
              lineNumber: 83,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-semibold text-ink", children: "SellerFi Ops" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/CommandNav.tsx",
              lineNumber: 86,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/CommandNav.tsx",
            lineNumber: 82,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/CommandNav.tsx",
          lineNumber: 78,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ml-3 flex min-w-0 flex-1 rounded-lg border border-line p-0.5", children: navItems.map((item) => {
          const isActive = activeSection === item.id;
          const Icon = item.icon;
          return /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => onSectionChange(item.id),
              className: cn(
                "relative flex h-9 min-w-[64px] flex-1 items-center justify-center gap-2 rounded-md px-2.5",
                "text-[12.5px] font-medium",
                "transition-colors duration-150",
                "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1 focus-visible:ring-offset-background",
                isActive ? "bg-surface-2 text-ink" : "text-ink-secondary hover:text-ink"
              ),
              "aria-current": isActive ? "page" : void 0,
              children: [
                /* @__PURE__ */ jsxDEV(Icon, { className: "relative h-3.5 w-3.5 shrink-0" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/CommandNav.tsx",
                  lineNumber: 112,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "relative hidden md:inline", children: item.label }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/CommandNav.tsx",
                  lineNumber: 113,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "relative hidden sm:inline md:hidden", children: item.shortLabel }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/CommandNav.tsx",
                  lineNumber: 114,
                  columnNumber: 17
                }, this)
              ]
            },
            item.id,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/CommandNav.tsx",
              lineNumber: 98,
              columnNumber: 15
            },
            this
          );
        }) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/CommandNav.tsx",
          lineNumber: 92,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/CommandNav.tsx",
        lineNumber: 77,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/CommandNav.tsx",
      lineNumber: 70,
      columnNumber: 5
    },
    this
  );
}
_c = CommandNav;
var _c;
$RefreshReg$(_c, "CommandNav");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/CommandNav.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/CommandNav.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNERZOzs7Ozs7Ozs7Ozs7Ozs7O0FBNURaLFNBQVNBLFVBQVU7QUFDbkI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUVLO0FBVVAsTUFBTUMsV0FBNkI7QUFBQSxFQUNqQyxFQUFFQyxJQUFJLFFBQVFDLE9BQU8sUUFBUUMsWUFBWSxRQUFRQyxNQUFNZixLQUFLO0FBQUEsRUFDNUQsRUFBRVksSUFBSSxXQUFXQyxPQUFPLFdBQVdDLFlBQVksUUFBUUMsTUFBTWQsTUFBTTtBQUFBLEVBQ25FLEVBQUVXLElBQUksT0FBT0MsT0FBTyxjQUFjQyxZQUFZLE9BQU9DLE1BQU1iLFVBQVU7QUFBQSxFQUNyRSxFQUFFVSxJQUFJLFVBQVVDLE9BQU8sVUFBVUMsWUFBWSxVQUFVQyxNQUFNWixJQUFJO0FBQUEsRUFDakUsRUFBRVMsSUFBSSxRQUFRQyxPQUFPLFFBQVFDLFlBQVksUUFBUUMsTUFBTVgsY0FBYztBQUFBLEVBQ3JFLEVBQUVRLElBQUksV0FBV0MsT0FBTyxXQUFXQyxZQUFZLFdBQVdDLE1BQU1WLFNBQVM7QUFBQSxFQUN6RSxFQUFFTyxJQUFJLFNBQVNDLE9BQU8sU0FBU0MsWUFBWSxTQUFTQyxNQUFNVCxNQUFNO0FBQUEsRUFDaEUsRUFBRU0sSUFBSSxhQUFhQyxPQUFPLGFBQWFDLFlBQVksTUFBTUMsTUFBTVIsU0FBUztBQUFBLEVBQ3hFLEVBQUVLLElBQUksUUFBUUMsT0FBTyxRQUFRQyxZQUFZLFFBQVFDLE1BQU1QLE1BQU07QUFBQSxFQUM3RCxFQUFFSSxJQUFJLFdBQVdDLE9BQU8sV0FBV0MsWUFBWSxNQUFNQyxNQUFNTixZQUFZO0FBQUEsRUFDdkUsRUFBRUcsSUFBSSxZQUFZQyxPQUFPLFlBQVlDLFlBQVksWUFBWUMsTUFBTUwsV0FBVztBQUFDO0FBUzFFLGdCQUFTTSxXQUFXO0FBQUEsRUFDekJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ2UsR0FBRztBQUNsQixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxXQUFXcEI7QUFBQUEsUUFDVDtBQUFBLFFBQ0FvQjtBQUFBQSxNQUNGO0FBQUEsTUFDQSxjQUFXO0FBQUEsTUFFWCxpQ0FBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsbUdBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMEdBQ2IsaUNBQUMsYUFBVSxXQUFVLGFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCLEtBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwwQ0FBd0MsNEJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxrQ0FBZ0MsNEJBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxhQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGdFQUNaUixtQkFBU1MsSUFBSSxDQUFDQyxTQUFTO0FBQ3RCLGdCQUFNQyxXQUFXTCxrQkFBa0JJLEtBQUtUO0FBQ3hDLGdCQUFNVyxPQUFPRixLQUFLTjtBQUVsQixpQkFDRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsU0FBUyxNQUFNRyxnQkFBZ0JHLEtBQUtULEVBQUU7QUFBQSxjQUN0QyxXQUFXYjtBQUFBQSxnQkFDVDtBQUFBLGdCQUNBO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQTtBQUFBLGdCQUNBdUIsV0FDSSwwQkFDQTtBQUFBLGNBQ047QUFBQSxjQUNBLGdCQUFjQSxXQUFXLFNBQVNFO0FBQUFBLGNBRWxDO0FBQUEsdUNBQUMsUUFBSyxXQUFVLG1DQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErQztBQUFBLGdCQUMvQyx1QkFBQyxVQUFLLFdBQVUsNkJBQTZCSCxlQUFLUixTQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RDtBQUFBLGdCQUN4RCx1QkFBQyxVQUFLLFdBQVUsdUNBQXVDUSxlQUFLUCxjQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RTtBQUFBO0FBQUE7QUFBQSxZQWZsRU8sS0FBS1Q7QUFBQUEsWUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBaUJBO0FBQUEsUUFFSixDQUFDLEtBekJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQkE7QUFBQSxXQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMENBO0FBQUE7QUFBQSxJQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFrREE7QUFFSjtBQUFDYSxLQTFEZVQ7QUFBVSxJQUFBUztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJjbiIsIkhvbWUiLCJPcmJpdCIsIkNyb3NzaGFpciIsIkJvdCIsIk1lc3NhZ2VTcXVhcmUiLCJGaWxlVGV4dCIsIlJhZGlvIiwiQm9va09wZW4iLCJDb2RlMiIsIlNoaWVsZENoZWNrIiwiTGF5b3V0R3JpZCIsIm5hdkl0ZW1zIiwiaWQiLCJsYWJlbCIsInNob3J0TGFiZWwiLCJpY29uIiwiQ29tbWFuZE5hdiIsImFjdGl2ZVNlY3Rpb24iLCJvblNlY3Rpb25DaGFuZ2UiLCJjbGFzc05hbWUiLCJtYXAiLCJpdGVtIiwiaXNBY3RpdmUiLCJJY29uIiwidW5kZWZpbmVkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29tbWFuZE5hdi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcbmltcG9ydCB7XG4gIEhvbWUsXG4gIE9yYml0LFxuICBDcm9zc2hhaXIsXG4gIEJvdCxcbiAgTWVzc2FnZVNxdWFyZSxcbiAgRmlsZVRleHQsXG4gIFJhZGlvLFxuICBCb29rT3BlbixcbiAgQ29kZTIsXG4gIFNoaWVsZENoZWNrLFxuICBMYXlvdXRHcmlkLFxuICB0eXBlIEx1Y2lkZUljb24sXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB0eXBlIHsgQ29tbWFuZFNlY3Rpb24gfSBmcm9tIFwiLi4vVG9wTmF2XCI7XG5cbmludGVyZmFjZSBDb21tYW5kTmF2SXRlbSB7XG4gIGlkOiBDb21tYW5kU2VjdGlvbjtcbiAgbGFiZWw6IHN0cmluZztcbiAgc2hvcnRMYWJlbDogc3RyaW5nO1xuICBpY29uOiBMdWNpZGVJY29uO1xufVxuXG5jb25zdCBuYXZJdGVtczogQ29tbWFuZE5hdkl0ZW1bXSA9IFtcbiAgeyBpZDogXCJob21lXCIsIGxhYmVsOiBcIkhvbWVcIiwgc2hvcnRMYWJlbDogXCJIb21lXCIsIGljb246IEhvbWUgfSxcbiAgeyBpZDogXCJjb250cm9sXCIsIGxhYmVsOiBcIkNvbnRyb2xcIiwgc2hvcnRMYWJlbDogXCJDdHJsXCIsIGljb246IE9yYml0IH0sXG4gIHsgaWQ6IFwib3BzXCIsIGxhYmVsOiBcIk9wZXJhdGlvbnNcIiwgc2hvcnRMYWJlbDogXCJPcHNcIiwgaWNvbjogQ3Jvc3NoYWlyIH0sXG4gIHsgaWQ6IFwiYWdlbnRzXCIsIGxhYmVsOiBcIkFnZW50c1wiLCBzaG9ydExhYmVsOiBcIkFnZW50c1wiLCBpY29uOiBCb3QgfSxcbiAgeyBpZDogXCJjaGF0XCIsIGxhYmVsOiBcIkNoYXRcIiwgc2hvcnRMYWJlbDogXCJDaGF0XCIsIGljb246IE1lc3NhZ2VTcXVhcmUgfSxcbiAgeyBpZDogXCJjb250ZW50XCIsIGxhYmVsOiBcIkNvbnRlbnRcIiwgc2hvcnRMYWJlbDogXCJDb250ZW50XCIsIGljb246IEZpbGVUZXh0IH0sXG4gIHsgaWQ6IFwiY29tbXNcIiwgbGFiZWw6IFwiQ29tbXNcIiwgc2hvcnRMYWJlbDogXCJDb21tc1wiLCBpY29uOiBSYWRpbyB9LFxuICB7IGlkOiBcImtub3dsZWRnZVwiLCBsYWJlbDogXCJLbm93bGVkZ2VcIiwgc2hvcnRMYWJlbDogXCJLQlwiLCBpY29uOiBCb29rT3BlbiB9LFxuICB7IGlkOiBcImNvZGVcIiwgbGFiZWw6IFwiQ29kZVwiLCBzaG9ydExhYmVsOiBcIkNvZGVcIiwgaWNvbjogQ29kZTIgfSxcbiAgeyBpZDogXCJxdWFsaXR5XCIsIGxhYmVsOiBcIlF1YWxpdHlcIiwgc2hvcnRMYWJlbDogXCJRQ1wiLCBpY29uOiBTaGllbGRDaGVjayB9LFxuICB7IGlkOiBcInBsYXRmb3JtXCIsIGxhYmVsOiBcIlBsYXRmb3JtXCIsIHNob3J0TGFiZWw6IFwiUGxhdGZvcm1cIiwgaWNvbjogTGF5b3V0R3JpZCB9LFxuXTtcblxuaW50ZXJmYWNlIENvbW1hbmROYXZQcm9wcyB7XG4gIGFjdGl2ZVNlY3Rpb246IENvbW1hbmRTZWN0aW9uO1xuICBvblNlY3Rpb25DaGFuZ2U6IChzZWN0aW9uOiBDb21tYW5kU2VjdGlvbikgPT4gdm9pZDtcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQ29tbWFuZE5hdih7XG4gIGFjdGl2ZVNlY3Rpb24sXG4gIG9uU2VjdGlvbkNoYW5nZSxcbiAgY2xhc3NOYW1lLFxufTogQ29tbWFuZE5hdlByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPG5hdlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBib3JkZXItYiBib3JkZXItbGluZSBiZy1yYWlsIHB4LTMgcHktMlwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICBhcmlhLWxhYmVsPVwiQ29tbWFuZCBjZW50ZXIgbmF2aWdhdGlvblwiXG4gICAgPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IG1pbi13LTAgZmxleC0xIGl0ZW1zLWNlbnRlciBvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gc2hyaW5rLTAgaXRlbXMtY2VudGVyIGdhcC0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMSBweC0zIHB5LTIgeGw6ZmxleFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTkgdy05IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTIgdGV4dC1pbmstc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICA8Q3Jvc3NoYWlyIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGVhZGluZy1ub25lXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtbWVkaXVtIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAgICAgIENvbW1hbmQgR3JpZFxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPlxuICAgICAgICAgICAgICBTZWxsZXJGaSBPcHNcbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLTMgZmxleCBtaW4tdy0wIGZsZXgtMSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBwLTAuNVwiPlxuICAgICAgICAgIHtuYXZJdGVtcy5tYXAoKGl0ZW0pID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGlzQWN0aXZlID0gYWN0aXZlU2VjdGlvbiA9PT0gaXRlbS5pZDtcbiAgICAgICAgICAgIGNvbnN0IEljb24gPSBpdGVtLmljb247XG5cbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBrZXk9e2l0ZW0uaWR9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25TZWN0aW9uQ2hhbmdlKGl0ZW0uaWQpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICBcInJlbGF0aXZlIGZsZXggaC05IG1pbi13LVs2NHB4XSBmbGV4LTEgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHJvdW5kZWQtbWQgcHgtMi41XCIsXG4gICAgICAgICAgICAgICAgICBcInRleHQtWzEyLjVweF0gZm9udC1tZWRpdW1cIixcbiAgICAgICAgICAgICAgICAgIFwidHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCIsXG4gICAgICAgICAgICAgICAgICBcImZvY3VzLXZpc2libGU6b3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy1yaW5nIGZvY3VzLXZpc2libGU6cmluZy1vZmZzZXQtMSBmb2N1cy12aXNpYmxlOnJpbmctb2Zmc2V0LWJhY2tncm91bmRcIixcbiAgICAgICAgICAgICAgICAgIGlzQWN0aXZlXG4gICAgICAgICAgICAgICAgICAgID8gXCJiZy1zdXJmYWNlLTIgdGV4dC1pbmtcIlxuICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1pbmstc2Vjb25kYXJ5IGhvdmVyOnRleHQtaW5rXCJcbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIGFyaWEtY3VycmVudD17aXNBY3RpdmUgPyBcInBhZ2VcIiA6IHVuZGVmaW5lZH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtMy41IHctMy41IHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBoaWRkZW4gbWQ6aW5saW5lXCI+e2l0ZW0ubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlbGF0aXZlIGhpZGRlbiBzbTppbmxpbmUgbWQ6aGlkZGVuXCI+e2l0ZW0uc2hvcnRMYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9KX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L25hdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL2NvbXBvbmVudHMvQ29tbWFuZE5hdi50c3gifQ==