import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/HealthDashboard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { X } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { cn } from "/src/lib/utils.ts";
import { MetricBlock, MetricRow } from "/src/components/factory/MetricBlock.tsx";
import { StatusBadge } from "/src/components/factory/badges.tsx";
function statusTone(status) {
  switch (status) {
    case "healthy":
      return "success";
    case "degraded":
      return "warning";
    case "unhealthy":
      return "error";
    default:
      return "neutral";
  }
}
function statusDotClass(status) {
  switch (status) {
    case "healthy":
      return "bg-ok";
    case "degraded":
      return "bg-warn";
    case "unhealthy":
      return "bg-err";
    default:
      return "bg-ink-muted";
  }
}
export function HealthDashboard({ onClose }) {
  _s();
  const [, setRefreshKey] = useState(0);
  const healthStatus = useQuery(api.health.status, {});
  const metrics = useQuery(api.health.metrics, {});
  if (!healthStatus || !metrics) {
    return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[1000] flex items-center justify-center bg-black/70", children: /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-line bg-surface-1 p-10 text-[13px] text-ink-secondary", children: "Loading health status..." }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
      lineNumber: 70,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
      lineNumber: 69,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "fixed inset-0 z-[1000] flex items-center justify-center overflow-auto bg-black/70 p-5",
      onClick: onClose,
      children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "max-h-[90vh] w-full max-w-[1200px] overflow-auto rounded-xl border border-line bg-surface-1",
          onClick: (e) => e.stopPropagation(),
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-line p-6", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-[19px] font-semibold text-ink", children: "System health" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                  lineNumber: 89,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-[13px] text-ink-secondary", children: [
                  "Last updated: ",
                  (/* @__PURE__ */ new Date()).toLocaleTimeString()
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                  lineNumber: 90,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                lineNumber: 88,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: onClose,
                  "aria-label": "Close system health",
                  className: "rounded-md p-1.5 text-ink-muted transition-colors duration-150 hover:bg-surface-2 hover:text-ink",
                  children: /* @__PURE__ */ jsxDEV(X, { size: 16, strokeWidth: 1.75 }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                    lineNumber: 99,
                    columnNumber: 13
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                  lineNumber: 94,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
              lineNumber: 87,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "mb-6 rounded-xl border border-line bg-surface-2 p-5", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV(StatusBadge, { tone: statusTone(healthStatus.status), children: healthStatus.status.toUpperCase() }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                  lineNumber: 107,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[13.5px] text-ink-secondary", children: healthStatus.message }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                  lineNumber: 110,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                lineNumber: 106,
                columnNumber: 13
              }, this) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                lineNumber: 105,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3", children: Object.entries(healthStatus.checks).map(
                ([component, check]) => /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-line bg-surface-1 p-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "mb-2 flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "span",
                      {
                        className: cn("h-1.5 w-1.5 rounded-full", statusDotClass(check.status)),
                        "aria-hidden": true
                      },
                      void 0,
                      false,
                      {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                        lineNumber: 119,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] font-semibold capitalize text-ink", children: component }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                      lineNumber: 123,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                    lineNumber: 118,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] text-ink-muted", children: check.message }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                    lineNumber: 125,
                    columnNumber: 17
                  }, this),
                  check.responseTime && /* @__PURE__ */ jsxDEV("div", { className: "mt-1 font-mono text-[11.5px] text-ink-muted", children: [
                    "Response: ",
                    check.responseTime,
                    "ms"
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                    lineNumber: 127,
                    columnNumber: 15
                  }, this)
                ] }, component, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                  lineNumber: 117,
                  columnNumber: 13
                }, this)
              ) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                lineNumber: 115,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-line bg-surface-1 p-5", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-[15px] font-semibold text-ink", children: "System metrics" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                  lineNumber: 137,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV(MetricRow, { className: "border-b-0 pb-0 sm:grid-cols-3 xl:grid-cols-6", children: [
                  /* @__PURE__ */ jsxDEV(MetricBlock, { label: "Total projects", value: metrics.projects?.total || 0 }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                    lineNumber: 139,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    MetricBlock,
                    {
                      label: "Active agents",
                      value: metrics.agents?.active || 0,
                      detail: `${metrics.agents?.total || 0} total`
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                      lineNumber: 140,
                      columnNumber: 15
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    MetricBlock,
                    {
                      label: "Tasks",
                      value: metrics.tasks?.total || 0,
                      detail: `${metrics.tasks?.byStatus?.inProgress || 0} in progress`
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                      lineNumber: 145,
                      columnNumber: 15
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    MetricBlock,
                    {
                      label: "Pending approvals",
                      value: metrics.approvals?.pending || 0,
                      adornment: metrics.approvals?.pending > 0 ? /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "warning", children: "Action" }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                        lineNumber: 155,
                        columnNumber: 17
                      }, this) : void 0
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                      lineNumber: 150,
                      columnNumber: 15
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    MetricBlock,
                    {
                      label: "Open alerts",
                      value: metrics.alerts?.open || 0,
                      adornment: metrics.alerts?.open > 0 ? /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "error", children: "Open" }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                        lineNumber: 163,
                        columnNumber: 44
                      }, this) : void 0
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                      lineNumber: 159,
                      columnNumber: 15
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(MetricBlock, { label: "Uptime", value: healthStatus.uptime || "N/A" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                    lineNumber: 166,
                    columnNumber: 15
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                  lineNumber: 138,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                lineNumber: 136,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-4 text-center", children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setRefreshKey((k) => k + 1),
                  className: "inline-flex h-9 items-center rounded-lg bg-act px-3 text-[13px] font-medium text-act-ink transition-opacity duration-150 hover:opacity-90",
                  children: "Refresh now"
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                  lineNumber: 172,
                  columnNumber: 13
                },
                this
              ) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
                lineNumber: 171,
                columnNumber: 11
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
              lineNumber: 103,
              columnNumber: 9
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
          lineNumber: 82,
          columnNumber: 7
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx",
      lineNumber: 78,
      columnNumber: 5
    },
    this
  );
}
_s(HealthDashboard, "Jx1WoZB38xA0nZ6ea4SwwpIjqrw=", false, function() {
  return [useQuery, useQuery];
});
_c = HealthDashboard;
var _c;
$RefreshReg$(_c, "HealthDashboard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/HealthDashboard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0RROzs7Ozs7Ozs7Ozs7Ozs7OztBQWxEUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFdBQVc7QUFFcEIsU0FBU0MsU0FBUztBQUNsQixTQUFTQyxVQUFVO0FBQ25CLFNBQVNDLGFBQWFDLGlCQUFpQjtBQUN2QyxTQUFTQyxtQkFBMEM7QUFPbkQsU0FBU0MsV0FBV0MsUUFBMEM7QUFDNUQsVUFBUUEsUUFBTTtBQUFBLElBQ1osS0FBSztBQUNILGFBQU87QUFBQSxJQUNULEtBQUs7QUFDSCxhQUFPO0FBQUEsSUFDVCxLQUFLO0FBQ0gsYUFBTztBQUFBLElBQ1Q7QUFDRSxhQUFPO0FBQUEsRUFDWDtBQUNGO0FBRUEsU0FBU0MsZUFBZUQsUUFBd0I7QUFDOUMsVUFBUUEsUUFBTTtBQUFBLElBQ1osS0FBSztBQUNILGFBQU87QUFBQSxJQUNULEtBQUs7QUFDSCxhQUFPO0FBQUEsSUFDVCxLQUFLO0FBQ0gsYUFBTztBQUFBLElBQ1Q7QUFDRSxhQUFPO0FBQUEsRUFDWDtBQUNGO0FBRU8sZ0JBQVNFLGdCQUFnQixFQUFFQyxRQUE4QixHQUFHO0FBQUFDLEtBQUE7QUFHakUsUUFBTSxHQUFHQyxhQUFhLElBQUlkLFNBQVMsQ0FBQztBQUNwQyxRQUFNZSxlQUFlZCxTQUFTQyxJQUFJYyxPQUFPUCxRQUFRLENBQUMsQ0FBQztBQUNuRCxRQUFNUSxVQUFVaEIsU0FBU0MsSUFBSWMsT0FBT0MsU0FBUyxDQUFDLENBQUM7QUFFL0MsTUFBSSxDQUFDRixnQkFBZ0IsQ0FBQ0UsU0FBUztBQUM3QixXQUNFLHVCQUFDLFNBQUksV0FBVSx1RUFDYixpQ0FBQyxTQUFJLFdBQVUsa0ZBQWdGLHdDQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxFQUVKO0FBRUEsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVTtBQUFBLE1BQ1YsU0FBU0w7QUFBQUEsTUFFVDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVTtBQUFBLFVBQ1YsU0FBUyxDQUFDTSxNQUFNQSxFQUFFQyxnQkFBZ0I7QUFBQSxVQUdsQztBQUFBLG1DQUFDLFNBQUksV0FBVSw4REFDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsc0NBQXFDLDZCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnRTtBQUFBLGdCQUNoRSx1QkFBQyxPQUFFLFdBQVUsdUNBQXFDO0FBQUE7QUFBQSxtQkFDakMsb0JBQUlDLEtBQUssR0FBRUMsbUJBQW1CO0FBQUEscUJBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTVDtBQUFBQSxrQkFDVCxjQUFXO0FBQUEsa0JBQ1gsV0FBVTtBQUFBLGtCQUVWLGlDQUFDLEtBQUUsTUFBTSxJQUFJLGFBQWEsUUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQTtBQUFBLGdCQUxqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLGlCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBY0E7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxPQUViO0FBQUEscUNBQUMsU0FBSSxXQUFVLHVEQUNiLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHVDQUFDLGVBQVksTUFBTUosV0FBV08sYUFBYU4sTUFBTSxHQUM5Q00sdUJBQWFOLE9BQU9hLFlBQVksS0FEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxvQ0FBb0NQLHVCQUFhUSxXQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RTtBQUFBLG1CQUoxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLDZEQUNaQyxpQkFBT0MsUUFBUVYsYUFBYVcsTUFBTSxFQUFFQztBQUFBQSxnQkFBSSxDQUFDLENBQUNDLFdBQVdDLEtBQUssTUFDekQsdUJBQUMsU0FBb0IsV0FBVSxrREFDN0I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFXekIsR0FBRyw0QkFBNEJNLGVBQWVtQixNQUFNcEIsTUFBTSxDQUFDO0FBQUEsd0JBQ3RFLGVBQVc7QUFBQTtBQUFBLHNCQUZiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFFYTtBQUFBLG9CQUViLHVCQUFDLFNBQUksV0FBVSxpREFBaURtQix1QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMEU7QUFBQSx1QkFMNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxnQ0FBZ0NDLGdCQUFNTixXQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2RDtBQUFBLGtCQUM1RE0sTUFBTUMsZ0JBQ0wsdUJBQUMsU0FBSSxXQUFVLCtDQUE2QztBQUFBO0FBQUEsb0JBQy9DRCxNQUFNQztBQUFBQSxvQkFBYTtBQUFBLHVCQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBWk1GLFdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFjQTtBQUFBLGNBQ0QsS0FqQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFrQkE7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSxrREFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSwyQ0FBMEMsOEJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNFO0FBQUEsZ0JBQ3RFLHVCQUFDLGFBQVUsV0FBVSxpREFDbkI7QUFBQSx5Q0FBQyxlQUFZLE9BQU0sa0JBQWlCLE9BQU9YLFFBQVFjLFVBQVVDLFNBQVMsS0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0U7QUFBQSxrQkFDeEU7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FBTTtBQUFBLHNCQUNOLE9BQU9mLFFBQVFnQixRQUFRQyxVQUFVO0FBQUEsc0JBQ2pDLFFBQVEsR0FBR2pCLFFBQVFnQixRQUFRRCxTQUFTLENBQUM7QUFBQTtBQUFBLG9CQUh2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBR2dEO0FBQUEsa0JBRWhEO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU07QUFBQSxzQkFDTixPQUFPZixRQUFRa0IsT0FBT0gsU0FBUztBQUFBLHNCQUMvQixRQUFRLEdBQUdmLFFBQVFrQixPQUFPQyxVQUFVQyxjQUFjLENBQUM7QUFBQTtBQUFBLG9CQUhyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBR29FO0FBQUEsa0JBRXBFO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU07QUFBQSxzQkFDTixPQUFPcEIsUUFBUXFCLFdBQVdDLFdBQVc7QUFBQSxzQkFDckMsV0FDRXRCLFFBQVFxQixXQUFXQyxVQUFVLElBQzNCLHVCQUFDLGVBQVksTUFBSyxXQUFVLHNCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFrQyxJQUNoQ0M7QUFBQUE7QUFBQUEsb0JBTlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU9HO0FBQUEsa0JBRUg7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FBTTtBQUFBLHNCQUNOLE9BQU92QixRQUFRd0IsUUFBUUMsUUFBUTtBQUFBLHNCQUMvQixXQUNFekIsUUFBUXdCLFFBQVFDLE9BQU8sSUFBSSx1QkFBQyxlQUFZLE1BQUssU0FBUSxvQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBOEIsSUFBaUJGO0FBQUFBO0FBQUFBLG9CQUo5RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0c7QUFBQSxrQkFFSCx1QkFBQyxlQUFZLE9BQU0sVUFBUyxPQUFPekIsYUFBYTRCLFVBQVUsU0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0U7QUFBQSxxQkE1QmxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBNkJBO0FBQUEsbUJBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0NBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxNQUFNN0IsY0FBYyxDQUFDOEIsTUFBTUEsSUFBSSxDQUFDO0FBQUEsa0JBQ3pDLFdBQVU7QUFBQSxrQkFBMkk7QUFBQTtBQUFBLGdCQUZ2SjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxpQkEzRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE0RUE7QUFBQTtBQUFBO0FBQUEsUUFqR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Ba0dBO0FBQUE7QUFBQSxJQXRHRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUF1R0E7QUFFSjtBQUFDL0IsR0EzSGVGLGlCQUFlO0FBQUEsVUFJUlYsVUFDTEEsUUFBUTtBQUFBO0FBQUEsS0FMVlU7QUFBZSxJQUFBa0M7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VRdWVyeSIsImFwaSIsIlgiLCJjbiIsIk1ldHJpY0Jsb2NrIiwiTWV0cmljUm93IiwiU3RhdHVzQmFkZ2UiLCJzdGF0dXNUb25lIiwic3RhdHVzIiwic3RhdHVzRG90Q2xhc3MiLCJIZWFsdGhEYXNoYm9hcmQiLCJvbkNsb3NlIiwiX3MiLCJzZXRSZWZyZXNoS2V5IiwiaGVhbHRoU3RhdHVzIiwiaGVhbHRoIiwibWV0cmljcyIsImUiLCJzdG9wUHJvcGFnYXRpb24iLCJEYXRlIiwidG9Mb2NhbGVUaW1lU3RyaW5nIiwidG9VcHBlckNhc2UiLCJtZXNzYWdlIiwiT2JqZWN0IiwiZW50cmllcyIsImNoZWNrcyIsIm1hcCIsImNvbXBvbmVudCIsImNoZWNrIiwicmVzcG9uc2VUaW1lIiwicHJvamVjdHMiLCJ0b3RhbCIsImFnZW50cyIsImFjdGl2ZSIsInRhc2tzIiwiYnlTdGF0dXMiLCJpblByb2dyZXNzIiwiYXBwcm92YWxzIiwicGVuZGluZyIsInVuZGVmaW5lZCIsImFsZXJ0cyIsIm9wZW4iLCJ1cHRpbWUiLCJrIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSGVhbHRoRGFzaGJvYXJkLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgWCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5pbXBvcnQgeyBNZXRyaWNCbG9jaywgTWV0cmljUm93IH0gZnJvbSBcIi4vY29tcG9uZW50cy9mYWN0b3J5L01ldHJpY0Jsb2NrXCI7XG5pbXBvcnQgeyBTdGF0dXNCYWRnZSwgdHlwZSBTdGF0dXNCYWRnZVByb3BzIH0gZnJvbSBcIi4vY29tcG9uZW50cy9mYWN0b3J5L2JhZGdlc1wiO1xuXG5pbnRlcmZhY2UgSGVhbHRoRGFzaGJvYXJkUHJvcHMge1xuICBwcm9qZWN0SWQ6IElkPFwicHJvamVjdHNcIj4gfCBudWxsO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xufVxuXG5mdW5jdGlvbiBzdGF0dXNUb25lKHN0YXR1czogc3RyaW5nKTogU3RhdHVzQmFkZ2VQcm9wc1tcInRvbmVcIl0ge1xuICBzd2l0Y2ggKHN0YXR1cykge1xuICAgIGNhc2UgXCJoZWFsdGh5XCI6XG4gICAgICByZXR1cm4gXCJzdWNjZXNzXCI7XG4gICAgY2FzZSBcImRlZ3JhZGVkXCI6XG4gICAgICByZXR1cm4gXCJ3YXJuaW5nXCI7XG4gICAgY2FzZSBcInVuaGVhbHRoeVwiOlxuICAgICAgcmV0dXJuIFwiZXJyb3JcIjtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIFwibmV1dHJhbFwiO1xuICB9XG59XG5cbmZ1bmN0aW9uIHN0YXR1c0RvdENsYXNzKHN0YXR1czogc3RyaW5nKTogc3RyaW5nIHtcbiAgc3dpdGNoIChzdGF0dXMpIHtcbiAgICBjYXNlIFwiaGVhbHRoeVwiOlxuICAgICAgcmV0dXJuIFwiYmctb2tcIjtcbiAgICBjYXNlIFwiZGVncmFkZWRcIjpcbiAgICAgIHJldHVybiBcImJnLXdhcm5cIjtcbiAgICBjYXNlIFwidW5oZWFsdGh5XCI6XG4gICAgICByZXR1cm4gXCJiZy1lcnJcIjtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIFwiYmctaW5rLW11dGVkXCI7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEhlYWx0aERhc2hib2FyZCh7IG9uQ2xvc2UgfTogSGVhbHRoRGFzaGJvYXJkUHJvcHMpIHtcbiAgLy8gQ29udmV4IHF1ZXJpZXMgYXJlIHJlYWN0aXZlLCBidXQgdGhpcyBjb3VudGVyIGdpdmVzIHVzZXJzIGEgdmlzdWFsXG4gIC8vIFwiY2xpY2stdG8tcmVmcmVzaFwiIGFjdGlvbi4gVGhlIHNldHRlciBpcyB1c2VkIGJ5IHRoZSBidXR0b24gYmVsb3cuXG4gIGNvbnN0IFssIHNldFJlZnJlc2hLZXldID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IGhlYWx0aFN0YXR1cyA9IHVzZVF1ZXJ5KGFwaS5oZWFsdGguc3RhdHVzLCB7fSk7XG4gIGNvbnN0IG1ldHJpY3MgPSB1c2VRdWVyeShhcGkuaGVhbHRoLm1ldHJpY3MsIHt9KTtcblxuICBpZiAoIWhlYWx0aFN0YXR1cyB8fCAhbWV0cmljcykge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bMTAwMF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYmxhY2svNzBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgcC0xMCB0ZXh0LVsxM3B4XSB0ZXh0LWluay1zZWNvbmRhcnlcIj5cbiAgICAgICAgICBMb2FkaW5nIGhlYWx0aCBzdGF0dXMuLi5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzEwMDBdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG92ZXJmbG93LWF1dG8gYmctYmxhY2svNzAgcC01XCJcbiAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgPlxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9XCJtYXgtaC1bOTB2aF0gdy1mdWxsIG1heC13LVsxMjAwcHhdIG92ZXJmbG93LWF1dG8gcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xXCJcbiAgICAgICAgb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XG4gICAgICA+XG4gICAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1saW5lIHAtNlwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMTlweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPlN5c3RlbSBoZWFsdGg8L2gyPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LVsxM3B4XSB0ZXh0LWluay1zZWNvbmRhcnlcIj5cbiAgICAgICAgICAgICAgTGFzdCB1cGRhdGVkOiB7bmV3IERhdGUoKS50b0xvY2FsZVRpbWVTdHJpbmcoKX1cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkNsb3NlIHN5c3RlbSBoZWFsdGhcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBwLTEuNSB0ZXh0LWluay1tdXRlZCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgaG92ZXI6Ymctc3VyZmFjZS0yIGhvdmVyOnRleHQtaW5rXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8WCBzaXplPXsxNn0gc3Ryb2tlV2lkdGg9ezEuNzV9IC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XG4gICAgICAgICAgey8qIE92ZXJhbGwgU3RhdHVzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTIgcC01XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxTdGF0dXNCYWRnZSB0b25lPXtzdGF0dXNUb25lKGhlYWx0aFN0YXR1cy5zdGF0dXMpfT5cbiAgICAgICAgICAgICAgICB7aGVhbHRoU3RhdHVzLnN0YXR1cy50b1VwcGVyQ2FzZSgpfVxuICAgICAgICAgICAgICA8L1N0YXR1c0JhZGdlPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEzLjVweF0gdGV4dC1pbmstc2Vjb25kYXJ5XCI+e2hlYWx0aFN0YXR1cy5tZXNzYWdlfTwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ29tcG9uZW50IFN0YXR1cyBHcmlkICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBncmlkIGdyaWQtY29scy0xIGdhcC00IHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zXCI+XG4gICAgICAgICAgICB7T2JqZWN0LmVudHJpZXMoaGVhbHRoU3RhdHVzLmNoZWNrcykubWFwKChbY29tcG9uZW50LCBjaGVja106IFtzdHJpbmcsIGFueV0pID0+IChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e2NvbXBvbmVudH0gY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xIHAtNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcImgtMS41IHctMS41IHJvdW5kZWQtZnVsbFwiLCBzdGF0dXNEb3RDbGFzcyhjaGVjay5zdGF0dXMpKX1cbiAgICAgICAgICAgICAgICAgICAgYXJpYS1oaWRkZW5cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgY2FwaXRhbGl6ZSB0ZXh0LWlua1wiPntjb21wb25lbnR9PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMi41cHhdIHRleHQtaW5rLW11dGVkXCI+e2NoZWNrLm1lc3NhZ2V9PC9kaXY+XG4gICAgICAgICAgICAgICAge2NoZWNrLnJlc3BvbnNlVGltZSAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgZm9udC1tb25vIHRleHQtWzExLjVweF0gdGV4dC1pbmstbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgUmVzcG9uc2U6IHtjaGVjay5yZXNwb25zZVRpbWV9bXNcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogTWV0cmljcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMSBwLTVcIj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj5TeXN0ZW0gbWV0cmljczwvaDM+XG4gICAgICAgICAgICA8TWV0cmljUm93IGNsYXNzTmFtZT1cImJvcmRlci1iLTAgcGItMCBzbTpncmlkLWNvbHMtMyB4bDpncmlkLWNvbHMtNlwiPlxuICAgICAgICAgICAgICA8TWV0cmljQmxvY2sgbGFiZWw9XCJUb3RhbCBwcm9qZWN0c1wiIHZhbHVlPXttZXRyaWNzLnByb2plY3RzPy50b3RhbCB8fCAwfSAvPlxuICAgICAgICAgICAgICA8TWV0cmljQmxvY2tcbiAgICAgICAgICAgICAgICBsYWJlbD1cIkFjdGl2ZSBhZ2VudHNcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXttZXRyaWNzLmFnZW50cz8uYWN0aXZlIHx8IDB9XG4gICAgICAgICAgICAgICAgZGV0YWlsPXtgJHttZXRyaWNzLmFnZW50cz8udG90YWwgfHwgMH0gdG90YWxgfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8TWV0cmljQmxvY2tcbiAgICAgICAgICAgICAgICBsYWJlbD1cIlRhc2tzXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17bWV0cmljcy50YXNrcz8udG90YWwgfHwgMH1cbiAgICAgICAgICAgICAgICBkZXRhaWw9e2Ake21ldHJpY3MudGFza3M/LmJ5U3RhdHVzPy5pblByb2dyZXNzIHx8IDB9IGluIHByb2dyZXNzYH1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPE1ldHJpY0Jsb2NrXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJQZW5kaW5nIGFwcHJvdmFsc1wiXG4gICAgICAgICAgICAgICAgdmFsdWU9e21ldHJpY3MuYXBwcm92YWxzPy5wZW5kaW5nIHx8IDB9XG4gICAgICAgICAgICAgICAgYWRvcm5tZW50PXtcbiAgICAgICAgICAgICAgICAgIG1ldHJpY3MuYXBwcm92YWxzPy5wZW5kaW5nID4gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgPFN0YXR1c0JhZGdlIHRvbmU9XCJ3YXJuaW5nXCI+QWN0aW9uPC9TdGF0dXNCYWRnZT5cbiAgICAgICAgICAgICAgICAgICkgOiB1bmRlZmluZWRcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxNZXRyaWNCbG9ja1xuICAgICAgICAgICAgICAgIGxhYmVsPVwiT3BlbiBhbGVydHNcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXttZXRyaWNzLmFsZXJ0cz8ub3BlbiB8fCAwfVxuICAgICAgICAgICAgICAgIGFkb3JubWVudD17XG4gICAgICAgICAgICAgICAgICBtZXRyaWNzLmFsZXJ0cz8ub3BlbiA+IDAgPyA8U3RhdHVzQmFkZ2UgdG9uZT1cImVycm9yXCI+T3BlbjwvU3RhdHVzQmFkZ2U+IDogdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8TWV0cmljQmxvY2sgbGFiZWw9XCJVcHRpbWVcIiB2YWx1ZT17aGVhbHRoU3RhdHVzLnVwdGltZSB8fCBcIk4vQVwifSAvPlxuICAgICAgICAgICAgPC9NZXRyaWNSb3c+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUmVmcmVzaCBCdXR0b24gKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJlZnJlc2hLZXkoKGspID0+IGsgKyAxKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaC05IGl0ZW1zLWNlbnRlciByb3VuZGVkLWxnIGJnLWFjdCBweC0zIHRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtYWN0LWluayB0cmFuc2l0aW9uLW9wYWNpdHkgZHVyYXRpb24tMTUwIGhvdmVyOm9wYWNpdHktOTBcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBSZWZyZXNoIG5vd1xuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9IZWFsdGhEYXNoYm9hcmQudHN4In0=