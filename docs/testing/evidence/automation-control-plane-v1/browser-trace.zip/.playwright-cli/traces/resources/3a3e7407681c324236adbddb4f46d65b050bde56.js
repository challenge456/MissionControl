import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/GoalsView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { useQuery, useMutation } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { cn } from "/src/lib/utils.ts";
import { PageHeader } from "/src/components/PageHeader.tsx";
import { Card } from "/src/components/ui/card.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { EmptyState } from "/src/components/ui/empty-state.tsx";
import { StatusBadge } from "/src/components/factory/badges.tsx";
import { MetricBlock } from "/src/components/factory/MetricBlock.tsx";
import {
  Target,
  Building2,
  Users,
  Bot,
  ClipboardList,
  ChevronRight,
  Plus
} from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
const LEVEL_CONFIG = {
  COMPANY: { label: "Company", icon: Building2 },
  TEAM: { label: "Team", icon: Users },
  AGENT: { label: "Agent", icon: Bot },
  TASK: { label: "Task", icon: ClipboardList }
};
const STATUS_CONFIG = {
  PLANNED: { label: "Planned", badge: "border-line bg-surface-2 text-ink-secondary" },
  ACTIVE: { label: "Active", badge: "border-transparent bg-info-soft text-info-accent" },
  ACHIEVED: { label: "Achieved", badge: "border-transparent bg-ok-soft text-ok" },
  CANCELLED: { label: "Cancelled", badge: "border-transparent bg-err-soft text-err" }
};
function CreateGoalModal({ projectId, parentGoalId, defaultLevel, onClose }) {
  _s();
  const createGoal = useMutation(api.goals.create);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [level, setLevel] = useState(defaultLevel);
  const [saving, setSaving] = useState(false);
  const handleSubmit = async () => {
    if (!title.trim()) return;
    setSaving(true);
    try {
      await createGoal({
        projectId,
        title: title.trim(),
        description: description.trim() || void 0,
        level,
        parentGoalId
      });
      onClose();
    } catch {
      setSaving(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/60", onClick: onClose, children: /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "w-full max-w-md rounded-xl border border-line bg-surface-3 p-6 shadow-[var(--shadow-elevation-2)]",
      onClick: (e) => e.stopPropagation(),
      children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[15px] font-semibold text-ink mb-4", children: parentGoalId ? "Add Sub-Goal" : "Create Goal" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 105,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[12.5px] font-medium text-ink-secondary mb-1", children: "Title" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 111,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: title,
                onChange: (e) => setTitle(e.target.value),
                placeholder: "e.g., Reach $1M ARR by Q3",
                className: "w-full h-9 rounded-lg border border-line bg-surface-1 px-3 text-[13.5px] text-ink placeholder:text-ink-muted focus:outline-none focus:ring-2 focus:ring-ring",
                autoFocus: true
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                lineNumber: 112,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 110,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[12.5px] font-medium text-ink-secondary mb-1", children: "Description" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 123,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                value: description,
                onChange: (e) => setDescription(e.target.value),
                placeholder: "Why does this goal matter?",
                rows: 3,
                className: "w-full rounded-lg border border-line bg-surface-1 px-3 py-2 text-[13.5px] text-ink placeholder:text-ink-muted focus:outline-none focus:ring-2 focus:ring-ring resize-none"
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                lineNumber: 124,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 122,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[12.5px] font-medium text-ink-secondary mb-1", children: "Level" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 134,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1 rounded-lg border border-line p-0.5 w-fit", children: ["COMPANY", "TEAM", "AGENT", "TASK"].map(
              (l) => /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setLevel(l),
                  className: cn(
                    "px-3 py-1.5 rounded-md text-xs font-medium transition-colors duration-150",
                    level === l ? "bg-surface-2 text-ink" : "text-ink-secondary hover:text-ink"
                  ),
                  children: LEVEL_CONFIG[l].label
                },
                l,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                  lineNumber: 137,
                  columnNumber: 15
                },
                this
              )
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 135,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 133,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 109,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2 mt-6", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: onClose,
              className: "h-9 px-3 rounded-lg border border-line text-[13px] font-medium text-ink-secondary hover:text-ink hover:border-line-strong transition-colors duration-150",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 155,
              columnNumber: 11
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handleSubmit,
              disabled: !title.trim() || saving,
              className: "h-9 px-3 rounded-lg bg-act text-act-ink text-[13px] font-medium hover:opacity-90 disabled:opacity-50 transition-colors duration-150",
              children: saving ? "Creating..." : "Create Goal"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 161,
              columnNumber: 11
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 154,
          columnNumber: 9
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
      lineNumber: 101,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
    lineNumber: 100,
    columnNumber: 5
  }, this);
}
_s(CreateGoalModal, "davdo5jWTFSf9O9/JUM5GaP1il0=", false, function() {
  return [useMutation];
});
_c = CreateGoalModal;
const TASK_DOT = {
  DONE: "bg-ok",
  IN_PROGRESS: "bg-info-accent",
  BLOCKED: "bg-warn",
  FAILED: "bg-err"
};
function GoalNode({ node, depth, projectId, onTaskSelect }) {
  _s2();
  const [expanded, setExpanded] = useState(depth < 2);
  const [showCreate, setShowCreate] = useState(false);
  const [showDetail, setShowDetail] = useState(false);
  const updateGoal = useMutation(api.goals.update);
  const linkedTasks = useQuery(api.goals.getLinkedTasks, { goalId: node._id });
  const levelCfg = LEVEL_CONFIG[node.level];
  const LevelIcon = levelCfg.icon;
  const statusCfg = STATUS_CONFIG[node.status];
  const hasChildren = node.children.length > 0;
  const taskCount = linkedTasks?.length ?? 0;
  const doneCount = linkedTasks?.filter((t) => t.status === "DONE").length ?? 0;
  const nextLevel = () => {
    if (node.level === "COMPANY") return "TEAM";
    if (node.level === "TEAM") return "AGENT";
    return "TASK";
  };
  const handleStatusCycle = async () => {
    const order = ["PLANNED", "ACTIVE", "ACHIEVED", "CANCELLED"];
    const idx = order.indexOf(node.status);
    const next = order[(idx + 1) % order.length];
    await updateGoal({ goalId: node._id, status: next });
  };
  return /* @__PURE__ */ jsxDEV("div", { className: cn("border-l border-line", depth > 0 && "ml-6"), children: [
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: cn(
          "group flex items-start gap-3 px-4 py-3 rounded-lg transition-colors duration-150 cursor-pointer",
          "hover:bg-surface-2",
          showDetail && "bg-surface-2"
        ),
        onClick: () => setShowDetail(!showDetail),
        children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: (e) => {
                e.stopPropagation();
                setExpanded(!expanded);
              },
              className: cn(
                "mt-0.5 w-5 h-5 flex items-center justify-center rounded text-ink-muted transition-transform duration-150",
                expanded && "rotate-90",
                !hasChildren && taskCount === 0 && "invisible"
              ),
              "aria-label": expanded ? "Collapse" : "Expand",
              children: /* @__PURE__ */ jsxDEV(ChevronRight, { size: 14, strokeWidth: 1.6, "aria-hidden": true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                lineNumber: 251,
                columnNumber: 11
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 242,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(LevelIcon, { size: 16, strokeWidth: 1.6, className: "mt-0.5 shrink-0 text-ink-muted", "aria-hidden": true }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 255,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-[13.5px] text-ink truncate", children: node.title }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                lineNumber: 260,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] text-ink-muted", children: levelCfg.label }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                lineNumber: 261,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 259,
              columnNumber: 11
            }, this),
            showDetail && node.description && /* @__PURE__ */ jsxDEV("p", { className: "text-[12.5px] text-ink-muted mt-1 leading-relaxed", children: node.description }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 267,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mt-1", children: [
              taskCount > 0 && /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] text-ink-muted", children: [
                doneCount,
                "/",
                taskCount,
                " tasks"
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                lineNumber: 273,
                columnNumber: 13
              }, this),
              node.progressPct !== void 0 && node.progressPct > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-1.5 rounded-full bg-surface-2 overflow-hidden", children: /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "h-full rounded-full bg-ok transition-all duration-150",
                    style: { width: `${Math.min(100, node.progressPct)}%` }
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                    lineNumber: 280,
                    columnNumber: 19
                  },
                  this
                ) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                  lineNumber: 279,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] text-ink-muted", children: [
                  Math.round(node.progressPct),
                  "%"
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                  lineNumber: 285,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                lineNumber: 278,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 271,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 258,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: (e) => {
                e.stopPropagation();
                handleStatusCycle();
              },
              className: cn(
                "inline-flex items-center rounded-md border px-1.5 py-0.5 text-[11.5px] font-medium leading-none transition-colors duration-150",
                statusCfg.badge
              ),
              title: "Click to cycle status",
              children: statusCfg.label
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 292,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: (e) => {
                e.stopPropagation();
                setShowCreate(true);
              },
              className: "opacity-0 group-hover:opacity-100 mt-0.5 w-6 h-6 flex items-center justify-center rounded text-ink-muted hover:text-ink hover:bg-surface-2 transition-colors duration-150",
              title: "Add sub-goal",
              "aria-label": "Add sub-goal",
              children: /* @__PURE__ */ jsxDEV(Plus, { size: 14, strokeWidth: 1.6, "aria-hidden": true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                lineNumber: 310,
                columnNumber: 11
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 304,
              columnNumber: 9
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
        lineNumber: 233,
        columnNumber: 7
      },
      this
    ),
    expanded && showDetail && linkedTasks && linkedTasks.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "ml-14 mb-2 space-y-1", children: linkedTasks.map(
      (task) => /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => onTaskSelect?.(task._id),
          className: "flex items-center gap-2 w-full text-left px-3 py-1.5 rounded-md text-[12.5px] hover:bg-surface-2 transition-colors duration-150",
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: cn(
              "w-1.5 h-1.5 rounded-full",
              TASK_DOT[task.status] ?? "bg-ink-muted/50"
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 323,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-ink-muted font-mono mr-1", children: task.identifier ?? "" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 327,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-ink truncate", children: task.title }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 328,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] text-ink-muted ml-auto", children: task.status }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 329,
              columnNumber: 15
            }, this)
          ]
        },
        task._id,
        true,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 318,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
      lineNumber: 316,
      columnNumber: 7
    }, this),
    expanded && node.children.map(
      (child) => /* @__PURE__ */ jsxDEV(
        GoalNode,
        {
          node: child,
          depth: depth + 1,
          projectId,
          onTaskSelect
        },
        child._id,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 337,
          columnNumber: 7
        },
        this
      )
    ),
    showCreate && /* @__PURE__ */ jsxDEV(
      CreateGoalModal,
      {
        projectId,
        parentGoalId: node._id,
        defaultLevel: nextLevel(),
        onClose: () => setShowCreate(false)
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
        lineNumber: 347,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
    lineNumber: 232,
    columnNumber: 5
  }, this);
}
_s2(GoalNode, "tLVt41RxwtPO7BF2GXwZ0BJJ4dw=", false, function() {
  return [useMutation, useQuery];
});
_c2 = GoalNode;
export function GoalsView({ projectId, onTaskSelect }) {
  _s3();
  const [showCreate, setShowCreate] = useState(false);
  const [statusFilter, setStatusFilter] = useState("ALL");
  const hierarchy = useQuery(
    api.goals.getHierarchy,
    projectId ? { projectId } : "skip"
  );
  if (!projectId) {
    return /* @__PURE__ */ jsxDEV("section", { className: "flex min-h-0 flex-1 flex-col overflow-y-auto bg-app", children: [
      /* @__PURE__ */ jsxDEV(
        PageHeader,
        {
          title: "Goals",
          description: "Track the hierarchy between company goals, team goals, and task execution.",
          icon: /* @__PURE__ */ jsxDEV(Target, { className: "h-4.5 w-4.5", strokeWidth: 1.7 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 377,
            columnNumber: 17
          }, this),
          eyebrow: "Operations"
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 374,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "mx-auto max-w-[1200px] px-6 py-6", children: /* @__PURE__ */ jsxDEV(
        EmptyState,
        {
          icon: Target,
          title: "No project selected",
          description: "Select a project to view goals."
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 381,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
        lineNumber: 380,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
      lineNumber: 373,
      columnNumber: 7
    }, this);
  }
  const filteredHierarchy = hierarchy?.filter((root) => {
    if (statusFilter === "ALL") return true;
    return root.status === statusFilter;
  });
  const topLevelGoals = hierarchy ?? [];
  const activeGoals = topLevelGoals.filter((goal) => goal.status === "ACTIVE").length;
  const achievedGoals = topLevelGoals.filter((goal) => goal.status === "ACHIEVED").length;
  const plannedGoals = topLevelGoals.filter((goal) => goal.status === "PLANNED").length;
  return /* @__PURE__ */ jsxDEV("section", { className: "flex min-h-0 flex-1 flex-col overflow-hidden bg-app", children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: "Goals",
        description: "Every task should trace back to a real goal. If you cannot explain why it matters, it should not be in the system.",
        icon: /* @__PURE__ */ jsxDEV(Target, { className: "h-4.5 w-4.5", strokeWidth: 1.7 }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 405,
          columnNumber: 15
        }, this),
        eyebrow: "Operations",
        status: /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", children: [
          topLevelGoals.length,
          " top-level goals"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 408,
          columnNumber: 9
        }, this),
        actions: /* @__PURE__ */ jsxDEV(Button, { onClick: () => setShowCreate(true), size: "sm", children: [
          /* @__PURE__ */ jsxDEV(Target, { className: "h-3.5 w-3.5 mr-1.5", strokeWidth: 1.7 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 412,
            columnNumber: 13
          }, this),
          "New Goal"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 411,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
        lineNumber: 402,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "mx-auto flex min-h-0 w-full max-w-[1200px] flex-1 flex-col gap-4 overflow-hidden px-6 pb-6 pt-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid shrink-0 gap-4 md:grid-cols-4", children: [
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Top level",
            value: topLevelGoals.length,
            detail: "Company-level direction currently tracked"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 420,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 419,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Active",
            value: activeGoals,
            detail: "Goals currently driving execution"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 427,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 426,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Achieved",
            value: achievedGoals,
            detail: "Goals that have already closed the loop"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 434,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 433,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Planned",
            value: plannedGoals,
            detail: "Ideas not yet shaping execution"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 441,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 440,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
        lineNumber: 418,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "shrink-0 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-3 overflow-x-auto flex-nowrap", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-[15px] font-semibold text-ink", children: "Goal filters" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 452,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-[12.5px] text-ink-muted", children: "Focus the goal tree by lifecycle state" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 453,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 451,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1 rounded-lg border border-line p-0.5", children: ["ALL", "ACTIVE", "PLANNED", "ACHIEVED", "CANCELLED"].map(
          (s) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setStatusFilter(s),
              className: cn(
                "rounded-md px-3 py-1.5 text-xs font-medium transition-colors duration-150",
                statusFilter === s ? "bg-surface-2 text-ink" : "text-ink-secondary hover:text-ink"
              ),
              children: s === "ALL" ? "All" : STATUS_CONFIG[s].label
            },
            s,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 457,
              columnNumber: 15
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 455,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
        lineNumber: 450,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
        lineNumber: 449,
        columnNumber: 9
      }, this),
      !hierarchy ? /* @__PURE__ */ jsxDEV(Card, { className: "flex flex-col gap-3 p-6", "aria-label": "Loading goals", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "h-3.5 w-2/3 animate-pulse rounded bg-surface-2" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 476,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "h-3.5 w-1/2 animate-pulse rounded bg-surface-2" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 477,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "h-3.5 w-3/5 animate-pulse rounded bg-surface-2" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 478,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
        lineNumber: 475,
        columnNumber: 9
      }, this) : filteredHierarchy && filteredHierarchy.length === 0 ? /* @__PURE__ */ jsxDEV(
        EmptyState,
        {
          icon: Target,
          title: statusFilter === "ALL" ? "No goals yet" : `No ${statusFilter.toLowerCase()} goals`,
          description: statusFilter === "ALL" ? "Start by defining your company mission." : void 0,
          action: statusFilter === "ALL" ? /* @__PURE__ */ jsxDEV(Button, { onClick: () => setShowCreate(true), size: "sm", children: "Create First Goal" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 491,
            columnNumber: 11
          }, this) : void 0
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 481,
          columnNumber: 9
        },
        this
      ) : /* @__PURE__ */ jsxDEV("div", { className: "grid min-h-0 flex-1 gap-4 overflow-y-auto xl:grid-cols-[minmax(0,1fr)_320px]", children: [
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-[15px] font-semibold text-ink", children: "Goal tree" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 501,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-[12.5px] text-ink-muted", children: "Execution should ladder into strategy" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 502,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 500,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: filteredHierarchy?.map(
            (root) => /* @__PURE__ */ jsxDEV(
              GoalNode,
              {
                node: root,
                depth: 0,
                projectId,
                onTaskSelect
              },
              root._id,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                lineNumber: 506,
                columnNumber: 15
              },
              this
            )
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 504,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 499,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-[15px] font-semibold text-ink", children: "Operator guidance" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 518,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-2 space-y-3 text-[13.5px] leading-relaxed text-ink-secondary", children: [
            /* @__PURE__ */ jsxDEV("p", { children: "Goals should stay few, sharp, and causal. If a task cannot trace back to a goal, it is work without a reason." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 520,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "Use company goals to set direction, team goals to route ownership, and task goals only when work needs measurable closure." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 521,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 519,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-4 rounded-xl border border-line bg-surface-2 p-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-[11.5px] font-medium text-ink-muted", children: "Current mix" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 524,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-3 grid gap-2 text-[13.5px]", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-ink-secondary", children: "Active" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                  lineNumber: 527,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-ink", children: activeGoals }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                  lineNumber: 528,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                lineNumber: 526,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-ink-secondary", children: "Planned" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                  lineNumber: 531,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-ink", children: plannedGoals }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                  lineNumber: 532,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                lineNumber: 530,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-ink-secondary", children: "Achieved" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                  lineNumber: 535,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-ink", children: achievedGoals }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                  lineNumber: 536,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
                lineNumber: 534,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
              lineNumber: 525,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
            lineNumber: 523,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 517,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
        lineNumber: 498,
        columnNumber: 9
      }, this),
      showCreate && /* @__PURE__ */ jsxDEV(
        CreateGoalModal,
        {
          projectId,
          defaultLevel: "COMPANY",
          onClose: () => setShowCreate(false)
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
          lineNumber: 545,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
      lineNumber: 417,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx",
    lineNumber: 401,
    columnNumber: 5
  }, this);
}
_s3(GoalsView, "rhPU+HQmWCr1/nmmT8Achj+gzms=", false, function() {
  return [useQuery];
});
_c3 = GoalsView;
var _c, _c2, _c3;
$RefreshReg$(_c, "CreateGoalModal");
$RefreshReg$(_c2, "GoalNode");
$RefreshReg$(_c3, "GoalsView");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/GoalsView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUZROzs7Ozs7Ozs7Ozs7Ozs7OztBQXJGUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsVUFBVUMsbUJBQW1CO0FBQ3RDLFNBQVNDLFdBQVc7QUFFcEIsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsbUJBQW1CO0FBQzVCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FFSztBQVVQLE1BQU1DLGVBQXVFO0FBQUEsRUFDM0VDLFNBQVMsRUFBRUMsT0FBTyxXQUFXQyxNQUFNVCxVQUFVO0FBQUEsRUFDN0NVLE1BQU0sRUFBRUYsT0FBTyxRQUFRQyxNQUFNUixNQUFNO0FBQUEsRUFDbkNVLE9BQU8sRUFBRUgsT0FBTyxTQUFTQyxNQUFNUCxJQUFJO0FBQUEsRUFDbkNVLE1BQU0sRUFBRUosT0FBTyxRQUFRQyxNQUFNTixjQUFjO0FBQzdDO0FBRUEsTUFBTVUsZ0JBQXNFO0FBQUEsRUFDMUVDLFNBQVMsRUFBRU4sT0FBTyxXQUFXTyxPQUFPLDhDQUE4QztBQUFBLEVBQ2xGQyxRQUFRLEVBQUVSLE9BQU8sVUFBVU8sT0FBTyxtREFBbUQ7QUFBQSxFQUNyRkUsVUFBVSxFQUFFVCxPQUFPLFlBQVlPLE9BQU8sd0NBQXdDO0FBQUEsRUFDOUVHLFdBQVcsRUFBRVYsT0FBTyxhQUFhTyxPQUFPLDBDQUEwQztBQUNwRjtBQWFBLFNBQVNJLGdCQUFnQixFQUFFQyxXQUFXQyxjQUFjQyxjQUFjQyxRQUE4QixHQUFHO0FBQUFDLEtBQUE7QUFDakcsUUFBTUMsYUFBYW5DLFlBQVlDLElBQUltQyxNQUFNQyxNQUFNO0FBQy9DLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJekMsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQzBDLGFBQWFDLGNBQWMsSUFBSTNDLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUM0QyxPQUFPQyxRQUFRLElBQUk3QyxTQUFvQmtDLFlBQVk7QUFDMUQsUUFBTSxDQUFDWSxRQUFRQyxTQUFTLElBQUkvQyxTQUFTLEtBQUs7QUFFMUMsUUFBTWdELGVBQWUsWUFBWTtBQUMvQixRQUFJLENBQUNSLE1BQU1TLEtBQUssRUFBRztBQUNuQkYsY0FBVSxJQUFJO0FBQ2QsUUFBSTtBQUNGLFlBQU1WLFdBQVc7QUFBQSxRQUNmTDtBQUFBQSxRQUNBUSxPQUFPQSxNQUFNUyxLQUFLO0FBQUEsUUFDbEJQLGFBQWFBLFlBQVlPLEtBQUssS0FBS0M7QUFBQUEsUUFDbkNOO0FBQUFBLFFBQ0FYO0FBQUFBLE1BQ0YsQ0FBQztBQUNERSxjQUFRO0FBQUEsSUFDVixRQUFRO0FBQ05ZLGdCQUFVLEtBQUs7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxtRUFBa0UsU0FBU1osU0FDeEY7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVU7QUFBQSxNQUNWLFNBQVMsQ0FBQ2dCLE1BQU1BLEVBQUVDLGdCQUFnQjtBQUFBLE1BRWxDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDJDQUNYbkIseUJBQWUsaUJBQWlCLGlCQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSwyREFBMEQscUJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdGO0FBQUEsWUFDaEY7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT087QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDVyxNQUFNVixTQUFTVSxFQUFFRSxPQUFPQyxLQUFLO0FBQUEsZ0JBQ3hDLGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUEsZ0JBQ1YsV0FBUztBQUFBO0FBQUEsY0FOWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNVztBQUFBLGVBUmI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSwyREFBMEQsMkJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNGO0FBQUEsWUFDdEY7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPWjtBQUFBQSxnQkFDUCxVQUFVLENBQUNTLE1BQU1SLGVBQWVRLEVBQUVFLE9BQU9DLEtBQUs7QUFBQSxnQkFDOUMsYUFBWTtBQUFBLGdCQUNaLE1BQU07QUFBQSxnQkFDTixXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUt1TDtBQUFBLGVBUHpMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsMkRBQTBELHFCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRjtBQUFBLFlBQ2hGLHVCQUFDLFNBQUksV0FBVSx3REFDWCxXQUFDLFdBQVcsUUFBUSxTQUFTLE1BQU0sRUFBa0JDO0FBQUFBLGNBQUksQ0FBQ0MsTUFDMUQ7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUMsU0FBUyxNQUFNWCxTQUFTVyxDQUFDO0FBQUEsa0JBQ3pCLFdBQVdwRDtBQUFBQSxvQkFDVDtBQUFBLG9CQUNBd0MsVUFBVVksSUFDTiwwQkFDQTtBQUFBLGtCQUNOO0FBQUEsa0JBRUN0Qyx1QkFBYXNDLENBQUMsRUFBRXBDO0FBQUFBO0FBQUFBLGdCQVRab0M7QUFBQUEsZ0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVdBO0FBQUEsWUFDRCxLQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxlQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLGFBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyQ0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTckI7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FBMEo7QUFBQTtBQUFBLFlBRnRLO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBU2E7QUFBQUEsY0FDVCxVQUFVLENBQUNSLE1BQU1TLEtBQUssS0FBS0g7QUFBQUEsY0FDM0IsV0FBVTtBQUFBLGNBRVRBLG1CQUFTLGdCQUFnQjtBQUFBO0FBQUEsWUFMNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxhQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBO0FBQUE7QUFBQSxJQW5FRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFvRUEsS0FyRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNFQTtBQUVKO0FBSUFWLEdBckdTTCxpQkFBZTtBQUFBLFVBQ0g3QixXQUFXO0FBQUE7QUFBQSxLQUR2QjZCO0FBMEhULE1BQU0wQixXQUFtQztBQUFBLEVBQ3ZDQyxNQUFNO0FBQUEsRUFDTkMsYUFBYTtBQUFBLEVBQ2JDLFNBQVM7QUFBQSxFQUNUQyxRQUFRO0FBQ1Y7QUFFQSxTQUFTQyxTQUFTLEVBQUVDLE1BQU1DLE9BQU9oQyxXQUFXaUMsYUFBNEIsR0FBRztBQUFBQyxNQUFBO0FBQ3pFLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJcEUsU0FBU2dFLFFBQVEsQ0FBQztBQUNsRCxRQUFNLENBQUNLLFlBQVlDLGFBQWEsSUFBSXRFLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUN1RSxZQUFZQyxhQUFhLElBQUl4RSxTQUFTLEtBQUs7QUFDbEQsUUFBTXlFLGFBQWF2RSxZQUFZQyxJQUFJbUMsTUFBTW9DLE1BQU07QUFFL0MsUUFBTUMsY0FBYzFFLFNBQVNFLElBQUltQyxNQUFNc0MsZ0JBQWdCLEVBQUVDLFFBQVFkLEtBQUtlLElBQUksQ0FBQztBQUMzRSxRQUFNQyxXQUFXN0QsYUFBYTZDLEtBQUtuQixLQUFLO0FBQ3hDLFFBQU1vQyxZQUFZRCxTQUFTMUQ7QUFDM0IsUUFBTTRELFlBQVl4RCxjQUFjc0MsS0FBS21CLE1BQU07QUFDM0MsUUFBTUMsY0FBY3BCLEtBQUtxQixTQUFTQyxTQUFTO0FBQzNDLFFBQU1DLFlBQVlYLGFBQWFVLFVBQVU7QUFDekMsUUFBTUUsWUFBWVosYUFBYWEsT0FBTyxDQUFDQyxNQUFNQSxFQUFFUCxXQUFXLE1BQU0sRUFBRUcsVUFBVTtBQUU1RSxRQUFNSyxZQUFZQSxNQUFpQjtBQUNqQyxRQUFJM0IsS0FBS25CLFVBQVUsVUFBVyxRQUFPO0FBQ3JDLFFBQUltQixLQUFLbkIsVUFBVSxPQUFRLFFBQU87QUFDbEMsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNK0Msb0JBQW9CLFlBQVk7QUFDcEMsVUFBTUMsUUFBc0IsQ0FBQyxXQUFXLFVBQVUsWUFBWSxXQUFXO0FBQ3pFLFVBQU1DLE1BQU1ELE1BQU1FLFFBQVEvQixLQUFLbUIsTUFBTTtBQUNyQyxVQUFNYSxPQUFPSCxPQUFPQyxNQUFNLEtBQUtELE1BQU1QLE1BQU07QUFDM0MsVUFBTVosV0FBVyxFQUFFSSxRQUFRZCxLQUFLZSxLQUFLSSxRQUFRYSxLQUFLLENBQUM7QUFBQSxFQUNyRDtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFXM0YsR0FBRyx3QkFBd0I0RCxRQUFRLEtBQUssTUFBTSxHQUM1RDtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXNUQ7QUFBQUEsVUFDVDtBQUFBLFVBQ0E7QUFBQSxVQUNBbUUsY0FBYztBQUFBLFFBQ2hCO0FBQUEsUUFDQSxTQUFTLE1BQU1DLGNBQWMsQ0FBQ0QsVUFBVTtBQUFBLFFBR3hDO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsQ0FBQ3BCLE1BQU07QUFBRUEsa0JBQUVDLGdCQUFnQjtBQUFHZ0IsNEJBQVksQ0FBQ0QsUUFBUTtBQUFBLGNBQUc7QUFBQSxjQUMvRCxXQUFXL0Q7QUFBQUEsZ0JBQ1Q7QUFBQSxnQkFDQStELFlBQVk7QUFBQSxnQkFDWixDQUFDZ0IsZUFBZUcsY0FBYyxLQUFLO0FBQUEsY0FDckM7QUFBQSxjQUNBLGNBQVluQixXQUFXLGFBQWE7QUFBQSxjQUVwQyxpQ0FBQyxnQkFBYSxNQUFNLElBQUksYUFBYSxLQUFLLGVBQVcsUUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUQ7QUFBQTtBQUFBLFlBVHZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsVUFHQSx1QkFBQyxhQUFVLE1BQU0sSUFBSSxhQUFhLEtBQUssV0FBVSxrQ0FBaUMsZUFBVyxRQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RjtBQUFBLFVBRzdGLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSwrQ0FBK0NKLGVBQUt2QixTQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRTtBQUFBLGNBQzFFLHVCQUFDLFVBQUssV0FBVSxnQ0FDYnVDLG1CQUFTM0QsU0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBRUNtRCxjQUFjUixLQUFLckIsZUFDbEIsdUJBQUMsT0FBRSxXQUFVLHFEQUFxRHFCLGVBQUtyQixlQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRjtBQUFBLFlBSXJGLHVCQUFDLFNBQUksV0FBVSxnQ0FDWjRDO0FBQUFBLDBCQUFZLEtBQ1gsdUJBQUMsVUFBSyxXQUFVLGdDQUNiQztBQUFBQTtBQUFBQSxnQkFBVTtBQUFBLGdCQUFFRDtBQUFBQSxnQkFBVTtBQUFBLG1CQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFRHZCLEtBQUtpQyxnQkFBZ0I5QyxVQUFhYSxLQUFLaUMsY0FBYyxLQUNwRCx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE9BQU8sRUFBRUMsT0FBTyxHQUFHQyxLQUFLQyxJQUFJLEtBQUtwQyxLQUFLaUMsV0FBVyxDQUFDLElBQUk7QUFBQTtBQUFBLGtCQUZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRTBELEtBSDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxnQkFDQSx1QkFBQyxVQUFLLFdBQVUsZ0NBQWdDRTtBQUFBQSx1QkFBS0UsTUFBTXJDLEtBQUtpQyxXQUFXO0FBQUEsa0JBQUU7QUFBQSxxQkFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEU7QUFBQSxtQkFQaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGlCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsZUE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErQkE7QUFBQSxVQUdBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLENBQUM3QyxNQUFNO0FBQUVBLGtCQUFFQyxnQkFBZ0I7QUFBR3VDLGtDQUFrQjtBQUFBLGNBQUc7QUFBQSxjQUM1RCxXQUFXdkY7QUFBQUEsZ0JBQ1Q7QUFBQSxnQkFDQTZFLFVBQVV0RDtBQUFBQSxjQUNaO0FBQUEsY0FDQSxPQUFNO0FBQUEsY0FFTHNELG9CQUFVN0Q7QUFBQUE7QUFBQUEsWUFSYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTQTtBQUFBLFVBR0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsQ0FBQytCLE1BQU07QUFBRUEsa0JBQUVDLGdCQUFnQjtBQUFHa0IsOEJBQWMsSUFBSTtBQUFBLGNBQUc7QUFBQSxjQUM1RCxXQUFVO0FBQUEsY0FDVixPQUFNO0FBQUEsY0FDTixjQUFXO0FBQUEsY0FFWCxpQ0FBQyxRQUFLLE1BQU0sSUFBSSxhQUFhLEtBQUssZUFBVyxRQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QztBQUFBO0FBQUEsWUFOL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQTtBQUFBO0FBQUEsTUE5RUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBK0VBO0FBQUEsSUFHQ0gsWUFBWUksY0FBY0ksZUFBZUEsWUFBWVUsU0FBUyxLQUM3RCx1QkFBQyxTQUFJLFdBQVUsd0JBQ1pWLHNCQUFZcEI7QUFBQUEsTUFBSSxDQUFDOEMsU0FDaEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDLFNBQVMsTUFBTXBDLGVBQWVvQyxLQUFLdkIsR0FBRztBQUFBLFVBQ3RDLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsVUFBSyxXQUFXMUU7QUFBQUEsY0FDZjtBQUFBLGNBQ0FxRCxTQUFTNEMsS0FBS25CLE1BQU0sS0FBSztBQUFBLFlBQzNCLEtBSEE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHRTtBQUFBLFlBQ0YsdUJBQUMsVUFBSyxXQUFVLGlDQUFpQ21CLGVBQUtDLGNBQWMsTUFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUU7QUFBQSxZQUN2RSx1QkFBQyxVQUFLLFdBQVUscUJBQXFCRCxlQUFLN0QsU0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Q7QUFBQSxZQUNoRCx1QkFBQyxVQUFLLFdBQVUsd0NBQXdDNkQsZUFBS25CLFVBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FO0FBQUE7QUFBQTtBQUFBLFFBVi9EbUIsS0FBS3ZCO0FBQUFBLFFBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVlBO0FBQUEsSUFDRCxLQWZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxJQUlEWCxZQUFZSixLQUFLcUIsU0FBUzdCO0FBQUFBLE1BQUksQ0FBQ2dELFVBQzlCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxNQUFNQTtBQUFBQSxVQUNOLE9BQU92QyxRQUFRO0FBQUEsVUFDZjtBQUFBLFVBQ0E7QUFBQTtBQUFBLFFBSkt1QyxNQUFNekI7QUFBQUEsUUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSzZCO0FBQUEsSUFFOUI7QUFBQSxJQUVBVCxjQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsY0FBY04sS0FBS2U7QUFBQUEsUUFDbkIsY0FBY1ksVUFBVTtBQUFBLFFBQ3hCLFNBQVMsTUFBTXBCLGNBQWMsS0FBSztBQUFBO0FBQUEsTUFKcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSXNDO0FBQUEsT0F2SDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwSEE7QUFFSjtBQUlBSixJQTVKU0osVUFBUTtBQUFBLFVBSUk1RCxhQUVDRCxRQUFRO0FBQUE7QUFBQSxNQU5yQjZEO0FBOEpGLGdCQUFTMEMsVUFBVSxFQUFFeEUsV0FBV2lDLGFBQTZCLEdBQUc7QUFBQXdDLE1BQUE7QUFDckUsUUFBTSxDQUFDcEMsWUFBWUMsYUFBYSxJQUFJdEUsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQzBHLGNBQWNDLGVBQWUsSUFBSTNHLFNBQTZCLEtBQUs7QUFFMUUsUUFBTTRHLFlBQVkzRztBQUFBQSxJQUNoQkUsSUFBSW1DLE1BQU11RTtBQUFBQSxJQUNWN0UsWUFBWSxFQUFFQSxVQUFVLElBQUk7QUFBQSxFQUM5QjtBQUVBLE1BQUksQ0FBQ0EsV0FBVztBQUNkLFdBQ0UsdUJBQUMsYUFBUSxXQUFVLHVEQUNqQjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFNO0FBQUEsVUFDTixhQUFZO0FBQUEsVUFDWixNQUFNLHVCQUFDLFVBQU8sV0FBVSxlQUFjLGFBQWEsT0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxVQUN2RCxTQUFRO0FBQUE7QUFBQSxRQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlzQjtBQUFBLE1BRXRCLHVCQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTXJCO0FBQUFBLFVBQ04sT0FBTTtBQUFBLFVBQ04sYUFBWTtBQUFBO0FBQUEsUUFIZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHK0MsS0FKakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsU0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0E7QUFBQSxFQUVKO0FBRUEsUUFBTW1HLG9CQUFvQkYsV0FBV3BCLE9BQU8sQ0FBQ3VCLFNBQVM7QUFDcEQsUUFBSUwsaUJBQWlCLE1BQU8sUUFBTztBQUNuQyxXQUFPSyxLQUFLN0IsV0FBV3dCO0FBQUFBLEVBQ3pCLENBQUM7QUFDRCxRQUFNTSxnQkFBZ0JKLGFBQWE7QUFDbkMsUUFBTUssY0FBY0QsY0FBY3hCLE9BQU8sQ0FBQzBCLFNBQVNBLEtBQUtoQyxXQUFXLFFBQVEsRUFBRUc7QUFDN0UsUUFBTThCLGdCQUFnQkgsY0FBY3hCLE9BQU8sQ0FBQzBCLFNBQVNBLEtBQUtoQyxXQUFXLFVBQVUsRUFBRUc7QUFDakYsUUFBTStCLGVBQWVKLGNBQWN4QixPQUFPLENBQUMwQixTQUFTQSxLQUFLaEMsV0FBVyxTQUFTLEVBQUVHO0FBRS9FLFNBQ0UsdUJBQUMsYUFBUSxXQUFVLHVEQUNqQjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFNO0FBQUEsUUFDTixhQUFZO0FBQUEsUUFDWixNQUFNLHVCQUFDLFVBQU8sV0FBVSxlQUFjLGFBQWEsT0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFFBQ3ZELFNBQVE7QUFBQSxRQUNSLFFBQ0UsdUJBQUMsZUFBWSxNQUFLLFdBQVcyQjtBQUFBQSx3QkFBYzNCO0FBQUFBLFVBQU87QUFBQSxhQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtFO0FBQUEsUUFFcEUsU0FDRSx1QkFBQyxVQUFPLFNBQVMsTUFBTWYsY0FBYyxJQUFJLEdBQUcsTUFBSyxNQUMvQztBQUFBLGlDQUFDLFVBQU8sV0FBVSxzQkFBcUIsYUFBYSxPQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBO0FBQUEsYUFEMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUE7QUFBQSxNQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWFHO0FBQUEsSUFFSCx1QkFBQyxTQUFJLFdBQVUsbUdBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsc0NBQ2I7QUFBQSwrQkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sT0FBTzBDLGNBQWMzQjtBQUFBQSxZQUNyQixRQUFPO0FBQUE7QUFBQSxVQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdvRCxLQUp0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUNBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPNEI7QUFBQUEsWUFDUCxRQUFPO0FBQUE7QUFBQSxVQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUc0QyxLQUo5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUNBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPRTtBQUFBQSxZQUNQLFFBQU87QUFBQTtBQUFBLFVBSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR2tELEtBSnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBQ0EsdUJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE9BQU9DO0FBQUFBLFlBQ1AsUUFBTztBQUFBO0FBQUEsVUFIVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHMEMsS0FKNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsV0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZCQTtBQUFBLE1BRUEsdUJBQUMsUUFBSyxXQUFVLGdCQUNkLGlDQUFDLFNBQUksV0FBVSx1RUFDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsc0NBQXFDLDRCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRTtBQUFBLFVBQ2hFLHVCQUFDLFNBQUksV0FBVSxxQ0FBb0Msc0RBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlGO0FBQUEsYUFGM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsa0RBQ1gsV0FBQyxPQUFPLFVBQVUsV0FBVyxZQUFZLFdBQVcsRUFBWTdEO0FBQUFBLFVBQUksQ0FBQzhELE1BQ3JFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxTQUFTLE1BQU1WLGdCQUFnQlUsQ0FBQztBQUFBLGNBQ2hDLFdBQVdqSDtBQUFBQSxnQkFDVDtBQUFBLGdCQUNBc0csaUJBQWlCVyxJQUNiLDBCQUNBO0FBQUEsY0FDTjtBQUFBLGNBRUNBLGdCQUFNLFFBQVEsUUFBUTVGLGNBQWM0RixDQUFDLEVBQUVqRztBQUFBQTtBQUFBQSxZQVRuQ2lHO0FBQUFBLFlBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVdBO0FBQUEsUUFDRCxLQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFdBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkEsS0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVCQTtBQUFBLE1BRUMsQ0FBQ1QsWUFDQSx1QkFBQyxRQUFLLFdBQVUsMkJBQTBCLGNBQVcsaUJBQ25EO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG9EQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0Q7QUFBQSxRQUMvRCx1QkFBQyxTQUFJLFdBQVUsb0RBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRDtBQUFBLFFBQy9ELHVCQUFDLFNBQUksV0FBVSxvREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStEO0FBQUEsV0FIakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBLElBQ0VFLHFCQUFxQkEsa0JBQWtCekIsV0FBVyxJQUNwRDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTTFFO0FBQUFBLFVBQ04sT0FBTytGLGlCQUFpQixRQUFRLGlCQUFpQixNQUFNQSxhQUFhWSxZQUFZLENBQUM7QUFBQSxVQUNqRixhQUNFWixpQkFBaUIsUUFDYiw0Q0FDQXhEO0FBQUFBLFVBRU4sUUFDRXdELGlCQUFpQixRQUNmLHVCQUFDLFVBQU8sU0FBUyxNQUFNcEMsY0FBYyxJQUFJLEdBQUcsTUFBSyxNQUFJLGlDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLElBQ0VwQjtBQUFBQTtBQUFBQSxRQWJSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWNHLElBR0gsdUJBQUMsU0FBSSxXQUFVLGdGQUNiO0FBQUEsK0JBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxzQ0FBcUMseUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZEO0FBQUEsWUFDN0QsdUJBQUMsU0FBSSxXQUFVLHFDQUFvQyxxREFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Y7QUFBQSxlQUYxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDWjRELDZCQUFtQnZEO0FBQUFBLFlBQUksQ0FBQ3dELFNBQ3ZCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsTUFBTUE7QUFBQUEsZ0JBQ04sT0FBTztBQUFBLGdCQUNQO0FBQUEsZ0JBQ0E7QUFBQTtBQUFBLGNBSktBLEtBQUtqQztBQUFBQSxjQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLNkI7QUFBQSxVQUU5QixLQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxhQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUVBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHNDQUFxQyxpQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUU7QUFBQSxVQUNyRSx1QkFBQyxTQUFJLFdBQVUsbUVBQ2I7QUFBQSxtQ0FBQyxPQUFFLDZIQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdIO0FBQUEsWUFDaEgsdUJBQUMsT0FBRSwwSUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2SDtBQUFBLGVBRi9IO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx1REFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSw0Q0FBMkMsMkJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFO0FBQUEsWUFDckUsdUJBQUMsU0FBSSxXQUFVLGlDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHNCQUFxQixzQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkM7QUFBQSxnQkFDM0MsdUJBQUMsVUFBSyxXQUFVLDBCQUEwQm1DLHlCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzRDtBQUFBLG1CQUZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsc0JBQXFCLHVCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0QztBQUFBLGdCQUM1Qyx1QkFBQyxVQUFLLFdBQVUsMEJBQTBCRywwQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUQ7QUFBQSxtQkFGekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHNCQUFxQix3QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkM7QUFBQSxnQkFDN0MsdUJBQUMsVUFBSyxXQUFVLDBCQUEwQkQsMkJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdEO0FBQUEsbUJBRjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWFBO0FBQUEsZUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLGFBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1QkE7QUFBQSxXQTFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkNBO0FBQUEsTUFHRDlDLGNBQ0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDO0FBQUEsVUFDQSxjQUFhO0FBQUEsVUFDYixTQUFTLE1BQU1DLGNBQWMsS0FBSztBQUFBO0FBQUEsUUFIcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR3NDO0FBQUEsU0FuSTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzSUE7QUFBQSxPQXRKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUpBO0FBRUo7QUFBQ21DLElBaE1lRCxXQUFTO0FBQUEsVUFJTHZHLFFBQVE7QUFBQTtBQUFBLE1BSlp1RztBQUFTLElBQUFlLElBQUFDLEtBQUFDO0FBQUEsYUFBQUYsSUFBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VRdWVyeSIsInVzZU11dGF0aW9uIiwiYXBpIiwiY24iLCJQYWdlSGVhZGVyIiwiQ2FyZCIsIkJ1dHRvbiIsIkVtcHR5U3RhdGUiLCJTdGF0dXNCYWRnZSIsIk1ldHJpY0Jsb2NrIiwiVGFyZ2V0IiwiQnVpbGRpbmcyIiwiVXNlcnMiLCJCb3QiLCJDbGlwYm9hcmRMaXN0IiwiQ2hldnJvblJpZ2h0IiwiUGx1cyIsIkxFVkVMX0NPTkZJRyIsIkNPTVBBTlkiLCJsYWJlbCIsImljb24iLCJURUFNIiwiQUdFTlQiLCJUQVNLIiwiU1RBVFVTX0NPTkZJRyIsIlBMQU5ORUQiLCJiYWRnZSIsIkFDVElWRSIsIkFDSElFVkVEIiwiQ0FOQ0VMTEVEIiwiQ3JlYXRlR29hbE1vZGFsIiwicHJvamVjdElkIiwicGFyZW50R29hbElkIiwiZGVmYXVsdExldmVsIiwib25DbG9zZSIsIl9zIiwiY3JlYXRlR29hbCIsImdvYWxzIiwiY3JlYXRlIiwidGl0bGUiLCJzZXRUaXRsZSIsImRlc2NyaXB0aW9uIiwic2V0RGVzY3JpcHRpb24iLCJsZXZlbCIsInNldExldmVsIiwic2F2aW5nIiwic2V0U2F2aW5nIiwiaGFuZGxlU3VibWl0IiwidHJpbSIsInVuZGVmaW5lZCIsImUiLCJzdG9wUHJvcGFnYXRpb24iLCJ0YXJnZXQiLCJ2YWx1ZSIsIm1hcCIsImwiLCJUQVNLX0RPVCIsIkRPTkUiLCJJTl9QUk9HUkVTUyIsIkJMT0NLRUQiLCJGQUlMRUQiLCJHb2FsTm9kZSIsIm5vZGUiLCJkZXB0aCIsIm9uVGFza1NlbGVjdCIsIl9zMiIsImV4cGFuZGVkIiwic2V0RXhwYW5kZWQiLCJzaG93Q3JlYXRlIiwic2V0U2hvd0NyZWF0ZSIsInNob3dEZXRhaWwiLCJzZXRTaG93RGV0YWlsIiwidXBkYXRlR29hbCIsInVwZGF0ZSIsImxpbmtlZFRhc2tzIiwiZ2V0TGlua2VkVGFza3MiLCJnb2FsSWQiLCJfaWQiLCJsZXZlbENmZyIsIkxldmVsSWNvbiIsInN0YXR1c0NmZyIsInN0YXR1cyIsImhhc0NoaWxkcmVuIiwiY2hpbGRyZW4iLCJsZW5ndGgiLCJ0YXNrQ291bnQiLCJkb25lQ291bnQiLCJmaWx0ZXIiLCJ0IiwibmV4dExldmVsIiwiaGFuZGxlU3RhdHVzQ3ljbGUiLCJvcmRlciIsImlkeCIsImluZGV4T2YiLCJuZXh0IiwicHJvZ3Jlc3NQY3QiLCJ3aWR0aCIsIk1hdGgiLCJtaW4iLCJyb3VuZCIsInRhc2siLCJpZGVudGlmaWVyIiwiY2hpbGQiLCJHb2Fsc1ZpZXciLCJfczMiLCJzdGF0dXNGaWx0ZXIiLCJzZXRTdGF0dXNGaWx0ZXIiLCJoaWVyYXJjaHkiLCJnZXRIaWVyYXJjaHkiLCJmaWx0ZXJlZEhpZXJhcmNoeSIsInJvb3QiLCJ0b3BMZXZlbEdvYWxzIiwiYWN0aXZlR29hbHMiLCJnb2FsIiwiYWNoaWV2ZWRHb2FscyIsInBsYW5uZWRHb2FscyIsInMiLCJ0b0xvd2VyQ2FzZSIsIl9jIiwiX2MyIiwiX2MzIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkdvYWxzVmlldy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5LCB1c2VNdXRhdGlvbiB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB0eXBlIHsgSWQsIERvYyB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9kYXRhTW9kZWxcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5pbXBvcnQgeyBQYWdlSGVhZGVyIH0gZnJvbSBcIi4vY29tcG9uZW50cy9QYWdlSGVhZGVyXCI7XG5pbXBvcnQgeyBDYXJkIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9jYXJkXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuaW1wb3J0IHsgRW1wdHlTdGF0ZSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvZW1wdHktc3RhdGVcIjtcbmltcG9ydCB7IFN0YXR1c0JhZGdlIH0gZnJvbSBcIkAvY29tcG9uZW50cy9mYWN0b3J5L2JhZGdlc1wiO1xuaW1wb3J0IHsgTWV0cmljQmxvY2sgfSBmcm9tIFwiQC9jb21wb25lbnRzL2ZhY3RvcnkvTWV0cmljQmxvY2tcIjtcbmltcG9ydCB7XG4gIFRhcmdldCxcbiAgQnVpbGRpbmcyLFxuICBVc2VycyxcbiAgQm90LFxuICBDbGlwYm9hcmRMaXN0LFxuICBDaGV2cm9uUmlnaHQsXG4gIFBsdXMsXG4gIHR5cGUgTHVjaWRlSWNvbixcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuXG5pbnRlcmZhY2UgR29hbHNWaWV3UHJvcHMge1xuICBwcm9qZWN0SWQ6IElkPFwicHJvamVjdHNcIj4gfCBudWxsO1xuICBvblRhc2tTZWxlY3Q/OiAodGFza0lkOiBJZDxcInRhc2tzXCI+KSA9PiB2b2lkO1xufVxuXG50eXBlIEdvYWxMZXZlbCA9IFwiQ09NUEFOWVwiIHwgXCJURUFNXCIgfCBcIkFHRU5UXCIgfCBcIlRBU0tcIjtcbnR5cGUgR29hbFN0YXR1cyA9IFwiUExBTk5FRFwiIHwgXCJBQ1RJVkVcIiB8IFwiQUNISUVWRURcIiB8IFwiQ0FOQ0VMTEVEXCI7XG5cbmNvbnN0IExFVkVMX0NPTkZJRzogUmVjb3JkPEdvYWxMZXZlbCwgeyBsYWJlbDogc3RyaW5nOyBpY29uOiBMdWNpZGVJY29uIH0+ID0ge1xuICBDT01QQU5ZOiB7IGxhYmVsOiBcIkNvbXBhbnlcIiwgaWNvbjogQnVpbGRpbmcyIH0sXG4gIFRFQU06IHsgbGFiZWw6IFwiVGVhbVwiLCBpY29uOiBVc2VycyB9LFxuICBBR0VOVDogeyBsYWJlbDogXCJBZ2VudFwiLCBpY29uOiBCb3QgfSxcbiAgVEFTSzogeyBsYWJlbDogXCJUYXNrXCIsIGljb246IENsaXBib2FyZExpc3QgfSxcbn07XG5cbmNvbnN0IFNUQVRVU19DT05GSUc6IFJlY29yZDxHb2FsU3RhdHVzLCB7IGxhYmVsOiBzdHJpbmc7IGJhZGdlOiBzdHJpbmcgfT4gPSB7XG4gIFBMQU5ORUQ6IHsgbGFiZWw6IFwiUGxhbm5lZFwiLCBiYWRnZTogXCJib3JkZXItbGluZSBiZy1zdXJmYWNlLTIgdGV4dC1pbmstc2Vjb25kYXJ5XCIgfSxcbiAgQUNUSVZFOiB7IGxhYmVsOiBcIkFjdGl2ZVwiLCBiYWRnZTogXCJib3JkZXItdHJhbnNwYXJlbnQgYmctaW5mby1zb2Z0IHRleHQtaW5mby1hY2NlbnRcIiB9LFxuICBBQ0hJRVZFRDogeyBsYWJlbDogXCJBY2hpZXZlZFwiLCBiYWRnZTogXCJib3JkZXItdHJhbnNwYXJlbnQgYmctb2stc29mdCB0ZXh0LW9rXCIgfSxcbiAgQ0FOQ0VMTEVEOiB7IGxhYmVsOiBcIkNhbmNlbGxlZFwiLCBiYWRnZTogXCJib3JkZXItdHJhbnNwYXJlbnQgYmctZXJyLXNvZnQgdGV4dC1lcnJcIiB9LFxufTtcblxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gQ1JFQVRFIEdPQUwgTU9EQUxcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuaW50ZXJmYWNlIENyZWF0ZUdvYWxNb2RhbFByb3BzIHtcbiAgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+O1xuICBwYXJlbnRHb2FsSWQ/OiBJZDxcImdvYWxzXCI+O1xuICBkZWZhdWx0TGV2ZWw6IEdvYWxMZXZlbDtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbn1cblxuZnVuY3Rpb24gQ3JlYXRlR29hbE1vZGFsKHsgcHJvamVjdElkLCBwYXJlbnRHb2FsSWQsIGRlZmF1bHRMZXZlbCwgb25DbG9zZSB9OiBDcmVhdGVHb2FsTW9kYWxQcm9wcykge1xuICBjb25zdCBjcmVhdGVHb2FsID0gdXNlTXV0YXRpb24oYXBpLmdvYWxzLmNyZWF0ZSk7XG4gIGNvbnN0IFt0aXRsZSwgc2V0VGl0bGVdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtkZXNjcmlwdGlvbiwgc2V0RGVzY3JpcHRpb25dID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtsZXZlbCwgc2V0TGV2ZWxdID0gdXNlU3RhdGU8R29hbExldmVsPihkZWZhdWx0TGV2ZWwpO1xuICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXRpdGxlLnRyaW0oKSkgcmV0dXJuO1xuICAgIHNldFNhdmluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgY3JlYXRlR29hbCh7XG4gICAgICAgIHByb2plY3RJZCxcbiAgICAgICAgdGl0bGU6IHRpdGxlLnRyaW0oKSxcbiAgICAgICAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uLnRyaW0oKSB8fCB1bmRlZmluZWQsXG4gICAgICAgIGxldmVsLFxuICAgICAgICBwYXJlbnRHb2FsSWQsXG4gICAgICB9KTtcbiAgICAgIG9uQ2xvc2UoKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHNldFNhdmluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYmxhY2svNjBcIiBvbkNsaWNrPXtvbkNsb3NlfT5cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LW1kIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMyBwLTYgc2hhZG93LVt2YXIoLS1zaGFkb3ctZWxldmF0aW9uLTIpXVwiXG4gICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgPlxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWluayBtYi00XCI+XG4gICAgICAgICAge3BhcmVudEdvYWxJZCA/IFwiQWRkIFN1Yi1Hb2FsXCIgOiBcIkNyZWF0ZSBHb2FsXCJ9XG4gICAgICAgIDwvaDI+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEyLjVweF0gZm9udC1tZWRpdW0gdGV4dC1pbmstc2Vjb25kYXJ5IG1iLTFcIj5UaXRsZTwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICB2YWx1ZT17dGl0bGV9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGl0bGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4sIFJlYWNoICQxTSBBUlIgYnkgUTNcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC05IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMSBweC0zIHRleHQtWzEzLjVweF0gdGV4dC1pbmsgcGxhY2Vob2xkZXI6dGV4dC1pbmstbXV0ZWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXJpbmdcIlxuICAgICAgICAgICAgICBhdXRvRm9jdXNcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEyLjVweF0gZm9udC1tZWRpdW0gdGV4dC1pbmstc2Vjb25kYXJ5IG1iLTFcIj5EZXNjcmlwdGlvbjwvbGFiZWw+XG4gICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgdmFsdWU9e2Rlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldERlc2NyaXB0aW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJXaHkgZG9lcyB0aGlzIGdvYWwgbWF0dGVyP1wiXG4gICAgICAgICAgICAgIHJvd3M9ezN9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgcHgtMyBweS0yIHRleHQtWzEzLjVweF0gdGV4dC1pbmsgcGxhY2Vob2xkZXI6dGV4dC1pbmstbXV0ZWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXJpbmcgcmVzaXplLW5vbmVcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTIuNXB4XSBmb250LW1lZGl1bSB0ZXh0LWluay1zZWNvbmRhcnkgbWItMVwiPkxldmVsPC9sYWJlbD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBwLTAuNSB3LWZpdFwiPlxuICAgICAgICAgICAgICB7KFtcIkNPTVBBTllcIiwgXCJURUFNXCIsIFwiQUdFTlRcIiwgXCJUQVNLXCJdIGFzIEdvYWxMZXZlbFtdKS5tYXAoKGwpID0+IChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e2x9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRMZXZlbChsKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgIFwicHgtMyBweS0xLjUgcm91bmRlZC1tZCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiLFxuICAgICAgICAgICAgICAgICAgICBsZXZlbCA9PT0gbFxuICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1zdXJmYWNlLTIgdGV4dC1pbmtcIlxuICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWluay1zZWNvbmRhcnkgaG92ZXI6dGV4dC1pbmtcIlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7TEVWRUxfQ09ORklHW2xdLmxhYmVsfVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTIgbXQtNlwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJoLTkgcHgtMyByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSB0ZXh0LVsxM3B4XSBmb250LW1lZGl1bSB0ZXh0LWluay1zZWNvbmRhcnkgaG92ZXI6dGV4dC1pbmsgaG92ZXI6Ym9yZGVyLWxpbmUtc3Ryb25nIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgQ2FuY2VsXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU3VibWl0fVxuICAgICAgICAgICAgZGlzYWJsZWQ9eyF0aXRsZS50cmltKCkgfHwgc2F2aW5nfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC05IHB4LTMgcm91bmRlZC1sZyBiZy1hY3QgdGV4dC1hY3QtaW5rIHRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIGhvdmVyOm9wYWNpdHktOTAgZGlzYWJsZWQ6b3BhY2l0eS01MCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtzYXZpbmcgPyBcIkNyZWF0aW5nLi4uXCIgOiBcIkNyZWF0ZSBHb2FsXCJ9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbi8vIEdPQUwgTk9ERSAocmVjdXJzaXZlIHRyZWUpXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbmludGVyZmFjZSBHb2FsTm9kZURhdGEge1xuICBfaWQ6IElkPFwiZ29hbHNcIj47XG4gIHRpdGxlOiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuICBsZXZlbDogR29hbExldmVsO1xuICBzdGF0dXM6IEdvYWxTdGF0dXM7XG4gIHByb2dyZXNzUGN0PzogbnVtYmVyO1xuICBwYXJlbnRHb2FsSWQ/OiBJZDxcImdvYWxzXCI+O1xuICBvd25lckFnZW50SWQ/OiBJZDxcImFnZW50c1wiPjtcbiAgY2hpbGRyZW46IEdvYWxOb2RlRGF0YVtdO1xufVxuXG5pbnRlcmZhY2UgR29hbE5vZGVQcm9wcyB7XG4gIG5vZGU6IEdvYWxOb2RlRGF0YTtcbiAgZGVwdGg6IG51bWJlcjtcbiAgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+O1xuICBvblRhc2tTZWxlY3Q/OiAodGFza0lkOiBJZDxcInRhc2tzXCI+KSA9PiB2b2lkO1xufVxuXG5jb25zdCBUQVNLX0RPVDogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcbiAgRE9ORTogXCJiZy1va1wiLFxuICBJTl9QUk9HUkVTUzogXCJiZy1pbmZvLWFjY2VudFwiLFxuICBCTE9DS0VEOiBcImJnLXdhcm5cIixcbiAgRkFJTEVEOiBcImJnLWVyclwiLFxufTtcblxuZnVuY3Rpb24gR29hbE5vZGUoeyBub2RlLCBkZXB0aCwgcHJvamVjdElkLCBvblRhc2tTZWxlY3QgfTogR29hbE5vZGVQcm9wcykge1xuICBjb25zdCBbZXhwYW5kZWQsIHNldEV4cGFuZGVkXSA9IHVzZVN0YXRlKGRlcHRoIDwgMik7XG4gIGNvbnN0IFtzaG93Q3JlYXRlLCBzZXRTaG93Q3JlYXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Nob3dEZXRhaWwsIHNldFNob3dEZXRhaWxdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCB1cGRhdGVHb2FsID0gdXNlTXV0YXRpb24oYXBpLmdvYWxzLnVwZGF0ZSk7XG5cbiAgY29uc3QgbGlua2VkVGFza3MgPSB1c2VRdWVyeShhcGkuZ29hbHMuZ2V0TGlua2VkVGFza3MsIHsgZ29hbElkOiBub2RlLl9pZCB9KTtcbiAgY29uc3QgbGV2ZWxDZmcgPSBMRVZFTF9DT05GSUdbbm9kZS5sZXZlbF07XG4gIGNvbnN0IExldmVsSWNvbiA9IGxldmVsQ2ZnLmljb247XG4gIGNvbnN0IHN0YXR1c0NmZyA9IFNUQVRVU19DT05GSUdbbm9kZS5zdGF0dXNdO1xuICBjb25zdCBoYXNDaGlsZHJlbiA9IG5vZGUuY2hpbGRyZW4ubGVuZ3RoID4gMDtcbiAgY29uc3QgdGFza0NvdW50ID0gbGlua2VkVGFza3M/Lmxlbmd0aCA/PyAwO1xuICBjb25zdCBkb25lQ291bnQgPSBsaW5rZWRUYXNrcz8uZmlsdGVyKCh0KSA9PiB0LnN0YXR1cyA9PT0gXCJET05FXCIpLmxlbmd0aCA/PyAwO1xuXG4gIGNvbnN0IG5leHRMZXZlbCA9ICgpOiBHb2FsTGV2ZWwgPT4ge1xuICAgIGlmIChub2RlLmxldmVsID09PSBcIkNPTVBBTllcIikgcmV0dXJuIFwiVEVBTVwiO1xuICAgIGlmIChub2RlLmxldmVsID09PSBcIlRFQU1cIikgcmV0dXJuIFwiQUdFTlRcIjtcbiAgICByZXR1cm4gXCJUQVNLXCI7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU3RhdHVzQ3ljbGUgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgb3JkZXI6IEdvYWxTdGF0dXNbXSA9IFtcIlBMQU5ORURcIiwgXCJBQ1RJVkVcIiwgXCJBQ0hJRVZFRFwiLCBcIkNBTkNFTExFRFwiXTtcbiAgICBjb25zdCBpZHggPSBvcmRlci5pbmRleE9mKG5vZGUuc3RhdHVzKTtcbiAgICBjb25zdCBuZXh0ID0gb3JkZXJbKGlkeCArIDEpICUgb3JkZXIubGVuZ3RoXTtcbiAgICBhd2FpdCB1cGRhdGVHb2FsKHsgZ29hbElkOiBub2RlLl9pZCwgc3RhdHVzOiBuZXh0IH0pO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2NuKFwiYm9yZGVyLWwgYm9yZGVyLWxpbmVcIiwgZGVwdGggPiAwICYmIFwibWwtNlwiKX0+XG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgXCJncm91cCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zIHB4LTQgcHktMyByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBjdXJzb3ItcG9pbnRlclwiLFxuICAgICAgICAgIFwiaG92ZXI6Ymctc3VyZmFjZS0yXCIsXG4gICAgICAgICAgc2hvd0RldGFpbCAmJiBcImJnLXN1cmZhY2UtMlwiXG4gICAgICAgICl9XG4gICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dEZXRhaWwoIXNob3dEZXRhaWwpfVxuICAgICAgPlxuICAgICAgICB7LyogRXhwYW5kL2NvbGxhcHNlICovfVxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17KGUpID0+IHsgZS5zdG9wUHJvcGFnYXRpb24oKTsgc2V0RXhwYW5kZWQoIWV4cGFuZGVkKTsgfX1cbiAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgXCJtdC0wLjUgdy01IGgtNSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkIHRleHQtaW5rLW11dGVkIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTE1MFwiLFxuICAgICAgICAgICAgZXhwYW5kZWQgJiYgXCJyb3RhdGUtOTBcIixcbiAgICAgICAgICAgICFoYXNDaGlsZHJlbiAmJiB0YXNrQ291bnQgPT09IDAgJiYgXCJpbnZpc2libGVcIlxuICAgICAgICAgICl9XG4gICAgICAgICAgYXJpYS1sYWJlbD17ZXhwYW5kZWQgPyBcIkNvbGxhcHNlXCIgOiBcIkV4cGFuZFwifVxuICAgICAgICA+XG4gICAgICAgICAgPENoZXZyb25SaWdodCBzaXplPXsxNH0gc3Ryb2tlV2lkdGg9ezEuNn0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgey8qIExldmVsIGljb24gKi99XG4gICAgICAgIDxMZXZlbEljb24gc2l6ZT17MTZ9IHN0cm9rZVdpZHRoPXsxLjZ9IGNsYXNzTmFtZT1cIm10LTAuNSBzaHJpbmstMCB0ZXh0LWluay1tdXRlZFwiIGFyaWEtaGlkZGVuIC8+XG5cbiAgICAgICAgey8qIENvbnRlbnQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LVsxMy41cHhdIHRleHQtaW5rIHRydW5jYXRlXCI+e25vZGUudGl0bGV9PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICB7bGV2ZWxDZmcubGFiZWx9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7c2hvd0RldGFpbCAmJiBub2RlLmRlc2NyaXB0aW9uICYmIChcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEyLjVweF0gdGV4dC1pbmstbXV0ZWQgbXQtMSBsZWFkaW5nLXJlbGF4ZWRcIj57bm9kZS5kZXNjcmlwdGlvbn08L3A+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBTdGF0cyByb3cgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtdC0xXCI+XG4gICAgICAgICAgICB7dGFza0NvdW50ID4gMCAmJiAoXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExLjVweF0gdGV4dC1pbmstbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICB7ZG9uZUNvdW50fS97dGFza0NvdW50fSB0YXNrc1xuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAge25vZGUucHJvZ3Jlc3NQY3QgIT09IHVuZGVmaW5lZCAmJiBub2RlLnByb2dyZXNzUGN0ID4gMCAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTEuNSByb3VuZGVkLWZ1bGwgYmctc3VyZmFjZS0yIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgcm91bmRlZC1mdWxsIGJnLW9rIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTE1MFwiXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHtNYXRoLm1pbigxMDAsIG5vZGUucHJvZ3Jlc3NQY3QpfSVgIH19XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExLjVweF0gdGV4dC1pbmstbXV0ZWRcIj57TWF0aC5yb3VuZChub2RlLnByb2dyZXNzUGN0KX0lPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBTdGF0dXMgYmFkZ2UgKi99XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4geyBlLnN0b3BQcm9wYWdhdGlvbigpOyBoYW5kbGVTdGF0dXNDeWNsZSgpOyB9fVxuICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICBcImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciByb3VuZGVkLW1kIGJvcmRlciBweC0xLjUgcHktMC41IHRleHQtWzExLjVweF0gZm9udC1tZWRpdW0gbGVhZGluZy1ub25lIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiLFxuICAgICAgICAgICAgc3RhdHVzQ2ZnLmJhZGdlXG4gICAgICAgICAgKX1cbiAgICAgICAgICB0aXRsZT1cIkNsaWNrIHRvIGN5Y2xlIHN0YXR1c1wiXG4gICAgICAgID5cbiAgICAgICAgICB7c3RhdHVzQ2ZnLmxhYmVsfVxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICB7LyogQWRkIHN1Yi1nb2FsICovfVxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17KGUpID0+IHsgZS5zdG9wUHJvcGFnYXRpb24oKTsgc2V0U2hvd0NyZWF0ZSh0cnVlKTsgfX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgbXQtMC41IHctNiBoLTYgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZCB0ZXh0LWluay1tdXRlZCBob3Zlcjp0ZXh0LWluayBob3ZlcjpiZy1zdXJmYWNlLTIgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCJcbiAgICAgICAgICB0aXRsZT1cIkFkZCBzdWItZ29hbFwiXG4gICAgICAgICAgYXJpYS1sYWJlbD1cIkFkZCBzdWItZ29hbFwiXG4gICAgICAgID5cbiAgICAgICAgICA8UGx1cyBzaXplPXsxNH0gc3Ryb2tlV2lkdGg9ezEuNn0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIExpbmtlZCB0YXNrcyAod2hlbiBleHBhbmRlZCBhbmQgZGV0YWlsIHNob3duKSAqL31cbiAgICAgIHtleHBhbmRlZCAmJiBzaG93RGV0YWlsICYmIGxpbmtlZFRhc2tzICYmIGxpbmtlZFRhc2tzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLTE0IG1iLTIgc3BhY2UteS0xXCI+XG4gICAgICAgICAge2xpbmtlZFRhc2tzLm1hcCgodGFzaykgPT4gKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBrZXk9e3Rhc2suX2lkfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblRhc2tTZWxlY3Q/Lih0YXNrLl9pZCl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHctZnVsbCB0ZXh0LWxlZnQgcHgtMyBweS0xLjUgcm91bmRlZC1tZCB0ZXh0LVsxMi41cHhdIGhvdmVyOmJnLXN1cmZhY2UtMiB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgIFwidy0xLjUgaC0xLjUgcm91bmRlZC1mdWxsXCIsXG4gICAgICAgICAgICAgICAgVEFTS19ET1RbdGFzay5zdGF0dXNdID8/IFwiYmctaW5rLW11dGVkLzUwXCJcbiAgICAgICAgICAgICAgKX0gLz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1pbmstbXV0ZWQgZm9udC1tb25vIG1yLTFcIj57dGFzay5pZGVudGlmaWVyID8/IFwiXCJ9PC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWluayB0cnVuY2F0ZVwiPnt0YXNrLnRpdGxlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSB0ZXh0LWluay1tdXRlZCBtbC1hdXRvXCI+e3Rhc2suc3RhdHVzfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBDaGlsZHJlbiAqL31cbiAgICAgIHtleHBhbmRlZCAmJiBub2RlLmNoaWxkcmVuLm1hcCgoY2hpbGQpID0+IChcbiAgICAgICAgPEdvYWxOb2RlXG4gICAgICAgICAga2V5PXtjaGlsZC5faWR9XG4gICAgICAgICAgbm9kZT17Y2hpbGQgYXMgR29hbE5vZGVEYXRhfVxuICAgICAgICAgIGRlcHRoPXtkZXB0aCArIDF9XG4gICAgICAgICAgcHJvamVjdElkPXtwcm9qZWN0SWR9XG4gICAgICAgICAgb25UYXNrU2VsZWN0PXtvblRhc2tTZWxlY3R9XG4gICAgICAgIC8+XG4gICAgICApKX1cblxuICAgICAge3Nob3dDcmVhdGUgJiYgKFxuICAgICAgICA8Q3JlYXRlR29hbE1vZGFsXG4gICAgICAgICAgcHJvamVjdElkPXtwcm9qZWN0SWR9XG4gICAgICAgICAgcGFyZW50R29hbElkPXtub2RlLl9pZH1cbiAgICAgICAgICBkZWZhdWx0TGV2ZWw9e25leHRMZXZlbCgpfVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dDcmVhdGUoZmFsc2UpfVxuICAgICAgICAvPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gR09BTFMgVklFVyAobWFpbiBleHBvcnQpXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbmV4cG9ydCBmdW5jdGlvbiBHb2Fsc1ZpZXcoeyBwcm9qZWN0SWQsIG9uVGFza1NlbGVjdCB9OiBHb2Fsc1ZpZXdQcm9wcykge1xuICBjb25zdCBbc2hvd0NyZWF0ZSwgc2V0U2hvd0NyZWF0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzdGF0dXNGaWx0ZXIsIHNldFN0YXR1c0ZpbHRlcl0gPSB1c2VTdGF0ZTxHb2FsU3RhdHVzIHwgXCJBTExcIj4oXCJBTExcIik7XG5cbiAgY29uc3QgaGllcmFyY2h5ID0gdXNlUXVlcnkoXG4gICAgYXBpLmdvYWxzLmdldEhpZXJhcmNoeSxcbiAgICBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCB9IDogXCJza2lwXCJcbiAgKTtcblxuICBpZiAoIXByb2plY3RJZCkge1xuICAgIHJldHVybiAoXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLTAgZmxleC0xIGZsZXgtY29sIG92ZXJmbG93LXktYXV0byBiZy1hcHBcIj5cbiAgICAgICAgPFBhZ2VIZWFkZXJcbiAgICAgICAgICB0aXRsZT1cIkdvYWxzXCJcbiAgICAgICAgICBkZXNjcmlwdGlvbj1cIlRyYWNrIHRoZSBoaWVyYXJjaHkgYmV0d2VlbiBjb21wYW55IGdvYWxzLCB0ZWFtIGdvYWxzLCBhbmQgdGFzayBleGVjdXRpb24uXCJcbiAgICAgICAgICBpY29uPXs8VGFyZ2V0IGNsYXNzTmFtZT1cImgtNC41IHctNC41XCIgc3Ryb2tlV2lkdGg9ezEuN30gLz59XG4gICAgICAgICAgZXllYnJvdz1cIk9wZXJhdGlvbnNcIlxuICAgICAgICAvPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gbWF4LXctWzEyMDBweF0gcHgtNiBweS02XCI+XG4gICAgICAgICAgPEVtcHR5U3RhdGVcbiAgICAgICAgICAgIGljb249e1RhcmdldH1cbiAgICAgICAgICAgIHRpdGxlPVwiTm8gcHJvamVjdCBzZWxlY3RlZFwiXG4gICAgICAgICAgICBkZXNjcmlwdGlvbj1cIlNlbGVjdCBhIHByb2plY3QgdG8gdmlldyBnb2Fscy5cIlxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuICAgICk7XG4gIH1cblxuICBjb25zdCBmaWx0ZXJlZEhpZXJhcmNoeSA9IGhpZXJhcmNoeT8uZmlsdGVyKChyb290KSA9PiB7XG4gICAgaWYgKHN0YXR1c0ZpbHRlciA9PT0gXCJBTExcIikgcmV0dXJuIHRydWU7XG4gICAgcmV0dXJuIHJvb3Quc3RhdHVzID09PSBzdGF0dXNGaWx0ZXI7XG4gIH0pO1xuICBjb25zdCB0b3BMZXZlbEdvYWxzID0gaGllcmFyY2h5ID8/IFtdO1xuICBjb25zdCBhY3RpdmVHb2FscyA9IHRvcExldmVsR29hbHMuZmlsdGVyKChnb2FsKSA9PiBnb2FsLnN0YXR1cyA9PT0gXCJBQ1RJVkVcIikubGVuZ3RoO1xuICBjb25zdCBhY2hpZXZlZEdvYWxzID0gdG9wTGV2ZWxHb2Fscy5maWx0ZXIoKGdvYWwpID0+IGdvYWwuc3RhdHVzID09PSBcIkFDSElFVkVEXCIpLmxlbmd0aDtcbiAgY29uc3QgcGxhbm5lZEdvYWxzID0gdG9wTGV2ZWxHb2Fscy5maWx0ZXIoKGdvYWwpID0+IGdvYWwuc3RhdHVzID09PSBcIlBMQU5ORURcIikubGVuZ3RoO1xuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiZmxleCBtaW4taC0wIGZsZXgtMSBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW4gYmctYXBwXCI+XG4gICAgICA8UGFnZUhlYWRlclxuICAgICAgICB0aXRsZT1cIkdvYWxzXCJcbiAgICAgICAgZGVzY3JpcHRpb249XCJFdmVyeSB0YXNrIHNob3VsZCB0cmFjZSBiYWNrIHRvIGEgcmVhbCBnb2FsLiBJZiB5b3UgY2Fubm90IGV4cGxhaW4gd2h5IGl0IG1hdHRlcnMsIGl0IHNob3VsZCBub3QgYmUgaW4gdGhlIHN5c3RlbS5cIlxuICAgICAgICBpY29uPXs8VGFyZ2V0IGNsYXNzTmFtZT1cImgtNC41IHctNC41XCIgc3Ryb2tlV2lkdGg9ezEuN30gLz59XG4gICAgICAgIGV5ZWJyb3c9XCJPcGVyYXRpb25zXCJcbiAgICAgICAgc3RhdHVzPXtcbiAgICAgICAgICA8U3RhdHVzQmFkZ2UgdG9uZT1cIm5ldXRyYWxcIj57dG9wTGV2ZWxHb2Fscy5sZW5ndGh9IHRvcC1sZXZlbCBnb2FsczwvU3RhdHVzQmFkZ2U+XG4gICAgICAgIH1cbiAgICAgICAgYWN0aW9ucz17XG4gICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93Q3JlYXRlKHRydWUpfSBzaXplPVwic21cIj5cbiAgICAgICAgICAgIDxUYXJnZXQgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgbXItMS41XCIgc3Ryb2tlV2lkdGg9ezEuN30gLz5cbiAgICAgICAgICAgIE5ldyBHb2FsXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIH1cbiAgICAgIC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gZmxleCBtaW4taC0wIHctZnVsbCBtYXgtdy1bMTIwMHB4XSBmbGV4LTEgZmxleC1jb2wgZ2FwLTQgb3ZlcmZsb3ctaGlkZGVuIHB4LTYgcGItNiBwdC00XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBzaHJpbmstMCBnYXAtNCBtZDpncmlkLWNvbHMtNFwiPlxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICAgICAgPE1ldHJpY0Jsb2NrXG4gICAgICAgICAgICAgIGxhYmVsPVwiVG9wIGxldmVsXCJcbiAgICAgICAgICAgICAgdmFsdWU9e3RvcExldmVsR29hbHMubGVuZ3RofVxuICAgICAgICAgICAgICBkZXRhaWw9XCJDb21wYW55LWxldmVsIGRpcmVjdGlvbiBjdXJyZW50bHkgdHJhY2tlZFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTRcIj5cbiAgICAgICAgICAgIDxNZXRyaWNCbG9ja1xuICAgICAgICAgICAgICBsYWJlbD1cIkFjdGl2ZVwiXG4gICAgICAgICAgICAgIHZhbHVlPXthY3RpdmVHb2Fsc31cbiAgICAgICAgICAgICAgZGV0YWlsPVwiR29hbHMgY3VycmVudGx5IGRyaXZpbmcgZXhlY3V0aW9uXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICAgICAgPE1ldHJpY0Jsb2NrXG4gICAgICAgICAgICAgIGxhYmVsPVwiQWNoaWV2ZWRcIlxuICAgICAgICAgICAgICB2YWx1ZT17YWNoaWV2ZWRHb2Fsc31cbiAgICAgICAgICAgICAgZGV0YWlsPVwiR29hbHMgdGhhdCBoYXZlIGFscmVhZHkgY2xvc2VkIHRoZSBsb29wXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICAgICAgPE1ldHJpY0Jsb2NrXG4gICAgICAgICAgICAgIGxhYmVsPVwiUGxhbm5lZFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtwbGFubmVkR29hbHN9XG4gICAgICAgICAgICAgIGRldGFpbD1cIklkZWFzIG5vdCB5ZXQgc2hhcGluZyBleGVjdXRpb25cIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNocmluay0wIHAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIG92ZXJmbG93LXgtYXV0byBmbGV4LW5vd3JhcFwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+R29hbCBmaWx0ZXJzPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LVsxMi41cHhdIHRleHQtaW5rLW11dGVkXCI+Rm9jdXMgdGhlIGdvYWwgdHJlZSBieSBsaWZlY3ljbGUgc3RhdGU8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0xIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1saW5lIHAtMC41XCI+XG4gICAgICAgICAgICAgIHsoW1wiQUxMXCIsIFwiQUNUSVZFXCIsIFwiUExBTk5FRFwiLCBcIkFDSElFVkVEXCIsIFwiQ0FOQ0VMTEVEXCJdIGFzIGNvbnN0KS5tYXAoKHMpID0+IChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e3N9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTdGF0dXNGaWx0ZXIocyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICBcInJvdW5kZWQtbWQgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIixcbiAgICAgICAgICAgICAgICAgICAgc3RhdHVzRmlsdGVyID09PSBzXG4gICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXN1cmZhY2UtMiB0ZXh0LWlua1wiXG4gICAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtaW5rLXNlY29uZGFyeSBob3Zlcjp0ZXh0LWlua1wiXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtzID09PSBcIkFMTFwiID8gXCJBbGxcIiA6IFNUQVRVU19DT05GSUdbc10ubGFiZWx9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZD5cblxuICAgICAgICB7IWhpZXJhcmNoeSA/IChcbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0zIHAtNlwiIGFyaWEtbGFiZWw9XCJMb2FkaW5nIGdvYWxzXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMy41IHctMi8zIGFuaW1hdGUtcHVsc2Ugcm91bmRlZCBiZy1zdXJmYWNlLTJcIiAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTMuNSB3LTEvMiBhbmltYXRlLXB1bHNlIHJvdW5kZWQgYmctc3VyZmFjZS0yXCIgLz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLzUgYW5pbWF0ZS1wdWxzZSByb3VuZGVkIGJnLXN1cmZhY2UtMlwiIC8+XG4gICAgICAgICAgPC9DYXJkPlxuICAgICAgICApIDogZmlsdGVyZWRIaWVyYXJjaHkgJiYgZmlsdGVyZWRIaWVyYXJjaHkubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgIDxFbXB0eVN0YXRlXG4gICAgICAgICAgICBpY29uPXtUYXJnZXR9XG4gICAgICAgICAgICB0aXRsZT17c3RhdHVzRmlsdGVyID09PSBcIkFMTFwiID8gXCJObyBnb2FscyB5ZXRcIiA6IGBObyAke3N0YXR1c0ZpbHRlci50b0xvd2VyQ2FzZSgpfSBnb2Fsc2B9XG4gICAgICAgICAgICBkZXNjcmlwdGlvbj17XG4gICAgICAgICAgICAgIHN0YXR1c0ZpbHRlciA9PT0gXCJBTExcIlxuICAgICAgICAgICAgICAgID8gXCJTdGFydCBieSBkZWZpbmluZyB5b3VyIGNvbXBhbnkgbWlzc2lvbi5cIlxuICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBhY3Rpb249e1xuICAgICAgICAgICAgICBzdGF0dXNGaWx0ZXIgPT09IFwiQUxMXCIgPyAoXG4gICAgICAgICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93Q3JlYXRlKHRydWUpfSBzaXplPVwic21cIj5cbiAgICAgICAgICAgICAgICAgIENyZWF0ZSBGaXJzdCBHb2FsXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICkgOiB1bmRlZmluZWRcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAvPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBtaW4taC0wIGZsZXgtMSBnYXAtNCBvdmVyZmxvdy15LWF1dG8geGw6Z3JpZC1jb2xzLVttaW5tYXgoMCwxZnIpXzMyMHB4XVwiPlxuICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC00XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPkdvYWwgdHJlZTwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LVsxMi41cHhdIHRleHQtaW5rLW11dGVkXCI+RXhlY3V0aW9uIHNob3VsZCBsYWRkZXIgaW50byBzdHJhdGVneTwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICB7ZmlsdGVyZWRIaWVyYXJjaHk/Lm1hcCgocm9vdCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPEdvYWxOb2RlXG4gICAgICAgICAgICAgICAgICAgIGtleT17cm9vdC5faWR9XG4gICAgICAgICAgICAgICAgICAgIG5vZGU9e3Jvb3QgYXMgR29hbE5vZGVEYXRhfVxuICAgICAgICAgICAgICAgICAgICBkZXB0aD17MH1cbiAgICAgICAgICAgICAgICAgICAgcHJvamVjdElkPXtwcm9qZWN0SWR9XG4gICAgICAgICAgICAgICAgICAgIG9uVGFza1NlbGVjdD17b25UYXNrU2VsZWN0fVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L0NhcmQ+XG5cbiAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj5PcGVyYXRvciBndWlkYW5jZTwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgc3BhY2UteS0zIHRleHQtWzEzLjVweF0gbGVhZGluZy1yZWxheGVkIHRleHQtaW5rLXNlY29uZGFyeVwiPlxuICAgICAgICAgICAgICAgIDxwPkdvYWxzIHNob3VsZCBzdGF5IGZldywgc2hhcnAsIGFuZCBjYXVzYWwuIElmIGEgdGFzayBjYW5ub3QgdHJhY2UgYmFjayB0byBhIGdvYWwsIGl0IGlzIHdvcmsgd2l0aG91dCBhIHJlYXNvbi48L3A+XG4gICAgICAgICAgICAgICAgPHA+VXNlIGNvbXBhbnkgZ29hbHMgdG8gc2V0IGRpcmVjdGlvbiwgdGVhbSBnb2FscyB0byByb3V0ZSBvd25lcnNoaXAsIGFuZCB0YXNrIGdvYWxzIG9ubHkgd2hlbiB3b3JrIG5lZWRzIG1lYXN1cmFibGUgY2xvc3VyZS48L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yIHAtNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSBmb250LW1lZGl1bSB0ZXh0LWluay1tdXRlZFwiPkN1cnJlbnQgbWl4PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGdyaWQgZ2FwLTIgdGV4dC1bMTMuNXB4XVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1pbmstc2Vjb25kYXJ5XCI+QWN0aXZlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtaW5rXCI+e2FjdGl2ZUdvYWxzfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1pbmstc2Vjb25kYXJ5XCI+UGxhbm5lZDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPntwbGFubmVkR29hbHN9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWluay1zZWNvbmRhcnlcIj5BY2hpZXZlZDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPnthY2hpZXZlZEdvYWxzfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7c2hvd0NyZWF0ZSAmJiAoXG4gICAgICAgICAgPENyZWF0ZUdvYWxNb2RhbFxuICAgICAgICAgICAgcHJvamVjdElkPXtwcm9qZWN0SWR9XG4gICAgICAgICAgICBkZWZhdWx0TGV2ZWw9XCJDT01QQU5ZXCJcbiAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dDcmVhdGUoZmFsc2UpfVxuICAgICAgICAgIC8+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9Hb2Fsc1ZpZXcudHN4In0=