import {
  createSlot
} from "/node_modules/.vite/deps/chunk-GD4GA362.js?v=738cb978";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-JRFAWF3F.js?v=738cb978";
import {
  require_react_dom
} from "/node_modules/.vite/deps/chunk-NYLGIEKY.js?v=738cb978";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-GMP6FTHE.js?v=738cb978";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-G3PMV62Z.js?v=738cb978";

// ../../../../../../../../node_modules/.pnpm/@radix-ui+react-primitive@2.1.4_@types+react-dom@18.3.7_@types+react@18.3.27__@types+react@18_7xv35u3vy5hgjsmbuptvyfvnui/node_modules/@radix-ui/react-primitive/dist/index.mjs
var React = __toESM(require_react(), 1);
var ReactDOM = __toESM(require_react_dom(), 1);
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var NODES = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "select",
  "span",
  "svg",
  "ul"
];
var Primitive = NODES.reduce((primitive, node) => {
  const Slot = createSlot(`Primitive.${node}`);
  const Node = React.forwardRef((props, forwardedRef) => {
    const { asChild, ...primitiveProps } = props;
    const Comp = asChild ? Slot : node;
    if (typeof window !== "undefined") {
      window[Symbol.for("radix-ui")] = true;
    }
    return (0, import_jsx_runtime.jsx)(Comp, { ...primitiveProps, ref: forwardedRef });
  });
  Node.displayName = `Primitive.${node}`;
  return { ...primitive, [node]: Node };
}, {});

export {
  Primitive
};
//# sourceMappingURL=chunk-2L5UJEP7.js.map
