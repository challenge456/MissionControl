import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/KeyboardShortcuts.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { Button } from "/src/components/ui/button.tsx";
import { Separator } from "/src/components/ui/separator.tsx";
import { Keyboard } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
export function useKeyboardShortcuts({
  onNewTask,
  onSearch,
  onApprovals,
  onAgents,
  onCostAnalytics,
  onGoToBoard,
  onShowHelp,
  onMission
}) {
  _s();
  const pendingGRef = useRef(false);
  const gTimerRef = useRef(null);
  useEffect(() => {
    const handleKeyDown = (e) => {
      const target = e.target;
      if (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT" || target.isContentEditable) {
        return;
      }
      const isMod = e.metaKey || e.ctrlKey;
      if (isMod) {
        switch (e.key.toLowerCase()) {
          case "n":
            e.preventDefault();
            onNewTask();
            return;
          case "k":
            e.preventDefault();
            onSearch();
            return;
          case "a":
            if (!e.shiftKey) return;
            e.preventDefault();
            onApprovals();
            return;
          case "i":
            if (!e.shiftKey) return;
            e.preventDefault();
            onCostAnalytics?.();
            return;
          case "e":
            e.preventDefault();
            onAgents();
            return;
          case "m":
            e.preventDefault();
            onMission?.();
            return;
        }
        return;
      }
      switch (e.key) {
        case "/":
          e.preventDefault();
          onSearch();
          return;
        case "?":
          e.preventDefault();
          onShowHelp?.();
          return;
        case "g":
          pendingGRef.current = true;
          if (gTimerRef.current) clearTimeout(gTimerRef.current);
          gTimerRef.current = setTimeout(() => {
            pendingGRef.current = false;
          }, 500);
          return;
        case "b":
          if (pendingGRef.current) {
            e.preventDefault();
            pendingGRef.current = false;
            if (gTimerRef.current) clearTimeout(gTimerRef.current);
            onGoToBoard?.();
          }
          return;
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      if (gTimerRef.current) clearTimeout(gTimerRef.current);
    };
  }, [onNewTask, onSearch, onApprovals, onAgents, onCostAnalytics, onGoToBoard, onShowHelp, onMission]);
}
_s(useKeyboardShortcuts, "7oaNworsabKEQlg1thaIWjjgzQI=");
const shortcutGroups = [
  {
    title: "Navigation",
    shortcuts: [
      { keys: ["/"], description: "Focus search / command palette" },
      { keys: ["g", "b"], description: "Go to board" },
      { keys: ["?"], description: "Show keyboard shortcuts" }
    ]
  },
  {
    title: "Actions",
    shortcuts: [
      { keys: ["⌘", "N"], description: "Create new task" },
      { keys: ["⌘", "K"], description: "Open command palette" },
      { keys: ["⇧", "⌘", "A"], description: "View approvals" },
      { keys: ["⇧", "⌘", "I"], description: "Open cost analytics" },
      { keys: ["⌘", "E"], description: "View agents" },
      { keys: ["⌘", "M"], description: "Edit mission statement" },
      { keys: ["Insights"], description: "Top bar → Cost Analytics, Health, Monitoring" }
    ]
  },
  {
    title: "General",
    shortcuts: [
      { keys: ["Esc"], description: "Close modal / drawer" }
    ]
  }
];
export function KeyboardShortcutsHelp({ onClose }) {
  _s2();
  const [, setMounted] = useState(false);
  const closeRef = useRef(null);
  useEffect(() => {
    setMounted(true);
    closeRef.current?.focus();
    const handleEsc = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleEsc);
    return () => window.removeEventListener("keydown", handleEsc);
  }, [onClose]);
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "fixed inset-0 bg-black/70 flex items-center justify-center z-[1000]",
      onClick: onClose,
      role: "dialog",
      "aria-modal": "true",
      "aria-label": "Keyboard shortcuts",
      children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "bg-surface-3 border border-line rounded-xl p-6 max-w-[480px] w-full shadow-[var(--shadow-elevation-2)]",
          onClick: (e) => e.stopPropagation(),
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-5", children: [
              /* @__PURE__ */ jsxDEV(Keyboard, { className: "h-5 w-5 text-ink-muted", strokeWidth: 1.75 }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx",
                lineNumber: 191,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV("h2", { className: "text-[15px] font-semibold text-ink", children: "Keyboard Shortcuts" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx",
                lineNumber: 192,
                columnNumber: 11
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx",
              lineNumber: 190,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4", children: shortcutGroups.map(
              (group, gi) => /* @__PURE__ */ jsxDEV("div", { children: [
                gi > 0 && /* @__PURE__ */ jsxDEV(Separator, { className: "mb-3" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx",
                  lineNumber: 198,
                  columnNumber: 26
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-[11.5px] font-semibold text-ink-muted uppercase tracking-wider mb-2", children: group.title }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx",
                  lineNumber: 199,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-1.5", children: group.shortcuts.map(
                  (shortcut, si) => /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "flex items-center justify-between py-1.5",
                      children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-[13.5px] text-ink", children: shortcut.description }, void 0, false, {
                          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx",
                          lineNumber: 208,
                          columnNumber: 21
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1", children: shortcut.keys.map(
                          (key, ki) => /* @__PURE__ */ jsxDEV(
                            "kbd",
                            {
                              className: "inline-flex items-center justify-center min-w-[24px] h-6 px-1.5 bg-surface-2 border border-line rounded text-[11px] font-mono text-ink-muted",
                              children: key
                            },
                            ki,
                            false,
                            {
                              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx",
                              lineNumber: 211,
                              columnNumber: 19
                            },
                            this
                          )
                        ) }, void 0, false, {
                          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx",
                          lineNumber: 209,
                          columnNumber: 21
                        }, this)
                      ]
                    },
                    si,
                    true,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx",
                      lineNumber: 204,
                      columnNumber: 15
                    },
                    this
                  )
                ) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx",
                  lineNumber: 202,
                  columnNumber: 15
                }, this)
              ] }, group.title, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx",
                lineNumber: 197,
                columnNumber: 11
              }, this)
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx",
              lineNumber: 195,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                ref: closeRef,
                onClick: onClose,
                className: "w-full mt-5",
                size: "sm",
                children: "Got it"
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx",
                lineNumber: 226,
                columnNumber: 9
              },
              this
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx",
          lineNumber: 186,
          columnNumber: 7
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx",
      lineNumber: 179,
      columnNumber: 5
    },
    this
  );
}
_s2(KeyboardShortcutsHelp, "mk0Amp+0o/OKsSdfDjnfx14BbIc=");
_c = KeyboardShortcutsHelp;
var _c;
$RefreshReg$(_c, "KeyboardShortcutsHelp");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/KeyboardShortcuts.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMktVOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNLVixTQUFTQSxXQUFXQyxRQUFRQyxnQkFBZ0I7QUFDNUMsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsZ0JBQWdCO0FBYWxCLGdCQUFTQyxxQkFBcUI7QUFBQSxFQUNuQ0M7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDc0IsR0FBRztBQUFBQyxLQUFBO0FBQ3pCLFFBQU1DLGNBQWNmLE9BQU8sS0FBSztBQUNoQyxRQUFNZ0IsWUFBWWhCLE9BQTZDLElBQUk7QUFFbkVELFlBQVUsTUFBTTtBQUNkLFVBQU1rQixnQkFBZ0JBLENBQUNDLE1BQXFCO0FBRTFDLFlBQU1DLFNBQVNELEVBQUVDO0FBQ2pCLFVBQ0VBLE9BQU9DLFlBQVksV0FDbkJELE9BQU9DLFlBQVksY0FDbkJELE9BQU9DLFlBQVksWUFDbkJELE9BQU9FLG1CQUNQO0FBQ0E7QUFBQSxNQUNGO0FBRUEsWUFBTUMsUUFBUUosRUFBRUssV0FBV0wsRUFBRU07QUFHN0IsVUFBSUYsT0FBTztBQUNULGdCQUFRSixFQUFFTyxJQUFJQyxZQUFZLEdBQUM7QUFBQSxVQUN6QixLQUFLO0FBQ0hSLGNBQUVTLGVBQWU7QUFDakJyQixzQkFBVTtBQUNWO0FBQUEsVUFDRixLQUFLO0FBQ0hZLGNBQUVTLGVBQWU7QUFDakJwQixxQkFBUztBQUNUO0FBQUEsVUFDRixLQUFLO0FBQ0gsZ0JBQUksQ0FBQ1csRUFBRVUsU0FBVTtBQUNqQlYsY0FBRVMsZUFBZTtBQUNqQm5CLHdCQUFZO0FBQ1o7QUFBQSxVQUNGLEtBQUs7QUFDSCxnQkFBSSxDQUFDVSxFQUFFVSxTQUFVO0FBQ2pCVixjQUFFUyxlQUFlO0FBQ2pCakIsOEJBQWtCO0FBQ2xCO0FBQUEsVUFDRixLQUFLO0FBQ0hRLGNBQUVTLGVBQWU7QUFDakJsQixxQkFBUztBQUNUO0FBQUEsVUFDRixLQUFLO0FBQ0hTLGNBQUVTLGVBQWU7QUFDakJkLHdCQUFZO0FBQ1o7QUFBQSxRQUNKO0FBQ0E7QUFBQSxNQUNGO0FBR0EsY0FBUUssRUFBRU8sS0FBRztBQUFBLFFBQ1gsS0FBSztBQUNIUCxZQUFFUyxlQUFlO0FBQ2pCcEIsbUJBQVM7QUFDVDtBQUFBLFFBQ0YsS0FBSztBQUNIVyxZQUFFUyxlQUFlO0FBQ2pCZix1QkFBYTtBQUNiO0FBQUEsUUFDRixLQUFLO0FBRUhHLHNCQUFZYyxVQUFVO0FBQ3RCLGNBQUliLFVBQVVhLFFBQVNDLGNBQWFkLFVBQVVhLE9BQU87QUFDckRiLG9CQUFVYSxVQUFVRSxXQUFXLE1BQU07QUFDbkNoQix3QkFBWWMsVUFBVTtBQUFBLFVBQ3hCLEdBQUcsR0FBRztBQUNOO0FBQUEsUUFDRixLQUFLO0FBQ0gsY0FBSWQsWUFBWWMsU0FBUztBQUN2QlgsY0FBRVMsZUFBZTtBQUNqQlosd0JBQVljLFVBQVU7QUFDdEIsZ0JBQUliLFVBQVVhLFFBQVNDLGNBQWFkLFVBQVVhLE9BQU87QUFDckRsQiwwQkFBYztBQUFBLFVBQ2hCO0FBQ0E7QUFBQSxNQUNKO0FBQUEsSUFDRjtBQUVBcUIsV0FBT0MsaUJBQWlCLFdBQVdoQixhQUFhO0FBQ2hELFdBQU8sTUFBTTtBQUNYZSxhQUFPRSxvQkFBb0IsV0FBV2pCLGFBQWE7QUFDbkQsVUFBSUQsVUFBVWEsUUFBU0MsY0FBYWQsVUFBVWEsT0FBTztBQUFBLElBQ3ZEO0FBQUEsRUFDRixHQUFHLENBQUN2QixXQUFXQyxVQUFVQyxhQUFhQyxVQUFVQyxpQkFBaUJDLGFBQWFDLFlBQVlDLFNBQVMsQ0FBQztBQUN0RztBQUFDQyxHQWhHZVQsc0JBQW9CO0FBa0dwQyxNQUFNOEIsaUJBQWlCO0FBQUEsRUFDckI7QUFBQSxJQUNFQyxPQUFPO0FBQUEsSUFDUEMsV0FBVztBQUFBLE1BQ1QsRUFBRUMsTUFBTSxDQUFDLEdBQUcsR0FBR0MsYUFBYSxpQ0FBaUM7QUFBQSxNQUM3RCxFQUFFRCxNQUFNLENBQUMsS0FBSyxHQUFHLEdBQUdDLGFBQWEsY0FBYztBQUFBLE1BQy9DLEVBQUVELE1BQU0sQ0FBQyxHQUFHLEdBQUdDLGFBQWEsMEJBQTBCO0FBQUEsSUFBQztBQUFBLEVBRTNEO0FBQUEsRUFDQTtBQUFBLElBQ0VILE9BQU87QUFBQSxJQUNQQyxXQUFXO0FBQUEsTUFDVCxFQUFFQyxNQUFNLENBQUMsS0FBSyxHQUFHLEdBQUdDLGFBQWEsa0JBQWtCO0FBQUEsTUFDbkQsRUFBRUQsTUFBTSxDQUFDLEtBQUssR0FBRyxHQUFHQyxhQUFhLHVCQUF1QjtBQUFBLE1BQ3hELEVBQUVELE1BQU0sQ0FBQyxLQUFLLEtBQUssR0FBRyxHQUFHQyxhQUFhLGlCQUFpQjtBQUFBLE1BQ3ZELEVBQUVELE1BQU0sQ0FBQyxLQUFLLEtBQUssR0FBRyxHQUFHQyxhQUFhLHNCQUFzQjtBQUFBLE1BQzVELEVBQUVELE1BQU0sQ0FBQyxLQUFLLEdBQUcsR0FBR0MsYUFBYSxjQUFjO0FBQUEsTUFDL0MsRUFBRUQsTUFBTSxDQUFDLEtBQUssR0FBRyxHQUFHQyxhQUFhLHlCQUF5QjtBQUFBLE1BQzFELEVBQUVELE1BQU0sQ0FBQyxVQUFVLEdBQUdDLGFBQWEsK0NBQStDO0FBQUEsSUFBQztBQUFBLEVBRXZGO0FBQUEsRUFDQTtBQUFBLElBQ0VILE9BQU87QUFBQSxJQUNQQyxXQUFXO0FBQUEsTUFDVCxFQUFFQyxNQUFNLENBQUMsS0FBSyxHQUFHQyxhQUFhLHVCQUF1QjtBQUFBLElBQUM7QUFBQSxFQUUxRDtBQUFDO0FBR0ksZ0JBQVNDLHNCQUFzQixFQUFFQyxRQUFpQyxHQUFHO0FBQUFDLE1BQUE7QUFDMUUsUUFBTSxHQUFHQyxVQUFVLElBQUkxQyxTQUFTLEtBQUs7QUFDckMsUUFBTTJDLFdBQVc1QyxPQUEwQixJQUFJO0FBRS9DRCxZQUFVLE1BQU07QUFDZDRDLGVBQVcsSUFBSTtBQUNmQyxhQUFTZixTQUFTZ0IsTUFBTTtBQUV4QixVQUFNQyxZQUFZQSxDQUFDNUIsTUFBcUI7QUFDdEMsVUFBSUEsRUFBRU8sUUFBUSxTQUFVZ0IsU0FBUTtBQUFBLElBQ2xDO0FBQ0FULFdBQU9DLGlCQUFpQixXQUFXYSxTQUFTO0FBQzVDLFdBQU8sTUFBTWQsT0FBT0Usb0JBQW9CLFdBQVdZLFNBQVM7QUFBQSxFQUM5RCxHQUFHLENBQUNMLE9BQU8sQ0FBQztBQUVaLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVU7QUFBQSxNQUNWLFNBQVNBO0FBQUFBLE1BQ1QsTUFBSztBQUFBLE1BQ0wsY0FBVztBQUFBLE1BQ1gsY0FBVztBQUFBLE1BRVg7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVU7QUFBQSxVQUNWLFNBQVMsQ0FBQ3ZCLE1BQU1BLEVBQUU2QixnQkFBZ0I7QUFBQSxVQUVsQztBQUFBLG1DQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLHFDQUFDLFlBQVMsV0FBVSwwQkFBeUIsYUFBYSxRQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErRDtBQUFBLGNBQy9ELHVCQUFDLFFBQUcsV0FBVSxzQ0FBcUMsa0NBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFFO0FBQUEsaUJBRnZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSx1QkFDWloseUJBQWVhO0FBQUFBLGNBQUksQ0FBQ0MsT0FBT0MsT0FDMUIsdUJBQUMsU0FDRUE7QUFBQUEscUJBQUssS0FBSyx1QkFBQyxhQUFVLFdBQVUsVUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkI7QUFBQSxnQkFDdEMsdUJBQUMsT0FBRSxXQUFVLDRFQUNWRCxnQkFBTWIsU0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNaYSxnQkFBTVosVUFBVVc7QUFBQUEsa0JBQUksQ0FBQ0csVUFBVUMsT0FDOUI7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBRUMsV0FBVTtBQUFBLHNCQUVWO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBCQUEwQkQsbUJBQVNaLGVBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQStEO0FBQUEsd0JBQy9ELHVCQUFDLFNBQUksV0FBVSxjQUNaWSxtQkFBU2IsS0FBS1U7QUFBQUEsMEJBQUksQ0FBQ3ZCLEtBQUs0QixPQUN2QjtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFFQyxXQUFVO0FBQUEsOEJBRVQ1QjtBQUFBQTtBQUFBQSw0QkFISTRCO0FBQUFBLDRCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBS0E7QUFBQSx3QkFDRCxLQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBU0E7QUFBQTtBQUFBO0FBQUEsb0JBYktEO0FBQUFBLG9CQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBZUE7QUFBQSxnQkFDRCxLQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1CQTtBQUFBLG1CQXhCUUgsTUFBTWIsT0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF5QkE7QUFBQSxZQUNELEtBNUJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkJBO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLEtBQUtRO0FBQUFBLGdCQUNMLFNBQVNIO0FBQUFBLGdCQUNULFdBQVU7QUFBQSxnQkFDVixNQUFLO0FBQUEsZ0JBQUk7QUFBQTtBQUFBLGNBSlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQTtBQUFBO0FBQUEsUUEvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BZ0RBO0FBQUE7QUFBQSxJQXZERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUF3REE7QUFFSjtBQUFDQyxJQTFFZUYsdUJBQXFCO0FBQUEsS0FBckJBO0FBQXFCLElBQUFjO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVN0YXRlIiwiQnV0dG9uIiwiU2VwYXJhdG9yIiwiS2V5Ym9hcmQiLCJ1c2VLZXlib2FyZFNob3J0Y3V0cyIsIm9uTmV3VGFzayIsIm9uU2VhcmNoIiwib25BcHByb3ZhbHMiLCJvbkFnZW50cyIsIm9uQ29zdEFuYWx5dGljcyIsIm9uR29Ub0JvYXJkIiwib25TaG93SGVscCIsIm9uTWlzc2lvbiIsIl9zIiwicGVuZGluZ0dSZWYiLCJnVGltZXJSZWYiLCJoYW5kbGVLZXlEb3duIiwiZSIsInRhcmdldCIsInRhZ05hbWUiLCJpc0NvbnRlbnRFZGl0YWJsZSIsImlzTW9kIiwibWV0YUtleSIsImN0cmxLZXkiLCJrZXkiLCJ0b0xvd2VyQ2FzZSIsInByZXZlbnREZWZhdWx0Iiwic2hpZnRLZXkiLCJjdXJyZW50IiwiY2xlYXJUaW1lb3V0Iiwic2V0VGltZW91dCIsIndpbmRvdyIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwic2hvcnRjdXRHcm91cHMiLCJ0aXRsZSIsInNob3J0Y3V0cyIsImtleXMiLCJkZXNjcmlwdGlvbiIsIktleWJvYXJkU2hvcnRjdXRzSGVscCIsIm9uQ2xvc2UiLCJfczIiLCJzZXRNb3VudGVkIiwiY2xvc2VSZWYiLCJmb2N1cyIsImhhbmRsZUVzYyIsInN0b3BQcm9wYWdhdGlvbiIsIm1hcCIsImdyb3VwIiwiZ2kiLCJzaG9ydGN1dCIsInNpIiwia2kiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJLZXlib2FyZFNob3J0Y3V0cy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuaW1wb3J0IHsgU2VwYXJhdG9yIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9zZXBhcmF0b3JcIjtcbmltcG9ydCB7IEtleWJvYXJkIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuXG5pbnRlcmZhY2UgS2V5Ym9hcmRTaG9ydGN1dHNQcm9wcyB7XG4gIG9uTmV3VGFzazogKCkgPT4gdm9pZDtcbiAgb25TZWFyY2g6ICgpID0+IHZvaWQ7XG4gIG9uQXBwcm92YWxzOiAoKSA9PiB2b2lkO1xuICBvbkFnZW50czogKCkgPT4gdm9pZDtcbiAgb25Db3N0QW5hbHl0aWNzPzogKCkgPT4gdm9pZDtcbiAgb25Hb1RvQm9hcmQ/OiAoKSA9PiB2b2lkO1xuICBvblNob3dIZWxwPzogKCkgPT4gdm9pZDtcbiAgb25NaXNzaW9uPzogKCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUtleWJvYXJkU2hvcnRjdXRzKHtcbiAgb25OZXdUYXNrLFxuICBvblNlYXJjaCxcbiAgb25BcHByb3ZhbHMsXG4gIG9uQWdlbnRzLFxuICBvbkNvc3RBbmFseXRpY3MsXG4gIG9uR29Ub0JvYXJkLFxuICBvblNob3dIZWxwLFxuICBvbk1pc3Npb24sXG59OiBLZXlib2FyZFNob3J0Y3V0c1Byb3BzKSB7XG4gIGNvbnN0IHBlbmRpbmdHUmVmID0gdXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgZ1RpbWVyUmVmID0gdXNlUmVmPFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgbnVsbD4obnVsbCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBoYW5kbGVLZXlEb3duID0gKGU6IEtleWJvYXJkRXZlbnQpID0+IHtcbiAgICAgIC8vIERvbid0IGNhcHR1cmUgd2hlbiB0eXBpbmcgaW4gaW5wdXRzXG4gICAgICBjb25zdCB0YXJnZXQgPSBlLnRhcmdldCBhcyBIVE1MRWxlbWVudDtcbiAgICAgIGlmIChcbiAgICAgICAgdGFyZ2V0LnRhZ05hbWUgPT09IFwiSU5QVVRcIiB8fFxuICAgICAgICB0YXJnZXQudGFnTmFtZSA9PT0gXCJURVhUQVJFQVwiIHx8XG4gICAgICAgIHRhcmdldC50YWdOYW1lID09PSBcIlNFTEVDVFwiIHx8XG4gICAgICAgIHRhcmdldC5pc0NvbnRlbnRFZGl0YWJsZVxuICAgICAgKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgY29uc3QgaXNNb2QgPSBlLm1ldGFLZXkgfHwgZS5jdHJsS2V5O1xuXG4gICAgICAvLyBNb2Qgc2hvcnRjdXRzXG4gICAgICBpZiAoaXNNb2QpIHtcbiAgICAgICAgc3dpdGNoIChlLmtleS50b0xvd2VyQ2FzZSgpKSB7XG4gICAgICAgICAgY2FzZSBcIm5cIjpcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgIG9uTmV3VGFzaygpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIGNhc2UgXCJrXCI6XG4gICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICBvblNlYXJjaCgpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIGNhc2UgXCJhXCI6XG4gICAgICAgICAgICBpZiAoIWUuc2hpZnRLZXkpIHJldHVybjtcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgIG9uQXBwcm92YWxzKCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgY2FzZSBcImlcIjpcbiAgICAgICAgICAgIGlmICghZS5zaGlmdEtleSkgcmV0dXJuO1xuICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgb25Db3N0QW5hbHl0aWNzPy4oKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICBjYXNlIFwiZVwiOlxuICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgb25BZ2VudHMoKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICBjYXNlIFwibVwiOlxuICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgb25NaXNzaW9uPy4oKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIC8vIE5vbi1tb2Qgc2hvcnRjdXRzXG4gICAgICBzd2l0Y2ggKGUua2V5KSB7XG4gICAgICAgIGNhc2UgXCIvXCI6XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIG9uU2VhcmNoKCk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICBjYXNlIFwiP1wiOlxuICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICBvblNob3dIZWxwPy4oKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIGNhc2UgXCJnXCI6XG4gICAgICAgICAgLy8gU3RhcnQgXCJnIHRoZW4gLi4uXCIgc2VxdWVuY2VcbiAgICAgICAgICBwZW5kaW5nR1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgICBpZiAoZ1RpbWVyUmVmLmN1cnJlbnQpIGNsZWFyVGltZW91dChnVGltZXJSZWYuY3VycmVudCk7XG4gICAgICAgICAgZ1RpbWVyUmVmLmN1cnJlbnQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIHBlbmRpbmdHUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgICB9LCA1MDApO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgY2FzZSBcImJcIjpcbiAgICAgICAgICBpZiAocGVuZGluZ0dSZWYuY3VycmVudCkge1xuICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgcGVuZGluZ0dSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICAgICAgaWYgKGdUaW1lclJlZi5jdXJyZW50KSBjbGVhclRpbWVvdXQoZ1RpbWVyUmVmLmN1cnJlbnQpO1xuICAgICAgICAgICAgb25Hb1RvQm9hcmQ/LigpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfTtcblxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBoYW5kbGVLZXlEb3duKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGhhbmRsZUtleURvd24pO1xuICAgICAgaWYgKGdUaW1lclJlZi5jdXJyZW50KSBjbGVhclRpbWVvdXQoZ1RpbWVyUmVmLmN1cnJlbnQpO1xuICAgIH07XG4gIH0sIFtvbk5ld1Rhc2ssIG9uU2VhcmNoLCBvbkFwcHJvdmFscywgb25BZ2VudHMsIG9uQ29zdEFuYWx5dGljcywgb25Hb1RvQm9hcmQsIG9uU2hvd0hlbHAsIG9uTWlzc2lvbl0pO1xufVxuXG5jb25zdCBzaG9ydGN1dEdyb3VwcyA9IFtcbiAge1xuICAgIHRpdGxlOiBcIk5hdmlnYXRpb25cIixcbiAgICBzaG9ydGN1dHM6IFtcbiAgICAgIHsga2V5czogW1wiL1wiXSwgZGVzY3JpcHRpb246IFwiRm9jdXMgc2VhcmNoIC8gY29tbWFuZCBwYWxldHRlXCIgfSxcbiAgICAgIHsga2V5czogW1wiZ1wiLCBcImJcIl0sIGRlc2NyaXB0aW9uOiBcIkdvIHRvIGJvYXJkXCIgfSxcbiAgICAgIHsga2V5czogW1wiP1wiXSwgZGVzY3JpcHRpb246IFwiU2hvdyBrZXlib2FyZCBzaG9ydGN1dHNcIiB9LFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICB0aXRsZTogXCJBY3Rpb25zXCIsXG4gICAgc2hvcnRjdXRzOiBbXG4gICAgICB7IGtleXM6IFtcIuKMmFwiLCBcIk5cIl0sIGRlc2NyaXB0aW9uOiBcIkNyZWF0ZSBuZXcgdGFza1wiIH0sXG4gICAgICB7IGtleXM6IFtcIuKMmFwiLCBcIktcIl0sIGRlc2NyaXB0aW9uOiBcIk9wZW4gY29tbWFuZCBwYWxldHRlXCIgfSxcbiAgICAgIHsga2V5czogW1wi4oenXCIsIFwi4oyYXCIsIFwiQVwiXSwgZGVzY3JpcHRpb246IFwiVmlldyBhcHByb3ZhbHNcIiB9LFxuICAgICAgeyBrZXlzOiBbXCLih6dcIiwgXCLijJhcIiwgXCJJXCJdLCBkZXNjcmlwdGlvbjogXCJPcGVuIGNvc3QgYW5hbHl0aWNzXCIgfSxcbiAgICAgIHsga2V5czogW1wi4oyYXCIsIFwiRVwiXSwgZGVzY3JpcHRpb246IFwiVmlldyBhZ2VudHNcIiB9LFxuICAgICAgeyBrZXlzOiBbXCLijJhcIiwgXCJNXCJdLCBkZXNjcmlwdGlvbjogXCJFZGl0IG1pc3Npb24gc3RhdGVtZW50XCIgfSxcbiAgICAgIHsga2V5czogW1wiSW5zaWdodHNcIl0sIGRlc2NyaXB0aW9uOiBcIlRvcCBiYXIg4oaSIENvc3QgQW5hbHl0aWNzLCBIZWFsdGgsIE1vbml0b3JpbmdcIiB9LFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICB0aXRsZTogXCJHZW5lcmFsXCIsXG4gICAgc2hvcnRjdXRzOiBbXG4gICAgICB7IGtleXM6IFtcIkVzY1wiXSwgZGVzY3JpcHRpb246IFwiQ2xvc2UgbW9kYWwgLyBkcmF3ZXJcIiB9LFxuICAgIF0sXG4gIH0sXG5dO1xuXG5leHBvcnQgZnVuY3Rpb24gS2V5Ym9hcmRTaG9ydGN1dHNIZWxwKHsgb25DbG9zZSB9OiB7IG9uQ2xvc2U6ICgpID0+IHZvaWQgfSkge1xuICBjb25zdCBbLCBzZXRNb3VudGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgY2xvc2VSZWYgPSB1c2VSZWY8SFRNTEJ1dHRvbkVsZW1lbnQ+KG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2V0TW91bnRlZCh0cnVlKTtcbiAgICBjbG9zZVJlZi5jdXJyZW50Py5mb2N1cygpO1xuXG4gICAgY29uc3QgaGFuZGxlRXNjID0gKGU6IEtleWJvYXJkRXZlbnQpID0+IHtcbiAgICAgIGlmIChlLmtleSA9PT0gXCJFc2NhcGVcIikgb25DbG9zZSgpO1xuICAgIH07XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGhhbmRsZUVzYyk7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBoYW5kbGVFc2MpO1xuICB9LCBbb25DbG9zZV0pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjay83MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB6LVsxMDAwXVwiXG4gICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgcm9sZT1cImRpYWxvZ1wiXG4gICAgICBhcmlhLW1vZGFsPVwidHJ1ZVwiXG4gICAgICBhcmlhLWxhYmVsPVwiS2V5Ym9hcmQgc2hvcnRjdXRzXCJcbiAgICA+XG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzTmFtZT1cImJnLXN1cmZhY2UtMyBib3JkZXIgYm9yZGVyLWxpbmUgcm91bmRlZC14bCBwLTYgbWF4LXctWzQ4MHB4XSB3LWZ1bGwgc2hhZG93LVt2YXIoLS1zaGFkb3ctZWxldmF0aW9uLTIpXVwiXG4gICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTVcIj5cbiAgICAgICAgICA8S2V5Ym9hcmQgY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LWluay1tdXRlZFwiIHN0cm9rZVdpZHRoPXsxLjc1fSAvPlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+S2V5Ym9hcmQgU2hvcnRjdXRzPC9oMj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00XCI+XG4gICAgICAgICAge3Nob3J0Y3V0R3JvdXBzLm1hcCgoZ3JvdXAsIGdpKSA9PiAoXG4gICAgICAgICAgICA8ZGl2IGtleT17Z3JvdXAudGl0bGV9PlxuICAgICAgICAgICAgICB7Z2kgPiAwICYmIDxTZXBhcmF0b3IgY2xhc3NOYW1lPVwibWItM1wiIC8+fVxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMS41cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmstbXV0ZWQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTJcIj5cbiAgICAgICAgICAgICAgICB7Z3JvdXAudGl0bGV9XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICB7Z3JvdXAuc2hvcnRjdXRzLm1hcCgoc2hvcnRjdXQsIHNpKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIGtleT17c2l9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweS0xLjVcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMy41cHhdIHRleHQtaW5rXCI+e3Nob3J0Y3V0LmRlc2NyaXB0aW9ufTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3Nob3J0Y3V0LmtleXMubWFwKChrZXksIGtpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8a2JkXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17a2l9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtaW4tdy1bMjRweF0gaC02IHB4LTEuNSBiZy1zdXJmYWNlLTIgYm9yZGVyIGJvcmRlci1saW5lIHJvdW5kZWQgdGV4dC1bMTFweF0gZm9udC1tb25vIHRleHQtaW5rLW11dGVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2tleX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwva2JkPlxuICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgcmVmPXtjbG9zZVJlZn1cbiAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtdC01XCJcbiAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICA+XG4gICAgICAgICAgR290IGl0XG4gICAgICAgIDwvQnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9LZXlib2FyZFNob3J0Y3V0cy50c3gifQ==