import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/contexts/PrivacyContext.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/contexts/PrivacyContext.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const createContext = __vite__cjsImport3_react["createContext"]; const useContext = __vite__cjsImport3_react["useContext"]; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useCallback = __vite__cjsImport3_react["useCallback"];
const STORAGE_KEY = "mc.privacy_mode";
const PrivacyContext = createContext({
  privacyMode: false,
  setPrivacyMode: () => {
  },
  togglePrivacyMode: () => {
  }
});
export function usePrivacy() {
  _s();
  const ctx = useContext(PrivacyContext);
  if (!ctx) throw new Error("usePrivacy must be used within PrivacyProvider");
  return ctx;
}
_s(usePrivacy, "/dMy7t63NXD4eYACoT93CePwGrg=");
export function PrivacyProvider({ children }) {
  _s2();
  const [privacyMode, setPrivacyModeState] = useState(() => {
    if (typeof window === "undefined") return false;
    return window.localStorage.getItem(STORAGE_KEY) === "1";
  });
  useEffect(() => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem(STORAGE_KEY, privacyMode ? "1" : "0");
    }
  }, [privacyMode]);
  const setPrivacyMode = useCallback((value) => setPrivacyModeState(value), []);
  const togglePrivacyMode = useCallback(() => setPrivacyModeState((v) => !v), []);
  return /* @__PURE__ */ jsxDEV(PrivacyContext.Provider, { value: { privacyMode, setPrivacyMode, togglePrivacyMode }, children }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/contexts/PrivacyContext.tsx",
    lineNumber: 58,
    columnNumber: 5
  }, this);
}
_s2(PrivacyProvider, "MePTPU2FYBn4BYq2jmQV176DNt0=");
_c = PrivacyProvider;
var _c;
$RefreshReg$(_c, "PrivacyProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/contexts/PrivacyContext.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/contexts/PrivacyContext.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0NJOzs7Ozs7Ozs7Ozs7Ozs7OztBQXRDSixTQUFTQSxlQUFlQyxZQUFZQyxVQUFVQyxXQUFXQyxtQkFBbUI7QUFFNUUsTUFBTUMsY0FBYztBQVFwQixNQUFNQyxpQkFBaUJOLGNBQWtDO0FBQUEsRUFDdkRPLGFBQWE7QUFBQSxFQUNiQyxnQkFBZ0JBLE1BQU07QUFBQSxFQUFDO0FBQUEsRUFDdkJDLG1CQUFtQkEsTUFBTTtBQUFBLEVBQUM7QUFDNUIsQ0FBQztBQUVNLGdCQUFTQyxhQUFhO0FBQUFDLEtBQUE7QUFDM0IsUUFBTUMsTUFBTVgsV0FBV0ssY0FBYztBQUNyQyxNQUFJLENBQUNNLElBQUssT0FBTSxJQUFJQyxNQUFNLGdEQUFnRDtBQUMxRSxTQUFPRDtBQUNUO0FBQUNELEdBSmVELFlBQVU7QUFNbkIsZ0JBQVNJLGdCQUFnQixFQUFFQyxTQUF3QyxHQUFHO0FBQUFDLE1BQUE7QUFDM0UsUUFBTSxDQUFDVCxhQUFhVSxtQkFBbUIsSUFBSWYsU0FBUyxNQUFNO0FBQ3hELFFBQUksT0FBT2dCLFdBQVcsWUFBYSxRQUFPO0FBQzFDLFdBQU9BLE9BQU9DLGFBQWFDLFFBQVFmLFdBQVcsTUFBTTtBQUFBLEVBQ3RELENBQUM7QUFFREYsWUFBVSxNQUFNO0FBQ2QsUUFBSSxPQUFPZSxXQUFXLGFBQWE7QUFDakNBLGFBQU9DLGFBQWFFLFFBQVFoQixhQUFhRSxjQUFjLE1BQU0sR0FBRztBQUFBLElBQ2xFO0FBQUEsRUFDRixHQUFHLENBQUNBLFdBQVcsQ0FBQztBQUVoQixRQUFNQyxpQkFBaUJKLFlBQVksQ0FBQ2tCLFVBQW1CTCxvQkFBb0JLLEtBQUssR0FBRyxFQUFFO0FBQ3JGLFFBQU1iLG9CQUFvQkwsWUFBWSxNQUFNYSxvQkFBb0IsQ0FBQ00sTUFBTSxDQUFDQSxDQUFDLEdBQUcsRUFBRTtBQUU5RSxTQUNFLHVCQUFDLGVBQWUsVUFBZixFQUF3QixPQUFPLEVBQUVoQixhQUFhQyxnQkFBZ0JDLGtCQUFrQixHQUM5RU0sWUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDQyxJQXBCZUYsaUJBQWU7QUFBQSxLQUFmQTtBQUFlLElBQUFVO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbImNyZWF0ZUNvbnRleHQiLCJ1c2VDb250ZXh0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VDYWxsYmFjayIsIlNUT1JBR0VfS0VZIiwiUHJpdmFjeUNvbnRleHQiLCJwcml2YWN5TW9kZSIsInNldFByaXZhY3lNb2RlIiwidG9nZ2xlUHJpdmFjeU1vZGUiLCJ1c2VQcml2YWN5IiwiX3MiLCJjdHgiLCJFcnJvciIsIlByaXZhY3lQcm92aWRlciIsImNoaWxkcmVuIiwiX3MyIiwic2V0UHJpdmFjeU1vZGVTdGF0ZSIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJzZXRJdGVtIiwidmFsdWUiLCJ2IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHJpdmFjeUNvbnRleHQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIHVzZUNvbnRleHQsIHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZUNhbGxiYWNrIH0gZnJvbSBcInJlYWN0XCI7XG5cbmNvbnN0IFNUT1JBR0VfS0VZID0gXCJtYy5wcml2YWN5X21vZGVcIjtcblxuaW50ZXJmYWNlIFByaXZhY3lDb250ZXh0VHlwZSB7XG4gIHByaXZhY3lNb2RlOiBib29sZWFuO1xuICBzZXRQcml2YWN5TW9kZTogKHZhbHVlOiBib29sZWFuKSA9PiB2b2lkO1xuICB0b2dnbGVQcml2YWN5TW9kZTogKCkgPT4gdm9pZDtcbn1cblxuY29uc3QgUHJpdmFjeUNvbnRleHQgPSBjcmVhdGVDb250ZXh0PFByaXZhY3lDb250ZXh0VHlwZT4oe1xuICBwcml2YWN5TW9kZTogZmFsc2UsXG4gIHNldFByaXZhY3lNb2RlOiAoKSA9PiB7fSxcbiAgdG9nZ2xlUHJpdmFjeU1vZGU6ICgpID0+IHt9LFxufSk7XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VQcml2YWN5KCkge1xuICBjb25zdCBjdHggPSB1c2VDb250ZXh0KFByaXZhY3lDb250ZXh0KTtcbiAgaWYgKCFjdHgpIHRocm93IG5ldyBFcnJvcihcInVzZVByaXZhY3kgbXVzdCBiZSB1c2VkIHdpdGhpbiBQcml2YWN5UHJvdmlkZXJcIik7XG4gIHJldHVybiBjdHg7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBQcml2YWN5UHJvdmlkZXIoeyBjaGlsZHJlbiB9OiB7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGUgfSkge1xuICBjb25zdCBbcHJpdmFjeU1vZGUsIHNldFByaXZhY3lNb2RlU3RhdGVdID0gdXNlU3RhdGUoKCkgPT4ge1xuICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gZmFsc2U7XG4gICAgcmV0dXJuIHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShTVE9SQUdFX0tFWSkgPT09IFwiMVwiO1xuICB9KTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oU1RPUkFHRV9LRVksIHByaXZhY3lNb2RlID8gXCIxXCIgOiBcIjBcIik7XG4gICAgfVxuICB9LCBbcHJpdmFjeU1vZGVdKTtcblxuICBjb25zdCBzZXRQcml2YWN5TW9kZSA9IHVzZUNhbGxiYWNrKCh2YWx1ZTogYm9vbGVhbikgPT4gc2V0UHJpdmFjeU1vZGVTdGF0ZSh2YWx1ZSksIFtdKTtcbiAgY29uc3QgdG9nZ2xlUHJpdmFjeU1vZGUgPSB1c2VDYWxsYmFjaygoKSA9PiBzZXRQcml2YWN5TW9kZVN0YXRlKCh2KSA9PiAhdiksIFtdKTtcblxuICByZXR1cm4gKFxuICAgIDxQcml2YWN5Q29udGV4dC5Qcm92aWRlciB2YWx1ZT17eyBwcml2YWN5TW9kZSwgc2V0UHJpdmFjeU1vZGUsIHRvZ2dsZVByaXZhY3lNb2RlIH19PlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvUHJpdmFjeUNvbnRleHQuUHJvdmlkZXI+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9jb250ZXh0cy9Qcml2YWN5Q29udGV4dC50c3gifQ==