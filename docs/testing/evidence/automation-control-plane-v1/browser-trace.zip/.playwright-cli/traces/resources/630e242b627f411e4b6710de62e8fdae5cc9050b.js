import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/controlPlane/RunRecoveryPanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { RotateCcw } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { Button } from "/src/components/ui/button.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { Textarea } from "/src/components/ui/textarea.tsx";
export function RunRecoveryPanel({
  runId,
  failureSummary,
  busy = false,
  onRetry
}) {
  _s();
  const [reason, setReason] = useState("");
  const [error, setError] = useState(null);
  const [recoveryStarted, setRecoveryStarted] = useState(false);
  const normalizedReason = reason.trim();
  useEffect(() => {
    setReason("");
    setError(null);
    setRecoveryStarted(false);
  }, [runId]);
  if (!onRetry) {
    return /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-line bg-surface-2 p-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] font-medium text-ink", children: "Recovery requires the linked WorkOrder" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-[12.5px] text-ink-secondary", children: "Open this run from Work Orders to start a governed recovery attempt." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
        lineNumber: 52,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
      lineNumber: 50,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-err/30 bg-err-soft p-4", "aria-live": "polite", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
    /* @__PURE__ */ jsxDEV(RotateCcw, { className: "mt-0.5 h-4 w-4 shrink-0 text-err", strokeWidth: 1.7, "aria-hidden": true }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
      lineNumber: 62,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] font-medium text-ink", children: "Start a recovery run" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
        lineNumber: 64,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-[12.5px] leading-5 text-ink-secondary", children: "This creates a new run from the current WorkOrder. The failed run, error, timeline, and artifacts remain unchanged." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
        lineNumber: 65,
        columnNumber: 11
      }, this),
      failureSummary ? /* @__PURE__ */ jsxDEV("div", { className: "mt-3 rounded-lg border border-line bg-surface-1 px-3 py-2 text-[12.5px] text-ink-secondary", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-ink", children: "Original failure:" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
          lineNumber: 70,
          columnNumber: 15
        }, this),
        " ",
        failureSummary
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
        lineNumber: 69,
        columnNumber: 11
      }, this) : null,
      recoveryStarted ? /* @__PURE__ */ jsxDEV("div", { className: "mt-3 rounded-lg border border-ok/30 bg-ok-soft px-3 py-2 text-[12.5px] text-ok", children: "Recovery run created. The original failure remains available in this inspector." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
        lineNumber: 75,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: `recovery-reason-${runId}`, className: "text-[12.5px] text-ink", children: "What changed before retrying?" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
          lineNumber: 80,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Textarea,
          {
            id: `recovery-reason-${runId}`,
            value: reason,
            onChange: (event) => {
              setReason(event.target.value);
              setError(null);
            },
            placeholder: "Describe the correction, new evidence, or operator intervention.",
            className: "mt-2 min-h-20 border-line bg-surface-1 text-[13px]",
            "aria-describedby": error ? `recovery-error-${runId}` : void 0,
            "aria-invalid": !!error
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
            lineNumber: 83,
            columnNumber: 15
          },
          this
        ),
        error ? /* @__PURE__ */ jsxDEV("p", { id: `recovery-error-${runId}`, className: "mt-2 text-[12px] text-err", children: error }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
          lineNumber: 96,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-[12px] text-ink-muted", children: "A reason of at least 10 characters is retained in the audit trail." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
          lineNumber: 100,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex justify-end", children: /* @__PURE__ */ jsxDEV(
          Button,
          {
            size: "sm",
            disabled: busy || normalizedReason.length < 10,
            onClick: async () => {
              setError(null);
              try {
                await onRetry(normalizedReason);
                setRecoveryStarted(true);
              } catch (caught) {
                setError(caught instanceof Error ? caught.message : "Recovery run could not be created.");
              }
            },
            children: [
              /* @__PURE__ */ jsxDEV(RotateCcw, { className: "mr-1.5 h-3.5 w-3.5", strokeWidth: 1.7, "aria-hidden": true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
                lineNumber: 118,
                columnNumber: 19
              }, this),
              busy ? "Starting recovery…" : "Retry as new run"
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
            lineNumber: 105,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
          lineNumber: 104,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
        lineNumber: 79,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
      lineNumber: 63,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
    lineNumber: 61,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx",
    lineNumber: 60,
    columnNumber: 5
  }, this);
}
_s(RunRecoveryPanel, "4qRUex2YXKbM1VlP5qThhf9nyuM=");
_c = RunRecoveryPanel;
var _c;
$RefreshReg$(_c, "RunRecoveryPanel");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/controlPlane/RunRecoveryPanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JROzs7Ozs7Ozs7Ozs7Ozs7OztBQS9CUixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxnQkFBZ0I7QUFFbEIsZ0JBQVNDLGlCQUFpQjtBQUFBLEVBQy9CQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxPQUFPO0FBQUEsRUFDUEM7QUFNRixHQUFHO0FBQUFDLEtBQUE7QUFDRCxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSVosU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ2EsT0FBT0MsUUFBUSxJQUFJZCxTQUF3QixJQUFJO0FBQ3RELFFBQU0sQ0FBQ2UsaUJBQWlCQyxrQkFBa0IsSUFBSWhCLFNBQVMsS0FBSztBQUM1RCxRQUFNaUIsbUJBQW1CTixPQUFPTyxLQUFLO0FBRXJDbkIsWUFBVSxNQUFNO0FBQ2RhLGNBQVUsRUFBRTtBQUNaRSxhQUFTLElBQUk7QUFDYkUsdUJBQW1CLEtBQUs7QUFBQSxFQUMxQixHQUFHLENBQUNWLEtBQUssQ0FBQztBQUVWLE1BQUksQ0FBQ0csU0FBUztBQUNaLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLGtEQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG9DQUFtQyxzREFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RjtBQUFBLE1BQ3hGLHVCQUFDLE9BQUUsV0FBVSx5Q0FBdUMsb0ZBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsRUFFSjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLG1EQUFrRCxhQUFVLFVBQ3pFLGlDQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLDJCQUFDLGFBQVUsV0FBVSxvQ0FBbUMsYUFBYSxLQUFLLGVBQVcsUUFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRjtBQUFBLElBQ3JGLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxvQ0FBbUMsb0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0U7QUFBQSxNQUN0RSx1QkFBQyxPQUFFLFdBQVUsbURBQWlELG1JQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNDRixpQkFDQyx1QkFBQyxTQUFJLFdBQVUsOEZBQ2I7QUFBQSwrQkFBQyxVQUFLLFdBQVUsd0JBQXVCLGlDQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdEO0FBQUEsUUFBTztBQUFBLFFBQUVBO0FBQUFBLFdBRG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxJQUNFO0FBQUEsTUFFSFEsa0JBQ0MsdUJBQUMsU0FBSSxXQUFVLGtGQUFnRiwrRkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSwrQkFBQyxTQUFNLFNBQVMsbUJBQW1CVCxLQUFLLElBQUksV0FBVSwwQkFBd0IsNkNBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUksbUJBQW1CQSxLQUFLO0FBQUEsWUFDNUIsT0FBT0s7QUFBQUEsWUFDUCxVQUFVLENBQUNRLFVBQVU7QUFDbkJQLHdCQUFVTyxNQUFNQyxPQUFPQyxLQUFLO0FBQzVCUCx1QkFBUyxJQUFJO0FBQUEsWUFDZjtBQUFBLFlBQ0EsYUFBWTtBQUFBLFlBQ1osV0FBVTtBQUFBLFlBQ1Ysb0JBQWtCRCxRQUFRLGtCQUFrQlAsS0FBSyxLQUFLZ0I7QUFBQUEsWUFDdEQsZ0JBQWMsQ0FBQyxDQUFDVDtBQUFBQTtBQUFBQSxVQVZsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFVd0I7QUFBQSxRQUV2QkEsUUFDQyx1QkFBQyxPQUFFLElBQUksa0JBQWtCUCxLQUFLLElBQUksV0FBVSw2QkFDekNPLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUVBLHVCQUFDLE9BQUUsV0FBVSxtQ0FBaUMsa0ZBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUYsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxVQUFVTCxRQUFRUyxpQkFBaUJNLFNBQVM7QUFBQSxZQUM1QyxTQUFTLFlBQVk7QUFDbkJULHVCQUFTLElBQUk7QUFDYixrQkFBSTtBQUNGLHNCQUFNTCxRQUFRUSxnQkFBZ0I7QUFDOUJELG1DQUFtQixJQUFJO0FBQUEsY0FDekIsU0FBU1EsUUFBUTtBQUNmVix5QkFBU1Usa0JBQWtCQyxRQUFRRCxPQUFPRSxVQUFVLG9DQUFvQztBQUFBLGNBQzFGO0FBQUEsWUFDRjtBQUFBLFlBRUE7QUFBQSxxQ0FBQyxhQUFVLFdBQVUsc0JBQXFCLGFBQWEsS0FBSyxlQUFXLFFBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVFO0FBQUEsY0FDdEVsQixPQUFPLHVCQUF1QjtBQUFBO0FBQUE7QUFBQSxVQWRqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFlQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsV0ExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJDQTtBQUFBLFNBM0RKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2REE7QUFBQSxPQS9ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0VBLEtBakVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrRUE7QUFFSjtBQUFDRSxHQXRHZUwsa0JBQWdCO0FBQUEsS0FBaEJBO0FBQWdCLElBQUFzQjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlJvdGF0ZUNjdyIsIkJ1dHRvbiIsIkxhYmVsIiwiVGV4dGFyZWEiLCJSdW5SZWNvdmVyeVBhbmVsIiwicnVuSWQiLCJmYWlsdXJlU3VtbWFyeSIsImJ1c3kiLCJvblJldHJ5IiwiX3MiLCJyZWFzb24iLCJzZXRSZWFzb24iLCJlcnJvciIsInNldEVycm9yIiwicmVjb3ZlcnlTdGFydGVkIiwic2V0UmVjb3ZlcnlTdGFydGVkIiwibm9ybWFsaXplZFJlYXNvbiIsInRyaW0iLCJldmVudCIsInRhcmdldCIsInZhbHVlIiwidW5kZWZpbmVkIiwibGVuZ3RoIiwiY2F1Z2h0IiwiRXJyb3IiLCJtZXNzYWdlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUnVuUmVjb3ZlcnlQYW5lbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgUm90YXRlQ2N3IH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9idXR0b25cIjtcbmltcG9ydCB7IExhYmVsIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9sYWJlbFwiO1xuaW1wb3J0IHsgVGV4dGFyZWEgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL3RleHRhcmVhXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBSdW5SZWNvdmVyeVBhbmVsKHtcbiAgcnVuSWQsXG4gIGZhaWx1cmVTdW1tYXJ5LFxuICBidXN5ID0gZmFsc2UsXG4gIG9uUmV0cnksXG59OiB7XG4gIHJ1bklkOiBzdHJpbmc7XG4gIGZhaWx1cmVTdW1tYXJ5Pzogc3RyaW5nIHwgbnVsbDtcbiAgYnVzeT86IGJvb2xlYW47XG4gIG9uUmV0cnk/OiAocmVhc29uOiBzdHJpbmcpID0+IFByb21pc2U8dm9pZD47XG59KSB7XG4gIGNvbnN0IFtyZWFzb24sIHNldFJlYXNvbl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3JlY292ZXJ5U3RhcnRlZCwgc2V0UmVjb3ZlcnlTdGFydGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3Qgbm9ybWFsaXplZFJlYXNvbiA9IHJlYXNvbi50cmltKCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXRSZWFzb24oXCJcIik7XG4gICAgc2V0RXJyb3IobnVsbCk7XG4gICAgc2V0UmVjb3ZlcnlTdGFydGVkKGZhbHNlKTtcbiAgfSwgW3J1bklkXSk7XG5cbiAgaWYgKCFvblJldHJ5KSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yIHAtNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtaW5rXCI+UmVjb3ZlcnkgcmVxdWlyZXMgdGhlIGxpbmtlZCBXb3JrT3JkZXI8L2Rpdj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LVsxMi41cHhdIHRleHQtaW5rLXNlY29uZGFyeVwiPlxuICAgICAgICAgIE9wZW4gdGhpcyBydW4gZnJvbSBXb3JrIE9yZGVycyB0byBzdGFydCBhIGdvdmVybmVkIHJlY292ZXJ5IGF0dGVtcHQuXG4gICAgICAgIDwvcD5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWVyci8zMCBiZy1lcnItc29mdCBwLTRcIiBhcmlhLWxpdmU9XCJwb2xpdGVcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxuICAgICAgICA8Um90YXRlQ2N3IGNsYXNzTmFtZT1cIm10LTAuNSBoLTQgdy00IHNocmluay0wIHRleHQtZXJyXCIgc3Ryb2tlV2lkdGg9ezEuN30gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGV4dC1pbmtcIj5TdGFydCBhIHJlY292ZXJ5IHJ1bjwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1bMTIuNXB4XSBsZWFkaW5nLTUgdGV4dC1pbmstc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICBUaGlzIGNyZWF0ZXMgYSBuZXcgcnVuIGZyb20gdGhlIGN1cnJlbnQgV29ya09yZGVyLiBUaGUgZmFpbGVkIHJ1biwgZXJyb3IsIHRpbWVsaW5lLCBhbmQgYXJ0aWZhY3RzIHJlbWFpbiB1bmNoYW5nZWQuXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIHtmYWlsdXJlU3VtbWFyeSA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgcHgtMyBweS0yIHRleHQtWzEyLjVweF0gdGV4dC1pbmstc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtaW5rXCI+T3JpZ2luYWwgZmFpbHVyZTo8L3NwYW4+IHtmYWlsdXJlU3VtbWFyeX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkgOiBudWxsfVxuXG4gICAgICAgICAge3JlY292ZXJ5U3RhcnRlZCA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItb2svMzAgYmctb2stc29mdCBweC0zIHB5LTIgdGV4dC1bMTIuNXB4XSB0ZXh0LW9rXCI+XG4gICAgICAgICAgICAgIFJlY292ZXJ5IHJ1biBjcmVhdGVkLiBUaGUgb3JpZ2luYWwgZmFpbHVyZSByZW1haW5zIGF2YWlsYWJsZSBpbiB0aGlzIGluc3BlY3Rvci5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cbiAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9e2ByZWNvdmVyeS1yZWFzb24tJHtydW5JZH1gfSBjbGFzc05hbWU9XCJ0ZXh0LVsxMi41cHhdIHRleHQtaW5rXCI+XG4gICAgICAgICAgICAgICAgV2hhdCBjaGFuZ2VkIGJlZm9yZSByZXRyeWluZz9cbiAgICAgICAgICAgICAgPC9MYWJlbD5cbiAgICAgICAgICAgICAgPFRleHRhcmVhXG4gICAgICAgICAgICAgICAgaWQ9e2ByZWNvdmVyeS1yZWFzb24tJHtydW5JZH1gfVxuICAgICAgICAgICAgICAgIHZhbHVlPXtyZWFzb259XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4ge1xuICAgICAgICAgICAgICAgICAgc2V0UmVhc29uKGV2ZW50LnRhcmdldC52YWx1ZSk7XG4gICAgICAgICAgICAgICAgICBzZXRFcnJvcihudWxsKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGVzY3JpYmUgdGhlIGNvcnJlY3Rpb24sIG5ldyBldmlkZW5jZSwgb3Igb3BlcmF0b3IgaW50ZXJ2ZW50aW9uLlwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMiBtaW4taC0yMCBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgdGV4dC1bMTNweF1cIlxuICAgICAgICAgICAgICAgIGFyaWEtZGVzY3JpYmVkYnk9e2Vycm9yID8gYHJlY292ZXJ5LWVycm9yLSR7cnVuSWR9YCA6IHVuZGVmaW5lZH1cbiAgICAgICAgICAgICAgICBhcmlhLWludmFsaWQ9eyEhZXJyb3J9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIHtlcnJvciA/IChcbiAgICAgICAgICAgICAgICA8cCBpZD17YHJlY292ZXJ5LWVycm9yLSR7cnVuSWR9YH0gY2xhc3NOYW1lPVwibXQtMiB0ZXh0LVsxMnB4XSB0ZXh0LWVyclwiPlxuICAgICAgICAgICAgICAgICAge2Vycm9yfVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtWzEycHhdIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAgICAgICAgICBBIHJlYXNvbiBvZiBhdCBsZWFzdCAxMCBjaGFyYWN0ZXJzIGlzIHJldGFpbmVkIGluIHRoZSBhdWRpdCB0cmFpbC5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBmbGV4IGp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtidXN5IHx8IG5vcm1hbGl6ZWRSZWFzb24ubGVuZ3RoIDwgMTB9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXthc3luYyAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldEVycm9yKG51bGwpO1xuICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IG9uUmV0cnkobm9ybWFsaXplZFJlYXNvbik7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0UmVjb3ZlcnlTdGFydGVkKHRydWUpO1xuICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChjYXVnaHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRFcnJvcihjYXVnaHQgaW5zdGFuY2VvZiBFcnJvciA/IGNhdWdodC5tZXNzYWdlIDogXCJSZWNvdmVyeSBydW4gY291bGQgbm90IGJlIGNyZWF0ZWQuXCIpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxSb3RhdGVDY3cgY2xhc3NOYW1lPVwibXItMS41IGgtMy41IHctMy41XCIgc3Ryb2tlV2lkdGg9ezEuN30gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgICAgIHtidXN5ID8gXCJTdGFydGluZyByZWNvdmVyeeKAplwiIDogXCJSZXRyeSBhcyBuZXcgcnVuXCJ9XG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL2NvbnRyb2xQbGFuZS9SdW5SZWNvdmVyeVBhbmVsLnRzeCJ9