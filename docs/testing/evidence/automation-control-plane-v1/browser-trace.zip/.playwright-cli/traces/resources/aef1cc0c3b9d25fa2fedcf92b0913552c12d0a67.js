import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
const STAGE_MAP = {
  "run.started": "turn_start",
  "task.claimed": "turn_start",
  "approval.requested": "gate",
  "tool.executed": "tool",
  "run.completed": "turn_end",
  "memory.consolidated": "consolidation"
};
const STAGE_LABELS = {
  turn_start: "message in",
  gate: "retrieval gate",
  llm: "agent reasons",
  tool: "tool runs",
  turn_end: "reply",
  consolidation: "consolidating memory"
};
const STAGE_NODES = {
  turn_start: ["gateway", "wm"],
  gate: ["gate"],
  llm: ["llm"],
  tool: ["tools"],
  turn_end: ["reply", "trace"],
  consolidation: ["consolidation", "semantic"]
};
const STAGE_EDGES = {
  turn_start: ["e-gw-wm"],
  gate: ["e-gate-wm"],
  llm: ["e-wm-loop"],
  tool: [],
  turn_end: ["e-reply-trace", "e-reply-save"],
  consolidation: ["e-consol-sem"]
};
export function useHarnessAnimation(projectId) {
  const events = useQuery(
    api.analytics.recentHarnessEvents,
    projectId ? { projectId, limit: 10 } : { limit: 10 }
  );
  const [statusLabel, setStatusLabel] = useState(null);
  const [animating, setAnimating] = useState(false);
  const seenRef = useRef(/* @__PURE__ */ new Set());
  useEffect(() => {
    if (!events?.length) return;
    const latest = events.find((e) => !seenRef.current.has(e.id));
    if (!latest) return;
    seenRef.current.add(latest.id);
    if (seenRef.current.size > 50) {
      const arr = [...seenRef.current];
      seenRef.current = new Set(arr.slice(-30));
    }
    const stageKey = STAGE_MAP[latest.type] ?? "llm";
    const label = STAGE_LABELS[stageKey] ?? latest.type;
    setStatusLabel(label);
    setAnimating(true);
    const nodes = STAGE_NODES[stageKey] ?? [];
    const edges = STAGE_EDGES[stageKey] ?? [];
    nodes.forEach((id) => {
      document.querySelectorAll(`[data-node="${id}"]`).forEach((el) => {
        el.classList.add("schematic-hot");
        window.setTimeout(() => el.classList.remove("schematic-hot"), 900);
      });
    });
    edges.forEach((id) => {
      document.querySelectorAll(`[data-edge="${id}"]`).forEach((el) => {
        el.classList.add("schematic-flow-live");
        window.setTimeout(() => el.classList.remove("schematic-flow-live"), 900);
      });
    });
    const t = window.setTimeout(() => {
      setAnimating(false);
      setStatusLabel(null);
    }, 1200);
    return () => window.clearTimeout(t);
  }, [events]);
  return { statusLabel, animating };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZUhhcm5lc3NBbmltYXRpb24udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB0eXBlIHsgSWQgfSBmcm9tIFwiLi4vLi4vLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvZGF0YU1vZGVsXCI7XG5cbi8qKiBNYXBzIGFjdGl2aXR5IHR5cGVzIHRvIHdha3UgU1RBR0UgYW5pbWF0aW9uIGtleXMuICovXG5jb25zdCBTVEFHRV9NQVA6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gIFwicnVuLnN0YXJ0ZWRcIjogXCJ0dXJuX3N0YXJ0XCIsXG4gIFwidGFzay5jbGFpbWVkXCI6IFwidHVybl9zdGFydFwiLFxuICBcImFwcHJvdmFsLnJlcXVlc3RlZFwiOiBcImdhdGVcIixcbiAgXCJ0b29sLmV4ZWN1dGVkXCI6IFwidG9vbFwiLFxuICBcInJ1bi5jb21wbGV0ZWRcIjogXCJ0dXJuX2VuZFwiLFxuICBcIm1lbW9yeS5jb25zb2xpZGF0ZWRcIjogXCJjb25zb2xpZGF0aW9uXCIsXG59O1xuXG5jb25zdCBTVEFHRV9MQUJFTFM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gIHR1cm5fc3RhcnQ6IFwibWVzc2FnZSBpblwiLFxuICBnYXRlOiBcInJldHJpZXZhbCBnYXRlXCIsXG4gIGxsbTogXCJhZ2VudCByZWFzb25zXCIsXG4gIHRvb2w6IFwidG9vbCBydW5zXCIsXG4gIHR1cm5fZW5kOiBcInJlcGx5XCIsXG4gIGNvbnNvbGlkYXRpb246IFwiY29uc29saWRhdGluZyBtZW1vcnlcIixcbn07XG5cbmNvbnN0IFNUQUdFX05PREVTOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4gPSB7XG4gIHR1cm5fc3RhcnQ6IFtcImdhdGV3YXlcIiwgXCJ3bVwiXSxcbiAgZ2F0ZTogW1wiZ2F0ZVwiXSxcbiAgbGxtOiBbXCJsbG1cIl0sXG4gIHRvb2w6IFtcInRvb2xzXCJdLFxuICB0dXJuX2VuZDogW1wicmVwbHlcIiwgXCJ0cmFjZVwiXSxcbiAgY29uc29saWRhdGlvbjogW1wiY29uc29saWRhdGlvblwiLCBcInNlbWFudGljXCJdLFxufTtcblxuY29uc3QgU1RBR0VfRURHRVM6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPiA9IHtcbiAgdHVybl9zdGFydDogW1wiZS1ndy13bVwiXSxcbiAgZ2F0ZTogW1wiZS1nYXRlLXdtXCJdLFxuICBsbG06IFtcImUtd20tbG9vcFwiXSxcbiAgdG9vbDogW10sXG4gIHR1cm5fZW5kOiBbXCJlLXJlcGx5LXRyYWNlXCIsIFwiZS1yZXBseS1zYXZlXCJdLFxuICBjb25zb2xpZGF0aW9uOiBbXCJlLWNvbnNvbC1zZW1cIl0sXG59O1xuXG5leHBvcnQgaW50ZXJmYWNlIEhhcm5lc3NBbmltYXRpb25TdGF0ZSB7XG4gIHN0YXR1c0xhYmVsOiBzdHJpbmcgfCBudWxsO1xuICBhbmltYXRpbmc6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VIYXJuZXNzQW5pbWF0aW9uKFxuICBwcm9qZWN0SWQ/OiBJZDxcInByb2plY3RzXCI+IHwgbnVsbFxuKTogSGFybmVzc0FuaW1hdGlvblN0YXRlIHtcbiAgY29uc3QgZXZlbnRzID0gdXNlUXVlcnkoXG4gICAgYXBpLmFuYWx5dGljcy5yZWNlbnRIYXJuZXNzRXZlbnRzLFxuICAgIHByb2plY3RJZCA/IHsgcHJvamVjdElkLCBsaW1pdDogMTAgfSA6IHsgbGltaXQ6IDEwIH1cbiAgKTtcbiAgY29uc3QgW3N0YXR1c0xhYmVsLCBzZXRTdGF0dXNMYWJlbF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2FuaW1hdGluZywgc2V0QW5pbWF0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3Qgc2VlblJlZiA9IHVzZVJlZjxTZXQ8c3RyaW5nPj4obmV3IFNldCgpKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZXZlbnRzPy5sZW5ndGgpIHJldHVybjtcbiAgICBjb25zdCBsYXRlc3QgPSBldmVudHMuZmluZCgoZSkgPT4gIXNlZW5SZWYuY3VycmVudC5oYXMoZS5pZCkpO1xuICAgIGlmICghbGF0ZXN0KSByZXR1cm47XG4gICAgc2VlblJlZi5jdXJyZW50LmFkZChsYXRlc3QuaWQpO1xuICAgIGlmIChzZWVuUmVmLmN1cnJlbnQuc2l6ZSA+IDUwKSB7XG4gICAgICBjb25zdCBhcnIgPSBbLi4uc2VlblJlZi5jdXJyZW50XTtcbiAgICAgIHNlZW5SZWYuY3VycmVudCA9IG5ldyBTZXQoYXJyLnNsaWNlKC0zMCkpO1xuICAgIH1cblxuICAgIGNvbnN0IHN0YWdlS2V5ID0gU1RBR0VfTUFQW2xhdGVzdC50eXBlXSA/PyBcImxsbVwiO1xuICAgIGNvbnN0IGxhYmVsID0gU1RBR0VfTEFCRUxTW3N0YWdlS2V5XSA/PyBsYXRlc3QudHlwZTtcbiAgICBzZXRTdGF0dXNMYWJlbChsYWJlbCk7XG4gICAgc2V0QW5pbWF0aW5nKHRydWUpO1xuXG4gICAgY29uc3Qgbm9kZXMgPSBTVEFHRV9OT0RFU1tzdGFnZUtleV0gPz8gW107XG4gICAgY29uc3QgZWRnZXMgPSBTVEFHRV9FREdFU1tzdGFnZUtleV0gPz8gW107XG4gICAgbm9kZXMuZm9yRWFjaCgoaWQpID0+IHtcbiAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoYFtkYXRhLW5vZGU9XCIke2lkfVwiXWApLmZvckVhY2goKGVsKSA9PiB7XG4gICAgICAgIGVsLmNsYXNzTGlzdC5hZGQoXCJzY2hlbWF0aWMtaG90XCIpO1xuICAgICAgICB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiBlbC5jbGFzc0xpc3QucmVtb3ZlKFwic2NoZW1hdGljLWhvdFwiKSwgOTAwKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIGVkZ2VzLmZvckVhY2goKGlkKSA9PiB7XG4gICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKGBbZGF0YS1lZGdlPVwiJHtpZH1cIl1gKS5mb3JFYWNoKChlbCkgPT4ge1xuICAgICAgICBlbC5jbGFzc0xpc3QuYWRkKFwic2NoZW1hdGljLWZsb3ctbGl2ZVwiKTtcbiAgICAgICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4gZWwuY2xhc3NMaXN0LnJlbW92ZShcInNjaGVtYXRpYy1mbG93LWxpdmVcIiksIDkwMCk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIGNvbnN0IHQgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBzZXRBbmltYXRpbmcoZmFsc2UpO1xuICAgICAgc2V0U3RhdHVzTGFiZWwobnVsbCk7XG4gICAgfSwgMTIwMCk7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5jbGVhclRpbWVvdXQodCk7XG4gIH0sIFtldmVudHNdKTtcblxuICByZXR1cm4geyBzdGF0dXNMYWJlbCwgYW5pbWF0aW5nIH07XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsV0FBVyxRQUFRLGdCQUFnQjtBQUM1QyxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLFdBQVc7QUFJcEIsTUFBTSxZQUFvQztBQUFBLEVBQ3hDLGVBQWU7QUFBQSxFQUNmLGdCQUFnQjtBQUFBLEVBQ2hCLHNCQUFzQjtBQUFBLEVBQ3RCLGlCQUFpQjtBQUFBLEVBQ2pCLGlCQUFpQjtBQUFBLEVBQ2pCLHVCQUF1QjtBQUN6QjtBQUVBLE1BQU0sZUFBdUM7QUFBQSxFQUMzQyxZQUFZO0FBQUEsRUFDWixNQUFNO0FBQUEsRUFDTixLQUFLO0FBQUEsRUFDTCxNQUFNO0FBQUEsRUFDTixVQUFVO0FBQUEsRUFDVixlQUFlO0FBQ2pCO0FBRUEsTUFBTSxjQUF3QztBQUFBLEVBQzVDLFlBQVksQ0FBQyxXQUFXLElBQUk7QUFBQSxFQUM1QixNQUFNLENBQUMsTUFBTTtBQUFBLEVBQ2IsS0FBSyxDQUFDLEtBQUs7QUFBQSxFQUNYLE1BQU0sQ0FBQyxPQUFPO0FBQUEsRUFDZCxVQUFVLENBQUMsU0FBUyxPQUFPO0FBQUEsRUFDM0IsZUFBZSxDQUFDLGlCQUFpQixVQUFVO0FBQzdDO0FBRUEsTUFBTSxjQUF3QztBQUFBLEVBQzVDLFlBQVksQ0FBQyxTQUFTO0FBQUEsRUFDdEIsTUFBTSxDQUFDLFdBQVc7QUFBQSxFQUNsQixLQUFLLENBQUMsV0FBVztBQUFBLEVBQ2pCLE1BQU0sQ0FBQztBQUFBLEVBQ1AsVUFBVSxDQUFDLGlCQUFpQixjQUFjO0FBQUEsRUFDMUMsZUFBZSxDQUFDLGNBQWM7QUFDaEM7QUFPTyxnQkFBUyxvQkFDZCxXQUN1QjtBQUN2QixRQUFNLFNBQVM7QUFBQSxJQUNiLElBQUksVUFBVTtBQUFBLElBQ2QsWUFBWSxFQUFFLFdBQVcsT0FBTyxHQUFHLElBQUksRUFBRSxPQUFPLEdBQUc7QUFBQSxFQUNyRDtBQUNBLFFBQU0sQ0FBQyxhQUFhLGNBQWMsSUFBSSxTQUF3QixJQUFJO0FBQ2xFLFFBQU0sQ0FBQyxXQUFXLFlBQVksSUFBSSxTQUFTLEtBQUs7QUFDaEQsUUFBTSxVQUFVLE9BQW9CLG9CQUFJLElBQUksQ0FBQztBQUU3QyxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUMsUUFBUSxPQUFRO0FBQ3JCLFVBQU0sU0FBUyxPQUFPLEtBQUssQ0FBQyxNQUFNLENBQUMsUUFBUSxRQUFRLElBQUksRUFBRSxFQUFFLENBQUM7QUFDNUQsUUFBSSxDQUFDLE9BQVE7QUFDYixZQUFRLFFBQVEsSUFBSSxPQUFPLEVBQUU7QUFDN0IsUUFBSSxRQUFRLFFBQVEsT0FBTyxJQUFJO0FBQzdCLFlBQU0sTUFBTSxDQUFDLEdBQUcsUUFBUSxPQUFPO0FBQy9CLGNBQVEsVUFBVSxJQUFJLElBQUksSUFBSSxNQUFNLEdBQUcsQ0FBQztBQUFBLElBQzFDO0FBRUEsVUFBTSxXQUFXLFVBQVUsT0FBTyxJQUFJLEtBQUs7QUFDM0MsVUFBTSxRQUFRLGFBQWEsUUFBUSxLQUFLLE9BQU87QUFDL0MsbUJBQWUsS0FBSztBQUNwQixpQkFBYSxJQUFJO0FBRWpCLFVBQU0sUUFBUSxZQUFZLFFBQVEsS0FBSyxDQUFDO0FBQ3hDLFVBQU0sUUFBUSxZQUFZLFFBQVEsS0FBSyxDQUFDO0FBQ3hDLFVBQU0sUUFBUSxDQUFDLE9BQU87QUFDcEIsZUFBUyxpQkFBaUIsZUFBZSxFQUFFLElBQUksRUFBRSxRQUFRLENBQUMsT0FBTztBQUMvRCxXQUFHLFVBQVUsSUFBSSxlQUFlO0FBQ2hDLGVBQU8sV0FBVyxNQUFNLEdBQUcsVUFBVSxPQUFPLGVBQWUsR0FBRyxHQUFHO0FBQUEsTUFDbkUsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUNELFVBQU0sUUFBUSxDQUFDLE9BQU87QUFDcEIsZUFBUyxpQkFBaUIsZUFBZSxFQUFFLElBQUksRUFBRSxRQUFRLENBQUMsT0FBTztBQUMvRCxXQUFHLFVBQVUsSUFBSSxxQkFBcUI7QUFDdEMsZUFBTyxXQUFXLE1BQU0sR0FBRyxVQUFVLE9BQU8scUJBQXFCLEdBQUcsR0FBRztBQUFBLE1BQ3pFLENBQUM7QUFBQSxJQUNILENBQUM7QUFFRCxVQUFNLElBQUksT0FBTyxXQUFXLE1BQU07QUFDaEMsbUJBQWEsS0FBSztBQUNsQixxQkFBZSxJQUFJO0FBQUEsSUFDckIsR0FBRyxJQUFJO0FBQ1AsV0FBTyxNQUFNLE9BQU8sYUFBYSxDQUFDO0FBQUEsRUFDcEMsR0FBRyxDQUFDLE1BQU0sQ0FBQztBQUVYLFNBQU8sRUFBRSxhQUFhLFVBQVU7QUFDbEM7IiwibmFtZXMiOltdfQ==