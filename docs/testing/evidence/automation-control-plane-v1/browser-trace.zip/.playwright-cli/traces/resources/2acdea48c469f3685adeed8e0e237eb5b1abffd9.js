import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ScheduleView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { PageHeader } from "/src/components/PageHeader.tsx";
import { Card } from "/src/components/ui/card.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { MetricBlock } from "/src/components/factory/MetricBlock.tsx";
import { Calendar, Clock, ListTodo } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
const CONVEX_CRONS = [
  { name: "expire stale approvals", interval: "Every 15 min" },
  { name: "escalate overdue approvals", interval: "Every 10 min" },
  { name: "detect loops", interval: "Every 15 min" },
  { name: "daily standup report", interval: "Daily 09:00 UTC" },
  { name: "daily CEO brief", interval: "Daily 09:00 UTC" },
  { name: "detect stale heartbeats", interval: "Every 2 min" },
  { name: "auto-route executions", interval: "Every 5 min" },
  { name: "guard ARM migration health", interval: "Every 30 min" },
  { name: "execute scheduled jobs", interval: "Every 1 min" },
  { name: "evaluate alert rules", interval: "Every 1 hour" }
];
const NOW = Date.now();
const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1e3;
export function ScheduleView({ projectId, onNavigate, onTaskSelect }) {
  _s();
  const tasks = useQuery(api.tasks.listAll, projectId ? { projectId } : {});
  const jobs = useQuery(api.scheduledJobs.list, projectId ? { projectId } : {});
  const tasksList = tasks ?? [];
  const jobsList = jobs ?? [];
  const scheduledTasks = tasksList.filter((t) => t.scheduledFor || t.recurrence);
  const upcomingTasks = scheduledTasks.filter((t) => {
    const at = t.scheduledFor ?? 0;
    return at >= NOW && at <= NOW + SEVEN_DAYS_MS;
  }).sort((a, b) => (a.scheduledFor ?? 0) - (b.scheduledFor ?? 0)).slice(0, 15);
  const nextJobs = [...jobsList].filter((j) => j.nextRun != null && j.nextRun >= NOW).sort((a, b) => (a.nextRun ?? 0) - (b.nextRun ?? 0)).slice(0, 15);
  return /* @__PURE__ */ jsxDEV("section", { className: "flex min-h-0 flex-1 flex-col overflow-y-auto bg-app", children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: "Schedule",
        description: "What's running and when. Upcoming tasks, scheduled jobs, and Convex crons in one place.",
        icon: /* @__PURE__ */ jsxDEV(Calendar, { className: "h-4 w-4", strokeWidth: 1.7 }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 79,
          columnNumber: 15
        }, this),
        eyebrow: "Operations",
        actions: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: onNavigate && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "outline", size: "sm", className: "h-8 text-xs", onClick: () => onNavigate("calendar"), children: [
            /* @__PURE__ */ jsxDEV(Calendar, { className: "h-3.5 w-3.5 mr-1.5" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
              lineNumber: 86,
              columnNumber: 19
            }, this),
            "Calendar"
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
            lineNumber: 85,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "outline", size: "sm", className: "h-8 text-xs", onClick: () => onNavigate("schedules"), children: "Schedules" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
            lineNumber: 89,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 84,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 82,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
        lineNumber: 76,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "mx-auto max-w-[1200px] px-6 py-6 flex flex-col gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 md:grid-cols-4", children: [
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Upcoming tasks",
            value: upcomingTasks.length,
            detail: "Scheduled work in the next seven days"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
            lineNumber: 100,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 99,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Scheduled jobs",
            value: jobsList.length,
            detail: "Jobs with persisted next-run timestamps"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
            lineNumber: 107,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 106,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Recurring tasks",
            value: scheduledTasks.filter((task) => task.recurrence).length,
            detail: "Operator routines and repeating agent work"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
            lineNumber: 114,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 113,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Convex crons",
            value: CONVEX_CRONS.length,
            detail: "Background jobs defined in code"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
            lineNumber: 121,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 120,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
        lineNumber: 98,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[15px] font-semibold text-ink flex items-center gap-2 mb-3", children: [
          /* @__PURE__ */ jsxDEV(ListTodo, { size: 16, strokeWidth: 1.6, className: "text-ink-muted" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
            lineNumber: 132,
            columnNumber: 13
          }, this),
          "Upcoming tasks (next 7 days)"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 131,
          columnNumber: 11
        }, this),
        upcomingTasks.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-[13.5px] text-ink-muted", children: "No tasks scheduled in the next 7 days." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 136,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2", children: upcomingTasks.map(
          (t) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "w-full text-left px-3 py-2 rounded-lg text-[13.5px] hover:bg-surface-2 border border-transparent hover:border-line transition-colors duration-150",
              onClick: () => onTaskSelect?.(t._id),
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-ink", children: t.title }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
                  lineNumber: 146,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-ink-muted ml-2", children: t.scheduledFor ? new Date(t.scheduledFor).toLocaleString(void 0, {
                  weekday: "short",
                  month: "short",
                  day: "numeric",
                  hour: "2-digit",
                  minute: "2-digit"
                }) : "Recurring" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
                  lineNumber: 147,
                  columnNumber: 21
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
              lineNumber: 141,
              columnNumber: 19
            },
            this
          ) }, t._id, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
            lineNumber: 140,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 138,
          columnNumber: 11
        }, this),
        onNavigate && /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", className: "mt-2 text-xs", onClick: () => onNavigate("calendar"), children: "View full calendar" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 164,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
        lineNumber: 130,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[15px] font-semibold text-ink flex items-center gap-2 mb-3", children: [
          /* @__PURE__ */ jsxDEV(Clock, { size: 16, strokeWidth: 1.6, className: "text-ink-muted" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
            lineNumber: 173,
            columnNumber: 13
          }, this),
          "Next scheduled job runs"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 172,
          columnNumber: 11
        }, this),
        nextJobs.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-[13.5px] text-ink-muted", children: "No upcoming job runs." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 177,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2", children: nextJobs.map(
          (j) => /* @__PURE__ */ jsxDEV("li", { className: "flex items-center justify-between text-[13.5px] py-1.5 border-b border-line last:border-0", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-ink", children: j.name }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
              lineNumber: 182,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-ink-muted text-xs", children: j.nextRun ? new Date(j.nextRun).toLocaleString(void 0, {
              month: "short",
              day: "numeric",
              hour: "2-digit",
              minute: "2-digit"
            }) : "—" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
              lineNumber: 183,
              columnNumber: 19
            }, this)
          ] }, j._id, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
            lineNumber: 181,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 179,
          columnNumber: 11
        }, this),
        onNavigate && /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", className: "mt-2 text-xs", onClick: () => onNavigate("schedules"), children: "Manage schedules" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 198,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
        lineNumber: 171,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[15px] font-semibold text-ink flex items-center gap-2 mb-3", children: [
          /* @__PURE__ */ jsxDEV(Clock, { size: 16, strokeWidth: 1.6, className: "text-ink-muted" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
            lineNumber: 207,
            columnNumber: 13
          }, this),
          "Convex cron jobs"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 206,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[12.5px] text-ink-muted mb-3", children: "Background jobs from crons.ts. Read-only; edit in code." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 210,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2", children: CONVEX_CRONS.map(
          (cron, i) => /* @__PURE__ */ jsxDEV("li", { className: "flex items-center justify-between text-[13.5px] py-1.5 border-b border-line last:border-0", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-ink", children: cron.name }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
              lineNumber: 216,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-ink-muted text-xs", children: cron.interval }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
              lineNumber: 217,
              columnNumber: 17
            }, this)
          ] }, i, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
            lineNumber: 215,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
          lineNumber: 213,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
        lineNumber: 205,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
      lineNumber: 97,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx",
    lineNumber: 75,
    columnNumber: 5
  }, this);
}
_s(ScheduleView, "zCBRLaFuk6y7RUvcLzkOtoAtL08=", false, function() {
  return [useQuery, useQuery];
});
_c = ScheduleView;
var _c;
$RefreshReg$(_c, "ScheduleView");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ScheduleView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkRjLFNBS0EsVUFMQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEzRGQsU0FBU0EsZ0JBQWdCO0FBQ3pCLFNBQVNDLFdBQVc7QUFHcEIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsVUFBVUMsT0FBT0MsZ0JBQWdCO0FBRzFDLE1BQU1DLGVBQWU7QUFBQSxFQUNuQixFQUFFQyxNQUFNLDBCQUEwQkMsVUFBVSxlQUFlO0FBQUEsRUFDM0QsRUFBRUQsTUFBTSw4QkFBOEJDLFVBQVUsZUFBZTtBQUFBLEVBQy9ELEVBQUVELE1BQU0sZ0JBQWdCQyxVQUFVLGVBQWU7QUFBQSxFQUNqRCxFQUFFRCxNQUFNLHdCQUF3QkMsVUFBVSxrQkFBa0I7QUFBQSxFQUM1RCxFQUFFRCxNQUFNLG1CQUFtQkMsVUFBVSxrQkFBa0I7QUFBQSxFQUN2RCxFQUFFRCxNQUFNLDJCQUEyQkMsVUFBVSxjQUFjO0FBQUEsRUFDM0QsRUFBRUQsTUFBTSx5QkFBeUJDLFVBQVUsY0FBYztBQUFBLEVBQ3pELEVBQUVELE1BQU0sOEJBQThCQyxVQUFVLGVBQWU7QUFBQSxFQUMvRCxFQUFFRCxNQUFNLDBCQUEwQkMsVUFBVSxjQUFjO0FBQUEsRUFDMUQsRUFBRUQsTUFBTSx3QkFBd0JDLFVBQVUsZUFBZTtBQUFDO0FBRzVELE1BQU1DLE1BQU1DLEtBQUtDLElBQUk7QUFDckIsTUFBTUMsZ0JBQWdCLElBQUksS0FBSyxLQUFLLEtBQUs7QUFRbEMsZ0JBQVNDLGFBQWEsRUFBRUMsV0FBV0MsWUFBWUMsYUFBZ0MsR0FBRztBQUFBQyxLQUFBO0FBQ3ZGLFFBQU1DLFFBQVFyQixTQUFTQyxJQUFJb0IsTUFBTUMsU0FBU0wsWUFBWSxFQUFFQSxVQUFVLElBQUksQ0FBQyxDQUFDO0FBQ3hFLFFBQU1NLE9BQU92QixTQUFTQyxJQUFJdUIsY0FBY0MsTUFBTVIsWUFBWSxFQUFFQSxVQUFVLElBQUksQ0FBQyxDQUFDO0FBRTVFLFFBQU1TLFlBQVlMLFNBQVM7QUFDM0IsUUFBTU0sV0FBV0osUUFBUTtBQUV6QixRQUFNSyxpQkFBaUJGLFVBQVVHLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRUMsZ0JBQWdCRCxFQUFFRSxVQUFVO0FBQzdFLFFBQU1DLGdCQUFnQkwsZUFDbkJDLE9BQU8sQ0FBQ0MsTUFBTTtBQUNiLFVBQU1JLEtBQUtKLEVBQUVDLGdCQUFnQjtBQUM3QixXQUFPRyxNQUFNdEIsT0FBT3NCLE1BQU10QixNQUFNRztBQUFBQSxFQUNsQyxDQUFDLEVBQ0FvQixLQUFLLENBQUNDLEdBQUdDLE9BQU9ELEVBQUVMLGdCQUFnQixNQUFNTSxFQUFFTixnQkFBZ0IsRUFBRSxFQUM1RE8sTUFBTSxHQUFHLEVBQUU7QUFFZCxRQUFNQyxXQUFXLENBQUMsR0FBR1osUUFBUSxFQUMxQkUsT0FBTyxDQUFDVyxNQUFNQSxFQUFFQyxXQUFXLFFBQVFELEVBQUVDLFdBQVc3QixHQUFHLEVBQ25EdUIsS0FBSyxDQUFDQyxHQUFHQyxPQUFPRCxFQUFFSyxXQUFXLE1BQU1KLEVBQUVJLFdBQVcsRUFBRSxFQUNsREgsTUFBTSxHQUFHLEVBQUU7QUFFZCxTQUNFLHVCQUFDLGFBQVEsV0FBVSx1REFDakI7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sYUFBWTtBQUFBLFFBQ1osTUFBTSx1QkFBQyxZQUFTLFdBQVUsV0FBVSxhQUFhLE9BQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0M7QUFBQSxRQUNyRCxTQUFRO0FBQUEsUUFDUixTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNacEIsd0JBQ0MsbUNBQ0U7QUFBQSxpQ0FBQyxVQUFPLFNBQVEsV0FBVSxNQUFLLE1BQUssV0FBVSxlQUFjLFNBQVMsTUFBTUEsV0FBVyxVQUFVLEdBQzlGO0FBQUEsbUNBQUMsWUFBUyxXQUFVLHdCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QztBQUFBO0FBQUEsZUFEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsVUFBTyxTQUFRLFdBQVUsTUFBSyxNQUFLLFdBQVUsZUFBYyxTQUFTLE1BQU1BLFdBQVcsV0FBVyxHQUFFLHlCQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUEsS0FWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQTtBQUFBLE1BbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQW1CRztBQUFBLElBRUgsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsK0JBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE9BQU9lLGNBQWNTO0FBQUFBLFlBQ3JCLFFBQU87QUFBQTtBQUFBLFVBSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR2dELEtBSmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBQ0EsdUJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE9BQU9mLFNBQVNlO0FBQUFBLFlBQ2hCLFFBQU87QUFBQTtBQUFBLFVBSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR2tELEtBSnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBQ0EsdUJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE9BQU9kLGVBQWVDLE9BQU8sQ0FBQ2MsU0FBU0EsS0FBS1gsVUFBVSxFQUFFVTtBQUFBQSxZQUN4RCxRQUFPO0FBQUE7QUFBQSxVQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdxRCxLQUp2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUNBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPakMsYUFBYWlDO0FBQUFBLFlBQ3BCLFFBQU87QUFBQTtBQUFBLFVBSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRzBDLEtBSjVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFdBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2QkE7QUFBQSxNQUdBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsK0JBQUMsUUFBRyxXQUFVLG1FQUNaO0FBQUEsaUNBQUMsWUFBUyxNQUFNLElBQUksYUFBYSxLQUFLLFdBQVUsb0JBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdFO0FBQUE7QUFBQSxhQURsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNDVCxjQUFjUyxXQUFXLElBQ3hCLHVCQUFDLE9BQUUsV0FBVSxnQ0FBK0Isc0RBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0YsSUFFbEYsdUJBQUMsUUFBRyxXQUFVLGFBQ1hULHdCQUFjVztBQUFBQSxVQUFJLENBQUNkLE1BQ2xCLHVCQUFDLFFBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLFNBQVMsTUFBTVgsZUFBZVcsRUFBRWUsR0FBRztBQUFBLGNBRW5DO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHdCQUF3QmYsWUFBRWdCLFNBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdEO0FBQUEsZ0JBQ2hELHVCQUFDLFVBQUssV0FBVSx1QkFDYmhCLFlBQUVDLGVBQ0MsSUFBSWxCLEtBQUtpQixFQUFFQyxZQUFZLEVBQUVnQixlQUFlQyxRQUFXO0FBQUEsa0JBQ2pEQyxTQUFTO0FBQUEsa0JBQ1RDLE9BQU87QUFBQSxrQkFDUEMsS0FBSztBQUFBLGtCQUNMQyxNQUFNO0FBQUEsa0JBQ05DLFFBQVE7QUFBQSxnQkFDVixDQUFDLElBQ0QsZUFUTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBO0FBQUE7QUFBQTtBQUFBLFlBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWlCQSxLQWxCT3ZCLEVBQUVlLEtBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxRQUNELEtBdEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1QkE7QUFBQSxRQUVEM0IsY0FDQyx1QkFBQyxVQUFPLFNBQVEsU0FBUSxNQUFLLE1BQUssV0FBVSxnQkFBZSxTQUFTLE1BQU1BLFdBQVcsVUFBVSxHQUFFLGtDQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQXBDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0NBO0FBQUEsTUFHQSx1QkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLCtCQUFDLFFBQUcsV0FBVSxtRUFDWjtBQUFBLGlDQUFDLFNBQU0sTUFBTSxJQUFJLGFBQWEsS0FBSyxXQUFVLG9CQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBO0FBQUEsYUFEL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQ3FCLFNBQVNHLFdBQVcsSUFDbkIsdUJBQUMsT0FBRSxXQUFVLGdDQUErQixxQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRSxJQUVqRSx1QkFBQyxRQUFHLFdBQVUsYUFDWEgsbUJBQVNLO0FBQUFBLFVBQUksQ0FBQ0osTUFDYix1QkFBQyxRQUFlLFdBQVUsNkZBQ3hCO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHdCQUF3QkEsWUFBRTlCLFFBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStDO0FBQUEsWUFDL0MsdUJBQUMsVUFBSyxXQUFVLDBCQUNiOEIsWUFBRUMsVUFDQyxJQUFJNUIsS0FBSzJCLEVBQUVDLE9BQU8sRUFBRU0sZUFBZUMsUUFBVztBQUFBLGNBQzVDRSxPQUFPO0FBQUEsY0FDUEMsS0FBSztBQUFBLGNBQ0xDLE1BQU07QUFBQSxjQUNOQyxRQUFRO0FBQUEsWUFDVixDQUFDLElBQ0QsT0FSTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsZUFYT2IsRUFBRUssS0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsUUFDRCxLQWZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUVEM0IsY0FDQyx1QkFBQyxVQUFPLFNBQVEsU0FBUSxNQUFLLE1BQUssV0FBVSxnQkFBZSxTQUFTLE1BQU1BLFdBQVcsV0FBVyxHQUFFLGdDQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQTdCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0JBO0FBQUEsTUFHQSx1QkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLCtCQUFDLFFBQUcsV0FBVSxtRUFDWjtBQUFBLGlDQUFDLFNBQU0sTUFBTSxJQUFJLGFBQWEsS0FBSyxXQUFVLG9CQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBO0FBQUEsYUFEL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUscUNBQW1DLHVFQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSxhQUNYVCx1QkFBYW1DO0FBQUFBLFVBQUksQ0FBQ1UsTUFBTUMsTUFDdkIsdUJBQUMsUUFBVyxXQUFVLDZGQUNwQjtBQUFBLG1DQUFDLFVBQUssV0FBVSxzQkFBc0JELGVBQUs1QyxRQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRDtBQUFBLFlBQ2hELHVCQUFDLFVBQUssV0FBVSwwQkFBMEI0QyxlQUFLM0MsWUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Q7QUFBQSxlQUZqRDRDLEdBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFFBQ0QsS0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxTQTVIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkhBO0FBQUEsT0FuSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9KQTtBQUVKO0FBQUNuQyxHQTVLZUosY0FBWTtBQUFBLFVBQ1poQixVQUNEQSxRQUFRO0FBQUE7QUFBQSxLQUZQZ0I7QUFBWSxJQUFBd0M7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlUXVlcnkiLCJhcGkiLCJQYWdlSGVhZGVyIiwiQ2FyZCIsIkJ1dHRvbiIsIk1ldHJpY0Jsb2NrIiwiQ2FsZW5kYXIiLCJDbG9jayIsIkxpc3RUb2RvIiwiQ09OVkVYX0NST05TIiwibmFtZSIsImludGVydmFsIiwiTk9XIiwiRGF0ZSIsIm5vdyIsIlNFVkVOX0RBWVNfTVMiLCJTY2hlZHVsZVZpZXciLCJwcm9qZWN0SWQiLCJvbk5hdmlnYXRlIiwib25UYXNrU2VsZWN0IiwiX3MiLCJ0YXNrcyIsImxpc3RBbGwiLCJqb2JzIiwic2NoZWR1bGVkSm9icyIsImxpc3QiLCJ0YXNrc0xpc3QiLCJqb2JzTGlzdCIsInNjaGVkdWxlZFRhc2tzIiwiZmlsdGVyIiwidCIsInNjaGVkdWxlZEZvciIsInJlY3VycmVuY2UiLCJ1cGNvbWluZ1Rhc2tzIiwiYXQiLCJzb3J0IiwiYSIsImIiLCJzbGljZSIsIm5leHRKb2JzIiwiaiIsIm5leHRSdW4iLCJsZW5ndGgiLCJ0YXNrIiwibWFwIiwiX2lkIiwidGl0bGUiLCJ0b0xvY2FsZVN0cmluZyIsInVuZGVmaW5lZCIsIndlZWtkYXkiLCJtb250aCIsImRheSIsImhvdXIiLCJtaW51dGUiLCJjcm9uIiwiaSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNjaGVkdWxlVmlldy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHR5cGUgeyBNYWluVmlldyB9IGZyb20gXCIuL1RvcE5hdlwiO1xuaW1wb3J0IHsgUGFnZUhlYWRlciB9IGZyb20gXCIuL2NvbXBvbmVudHMvUGFnZUhlYWRlclwiO1xuaW1wb3J0IHsgQ2FyZCB9IGZyb20gXCIuL2NvbXBvbmVudHMvdWkvY2FyZFwiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIi4vY29tcG9uZW50cy91aS9idXR0b25cIjtcbmltcG9ydCB7IE1ldHJpY0Jsb2NrIH0gZnJvbSBcIi4vY29tcG9uZW50cy9mYWN0b3J5L01ldHJpY0Jsb2NrXCI7XG5pbXBvcnQgeyBDYWxlbmRhciwgQ2xvY2ssIExpc3RUb2RvIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuXG4vKiogU3RhdGljIGxpc3QgZGVyaXZlZCBmcm9tIGNvbnZleC9jcm9ucy50cyBmb3IgcmVhZC1vbmx5IGRpc3BsYXkgKi9cbmNvbnN0IENPTlZFWF9DUk9OUyA9IFtcbiAgeyBuYW1lOiBcImV4cGlyZSBzdGFsZSBhcHByb3ZhbHNcIiwgaW50ZXJ2YWw6IFwiRXZlcnkgMTUgbWluXCIgfSxcbiAgeyBuYW1lOiBcImVzY2FsYXRlIG92ZXJkdWUgYXBwcm92YWxzXCIsIGludGVydmFsOiBcIkV2ZXJ5IDEwIG1pblwiIH0sXG4gIHsgbmFtZTogXCJkZXRlY3QgbG9vcHNcIiwgaW50ZXJ2YWw6IFwiRXZlcnkgMTUgbWluXCIgfSxcbiAgeyBuYW1lOiBcImRhaWx5IHN0YW5kdXAgcmVwb3J0XCIsIGludGVydmFsOiBcIkRhaWx5IDA5OjAwIFVUQ1wiIH0sXG4gIHsgbmFtZTogXCJkYWlseSBDRU8gYnJpZWZcIiwgaW50ZXJ2YWw6IFwiRGFpbHkgMDk6MDAgVVRDXCIgfSxcbiAgeyBuYW1lOiBcImRldGVjdCBzdGFsZSBoZWFydGJlYXRzXCIsIGludGVydmFsOiBcIkV2ZXJ5IDIgbWluXCIgfSxcbiAgeyBuYW1lOiBcImF1dG8tcm91dGUgZXhlY3V0aW9uc1wiLCBpbnRlcnZhbDogXCJFdmVyeSA1IG1pblwiIH0sXG4gIHsgbmFtZTogXCJndWFyZCBBUk0gbWlncmF0aW9uIGhlYWx0aFwiLCBpbnRlcnZhbDogXCJFdmVyeSAzMCBtaW5cIiB9LFxuICB7IG5hbWU6IFwiZXhlY3V0ZSBzY2hlZHVsZWQgam9ic1wiLCBpbnRlcnZhbDogXCJFdmVyeSAxIG1pblwiIH0sXG4gIHsgbmFtZTogXCJldmFsdWF0ZSBhbGVydCBydWxlc1wiLCBpbnRlcnZhbDogXCJFdmVyeSAxIGhvdXJcIiB9LFxuXTtcblxuY29uc3QgTk9XID0gRGF0ZS5ub3coKTtcbmNvbnN0IFNFVkVOX0RBWVNfTVMgPSA3ICogMjQgKiA2MCAqIDYwICogMTAwMDtcblxuaW50ZXJmYWNlIFNjaGVkdWxlVmlld1Byb3BzIHtcbiAgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+IHwgbnVsbDtcbiAgb25OYXZpZ2F0ZT86ICh2aWV3OiBNYWluVmlldykgPT4gdm9pZDtcbiAgb25UYXNrU2VsZWN0PzogKHRhc2tJZDogSWQ8XCJ0YXNrc1wiPikgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFNjaGVkdWxlVmlldyh7IHByb2plY3RJZCwgb25OYXZpZ2F0ZSwgb25UYXNrU2VsZWN0IH06IFNjaGVkdWxlVmlld1Byb3BzKSB7XG4gIGNvbnN0IHRhc2tzID0gdXNlUXVlcnkoYXBpLnRhc2tzLmxpc3RBbGwsIHByb2plY3RJZCA/IHsgcHJvamVjdElkIH0gOiB7fSk7XG4gIGNvbnN0IGpvYnMgPSB1c2VRdWVyeShhcGkuc2NoZWR1bGVkSm9icy5saXN0LCBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCB9IDoge30pO1xuXG4gIGNvbnN0IHRhc2tzTGlzdCA9IHRhc2tzID8/IFtdO1xuICBjb25zdCBqb2JzTGlzdCA9IGpvYnMgPz8gW107XG5cbiAgY29uc3Qgc2NoZWR1bGVkVGFza3MgPSB0YXNrc0xpc3QuZmlsdGVyKCh0KSA9PiB0LnNjaGVkdWxlZEZvciB8fCB0LnJlY3VycmVuY2UpO1xuICBjb25zdCB1cGNvbWluZ1Rhc2tzID0gc2NoZWR1bGVkVGFza3NcbiAgICAuZmlsdGVyKCh0KSA9PiB7XG4gICAgICBjb25zdCBhdCA9IHQuc2NoZWR1bGVkRm9yID8/IDA7XG4gICAgICByZXR1cm4gYXQgPj0gTk9XICYmIGF0IDw9IE5PVyArIFNFVkVOX0RBWVNfTVM7XG4gICAgfSlcbiAgICAuc29ydCgoYSwgYikgPT4gKGEuc2NoZWR1bGVkRm9yID8/IDApIC0gKGIuc2NoZWR1bGVkRm9yID8/IDApKVxuICAgIC5zbGljZSgwLCAxNSk7XG5cbiAgY29uc3QgbmV4dEpvYnMgPSBbLi4uam9ic0xpc3RdXG4gICAgLmZpbHRlcigoaikgPT4gai5uZXh0UnVuICE9IG51bGwgJiYgai5uZXh0UnVuID49IE5PVylcbiAgICAuc29ydCgoYSwgYikgPT4gKGEubmV4dFJ1biA/PyAwKSAtIChiLm5leHRSdW4gPz8gMCkpXG4gICAgLnNsaWNlKDAsIDE1KTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImZsZXggbWluLWgtMCBmbGV4LTEgZmxleC1jb2wgb3ZlcmZsb3cteS1hdXRvIGJnLWFwcFwiPlxuICAgICAgPFBhZ2VIZWFkZXJcbiAgICAgICAgdGl0bGU9XCJTY2hlZHVsZVwiXG4gICAgICAgIGRlc2NyaXB0aW9uPVwiV2hhdCdzIHJ1bm5pbmcgYW5kIHdoZW4uIFVwY29taW5nIHRhc2tzLCBzY2hlZHVsZWQgam9icywgYW5kIENvbnZleCBjcm9ucyBpbiBvbmUgcGxhY2UuXCJcbiAgICAgICAgaWNvbj17PENhbGVuZGFyIGNsYXNzTmFtZT1cImgtNCB3LTRcIiBzdHJva2VXaWR0aD17MS43fSAvPn1cbiAgICAgICAgZXllYnJvdz1cIk9wZXJhdGlvbnNcIlxuICAgICAgICBhY3Rpb25zPXtcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgIHtvbk5hdmlnYXRlICYmIChcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgc2l6ZT1cInNtXCIgY2xhc3NOYW1lPVwiaC04IHRleHQteHNcIiBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKFwiY2FsZW5kYXJcIil9PlxuICAgICAgICAgICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cImgtMy41IHctMy41IG1yLTEuNVwiIC8+XG4gICAgICAgICAgICAgICAgICBDYWxlbmRhclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBzaXplPVwic21cIiBjbGFzc05hbWU9XCJoLTggdGV4dC14c1wiIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoXCJzY2hlZHVsZXNcIil9PlxuICAgICAgICAgICAgICAgICAgU2NoZWR1bGVzXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgICAgLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy1bMTIwMHB4XSBweC02IHB5LTYgZmxleCBmbGV4LWNvbCBnYXAtNlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTQgbWQ6Z3JpZC1jb2xzLTRcIj5cbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTRcIj5cbiAgICAgICAgICAgIDxNZXRyaWNCbG9ja1xuICAgICAgICAgICAgICBsYWJlbD1cIlVwY29taW5nIHRhc2tzXCJcbiAgICAgICAgICAgICAgdmFsdWU9e3VwY29taW5nVGFza3MubGVuZ3RofVxuICAgICAgICAgICAgICBkZXRhaWw9XCJTY2hlZHVsZWQgd29yayBpbiB0aGUgbmV4dCBzZXZlbiBkYXlzXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICAgICAgPE1ldHJpY0Jsb2NrXG4gICAgICAgICAgICAgIGxhYmVsPVwiU2NoZWR1bGVkIGpvYnNcIlxuICAgICAgICAgICAgICB2YWx1ZT17am9ic0xpc3QubGVuZ3RofVxuICAgICAgICAgICAgICBkZXRhaWw9XCJKb2JzIHdpdGggcGVyc2lzdGVkIG5leHQtcnVuIHRpbWVzdGFtcHNcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC00XCI+XG4gICAgICAgICAgICA8TWV0cmljQmxvY2tcbiAgICAgICAgICAgICAgbGFiZWw9XCJSZWN1cnJpbmcgdGFza3NcIlxuICAgICAgICAgICAgICB2YWx1ZT17c2NoZWR1bGVkVGFza3MuZmlsdGVyKCh0YXNrKSA9PiB0YXNrLnJlY3VycmVuY2UpLmxlbmd0aH1cbiAgICAgICAgICAgICAgZGV0YWlsPVwiT3BlcmF0b3Igcm91dGluZXMgYW5kIHJlcGVhdGluZyBhZ2VudCB3b3JrXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICAgICAgPE1ldHJpY0Jsb2NrXG4gICAgICAgICAgICAgIGxhYmVsPVwiQ29udmV4IGNyb25zXCJcbiAgICAgICAgICAgICAgdmFsdWU9e0NPTlZFWF9DUk9OUy5sZW5ndGh9XG4gICAgICAgICAgICAgIGRldGFpbD1cIkJhY2tncm91bmQgam9icyBkZWZpbmVkIGluIGNvZGVcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBVcGNvbWluZyB0YXNrcyAqL31cbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC00XCI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmsgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItM1wiPlxuICAgICAgICAgICAgPExpc3RUb2RvIHNpemU9ezE2fSBzdHJva2VXaWR0aD17MS42fSBjbGFzc05hbWU9XCJ0ZXh0LWluay1tdXRlZFwiIC8+XG4gICAgICAgICAgICBVcGNvbWluZyB0YXNrcyAobmV4dCA3IGRheXMpXG4gICAgICAgICAgPC9oMz5cbiAgICAgICAgICB7dXBjb21pbmdUYXNrcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMy41cHhdIHRleHQtaW5rLW11dGVkXCI+Tm8gdGFza3Mgc2NoZWR1bGVkIGluIHRoZSBuZXh0IDcgZGF5cy48L3A+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAge3VwY29taW5nVGFza3MubWFwKCh0KSA9PiAoXG4gICAgICAgICAgICAgICAgPGxpIGtleT17dC5faWR9PlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCBweC0zIHB5LTIgcm91bmRlZC1sZyB0ZXh0LVsxMy41cHhdIGhvdmVyOmJnLXN1cmZhY2UtMiBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGhvdmVyOmJvcmRlci1saW5lIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uVGFza1NlbGVjdD8uKHQuX2lkKX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1pbmtcIj57dC50aXRsZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtaW5rLW11dGVkIG1sLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7dC5zY2hlZHVsZWRGb3JcbiAgICAgICAgICAgICAgICAgICAgICAgID8gbmV3IERhdGUodC5zY2hlZHVsZWRGb3IpLnRvTG9jYWxlU3RyaW5nKHVuZGVmaW5lZCwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdlZWtkYXk6IFwic2hvcnRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb250aDogXCJzaG9ydFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRheTogXCJudW1lcmljXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaG91cjogXCIyLWRpZ2l0XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWludXRlOiBcIjItZGlnaXRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJSZWN1cnJpbmdcIn1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICl9XG4gICAgICAgICAge29uTmF2aWdhdGUgJiYgKFxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBzaXplPVwic21cIiBjbGFzc05hbWU9XCJtdC0yIHRleHQteHNcIiBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKFwiY2FsZW5kYXJcIil9PlxuICAgICAgICAgICAgICBWaWV3IGZ1bGwgY2FsZW5kYXJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvQ2FyZD5cblxuICAgICAgICB7LyogTmV4dCBzY2hlZHVsZWQgam9iIHJ1bnMgKi99XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtaW5rIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTNcIj5cbiAgICAgICAgICAgIDxDbG9jayBzaXplPXsxNn0gc3Ryb2tlV2lkdGg9ezEuNn0gY2xhc3NOYW1lPVwidGV4dC1pbmstbXV0ZWRcIiAvPlxuICAgICAgICAgICAgTmV4dCBzY2hlZHVsZWQgam9iIHJ1bnNcbiAgICAgICAgICA8L2gzPlxuICAgICAgICAgIHtuZXh0Sm9icy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMy41cHhdIHRleHQtaW5rLW11dGVkXCI+Tm8gdXBjb21pbmcgam9iIHJ1bnMuPC9wPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIHtuZXh0Sm9icy5tYXAoKGopID0+IChcbiAgICAgICAgICAgICAgICA8bGkga2V5PXtqLl9pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtWzEzLjVweF0gcHktMS41IGJvcmRlci1iIGJvcmRlci1saW5lIGxhc3Q6Ym9yZGVyLTBcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtaW5rXCI+e2oubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWluay1tdXRlZCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgIHtqLm5leHRSdW5cbiAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGoubmV4dFJ1bikudG9Mb2NhbGVTdHJpbmcodW5kZWZpbmVkLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1vbnRoOiBcInNob3J0XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRheTogXCJudW1lcmljXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhvdXI6IFwiMi1kaWdpdFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBtaW51dGU6IFwiMi1kaWdpdFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICA6IFwi4oCUXCJ9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICl9XG4gICAgICAgICAge29uTmF2aWdhdGUgJiYgKFxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBzaXplPVwic21cIiBjbGFzc05hbWU9XCJtdC0yIHRleHQteHNcIiBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKFwic2NoZWR1bGVzXCIpfT5cbiAgICAgICAgICAgICAgTWFuYWdlIHNjaGVkdWxlc1xuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9DYXJkPlxuXG4gICAgICAgIHsvKiBDb252ZXggY3JvbnMgKHJlYWQtb25seSkgKi99XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtaW5rIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTNcIj5cbiAgICAgICAgICAgIDxDbG9jayBzaXplPXsxNn0gc3Ryb2tlV2lkdGg9ezEuNn0gY2xhc3NOYW1lPVwidGV4dC1pbmstbXV0ZWRcIiAvPlxuICAgICAgICAgICAgQ29udmV4IGNyb24gam9ic1xuICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZCBtYi0zXCI+XG4gICAgICAgICAgICBCYWNrZ3JvdW5kIGpvYnMgZnJvbSBjcm9ucy50cy4gUmVhZC1vbmx5OyBlZGl0IGluIGNvZGUuXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgIHtDT05WRVhfQ1JPTlMubWFwKChjcm9uLCBpKSA9PiAoXG4gICAgICAgICAgICAgIDxsaSBrZXk9e2l9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMy41cHhdIHB5LTEuNSBib3JkZXItYiBib3JkZXItbGluZSBsYXN0OmJvcmRlci0wXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtaW5rXCI+e2Nyb24ubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1pbmstbXV0ZWQgdGV4dC14c1wiPntjcm9uLmludGVydmFsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvdWw+XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL1NjaGVkdWxlVmlldy50c3gifQ==