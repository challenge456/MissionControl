import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/harness/components/HarnessFirstReviewModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/harness/components/HarnessFirstReviewModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { Button } from "/src/components/ui/button.tsx";
export function HarnessFirstReviewModal({
  open,
  onClose,
  onProceedComment
}) {
  _s();
  const [fixedHarness, setFixedHarness] = useState(false);
  if (!open) return null;
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-md rounded-xl border border-line bg-surface-1 p-6 shadow-xl", children: [
    /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-ink", children: "Harness-first feedback" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/harness/components/HarnessFirstReviewModal.tsx",
      lineNumber: 39,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-ink-secondary", children: "Before leaving a drive-by PR comment, fix the harness once: update skill, test, or architecture — then retry." }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/harness/components/HarnessFirstReviewModal.tsx",
      lineNumber: 40,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("label", { className: "mt-4 flex items-center gap-2 text-sm text-ink", children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "checkbox",
          checked: fixedHarness,
          onChange: (e) => setFixedHarness(e.target.checked)
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/harness/components/HarnessFirstReviewModal.tsx",
          lineNumber: 44,
          columnNumber: 11
        },
        this
      ),
      "I updated the harness and retried"
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/harness/components/HarnessFirstReviewModal.tsx",
      lineNumber: 43,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-6 flex justify-end gap-2", children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "outline", size: "sm", onClick: onClose, children: "Cancel" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/harness/components/HarnessFirstReviewModal.tsx",
        lineNumber: 52,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { size: "sm", disabled: !fixedHarness, onClick: onProceedComment, children: "Leave comment" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/harness/components/HarnessFirstReviewModal.tsx",
        lineNumber: 55,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/harness/components/HarnessFirstReviewModal.tsx",
      lineNumber: 51,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/harness/components/HarnessFirstReviewModal.tsx",
    lineNumber: 38,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/harness/components/HarnessFirstReviewModal.tsx",
    lineNumber: 37,
    columnNumber: 5
  }, this);
}
_s(HarnessFirstReviewModal, "7NkeD+1dXG8eHspOIsVlIZgpG+M=");
_c = HarnessFirstReviewModal;
var _c;
$RefreshReg$(_c, "HarnessFirstReviewModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/harness/components/HarnessFirstReviewModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/harness/components/HarnessFirstReviewModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJROzs7Ozs7Ozs7Ozs7Ozs7OztBQW5CUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsY0FBYztBQUVoQixnQkFBU0Msd0JBQXdCO0FBQUEsRUFDdENDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBS0YsR0FBdUI7QUFBQUMsS0FBQTtBQUNyQixRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSVIsU0FBUyxLQUFLO0FBRXRELE1BQUksQ0FBQ0csS0FBTSxRQUFPO0FBRWxCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHVFQUNiLGlDQUFDLFNBQUksV0FBVSxxRUFDYjtBQUFBLDJCQUFDLFFBQUcsV0FBVSxrQ0FBaUMsc0NBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUU7QUFBQSxJQUNyRSx1QkFBQyxPQUFFLFdBQVUsbUNBQWlDLDZIQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFdBQU0sV0FBVSxpREFDZjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUFTSTtBQUFBQSxVQUNULFVBQVUsQ0FBQ0UsTUFBTUQsZ0JBQWdCQyxFQUFFQyxPQUFPQyxPQUFPO0FBQUE7QUFBQSxRQUhuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHcUQ7QUFBQTtBQUFBLFNBSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsNkJBQUMsVUFBTyxTQUFRLFdBQVUsTUFBSyxNQUFLLFNBQVNQLFNBQVEsc0JBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBTyxNQUFLLE1BQUssVUFBVSxDQUFDRyxjQUFjLFNBQVNGLGtCQUFpQiw2QkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxPQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUJBLEtBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1QkE7QUFFSjtBQUFDQyxHQXZDZUoseUJBQXVCO0FBQUEsS0FBdkJBO0FBQXVCLElBQUFVO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQnV0dG9uIiwiSGFybmVzc0ZpcnN0UmV2aWV3TW9kYWwiLCJvcGVuIiwib25DbG9zZSIsIm9uUHJvY2VlZENvbW1lbnQiLCJfcyIsImZpeGVkSGFybmVzcyIsInNldEZpeGVkSGFybmVzcyIsImUiLCJ0YXJnZXQiLCJjaGVja2VkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSGFybmVzc0ZpcnN0UmV2aWV3TW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuXG5leHBvcnQgZnVuY3Rpb24gSGFybmVzc0ZpcnN0UmV2aWV3TW9kYWwoe1xuICBvcGVuLFxuICBvbkNsb3NlLFxuICBvblByb2NlZWRDb21tZW50LFxufToge1xuICBvcGVuOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBvblByb2NlZWRDb21tZW50OiAoKSA9PiB2b2lkO1xufSk6IEpTWC5FbGVtZW50IHwgbnVsbCB7XG4gIGNvbnN0IFtmaXhlZEhhcm5lc3MsIHNldEZpeGVkSGFybmVzc10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgaWYgKCFvcGVuKSByZXR1cm4gbnVsbDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJsYWNrLzUwIHAtNFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy1tZCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgcC02IHNoYWRvdy14bFwiPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+SGFybmVzcy1maXJzdCBmZWVkYmFjazwvaDM+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LWluay1zZWNvbmRhcnlcIj5cbiAgICAgICAgICBCZWZvcmUgbGVhdmluZyBhIGRyaXZlLWJ5IFBSIGNvbW1lbnQsIGZpeCB0aGUgaGFybmVzcyBvbmNlOiB1cGRhdGUgc2tpbGwsIHRlc3QsIG9yIGFyY2hpdGVjdHVyZSDigJQgdGhlbiByZXRyeS5cbiAgICAgICAgPC9wPlxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibXQtNCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIHRleHQtaW5rXCI+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgY2hlY2tlZD17Zml4ZWRIYXJuZXNzfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGaXhlZEhhcm5lc3MoZS50YXJnZXQuY2hlY2tlZCl9XG4gICAgICAgICAgLz5cbiAgICAgICAgICBJIHVwZGF0ZWQgdGhlIGhhcm5lc3MgYW5kIHJldHJpZWRcbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGZsZXgganVzdGlmeS1lbmQgZ2FwLTJcIj5cbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgc2l6ZT1cInNtXCIgb25DbGljaz17b25DbG9zZX0+XG4gICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIGRpc2FibGVkPXshZml4ZWRIYXJuZXNzfSBvbkNsaWNrPXtvblByb2NlZWRDb21tZW50fT5cbiAgICAgICAgICAgIExlYXZlIGNvbW1lbnRcbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL2hhcm5lc3MvY29tcG9uZW50cy9IYXJuZXNzRmlyc3RSZXZpZXdNb2RhbC50c3gifQ==