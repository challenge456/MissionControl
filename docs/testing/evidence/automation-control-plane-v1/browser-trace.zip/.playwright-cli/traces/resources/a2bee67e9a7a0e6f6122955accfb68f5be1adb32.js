import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/AnalyticsDashboard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { cn } from "/src/lib/utils.ts";
import { X } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { MetricBlock, MetricRow } from "/src/components/factory/MetricBlock.tsx";
import { StatusBadge } from "/src/components/factory/badges.tsx";
import { CHART_SERIES } from "/src/components/factory/chartTheme.ts";
import {
  UsageTrendCharts
} from "/src/components/dashboard/UsageTrendCharts.tsx";
export function AnalyticsDashboard({ projectId, onClose }) {
  _s();
  const [chartWindowHours, setChartWindowHours] = useState(168);
  const agents = useQuery(
    api.agents.listAll,
    projectId ? { projectId } : {}
  );
  const tasks = useQuery(
    api.tasks.listAll,
    projectId ? { projectId } : {}
  );
  const runs = useQuery(
    api.runs.listRecent,
    { limit: 1e3 }
  );
  const usageTimeSeries = useQuery(
    api.runs.getUsageTimeSeries,
    projectId ? {
      projectId,
      windowHours: chartWindowHours,
      bucketHours: chartWindowHours === 24 ? 1 : 24
    } : {
      windowHours: chartWindowHours,
      bucketHours: chartWindowHours === 24 ? 1 : 24
    }
  );
  if (!agents || !tasks || !runs) {
    return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[1000] flex items-center justify-center bg-black/70", children: /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-line bg-surface-1 p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "h-16 w-40 animate-pulse rounded bg-surface-2" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
      lineNumber: 75,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
      lineNumber: 74,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
      lineNumber: 73,
      columnNumber: 7
    }, this);
  }
  const now = Date.now();
  const sevenDaysAgo = now - 7 * 24 * 60 * 60 * 1e3;
  const last7DaysRuns = runs.filter((r) => r.startedAt >= sevenDaysAgo);
  const dailyCosts = new Array(7).fill(0);
  last7DaysRuns.forEach((run) => {
    const daysAgo = Math.floor((now - run.startedAt) / (24 * 60 * 60 * 1e3));
    if (daysAgo >= 0 && daysAgo < 7) {
      dailyCosts[6 - daysAgo] += run.costUsd;
    }
  });
  const avgDailyCost = dailyCosts.reduce((a, b) => a + b, 0) / 7;
  const forecast7Days = avgDailyCost * 7;
  const agentEfficiency = agents.map((agent) => {
    const agentTasks = tasks.filter((t) => t.assigneeIds.includes(agent._id));
    const agentRuns = runs.filter((r) => r.agentId === agent._id);
    const completedTasks = agentTasks.filter((t) => t.status === "DONE").length;
    const totalCost = agentRuns.reduce((sum, r) => sum + r.costUsd, 0);
    const totalTime = agentRuns.reduce((sum, r) => sum + (r.durationMs || 0), 0);
    const tasksPerHour = totalTime > 0 ? completedTasks / (totalTime / (1e3 * 60 * 60)) : 0;
    const costPerTask = completedTasks > 0 ? totalCost / completedTasks : 0;
    const efficiencyScore = completedTasks > 0 ? completedTasks / (totalCost + 1) * 100 : 0;
    return {
      agent,
      completedTasks,
      tasksPerHour,
      costPerTask,
      efficiencyScore,
      totalCost
    };
  }).sort((a, b) => b.efficiencyScore - a.efficiencyScore);
  const completionTrend = new Array(7).fill(0);
  tasks.filter((t) => t.status === "DONE").forEach((task) => {
    const daysAgo = Math.floor((now - task._creationTime) / (24 * 60 * 60 * 1e3));
    if (daysAgo >= 0 && daysAgo < 7) {
      completionTrend[6 - daysAgo]++;
    }
  });
  const bottlenecks = [];
  const reviewTasks = tasks.filter((t) => t.status === "REVIEW");
  if (reviewTasks.length > 5) {
    bottlenecks.push({
      type: "Review Queue",
      count: reviewTasks.length,
      severity: "warning",
      message: `${reviewTasks.length} tasks waiting for review`
    });
  }
  const approvalTasks = tasks.filter((t) => t.status === "NEEDS_APPROVAL");
  if (approvalTasks.length > 3) {
    bottlenecks.push({
      type: "Approval Queue",
      count: approvalTasks.length,
      severity: "critical",
      message: `${approvalTasks.length} tasks waiting for approval`
    });
  }
  const blockedTasks = tasks.filter((t) => t.status === "BLOCKED");
  if (blockedTasks.length > 0) {
    bottlenecks.push({
      type: "Blocked Tasks",
      count: blockedTasks.length,
      severity: "critical",
      message: `${blockedTasks.length} tasks are blocked`
    });
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[1000] flex items-center justify-center overflow-y-auto bg-black/70 p-5", children: /* @__PURE__ */ jsxDEV("div", { className: "max-h-[90vh] w-full max-w-[1200px] overflow-y-auto rounded-xl border border-line bg-surface-1 p-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-6 flex items-start justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[19px] font-semibold text-ink", children: "Analytics" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
          lineNumber: 165,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-[13px] text-ink-secondary", children: "Cost forecast, agent efficiency, and pipeline bottlenecks" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
          lineNumber: 166,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
        lineNumber: 164,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: onClose,
          "aria-label": "Close analytics",
          className: "rounded-md p-1.5 text-ink-muted transition-colors duration-150 hover:bg-surface-2 hover:text-ink",
          children: /* @__PURE__ */ jsxDEV(X, { size: 16, strokeWidth: 1.75 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
            lineNumber: 175,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
          lineNumber: 170,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
      lineNumber: 163,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-3 text-[15px] font-semibold text-ink", children: "Cost forecasting" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
        lineNumber: 181,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(MetricRow, { className: "mb-4 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2", children: [
        /* @__PURE__ */ jsxDEV(MetricBlock, { label: "Avg daily cost", value: `$${avgDailyCost.toFixed(2)}`, detail: "Last 7 days" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
          lineNumber: 183,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(MetricBlock, { label: "7-day forecast", value: `$${forecast7Days.toFixed(2)}`, detail: "At current burn rate" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
          lineNumber: 184,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
        lineNumber: 182,
        columnNumber: 11
      }, this),
      usageTimeSeries && /* @__PURE__ */ jsxDEV(
        UsageTrendCharts,
        {
          series: usageTimeSeries,
          windowHours: chartWindowHours,
          onWindowChange: setChartWindowHours
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
          lineNumber: 188,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
      lineNumber: 180,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-3 text-[15px] font-semibold text-ink", children: "Agent efficiency" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
        lineNumber: 198,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-xl border border-line", children: agentEfficiency.slice(0, 5).map(
        (item, i) => /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: cn(
              "flex items-center justify-between px-4 py-3",
              i < 4 && "border-b border-line"
            ),
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex h-6 w-6 items-center justify-center rounded-md border border-line bg-surface-2 font-mono text-[11.5px] font-semibold text-ink-secondary", children: i + 1 }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
                  lineNumber: 209,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] font-medium text-ink", children: item.agent.name }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
                    lineNumber: 213,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[12px] text-ink-muted", children: [
                    item.completedTasks,
                    " tasks · $",
                    item.totalCost.toFixed(2),
                    " spent"
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
                    lineNumber: 214,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
                  lineNumber: 212,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
                lineNumber: 208,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-[14px] font-semibold text-ink", children: item.efficiencyScore.toFixed(1) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
                  lineNumber: 220,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-ink-muted", children: [
                  "$",
                  item.costPerTask.toFixed(2),
                  "/task"
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
                  lineNumber: 223,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
                lineNumber: 219,
                columnNumber: 17
              }, this)
            ]
          },
          item.agent._id,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
            lineNumber: 201,
            columnNumber: 13
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
        lineNumber: 199,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
      lineNumber: 197,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-3 text-[15px] font-semibold text-ink", children: "Task completion trend" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
        lineNumber: 234,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-line bg-surface-1 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex h-[100px] items-end gap-1", children: completionTrend.map((count, i) => {
        const maxCount = Math.max(...completionTrend, 1);
        const height = count / maxCount * 100;
        return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-1 flex-col items-center", children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "w-full rounded-t-sm",
              style: {
                height: `${height}%`,
                minHeight: count > 0 ? "4px" : "0",
                backgroundColor: CHART_SERIES[0]
              },
              title: `${count} tasks`
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
              lineNumber: 242,
              columnNumber: 21
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-[11px] text-ink-muted", children: i === 6 ? "Today" : `${6 - i}d` }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
            lineNumber: 251,
            columnNumber: 21
          }, this)
        ] }, i, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
          lineNumber: 241,
          columnNumber: 19
        }, this);
      }) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
        lineNumber: 236,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
        lineNumber: 235,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
      lineNumber: 233,
      columnNumber: 9
    }, this),
    bottlenecks.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-3 text-[15px] font-semibold text-ink", children: "Bottlenecks" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
        lineNumber: 264,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2", children: bottlenecks.map(
        (bottleneck, i) => /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "flex items-center justify-between rounded-lg border border-line bg-surface-2 px-4 py-3",
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV(StatusBadge, { tone: bottleneck.severity === "critical" ? "error" : "warning", children: bottleneck.severity === "critical" ? "Critical" : "Warning" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
                  lineNumber: 272,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] font-medium text-ink", children: bottleneck.type }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
                    lineNumber: 276,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "mt-0.5 text-[12px] text-ink-muted", children: bottleneck.message }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
                    lineNumber: 277,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
                  lineNumber: 275,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
                lineNumber: 271,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: cn(
                    "font-mono text-[19px] font-semibold",
                    bottleneck.severity === "critical" ? "text-err" : "text-warn"
                  ),
                  children: bottleneck.count
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
                  lineNumber: 280,
                  columnNumber: 19
                },
                this
              )
            ]
          },
          i,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
            lineNumber: 267,
            columnNumber: 13
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
        lineNumber: 265,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
      lineNumber: 263,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
    lineNumber: 161,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx",
    lineNumber: 160,
    columnNumber: 5
  }, this);
}
_s(AnalyticsDashboard, "eMD6HQVi+xAvoi1NCcC1GHp23ao=", false, function() {
  return [useQuery, useQuery, useQuery, useQuery];
});
_c = AnalyticsDashboard;
var _c;
$RefreshReg$(_c, "AnalyticsDashboard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AnalyticsDashboard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdURVOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZEVixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFdBQVc7QUFFcEIsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxTQUFTO0FBQ2xCLFNBQVNDLGFBQWFDLGlCQUFpQjtBQUN2QyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msb0JBQW9CO0FBQzdCO0FBQUEsRUFDRUM7QUFBQUEsT0FFSztBQU9BLGdCQUFTQyxtQkFBbUIsRUFBRUMsV0FBV0MsUUFBaUMsR0FBRztBQUFBQyxLQUFBO0FBQ2xGLFFBQU0sQ0FBQ0Msa0JBQWtCQyxtQkFBbUIsSUFBSWYsU0FBc0IsR0FBRztBQUV6RSxRQUFNZ0IsU0FBU2Y7QUFBQUEsSUFDYkMsSUFBSWMsT0FBT0M7QUFBQUEsSUFDWE4sWUFBWSxFQUFFQSxVQUFVLElBQUksQ0FBQztBQUFBLEVBQy9CO0FBRUEsUUFBTU8sUUFBUWpCO0FBQUFBLElBQ1pDLElBQUlnQixNQUFNRDtBQUFBQSxJQUNWTixZQUFZLEVBQUVBLFVBQVUsSUFBSSxDQUFDO0FBQUEsRUFDL0I7QUFFQSxRQUFNUSxPQUFPbEI7QUFBQUEsSUFDWEMsSUFBSWlCLEtBQUtDO0FBQUFBLElBQ1QsRUFBRUMsT0FBTyxJQUFLO0FBQUEsRUFDaEI7QUFFQSxRQUFNQyxrQkFBa0JyQjtBQUFBQSxJQUN0QkMsSUFBSWlCLEtBQUtJO0FBQUFBLElBQ1RaLFlBQ0k7QUFBQSxNQUNFQTtBQUFBQSxNQUNBYSxhQUFhVjtBQUFBQSxNQUNiVyxhQUFhWCxxQkFBcUIsS0FBSyxJQUFJO0FBQUEsSUFDN0MsSUFDQTtBQUFBLE1BQ0VVLGFBQWFWO0FBQUFBLE1BQ2JXLGFBQWFYLHFCQUFxQixLQUFLLElBQUk7QUFBQSxJQUM3QztBQUFBLEVBQ047QUFFQSxNQUFJLENBQUNFLFVBQVUsQ0FBQ0UsU0FBUyxDQUFDQyxNQUFNO0FBQzlCLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLHVFQUNiLGlDQUFDLFNBQUksV0FBVSxrREFDYixpQ0FBQyxTQUFJLFdBQVUsa0RBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2RCxLQUQvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxFQUVKO0FBRUEsUUFBTU8sTUFBTUMsS0FBS0QsSUFBSTtBQUNyQixRQUFNRSxlQUFlRixNQUFNLElBQUksS0FBSyxLQUFLLEtBQUs7QUFFOUMsUUFBTUcsZ0JBQWdCVixLQUFLVyxPQUFPLENBQUFDLE1BQUtBLEVBQUVDLGFBQWFKLFlBQVk7QUFDbEUsUUFBTUssYUFBYSxJQUFJQyxNQUFNLENBQUMsRUFBRUMsS0FBSyxDQUFDO0FBRXRDTixnQkFBY08sUUFBUSxDQUFBQyxRQUFPO0FBQzNCLFVBQU1DLFVBQVVDLEtBQUtDLE9BQU9kLE1BQU1XLElBQUlMLGNBQWMsS0FBSyxLQUFLLEtBQUssSUFBSztBQUN4RSxRQUFJTSxXQUFXLEtBQUtBLFVBQVUsR0FBRztBQUMvQkwsaUJBQVcsSUFBSUssT0FBTyxLQUFLRCxJQUFJSTtBQUFBQSxJQUNqQztBQUFBLEVBQ0YsQ0FBQztBQUVELFFBQU1DLGVBQWVULFdBQVdVLE9BQU8sQ0FBQ0MsR0FBR0MsTUFBTUQsSUFBSUMsR0FBRyxDQUFDLElBQUk7QUFDN0QsUUFBTUMsZ0JBQWdCSixlQUFlO0FBRXJDLFFBQU1LLGtCQUFrQi9CLE9BQU9nQyxJQUFJLENBQUFDLFVBQVM7QUFDMUMsVUFBTUMsYUFBYWhDLE1BQU1ZLE9BQU8sQ0FBQXFCLE1BQUtBLEVBQUVDLFlBQVlDLFNBQVNKLE1BQU1LLEdBQUcsQ0FBQztBQUN0RSxVQUFNQyxZQUFZcEMsS0FBS1csT0FBTyxDQUFBQyxNQUFLQSxFQUFFeUIsWUFBWVAsTUFBTUssR0FBRztBQUUxRCxVQUFNRyxpQkFBaUJQLFdBQVdwQixPQUFPLENBQUFxQixNQUFLQSxFQUFFTyxXQUFXLE1BQU0sRUFBRUM7QUFDbkUsVUFBTUMsWUFBWUwsVUFBVVosT0FBTyxDQUFDa0IsS0FBSzlCLE1BQU04QixNQUFNOUIsRUFBRVUsU0FBUyxDQUFDO0FBQ2pFLFVBQU1xQixZQUFZUCxVQUFVWixPQUFPLENBQUNrQixLQUFLOUIsTUFBTThCLE9BQU85QixFQUFFZ0MsY0FBYyxJQUFJLENBQUM7QUFFM0UsVUFBTUMsZUFBZUYsWUFBWSxJQUFLTCxrQkFBa0JLLGFBQWEsTUFBTyxLQUFLLE9BQVE7QUFDekYsVUFBTUcsY0FBY1IsaUJBQWlCLElBQUlHLFlBQVlILGlCQUFpQjtBQUN0RSxVQUFNUyxrQkFBa0JULGlCQUFpQixJQUFLQSxrQkFBa0JHLFlBQVksS0FBTSxNQUFNO0FBRXhGLFdBQU87QUFBQSxNQUNMWDtBQUFBQSxNQUNBUTtBQUFBQSxNQUNBTztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBTjtBQUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDLEVBQUVPLEtBQUssQ0FBQ3ZCLEdBQUdDLE1BQU1BLEVBQUVxQixrQkFBa0J0QixFQUFFc0IsZUFBZTtBQUV2RCxRQUFNRSxrQkFBa0IsSUFBSWxDLE1BQU0sQ0FBQyxFQUFFQyxLQUFLLENBQUM7QUFDM0NqQixRQUFNWSxPQUFPLENBQUFxQixNQUFLQSxFQUFFTyxXQUFXLE1BQU0sRUFBRXRCLFFBQVEsQ0FBQWlDLFNBQVE7QUFDckQsVUFBTS9CLFVBQVVDLEtBQUtDLE9BQU9kLE1BQU0yQyxLQUFLQyxrQkFBa0IsS0FBSyxLQUFLLEtBQUssSUFBSztBQUM3RSxRQUFJaEMsV0FBVyxLQUFLQSxVQUFVLEdBQUc7QUFDL0I4QixzQkFBZ0IsSUFBSTlCLE9BQU87QUFBQSxJQUM3QjtBQUFBLEVBQ0YsQ0FBQztBQUVELFFBQU1pQyxjQUFjO0FBRXBCLFFBQU1DLGNBQWN0RCxNQUFNWSxPQUFPLENBQUFxQixNQUFLQSxFQUFFTyxXQUFXLFFBQVE7QUFDM0QsTUFBSWMsWUFBWWIsU0FBUyxHQUFHO0FBQzFCWSxnQkFBWUUsS0FBSztBQUFBLE1BQ2ZDLE1BQU07QUFBQSxNQUNOQyxPQUFPSCxZQUFZYjtBQUFBQSxNQUNuQmlCLFVBQVU7QUFBQSxNQUNWQyxTQUFTLEdBQUdMLFlBQVliLE1BQU07QUFBQSxJQUNoQyxDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU1tQixnQkFBZ0I1RCxNQUFNWSxPQUFPLENBQUFxQixNQUFLQSxFQUFFTyxXQUFXLGdCQUFnQjtBQUNyRSxNQUFJb0IsY0FBY25CLFNBQVMsR0FBRztBQUM1QlksZ0JBQVlFLEtBQUs7QUFBQSxNQUNmQyxNQUFNO0FBQUEsTUFDTkMsT0FBT0csY0FBY25CO0FBQUFBLE1BQ3JCaUIsVUFBVTtBQUFBLE1BQ1ZDLFNBQVMsR0FBR0MsY0FBY25CLE1BQU07QUFBQSxJQUNsQyxDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU1vQixlQUFlN0QsTUFBTVksT0FBTyxDQUFBcUIsTUFBS0EsRUFBRU8sV0FBVyxTQUFTO0FBQzdELE1BQUlxQixhQUFhcEIsU0FBUyxHQUFHO0FBQzNCWSxnQkFBWUUsS0FBSztBQUFBLE1BQ2ZDLE1BQU07QUFBQSxNQUNOQyxPQUFPSSxhQUFhcEI7QUFBQUEsTUFDcEJpQixVQUFVO0FBQUEsTUFDVkMsU0FBUyxHQUFHRSxhQUFhcEIsTUFBTTtBQUFBLElBQ2pDLENBQUM7QUFBQSxFQUNIO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMkZBQ2IsaUNBQUMsU0FBSSxXQUFVLHFHQUViO0FBQUEsMkJBQUMsU0FBSSxXQUFVLCtDQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSxzQ0FBcUMseUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEQ7QUFBQSxRQUM1RCx1QkFBQyxPQUFFLFdBQVUsdUNBQXFDLHlFQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMvQztBQUFBQSxVQUNULGNBQVc7QUFBQSxVQUNYLFdBQVU7QUFBQSxVQUVWLGlDQUFDLEtBQUUsTUFBTSxJQUFJLGFBQWEsUUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0I7QUFBQTtBQUFBLFFBTGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDJDQUEwQyxnQ0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RTtBQUFBLE1BQ3hFLHVCQUFDLGFBQVUsV0FBVSxxREFDbkI7QUFBQSwrQkFBQyxlQUFZLE9BQU0sa0JBQWlCLE9BQU8sSUFBSThCLGFBQWFzQyxRQUFRLENBQUMsQ0FBQyxJQUFJLFFBQU8saUJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEY7QUFBQSxRQUM5Rix1QkFBQyxlQUFZLE9BQU0sa0JBQWlCLE9BQU8sSUFBSWxDLGNBQWNrQyxRQUFRLENBQUMsQ0FBQyxJQUFJLFFBQU8sMEJBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0c7QUFBQSxXQUYxRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVDMUQsbUJBQ0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFFBQVFBO0FBQUFBLFVBQ1IsYUFBYVI7QUFBQUEsVUFDYixnQkFBZ0JDO0FBQUFBO0FBQUFBLFFBSGxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdzQztBQUFBLFNBWDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsMkNBQTBDLGdDQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdFO0FBQUEsTUFDeEUsdUJBQUMsU0FBSSxXQUFVLGlEQUNaZ0MsMEJBQWdCa0MsTUFBTSxHQUFHLENBQUMsRUFBRWpDO0FBQUFBLFFBQUksQ0FBQ2tDLE1BQU1DLE1BQ3RDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxXQUFXaEY7QUFBQUEsY0FDVDtBQUFBLGNBQ0FnRixJQUFJLEtBQUs7QUFBQSxZQUNYO0FBQUEsWUFFQTtBQUFBLHFDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxnSkFDWkEsY0FBSSxLQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsU0FBSSxXQUFVLG9DQUFvQ0QsZUFBS2pDLE1BQU1tQyxRQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtRTtBQUFBLGtCQUNuRSx1QkFBQyxTQUFJLFdBQVUsOEJBQ1pGO0FBQUFBLHlCQUFLekI7QUFBQUEsb0JBQWU7QUFBQSxvQkFBV3lCLEtBQUt0QixVQUFVb0IsUUFBUSxDQUFDO0FBQUEsb0JBQUU7QUFBQSx1QkFENUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxtQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxnREFDWkUsZUFBS2hCLGdCQUFnQmMsUUFBUSxDQUFDLEtBRGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsOEJBQTRCO0FBQUE7QUFBQSxrQkFDdkNFLEtBQUtqQixZQUFZZSxRQUFRLENBQUM7QUFBQSxrQkFBRTtBQUFBLHFCQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBO0FBQUE7QUFBQSxVQXhCS0UsS0FBS2pDLE1BQU1LO0FBQUFBLFVBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUEwQkE7QUFBQSxNQUNELEtBN0JIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4QkE7QUFBQSxTQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUNBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSwyQ0FBMEMscUNBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkU7QUFBQSxNQUM3RSx1QkFBQyxTQUFJLFdBQVUsa0RBQ2IsaUNBQUMsU0FBSSxXQUFVLGtDQUNaYywwQkFBZ0JwQixJQUFJLENBQUMyQixPQUFPUSxNQUFNO0FBQ2pDLGNBQU1FLFdBQVc5QyxLQUFLK0MsSUFBSSxHQUFHbEIsaUJBQWlCLENBQUM7QUFDL0MsY0FBTW1CLFNBQVVaLFFBQVFVLFdBQVk7QUFDcEMsZUFDRSx1QkFBQyxTQUFZLFdBQVUscUNBQ3JCO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE9BQU87QUFBQSxnQkFDTEUsUUFBUSxHQUFHQSxNQUFNO0FBQUEsZ0JBQ2pCQyxXQUFXYixRQUFRLElBQUksUUFBUTtBQUFBLGdCQUMvQmMsaUJBQWlCakYsYUFBYSxDQUFDO0FBQUEsY0FDakM7QUFBQSxjQUNBLE9BQU8sR0FBR21FLEtBQUs7QUFBQTtBQUFBLFlBUGpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU8wQjtBQUFBLFVBRTFCLHVCQUFDLFNBQUksV0FBVSxtQ0FDWlEsZ0JBQU0sSUFBSSxVQUFVLEdBQUcsSUFBSUEsQ0FBQyxPQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFaUUEsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxNQUVKLENBQUMsS0FwQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCQSxLQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUJBO0FBQUEsU0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQTtBQUFBLElBR0NaLFlBQVlaLFNBQVMsS0FDcEIsdUJBQUMsU0FDQztBQUFBLDZCQUFDLFFBQUcsV0FBVSwyQ0FBMEMsMkJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUU7QUFBQSxNQUNuRSx1QkFBQyxTQUFJLFdBQVUsdUJBQ1pZLHNCQUFZdkI7QUFBQUEsUUFBSSxDQUFDMEMsWUFBWVAsTUFDNUI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsdUNBQUMsZUFBWSxNQUFNTyxXQUFXZCxhQUFhLGFBQWEsVUFBVSxXQUMvRGMscUJBQVdkLGFBQWEsYUFBYSxhQUFhLGFBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsU0FBSSxXQUFVLG9DQUFvQ2MscUJBQVdoQixRQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtRTtBQUFBLGtCQUNuRSx1QkFBQyxTQUFJLFdBQVUscUNBQXFDZ0IscUJBQVdiLFdBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVFO0FBQUEscUJBRnpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXMUU7QUFBQUEsb0JBQ1Q7QUFBQSxvQkFDQXVGLFdBQVdkLGFBQWEsYUFBYSxhQUFhO0FBQUEsa0JBQ3BEO0FBQUEsa0JBRUNjLHFCQUFXZjtBQUFBQTtBQUFBQSxnQkFOZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBO0FBQUE7QUFBQSxVQW5CS1E7QUFBQUEsVUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBcUJBO0FBQUEsTUFDRCxLQXhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUJBO0FBQUEsU0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRCQTtBQUFBLE9BbElKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvSUEsS0FySUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNJQTtBQUVKO0FBQUN0RSxHQWpRZUgsb0JBQWtCO0FBQUEsVUFHakJULFVBS0RBLFVBS0RBLFVBS1dBLFFBQVE7QUFBQTtBQUFBLEtBbEJsQlM7QUFBa0IsSUFBQWlGO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlUXVlcnkiLCJhcGkiLCJjbiIsIlgiLCJNZXRyaWNCbG9jayIsIk1ldHJpY1JvdyIsIlN0YXR1c0JhZGdlIiwiQ0hBUlRfU0VSSUVTIiwiVXNhZ2VUcmVuZENoYXJ0cyIsIkFuYWx5dGljc0Rhc2hib2FyZCIsInByb2plY3RJZCIsIm9uQ2xvc2UiLCJfcyIsImNoYXJ0V2luZG93SG91cnMiLCJzZXRDaGFydFdpbmRvd0hvdXJzIiwiYWdlbnRzIiwibGlzdEFsbCIsInRhc2tzIiwicnVucyIsImxpc3RSZWNlbnQiLCJsaW1pdCIsInVzYWdlVGltZVNlcmllcyIsImdldFVzYWdlVGltZVNlcmllcyIsIndpbmRvd0hvdXJzIiwiYnVja2V0SG91cnMiLCJub3ciLCJEYXRlIiwic2V2ZW5EYXlzQWdvIiwibGFzdDdEYXlzUnVucyIsImZpbHRlciIsInIiLCJzdGFydGVkQXQiLCJkYWlseUNvc3RzIiwiQXJyYXkiLCJmaWxsIiwiZm9yRWFjaCIsInJ1biIsImRheXNBZ28iLCJNYXRoIiwiZmxvb3IiLCJjb3N0VXNkIiwiYXZnRGFpbHlDb3N0IiwicmVkdWNlIiwiYSIsImIiLCJmb3JlY2FzdDdEYXlzIiwiYWdlbnRFZmZpY2llbmN5IiwibWFwIiwiYWdlbnQiLCJhZ2VudFRhc2tzIiwidCIsImFzc2lnbmVlSWRzIiwiaW5jbHVkZXMiLCJfaWQiLCJhZ2VudFJ1bnMiLCJhZ2VudElkIiwiY29tcGxldGVkVGFza3MiLCJzdGF0dXMiLCJsZW5ndGgiLCJ0b3RhbENvc3QiLCJzdW0iLCJ0b3RhbFRpbWUiLCJkdXJhdGlvbk1zIiwidGFza3NQZXJIb3VyIiwiY29zdFBlclRhc2siLCJlZmZpY2llbmN5U2NvcmUiLCJzb3J0IiwiY29tcGxldGlvblRyZW5kIiwidGFzayIsIl9jcmVhdGlvblRpbWUiLCJib3R0bGVuZWNrcyIsInJldmlld1Rhc2tzIiwicHVzaCIsInR5cGUiLCJjb3VudCIsInNldmVyaXR5IiwibWVzc2FnZSIsImFwcHJvdmFsVGFza3MiLCJibG9ja2VkVGFza3MiLCJ0b0ZpeGVkIiwic2xpY2UiLCJpdGVtIiwiaSIsIm5hbWUiLCJtYXhDb3VudCIsIm1heCIsImhlaWdodCIsIm1pbkhlaWdodCIsImJhY2tncm91bmRDb2xvciIsImJvdHRsZW5lY2siLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBbmFseXRpY3NEYXNoYm9hcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB0eXBlIHsgSWQgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvZGF0YU1vZGVsXCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiO1xuaW1wb3J0IHsgWCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IE1ldHJpY0Jsb2NrLCBNZXRyaWNSb3cgfSBmcm9tIFwiLi9jb21wb25lbnRzL2ZhY3RvcnkvTWV0cmljQmxvY2tcIjtcbmltcG9ydCB7IFN0YXR1c0JhZGdlIH0gZnJvbSBcIi4vY29tcG9uZW50cy9mYWN0b3J5L2JhZGdlc1wiO1xuaW1wb3J0IHsgQ0hBUlRfU0VSSUVTIH0gZnJvbSBcIi4vY29tcG9uZW50cy9mYWN0b3J5L2NoYXJ0VGhlbWVcIjtcbmltcG9ydCB7XG4gIFVzYWdlVHJlbmRDaGFydHMsXG4gIHR5cGUgQ2hhcnRXaW5kb3csXG59IGZyb20gXCJAL2NvbXBvbmVudHMvZGFzaGJvYXJkL1VzYWdlVHJlbmRDaGFydHNcIjtcblxuaW50ZXJmYWNlIEFuYWx5dGljc0Rhc2hib2FyZFByb3BzIHtcbiAgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+IHwgbnVsbDtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEFuYWx5dGljc0Rhc2hib2FyZCh7IHByb2plY3RJZCwgb25DbG9zZSB9OiBBbmFseXRpY3NEYXNoYm9hcmRQcm9wcykge1xuICBjb25zdCBbY2hhcnRXaW5kb3dIb3Vycywgc2V0Q2hhcnRXaW5kb3dIb3Vyc10gPSB1c2VTdGF0ZTxDaGFydFdpbmRvdz4oMTY4KTtcblxuICBjb25zdCBhZ2VudHMgPSB1c2VRdWVyeShcbiAgICBhcGkuYWdlbnRzLmxpc3RBbGwsXG4gICAgcHJvamVjdElkID8geyBwcm9qZWN0SWQgfSA6IHt9XG4gICk7XG5cbiAgY29uc3QgdGFza3MgPSB1c2VRdWVyeShcbiAgICBhcGkudGFza3MubGlzdEFsbCxcbiAgICBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCB9IDoge31cbiAgKTtcblxuICBjb25zdCBydW5zID0gdXNlUXVlcnkoXG4gICAgYXBpLnJ1bnMubGlzdFJlY2VudCxcbiAgICB7IGxpbWl0OiAxMDAwIH1cbiAgKTtcblxuICBjb25zdCB1c2FnZVRpbWVTZXJpZXMgPSB1c2VRdWVyeShcbiAgICBhcGkucnVucy5nZXRVc2FnZVRpbWVTZXJpZXMsXG4gICAgcHJvamVjdElkXG4gICAgICA/IHtcbiAgICAgICAgICBwcm9qZWN0SWQsXG4gICAgICAgICAgd2luZG93SG91cnM6IGNoYXJ0V2luZG93SG91cnMsXG4gICAgICAgICAgYnVja2V0SG91cnM6IGNoYXJ0V2luZG93SG91cnMgPT09IDI0ID8gMSA6IDI0LFxuICAgICAgICB9XG4gICAgICA6IHtcbiAgICAgICAgICB3aW5kb3dIb3VyczogY2hhcnRXaW5kb3dIb3VycyxcbiAgICAgICAgICBidWNrZXRIb3VyczogY2hhcnRXaW5kb3dIb3VycyA9PT0gMjQgPyAxIDogMjQsXG4gICAgICAgIH0sXG4gICk7XG5cbiAgaWYgKCFhZ2VudHMgfHwgIXRhc2tzIHx8ICFydW5zKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVsxMDAwXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ibGFjay83MFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMSBwLTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMTYgdy00MCBhbmltYXRlLXB1bHNlIHJvdW5kZWQgYmctc3VyZmFjZS0yXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgY29uc3Qgc2V2ZW5EYXlzQWdvID0gbm93IC0gNyAqIDI0ICogNjAgKiA2MCAqIDEwMDA7XG5cbiAgY29uc3QgbGFzdDdEYXlzUnVucyA9IHJ1bnMuZmlsdGVyKHIgPT4gci5zdGFydGVkQXQgPj0gc2V2ZW5EYXlzQWdvKTtcbiAgY29uc3QgZGFpbHlDb3N0cyA9IG5ldyBBcnJheSg3KS5maWxsKDApO1xuXG4gIGxhc3Q3RGF5c1J1bnMuZm9yRWFjaChydW4gPT4ge1xuICAgIGNvbnN0IGRheXNBZ28gPSBNYXRoLmZsb29yKChub3cgLSBydW4uc3RhcnRlZEF0KSAvICgyNCAqIDYwICogNjAgKiAxMDAwKSk7XG4gICAgaWYgKGRheXNBZ28gPj0gMCAmJiBkYXlzQWdvIDwgNykge1xuICAgICAgZGFpbHlDb3N0c1s2IC0gZGF5c0Fnb10gKz0gcnVuLmNvc3RVc2Q7XG4gICAgfVxuICB9KTtcblxuICBjb25zdCBhdmdEYWlseUNvc3QgPSBkYWlseUNvc3RzLnJlZHVjZSgoYSwgYikgPT4gYSArIGIsIDApIC8gNztcbiAgY29uc3QgZm9yZWNhc3Q3RGF5cyA9IGF2Z0RhaWx5Q29zdCAqIDc7XG5cbiAgY29uc3QgYWdlbnRFZmZpY2llbmN5ID0gYWdlbnRzLm1hcChhZ2VudCA9PiB7XG4gICAgY29uc3QgYWdlbnRUYXNrcyA9IHRhc2tzLmZpbHRlcih0ID0+IHQuYXNzaWduZWVJZHMuaW5jbHVkZXMoYWdlbnQuX2lkKSk7XG4gICAgY29uc3QgYWdlbnRSdW5zID0gcnVucy5maWx0ZXIociA9PiByLmFnZW50SWQgPT09IGFnZW50Ll9pZCk7XG5cbiAgICBjb25zdCBjb21wbGV0ZWRUYXNrcyA9IGFnZW50VGFza3MuZmlsdGVyKHQgPT4gdC5zdGF0dXMgPT09IFwiRE9ORVwiKS5sZW5ndGg7XG4gICAgY29uc3QgdG90YWxDb3N0ID0gYWdlbnRSdW5zLnJlZHVjZSgoc3VtLCByKSA9PiBzdW0gKyByLmNvc3RVc2QsIDApO1xuICAgIGNvbnN0IHRvdGFsVGltZSA9IGFnZW50UnVucy5yZWR1Y2UoKHN1bSwgcikgPT4gc3VtICsgKHIuZHVyYXRpb25NcyB8fCAwKSwgMCk7XG5cbiAgICBjb25zdCB0YXNrc1BlckhvdXIgPSB0b3RhbFRpbWUgPiAwID8gKGNvbXBsZXRlZFRhc2tzIC8gKHRvdGFsVGltZSAvICgxMDAwICogNjAgKiA2MCkpKSA6IDA7XG4gICAgY29uc3QgY29zdFBlclRhc2sgPSBjb21wbGV0ZWRUYXNrcyA+IDAgPyB0b3RhbENvc3QgLyBjb21wbGV0ZWRUYXNrcyA6IDA7XG4gICAgY29uc3QgZWZmaWNpZW5jeVNjb3JlID0gY29tcGxldGVkVGFza3MgPiAwID8gKGNvbXBsZXRlZFRhc2tzIC8gKHRvdGFsQ29zdCArIDEpKSAqIDEwMCA6IDA7XG5cbiAgICByZXR1cm4ge1xuICAgICAgYWdlbnQsXG4gICAgICBjb21wbGV0ZWRUYXNrcyxcbiAgICAgIHRhc2tzUGVySG91cixcbiAgICAgIGNvc3RQZXJUYXNrLFxuICAgICAgZWZmaWNpZW5jeVNjb3JlLFxuICAgICAgdG90YWxDb3N0LFxuICAgIH07XG4gIH0pLnNvcnQoKGEsIGIpID0+IGIuZWZmaWNpZW5jeVNjb3JlIC0gYS5lZmZpY2llbmN5U2NvcmUpO1xuXG4gIGNvbnN0IGNvbXBsZXRpb25UcmVuZCA9IG5ldyBBcnJheSg3KS5maWxsKDApO1xuICB0YXNrcy5maWx0ZXIodCA9PiB0LnN0YXR1cyA9PT0gXCJET05FXCIpLmZvckVhY2godGFzayA9PiB7XG4gICAgY29uc3QgZGF5c0FnbyA9IE1hdGguZmxvb3IoKG5vdyAtIHRhc2suX2NyZWF0aW9uVGltZSkgLyAoMjQgKiA2MCAqIDYwICogMTAwMCkpO1xuICAgIGlmIChkYXlzQWdvID49IDAgJiYgZGF5c0FnbyA8IDcpIHtcbiAgICAgIGNvbXBsZXRpb25UcmVuZFs2IC0gZGF5c0Fnb10rKztcbiAgICB9XG4gIH0pO1xuXG4gIGNvbnN0IGJvdHRsZW5lY2tzID0gW107XG5cbiAgY29uc3QgcmV2aWV3VGFza3MgPSB0YXNrcy5maWx0ZXIodCA9PiB0LnN0YXR1cyA9PT0gXCJSRVZJRVdcIik7XG4gIGlmIChyZXZpZXdUYXNrcy5sZW5ndGggPiA1KSB7XG4gICAgYm90dGxlbmVja3MucHVzaCh7XG4gICAgICB0eXBlOiBcIlJldmlldyBRdWV1ZVwiLFxuICAgICAgY291bnQ6IHJldmlld1Rhc2tzLmxlbmd0aCxcbiAgICAgIHNldmVyaXR5OiBcIndhcm5pbmdcIiBhcyBjb25zdCxcbiAgICAgIG1lc3NhZ2U6IGAke3Jldmlld1Rhc2tzLmxlbmd0aH0gdGFza3Mgd2FpdGluZyBmb3IgcmV2aWV3YCxcbiAgICB9KTtcbiAgfVxuXG4gIGNvbnN0IGFwcHJvdmFsVGFza3MgPSB0YXNrcy5maWx0ZXIodCA9PiB0LnN0YXR1cyA9PT0gXCJORUVEU19BUFBST1ZBTFwiKTtcbiAgaWYgKGFwcHJvdmFsVGFza3MubGVuZ3RoID4gMykge1xuICAgIGJvdHRsZW5lY2tzLnB1c2goe1xuICAgICAgdHlwZTogXCJBcHByb3ZhbCBRdWV1ZVwiLFxuICAgICAgY291bnQ6IGFwcHJvdmFsVGFza3MubGVuZ3RoLFxuICAgICAgc2V2ZXJpdHk6IFwiY3JpdGljYWxcIiBhcyBjb25zdCxcbiAgICAgIG1lc3NhZ2U6IGAke2FwcHJvdmFsVGFza3MubGVuZ3RofSB0YXNrcyB3YWl0aW5nIGZvciBhcHByb3ZhbGAsXG4gICAgfSk7XG4gIH1cblxuICBjb25zdCBibG9ja2VkVGFza3MgPSB0YXNrcy5maWx0ZXIodCA9PiB0LnN0YXR1cyA9PT0gXCJCTE9DS0VEXCIpO1xuICBpZiAoYmxvY2tlZFRhc2tzLmxlbmd0aCA+IDApIHtcbiAgICBib3R0bGVuZWNrcy5wdXNoKHtcbiAgICAgIHR5cGU6IFwiQmxvY2tlZCBUYXNrc1wiLFxuICAgICAgY291bnQ6IGJsb2NrZWRUYXNrcy5sZW5ndGgsXG4gICAgICBzZXZlcml0eTogXCJjcml0aWNhbFwiIGFzIGNvbnN0LFxuICAgICAgbWVzc2FnZTogYCR7YmxvY2tlZFRhc2tzLmxlbmd0aH0gdGFza3MgYXJlIGJsb2NrZWRgLFxuICAgIH0pO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bMTAwMF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgb3ZlcmZsb3cteS1hdXRvIGJnLWJsYWNrLzcwIHAtNVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtaC1bOTB2aF0gdy1mdWxsIG1heC13LVsxMjAwcHhdIG92ZXJmbG93LXktYXV0byByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgcC02XCI+XG4gICAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMTlweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPkFuYWx5dGljczwvaDI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtWzEzcHhdIHRleHQtaW5rLXNlY29uZGFyeVwiPlxuICAgICAgICAgICAgICBDb3N0IGZvcmVjYXN0LCBhZ2VudCBlZmZpY2llbmN5LCBhbmQgcGlwZWxpbmUgYm90dGxlbmVja3NcbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkNsb3NlIGFuYWx5dGljc1wiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIHAtMS41IHRleHQtaW5rLW11dGVkIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBob3ZlcjpiZy1zdXJmYWNlLTIgaG92ZXI6dGV4dC1pbmtcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxYIHNpemU9ezE2fSBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIENvc3QgRm9yZWNhc3RpbmcgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi0zIHRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj5Db3N0IGZvcmVjYXN0aW5nPC9oMz5cbiAgICAgICAgICA8TWV0cmljUm93IGNsYXNzTmFtZT1cIm1iLTQgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTIgeGw6Z3JpZC1jb2xzLTJcIj5cbiAgICAgICAgICAgIDxNZXRyaWNCbG9jayBsYWJlbD1cIkF2ZyBkYWlseSBjb3N0XCIgdmFsdWU9e2AkJHthdmdEYWlseUNvc3QudG9GaXhlZCgyKX1gfSBkZXRhaWw9XCJMYXN0IDcgZGF5c1wiIC8+XG4gICAgICAgICAgICA8TWV0cmljQmxvY2sgbGFiZWw9XCI3LWRheSBmb3JlY2FzdFwiIHZhbHVlPXtgJCR7Zm9yZWNhc3Q3RGF5cy50b0ZpeGVkKDIpfWB9IGRldGFpbD1cIkF0IGN1cnJlbnQgYnVybiByYXRlXCIgLz5cbiAgICAgICAgICA8L01ldHJpY1Jvdz5cblxuICAgICAgICAgIHt1c2FnZVRpbWVTZXJpZXMgJiYgKFxuICAgICAgICAgICAgPFVzYWdlVHJlbmRDaGFydHNcbiAgICAgICAgICAgICAgc2VyaWVzPXt1c2FnZVRpbWVTZXJpZXN9XG4gICAgICAgICAgICAgIHdpbmRvd0hvdXJzPXtjaGFydFdpbmRvd0hvdXJzfVxuICAgICAgICAgICAgICBvbldpbmRvd0NoYW5nZT17c2V0Q2hhcnRXaW5kb3dIb3Vyc31cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEFnZW50IEVmZmljaWVuY3kgTGVhZGVyYm9hcmQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi0zIHRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj5BZ2VudCBlZmZpY2llbmN5PC9oMz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LWhpZGRlbiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItbGluZVwiPlxuICAgICAgICAgICAge2FnZW50RWZmaWNpZW5jeS5zbGljZSgwLCA1KS5tYXAoKGl0ZW0sIGkpID0+IChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGtleT17aXRlbS5hZ2VudC5faWR9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgIFwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTQgcHktM1wiLFxuICAgICAgICAgICAgICAgICAgaSA8IDQgJiYgXCJib3JkZXItYiBib3JkZXItbGluZVwiXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTYgdy02IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTIgZm9udC1tb25vIHRleHQtWzExLjVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWluay1zZWNvbmRhcnlcIj5cbiAgICAgICAgICAgICAgICAgICAge2kgKyAxfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRleHQtaW5rXCI+e2l0ZW0uYWdlbnQubmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmNvbXBsZXRlZFRhc2tzfSB0YXNrcyDCtyAke2l0ZW0udG90YWxDb3N0LnRvRml4ZWQoMil9IHNwZW50XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LVsxNHB4XSBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+XG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLmVmZmljaWVuY3lTY29yZS50b0ZpeGVkKDEpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICR7aXRlbS5jb3N0UGVyVGFzay50b0ZpeGVkKDIpfS90YXNrXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFRhc2sgQ29tcGxldGlvbiBUcmVuZCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTMgdGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPlRhc2sgY29tcGxldGlvbiB0cmVuZDwvaDM+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgcC00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1bMTAwcHhdIGl0ZW1zLWVuZCBnYXAtMVwiPlxuICAgICAgICAgICAgICB7Y29tcGxldGlvblRyZW5kLm1hcCgoY291bnQsIGkpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBtYXhDb3VudCA9IE1hdGgubWF4KC4uLmNvbXBsZXRpb25UcmVuZCwgMSk7XG4gICAgICAgICAgICAgICAgY29uc3QgaGVpZ2h0ID0gKGNvdW50IC8gbWF4Q291bnQpICogMTAwO1xuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPVwiZmxleCBmbGV4LTEgZmxleC1jb2wgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC10LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBgJHtoZWlnaHR9JWAsXG4gICAgICAgICAgICAgICAgICAgICAgICBtaW5IZWlnaHQ6IGNvdW50ID4gMCA/IFwiNHB4XCIgOiBcIjBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogQ0hBUlRfU0VSSUVTWzBdLFxuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2Ake2NvdW50fSB0YXNrc2B9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LVsxMXB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtpID09PSA2ID8gXCJUb2RheVwiIDogYCR7NiAtIGl9ZGB9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEJvdHRsZW5lY2sgRGV0ZWN0aW9uICovfVxuICAgICAgICB7Ym90dGxlbmVja3MubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi0zIHRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj5Cb3R0bGVuZWNrczwvaDM+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTJcIj5cbiAgICAgICAgICAgICAge2JvdHRsZW5lY2tzLm1hcCgoYm90dGxlbmVjaywgaSkgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGtleT17aX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTIgcHgtNCBweS0zXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxTdGF0dXNCYWRnZSB0b25lPXtib3R0bGVuZWNrLnNldmVyaXR5ID09PSBcImNyaXRpY2FsXCIgPyBcImVycm9yXCIgOiBcIndhcm5pbmdcIn0+XG4gICAgICAgICAgICAgICAgICAgICAge2JvdHRsZW5lY2suc2V2ZXJpdHkgPT09IFwiY3JpdGljYWxcIiA/IFwiQ3JpdGljYWxcIiA6IFwiV2FybmluZ1wifVxuICAgICAgICAgICAgICAgICAgICA8L1N0YXR1c0JhZGdlPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGV4dC1pbmtcIj57Ym90dGxlbmVjay50eXBlfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMC41IHRleHQtWzEycHhdIHRleHQtaW5rLW11dGVkXCI+e2JvdHRsZW5lY2subWVzc2FnZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICBcImZvbnQtbW9ubyB0ZXh0LVsxOXB4XSBmb250LXNlbWlib2xkXCIsXG4gICAgICAgICAgICAgICAgICAgICAgYm90dGxlbmVjay5zZXZlcml0eSA9PT0gXCJjcml0aWNhbFwiID8gXCJ0ZXh0LWVyclwiIDogXCJ0ZXh0LXdhcm5cIlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7Ym90dGxlbmVjay5jb3VudH1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9BbmFseXRpY3NEYXNoYm9hcmQudHN4In0=