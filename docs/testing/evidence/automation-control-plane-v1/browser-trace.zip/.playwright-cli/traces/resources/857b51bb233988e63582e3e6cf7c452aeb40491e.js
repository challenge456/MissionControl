import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/MissionDAGView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { cn } from "/src/lib/utils.ts";
import { PageHeader } from "/src/components/PageHeader.tsx";
import { Card } from "/src/components/ui/card.tsx";
import { StatusBadge } from "/src/components/factory/badges.tsx";
import { MetricBlock } from "/src/components/factory/MetricBlock.tsx";
import { GitBranch } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
const STATUS_COLORS = {
  INBOX: "#64748b",
  ASSIGNED: "#2563eb",
  IN_PROGRESS: "#3b82f6",
  REVIEW: "#f59e0b",
  NEEDS_APPROVAL: "#f97316",
  BLOCKED: "#ef4444",
  FAILED: "#dc2626",
  DONE: "#10b981",
  CANCELED: "#475569"
};
function layoutNodes(nodes, edges) {
  const subtasksOf = /* @__PURE__ */ new Map();
  for (const node of nodes) {
    if (node.parentTaskId) {
      const list = subtasksOf.get(node.parentTaskId) ?? [];
      list.push(node);
      subtasksOf.set(node.parentTaskId, list);
    }
  }
  const inDegree = /* @__PURE__ */ new Map();
  const adjList = /* @__PURE__ */ new Map();
  for (const node of nodes) {
    inDegree.set(node.id, 0);
    adjList.set(node.id, []);
  }
  for (const edge of edges) {
    const existing = adjList.get(edge.to) ?? [];
    existing.push(edge.from);
    adjList.set(edge.to, existing);
    inDegree.set(edge.from, (inDegree.get(edge.from) ?? 0) + 1);
  }
  const layers = /* @__PURE__ */ new Map();
  const queue = [];
  for (const [id, deg] of inDegree) {
    if (deg === 0) {
      queue.push(id);
      layers.set(id, 0);
    }
  }
  while (queue.length > 0) {
    const current = queue.shift();
    const currentLayer = layers.get(current) ?? 0;
    for (const neighbor of adjList.get(current) ?? []) {
      const newDeg = (inDegree.get(neighbor) ?? 1) - 1;
      inDegree.set(neighbor, newDeg);
      layers.set(neighbor, Math.max(layers.get(neighbor) ?? 0, currentLayer + 1));
      if (newDeg === 0) {
        queue.push(neighbor);
      }
    }
  }
  const layerGroups = /* @__PURE__ */ new Map();
  for (const [id, layer] of layers) {
    const list = layerGroups.get(layer) ?? [];
    list.push(id);
    layerGroups.set(layer, list);
  }
  for (const node of nodes) {
    if (!layers.has(node.id)) {
      layers.set(node.id, 0);
      const list = layerGroups.get(0) ?? [];
      list.push(node.id);
      layerGroups.set(0, list);
    }
  }
  const NODE_W = 240;
  const NODE_H = 60;
  const H_GAP = 80;
  const V_GAP = 30;
  const positions = /* @__PURE__ */ new Map();
  const maxLayer = Math.max(...Array.from(layerGroups.keys()), 0);
  for (let layer = 0; layer <= maxLayer; layer++) {
    const group = layerGroups.get(layer) ?? [];
    const x = layer * (NODE_W + H_GAP) + 40;
    for (let i = 0; i < group.length; i++) {
      const y = i * (NODE_H + V_GAP) + 40;
      positions.set(group[i], { x, y });
    }
  }
  return { positions, nodeWidth: NODE_W, nodeHeight: NODE_H };
}
export function MissionDAGView({ projectId, onTaskSelect }) {
  _s();
  const [hoveredNode, setHoveredNode] = useState(null);
  const [filter, setFilter] = useState("all");
  const graphData = useQuery(
    api.coordinator.getDependencyGraph,
    projectId ? { projectId } : {}
  );
  const tasks = useQuery(api.tasks.listAll, projectId ? { projectId } : {});
  const { nodes, edges, metrics } = useMemo(() => {
    if (graphData) {
      return graphData;
    }
    if (tasks) {
      const nodes2 = tasks.map((t) => ({
        id: t._id,
        title: t.title,
        status: t.status,
        type: t.type,
        priority: t.priority,
        assigneeIds: t.assigneeIds,
        parentTaskId: t.parentTaskId
      }));
      return {
        nodes: nodes2,
        edges: [],
        metrics: { depth: nodes2.length > 0 ? 1 : 0, maximumWidth: nodes2.length, readyCount: 0, cyclicNodeCount: 0 }
      };
    }
    return {
      nodes: [],
      edges: [],
      metrics: { depth: 0, maximumWidth: 0, readyCount: 0, cyclicNodeCount: 0 }
    };
  }, [graphData, tasks]);
  const filteredNodes = useMemo(() => {
    if (filter === "all") return nodes;
    return nodes.filter((n) => n.status === filter);
  }, [nodes, filter]);
  const layout = useMemo(
    () => layoutNodes(
      filteredNodes.map((n) => ({
        id: n.id,
        parentTaskId: n.parentTaskId,
        status: n.status
      })),
      edges.map((e) => ({ from: e.from, to: e.to }))
    ),
    [filteredNodes, edges]
  );
  const positionedNodes = Array.from(layout.positions.values());
  const canvasWidth = Math.max(
    800,
    ...positionedNodes.map((p) => p.x + layout.nodeWidth + 40)
  );
  const canvasHeight = Math.max(
    400,
    ...positionedNodes.map((p) => p.y + layout.nodeHeight + 40)
  );
  const statusCounts = useMemo(() => {
    const counts = {};
    for (const n of nodes) {
      counts[n.status] = (counts[n.status] ?? 0) + 1;
    }
    return counts;
  }, [nodes]);
  const blockedCount = statusCounts.BLOCKED ?? 0;
  return /* @__PURE__ */ jsxDEV("section", { className: "flex min-h-0 flex-1 flex-col overflow-hidden bg-app", children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: "Mission DAG",
        description: "Visualize dependency structure, sequencing, and blockers across the mission graph.",
        icon: /* @__PURE__ */ jsxDEV(GitBranch, { className: "h-4.5 w-4.5", strokeWidth: 1.7 }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
          lineNumber: 222,
          columnNumber: 15
        }, this),
        eyebrow: "Operations",
        status: /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", children: [
          nodes.length,
          " tasks · ",
          edges.length,
          " dependencies"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
          lineNumber: 225,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
        lineNumber: 219,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-0 flex-1 flex-col overflow-hidden px-6 pb-6 pt-4 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid shrink-0 gap-4 md:grid-cols-4", children: [
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Graph size",
            value: nodes.length,
            detail: "Tasks currently represented in the dependency graph"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
            lineNumber: 233,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
          lineNumber: 232,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Edges",
            value: edges.length,
            detail: "Explicit dependencies shaping execution order"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
            lineNumber: 240,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
          lineNumber: 239,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Parallel width",
            value: metrics.maximumWidth,
            detail: `${metrics.readyCount} node(s) ready now · ${metrics.depth} dependency layer(s)`
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
            lineNumber: 247,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
          lineNumber: 246,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Blocked",
            value: blockedCount + metrics.cyclicNodeCount,
            detail: metrics.cyclicNodeCount > 0 ? `${metrics.cyclicNodeCount} node(s) are part of an invalid dependency cycle` : "Nodes currently breaking flow through the graph"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
            lineNumber: 254,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
          lineNumber: 253,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
        lineNumber: 231,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "shrink-0 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-3 overflow-x-auto flex-nowrap", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "shrink-0", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-[15px] font-semibold text-ink", children: "Graph filters" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
            lineNumber: 269,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-[12.5px] text-ink-muted", children: "Focus the dependency map by task state" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
            lineNumber: 270,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
          lineNumber: 268,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex shrink-0 gap-1 rounded-lg border border-line p-0.5", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: cn(
                "rounded-md px-3 py-1.5 text-xs font-medium transition-colors duration-150",
                filter === "all" ? "bg-surface-2 text-ink" : "text-ink-secondary hover:text-ink"
              ),
              onClick: () => setFilter("all"),
              children: [
                "All (",
                nodes.length,
                ")"
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
              lineNumber: 273,
              columnNumber: 15
            },
            this
          ),
          Object.entries(statusCounts).map(
            ([status, count]) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                className: cn(
                  "rounded-md px-3 py-1.5 text-xs font-medium transition-colors duration-150",
                  filter === status ? "bg-surface-2 text-ink" : "text-ink-secondary hover:text-ink"
                ),
                onClick: () => setFilter(filter === status ? "all" : status),
                children: [
                  status,
                  " (",
                  count,
                  ")"
                ]
              },
              status,
              true,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
                lineNumber: 285,
                columnNumber: 15
              },
              this
            )
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
          lineNumber: 272,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
        lineNumber: 267,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
        lineNumber: 266,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid min-h-0 flex-1 gap-4 xl:grid-cols-[minmax(0,1fr)_320px]", children: [
        /* @__PURE__ */ jsxDEV(Card, { className: "flex min-h-0 flex-1 flex-col overflow-hidden p-0", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "shrink-0 border-b border-line px-5 py-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-[15px] font-semibold text-ink", children: "Dependency canvas" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
              lineNumber: 305,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-[12.5px] text-ink-muted", children: "Read downstream relationships before changing task sequencing" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
              lineNumber: 306,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
            lineNumber: 304,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "min-h-0 flex-1 overflow-auto bg-app", children: /* @__PURE__ */ jsxDEV(
            "svg",
            {
              width: canvasWidth,
              height: canvasHeight,
              className: "bg-transparent",
              children: [
                edges.map((edge, i) => {
                  const fromPos = layout.positions.get(edge.from);
                  const toPos = layout.positions.get(edge.to);
                  if (!fromPos || !toPos) return null;
                  const x1 = toPos.x + layout.nodeWidth;
                  const y1 = toPos.y + layout.nodeHeight / 2;
                  const x2 = fromPos.x;
                  const y2 = fromPos.y + layout.nodeHeight / 2;
                  return /* @__PURE__ */ jsxDEV(
                    "line",
                    {
                      x1,
                      y1,
                      x2,
                      y2,
                      className: "stroke-line",
                      strokeWidth: 1.5,
                      markerEnd: "url(#arrowhead)"
                    },
                    `edge-${i}`,
                    false,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
                      lineNumber: 326,
                      columnNumber: 21
                    },
                    this
                  );
                }),
                /* @__PURE__ */ jsxDEV("defs", { children: /* @__PURE__ */ jsxDEV(
                  "marker",
                  {
                    id: "arrowhead",
                    markerWidth: "10",
                    markerHeight: "7",
                    refX: "10",
                    refY: "3.5",
                    orient: "auto",
                    children: /* @__PURE__ */ jsxDEV(
                      "polygon",
                      {
                        points: "0 0, 10 3.5, 0 7",
                        className: "fill-line"
                      },
                      void 0,
                      false,
                      {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
                        lineNumber: 349,
                        columnNumber: 15
                      },
                      this
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
                    lineNumber: 341,
                    columnNumber: 13
                  },
                  this
                ) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
                  lineNumber: 340,
                  columnNumber: 11
                }, this),
                filteredNodes.map((node) => {
                  const pos = layout.positions.get(node.id);
                  if (!pos) return null;
                  const isHovered = hoveredNode === node.id;
                  const statusColor = STATUS_COLORS[node.status] ?? "#64748b";
                  return /* @__PURE__ */ jsxDEV(
                    "g",
                    {
                      onClick: () => onTaskSelect?.(node.id),
                      onMouseEnter: () => setHoveredNode(node.id),
                      onMouseLeave: () => setHoveredNode(null),
                      style: { cursor: "pointer" },
                      children: [
                        /* @__PURE__ */ jsxDEV(
                          "rect",
                          {
                            x: pos.x,
                            y: pos.y,
                            width: layout.nodeWidth,
                            height: layout.nodeHeight,
                            rx: 8,
                            ry: 8,
                            style: {
                              fill: isHovered ? "var(--color-surface-2)" : "var(--color-surface-1)",
                              stroke: statusColor,
                              strokeWidth: isHovered ? 2 : 1.5
                            }
                          },
                          void 0,
                          false,
                          {
                            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
                            lineNumber: 371,
                            columnNumber: 17
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          "rect",
                          {
                            x: pos.x,
                            y: pos.y,
                            width: 6,
                            height: layout.nodeHeight,
                            rx: 8,
                            style: { fill: statusColor }
                          },
                          void 0,
                          false,
                          {
                            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
                            lineNumber: 385,
                            columnNumber: 17
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          "text",
                          {
                            x: pos.x + 14,
                            y: pos.y + 22,
                            className: "fill-ink",
                            fontSize: 12,
                            fontWeight: 600,
                            children: node.title.length > 28 ? node.title.slice(0, 25) + "..." : node.title
                          },
                          void 0,
                          false,
                          {
                            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
                            lineNumber: 394,
                            columnNumber: 17
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          "text",
                          {
                            x: pos.x + 14,
                            y: pos.y + 42,
                            className: "fill-ink-muted",
                            fontSize: 10,
                            children: [
                              node.status,
                              " · ",
                              node.type,
                              " · P",
                              node.priority
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
                            lineNumber: 406,
                            columnNumber: 17
                          },
                          this
                        )
                      ]
                    },
                    node.id,
                    true,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
                      lineNumber: 364,
                      columnNumber: 21
                    },
                    this
                  );
                })
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
              lineNumber: 309,
              columnNumber: 9
            },
            this
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
            lineNumber: 308,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
          lineNumber: 303,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-[15px] font-semibold text-ink", children: "Operator guidance" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
            lineNumber: 422,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-2 space-y-3 text-[13.5px] leading-relaxed text-ink-secondary", children: [
            /* @__PURE__ */ jsxDEV("p", { children: "Use the graph to inspect sequencing before you change task ownership. A node with many incoming lines usually represents a coordination choke point." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
              lineNumber: 424,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "Blocked nodes matter most when they sit early in the graph. Clear them before optimizing lower-value branches." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
              lineNumber: 425,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
            lineNumber: 423,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-4 rounded-xl border border-line bg-surface-2 p-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-[11.5px] font-medium text-ink-muted", children: "Legend" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
              lineNumber: 428,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex gap-3 flex-wrap", children: Object.entries(STATUS_COLORS).map(
              ([status, color]) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "w-2 h-2 rounded-full",
                    style: { background: color }
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
                    lineNumber: 432,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-ink-muted text-xs", children: status }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
                  lineNumber: 436,
                  columnNumber: 19
                }, this)
              ] }, status, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
                lineNumber: 431,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
              lineNumber: 429,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
            lineNumber: 427,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
          lineNumber: 421,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
        lineNumber: 302,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
      lineNumber: 230,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx",
    lineNumber: 218,
    columnNumber: 5
  }, this);
}
_s(MissionDAGView, "oGRraI1WOVq2s3h81PlrtHlTHT0=", false, function() {
  return [useQuery, useQuery];
});
_c = MissionDAGView;
var _c;
$RefreshReg$(_c, "MissionDAGView");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionDAGView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBME1jOzs7Ozs7Ozs7Ozs7Ozs7OztBQWxNZCxTQUFTQSxVQUFVQyxlQUFlO0FBQ2xDLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxXQUFXO0FBRXBCLFNBQVNDLFVBQVU7QUFDbkIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxpQkFBaUI7QUFPMUIsTUFBTUMsZ0JBQXdDO0FBQUEsRUFDNUNDLE9BQU87QUFBQSxFQUNQQyxVQUFVO0FBQUEsRUFDVkMsYUFBYTtBQUFBLEVBQ2JDLFFBQVE7QUFBQSxFQUNSQyxnQkFBZ0I7QUFBQSxFQUNoQkMsU0FBUztBQUFBLEVBQ1RDLFFBQVE7QUFBQSxFQUNSQyxNQUFNO0FBQUEsRUFDTkMsVUFBVTtBQUNaO0FBR0EsU0FBU0MsWUFDUEMsT0FDQUMsT0FDQTtBQUNBLFFBQU1DLGFBQWEsb0JBQUlDLElBQTBCO0FBRWpELGFBQVdDLFFBQVFKLE9BQU87QUFDeEIsUUFBSUksS0FBS0MsY0FBYztBQUNyQixZQUFNQyxPQUFPSixXQUFXSyxJQUFJSCxLQUFLQyxZQUFZLEtBQUs7QUFDbERDLFdBQUtFLEtBQUtKLElBQUk7QUFDZEYsaUJBQVdPLElBQUlMLEtBQUtDLGNBQWNDLElBQUk7QUFBQSxJQUN4QztBQUFBLEVBQ0Y7QUFFQSxRQUFNSSxXQUFXLG9CQUFJUCxJQUFvQjtBQUN6QyxRQUFNUSxVQUFVLG9CQUFJUixJQUFzQjtBQUMxQyxhQUFXQyxRQUFRSixPQUFPO0FBQ3hCVSxhQUFTRCxJQUFJTCxLQUFLUSxJQUFJLENBQUM7QUFDdkJELFlBQVFGLElBQUlMLEtBQUtRLElBQUksRUFBRTtBQUFBLEVBQ3pCO0FBQ0EsYUFBV0MsUUFBUVosT0FBTztBQUN4QixVQUFNYSxXQUFXSCxRQUFRSixJQUFJTSxLQUFLRSxFQUFFLEtBQUs7QUFDekNELGFBQVNOLEtBQUtLLEtBQUtHLElBQUk7QUFDdkJMLFlBQVFGLElBQUlJLEtBQUtFLElBQUlELFFBQVE7QUFDN0JKLGFBQVNELElBQUlJLEtBQUtHLE9BQU9OLFNBQVNILElBQUlNLEtBQUtHLElBQUksS0FBSyxLQUFLLENBQUM7QUFBQSxFQUM1RDtBQUVBLFFBQU1DLFNBQVMsb0JBQUlkLElBQW9CO0FBQ3ZDLFFBQU1lLFFBQWtCO0FBQ3hCLGFBQVcsQ0FBQ04sSUFBSU8sR0FBRyxLQUFLVCxVQUFVO0FBQ2hDLFFBQUlTLFFBQVEsR0FBRztBQUNiRCxZQUFNVixLQUFLSSxFQUFFO0FBQ2JLLGFBQU9SLElBQUlHLElBQUksQ0FBQztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBLFNBQU9NLE1BQU1FLFNBQVMsR0FBRztBQUN2QixVQUFNQyxVQUFVSCxNQUFNSSxNQUFNO0FBQzVCLFVBQU1DLGVBQWVOLE9BQU9WLElBQUljLE9BQU8sS0FBSztBQUM1QyxlQUFXRyxZQUFZYixRQUFRSixJQUFJYyxPQUFPLEtBQUssSUFBSTtBQUNqRCxZQUFNSSxVQUFVZixTQUFTSCxJQUFJaUIsUUFBUSxLQUFLLEtBQUs7QUFDL0NkLGVBQVNELElBQUllLFVBQVVDLE1BQU07QUFDN0JSLGFBQU9SLElBQUllLFVBQVVFLEtBQUtDLElBQUlWLE9BQU9WLElBQUlpQixRQUFRLEtBQUssR0FBR0QsZUFBZSxDQUFDLENBQUM7QUFDMUUsVUFBSUUsV0FBVyxHQUFHO0FBQ2hCUCxjQUFNVixLQUFLZ0IsUUFBUTtBQUFBLE1BQ3JCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNSSxjQUFjLG9CQUFJekIsSUFBc0I7QUFDOUMsYUFBVyxDQUFDUyxJQUFJaUIsS0FBSyxLQUFLWixRQUFRO0FBQ2hDLFVBQU1YLE9BQU9zQixZQUFZckIsSUFBSXNCLEtBQUssS0FBSztBQUN2Q3ZCLFNBQUtFLEtBQUtJLEVBQUU7QUFDWmdCLGdCQUFZbkIsSUFBSW9CLE9BQU92QixJQUFJO0FBQUEsRUFDN0I7QUFFQSxhQUFXRixRQUFRSixPQUFPO0FBQ3hCLFFBQUksQ0FBQ2lCLE9BQU9hLElBQUkxQixLQUFLUSxFQUFFLEdBQUc7QUFDeEJLLGFBQU9SLElBQUlMLEtBQUtRLElBQUksQ0FBQztBQUNyQixZQUFNTixPQUFPc0IsWUFBWXJCLElBQUksQ0FBQyxLQUFLO0FBQ25DRCxXQUFLRSxLQUFLSixLQUFLUSxFQUFFO0FBQ2pCZ0Isa0JBQVluQixJQUFJLEdBQUdILElBQUk7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNeUIsU0FBUztBQUNmLFFBQU1DLFNBQVM7QUFDZixRQUFNQyxRQUFRO0FBQ2QsUUFBTUMsUUFBUTtBQUVkLFFBQU1DLFlBQVksb0JBQUloQyxJQUFzQztBQUM1RCxRQUFNaUMsV0FBV1YsS0FBS0MsSUFBSSxHQUFHVSxNQUFNckIsS0FBS1ksWUFBWVUsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUU5RCxXQUFTVCxRQUFRLEdBQUdBLFNBQVNPLFVBQVVQLFNBQVM7QUFDOUMsVUFBTVUsUUFBUVgsWUFBWXJCLElBQUlzQixLQUFLLEtBQUs7QUFDeEMsVUFBTVcsSUFBSVgsU0FBU0UsU0FBU0UsU0FBUztBQUNyQyxhQUFTUSxJQUFJLEdBQUdBLElBQUlGLE1BQU1uQixRQUFRcUIsS0FBSztBQUNyQyxZQUFNQyxJQUFJRCxLQUFLVCxTQUFTRSxTQUFTO0FBQ2pDQyxnQkFBVTFCLElBQUk4QixNQUFNRSxDQUFDLEdBQUcsRUFBRUQsR0FBR0UsRUFBRSxDQUFDO0FBQUEsSUFDbEM7QUFBQSxFQUNGO0FBRUEsU0FBTyxFQUFFUCxXQUFXUSxXQUFXWixRQUFRYSxZQUFZWixPQUFPO0FBQzVEO0FBRU8sZ0JBQVNhLGVBQWUsRUFBRUMsV0FBV0MsYUFBa0MsR0FBRztBQUFBQyxLQUFBO0FBQy9FLFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJdkUsU0FBd0IsSUFBSTtBQUNsRSxRQUFNLENBQUN3RSxRQUFRQyxTQUFTLElBQUl6RSxTQUFpQixLQUFLO0FBRWxELFFBQU0wRSxZQUFZeEU7QUFBQUEsSUFDaEJDLElBQUl3RSxZQUFZQztBQUFBQSxJQUNoQlQsWUFBWSxFQUFFQSxVQUFVLElBQUksQ0FBQztBQUFBLEVBQy9CO0FBQ0EsUUFBTVUsUUFBUTNFLFNBQVNDLElBQUkwRSxNQUFNQyxTQUFTWCxZQUFZLEVBQUVBLFVBQVUsSUFBSSxDQUFDLENBQUM7QUFFeEUsUUFBTSxFQUFFOUMsT0FBT0MsT0FBT3lELFFBQVEsSUFBSTlFLFFBQVEsTUFBTTtBQUM5QyxRQUFJeUUsV0FBVztBQUNiLGFBQU9BO0FBQUFBLElBQ1Q7QUFDQSxRQUFJRyxPQUFPO0FBQ1QsWUFBTXhELFNBQVF3RCxNQUFNRyxJQUFJLENBQUNDLE9BQU87QUFBQSxRQUM5QmhELElBQUlnRCxFQUFFQztBQUFBQSxRQUNOQyxPQUFPRixFQUFFRTtBQUFBQSxRQUNUQyxRQUFRSCxFQUFFRztBQUFBQSxRQUNWQyxNQUFNSixFQUFFSTtBQUFBQSxRQUNSQyxVQUFVTCxFQUFFSztBQUFBQSxRQUNaQyxhQUFhTixFQUFFTTtBQUFBQSxRQUNmN0QsY0FBY3VELEVBQUV2RDtBQUFBQSxNQUNsQixFQUFFO0FBQ0YsYUFBTztBQUFBLFFBQ0xMO0FBQUFBLFFBQ0FDLE9BQU87QUFBQSxRQUNQeUQsU0FBUyxFQUFFUyxPQUFPbkUsT0FBTW9CLFNBQVMsSUFBSSxJQUFJLEdBQUdnRCxjQUFjcEUsT0FBTW9CLFFBQVFpRCxZQUFZLEdBQUdDLGlCQUFpQixFQUFFO0FBQUEsTUFDNUc7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLE1BQ0x0RSxPQUFPO0FBQUEsTUFDUEMsT0FBTztBQUFBLE1BQ1B5RCxTQUFTLEVBQUVTLE9BQU8sR0FBR0MsY0FBYyxHQUFHQyxZQUFZLEdBQUdDLGlCQUFpQixFQUFFO0FBQUEsSUFDMUU7QUFBQSxFQUNGLEdBQUcsQ0FBQ2pCLFdBQVdHLEtBQUssQ0FBQztBQUVyQixRQUFNZSxnQkFBZ0IzRixRQUFRLE1BQU07QUFDbEMsUUFBSXVFLFdBQVcsTUFBTyxRQUFPbkQ7QUFDN0IsV0FBT0EsTUFBTW1ELE9BQU8sQ0FBQ3FCLE1BQU1BLEVBQUVULFdBQVdaLE1BQU07QUFBQSxFQUNoRCxHQUFHLENBQUNuRCxPQUFPbUQsTUFBTSxDQUFDO0FBRWxCLFFBQU1zQixTQUFTN0Y7QUFBQUEsSUFDYixNQUNFbUI7QUFBQUEsTUFDRXdFLGNBQWNaLElBQUksQ0FBQ2EsT0FBTztBQUFBLFFBQ3hCNUQsSUFBSTRELEVBQUU1RDtBQUFBQSxRQUNOUCxjQUFjbUUsRUFBRW5FO0FBQUFBLFFBQ2hCMEQsUUFBUVMsRUFBRVQ7QUFBQUEsTUFDWixFQUFFO0FBQUEsTUFDRjlELE1BQU0wRCxJQUFJLENBQUNlLE9BQU8sRUFBRTFELE1BQU0wRCxFQUFFMUQsTUFBZ0JELElBQUkyRCxFQUFFM0QsR0FBYSxFQUFFO0FBQUEsSUFDbkU7QUFBQSxJQUNGLENBQUN3RCxlQUFldEUsS0FBSztBQUFBLEVBQ3ZCO0FBRUEsUUFBTTBFLGtCQUFrQnRDLE1BQU1yQixLQUFLeUQsT0FBT3RDLFVBQVV5QyxPQUFPLENBQUM7QUFFNUQsUUFBTUMsY0FBY25ELEtBQUtDO0FBQUFBLElBQ3ZCO0FBQUEsSUFDQSxHQUFHZ0QsZ0JBQWdCaEIsSUFBSSxDQUFDbUIsTUFBTUEsRUFBRXRDLElBQUlpQyxPQUFPOUIsWUFBWSxFQUFFO0FBQUEsRUFDM0Q7QUFDQSxRQUFNb0MsZUFBZXJELEtBQUtDO0FBQUFBLElBQ3hCO0FBQUEsSUFDQSxHQUFHZ0QsZ0JBQWdCaEIsSUFBSSxDQUFDbUIsTUFBTUEsRUFBRXBDLElBQUkrQixPQUFPN0IsYUFBYSxFQUFFO0FBQUEsRUFDNUQ7QUFFQSxRQUFNb0MsZUFBZXBHLFFBQVEsTUFBTTtBQUNqQyxVQUFNcUcsU0FBaUMsQ0FBQztBQUN4QyxlQUFXVCxLQUFLeEUsT0FBTztBQUNyQmlGLGFBQU9ULEVBQUVULE1BQU0sS0FBS2tCLE9BQU9ULEVBQUVULE1BQU0sS0FBSyxLQUFLO0FBQUEsSUFDL0M7QUFDQSxXQUFPa0I7QUFBQUEsRUFDVCxHQUFHLENBQUNqRixLQUFLLENBQUM7QUFDVixRQUFNa0YsZUFBZUYsYUFBYXJGLFdBQVc7QUFFN0MsU0FDRSx1QkFBQyxhQUFRLFdBQVUsdURBQ2pCO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLGFBQVk7QUFBQSxRQUNaLE1BQU0sdUJBQUMsYUFBVSxXQUFVLGVBQWMsYUFBYSxPQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9EO0FBQUEsUUFDMUQsU0FBUTtBQUFBLFFBQ1IsUUFDRSx1QkFBQyxlQUFZLE1BQUssV0FDZks7QUFBQUEsZ0JBQU1vQjtBQUFBQSxVQUFPO0FBQUEsVUFBVW5CLE1BQU1tQjtBQUFBQSxVQUFPO0FBQUEsYUFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUE7QUFBQSxNQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVNHO0FBQUEsSUFFSCx1QkFBQyxTQUFJLFdBQVUscUVBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsc0NBQ2I7QUFBQSwrQkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sT0FBT3BCLE1BQU1vQjtBQUFBQSxZQUNiLFFBQU87QUFBQTtBQUFBLFVBSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRzhELEtBSmhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBQ0EsdUJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE9BQU9uQixNQUFNbUI7QUFBQUEsWUFDYixRQUFPO0FBQUE7QUFBQSxVQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUd3RCxLQUoxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUNBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPc0MsUUFBUVU7QUFBQUEsWUFDZixRQUFRLEdBQUdWLFFBQVFXLFVBQVUsd0JBQXdCWCxRQUFRUyxLQUFLO0FBQUE7QUFBQSxVQUhwRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHMkYsS0FKN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sT0FBT2UsZUFBZXhCLFFBQVFZO0FBQUFBLFlBQzlCLFFBQ0VaLFFBQVFZLGtCQUFrQixJQUN0QixHQUFHWixRQUFRWSxlQUFlLHFEQUMxQjtBQUFBO0FBQUEsVUFOUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPRyxLQVJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFdBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQ0E7QUFBQSxNQUVBLHVCQUFDLFFBQUssV0FBVSxnQkFDZCxpQ0FBQyxTQUFJLFdBQVUsdUVBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxzQ0FBcUMsNkJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlFO0FBQUEsVUFDakUsdUJBQUMsU0FBSSxXQUFVLHFDQUFvQyxzREFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUY7QUFBQSxhQUYzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwyREFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFXdkY7QUFBQUEsZ0JBQ1Q7QUFBQSxnQkFDQW9FLFdBQVcsUUFDUCwwQkFDQTtBQUFBLGNBQ047QUFBQSxjQUNBLFNBQVMsTUFBTUMsVUFBVSxLQUFLO0FBQUEsY0FBRTtBQUFBO0FBQUEsZ0JBRTFCcEQsTUFBTW9CO0FBQUFBLGdCQUFPO0FBQUE7QUFBQTtBQUFBLFlBVHJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsVUFDRStELE9BQU9DLFFBQVFKLFlBQVksRUFBOEJyQjtBQUFBQSxZQUFJLENBQUMsQ0FBQ0ksUUFBUXNCLEtBQUssTUFDNUU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxXQUFXdEc7QUFBQUEsa0JBQ1Q7QUFBQSxrQkFDQW9FLFdBQVdZLFNBQ1AsMEJBQ0E7QUFBQSxnQkFDTjtBQUFBLGdCQUNBLFNBQVMsTUFBTVgsVUFBVUQsV0FBV1ksU0FBUyxRQUFRQSxNQUFNO0FBQUEsZ0JBRTFEQTtBQUFBQTtBQUFBQSxrQkFBTztBQUFBLGtCQUFHc0I7QUFBQUEsa0JBQU07QUFBQTtBQUFBO0FBQUEsY0FUWnRCO0FBQUFBLGNBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVdBO0FBQUEsVUFDRDtBQUFBLGFBekJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQkE7QUFBQSxXQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0NBLEtBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQ0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxnRUFDZjtBQUFBLCtCQUFDLFFBQUssV0FBVSxvREFDZDtBQUFBLGlDQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxzQ0FBcUMsaUNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFO0FBQUEsWUFDckUsdUJBQUMsU0FBSSxXQUFVLHFDQUFvQyw2RUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0g7QUFBQSxlQUZsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2pCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPYztBQUFBQSxjQUNQLFFBQVFFO0FBQUFBLGNBQ1IsV0FBVTtBQUFBLGNBR1Q5RTtBQUFBQSxzQkFBTTBELElBQUksQ0FBQzlDLE1BQU00QixNQUFNO0FBQ3RCLHdCQUFNNkMsVUFBVWIsT0FBT3RDLFVBQVU1QixJQUFJTSxLQUFLRyxJQUFjO0FBQ3hELHdCQUFNdUUsUUFBUWQsT0FBT3RDLFVBQVU1QixJQUFJTSxLQUFLRSxFQUFZO0FBQ3BELHNCQUFJLENBQUN1RSxXQUFXLENBQUNDLE1BQU8sUUFBTztBQUUvQix3QkFBTUMsS0FBS0QsTUFBTS9DLElBQUlpQyxPQUFPOUI7QUFDNUIsd0JBQU04QyxLQUFLRixNQUFNN0MsSUFBSStCLE9BQU83QixhQUFhO0FBQ3pDLHdCQUFNOEMsS0FBS0osUUFBUTlDO0FBQ25CLHdCQUFNbUQsS0FBS0wsUUFBUTVDLElBQUkrQixPQUFPN0IsYUFBYTtBQUUzQyx5QkFDRTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFFQztBQUFBLHNCQUNBO0FBQUEsc0JBQ0E7QUFBQSxzQkFDQTtBQUFBLHNCQUNBLFdBQVU7QUFBQSxzQkFDVixhQUFhO0FBQUEsc0JBQ2IsV0FBVTtBQUFBO0FBQUEsb0JBUEwsUUFBUUgsQ0FBQztBQUFBLG9CQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVE2QjtBQUFBLGdCQUdqQyxDQUFDO0FBQUEsZ0JBR0QsdUJBQUMsVUFDQztBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaLGNBQWE7QUFBQSxvQkFDYixNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLFFBQU87QUFBQSxvQkFFUDtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxRQUFPO0FBQUEsd0JBQ1AsV0FBVTtBQUFBO0FBQUEsc0JBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUV1QjtBQUFBO0FBQUEsa0JBVnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBY0E7QUFBQSxnQkFHQzhCLGNBQWNaLElBQUksQ0FBQ3ZELFNBQVM7QUFDM0Isd0JBQU13RixNQUFNbkIsT0FBT3RDLFVBQVU1QixJQUFJSCxLQUFLUSxFQUFZO0FBQ2xELHNCQUFJLENBQUNnRixJQUFLLFFBQU87QUFDakIsd0JBQU1DLFlBQVk1QyxnQkFBaUI3QyxLQUFLUTtBQUN4Qyx3QkFBTWtGLGNBQWN6RyxjQUFjZSxLQUFLMkQsTUFBTSxLQUFLO0FBRWxELHlCQUNFO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUVDLFNBQVMsTUFBTWhCLGVBQWUzQyxLQUFLUSxFQUFpQjtBQUFBLHNCQUNwRCxjQUFjLE1BQU1zQyxlQUFlOUMsS0FBS1EsRUFBWTtBQUFBLHNCQUNwRCxjQUFjLE1BQU1zQyxlQUFlLElBQUk7QUFBQSxzQkFDdkMsT0FBTyxFQUFFNkMsUUFBUSxVQUFVO0FBQUEsc0JBRTNCO0FBQUE7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsR0FBR0gsSUFBSXBEO0FBQUFBLDRCQUNQLEdBQUdvRCxJQUFJbEQ7QUFBQUEsNEJBQ1AsT0FBTytCLE9BQU85QjtBQUFBQSw0QkFDZCxRQUFROEIsT0FBTzdCO0FBQUFBLDRCQUNmLElBQUk7QUFBQSw0QkFDSixJQUFJO0FBQUEsNEJBQ0osT0FBTztBQUFBLDhCQUNMb0QsTUFBTUgsWUFBWSwyQkFBMkI7QUFBQSw4QkFDN0NJLFFBQVFIO0FBQUFBLDhCQUNSSSxhQUFhTCxZQUFZLElBQUk7QUFBQSw0QkFDL0I7QUFBQTtBQUFBLDBCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFXSTtBQUFBLHdCQUdKO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLEdBQUdELElBQUlwRDtBQUFBQSw0QkFDUCxHQUFHb0QsSUFBSWxEO0FBQUFBLDRCQUNQLE9BQU87QUFBQSw0QkFDUCxRQUFRK0IsT0FBTzdCO0FBQUFBLDRCQUNmLElBQUk7QUFBQSw0QkFDSixPQUFPLEVBQUVvRCxNQUFNRixZQUFZO0FBQUE7QUFBQSwwQkFON0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQU0rQjtBQUFBLHdCQUcvQjtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxHQUFHRixJQUFJcEQsSUFBSTtBQUFBLDRCQUNYLEdBQUdvRCxJQUFJbEQsSUFBSTtBQUFBLDRCQUNYLFdBQVU7QUFBQSw0QkFDVixVQUFVO0FBQUEsNEJBQ1YsWUFBWTtBQUFBLDRCQUVWdEMsZUFBSzBELE1BQWlCMUMsU0FBUyxLQUM1QmhCLEtBQUswRCxNQUFpQnFDLE1BQU0sR0FBRyxFQUFFLElBQUksUUFDckMvRixLQUFLMEQ7QUFBQUE7QUFBQUEsMEJBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVVBO0FBQUEsd0JBRUE7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsR0FBRzhCLElBQUlwRCxJQUFJO0FBQUEsNEJBQ1gsR0FBR29ELElBQUlsRCxJQUFJO0FBQUEsNEJBQ1gsV0FBVTtBQUFBLDRCQUNWLFVBQVU7QUFBQSw0QkFFVHRDO0FBQUFBLG1DQUFLMkQ7QUFBQUEsOEJBQU87QUFBQSw4QkFBSTNELEtBQUs0RDtBQUFBQSw4QkFBSztBQUFBLDhCQUFLNUQsS0FBSzZEO0FBQUFBO0FBQUFBO0FBQUFBLDBCQU52QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBT0E7QUFBQTtBQUFBO0FBQUEsb0JBaERLN0QsS0FBS1E7QUFBQUEsb0JBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFrREE7QUFBQSxnQkFFSixDQUFDO0FBQUE7QUFBQTtBQUFBLFlBM0dIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQTRHQSxLQTdHRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThHQTtBQUFBLGFBbkhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvSEE7QUFBQSxRQUVBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHNDQUFxQyxpQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUU7QUFBQSxVQUNyRSx1QkFBQyxTQUFJLFdBQVUsbUVBQ2I7QUFBQSxtQ0FBQyxPQUFFLG9LQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVKO0FBQUEsWUFDdkosdUJBQUMsT0FBRSw4SEFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpSDtBQUFBLGVBRm5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx1REFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSw0Q0FBMkMsc0JBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdFO0FBQUEsWUFDaEUsdUJBQUMsU0FBSSxXQUFVLDZCQUNadUUsaUJBQU9DLFFBQVEvRixhQUFhLEVBQUVzRTtBQUFBQSxjQUFJLENBQUMsQ0FBQ0ksUUFBUXFDLEtBQUssTUFDaEQsdUJBQUMsU0FBaUIsV0FBVSw2QkFDMUI7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsT0FBTyxFQUFFQyxZQUFZRCxNQUFNO0FBQUE7QUFBQSxrQkFGN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUUrQjtBQUFBLGdCQUUvQix1QkFBQyxVQUFLLFdBQVUsMEJBQTBCckMsb0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlEO0FBQUEsbUJBTHpDQSxRQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUE7QUFBQSxZQUNELEtBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLGVBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLGFBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxXQTNJQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNElBO0FBQUEsU0FwTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFOQTtBQUFBLE9Bak9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrT0E7QUFFSjtBQUFDZixHQWhUZUgsZ0JBQWM7QUFBQSxVQUlWaEUsVUFJSkEsUUFBUTtBQUFBO0FBQUEsS0FSUmdFO0FBQWMsSUFBQXlEO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlTWVtbyIsInVzZVF1ZXJ5IiwiYXBpIiwiY24iLCJQYWdlSGVhZGVyIiwiQ2FyZCIsIlN0YXR1c0JhZGdlIiwiTWV0cmljQmxvY2siLCJHaXRCcmFuY2giLCJTVEFUVVNfQ09MT1JTIiwiSU5CT1giLCJBU1NJR05FRCIsIklOX1BST0dSRVNTIiwiUkVWSUVXIiwiTkVFRFNfQVBQUk9WQUwiLCJCTE9DS0VEIiwiRkFJTEVEIiwiRE9ORSIsIkNBTkNFTEVEIiwibGF5b3V0Tm9kZXMiLCJub2RlcyIsImVkZ2VzIiwic3VidGFza3NPZiIsIk1hcCIsIm5vZGUiLCJwYXJlbnRUYXNrSWQiLCJsaXN0IiwiZ2V0IiwicHVzaCIsInNldCIsImluRGVncmVlIiwiYWRqTGlzdCIsImlkIiwiZWRnZSIsImV4aXN0aW5nIiwidG8iLCJmcm9tIiwibGF5ZXJzIiwicXVldWUiLCJkZWciLCJsZW5ndGgiLCJjdXJyZW50Iiwic2hpZnQiLCJjdXJyZW50TGF5ZXIiLCJuZWlnaGJvciIsIm5ld0RlZyIsIk1hdGgiLCJtYXgiLCJsYXllckdyb3VwcyIsImxheWVyIiwiaGFzIiwiTk9ERV9XIiwiTk9ERV9IIiwiSF9HQVAiLCJWX0dBUCIsInBvc2l0aW9ucyIsIm1heExheWVyIiwiQXJyYXkiLCJrZXlzIiwiZ3JvdXAiLCJ4IiwiaSIsInkiLCJub2RlV2lkdGgiLCJub2RlSGVpZ2h0IiwiTWlzc2lvbkRBR1ZpZXciLCJwcm9qZWN0SWQiLCJvblRhc2tTZWxlY3QiLCJfcyIsImhvdmVyZWROb2RlIiwic2V0SG92ZXJlZE5vZGUiLCJmaWx0ZXIiLCJzZXRGaWx0ZXIiLCJncmFwaERhdGEiLCJjb29yZGluYXRvciIsImdldERlcGVuZGVuY3lHcmFwaCIsInRhc2tzIiwibGlzdEFsbCIsIm1ldHJpY3MiLCJtYXAiLCJ0IiwiX2lkIiwidGl0bGUiLCJzdGF0dXMiLCJ0eXBlIiwicHJpb3JpdHkiLCJhc3NpZ25lZUlkcyIsImRlcHRoIiwibWF4aW11bVdpZHRoIiwicmVhZHlDb3VudCIsImN5Y2xpY05vZGVDb3VudCIsImZpbHRlcmVkTm9kZXMiLCJuIiwibGF5b3V0IiwiZSIsInBvc2l0aW9uZWROb2RlcyIsInZhbHVlcyIsImNhbnZhc1dpZHRoIiwicCIsImNhbnZhc0hlaWdodCIsInN0YXR1c0NvdW50cyIsImNvdW50cyIsImJsb2NrZWRDb3VudCIsIk9iamVjdCIsImVudHJpZXMiLCJjb3VudCIsImZyb21Qb3MiLCJ0b1BvcyIsIngxIiwieTEiLCJ4MiIsInkyIiwicG9zIiwiaXNIb3ZlcmVkIiwic3RhdHVzQ29sb3IiLCJjdXJzb3IiLCJmaWxsIiwic3Ryb2tlIiwic3Ryb2tlV2lkdGgiLCJzbGljZSIsImNvbG9yIiwiYmFja2dyb3VuZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1pc3Npb25EQUdWaWV3LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIE1pc3Npb24gREFHIFZpZXdcbiAqXG4gKiBWaXN1YWxpemVzIHRhc2sgZGVwZW5kZW5jaWVzIGFzIGEgZGlyZWN0ZWQgYWN5Y2xpYyBncmFwaCAoREFHKS5cbiAqIFRhc2tzIGFyZSBub2RlcywgZGVwZW5kZW5jaWVzIGFyZSBlZGdlcy5cbiAqIENvbG9yLWNvZGVkIGJ5IHN0YXR1cywgd2l0aCBjcml0aWNhbCBwYXRoIGhpZ2hsaWdodGluZy5cbiAqL1xuXG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcbmltcG9ydCB7IFBhZ2VIZWFkZXIgfSBmcm9tIFwiLi9jb21wb25lbnRzL1BhZ2VIZWFkZXJcIjtcbmltcG9ydCB7IENhcmQgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2NhcmRcIjtcbmltcG9ydCB7IFN0YXR1c0JhZGdlIH0gZnJvbSBcIkAvY29tcG9uZW50cy9mYWN0b3J5L2JhZGdlc1wiO1xuaW1wb3J0IHsgTWV0cmljQmxvY2sgfSBmcm9tIFwiQC9jb21wb25lbnRzL2ZhY3RvcnkvTWV0cmljQmxvY2tcIjtcbmltcG9ydCB7IEdpdEJyYW5jaCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcblxuaW50ZXJmYWNlIE1pc3Npb25EQUdWaWV3UHJvcHMge1xuICBwcm9qZWN0SWQ6IElkPFwicHJvamVjdHNcIj4gfCBudWxsO1xuICBvblRhc2tTZWxlY3Q/OiAodGFza0lkOiBJZDxcInRhc2tzXCI+KSA9PiB2b2lkO1xufVxuXG5jb25zdCBTVEFUVVNfQ09MT1JTOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICBJTkJPWDogXCIjNjQ3NDhiXCIsXG4gIEFTU0lHTkVEOiBcIiMyNTYzZWJcIixcbiAgSU5fUFJPR1JFU1M6IFwiIzNiODJmNlwiLFxuICBSRVZJRVc6IFwiI2Y1OWUwYlwiLFxuICBORUVEU19BUFBST1ZBTDogXCIjZjk3MzE2XCIsXG4gIEJMT0NLRUQ6IFwiI2VmNDQ0NFwiLFxuICBGQUlMRUQ6IFwiI2RjMjYyNlwiLFxuICBET05FOiBcIiMxMGI5ODFcIixcbiAgQ0FOQ0VMRUQ6IFwiIzQ3NTU2OVwiLFxufTtcblxuLyoqIFNpbXBsZSBsYXlvdXQ6IGFzc2lnbnMgeC95IHBvc2l0aW9ucyB0byBub2RlcyBpbiBsYXllcnMgKi9cbmZ1bmN0aW9uIGxheW91dE5vZGVzKFxuICBub2RlczogQXJyYXk8eyBpZDogc3RyaW5nOyBwYXJlbnRUYXNrSWQ/OiBzdHJpbmc7IHN0YXR1czogc3RyaW5nIH0+LFxuICBlZGdlczogQXJyYXk8eyBmcm9tOiBzdHJpbmc7IHRvOiBzdHJpbmcgfT5cbikge1xuICBjb25zdCBzdWJ0YXNrc09mID0gbmV3IE1hcDxzdHJpbmcsIHR5cGVvZiBub2Rlcz4oKTtcblxuICBmb3IgKGNvbnN0IG5vZGUgb2Ygbm9kZXMpIHtcbiAgICBpZiAobm9kZS5wYXJlbnRUYXNrSWQpIHtcbiAgICAgIGNvbnN0IGxpc3QgPSBzdWJ0YXNrc09mLmdldChub2RlLnBhcmVudFRhc2tJZCkgPz8gW107XG4gICAgICBsaXN0LnB1c2gobm9kZSk7XG4gICAgICBzdWJ0YXNrc09mLnNldChub2RlLnBhcmVudFRhc2tJZCwgbGlzdCk7XG4gICAgfVxuICB9XG5cbiAgY29uc3QgaW5EZWdyZWUgPSBuZXcgTWFwPHN0cmluZywgbnVtYmVyPigpO1xuICBjb25zdCBhZGpMaXN0ID0gbmV3IE1hcDxzdHJpbmcsIHN0cmluZ1tdPigpO1xuICBmb3IgKGNvbnN0IG5vZGUgb2Ygbm9kZXMpIHtcbiAgICBpbkRlZ3JlZS5zZXQobm9kZS5pZCwgMCk7XG4gICAgYWRqTGlzdC5zZXQobm9kZS5pZCwgW10pO1xuICB9XG4gIGZvciAoY29uc3QgZWRnZSBvZiBlZGdlcykge1xuICAgIGNvbnN0IGV4aXN0aW5nID0gYWRqTGlzdC5nZXQoZWRnZS50bykgPz8gW107XG4gICAgZXhpc3RpbmcucHVzaChlZGdlLmZyb20pO1xuICAgIGFkakxpc3Quc2V0KGVkZ2UudG8sIGV4aXN0aW5nKTtcbiAgICBpbkRlZ3JlZS5zZXQoZWRnZS5mcm9tLCAoaW5EZWdyZWUuZ2V0KGVkZ2UuZnJvbSkgPz8gMCkgKyAxKTtcbiAgfVxuXG4gIGNvbnN0IGxheWVycyA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KCk7XG4gIGNvbnN0IHF1ZXVlOiBzdHJpbmdbXSA9IFtdO1xuICBmb3IgKGNvbnN0IFtpZCwgZGVnXSBvZiBpbkRlZ3JlZSkge1xuICAgIGlmIChkZWcgPT09IDApIHtcbiAgICAgIHF1ZXVlLnB1c2goaWQpO1xuICAgICAgbGF5ZXJzLnNldChpZCwgMCk7XG4gICAgfVxuICB9XG5cbiAgd2hpbGUgKHF1ZXVlLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBjdXJyZW50ID0gcXVldWUuc2hpZnQoKSE7XG4gICAgY29uc3QgY3VycmVudExheWVyID0gbGF5ZXJzLmdldChjdXJyZW50KSA/PyAwO1xuICAgIGZvciAoY29uc3QgbmVpZ2hib3Igb2YgYWRqTGlzdC5nZXQoY3VycmVudCkgPz8gW10pIHtcbiAgICAgIGNvbnN0IG5ld0RlZyA9IChpbkRlZ3JlZS5nZXQobmVpZ2hib3IpID8/IDEpIC0gMTtcbiAgICAgIGluRGVncmVlLnNldChuZWlnaGJvciwgbmV3RGVnKTtcbiAgICAgIGxheWVycy5zZXQobmVpZ2hib3IsIE1hdGgubWF4KGxheWVycy5nZXQobmVpZ2hib3IpID8/IDAsIGN1cnJlbnRMYXllciArIDEpKTtcbiAgICAgIGlmIChuZXdEZWcgPT09IDApIHtcbiAgICAgICAgcXVldWUucHVzaChuZWlnaGJvcik7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgY29uc3QgbGF5ZXJHcm91cHMgPSBuZXcgTWFwPG51bWJlciwgc3RyaW5nW10+KCk7XG4gIGZvciAoY29uc3QgW2lkLCBsYXllcl0gb2YgbGF5ZXJzKSB7XG4gICAgY29uc3QgbGlzdCA9IGxheWVyR3JvdXBzLmdldChsYXllcikgPz8gW107XG4gICAgbGlzdC5wdXNoKGlkKTtcbiAgICBsYXllckdyb3Vwcy5zZXQobGF5ZXIsIGxpc3QpO1xuICB9XG5cbiAgZm9yIChjb25zdCBub2RlIG9mIG5vZGVzKSB7XG4gICAgaWYgKCFsYXllcnMuaGFzKG5vZGUuaWQpKSB7XG4gICAgICBsYXllcnMuc2V0KG5vZGUuaWQsIDApO1xuICAgICAgY29uc3QgbGlzdCA9IGxheWVyR3JvdXBzLmdldCgwKSA/PyBbXTtcbiAgICAgIGxpc3QucHVzaChub2RlLmlkKTtcbiAgICAgIGxheWVyR3JvdXBzLnNldCgwLCBsaXN0KTtcbiAgICB9XG4gIH1cblxuICBjb25zdCBOT0RFX1cgPSAyNDA7XG4gIGNvbnN0IE5PREVfSCA9IDYwO1xuICBjb25zdCBIX0dBUCA9IDgwO1xuICBjb25zdCBWX0dBUCA9IDMwO1xuXG4gIGNvbnN0IHBvc2l0aW9ucyA9IG5ldyBNYXA8c3RyaW5nLCB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0+KCk7XG4gIGNvbnN0IG1heExheWVyID0gTWF0aC5tYXgoLi4uQXJyYXkuZnJvbShsYXllckdyb3Vwcy5rZXlzKCkpLCAwKTtcblxuICBmb3IgKGxldCBsYXllciA9IDA7IGxheWVyIDw9IG1heExheWVyOyBsYXllcisrKSB7XG4gICAgY29uc3QgZ3JvdXAgPSBsYXllckdyb3Vwcy5nZXQobGF5ZXIpID8/IFtdO1xuICAgIGNvbnN0IHggPSBsYXllciAqIChOT0RFX1cgKyBIX0dBUCkgKyA0MDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGdyb3VwLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCB5ID0gaSAqIChOT0RFX0ggKyBWX0dBUCkgKyA0MDtcbiAgICAgIHBvc2l0aW9ucy5zZXQoZ3JvdXBbaV0sIHsgeCwgeSB9KTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4geyBwb3NpdGlvbnMsIG5vZGVXaWR0aDogTk9ERV9XLCBub2RlSGVpZ2h0OiBOT0RFX0ggfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIE1pc3Npb25EQUdWaWV3KHsgcHJvamVjdElkLCBvblRhc2tTZWxlY3QgfTogTWlzc2lvbkRBR1ZpZXdQcm9wcykge1xuICBjb25zdCBbaG92ZXJlZE5vZGUsIHNldEhvdmVyZWROb2RlXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbZmlsdGVyLCBzZXRGaWx0ZXJdID0gdXNlU3RhdGU8c3RyaW5nPihcImFsbFwiKTtcblxuICBjb25zdCBncmFwaERhdGEgPSB1c2VRdWVyeShcbiAgICBhcGkuY29vcmRpbmF0b3IuZ2V0RGVwZW5kZW5jeUdyYXBoLFxuICAgIHByb2plY3RJZCA/IHsgcHJvamVjdElkIH0gOiB7fVxuICApO1xuICBjb25zdCB0YXNrcyA9IHVzZVF1ZXJ5KGFwaS50YXNrcy5saXN0QWxsLCBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCB9IDoge30pO1xuXG4gIGNvbnN0IHsgbm9kZXMsIGVkZ2VzLCBtZXRyaWNzIH0gPSB1c2VNZW1vKCgpID0+IHtcbiAgICBpZiAoZ3JhcGhEYXRhKSB7XG4gICAgICByZXR1cm4gZ3JhcGhEYXRhO1xuICAgIH1cbiAgICBpZiAodGFza3MpIHtcbiAgICAgIGNvbnN0IG5vZGVzID0gdGFza3MubWFwKCh0KSA9PiAoe1xuICAgICAgICBpZDogdC5faWQgYXMgc3RyaW5nLFxuICAgICAgICB0aXRsZTogdC50aXRsZSxcbiAgICAgICAgc3RhdHVzOiB0LnN0YXR1cyxcbiAgICAgICAgdHlwZTogdC50eXBlLFxuICAgICAgICBwcmlvcml0eTogdC5wcmlvcml0eSxcbiAgICAgICAgYXNzaWduZWVJZHM6IHQuYXNzaWduZWVJZHMsXG4gICAgICAgIHBhcmVudFRhc2tJZDogdC5wYXJlbnRUYXNrSWQgYXMgc3RyaW5nIHwgdW5kZWZpbmVkLFxuICAgICAgfSkpO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbm9kZXMsXG4gICAgICAgIGVkZ2VzOiBbXSxcbiAgICAgICAgbWV0cmljczogeyBkZXB0aDogbm9kZXMubGVuZ3RoID4gMCA/IDEgOiAwLCBtYXhpbXVtV2lkdGg6IG5vZGVzLmxlbmd0aCwgcmVhZHlDb3VudDogMCwgY3ljbGljTm9kZUNvdW50OiAwIH0sXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgbm9kZXM6IFtdLFxuICAgICAgZWRnZXM6IFtdLFxuICAgICAgbWV0cmljczogeyBkZXB0aDogMCwgbWF4aW11bVdpZHRoOiAwLCByZWFkeUNvdW50OiAwLCBjeWNsaWNOb2RlQ291bnQ6IDAgfSxcbiAgICB9O1xuICB9LCBbZ3JhcGhEYXRhLCB0YXNrc10pO1xuXG4gIGNvbnN0IGZpbHRlcmVkTm9kZXMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBpZiAoZmlsdGVyID09PSBcImFsbFwiKSByZXR1cm4gbm9kZXM7XG4gICAgcmV0dXJuIG5vZGVzLmZpbHRlcigobikgPT4gbi5zdGF0dXMgPT09IGZpbHRlcik7XG4gIH0sIFtub2RlcywgZmlsdGVyXSk7XG5cbiAgY29uc3QgbGF5b3V0ID0gdXNlTWVtbyhcbiAgICAoKSA9PlxuICAgICAgbGF5b3V0Tm9kZXMoXG4gICAgICAgIGZpbHRlcmVkTm9kZXMubWFwKChuKSA9PiAoe1xuICAgICAgICAgIGlkOiBuLmlkIGFzIHN0cmluZyxcbiAgICAgICAgICBwYXJlbnRUYXNrSWQ6IG4ucGFyZW50VGFza0lkIGFzIHN0cmluZyB8IHVuZGVmaW5lZCxcbiAgICAgICAgICBzdGF0dXM6IG4uc3RhdHVzLFxuICAgICAgICB9KSksXG4gICAgICAgIGVkZ2VzLm1hcCgoZSkgPT4gKHsgZnJvbTogZS5mcm9tIGFzIHN0cmluZywgdG86IGUudG8gYXMgc3RyaW5nIH0pKVxuICAgICAgKSxcbiAgICBbZmlsdGVyZWROb2RlcywgZWRnZXNdXG4gICk7XG5cbiAgY29uc3QgcG9zaXRpb25lZE5vZGVzID0gQXJyYXkuZnJvbShsYXlvdXQucG9zaXRpb25zLnZhbHVlcygpKSBhcyBBcnJheTx7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0+O1xuXG4gIGNvbnN0IGNhbnZhc1dpZHRoID0gTWF0aC5tYXgoXG4gICAgODAwLFxuICAgIC4uLnBvc2l0aW9uZWROb2Rlcy5tYXAoKHApID0+IHAueCArIGxheW91dC5ub2RlV2lkdGggKyA0MClcbiAgKTtcbiAgY29uc3QgY2FudmFzSGVpZ2h0ID0gTWF0aC5tYXgoXG4gICAgNDAwLFxuICAgIC4uLnBvc2l0aW9uZWROb2Rlcy5tYXAoKHApID0+IHAueSArIGxheW91dC5ub2RlSGVpZ2h0ICsgNDApXG4gICk7XG5cbiAgY29uc3Qgc3RhdHVzQ291bnRzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgY29uc3QgY291bnRzOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+ID0ge307XG4gICAgZm9yIChjb25zdCBuIG9mIG5vZGVzKSB7XG4gICAgICBjb3VudHNbbi5zdGF0dXNdID0gKGNvdW50c1tuLnN0YXR1c10gPz8gMCkgKyAxO1xuICAgIH1cbiAgICByZXR1cm4gY291bnRzO1xuICB9LCBbbm9kZXNdKTtcbiAgY29uc3QgYmxvY2tlZENvdW50ID0gc3RhdHVzQ291bnRzLkJMT0NLRUQgPz8gMDtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImZsZXggbWluLWgtMCBmbGV4LTEgZmxleC1jb2wgb3ZlcmZsb3ctaGlkZGVuIGJnLWFwcFwiPlxuICAgICAgPFBhZ2VIZWFkZXJcbiAgICAgICAgdGl0bGU9XCJNaXNzaW9uIERBR1wiXG4gICAgICAgIGRlc2NyaXB0aW9uPVwiVmlzdWFsaXplIGRlcGVuZGVuY3kgc3RydWN0dXJlLCBzZXF1ZW5jaW5nLCBhbmQgYmxvY2tlcnMgYWNyb3NzIHRoZSBtaXNzaW9uIGdyYXBoLlwiXG4gICAgICAgIGljb249ezxHaXRCcmFuY2ggY2xhc3NOYW1lPVwiaC00LjUgdy00LjVcIiBzdHJva2VXaWR0aD17MS43fSAvPn1cbiAgICAgICAgZXllYnJvdz1cIk9wZXJhdGlvbnNcIlxuICAgICAgICBzdGF0dXM9e1xuICAgICAgICAgIDxTdGF0dXNCYWRnZSB0b25lPVwibmV1dHJhbFwiPlxuICAgICAgICAgICAge25vZGVzLmxlbmd0aH0gdGFza3Mgwrcge2VkZ2VzLmxlbmd0aH0gZGVwZW5kZW5jaWVzXG4gICAgICAgICAgPC9TdGF0dXNCYWRnZT5cbiAgICAgICAgfVxuICAgICAgLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC0wIGZsZXgtMSBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW4gcHgtNiBwYi02IHB0LTQgZ2FwLTRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIHNocmluay0wIGdhcC00IG1kOmdyaWQtY29scy00XCI+XG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC00XCI+XG4gICAgICAgICAgICA8TWV0cmljQmxvY2tcbiAgICAgICAgICAgICAgbGFiZWw9XCJHcmFwaCBzaXplXCJcbiAgICAgICAgICAgICAgdmFsdWU9e25vZGVzLmxlbmd0aH1cbiAgICAgICAgICAgICAgZGV0YWlsPVwiVGFza3MgY3VycmVudGx5IHJlcHJlc2VudGVkIGluIHRoZSBkZXBlbmRlbmN5IGdyYXBoXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICAgICAgPE1ldHJpY0Jsb2NrXG4gICAgICAgICAgICAgIGxhYmVsPVwiRWRnZXNcIlxuICAgICAgICAgICAgICB2YWx1ZT17ZWRnZXMubGVuZ3RofVxuICAgICAgICAgICAgICBkZXRhaWw9XCJFeHBsaWNpdCBkZXBlbmRlbmNpZXMgc2hhcGluZyBleGVjdXRpb24gb3JkZXJcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC00XCI+XG4gICAgICAgICAgICA8TWV0cmljQmxvY2tcbiAgICAgICAgICAgICAgbGFiZWw9XCJQYXJhbGxlbCB3aWR0aFwiXG4gICAgICAgICAgICAgIHZhbHVlPXttZXRyaWNzLm1heGltdW1XaWR0aH1cbiAgICAgICAgICAgICAgZGV0YWlsPXtgJHttZXRyaWNzLnJlYWR5Q291bnR9IG5vZGUocykgcmVhZHkgbm93IMK3ICR7bWV0cmljcy5kZXB0aH0gZGVwZW5kZW5jeSBsYXllcihzKWB9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTRcIj5cbiAgICAgICAgICAgIDxNZXRyaWNCbG9ja1xuICAgICAgICAgICAgICBsYWJlbD1cIkJsb2NrZWRcIlxuICAgICAgICAgICAgICB2YWx1ZT17YmxvY2tlZENvdW50ICsgbWV0cmljcy5jeWNsaWNOb2RlQ291bnR9XG4gICAgICAgICAgICAgIGRldGFpbD17XG4gICAgICAgICAgICAgICAgbWV0cmljcy5jeWNsaWNOb2RlQ291bnQgPiAwXG4gICAgICAgICAgICAgICAgICA/IGAke21ldHJpY3MuY3ljbGljTm9kZUNvdW50fSBub2RlKHMpIGFyZSBwYXJ0IG9mIGFuIGludmFsaWQgZGVwZW5kZW5jeSBjeWNsZWBcbiAgICAgICAgICAgICAgICAgIDogXCJOb2RlcyBjdXJyZW50bHkgYnJlYWtpbmcgZmxvdyB0aHJvdWdoIHRoZSBncmFwaFwiXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9DYXJkPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaHJpbmstMCBwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBvdmVyZmxvdy14LWF1dG8gZmxleC1ub3dyYXBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+R3JhcGggZmlsdGVyczwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgdGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZFwiPkZvY3VzIHRoZSBkZXBlbmRlbmN5IG1hcCBieSB0YXNrIHN0YXRlPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBzaHJpbmstMCBnYXAtMSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBwLTAuNVwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgIFwicm91bmRlZC1tZCBweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiLFxuICAgICAgICAgICAgICAgICAgZmlsdGVyID09PSBcImFsbFwiXG4gICAgICAgICAgICAgICAgICAgID8gXCJiZy1zdXJmYWNlLTIgdGV4dC1pbmtcIlxuICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1pbmstc2Vjb25kYXJ5IGhvdmVyOnRleHQtaW5rXCJcbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZpbHRlcihcImFsbFwiKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIEFsbCAoe25vZGVzLmxlbmd0aH0pXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICB7KE9iamVjdC5lbnRyaWVzKHN0YXR1c0NvdW50cykgYXMgQXJyYXk8W3N0cmluZywgbnVtYmVyXT4pLm1hcCgoW3N0YXR1cywgY291bnRdKSA9PiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAga2V5PXtzdGF0dXN9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICBcInJvdW5kZWQtbWQgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIixcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyID09PSBzdGF0dXNcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctc3VyZmFjZS0yIHRleHQtaW5rXCJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1pbmstc2Vjb25kYXJ5IGhvdmVyOnRleHQtaW5rXCJcbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRGaWx0ZXIoZmlsdGVyID09PSBzdGF0dXMgPyBcImFsbFwiIDogc3RhdHVzKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7c3RhdHVzfSAoe2NvdW50fSlcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9DYXJkPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBtaW4taC0wIGZsZXgtMSBnYXAtNCB4bDpncmlkLWNvbHMtW21pbm1heCgwLDFmcilfMzIwcHhdXCI+XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cImZsZXggbWluLWgtMCBmbGV4LTEgZmxleC1jb2wgb3ZlcmZsb3ctaGlkZGVuIHAtMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2hyaW5rLTAgYm9yZGVyLWIgYm9yZGVyLWxpbmUgcHgtNSBweS00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzE1cHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj5EZXBlbmRlbmN5IGNhbnZhczwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIHRleHQtWzEyLjVweF0gdGV4dC1pbmstbXV0ZWRcIj5SZWFkIGRvd25zdHJlYW0gcmVsYXRpb25zaGlwcyBiZWZvcmUgY2hhbmdpbmcgdGFzayBzZXF1ZW5jaW5nPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC0wIGZsZXgtMSBvdmVyZmxvdy1hdXRvIGJnLWFwcFwiPlxuICAgICAgICA8c3ZnXG4gICAgICAgICAgd2lkdGg9e2NhbnZhc1dpZHRofVxuICAgICAgICAgIGhlaWdodD17Y2FudmFzSGVpZ2h0fVxuICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXRyYW5zcGFyZW50XCJcbiAgICAgICAgPlxuICAgICAgICAgIHsvKiBFZGdlcyAqL31cbiAgICAgICAgICB7ZWRnZXMubWFwKChlZGdlLCBpKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBmcm9tUG9zID0gbGF5b3V0LnBvc2l0aW9ucy5nZXQoZWRnZS5mcm9tIGFzIHN0cmluZyk7XG4gICAgICAgICAgICBjb25zdCB0b1BvcyA9IGxheW91dC5wb3NpdGlvbnMuZ2V0KGVkZ2UudG8gYXMgc3RyaW5nKTtcbiAgICAgICAgICAgIGlmICghZnJvbVBvcyB8fCAhdG9Qb3MpIHJldHVybiBudWxsO1xuXG4gICAgICAgICAgICBjb25zdCB4MSA9IHRvUG9zLnggKyBsYXlvdXQubm9kZVdpZHRoO1xuICAgICAgICAgICAgY29uc3QgeTEgPSB0b1Bvcy55ICsgbGF5b3V0Lm5vZGVIZWlnaHQgLyAyO1xuICAgICAgICAgICAgY29uc3QgeDIgPSBmcm9tUG9zLng7XG4gICAgICAgICAgICBjb25zdCB5MiA9IGZyb21Qb3MueSArIGxheW91dC5ub2RlSGVpZ2h0IC8gMjtcblxuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGxpbmVcbiAgICAgICAgICAgICAgICBrZXk9e2BlZGdlLSR7aX1gfVxuICAgICAgICAgICAgICAgIHgxPXt4MX1cbiAgICAgICAgICAgICAgICB5MT17eTF9XG4gICAgICAgICAgICAgICAgeDI9e3gyfVxuICAgICAgICAgICAgICAgIHkyPXt5Mn1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzdHJva2UtbGluZVwiXG4gICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezEuNX1cbiAgICAgICAgICAgICAgICBtYXJrZXJFbmQ9XCJ1cmwoI2Fycm93aGVhZClcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9KX1cblxuICAgICAgICAgIHsvKiBBcnJvdyBtYXJrZXIgKi99XG4gICAgICAgICAgPGRlZnM+XG4gICAgICAgICAgICA8bWFya2VyXG4gICAgICAgICAgICAgIGlkPVwiYXJyb3doZWFkXCJcbiAgICAgICAgICAgICAgbWFya2VyV2lkdGg9XCIxMFwiXG4gICAgICAgICAgICAgIG1hcmtlckhlaWdodD1cIjdcIlxuICAgICAgICAgICAgICByZWZYPVwiMTBcIlxuICAgICAgICAgICAgICByZWZZPVwiMy41XCJcbiAgICAgICAgICAgICAgb3JpZW50PVwiYXV0b1wiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxwb2x5Z29uXG4gICAgICAgICAgICAgICAgcG9pbnRzPVwiMCAwLCAxMCAzLjUsIDAgN1wiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmlsbC1saW5lXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvbWFya2VyPlxuICAgICAgICAgIDwvZGVmcz5cblxuICAgICAgICAgIHsvKiBOb2RlcyAqL31cbiAgICAgICAgICB7ZmlsdGVyZWROb2Rlcy5tYXAoKG5vZGUpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHBvcyA9IGxheW91dC5wb3NpdGlvbnMuZ2V0KG5vZGUuaWQgYXMgc3RyaW5nKTtcbiAgICAgICAgICAgIGlmICghcG9zKSByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIGNvbnN0IGlzSG92ZXJlZCA9IGhvdmVyZWROb2RlID09PSAobm9kZS5pZCBhcyBzdHJpbmcpO1xuICAgICAgICAgICAgY29uc3Qgc3RhdHVzQ29sb3IgPSBTVEFUVVNfQ09MT1JTW25vZGUuc3RhdHVzXSA/PyBcIiM2NDc0OGJcIjtcblxuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGdcbiAgICAgICAgICAgICAgICBrZXk9e25vZGUuaWR9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25UYXNrU2VsZWN0Py4obm9kZS5pZCBhcyBJZDxcInRhc2tzXCI+KX1cbiAgICAgICAgICAgICAgICBvbk1vdXNlRW50ZXI9eygpID0+IHNldEhvdmVyZWROb2RlKG5vZGUuaWQgYXMgc3RyaW5nKX1cbiAgICAgICAgICAgICAgICBvbk1vdXNlTGVhdmU9eygpID0+IHNldEhvdmVyZWROb2RlKG51bGwpfVxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGN1cnNvcjogXCJwb2ludGVyXCIgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxyZWN0XG4gICAgICAgICAgICAgICAgICB4PXtwb3MueH1cbiAgICAgICAgICAgICAgICAgIHk9e3Bvcy55fVxuICAgICAgICAgICAgICAgICAgd2lkdGg9e2xheW91dC5ub2RlV2lkdGh9XG4gICAgICAgICAgICAgICAgICBoZWlnaHQ9e2xheW91dC5ub2RlSGVpZ2h0fVxuICAgICAgICAgICAgICAgICAgcng9ezh9XG4gICAgICAgICAgICAgICAgICByeT17OH1cbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgIGZpbGw6IGlzSG92ZXJlZCA/IFwidmFyKC0tY29sb3Itc3VyZmFjZS0yKVwiIDogXCJ2YXIoLS1jb2xvci1zdXJmYWNlLTEpXCIsXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZTogc3RhdHVzQ29sb3IsXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoOiBpc0hvdmVyZWQgPyAyIDogMS41LFxuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIHsvKiBTdGF0dXMgaW5kaWNhdG9yIGJhciAqL31cbiAgICAgICAgICAgICAgICA8cmVjdFxuICAgICAgICAgICAgICAgICAgeD17cG9zLnh9XG4gICAgICAgICAgICAgICAgICB5PXtwb3MueX1cbiAgICAgICAgICAgICAgICAgIHdpZHRoPXs2fVxuICAgICAgICAgICAgICAgICAgaGVpZ2h0PXtsYXlvdXQubm9kZUhlaWdodH1cbiAgICAgICAgICAgICAgICAgIHJ4PXs4fVxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgZmlsbDogc3RhdHVzQ29sb3IgfX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIHsvKiBUaXRsZSAqL31cbiAgICAgICAgICAgICAgICA8dGV4dFxuICAgICAgICAgICAgICAgICAgeD17cG9zLnggKyAxNH1cbiAgICAgICAgICAgICAgICAgIHk9e3Bvcy55ICsgMjJ9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmaWxsLWlua1wiXG4gICAgICAgICAgICAgICAgICBmb250U2l6ZT17MTJ9XG4gICAgICAgICAgICAgICAgICBmb250V2VpZ2h0PXs2MDB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgeyhub2RlLnRpdGxlIGFzIHN0cmluZykubGVuZ3RoID4gMjhcbiAgICAgICAgICAgICAgICAgICAgPyAobm9kZS50aXRsZSBhcyBzdHJpbmcpLnNsaWNlKDAsIDI1KSArIFwiLi4uXCJcbiAgICAgICAgICAgICAgICAgICAgOiAobm9kZS50aXRsZSBhcyBzdHJpbmcpfVxuICAgICAgICAgICAgICAgIDwvdGV4dD5cbiAgICAgICAgICAgICAgICB7LyogU3RhdHVzICsgdHlwZSAqL31cbiAgICAgICAgICAgICAgICA8dGV4dFxuICAgICAgICAgICAgICAgICAgeD17cG9zLnggKyAxNH1cbiAgICAgICAgICAgICAgICAgIHk9e3Bvcy55ICsgNDJ9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmaWxsLWluay1tdXRlZFwiXG4gICAgICAgICAgICAgICAgICBmb250U2l6ZT17MTB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge25vZGUuc3RhdHVzfSDCtyB7bm9kZS50eXBlfSDCtyBQe25vZGUucHJpb3JpdHl9XG4gICAgICAgICAgICAgICAgPC90ZXh0PlxuICAgICAgICAgICAgICA8L2c+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pfVxuICAgICAgICA8L3N2Zz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9DYXJkPlxuXG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPk9wZXJhdG9yIGd1aWRhbmNlPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIHNwYWNlLXktMyB0ZXh0LVsxMy41cHhdIGxlYWRpbmctcmVsYXhlZCB0ZXh0LWluay1zZWNvbmRhcnlcIj5cbiAgICAgICAgICAgIDxwPlVzZSB0aGUgZ3JhcGggdG8gaW5zcGVjdCBzZXF1ZW5jaW5nIGJlZm9yZSB5b3UgY2hhbmdlIHRhc2sgb3duZXJzaGlwLiBBIG5vZGUgd2l0aCBtYW55IGluY29taW5nIGxpbmVzIHVzdWFsbHkgcmVwcmVzZW50cyBhIGNvb3JkaW5hdGlvbiBjaG9rZSBwb2ludC48L3A+XG4gICAgICAgICAgICA8cD5CbG9ja2VkIG5vZGVzIG1hdHRlciBtb3N0IHdoZW4gdGhleSBzaXQgZWFybHkgaW4gdGhlIGdyYXBoLiBDbGVhciB0aGVtIGJlZm9yZSBvcHRpbWl6aW5nIGxvd2VyLXZhbHVlIGJyYW5jaGVzLjwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yIHAtNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMS41cHhdIGZvbnQtbWVkaXVtIHRleHQtaW5rLW11dGVkXCI+TGVnZW5kPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZmxleCBnYXAtMyBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgICAge09iamVjdC5lbnRyaWVzKFNUQVRVU19DT0xPUlMpLm1hcCgoW3N0YXR1cywgY29sb3JdKSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e3N0YXR1c30gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTIgaC0yIHJvdW5kZWQtZnVsbFwiXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6IGNvbG9yIH19XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1pbmstbXV0ZWQgdGV4dC14c1wiPntzdGF0dXN9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9zZWN0aW9uPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvTWlzc2lvbkRBR1ZpZXcudHN4In0=