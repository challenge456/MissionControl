import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/separator.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/separator.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const React = ((m) => m?.__esModule ? m : { ...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {}, default: m })(__vite__cjsImport3_react);
import * as SeparatorPrimitive from "/node_modules/.vite/deps/@radix-ui_react-separator.js?v=36aefbc5";
import { cn } from "/src/lib/utils.ts";
const Separator = React.forwardRef(
  _c = ({ className, orientation = "horizontal", decorative = true, ...props }, ref) => {
    const resolvedOrientation = orientation === "vertical" ? "vertical" : "horizontal";
    return /* @__PURE__ */ jsxDEV(
      SeparatorPrimitive.Root,
      {
        ref,
        decorative,
        orientation: resolvedOrientation,
        className: cn(
          "shrink-0 bg-border",
          resolvedOrientation === "horizontal" ? "h-[1px] w-full" : "h-full w-[1px]",
          className
        ),
        ...props
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/separator.tsx",
        lineNumber: 37,
        columnNumber: 5
      },
      this
    );
  }
);
_c2 = Separator;
Separator.displayName = SeparatorPrimitive.Root.displayName;
export { Separator };
var _c, _c2;
$RefreshReg$(_c, "Separator$React.forwardRef");
$RefreshReg$(_c2, "Separator");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/separator.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/separator.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJNOzs7Ozs7Ozs7Ozs7Ozs7O0FBakJOLFlBQVlBLFdBQVc7QUFDdkIsWUFBWUMsd0JBQXdCO0FBRXBDLFNBQVNDLFVBQVU7QUFFbkIsTUFBTUMsWUFBWUgsTUFBTUk7QUFBQUEsRUFHdkJDLEtBQ0NBLENBQ0UsRUFBRUMsV0FBV0MsY0FBYyxjQUFjQyxhQUFhLE1BQU0sR0FBR0MsTUFBTSxHQUNyRUMsUUFDRztBQUNILFVBQU1DLHNCQUNKSixnQkFBZ0IsYUFBYSxhQUFhO0FBRTVDLFdBQ0U7QUFBQSxNQUFDLG1CQUFtQjtBQUFBLE1BQW5CO0FBQUEsUUFDQztBQUFBLFFBQ0E7QUFBQSxRQUNBLGFBQWFJO0FBQUFBLFFBQ2IsV0FBV1Q7QUFBQUEsVUFDVDtBQUFBLFVBQ0FTLHdCQUF3QixlQUFlLG1CQUFtQjtBQUFBLFVBQzFETDtBQUFBQSxRQUNGO0FBQUEsUUFDQSxHQUFJRztBQUFBQTtBQUFBQSxNQVROO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVNZO0FBQUEsRUFHaEI7QUFDRjtBQUFDRyxNQXpCS1Q7QUEwQk5BLFVBQVVVLGNBQWNaLG1CQUFtQmEsS0FBS0Q7QUFFaEQsU0FBU1Y7QUFBVyxJQUFBRSxJQUFBTztBQUFBLGFBQUFQLElBQUE7QUFBQSxhQUFBTyxLQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJTZXBhcmF0b3JQcmltaXRpdmUiLCJjbiIsIlNlcGFyYXRvciIsImZvcndhcmRSZWYiLCJfYyIsImNsYXNzTmFtZSIsIm9yaWVudGF0aW9uIiwiZGVjb3JhdGl2ZSIsInByb3BzIiwicmVmIiwicmVzb2x2ZWRPcmllbnRhdGlvbiIsIl9jMiIsImRpc3BsYXlOYW1lIiwiUm9vdCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJzZXBhcmF0b3IudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiXG5pbXBvcnQgKiBhcyBTZXBhcmF0b3JQcmltaXRpdmUgZnJvbSBcIkByYWRpeC11aS9yZWFjdC1zZXBhcmF0b3JcIlxuXG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiXG5cbmNvbnN0IFNlcGFyYXRvciA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIFJlYWN0LkVsZW1lbnRSZWY8dHlwZW9mIFNlcGFyYXRvclByaW1pdGl2ZS5Sb290PixcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBTZXBhcmF0b3JQcmltaXRpdmUuUm9vdD5cbj4oXG4gIChcbiAgICB7IGNsYXNzTmFtZSwgb3JpZW50YXRpb24gPSBcImhvcml6b250YWxcIiwgZGVjb3JhdGl2ZSA9IHRydWUsIC4uLnByb3BzIH0sXG4gICAgcmVmXG4gICkgPT4ge1xuICAgIGNvbnN0IHJlc29sdmVkT3JpZW50YXRpb246IFwiaG9yaXpvbnRhbFwiIHwgXCJ2ZXJ0aWNhbFwiID1cbiAgICAgIG9yaWVudGF0aW9uID09PSBcInZlcnRpY2FsXCIgPyBcInZlcnRpY2FsXCIgOiBcImhvcml6b250YWxcIlxuXG4gICAgcmV0dXJuIChcbiAgICAgIDxTZXBhcmF0b3JQcmltaXRpdmUuUm9vdFxuICAgICAgICByZWY9e3JlZn1cbiAgICAgICAgZGVjb3JhdGl2ZT17ZGVjb3JhdGl2ZX1cbiAgICAgICAgb3JpZW50YXRpb249e3Jlc29sdmVkT3JpZW50YXRpb259XG4gICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgXCJzaHJpbmstMCBiZy1ib3JkZXJcIixcbiAgICAgICAgICByZXNvbHZlZE9yaWVudGF0aW9uID09PSBcImhvcml6b250YWxcIiA/IFwiaC1bMXB4XSB3LWZ1bGxcIiA6IFwiaC1mdWxsIHctWzFweF1cIixcbiAgICAgICAgICBjbGFzc05hbWVcbiAgICAgICAgKX1cbiAgICAgICAgey4uLnByb3BzfVxuICAgICAgLz5cbiAgICApXG4gIH1cbilcblNlcGFyYXRvci5kaXNwbGF5TmFtZSA9IFNlcGFyYXRvclByaW1pdGl2ZS5Sb290LmRpc3BsYXlOYW1lXG5cbmV4cG9ydCB7IFNlcGFyYXRvciB9XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9jb21wb25lbnRzL3VpL3NlcGFyYXRvci50c3gifQ==