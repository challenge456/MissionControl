import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/PolicyModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription
} from "/src/components/ui/dialog.tsx";
import { Badge } from "/src/components/ui/badge.tsx";
import { ScrollArea } from "/src/components/ui/scroll-area.tsx";
import { ShieldCheck, CheckCircle2, Globe, Layers } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { cn } from "/src/lib/utils.ts";
export function PolicyModal({ onClose }) {
  _s();
  const policies = useQuery(api.policy.listAll);
  const activePolicy = useQuery(api.policy.getActive);
  const active = activePolicy ?? policies?.find((p) => p.active);
  return /* @__PURE__ */ jsxDEV(Dialog, { open: true, onOpenChange: (open) => {
    if (!open) onClose();
  }, children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "sm:max-w-[560px] max-h-[88vh] flex flex-col gap-0 p-0 overflow-hidden", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { className: "px-6 pt-6 pb-4 border-b border-border shrink-0", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary", children: /* @__PURE__ */ jsxDEV(ShieldCheck, { className: "h-5 w-5" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
        lineNumber: 48,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
        lineNumber: 47,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV(DialogTitle, { className: "text-base font-semibold", children: "Policy" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
          lineNumber: 51,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(DialogDescription, { className: "text-xs mt-0.5", children: "Active agent guardrails and operational rules" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
          lineNumber: 52,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
        lineNumber: 50,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
      lineNumber: 46,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
      lineNumber: 45,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(ScrollArea, { className: "flex-1 min-h-0", children: /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 space-y-4", children: policies === void 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center py-12 text-sm text-muted-foreground", children: "Loading policies…" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
      lineNumber: 62,
      columnNumber: 13
    }, this) : policies.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center py-12 text-sm text-muted-foreground", children: "No policies defined yet." }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
      lineNumber: 66,
      columnNumber: 13
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      active && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 rounded-lg border border-primary/30 bg-primary/10 px-4 py-3", children: [
        /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-4 w-4 text-primary shrink-0" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
          lineNumber: 74,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-semibold text-foreground", children: [
            active.name,
            /* @__PURE__ */ jsxDEV("span", { className: "ml-2 text-xs font-normal text-muted-foreground", children: [
              "v",
              active.version
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
              lineNumber: 78,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
            lineNumber: 76,
            columnNumber: 23
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-primary/70 mt-0.5", children: "Currently active policy" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
            lineNumber: 80,
            columnNumber: 23
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
          lineNumber: 75,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Badge, { variant: "success", className: "ml-auto", children: "ACTIVE" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
          lineNumber: 82,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
        lineNumber: 73,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: policies.map(
        (p) => /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: cn(
              "rounded-xl border p-4 space-y-3 transition-colors",
              p.active ? "border-primary/30 bg-primary/5" : "border-border bg-card"
            ),
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: cn(
                    "flex h-8 w-8 items-center justify-center rounded-md text-xs font-bold",
                    p.active ? "bg-primary/20 text-primary" : "bg-secondary text-muted-foreground"
                  ), children: [
                    "v",
                    p.version
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
                    lineNumber: 103,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-semibold text-foreground leading-tight", children: p.name }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
                      lineNumber: 112,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 mt-0.5", children: [
                      p.scopeType === "GLOBAL" ? /* @__PURE__ */ jsxDEV(Globe, { className: "h-3 w-3 text-muted-foreground" }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
                        lineNumber: 115,
                        columnNumber: 27
                      }, this) : /* @__PURE__ */ jsxDEV(Layers, { className: "h-3 w-3 text-muted-foreground" }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
                        lineNumber: 117,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-muted-foreground", children: [
                        p.scopeType,
                        p.scopeId ? ` · ${p.scopeId}` : ""
                      ] }, void 0, true, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
                        lineNumber: 119,
                        columnNumber: 31
                      }, this)
                    ] }, void 0, true, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
                      lineNumber: 113,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
                    lineNumber: 111,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
                  lineNumber: 102,
                  columnNumber: 25
                }, this),
                p.active && /* @__PURE__ */ jsxDEV(Badge, { variant: "success", className: "shrink-0", children: "ACTIVE" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
                  lineNumber: 126,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
                lineNumber: 101,
                columnNumber: 23
              }, this),
              p.notes && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-foreground leading-relaxed", children: p.notes }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
                lineNumber: 134,
                columnNumber: 19
              }, this),
              p.rules && typeof p.rules === "object" && /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-border bg-background overflow-hidden", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 px-3 py-2 border-b border-border bg-secondary/30", children: /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold text-muted-foreground uppercase tracking-wide", children: "Rules" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
                  lineNumber: 141,
                  columnNumber: 29
                }, this) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
                  lineNumber: 140,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV(ScrollArea, { className: "max-h-[180px]", children: /* @__PURE__ */ jsxDEV("pre", { className: "px-3 py-3 text-xs font-mono text-foreground leading-relaxed whitespace-pre-wrap", children: JSON.stringify(p.rules, null, 2) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
                  lineNumber: 144,
                  columnNumber: 29
                }, this) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
                  lineNumber: 143,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
                lineNumber: 139,
                columnNumber: 19
              }, this)
            ]
          },
          p._id,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
            lineNumber: 91,
            columnNumber: 17
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
        lineNumber: 89,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
      lineNumber: 70,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
      lineNumber: 60,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
      lineNumber: 59,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
    lineNumber: 43,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx",
    lineNumber: 42,
    columnNumber: 5
  }, this);
}
_s(PolicyModal, "jO7mZ8zvbhWzh6bcNhbmMfIUsxU=", false, function() {
  return [useQuery, useQuery];
});
_c = PolicyModal;
var _c;
$RefreshReg$(_c, "PolicyModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PolicyModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJjLFNBc0JBLFVBdEJBOzs7Ozs7Ozs7Ozs7Ozs7OztBQTVCZCxTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsV0FBVztBQUVwQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxhQUFhQyxjQUFjQyxPQUFPQyxjQUFjO0FBQ3pELFNBQVNDLFVBQVU7QUFFWixnQkFBU0MsWUFBWSxFQUFFQyxRQUFpQyxHQUFHO0FBQUFDLEtBQUE7QUFDaEUsUUFBTUMsV0FBV2pCLFNBQVNDLElBQUlpQixPQUFPQyxPQUFPO0FBQzVDLFFBQU1DLGVBQWVwQixTQUFTQyxJQUFJaUIsT0FBT0csU0FBUztBQUVsRCxRQUFNQyxTQUFTRixnQkFBZ0JILFVBQVVNLEtBQUssQ0FBQ0MsTUFBdUJBLEVBQUVGLE1BQU07QUFFOUUsU0FDRSx1QkFBQyxVQUFPLE1BQUksTUFBQyxjQUFjLENBQUNHLFNBQVM7QUFBRSxRQUFJLENBQUNBLEtBQU1WLFNBQVE7QUFBQSxFQUFHLEdBQzNELGlDQUFDLGlCQUFjLFdBQVUseUVBRXZCO0FBQUEsMkJBQUMsZ0JBQWEsV0FBVSxrREFDdEIsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGtGQUNiLGlDQUFDLGVBQVksV0FBVSxhQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FDQztBQUFBLCtCQUFDLGVBQVksV0FBVSwyQkFBMEIsc0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUQ7QUFBQSxRQUN2RCx1QkFBQyxxQkFBa0IsV0FBVSxrQkFBZ0IsNkRBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUVBLHVCQUFDLGNBQVcsV0FBVSxrQkFDcEIsaUNBQUMsU0FBSSxXQUFVLHVCQUNaRSx1QkFBYVMsU0FDWix1QkFBQyxTQUFJLFdBQVUsd0VBQXNFLGlDQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsSUFDRVQsU0FBU1UsV0FBVyxJQUN0Qix1QkFBQyxTQUFJLFdBQVUsd0VBQXNFLHdDQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsSUFFQSxtQ0FFR0w7QUFBQUEsZ0JBQ0MsdUJBQUMsU0FBSSxXQUFVLHVGQUNiO0FBQUEsK0JBQUMsZ0JBQWEsV0FBVSxtQ0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RDtBQUFBLFFBQ3ZELHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxTQUFJLFdBQVUseUNBQ1pBO0FBQUFBLG1CQUFPTTtBQUFBQSxZQUNSLHVCQUFDLFVBQUssV0FBVSxrREFBaUQ7QUFBQTtBQUFBLGNBQUVOLE9BQU9PO0FBQUFBLGlCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRjtBQUFBLGVBRnBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxrQ0FBaUMsdUNBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVFO0FBQUEsYUFMekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxTQUFNLFNBQVEsV0FBVSxXQUFVLFdBQVMsc0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFJRix1QkFBQyxTQUFJLFdBQVUsYUFDWlosbUJBQVNhO0FBQUFBLFFBQUksQ0FBQ04sTUFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsV0FBV1g7QUFBQUEsY0FDVDtBQUFBLGNBQ0FXLEVBQUVGLFNBQ0UsbUNBQ0E7QUFBQSxZQUNOO0FBQUEsWUFHQTtBQUFBLHFDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBV1Q7QUFBQUEsb0JBQ2Q7QUFBQSxvQkFDQVcsRUFBRUYsU0FDRSwrQkFDQTtBQUFBLGtCQUNOLEdBQUU7QUFBQTtBQUFBLG9CQUNFRSxFQUFFSztBQUFBQSx1QkFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUEsa0JBQ0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFNBQUksV0FBVSx1REFBdURMLFlBQUVJLFFBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZFO0FBQUEsb0JBQzdFLHVCQUFDLFNBQUksV0FBVSxvQ0FDWko7QUFBQUEsd0JBQUVPLGNBQWMsV0FDZix1QkFBQyxTQUFNLFdBQVUsbUNBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdELElBRWhELHVCQUFDLFVBQU8sV0FBVSxtQ0FBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUQ7QUFBQSxzQkFFbkQsdUJBQUMsVUFBSyxXQUFVLGlDQUNiUDtBQUFBQSwwQkFBRU87QUFBQUEsd0JBQVdQLEVBQUVRLFVBQVUsTUFBTVIsRUFBRVEsT0FBTyxLQUFLO0FBQUEsMkJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVNBO0FBQUEsdUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFZQTtBQUFBLHFCQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXNCQTtBQUFBLGdCQUNDUixFQUFFRixVQUNELHVCQUFDLFNBQU0sU0FBUSxXQUFVLFdBQVUsWUFBVSxzQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQTNCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTZCQTtBQUFBLGNBR0NFLEVBQUVTLFNBQ0QsdUJBQUMsT0FBRSxXQUFVLDJDQUEyQ1QsWUFBRVMsU0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0U7QUFBQSxjQUlqRVQsRUFBRVUsU0FBUyxPQUFPVixFQUFFVSxVQUFVLFlBQzdCLHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSw0RUFDYixpQ0FBQyxVQUFLLFdBQVUsMkVBQTBFLHFCQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErRixLQURqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsY0FBVyxXQUFVLGlCQUNwQixpQ0FBQyxTQUFJLFdBQVUsbUZBQ1pDLGVBQUtDLFVBQVVaLEVBQUVVLE9BQU8sTUFBTSxDQUFDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBO0FBQUE7QUFBQSxVQXhER1YsRUFBRWE7QUFBQUEsVUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBMkRBO0FBQUEsTUFDRCxLQTlESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0RBO0FBQUEsU0FsRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1GQSxLQTdGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0ZBLEtBaEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpR0E7QUFBQSxPQWpIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0hBLEtBbkhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvSEE7QUFFSjtBQUFDckIsR0E3SGVGLGFBQVc7QUFBQSxVQUNSZCxVQUNJQSxRQUFRO0FBQUE7QUFBQSxLQUZmYztBQUFXLElBQUF3QjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VRdWVyeSIsImFwaSIsIkRpYWxvZyIsIkRpYWxvZ0NvbnRlbnQiLCJEaWFsb2dIZWFkZXIiLCJEaWFsb2dUaXRsZSIsIkRpYWxvZ0Rlc2NyaXB0aW9uIiwiQmFkZ2UiLCJTY3JvbGxBcmVhIiwiU2hpZWxkQ2hlY2siLCJDaGVja0NpcmNsZTIiLCJHbG9iZSIsIkxheWVycyIsImNuIiwiUG9saWN5TW9kYWwiLCJvbkNsb3NlIiwiX3MiLCJwb2xpY2llcyIsInBvbGljeSIsImxpc3RBbGwiLCJhY3RpdmVQb2xpY3kiLCJnZXRBY3RpdmUiLCJhY3RpdmUiLCJmaW5kIiwicCIsIm9wZW4iLCJ1bmRlZmluZWQiLCJsZW5ndGgiLCJuYW1lIiwidmVyc2lvbiIsIm1hcCIsInNjb3BlVHlwZSIsInNjb3BlSWQiLCJub3RlcyIsInJ1bGVzIiwiSlNPTiIsInN0cmluZ2lmeSIsIl9pZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBvbGljeU1vZGFsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB0eXBlIHsgRG9jIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHtcbiAgRGlhbG9nLFxuICBEaWFsb2dDb250ZW50LFxuICBEaWFsb2dIZWFkZXIsXG4gIERpYWxvZ1RpdGxlLFxuICBEaWFsb2dEZXNjcmlwdGlvbixcbn0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9kaWFsb2dcIjtcbmltcG9ydCB7IEJhZGdlIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9iYWRnZVwiO1xuaW1wb3J0IHsgU2Nyb2xsQXJlYSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvc2Nyb2xsLWFyZWFcIjtcbmltcG9ydCB7IFNoaWVsZENoZWNrLCBDaGVja0NpcmNsZTIsIEdsb2JlLCBMYXllcnMgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiO1xuXG5leHBvcnQgZnVuY3Rpb24gUG9saWN5TW9kYWwoeyBvbkNsb3NlIH06IHsgb25DbG9zZTogKCkgPT4gdm9pZCB9KSB7XG4gIGNvbnN0IHBvbGljaWVzID0gdXNlUXVlcnkoYXBpLnBvbGljeS5saXN0QWxsKTtcbiAgY29uc3QgYWN0aXZlUG9saWN5ID0gdXNlUXVlcnkoYXBpLnBvbGljeS5nZXRBY3RpdmUpO1xuXG4gIGNvbnN0IGFjdGl2ZSA9IGFjdGl2ZVBvbGljeSA/PyBwb2xpY2llcz8uZmluZCgocDogRG9jPFwicG9saWNpZXNcIj4pID0+IHAuYWN0aXZlKTtcblxuICByZXR1cm4gKFxuICAgIDxEaWFsb2cgb3BlbiBvbk9wZW5DaGFuZ2U9eyhvcGVuKSA9PiB7IGlmICghb3Blbikgb25DbG9zZSgpOyB9fT5cbiAgICAgIDxEaWFsb2dDb250ZW50IGNsYXNzTmFtZT1cInNtOm1heC13LVs1NjBweF0gbWF4LWgtWzg4dmhdIGZsZXggZmxleC1jb2wgZ2FwLTAgcC0wIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICA8RGlhbG9nSGVhZGVyIGNsYXNzTmFtZT1cInB4LTYgcHQtNiBwYi00IGJvcmRlci1iIGJvcmRlci1ib3JkZXIgc2hyaW5rLTBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC05IHctOSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBiZy1wcmltYXJ5LzEwIHRleHQtcHJpbWFyeVwiPlxuICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxEaWFsb2dUaXRsZSBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZFwiPlBvbGljeTwvRGlhbG9nVGl0bGU+XG4gICAgICAgICAgICAgIDxEaWFsb2dEZXNjcmlwdGlvbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgIEFjdGl2ZSBhZ2VudCBndWFyZHJhaWxzIGFuZCBvcGVyYXRpb25hbCBydWxlc1xuICAgICAgICAgICAgICA8L0RpYWxvZ0Rlc2NyaXB0aW9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvRGlhbG9nSGVhZGVyPlxuXG4gICAgICAgIDxTY3JvbGxBcmVhIGNsYXNzTmFtZT1cImZsZXgtMSBtaW4taC0wXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB5LTQgc3BhY2UteS00XCI+XG4gICAgICAgICAgICB7cG9saWNpZXMgPT09IHVuZGVmaW5lZCA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBweS0xMiB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgIExvYWRpbmcgcG9saWNpZXPigKZcbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApIDogcG9saWNpZXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB5LTEyIHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgTm8gcG9saWNpZXMgZGVmaW5lZCB5ZXQuXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICB7LyogQWN0aXZlIHBvbGljeSBiYW5uZXIgKi99XG4gICAgICAgICAgICAgICAge2FjdGl2ZSAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1wcmltYXJ5LzMwIGJnLXByaW1hcnkvMTAgcHgtNCBweS0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LXByaW1hcnkgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2ZS5uYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiB0ZXh0LXhzIGZvbnQtbm9ybWFsIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPnZ7YWN0aXZlLnZlcnNpb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXByaW1hcnkvNzAgbXQtMC41XCI+Q3VycmVudGx5IGFjdGl2ZSBwb2xpY3k8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwic3VjY2Vzc1wiIGNsYXNzTmFtZT1cIm1sLWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgICBBQ1RJVkVcbiAgICAgICAgICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICB7LyogUG9saWN5IGNhcmRzICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgICB7cG9saWNpZXMubWFwKChwOiBEb2M8XCJwb2xpY2llc1wiPikgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtwLl9pZH1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJyb3VuZGVkLXhsIGJvcmRlciBwLTQgc3BhY2UteS0zIHRyYW5zaXRpb24tY29sb3JzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBwLmFjdGl2ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLXByaW1hcnkvMzAgYmctcHJpbWFyeS81XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci1ib3JkZXIgYmctY2FyZFwiXG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBDYXJkIGhlYWRlciAqL31cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZmxleCBoLTggdy04IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLW1kIHRleHQteHMgZm9udC1ib2xkXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcC5hY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1wcmltYXJ5LzIwIHRleHQtcHJpbWFyeVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctc2Vjb25kYXJ5IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZ7cC52ZXJzaW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWZvcmVncm91bmQgbGVhZGluZy10aWdodFwiPntwLm5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Auc2NvcGVUeXBlID09PSBcIkdMT0JBTFwiID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8R2xvYmUgY2xhc3NOYW1lPVwiaC0zIHctMyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExheWVycyBjbGFzc05hbWU9XCJoLTMgdy0zIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Auc2NvcGVUeXBlfXtwLnNjb3BlSWQgPyBgIMK3ICR7cC5zY29wZUlkfWAgOiBcIlwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAge3AuYWN0aXZlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJzdWNjZXNzXCIgY2xhc3NOYW1lPVwic2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBQ1RJVkVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogTm90ZXMgKi99XG4gICAgICAgICAgICAgICAgICAgICAge3Aubm90ZXMgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWZvcmVncm91bmQgbGVhZGluZy1yZWxheGVkXCI+e3Aubm90ZXN9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogUnVsZXMgSlNPTiAqL31cbiAgICAgICAgICAgICAgICAgICAgICB7cC5ydWxlcyAmJiB0eXBlb2YgcC5ydWxlcyA9PT0gXCJvYmplY3RcIiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctYmFja2dyb3VuZCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC0zIHB5LTIgYm9yZGVyLWIgYm9yZGVyLWJvcmRlciBiZy1zZWNvbmRhcnkvMzBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlJ1bGVzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNjcm9sbEFyZWEgY2xhc3NOYW1lPVwibWF4LWgtWzE4MHB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwcmUgY2xhc3NOYW1lPVwicHgtMyBweS0zIHRleHQteHMgZm9udC1tb25vIHRleHQtZm9yZWdyb3VuZCBsZWFkaW5nLXJlbGF4ZWQgd2hpdGVzcGFjZS1wcmUtd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge0pTT04uc3RyaW5naWZ5KHAucnVsZXMsIG51bGwsIDIpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcHJlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1Njcm9sbEFyZWE+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvU2Nyb2xsQXJlYT5cbiAgICAgIDwvRGlhbG9nQ29udGVudD5cbiAgICA8L0RpYWxvZz5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL1BvbGljeU1vZGFsLnRzeCJ9