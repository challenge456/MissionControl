import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/sheet.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/sheet.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const React = ((m) => m?.__esModule ? m : { ...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {}, default: m })(__vite__cjsImport3_react);
import * as SheetPrimitive from "/node_modules/.vite/deps/@radix-ui_react-dialog.js?v=52b21764";
import { cva } from "/node_modules/.vite/deps/class-variance-authority.js?v=257b6f3a";
import { X } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { cn } from "/src/lib/utils.ts";
const Sheet = SheetPrimitive.Root;
const SheetTrigger = SheetPrimitive.Trigger;
const SheetClose = SheetPrimitive.Close;
const SheetPortal = SheetPrimitive.Portal;
const SheetOverlay = React.forwardRef(
  _c = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    SheetPrimitive.Overlay,
    {
      className: cn(
        "fixed inset-0 z-50 bg-black/60 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        className
      ),
      ...props,
      ref
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/sheet.tsx",
      lineNumber: 39,
      columnNumber: 1
    },
    this
  )
);
_c2 = SheetOverlay;
SheetOverlay.displayName = SheetPrimitive.Overlay.displayName;
const sheetVariants = cva(
  "fixed z-50 gap-4 bg-surface-2 border border-line p-6 shadow-[var(--shadow-elevation-2)] transition ease-in-out data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:duration-300 data-[state=open]:duration-400",
  {
    variants: {
      side: {
        top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
        bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
        left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
        right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right"
      }
    },
    defaultVariants: {
      side: "right"
    }
  }
);
const SheetContent = React.forwardRef(_c3 = ({ side = "right", className, children, ...props }, ref) => {
  const resolvedSide = side === "top" || side === "bottom" || side === "left" ? side : "right";
  return /* @__PURE__ */ jsxDEV(SheetPortal, { children: [
    /* @__PURE__ */ jsxDEV(SheetOverlay, {}, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/sheet.tsx",
      lineNumber: 82,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      SheetPrimitive.Content,
      {
        ref,
        className: cn(sheetVariants({ side: resolvedSide }), className),
        ...props,
        children: [
          children,
          /* @__PURE__ */ jsxDEV(SheetPrimitive.Close, { className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-[var(--neon-cyan)] focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary", children: [
            /* @__PURE__ */ jsxDEV(X, { className: "h-4 w-4" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/sheet.tsx",
              lineNumber: 90,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Close" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/sheet.tsx",
              lineNumber: 91,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/sheet.tsx",
            lineNumber: 89,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/sheet.tsx",
        lineNumber: 83,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/sheet.tsx",
    lineNumber: 81,
    columnNumber: 5
  }, this);
});
_c4 = SheetContent;
SheetContent.displayName = SheetPrimitive.Content.displayName;
const SheetHeader = ({
  className,
  ...props
}) => /* @__PURE__ */ jsxDEV(
  "div",
  {
    className: cn(
      "flex flex-col space-y-2 text-center sm:text-left",
      className
    ),
    ...props
  },
  void 0,
  false,
  {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/sheet.tsx",
    lineNumber: 103,
    columnNumber: 1
  },
  this
);
_c5 = SheetHeader;
SheetHeader.displayName = "SheetHeader";
const SheetFooter = ({
  className,
  ...props
}) => /* @__PURE__ */ jsxDEV(
  "div",
  {
    className: cn(
      "flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2",
      className
    ),
    ...props
  },
  void 0,
  false,
  {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/sheet.tsx",
    lineNumber: 117,
    columnNumber: 1
  },
  this
);
_c6 = SheetFooter;
SheetFooter.displayName = "SheetFooter";
const SheetTitle = React.forwardRef(
  _c7 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    SheetPrimitive.Title,
    {
      ref,
      className: cn("text-lg font-semibold text-foreground", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/sheet.tsx",
      lineNumber: 131,
      columnNumber: 1
    },
    this
  )
);
_c8 = SheetTitle;
SheetTitle.displayName = SheetPrimitive.Title.displayName;
const SheetDescription = React.forwardRef(
  _c9 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    SheetPrimitive.Description,
    {
      ref,
      className: cn("text-sm text-muted-foreground", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/sheet.tsx",
      lineNumber: 143,
      columnNumber: 1
    },
    this
  )
);
_c0 = SheetDescription;
SheetDescription.displayName = SheetPrimitive.Description.displayName;
export {
  Sheet,
  SheetPortal,
  SheetOverlay,
  SheetTrigger,
  SheetClose,
  SheetContent,
  SheetHeader,
  SheetFooter,
  SheetTitle,
  SheetDescription
};
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0;
$RefreshReg$(_c, "SheetOverlay$React.forwardRef");
$RefreshReg$(_c2, "SheetOverlay");
$RefreshReg$(_c3, "SheetContent$React.forwardRef");
$RefreshReg$(_c4, "SheetContent");
$RefreshReg$(_c5, "SheetHeader");
$RefreshReg$(_c6, "SheetFooter");
$RefreshReg$(_c7, "SheetTitle$React.forwardRef");
$RefreshReg$(_c8, "SheetTitle");
$RefreshReg$(_c9, "SheetDescription$React.forwardRef");
$RefreshReg$(_c0, "SheetDescription");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/sheet.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/sheet.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJFOzs7Ozs7Ozs7Ozs7Ozs7O0FBbkJGLFlBQVlBLFdBQVc7QUFDdkIsWUFBWUMsb0JBQW9CO0FBQ2hDLFNBQVNDLFdBQThCO0FBQ3ZDLFNBQVNDLFNBQVM7QUFFbEIsU0FBU0MsVUFBVTtBQUVuQixNQUFNQyxRQUFRSixlQUFlSztBQUU3QixNQUFNQyxlQUFlTixlQUFlTztBQUVwQyxNQUFNQyxhQUFhUixlQUFlUztBQUVsQyxNQUFNQyxjQUFjVixlQUFlVztBQUVuQyxNQUFNQyxlQUFlYixNQUFNYztBQUFBQSxFQUcxQkMsS0FBQ0EsQ0FBQyxFQUFFQyxXQUFXLEdBQUdDLE1BQU0sR0FBR0MsUUFDMUI7QUFBQSxJQUFDLGVBQWU7QUFBQSxJQUFmO0FBQUEsTUFDQyxXQUFXZDtBQUFBQSxRQUNUO0FBQUEsUUFDQVk7QUFBQUEsTUFDRjtBQUFBLE1BQ0EsR0FBSUM7QUFBQUEsTUFDSjtBQUFBO0FBQUEsSUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNVztBQUVaO0FBQUNFLE1BWklOO0FBYU5BLGFBQWFPLGNBQWNuQixlQUFlb0IsUUFBUUQ7QUFFbEQsTUFBTUUsZ0JBQWdCcEI7QUFBQUEsRUFDcEI7QUFBQSxFQUNBO0FBQUEsSUFDRXFCLFVBQVU7QUFBQSxNQUNSQyxNQUFNO0FBQUEsUUFDSkMsS0FBSztBQUFBLFFBQ0xDLFFBQ0U7QUFBQSxRQUNGQyxNQUFNO0FBQUEsUUFDTkMsT0FDRTtBQUFBLE1BQ0o7QUFBQSxJQUNGO0FBQUEsSUFDQUMsaUJBQWlCO0FBQUEsTUFDZkwsTUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQ0Y7QUFNQSxNQUFNTSxlQUFlOUIsTUFBTWMsV0FHMUJpQixNQUFDQSxDQUFDLEVBQUVQLE9BQU8sU0FBU1IsV0FBV2dCLFVBQVUsR0FBR2YsTUFBTSxHQUFHQyxRQUFRO0FBQzVELFFBQU1lLGVBQ0pULFNBQVMsU0FBU0EsU0FBUyxZQUFZQSxTQUFTLFNBQVNBLE9BQU87QUFFbEUsU0FDRSx1QkFBQyxlQUNDO0FBQUEsMkJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFhO0FBQUEsSUFDYjtBQUFBLE1BQUMsZUFBZTtBQUFBLE1BQWY7QUFBQSxRQUNDO0FBQUEsUUFDQSxXQUFXcEIsR0FBR2tCLGNBQWMsRUFBRUUsTUFBTVMsYUFBYSxDQUFDLEdBQUdqQixTQUFTO0FBQUEsUUFDOUQsR0FBSUM7QUFBQUEsUUFFSGU7QUFBQUE7QUFBQUEsVUFDRCx1QkFBQyxlQUFlLE9BQWYsRUFBcUIsV0FBVSwwUEFDOUI7QUFBQSxtQ0FBQyxLQUFFLFdBQVUsYUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzQjtBQUFBLFlBQ3RCLHVCQUFDLFVBQUssV0FBVSxXQUFVLHFCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQjtBQUFBLGVBRmpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQTtBQUFBO0FBQUEsTUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFVQTtBQUFBLE9BWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWFBO0FBRUosQ0FBQztBQUFDRSxNQXZCSUo7QUF3Qk5BLGFBQWFWLGNBQWNuQixlQUFla0MsUUFBUWY7QUFFbEQsTUFBTWdCLGNBQWNBLENBQUM7QUFBQSxFQUNuQnBCO0FBQUFBLEVBQ0EsR0FBR0M7QUFDaUMsTUFDcEM7QUFBQSxFQUFDO0FBQUE7QUFBQSxJQUNDLFdBQVdiO0FBQUFBLE1BQ1Q7QUFBQSxNQUNBWTtBQUFBQSxJQUNGO0FBQUEsSUFDQSxHQUFJQztBQUFBQTtBQUFBQSxFQUxOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFLWTtBQUVib0IsTUFYS0Q7QUFZTkEsWUFBWWhCLGNBQWM7QUFFMUIsTUFBTWtCLGNBQWNBLENBQUM7QUFBQSxFQUNuQnRCO0FBQUFBLEVBQ0EsR0FBR0M7QUFDaUMsTUFDcEM7QUFBQSxFQUFDO0FBQUE7QUFBQSxJQUNDLFdBQVdiO0FBQUFBLE1BQ1Q7QUFBQSxNQUNBWTtBQUFBQSxJQUNGO0FBQUEsSUFDQSxHQUFJQztBQUFBQTtBQUFBQSxFQUxOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFLWTtBQUVic0IsTUFYS0Q7QUFZTkEsWUFBWWxCLGNBQWM7QUFFMUIsTUFBTW9CLGFBQWF4QyxNQUFNYztBQUFBQSxFQUd4QjJCLE1BQUNBLENBQUMsRUFBRXpCLFdBQVcsR0FBR0MsTUFBTSxHQUFHQyxRQUMxQjtBQUFBLElBQUMsZUFBZTtBQUFBLElBQWY7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXZCxHQUFHLHlDQUF5Q1ksU0FBUztBQUFBLE1BQ2hFLEdBQUlDO0FBQUFBO0FBQUFBLElBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBR1k7QUFFYjtBQUFDeUIsTUFUSUY7QUFVTkEsV0FBV3BCLGNBQWNuQixlQUFlMEMsTUFBTXZCO0FBRTlDLE1BQU13QixtQkFBbUI1QyxNQUFNYztBQUFBQSxFQUc5QitCLE1BQUNBLENBQUMsRUFBRTdCLFdBQVcsR0FBR0MsTUFBTSxHQUFHQyxRQUMxQjtBQUFBLElBQUMsZUFBZTtBQUFBLElBQWY7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXZCxHQUFHLGlDQUFpQ1ksU0FBUztBQUFBLE1BQ3hELEdBQUlDO0FBQUFBO0FBQUFBLElBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBR1k7QUFFYjtBQUFDNkIsTUFUSUY7QUFVTkEsaUJBQWlCeEIsY0FBY25CLGVBQWU4QyxZQUFZM0I7QUFFMUQ7QUFBQSxFQUNFZjtBQUFBQSxFQUNBTTtBQUFBQSxFQUNBRTtBQUFBQSxFQUNBTjtBQUFBQSxFQUNBRTtBQUFBQSxFQUNBcUI7QUFBQUEsRUFDQU07QUFBQUEsRUFDQUU7QUFBQUEsRUFDQUU7QUFBQUEsRUFDQUk7QUFBQUE7QUFDRCxJQUFBN0IsSUFBQUksS0FBQVksS0FBQUcsS0FBQUcsS0FBQUUsS0FBQUUsS0FBQUMsS0FBQUcsS0FBQUM7QUFBQSxhQUFBL0IsSUFBQTtBQUFBLGFBQUFJLEtBQUE7QUFBQSxhQUFBWSxLQUFBO0FBQUEsYUFBQUcsS0FBQTtBQUFBLGFBQUFHLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBRyxLQUFBO0FBQUEsYUFBQUMsS0FBQSIsIm5hbWVzIjpbIlJlYWN0IiwiU2hlZXRQcmltaXRpdmUiLCJjdmEiLCJYIiwiY24iLCJTaGVldCIsIlJvb3QiLCJTaGVldFRyaWdnZXIiLCJUcmlnZ2VyIiwiU2hlZXRDbG9zZSIsIkNsb3NlIiwiU2hlZXRQb3J0YWwiLCJQb3J0YWwiLCJTaGVldE92ZXJsYXkiLCJmb3J3YXJkUmVmIiwiX2MiLCJjbGFzc05hbWUiLCJwcm9wcyIsInJlZiIsIl9jMiIsImRpc3BsYXlOYW1lIiwiT3ZlcmxheSIsInNoZWV0VmFyaWFudHMiLCJ2YXJpYW50cyIsInNpZGUiLCJ0b3AiLCJib3R0b20iLCJsZWZ0IiwicmlnaHQiLCJkZWZhdWx0VmFyaWFudHMiLCJTaGVldENvbnRlbnQiLCJfYzMiLCJjaGlsZHJlbiIsInJlc29sdmVkU2lkZSIsIl9jNCIsIkNvbnRlbnQiLCJTaGVldEhlYWRlciIsIl9jNSIsIlNoZWV0Rm9vdGVyIiwiX2M2IiwiU2hlZXRUaXRsZSIsIl9jNyIsIl9jOCIsIlRpdGxlIiwiU2hlZXREZXNjcmlwdGlvbiIsIl9jOSIsIl9jMCIsIkRlc2NyaXB0aW9uIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInNoZWV0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIlxuaW1wb3J0ICogYXMgU2hlZXRQcmltaXRpdmUgZnJvbSBcIkByYWRpeC11aS9yZWFjdC1kaWFsb2dcIlxuaW1wb3J0IHsgY3ZhLCB0eXBlIFZhcmlhbnRQcm9wcyB9IGZyb20gXCJjbGFzcy12YXJpYW5jZS1hdXRob3JpdHlcIlxuaW1wb3J0IHsgWCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIlxuXG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiXG5cbmNvbnN0IFNoZWV0ID0gU2hlZXRQcmltaXRpdmUuUm9vdFxuXG5jb25zdCBTaGVldFRyaWdnZXIgPSBTaGVldFByaW1pdGl2ZS5UcmlnZ2VyXG5cbmNvbnN0IFNoZWV0Q2xvc2UgPSBTaGVldFByaW1pdGl2ZS5DbG9zZVxuXG5jb25zdCBTaGVldFBvcnRhbCA9IFNoZWV0UHJpbWl0aXZlLlBvcnRhbFxuXG5jb25zdCBTaGVldE92ZXJsYXkgPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBSZWFjdC5FbGVtZW50UmVmPHR5cGVvZiBTaGVldFByaW1pdGl2ZS5PdmVybGF5PixcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBTaGVldFByaW1pdGl2ZS5PdmVybGF5PlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8U2hlZXRQcmltaXRpdmUuT3ZlcmxheVxuICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICBcImZpeGVkIGluc2V0LTAgei01MCBiZy1ibGFjay82MCBkYXRhLVtzdGF0ZT1vcGVuXTphbmltYXRlLWluIGRhdGEtW3N0YXRlPWNsb3NlZF06YW5pbWF0ZS1vdXQgZGF0YS1bc3RhdGU9Y2xvc2VkXTpmYWRlLW91dC0wIGRhdGEtW3N0YXRlPW9wZW5dOmZhZGUtaW4tMFwiLFxuICAgICAgY2xhc3NOYW1lXG4gICAgKX1cbiAgICB7Li4ucHJvcHN9XG4gICAgcmVmPXtyZWZ9XG4gIC8+XG4pKVxuU2hlZXRPdmVybGF5LmRpc3BsYXlOYW1lID0gU2hlZXRQcmltaXRpdmUuT3ZlcmxheS5kaXNwbGF5TmFtZVxuXG5jb25zdCBzaGVldFZhcmlhbnRzID0gY3ZhKFxuICBcImZpeGVkIHotNTAgZ2FwLTQgYmctc3VyZmFjZS0yIGJvcmRlciBib3JkZXItbGluZSBwLTYgc2hhZG93LVt2YXIoLS1zaGFkb3ctZWxldmF0aW9uLTIpXSB0cmFuc2l0aW9uIGVhc2UtaW4tb3V0IGRhdGEtW3N0YXRlPW9wZW5dOmFuaW1hdGUtaW4gZGF0YS1bc3RhdGU9Y2xvc2VkXTphbmltYXRlLW91dCBkYXRhLVtzdGF0ZT1jbG9zZWRdOmR1cmF0aW9uLTMwMCBkYXRhLVtzdGF0ZT1vcGVuXTpkdXJhdGlvbi00MDBcIixcbiAge1xuICAgIHZhcmlhbnRzOiB7XG4gICAgICBzaWRlOiB7XG4gICAgICAgIHRvcDogXCJpbnNldC14LTAgdG9wLTAgYm9yZGVyLWIgZGF0YS1bc3RhdGU9Y2xvc2VkXTpzbGlkZS1vdXQtdG8tdG9wIGRhdGEtW3N0YXRlPW9wZW5dOnNsaWRlLWluLWZyb20tdG9wXCIsXG4gICAgICAgIGJvdHRvbTpcbiAgICAgICAgICBcImluc2V0LXgtMCBib3R0b20tMCBib3JkZXItdCBkYXRhLVtzdGF0ZT1jbG9zZWRdOnNsaWRlLW91dC10by1ib3R0b20gZGF0YS1bc3RhdGU9b3Blbl06c2xpZGUtaW4tZnJvbS1ib3R0b21cIixcbiAgICAgICAgbGVmdDogXCJpbnNldC15LTAgbGVmdC0wIGgtZnVsbCB3LTMvNCBib3JkZXItciBkYXRhLVtzdGF0ZT1jbG9zZWRdOnNsaWRlLW91dC10by1sZWZ0IGRhdGEtW3N0YXRlPW9wZW5dOnNsaWRlLWluLWZyb20tbGVmdCBzbTptYXgtdy1zbVwiLFxuICAgICAgICByaWdodDpcbiAgICAgICAgICBcImluc2V0LXktMCByaWdodC0wIGgtZnVsbCB3LTMvNCBib3JkZXItbCBkYXRhLVtzdGF0ZT1jbG9zZWRdOnNsaWRlLW91dC10by1yaWdodCBkYXRhLVtzdGF0ZT1vcGVuXTpzbGlkZS1pbi1mcm9tLXJpZ2h0XCIsXG4gICAgICB9LFxuICAgIH0sXG4gICAgZGVmYXVsdFZhcmlhbnRzOiB7XG4gICAgICBzaWRlOiBcInJpZ2h0XCIsXG4gICAgfSxcbiAgfVxuKVxuXG5pbnRlcmZhY2UgU2hlZXRDb250ZW50UHJvcHNcbiAgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnRQcm9wc1dpdGhvdXRSZWY8dHlwZW9mIFNoZWV0UHJpbWl0aXZlLkNvbnRlbnQ+LFxuICAgIFZhcmlhbnRQcm9wczx0eXBlb2Ygc2hlZXRWYXJpYW50cz4ge31cblxuY29uc3QgU2hlZXRDb250ZW50ID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgUmVhY3QuRWxlbWVudFJlZjx0eXBlb2YgU2hlZXRQcmltaXRpdmUuQ29udGVudD4sXG4gIFNoZWV0Q29udGVudFByb3BzXG4+KCh7IHNpZGUgPSBcInJpZ2h0XCIsIGNsYXNzTmFtZSwgY2hpbGRyZW4sIC4uLnByb3BzIH0sIHJlZikgPT4ge1xuICBjb25zdCByZXNvbHZlZFNpZGU6IFwiYm90dG9tXCIgfCBcImxlZnRcIiB8IFwicmlnaHRcIiB8IFwidG9wXCIgPVxuICAgIHNpZGUgPT09IFwidG9wXCIgfHwgc2lkZSA9PT0gXCJib3R0b21cIiB8fCBzaWRlID09PSBcImxlZnRcIiA/IHNpZGUgOiBcInJpZ2h0XCJcblxuICByZXR1cm4gKFxuICAgIDxTaGVldFBvcnRhbD5cbiAgICAgIDxTaGVldE92ZXJsYXkgLz5cbiAgICAgIDxTaGVldFByaW1pdGl2ZS5Db250ZW50XG4gICAgICAgIHJlZj17cmVmfVxuICAgICAgICBjbGFzc05hbWU9e2NuKHNoZWV0VmFyaWFudHMoeyBzaWRlOiByZXNvbHZlZFNpZGUgfSksIGNsYXNzTmFtZSl9XG4gICAgICAgIHsuLi5wcm9wc31cbiAgICAgID5cbiAgICAgICAge2NoaWxkcmVufVxuICAgICAgICA8U2hlZXRQcmltaXRpdmUuQ2xvc2UgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtNCB0b3AtNCByb3VuZGVkLXNtIG9wYWNpdHktNzAgcmluZy1vZmZzZXQtYmFja2dyb3VuZCB0cmFuc2l0aW9uLW9wYWNpdHkgaG92ZXI6b3BhY2l0eS0xMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVt2YXIoLS1uZW9uLWN5YW4pXSBmb2N1czpyaW5nLW9mZnNldC0yIGRpc2FibGVkOnBvaW50ZXItZXZlbnRzLW5vbmUgZGF0YS1bc3RhdGU9b3Blbl06Ymctc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgPFggY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Itb25seVwiPkNsb3NlPC9zcGFuPlxuICAgICAgICA8L1NoZWV0UHJpbWl0aXZlLkNsb3NlPlxuICAgICAgPC9TaGVldFByaW1pdGl2ZS5Db250ZW50PlxuICAgIDwvU2hlZXRQb3J0YWw+XG4gIClcbn0pXG5TaGVldENvbnRlbnQuZGlzcGxheU5hbWUgPSBTaGVldFByaW1pdGl2ZS5Db250ZW50LmRpc3BsYXlOYW1lXG5cbmNvbnN0IFNoZWV0SGVhZGVyID0gKHtcbiAgY2xhc3NOYW1lLFxuICAuLi5wcm9wc1xufTogUmVhY3QuSFRNTEF0dHJpYnV0ZXM8SFRNTERpdkVsZW1lbnQ+KSA9PiAoXG4gIDxkaXZcbiAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgXCJmbGV4IGZsZXgtY29sIHNwYWNlLXktMiB0ZXh0LWNlbnRlciBzbTp0ZXh0LWxlZnRcIixcbiAgICAgIGNsYXNzTmFtZVxuICAgICl9XG4gICAgey4uLnByb3BzfVxuICAvPlxuKVxuU2hlZXRIZWFkZXIuZGlzcGxheU5hbWUgPSBcIlNoZWV0SGVhZGVyXCJcblxuY29uc3QgU2hlZXRGb290ZXIgPSAoe1xuICBjbGFzc05hbWUsXG4gIC4uLnByb3BzXG59OiBSZWFjdC5IVE1MQXR0cmlidXRlczxIVE1MRGl2RWxlbWVudD4pID0+IChcbiAgPGRpdlxuICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICBcImZsZXggZmxleC1jb2wtcmV2ZXJzZSBzbTpmbGV4LXJvdyBzbTpqdXN0aWZ5LWVuZCBzbTpzcGFjZS14LTJcIixcbiAgICAgIGNsYXNzTmFtZVxuICAgICl9XG4gICAgey4uLnByb3BzfVxuICAvPlxuKVxuU2hlZXRGb290ZXIuZGlzcGxheU5hbWUgPSBcIlNoZWV0Rm9vdGVyXCJcblxuY29uc3QgU2hlZXRUaXRsZSA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIFJlYWN0LkVsZW1lbnRSZWY8dHlwZW9mIFNoZWV0UHJpbWl0aXZlLlRpdGxlPixcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBTaGVldFByaW1pdGl2ZS5UaXRsZT5cbj4oKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9LCByZWYpID0+IChcbiAgPFNoZWV0UHJpbWl0aXZlLlRpdGxlXG4gICAgcmVmPXtyZWZ9XG4gICAgY2xhc3NOYW1lPXtjbihcInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWZvcmVncm91bmRcIiwgY2xhc3NOYW1lKX1cbiAgICB7Li4ucHJvcHN9XG4gIC8+XG4pKVxuU2hlZXRUaXRsZS5kaXNwbGF5TmFtZSA9IFNoZWV0UHJpbWl0aXZlLlRpdGxlLmRpc3BsYXlOYW1lXG5cbmNvbnN0IFNoZWV0RGVzY3JpcHRpb24gPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBSZWFjdC5FbGVtZW50UmVmPHR5cGVvZiBTaGVldFByaW1pdGl2ZS5EZXNjcmlwdGlvbj4sXG4gIFJlYWN0LkNvbXBvbmVudFByb3BzV2l0aG91dFJlZjx0eXBlb2YgU2hlZXRQcmltaXRpdmUuRGVzY3JpcHRpb24+XG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDxTaGVldFByaW1pdGl2ZS5EZXNjcmlwdGlvblxuICAgIHJlZj17cmVmfVxuICAgIGNsYXNzTmFtZT17Y24oXCJ0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiLCBjbGFzc05hbWUpfVxuICAgIHsuLi5wcm9wc31cbiAgLz5cbikpXG5TaGVldERlc2NyaXB0aW9uLmRpc3BsYXlOYW1lID0gU2hlZXRQcmltaXRpdmUuRGVzY3JpcHRpb24uZGlzcGxheU5hbWVcblxuZXhwb3J0IHtcbiAgU2hlZXQsXG4gIFNoZWV0UG9ydGFsLFxuICBTaGVldE92ZXJsYXksXG4gIFNoZWV0VHJpZ2dlcixcbiAgU2hlZXRDbG9zZSxcbiAgU2hlZXRDb250ZW50LFxuICBTaGVldEhlYWRlcixcbiAgU2hlZXRGb290ZXIsXG4gIFNoZWV0VGl0bGUsXG4gIFNoZWV0RGVzY3JpcHRpb24sXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9jb21wb25lbnRzL3VpL3NoZWV0LnRzeCJ9