import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/button.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/button.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const React = ((m) => m?.__esModule ? m : { ...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {}, default: m })(__vite__cjsImport3_react);
import { Slot } from "/node_modules/.vite/deps/@radix-ui_react-slot.js?v=d865e30d";
import { cva } from "/node_modules/.vite/deps/class-variance-authority.js?v=257b6f3a";
import { cn } from "/src/lib/utils.ts";
const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-[13px] font-medium ring-offset-background transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-0 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "border border-transparent bg-act text-act-ink hover:opacity-90",
        destructive: "border border-transparent bg-err-soft text-err hover:opacity-90",
        outline: "border border-line bg-surface-1 text-ink-secondary hover:border-line-strong hover:text-ink",
        secondary: "border border-line bg-surface-2 text-ink-secondary hover:text-ink hover:border-line-strong",
        ghost: "text-ink-secondary hover:bg-surface-2 hover:text-ink",
        link: "text-ink underline-offset-4 hover:underline p-0 h-auto",
        success: "border border-transparent bg-ok-soft text-ok hover:opacity-90",
        neon: "border border-transparent bg-ok-soft text-ok hover:opacity-90",
        warning: "border border-transparent bg-warn-soft text-warn hover:opacity-90",
        "neon-cyan": "border border-transparent bg-info-soft text-info-accent hover:opacity-90"
      },
      size: {
        default: "h-9 px-3",
        sm: "h-8 rounded-lg px-3 text-xs",
        lg: "h-10 rounded-lg px-5",
        icon: "h-9 w-9"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
const Button = React.forwardRef(
  _c = ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return /* @__PURE__ */ jsxDEV(
      Comp,
      {
        className: cn(buttonVariants({ variant, size, className })),
        ref,
        ...props
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/button.tsx",
        lineNumber: 74,
        columnNumber: 5
      },
      this
    );
  }
);
_c2 = Button;
Button.displayName = "Button";
export { Button, buttonVariants };
var _c, _c2;
$RefreshReg$(_c, "Button$React.forwardRef");
$RefreshReg$(_c2, "Button");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0RNOzs7Ozs7Ozs7Ozs7Ozs7O0FBdEROLFlBQVlBLFdBQVc7QUFDdkIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxXQUE4QjtBQUV2QyxTQUFTQyxVQUFVO0FBRW5CLE1BQU1DLGlCQUFpQkY7QUFBQUEsRUFDckI7QUFBQSxFQUNBO0FBQUEsSUFDRUcsVUFBVTtBQUFBLE1BQ1JDLFNBQVM7QUFBQSxRQUNQQyxTQUNFO0FBQUEsUUFDRkMsYUFDRTtBQUFBLFFBQ0ZDLFNBQ0U7QUFBQSxRQUNGQyxXQUNFO0FBQUEsUUFDRkMsT0FBTztBQUFBLFFBQ1BDLE1BQU07QUFBQSxRQUNOQyxTQUNFO0FBQUEsUUFDRkMsTUFDRTtBQUFBLFFBQ0ZDLFNBQ0U7QUFBQSxRQUNGLGFBQ0U7QUFBQSxNQUNKO0FBQUEsTUFDQUMsTUFBTTtBQUFBLFFBQ0pULFNBQVM7QUFBQSxRQUNUVSxJQUFJO0FBQUEsUUFDSkMsSUFBSTtBQUFBLFFBQ0pDLE1BQU07QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUFBLElBQ0FDLGlCQUFpQjtBQUFBLE1BQ2ZkLFNBQVM7QUFBQSxNQUNUVSxNQUFNO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFDRjtBQVFBLE1BQU1LLFNBQVNyQixNQUFNc0I7QUFBQUEsRUFBMENDLEtBQzdEQSxDQUFDLEVBQUVDLFdBQVdsQixTQUFTVSxNQUFNUyxVQUFVLE9BQU8sR0FBR0MsTUFBTSxHQUFHQyxRQUFRO0FBQ2hFLFVBQU1DLE9BQU9ILFVBQVV4QixPQUFPO0FBQzlCLFdBQ0U7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVdFLEdBQUdDLGVBQWUsRUFBRUUsU0FBU1UsTUFBTVEsVUFBVSxDQUFDLENBQUM7QUFBQSxRQUMxRDtBQUFBLFFBQ0EsR0FBSUU7QUFBQUE7QUFBQUEsTUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHWTtBQUFBLEVBR2hCO0FBQ0Y7QUFBQ0csTUFYS1I7QUFZTkEsT0FBT1MsY0FBYztBQUVyQixTQUFTVCxRQUFRakI7QUFBZ0IsSUFBQW1CLElBQUFNO0FBQUEsYUFBQU4sSUFBQTtBQUFBLGFBQUFNLEtBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIlNsb3QiLCJjdmEiLCJjbiIsImJ1dHRvblZhcmlhbnRzIiwidmFyaWFudHMiLCJ2YXJpYW50IiwiZGVmYXVsdCIsImRlc3RydWN0aXZlIiwib3V0bGluZSIsInNlY29uZGFyeSIsImdob3N0IiwibGluayIsInN1Y2Nlc3MiLCJuZW9uIiwid2FybmluZyIsInNpemUiLCJzbSIsImxnIiwiaWNvbiIsImRlZmF1bHRWYXJpYW50cyIsIkJ1dHRvbiIsImZvcndhcmRSZWYiLCJfYyIsImNsYXNzTmFtZSIsImFzQ2hpbGQiLCJwcm9wcyIsInJlZiIsIkNvbXAiLCJfYzIiLCJkaXNwbGF5TmFtZSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJidXR0b24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiXG5pbXBvcnQgeyBTbG90IH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1zbG90XCJcbmltcG9ydCB7IGN2YSwgdHlwZSBWYXJpYW50UHJvcHMgfSBmcm9tIFwiY2xhc3MtdmFyaWFuY2UtYXV0aG9yaXR5XCJcblxuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIlxuXG5jb25zdCBidXR0b25WYXJpYW50cyA9IGN2YShcbiAgXCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgd2hpdGVzcGFjZS1ub3dyYXAgcm91bmRlZC1sZyB0ZXh0LVsxM3B4XSBmb250LW1lZGl1bSByaW5nLW9mZnNldC1iYWNrZ3JvdW5kIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBmb2N1cy12aXNpYmxlOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctcmluZyBmb2N1cy12aXNpYmxlOnJpbmctb2Zmc2V0LTAgZGlzYWJsZWQ6cG9pbnRlci1ldmVudHMtbm9uZSBkaXNhYmxlZDpvcGFjaXR5LTUwIFsmX3N2Z106cG9pbnRlci1ldmVudHMtbm9uZSBbJl9zdmddOnNpemUtNCBbJl9zdmddOnNocmluay0wXCIsXG4gIHtcbiAgICB2YXJpYW50czoge1xuICAgICAgdmFyaWFudDoge1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIFwiYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCBiZy1hY3QgdGV4dC1hY3QtaW5rIGhvdmVyOm9wYWNpdHktOTBcIixcbiAgICAgICAgZGVzdHJ1Y3RpdmU6XG4gICAgICAgICAgXCJib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGJnLWVyci1zb2Z0IHRleHQtZXJyIGhvdmVyOm9wYWNpdHktOTBcIixcbiAgICAgICAgb3V0bGluZTpcbiAgICAgICAgICBcImJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgdGV4dC1pbmstc2Vjb25kYXJ5IGhvdmVyOmJvcmRlci1saW5lLXN0cm9uZyBob3Zlcjp0ZXh0LWlua1wiLFxuICAgICAgICBzZWNvbmRhcnk6XG4gICAgICAgICAgXCJib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yIHRleHQtaW5rLXNlY29uZGFyeSBob3Zlcjp0ZXh0LWluayBob3Zlcjpib3JkZXItbGluZS1zdHJvbmdcIixcbiAgICAgICAgZ2hvc3Q6IFwidGV4dC1pbmstc2Vjb25kYXJ5IGhvdmVyOmJnLXN1cmZhY2UtMiBob3Zlcjp0ZXh0LWlua1wiLFxuICAgICAgICBsaW5rOiBcInRleHQtaW5rIHVuZGVybGluZS1vZmZzZXQtNCBob3Zlcjp1bmRlcmxpbmUgcC0wIGgtYXV0b1wiLFxuICAgICAgICBzdWNjZXNzOlxuICAgICAgICAgIFwiYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCBiZy1vay1zb2Z0IHRleHQtb2sgaG92ZXI6b3BhY2l0eS05MFwiLFxuICAgICAgICBuZW9uOlxuICAgICAgICAgIFwiYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCBiZy1vay1zb2Z0IHRleHQtb2sgaG92ZXI6b3BhY2l0eS05MFwiLFxuICAgICAgICB3YXJuaW5nOlxuICAgICAgICAgIFwiYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCBiZy13YXJuLXNvZnQgdGV4dC13YXJuIGhvdmVyOm9wYWNpdHktOTBcIixcbiAgICAgICAgXCJuZW9uLWN5YW5cIjpcbiAgICAgICAgICBcImJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgYmctaW5mby1zb2Z0IHRleHQtaW5mby1hY2NlbnQgaG92ZXI6b3BhY2l0eS05MFwiLFxuICAgICAgfSxcbiAgICAgIHNpemU6IHtcbiAgICAgICAgZGVmYXVsdDogXCJoLTkgcHgtM1wiLFxuICAgICAgICBzbTogXCJoLTggcm91bmRlZC1sZyBweC0zIHRleHQteHNcIixcbiAgICAgICAgbGc6IFwiaC0xMCByb3VuZGVkLWxnIHB4LTVcIixcbiAgICAgICAgaWNvbjogXCJoLTkgdy05XCIsXG4gICAgICB9LFxuICAgIH0sXG4gICAgZGVmYXVsdFZhcmlhbnRzOiB7XG4gICAgICB2YXJpYW50OiBcImRlZmF1bHRcIixcbiAgICAgIHNpemU6IFwiZGVmYXVsdFwiLFxuICAgIH0sXG4gIH1cbilcblxuZXhwb3J0IGludGVyZmFjZSBCdXR0b25Qcm9wc1xuICBleHRlbmRzIFJlYWN0LkJ1dHRvbkhUTUxBdHRyaWJ1dGVzPEhUTUxCdXR0b25FbGVtZW50PixcbiAgICBWYXJpYW50UHJvcHM8dHlwZW9mIGJ1dHRvblZhcmlhbnRzPiB7XG4gIGFzQ2hpbGQ/OiBib29sZWFuXG59XG5cbmNvbnN0IEJ1dHRvbiA9IFJlYWN0LmZvcndhcmRSZWY8SFRNTEJ1dHRvbkVsZW1lbnQsIEJ1dHRvblByb3BzPihcbiAgKHsgY2xhc3NOYW1lLCB2YXJpYW50LCBzaXplLCBhc0NoaWxkID0gZmFsc2UsIC4uLnByb3BzIH0sIHJlZikgPT4ge1xuICAgIGNvbnN0IENvbXAgPSBhc0NoaWxkID8gU2xvdCA6IFwiYnV0dG9uXCJcbiAgICByZXR1cm4gKFxuICAgICAgPENvbXBcbiAgICAgICAgY2xhc3NOYW1lPXtjbihidXR0b25WYXJpYW50cyh7IHZhcmlhbnQsIHNpemUsIGNsYXNzTmFtZSB9KSl9XG4gICAgICAgIHJlZj17cmVmfVxuICAgICAgICB7Li4ucHJvcHN9XG4gICAgICAvPlxuICAgIClcbiAgfVxuKVxuQnV0dG9uLmRpc3BsYXlOYW1lID0gXCJCdXR0b25cIlxuXG5leHBvcnQgeyBCdXR0b24sIGJ1dHRvblZhcmlhbnRzIH1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL2NvbXBvbmVudHMvdWkvYnV0dG9uLnRzeCJ9