import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ApprovalsModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { cn } from "/src/lib/utils.ts";
import { Badge } from "/src/components/ui/badge.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription
} from "/src/components/ui/dialog.tsx";
const TAB_ORDER = ["PENDING", "ESCALATED", "APPROVED", "DENIED"];
const TAB_LABEL = {
  PENDING: "Pending",
  ESCALATED: "Escalated",
  APPROVED: "Approved",
  DENIED: "Denied"
};
export function ApprovalsModal({
  projectId,
  onClose
}) {
  _s();
  const [activeTab, setActiveTab] = useState("PENDING");
  const pending = useQuery(
    api.approvals.listByStatus,
    projectId ? { projectId, status: "PENDING", limit: 100 } : { status: "PENDING", limit: 100 }
  );
  const escalated = useQuery(
    api.approvals.listByStatus,
    projectId ? { projectId, status: "ESCALATED", limit: 100 } : { status: "ESCALATED", limit: 100 }
  );
  const approved = useQuery(
    api.approvals.listByStatus,
    projectId ? { projectId, status: "APPROVED", limit: 100 } : { status: "APPROVED", limit: 100 }
  );
  const denied = useQuery(
    api.approvals.listByStatus,
    projectId ? { projectId, status: "DENIED", limit: 100 } : { status: "DENIED", limit: 100 }
  );
  const agents = useQuery(api.agents.listAll, projectId ? { projectId } : {});
  const approveMutation = useMutation(api.approvals.approve);
  const denyMutation = useMutation(api.approvals.deny);
  const isLoading = !pending || !escalated || !approved || !denied || !agents;
  return /* @__PURE__ */ jsxDEV(Dialog, { open: true, onOpenChange: (open) => {
    if (!open) onClose();
  }, children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "max-w-[900px] max-h-[90vh] overflow-auto", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Approvals Center" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
        lineNumber: 82,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Escalated approvals breached SLA and should be actioned first." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
        lineNumber: 83,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
      lineNumber: 81,
      columnNumber: 9
    }, this),
    isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "py-6 text-sm text-muted-foreground", children: "Loading approvals..." }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
      lineNumber: 89,
      columnNumber: 9
    }, this) : (() => {
      const agentMap = new Map(
        agents.map((agent) => [agent._id, agent])
      );
      const byStatus = {
        PENDING: pending,
        ESCALATED: escalated,
        APPROVED: approved,
        DENIED: denied
      };
      const rows = byStatus[activeTab];
      const counts = {
        PENDING: pending.length,
        ESCALATED: escalated.length,
        APPROVED: approved.length,
        DENIED: denied.length
      };
      return /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 flex-wrap", role: "tablist", children: TAB_ORDER.map(
          (status) => /* @__PURE__ */ jsxDEV(
            Button,
            {
              role: "tab",
              "aria-selected": activeTab === status,
              variant: activeTab === status ? "default" : "outline",
              size: "sm",
              onClick: () => setActiveTab(status),
              children: [
                TAB_LABEL[status],
                " (",
                counts[status],
                ")"
              ]
            },
            status,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
              lineNumber: 112,
              columnNumber: 17
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
          lineNumber: 110,
          columnNumber: 15
        }, this),
        rows.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground py-4", children: [
          "No ",
          TAB_LABEL[activeTab].toLowerCase(),
          " approvals."
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
          lineNumber: 126,
          columnNumber: 15
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: rows.map(
          (approval) => /* @__PURE__ */ jsxDEV(
            ApprovalCard,
            {
              approval,
              requestor: agentMap.get(approval.requestorAgentId),
              canDecide: activeTab === "PENDING" || activeTab === "ESCALATED",
              onApprove: async (reason) => {
                return await approveMutation({
                  approvalId: approval._id,
                  decidedByUserId: "operator",
                  reason
                });
              },
              onDeny: async (reason) => {
                return await denyMutation({
                  approvalId: approval._id,
                  decidedByUserId: "operator",
                  reason
                });
              }
            },
            approval._id,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
              lineNumber: 132,
              columnNumber: 17
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
          lineNumber: 130,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
        lineNumber: 109,
        columnNumber: 13
      }, this);
    })()
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
    lineNumber: 80,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
    lineNumber: 79,
    columnNumber: 5
  }, this);
}
_s(ApprovalsModal, "oqGBjXfiXLSQKIC6lUMVjGdX7oY=", false, function() {
  return [useQuery, useQuery, useQuery, useQuery, useQuery, useMutation, useMutation];
});
_c = ApprovalsModal;
function ApprovalCard({
  approval,
  requestor,
  canDecide,
  onApprove,
  onDeny
}) {
  _s2();
  const [loading, setLoading] = useState(false);
  const [approveReason, setApproveReason] = useState("");
  const [denyReason, setDenyReason] = useState("");
  const [showDeny, setShowDeny] = useState(false);
  const [error, setError] = useState(null);
  const [info, setInfo] = useState(null);
  const expiryText = useMemo(() => {
    return new Date(approval.expiresAt).toLocaleString();
  }, [approval.expiresAt]);
  const decidedText = approval.decidedAt ? new Date(approval.decidedAt).toLocaleString() : null;
  const escalatedText = approval.escalatedAt ? new Date(approval.escalatedAt).toLocaleString() : null;
  const minutesRemaining = Math.floor((approval.expiresAt - Date.now()) / 6e4);
  const needsDualControl = (approval.requiredDecisionCount ?? 1) > 1;
  async function handleApprove() {
    if (!approveReason.trim()) return;
    setLoading(true);
    setError(null);
    setInfo(null);
    try {
      const result = await onApprove(approveReason.trim());
      if (result?.pendingSecondDecision) {
        setInfo("First approval recorded. A second distinct approver is required.");
      } else {
        setInfo("Approval recorded.");
      }
      setApproveReason("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to approve. Please try again.");
    } finally {
      setLoading(false);
    }
  }
  async function handleDeny() {
    if (!denyReason.trim()) return;
    setLoading(true);
    setError(null);
    setInfo(null);
    try {
      await onDeny(denyReason.trim());
      setShowDeny(false);
      setDenyReason("");
      setInfo("Approval denied.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to deny. Please try again.");
    } finally {
      setLoading(false);
    }
  }
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: cn(
        "p-4 rounded-lg border bg-card",
        approval.status === "ESCALATED" ? "border-orange-500/50" : "border-border"
      ),
      children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 flex-wrap", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-foreground", children: [
              requestor?.emoji ? `${requestor.emoji} ` : "",
              requestor?.name ?? "Agent"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
              lineNumber: 238,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-muted-foreground", children: [
              "· ",
              approval.actionType
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
              lineNumber: 241,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(
              Badge,
              {
                variant: approval.riskLevel === "RED" ? "destructive" : "secondary",
                className: "text-xs",
                children: approval.riskLevel
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
                lineNumber: 242,
                columnNumber: 11
              },
              this
            ),
            needsDualControl && /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", className: "text-xs", children: "DUAL CONTROL" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
              lineNumber: 249,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
            lineNumber: 237,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            Badge,
            {
              variant: approval.status === "APPROVED" ? "default" : approval.status === "DENIED" ? "destructive" : "secondary",
              className: "text-xs",
              children: approval.status
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
              lineNumber: 254,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
          lineNumber: 236,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "font-medium text-sm mt-2", children: approval.actionSummary }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
          lineNumber: 266,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted-foreground mt-1.5 whitespace-pre-wrap", children: approval.justification }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
          lineNumber: 268,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: cn("text-xs mt-2", minutesRemaining < 10 ? "text-destructive" : "text-muted-foreground"), children: [
          "Expires: ",
          expiryText,
          " (",
          minutesRemaining >= 0 ? `${minutesRemaining}m left` : "expired",
          ")"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
          lineNumber: 272,
          columnNumber: 7
        }, this),
        approval.status === "ESCALATED" && /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-orange-400 mt-1.5", children: [
          "Escalated: ",
          escalatedText ?? "now",
          approval.escalationReason ? ` · ${approval.escalationReason}` : ""
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
          lineNumber: 277,
          columnNumber: 7
        }, this),
        approval.firstDecisionAt && /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-warn mt-1.5", children: [
          "First approval: ",
          approval.firstDecisionByUserId ?? "operator",
          " at ",
          new Date(approval.firstDecisionAt).toLocaleString()
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
          lineNumber: 284,
          columnNumber: 7
        }, this),
        !canDecide && /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-foreground/70 mt-2", children: [
          "Decision reason: ",
          approval.decisionReason || "No reason provided",
          decidedText ? ` · ${decidedText}` : ""
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
          lineNumber: 290,
          columnNumber: 7
        }, this),
        canDecide && /* @__PURE__ */ jsxDEV("div", { className: "mt-3 pt-3 border-t border-border", children: [
          error && /* @__PURE__ */ jsxDEV("div", { className: "mb-2 p-2 bg-destructive/10 border border-destructive/20 rounded-md text-xs text-destructive", children: error }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
            lineNumber: 299,
            columnNumber: 9
          }, this),
          info && /* @__PURE__ */ jsxDEV("div", { className: "mb-2 p-2 bg-primary/10 border border-primary/20 rounded-md text-xs text-primary", children: info }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
            lineNumber: 305,
            columnNumber: 9
          }, this),
          !showDeny ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                value: approveReason,
                onChange: (event) => setApproveReason(event.target.value),
                placeholder: "Approval reason (required)",
                className: "mb-2"
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
                lineNumber: 312,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  size: "sm",
                  onClick: handleApprove,
                  disabled: loading || !approveReason.trim(),
                  children: loading ? "Saving..." : needsDualControl && !approval.firstDecisionAt ? "Record 1st Approval" : "Approve"
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
                  lineNumber: 319,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  size: "sm",
                  variant: "destructive",
                  onClick: () => setShowDeny(true),
                  disabled: loading,
                  children: "Deny"
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
                  lineNumber: 326,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
              lineNumber: 318,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
            lineNumber: 311,
            columnNumber: 9
          }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                value: denyReason,
                onChange: (event) => setDenyReason(event.target.value),
                placeholder: "Denial reason (required)",
                className: "mb-2"
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
                lineNumber: 338,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  size: "sm",
                  variant: "destructive",
                  onClick: handleDeny,
                  disabled: loading || !denyReason.trim(),
                  children: loading ? "Saving..." : "Confirm Deny"
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
                  lineNumber: 345,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  size: "sm",
                  variant: "outline",
                  onClick: () => {
                    setShowDeny(false);
                    setDenyReason("");
                  },
                  disabled: loading,
                  children: "Cancel"
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
                  lineNumber: 353,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
              lineNumber: 344,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
            lineNumber: 337,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
          lineNumber: 297,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx",
      lineNumber: 230,
      columnNumber: 5
    },
    this
  );
}
_s2(ApprovalCard, "PJBSwyOGgUfHBmD3Z4qlFaRjpCY=");
_c2 = ApprovalCard;
var _c, _c2;
$RefreshReg$(_c, "ApprovalsModal");
$RefreshReg$(_c2, "ApprovalCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ApprovalsModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOERVLFNBMkJFLFVBM0JGOzs7Ozs7Ozs7Ozs7Ozs7OztBQTlEVixTQUFTQSxTQUFTQyxnQkFBZ0I7QUFDbEMsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLFdBQVc7QUFFcEIsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsYUFBYTtBQUN0QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFJUCxNQUFNQyxZQUE4QixDQUFDLFdBQVcsYUFBYSxZQUFZLFFBQVE7QUFDakYsTUFBTUMsWUFBNEM7QUFBQSxFQUNoREMsU0FBUztBQUFBLEVBQ1RDLFdBQVc7QUFBQSxFQUNYQyxVQUFVO0FBQUEsRUFDVkMsUUFBUTtBQUNWO0FBRU8sZ0JBQVNDLGVBQWU7QUFBQSxFQUM3QkM7QUFBQUEsRUFDQUM7QUFJRixHQUFHO0FBQUFDLEtBQUE7QUFDRCxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSXhCLFNBQXlCLFNBQVM7QUFFcEUsUUFBTXlCLFVBQVV2QjtBQUFBQSxJQUNkQyxJQUFJdUIsVUFBVUM7QUFBQUEsSUFDZFAsWUFBWSxFQUFFQSxXQUFXUSxRQUFRLFdBQVdDLE9BQU8sSUFBSSxJQUFJLEVBQUVELFFBQVEsV0FBV0MsT0FBTyxJQUFJO0FBQUEsRUFDN0Y7QUFDQSxRQUFNQyxZQUFZNUI7QUFBQUEsSUFDaEJDLElBQUl1QixVQUFVQztBQUFBQSxJQUNkUCxZQUFZLEVBQUVBLFdBQVdRLFFBQVEsYUFBYUMsT0FBTyxJQUFJLElBQUksRUFBRUQsUUFBUSxhQUFhQyxPQUFPLElBQUk7QUFBQSxFQUNqRztBQUNBLFFBQU1FLFdBQVc3QjtBQUFBQSxJQUNmQyxJQUFJdUIsVUFBVUM7QUFBQUEsSUFDZFAsWUFBWSxFQUFFQSxXQUFXUSxRQUFRLFlBQVlDLE9BQU8sSUFBSSxJQUFJLEVBQUVELFFBQVEsWUFBWUMsT0FBTyxJQUFJO0FBQUEsRUFDL0Y7QUFDQSxRQUFNRyxTQUFTOUI7QUFBQUEsSUFDYkMsSUFBSXVCLFVBQVVDO0FBQUFBLElBQ2RQLFlBQVksRUFBRUEsV0FBV1EsUUFBUSxVQUFVQyxPQUFPLElBQUksSUFBSSxFQUFFRCxRQUFRLFVBQVVDLE9BQU8sSUFBSTtBQUFBLEVBQzNGO0FBQ0EsUUFBTUksU0FBUy9CLFNBQVNDLElBQUk4QixPQUFPQyxTQUFTZCxZQUFZLEVBQUVBLFVBQVUsSUFBSSxDQUFDLENBQUM7QUFFMUUsUUFBTWUsa0JBQWtCbEMsWUFBWUUsSUFBSXVCLFVBQVVVLE9BQU87QUFDekQsUUFBTUMsZUFBZXBDLFlBQVlFLElBQUl1QixVQUFVWSxJQUFJO0FBRW5ELFFBQU1DLFlBQVksQ0FBQ2QsV0FBVyxDQUFDSyxhQUFhLENBQUNDLFlBQVksQ0FBQ0MsVUFBVSxDQUFDQztBQUVyRSxTQUNFLHVCQUFDLFVBQU8sTUFBSSxNQUFDLGNBQWMsQ0FBQ08sU0FBUztBQUFFLFFBQUksQ0FBQ0EsS0FBTW5CLFNBQVE7QUFBQSxFQUFHLEdBQzNELGlDQUFDLGlCQUFjLFdBQVUsNENBQ3ZCO0FBQUEsMkJBQUMsZ0JBQ0M7QUFBQSw2QkFBQyxlQUFZLGdDQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkI7QUFBQSxNQUM3Qix1QkFBQyxxQkFBaUIsOEVBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFFQ2tCLFlBQ0MsdUJBQUMsU0FBSSxXQUFVLHNDQUFxQyxvQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RSxLQUNyRSxNQUFNO0FBQ1QsWUFBTUUsV0FBVyxJQUFJQztBQUFBQSxRQUNsQlQsT0FBMkJVLElBQUksQ0FBQ0MsVUFBVSxDQUFDQSxNQUFNQyxLQUFLRCxLQUFLLENBQUM7QUFBQSxNQUMvRDtBQUNBLFlBQU1FLFdBQXVEO0FBQUEsUUFDM0QvQixTQUFTVTtBQUFBQSxRQUNUVCxXQUFXYztBQUFBQSxRQUNYYixVQUFVYztBQUFBQSxRQUNWYixRQUFRYztBQUFBQSxNQUNWO0FBQ0EsWUFBTWUsT0FBT0QsU0FBU3ZCLFNBQVM7QUFDL0IsWUFBTXlCLFNBQVM7QUFBQSxRQUNiakMsU0FBU1UsUUFBUXdCO0FBQUFBLFFBQ2pCakMsV0FBV2MsVUFBVW1CO0FBQUFBLFFBQ3JCaEMsVUFBVWMsU0FBU2tCO0FBQUFBLFFBQ25CL0IsUUFBUWMsT0FBT2lCO0FBQUFBLE1BQ2pCO0FBRUEsYUFDRSxtQ0FDRTtBQUFBLCtCQUFDLFNBQUksV0FBVSx3QkFBdUIsTUFBSyxXQUN4Q3BDLG9CQUFVOEI7QUFBQUEsVUFBSSxDQUFDZixXQUNkO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxNQUFLO0FBQUEsY0FDTCxpQkFBZUwsY0FBY0s7QUFBQUEsY0FDN0IsU0FBU0wsY0FBY0ssU0FBUyxZQUFZO0FBQUEsY0FDNUMsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNSixhQUFhSSxNQUFNO0FBQUEsY0FFakNkO0FBQUFBLDBCQUFVYyxNQUFNO0FBQUEsZ0JBQUU7QUFBQSxnQkFBR29CLE9BQU9wQixNQUFNO0FBQUEsZ0JBQUU7QUFBQTtBQUFBO0FBQUEsWUFQaENBO0FBQUFBLFlBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBO0FBQUEsUUFDRCxLQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBRUNtQixLQUFLRSxXQUFXLElBQ2YsdUJBQUMsT0FBRSxXQUFVLHNDQUFvQztBQUFBO0FBQUEsVUFDM0NuQyxVQUFVUyxTQUFTLEVBQUUyQixZQUFZO0FBQUEsVUFBRTtBQUFBLGFBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNaSCxlQUFLSjtBQUFBQSxVQUFJLENBQUNRLGFBQ1Q7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDO0FBQUEsY0FDQSxXQUFXVixTQUFTVyxJQUFJRCxTQUFTRSxnQkFBZ0I7QUFBQSxjQUNqRCxXQUFXOUIsY0FBYyxhQUFhQSxjQUFjO0FBQUEsY0FDcEQsV0FBVyxPQUFPK0IsV0FBVztBQUMzQix1QkFBTyxNQUFNbkIsZ0JBQWdCO0FBQUEsa0JBQzNCb0IsWUFBWUosU0FBU047QUFBQUEsa0JBQ3JCVyxpQkFBaUI7QUFBQSxrQkFDakJGO0FBQUFBLGdCQUNGLENBQUM7QUFBQSxjQUNIO0FBQUEsY0FDQSxRQUFRLE9BQU9BLFdBQVc7QUFDeEIsdUJBQU8sTUFBTWpCLGFBQWE7QUFBQSxrQkFDeEJrQixZQUFZSixTQUFTTjtBQUFBQSxrQkFDckJXLGlCQUFpQjtBQUFBLGtCQUNqQkY7QUFBQUEsZ0JBQ0YsQ0FBQztBQUFBLGNBQ0g7QUFBQTtBQUFBLFlBakJLSCxTQUFTTjtBQUFBQSxZQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0JJO0FBQUEsUUFFTCxLQXRCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUJBO0FBQUEsV0E1Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThDQTtBQUFBLElBRUosR0FBRztBQUFBLE9BN0VMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4RUEsS0EvRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdGQTtBQUVKO0FBQUN2QixHQW5IZUgsZ0JBQWM7QUFBQSxVQVNaakIsVUFJRUEsVUFJREEsVUFJRkEsVUFJQUEsVUFFU0QsYUFDSEEsV0FBVztBQUFBO0FBQUEsS0E1QmxCa0I7QUFxSGhCLFNBQVNzQyxhQUFhO0FBQUEsRUFDcEJOO0FBQUFBLEVBQ0FPO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBT0YsR0FBRztBQUFBQyxNQUFBO0FBQ0QsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUloRSxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDaUUsZUFBZUMsZ0JBQWdCLElBQUlsRSxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDbUUsWUFBWUMsYUFBYSxJQUFJcEUsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3FFLFVBQVVDLFdBQVcsSUFBSXRFLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUN1RSxPQUFPQyxRQUFRLElBQUl4RSxTQUF3QixJQUFJO0FBQ3RELFFBQU0sQ0FBQ3lFLE1BQU1DLE9BQU8sSUFBSTFFLFNBQXdCLElBQUk7QUFFcEQsUUFBTTJFLGFBQWE1RSxRQUFRLE1BQU07QUFDL0IsV0FBTyxJQUFJNkUsS0FBS3pCLFNBQVMwQixTQUFTLEVBQUVDLGVBQWU7QUFBQSxFQUNyRCxHQUFHLENBQUMzQixTQUFTMEIsU0FBUyxDQUFDO0FBRXZCLFFBQU1FLGNBQWM1QixTQUFTNkIsWUFBWSxJQUFJSixLQUFLekIsU0FBUzZCLFNBQVMsRUFBRUYsZUFBZSxJQUFJO0FBQ3pGLFFBQU1HLGdCQUFnQjlCLFNBQVMrQixjQUFjLElBQUlOLEtBQUt6QixTQUFTK0IsV0FBVyxFQUFFSixlQUFlLElBQUk7QUFDL0YsUUFBTUssbUJBQW1CQyxLQUFLQyxPQUFPbEMsU0FBUzBCLFlBQVlELEtBQUtVLElBQUksS0FBSyxHQUFLO0FBQzdFLFFBQU1DLG9CQUFvQnBDLFNBQVNxQyx5QkFBeUIsS0FBSztBQUVqRSxpQkFBZUMsZ0JBQWdCO0FBQzdCLFFBQUksQ0FBQ3hCLGNBQWN5QixLQUFLLEVBQUc7QUFDM0IxQixlQUFXLElBQUk7QUFDZlEsYUFBUyxJQUFJO0FBQ2JFLFlBQVEsSUFBSTtBQUNaLFFBQUk7QUFDRixZQUFNaUIsU0FBUyxNQUFNL0IsVUFBVUssY0FBY3lCLEtBQUssQ0FBQztBQUNuRCxVQUFJQyxRQUFRQyx1QkFBdUI7QUFDakNsQixnQkFBUSxrRUFBa0U7QUFBQSxNQUM1RSxPQUFPO0FBQ0xBLGdCQUFRLG9CQUFvQjtBQUFBLE1BQzlCO0FBQ0FSLHVCQUFpQixFQUFFO0FBQUEsSUFDckIsU0FBUzJCLEtBQUs7QUFDWnJCLGVBQVNxQixlQUFlQyxRQUFRRCxJQUFJRSxVQUFVLHNDQUFzQztBQUFBLElBQ3RGLFVBQUM7QUFDQy9CLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxpQkFBZWdDLGFBQWE7QUFDMUIsUUFBSSxDQUFDN0IsV0FBV3VCLEtBQUssRUFBRztBQUN4QjFCLGVBQVcsSUFBSTtBQUNmUSxhQUFTLElBQUk7QUFDYkUsWUFBUSxJQUFJO0FBQ1osUUFBSTtBQUNGLFlBQU1iLE9BQU9NLFdBQVd1QixLQUFLLENBQUM7QUFDOUJwQixrQkFBWSxLQUFLO0FBQ2pCRixvQkFBYyxFQUFFO0FBQ2hCTSxjQUFRLGtCQUFrQjtBQUFBLElBQzVCLFNBQVNtQixLQUFLO0FBQ1pyQixlQUFTcUIsZUFBZUMsUUFBUUQsSUFBSUUsVUFBVSxtQ0FBbUM7QUFBQSxJQUNuRixVQUFDO0FBQ0MvQixpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVzVEO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBK0MsU0FBU3ZCLFdBQVcsY0FBYyx5QkFBeUI7QUFBQSxNQUM3RDtBQUFBLE1BRUE7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsMkJBQ2I4QjtBQUFBQSx5QkFBV3VDLFFBQVEsR0FBR3ZDLFVBQVV1QyxLQUFLLE1BQU07QUFBQSxjQUFJdkMsV0FBV3dDLFFBQVE7QUFBQSxpQkFEckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsVUFBSyxXQUFVLGlDQUFnQztBQUFBO0FBQUEsY0FBRy9DLFNBQVNnRDtBQUFBQSxpQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUU7QUFBQSxZQUN2RTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVNoRCxTQUFTaUQsY0FBYyxRQUFRLGdCQUFnQjtBQUFBLGdCQUN4RCxXQUFVO0FBQUEsZ0JBRVRqRCxtQkFBU2lEO0FBQUFBO0FBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNDYixvQkFDQyx1QkFBQyxTQUFNLFNBQVEsV0FBVSxXQUFVLFdBQVMsNEJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FDRXBDLFNBQVN2QixXQUFXLGFBQWEsWUFDL0J1QixTQUFTdkIsV0FBVyxXQUFXLGdCQUMvQjtBQUFBLGNBRUosV0FBVTtBQUFBLGNBRVR1QixtQkFBU3ZCO0FBQUFBO0FBQUFBLFlBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0E7QUFBQSxhQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNEJBO0FBQUEsUUFFQSx1QkFBQyxPQUFFLFdBQVUsNEJBQTRCdUIsbUJBQVNrRCxpQkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRTtBQUFBLFFBRWhFLHVCQUFDLE9BQUUsV0FBVSw0REFDVmxELG1CQUFTbUQsaUJBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFQSx1QkFBQyxPQUFFLFdBQVdsRyxHQUFHLGdCQUFnQitFLG1CQUFtQixLQUFLLHFCQUFxQix1QkFBdUIsR0FBRTtBQUFBO0FBQUEsVUFDM0ZSO0FBQUFBLFVBQVc7QUFBQSxVQUFHUSxvQkFBb0IsSUFBSSxHQUFHQSxnQkFBZ0IsV0FBVztBQUFBLFVBQVU7QUFBQSxhQUQxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVDaEMsU0FBU3ZCLFdBQVcsZUFDbkIsdUJBQUMsT0FBRSxXQUFVLGtDQUFnQztBQUFBO0FBQUEsVUFDL0JxRCxpQkFBaUI7QUFBQSxVQUM1QjlCLFNBQVNvRCxtQkFBbUIsTUFBTXBELFNBQVNvRCxnQkFBZ0IsS0FBSztBQUFBLGFBRm5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBR0RwRCxTQUFTcUQsbUJBQ1IsdUJBQUMsT0FBRSxXQUFVLDRCQUEwQjtBQUFBO0FBQUEsVUFDcEJyRCxTQUFTc0QseUJBQXlCO0FBQUEsVUFBVztBQUFBLFVBQUssSUFBSTdCLEtBQUt6QixTQUFTcUQsZUFBZSxFQUFFMUIsZUFBZTtBQUFBLGFBRHZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBR0QsQ0FBQ25CLGFBQ0EsdUJBQUMsT0FBRSxXQUFVLG1DQUFpQztBQUFBO0FBQUEsVUFDMUJSLFNBQVN1RCxrQkFBa0I7QUFBQSxVQUM1QzNCLGNBQWMsTUFBTUEsV0FBVyxLQUFLO0FBQUEsYUFGdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFHRHBCLGFBQ0MsdUJBQUMsU0FBSSxXQUFVLG9DQUNaWTtBQUFBQSxtQkFDQyx1QkFBQyxTQUFJLFdBQVUsK0ZBQ1pBLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUdERSxRQUNDLHVCQUFDLFNBQUksV0FBVSxtRkFDWkEsa0JBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBR0QsQ0FBQ0osV0FDQSxtQ0FDRTtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT0o7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDMEMsVUFBVXpDLGlCQUFpQnlDLE1BQU1DLE9BQU9DLEtBQUs7QUFBQSxnQkFDeEQsYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQTtBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSWtCO0FBQUEsWUFFbEIsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBU3BCO0FBQUFBLGtCQUNULFVBQVUxQixXQUFXLENBQUNFLGNBQWN5QixLQUFLO0FBQUEsa0JBRXhDM0Isb0JBQVUsY0FBY3dCLG9CQUFvQixDQUFDcEMsU0FBU3FELGtCQUFrQix3QkFBd0I7QUFBQTtBQUFBLGdCQUxuRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVE7QUFBQSxrQkFDUixTQUFTLE1BQU1sQyxZQUFZLElBQUk7QUFBQSxrQkFDL0IsVUFBVVA7QUFBQUEsa0JBQVE7QUFBQTtBQUFBLGdCQUpwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLGlCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsZUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkEsSUFFQSxtQ0FDRTtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT0k7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDd0MsVUFBVXZDLGNBQWN1QyxNQUFNQyxPQUFPQyxLQUFLO0FBQUEsZ0JBQ3JELGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUE7QUFBQSxjQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlrQjtBQUFBLFlBRWxCLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVE7QUFBQSxrQkFDUixTQUFTYjtBQUFBQSxrQkFDVCxVQUFVakMsV0FBVyxDQUFDSSxXQUFXdUIsS0FBSztBQUFBLGtCQUVyQzNCLG9CQUFVLGNBQWM7QUFBQTtBQUFBLGdCQU4zQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVE7QUFBQSxrQkFDUixTQUFTLE1BQU07QUFBRU8sZ0NBQVksS0FBSztBQUFHRixrQ0FBYyxFQUFFO0FBQUEsa0JBQUc7QUFBQSxrQkFDeEQsVUFBVUw7QUFBQUEsa0JBQVE7QUFBQTtBQUFBLGdCQUpwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLGlCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLGVBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBO0FBQUEsYUFqRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1FQTtBQUFBO0FBQUE7QUFBQSxJQXRJSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUF3SUE7QUFFSjtBQUFDRCxJQTdNUUwsY0FBWTtBQUFBLE1BQVpBO0FBQVksSUFBQXFELElBQUFDO0FBQUEsYUFBQUQsSUFBQTtBQUFBLGFBQUFDLEtBQUEiLCJuYW1lcyI6WyJ1c2VNZW1vIiwidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsInVzZVF1ZXJ5IiwiYXBpIiwiY24iLCJCYWRnZSIsIkJ1dHRvbiIsIklucHV0IiwiRGlhbG9nIiwiRGlhbG9nQ29udGVudCIsIkRpYWxvZ0hlYWRlciIsIkRpYWxvZ1RpdGxlIiwiRGlhbG9nRGVzY3JpcHRpb24iLCJUQUJfT1JERVIiLCJUQUJfTEFCRUwiLCJQRU5ESU5HIiwiRVNDQUxBVEVEIiwiQVBQUk9WRUQiLCJERU5JRUQiLCJBcHByb3ZhbHNNb2RhbCIsInByb2plY3RJZCIsIm9uQ2xvc2UiLCJfcyIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsInBlbmRpbmciLCJhcHByb3ZhbHMiLCJsaXN0QnlTdGF0dXMiLCJzdGF0dXMiLCJsaW1pdCIsImVzY2FsYXRlZCIsImFwcHJvdmVkIiwiZGVuaWVkIiwiYWdlbnRzIiwibGlzdEFsbCIsImFwcHJvdmVNdXRhdGlvbiIsImFwcHJvdmUiLCJkZW55TXV0YXRpb24iLCJkZW55IiwiaXNMb2FkaW5nIiwib3BlbiIsImFnZW50TWFwIiwiTWFwIiwibWFwIiwiYWdlbnQiLCJfaWQiLCJieVN0YXR1cyIsInJvd3MiLCJjb3VudHMiLCJsZW5ndGgiLCJ0b0xvd2VyQ2FzZSIsImFwcHJvdmFsIiwiZ2V0IiwicmVxdWVzdG9yQWdlbnRJZCIsInJlYXNvbiIsImFwcHJvdmFsSWQiLCJkZWNpZGVkQnlVc2VySWQiLCJBcHByb3ZhbENhcmQiLCJyZXF1ZXN0b3IiLCJjYW5EZWNpZGUiLCJvbkFwcHJvdmUiLCJvbkRlbnkiLCJfczIiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImFwcHJvdmVSZWFzb24iLCJzZXRBcHByb3ZlUmVhc29uIiwiZGVueVJlYXNvbiIsInNldERlbnlSZWFzb24iLCJzaG93RGVueSIsInNldFNob3dEZW55IiwiZXJyb3IiLCJzZXRFcnJvciIsImluZm8iLCJzZXRJbmZvIiwiZXhwaXJ5VGV4dCIsIkRhdGUiLCJleHBpcmVzQXQiLCJ0b0xvY2FsZVN0cmluZyIsImRlY2lkZWRUZXh0IiwiZGVjaWRlZEF0IiwiZXNjYWxhdGVkVGV4dCIsImVzY2FsYXRlZEF0IiwibWludXRlc1JlbWFpbmluZyIsIk1hdGgiLCJmbG9vciIsIm5vdyIsIm5lZWRzRHVhbENvbnRyb2wiLCJyZXF1aXJlZERlY2lzaW9uQ291bnQiLCJoYW5kbGVBcHByb3ZlIiwidHJpbSIsInJlc3VsdCIsInBlbmRpbmdTZWNvbmREZWNpc2lvbiIsImVyciIsIkVycm9yIiwibWVzc2FnZSIsImhhbmRsZURlbnkiLCJlbW9qaSIsIm5hbWUiLCJhY3Rpb25UeXBlIiwicmlza0xldmVsIiwiYWN0aW9uU3VtbWFyeSIsImp1c3RpZmljYXRpb24iLCJlc2NhbGF0aW9uUmVhc29uIiwiZmlyc3REZWNpc2lvbkF0IiwiZmlyc3REZWNpc2lvbkJ5VXNlcklkIiwiZGVjaXNpb25SZWFzb24iLCJldmVudCIsInRhcmdldCIsInZhbHVlIiwiX2MiLCJfYzIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXBwcm92YWxzTW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnkgfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IERvYywgSWQgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvZGF0YU1vZGVsXCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiO1xuaW1wb3J0IHsgQmFkZ2UgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2JhZGdlXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2lucHV0XCI7XG5pbXBvcnQge1xuICBEaWFsb2csXG4gIERpYWxvZ0NvbnRlbnQsXG4gIERpYWxvZ0hlYWRlcixcbiAgRGlhbG9nVGl0bGUsXG4gIERpYWxvZ0Rlc2NyaXB0aW9uLFxufSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2RpYWxvZ1wiO1xuXG50eXBlIEFwcHJvdmFsU3RhdHVzID0gXCJQRU5ESU5HXCIgfCBcIkVTQ0FMQVRFRFwiIHwgXCJBUFBST1ZFRFwiIHwgXCJERU5JRURcIjtcblxuY29uc3QgVEFCX09SREVSOiBBcHByb3ZhbFN0YXR1c1tdID0gW1wiUEVORElOR1wiLCBcIkVTQ0FMQVRFRFwiLCBcIkFQUFJPVkVEXCIsIFwiREVOSUVEXCJdO1xuY29uc3QgVEFCX0xBQkVMOiBSZWNvcmQ8QXBwcm92YWxTdGF0dXMsIHN0cmluZz4gPSB7XG4gIFBFTkRJTkc6IFwiUGVuZGluZ1wiLFxuICBFU0NBTEFURUQ6IFwiRXNjYWxhdGVkXCIsXG4gIEFQUFJPVkVEOiBcIkFwcHJvdmVkXCIsXG4gIERFTklFRDogXCJEZW5pZWRcIixcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBBcHByb3ZhbHNNb2RhbCh7XG4gIHByb2plY3RJZCxcbiAgb25DbG9zZSxcbn06IHtcbiAgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+IHwgbnVsbDtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlPEFwcHJvdmFsU3RhdHVzPihcIlBFTkRJTkdcIik7XG5cbiAgY29uc3QgcGVuZGluZyA9IHVzZVF1ZXJ5KFxuICAgIGFwaS5hcHByb3ZhbHMubGlzdEJ5U3RhdHVzLFxuICAgIHByb2plY3RJZCA/IHsgcHJvamVjdElkLCBzdGF0dXM6IFwiUEVORElOR1wiLCBsaW1pdDogMTAwIH0gOiB7IHN0YXR1czogXCJQRU5ESU5HXCIsIGxpbWl0OiAxMDAgfVxuICApO1xuICBjb25zdCBlc2NhbGF0ZWQgPSB1c2VRdWVyeShcbiAgICBhcGkuYXBwcm92YWxzLmxpc3RCeVN0YXR1cyxcbiAgICBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCwgc3RhdHVzOiBcIkVTQ0FMQVRFRFwiLCBsaW1pdDogMTAwIH0gOiB7IHN0YXR1czogXCJFU0NBTEFURURcIiwgbGltaXQ6IDEwMCB9XG4gICk7XG4gIGNvbnN0IGFwcHJvdmVkID0gdXNlUXVlcnkoXG4gICAgYXBpLmFwcHJvdmFscy5saXN0QnlTdGF0dXMsXG4gICAgcHJvamVjdElkID8geyBwcm9qZWN0SWQsIHN0YXR1czogXCJBUFBST1ZFRFwiLCBsaW1pdDogMTAwIH0gOiB7IHN0YXR1czogXCJBUFBST1ZFRFwiLCBsaW1pdDogMTAwIH1cbiAgKTtcbiAgY29uc3QgZGVuaWVkID0gdXNlUXVlcnkoXG4gICAgYXBpLmFwcHJvdmFscy5saXN0QnlTdGF0dXMsXG4gICAgcHJvamVjdElkID8geyBwcm9qZWN0SWQsIHN0YXR1czogXCJERU5JRURcIiwgbGltaXQ6IDEwMCB9IDogeyBzdGF0dXM6IFwiREVOSUVEXCIsIGxpbWl0OiAxMDAgfVxuICApO1xuICBjb25zdCBhZ2VudHMgPSB1c2VRdWVyeShhcGkuYWdlbnRzLmxpc3RBbGwsIHByb2plY3RJZCA/IHsgcHJvamVjdElkIH0gOiB7fSk7XG5cbiAgY29uc3QgYXBwcm92ZU11dGF0aW9uID0gdXNlTXV0YXRpb24oYXBpLmFwcHJvdmFscy5hcHByb3ZlKTtcbiAgY29uc3QgZGVueU11dGF0aW9uID0gdXNlTXV0YXRpb24oYXBpLmFwcHJvdmFscy5kZW55KTtcblxuICBjb25zdCBpc0xvYWRpbmcgPSAhcGVuZGluZyB8fCAhZXNjYWxhdGVkIHx8ICFhcHByb3ZlZCB8fCAhZGVuaWVkIHx8ICFhZ2VudHM7XG5cbiAgcmV0dXJuIChcbiAgICA8RGlhbG9nIG9wZW4gb25PcGVuQ2hhbmdlPXsob3BlbikgPT4geyBpZiAoIW9wZW4pIG9uQ2xvc2UoKTsgfX0+XG4gICAgICA8RGlhbG9nQ29udGVudCBjbGFzc05hbWU9XCJtYXgtdy1bOTAwcHhdIG1heC1oLVs5MHZoXSBvdmVyZmxvdy1hdXRvXCI+XG4gICAgICAgIDxEaWFsb2dIZWFkZXI+XG4gICAgICAgICAgPERpYWxvZ1RpdGxlPkFwcHJvdmFscyBDZW50ZXI8L0RpYWxvZ1RpdGxlPlxuICAgICAgICAgIDxEaWFsb2dEZXNjcmlwdGlvbj5cbiAgICAgICAgICAgIEVzY2FsYXRlZCBhcHByb3ZhbHMgYnJlYWNoZWQgU0xBIGFuZCBzaG91bGQgYmUgYWN0aW9uZWQgZmlyc3QuXG4gICAgICAgICAgPC9EaWFsb2dEZXNjcmlwdGlvbj5cbiAgICAgICAgPC9EaWFsb2dIZWFkZXI+XG5cbiAgICAgICAge2lzTG9hZGluZyA/IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5Mb2FkaW5nIGFwcHJvdmFscy4uLjwvZGl2PlxuICAgICAgICApIDogKCgpID0+IHtcbiAgICAgICAgICBjb25zdCBhZ2VudE1hcCA9IG5ldyBNYXA8SWQ8XCJhZ2VudHNcIj4sIERvYzxcImFnZW50c1wiPj4oXG4gICAgICAgICAgICAoYWdlbnRzIGFzIERvYzxcImFnZW50c1wiPltdKS5tYXAoKGFnZW50KSA9PiBbYWdlbnQuX2lkLCBhZ2VudF0pXG4gICAgICAgICAgKTtcbiAgICAgICAgICBjb25zdCBieVN0YXR1czogUmVjb3JkPEFwcHJvdmFsU3RhdHVzLCBEb2M8XCJhcHByb3ZhbHNcIj5bXT4gPSB7XG4gICAgICAgICAgICBQRU5ESU5HOiBwZW5kaW5nLFxuICAgICAgICAgICAgRVNDQUxBVEVEOiBlc2NhbGF0ZWQsXG4gICAgICAgICAgICBBUFBST1ZFRDogYXBwcm92ZWQsXG4gICAgICAgICAgICBERU5JRUQ6IGRlbmllZCxcbiAgICAgICAgICB9O1xuICAgICAgICAgIGNvbnN0IHJvd3MgPSBieVN0YXR1c1thY3RpdmVUYWJdO1xuICAgICAgICAgIGNvbnN0IGNvdW50cyA9IHtcbiAgICAgICAgICAgIFBFTkRJTkc6IHBlbmRpbmcubGVuZ3RoLFxuICAgICAgICAgICAgRVNDQUxBVEVEOiBlc2NhbGF0ZWQubGVuZ3RoLFxuICAgICAgICAgICAgQVBQUk9WRUQ6IGFwcHJvdmVkLmxlbmd0aCxcbiAgICAgICAgICAgIERFTklFRDogZGVuaWVkLmxlbmd0aCxcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMiBmbGV4LXdyYXBcIiByb2xlPVwidGFibGlzdFwiPlxuICAgICAgICAgICAgICAgIHtUQUJfT1JERVIubWFwKChzdGF0dXMpID0+IChcbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAga2V5PXtzdGF0dXN9XG4gICAgICAgICAgICAgICAgICAgIHJvbGU9XCJ0YWJcIlxuICAgICAgICAgICAgICAgICAgICBhcmlhLXNlbGVjdGVkPXthY3RpdmVUYWIgPT09IHN0YXR1c31cbiAgICAgICAgICAgICAgICAgICAgdmFyaWFudD17YWN0aXZlVGFiID09PSBzdGF0dXMgPyBcImRlZmF1bHRcIiA6IFwib3V0bGluZVwifVxuICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoc3RhdHVzKX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge1RBQl9MQUJFTFtzdGF0dXNdfSAoe2NvdW50c1tzdGF0dXNdfSlcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7cm93cy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmQgcHktNFwiPlxuICAgICAgICAgICAgICAgICAgTm8ge1RBQl9MQUJFTFthY3RpdmVUYWJdLnRvTG93ZXJDYXNlKCl9IGFwcHJvdmFscy5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgIHtyb3dzLm1hcCgoYXBwcm92YWwpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPEFwcHJvdmFsQ2FyZFxuICAgICAgICAgICAgICAgICAgICAgIGtleT17YXBwcm92YWwuX2lkfVxuICAgICAgICAgICAgICAgICAgICAgIGFwcHJvdmFsPXthcHByb3ZhbH1cbiAgICAgICAgICAgICAgICAgICAgICByZXF1ZXN0b3I9e2FnZW50TWFwLmdldChhcHByb3ZhbC5yZXF1ZXN0b3JBZ2VudElkKX1cbiAgICAgICAgICAgICAgICAgICAgICBjYW5EZWNpZGU9e2FjdGl2ZVRhYiA9PT0gXCJQRU5ESU5HXCIgfHwgYWN0aXZlVGFiID09PSBcIkVTQ0FMQVRFRFwifVxuICAgICAgICAgICAgICAgICAgICAgIG9uQXBwcm92ZT17YXN5bmMgKHJlYXNvbikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGF3YWl0IGFwcHJvdmVNdXRhdGlvbih7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFwcHJvdmFsSWQ6IGFwcHJvdmFsLl9pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGVjaWRlZEJ5VXNlcklkOiBcIm9wZXJhdG9yXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlYXNvbixcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgb25EZW55PXthc3luYyAocmVhc29uKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYXdhaXQgZGVueU11dGF0aW9uKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYXBwcm92YWxJZDogYXBwcm92YWwuX2lkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBkZWNpZGVkQnlVc2VySWQ6IFwib3BlcmF0b3JcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhc29uLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC8+XG4gICAgICAgICAgKTtcbiAgICAgICAgfSkoKX1cbiAgICAgIDwvRGlhbG9nQ29udGVudD5cbiAgICA8L0RpYWxvZz5cbiAgKTtcbn1cblxuZnVuY3Rpb24gQXBwcm92YWxDYXJkKHtcbiAgYXBwcm92YWwsXG4gIHJlcXVlc3RvcixcbiAgY2FuRGVjaWRlLFxuICBvbkFwcHJvdmUsXG4gIG9uRGVueSxcbn06IHtcbiAgYXBwcm92YWw6IERvYzxcImFwcHJvdmFsc1wiPjtcbiAgcmVxdWVzdG9yOiBEb2M8XCJhZ2VudHNcIj4gfCB1bmRlZmluZWQ7XG4gIGNhbkRlY2lkZTogYm9vbGVhbjtcbiAgb25BcHByb3ZlOiAocmVhc29uOiBzdHJpbmcpID0+IFByb21pc2U8YW55PjtcbiAgb25EZW55OiAocmVhc29uOiBzdHJpbmcpID0+IFByb21pc2U8YW55Pjtcbn0pIHtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbYXBwcm92ZVJlYXNvbiwgc2V0QXBwcm92ZVJlYXNvbl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2RlbnlSZWFzb24sIHNldERlbnlSZWFzb25dID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtzaG93RGVueSwgc2V0U2hvd0RlbnldID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbaW5mbywgc2V0SW5mb10gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBleHBpcnlUZXh0ID0gdXNlTWVtbygoKSA9PiB7XG4gICAgcmV0dXJuIG5ldyBEYXRlKGFwcHJvdmFsLmV4cGlyZXNBdCkudG9Mb2NhbGVTdHJpbmcoKTtcbiAgfSwgW2FwcHJvdmFsLmV4cGlyZXNBdF0pO1xuXG4gIGNvbnN0IGRlY2lkZWRUZXh0ID0gYXBwcm92YWwuZGVjaWRlZEF0ID8gbmV3IERhdGUoYXBwcm92YWwuZGVjaWRlZEF0KS50b0xvY2FsZVN0cmluZygpIDogbnVsbDtcbiAgY29uc3QgZXNjYWxhdGVkVGV4dCA9IGFwcHJvdmFsLmVzY2FsYXRlZEF0ID8gbmV3IERhdGUoYXBwcm92YWwuZXNjYWxhdGVkQXQpLnRvTG9jYWxlU3RyaW5nKCkgOiBudWxsO1xuICBjb25zdCBtaW51dGVzUmVtYWluaW5nID0gTWF0aC5mbG9vcigoYXBwcm92YWwuZXhwaXJlc0F0IC0gRGF0ZS5ub3coKSkgLyA2MDAwMCk7XG4gIGNvbnN0IG5lZWRzRHVhbENvbnRyb2wgPSAoYXBwcm92YWwucmVxdWlyZWREZWNpc2lvbkNvdW50ID8/IDEpID4gMTtcblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVBcHByb3ZlKCkge1xuICAgIGlmICghYXBwcm92ZVJlYXNvbi50cmltKCkpIHJldHVybjtcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgIHNldEVycm9yKG51bGwpO1xuICAgIHNldEluZm8obnVsbCk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IG9uQXBwcm92ZShhcHByb3ZlUmVhc29uLnRyaW0oKSk7XG4gICAgICBpZiAocmVzdWx0Py5wZW5kaW5nU2Vjb25kRGVjaXNpb24pIHtcbiAgICAgICAgc2V0SW5mbyhcIkZpcnN0IGFwcHJvdmFsIHJlY29yZGVkLiBBIHNlY29uZCBkaXN0aW5jdCBhcHByb3ZlciBpcyByZXF1aXJlZC5cIik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRJbmZvKFwiQXBwcm92YWwgcmVjb3JkZWQuXCIpO1xuICAgICAgfVxuICAgICAgc2V0QXBwcm92ZVJlYXNvbihcIlwiKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBcIkZhaWxlZCB0byBhcHByb3ZlLiBQbGVhc2UgdHJ5IGFnYWluLlwiKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlRGVueSgpIHtcbiAgICBpZiAoIWRlbnlSZWFzb24udHJpbSgpKSByZXR1cm47XG4gICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICBzZXRFcnJvcihudWxsKTtcbiAgICBzZXRJbmZvKG51bGwpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBvbkRlbnkoZGVueVJlYXNvbi50cmltKCkpO1xuICAgICAgc2V0U2hvd0RlbnkoZmFsc2UpO1xuICAgICAgc2V0RGVueVJlYXNvbihcIlwiKTtcbiAgICAgIHNldEluZm8oXCJBcHByb3ZhbCBkZW5pZWQuXCIpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6IFwiRmFpbGVkIHRvIGRlbnkuIFBsZWFzZSB0cnkgYWdhaW4uXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwicC00IHJvdW5kZWQtbGcgYm9yZGVyIGJnLWNhcmRcIixcbiAgICAgICAgYXBwcm92YWwuc3RhdHVzID09PSBcIkVTQ0FMQVRFRFwiID8gXCJib3JkZXItb3JhbmdlLTUwMC81MFwiIDogXCJib3JkZXItYm9yZGVyXCJcbiAgICAgICl9XG4gICAgPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LXdyYXBcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAge3JlcXVlc3Rvcj8uZW1vamkgPyBgJHtyZXF1ZXN0b3IuZW1vaml9IGAgOiBcIlwifXtyZXF1ZXN0b3I/Lm5hbWUgPz8gXCJBZ2VudFwifVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPsK3IHthcHByb3ZhbC5hY3Rpb25UeXBlfTwvc3Bhbj5cbiAgICAgICAgICA8QmFkZ2VcbiAgICAgICAgICAgIHZhcmlhbnQ9e2FwcHJvdmFsLnJpc2tMZXZlbCA9PT0gXCJSRURcIiA/IFwiZGVzdHJ1Y3RpdmVcIiA6IFwic2Vjb25kYXJ5XCJ9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICB7YXBwcm92YWwucmlza0xldmVsfVxuICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAge25lZWRzRHVhbENvbnRyb2wgJiYgKFxuICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCIgY2xhc3NOYW1lPVwidGV4dC14c1wiPlxuICAgICAgICAgICAgICBEVUFMIENPTlRST0xcbiAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxCYWRnZVxuICAgICAgICAgIHZhcmlhbnQ9e1xuICAgICAgICAgICAgYXBwcm92YWwuc3RhdHVzID09PSBcIkFQUFJPVkVEXCIgPyBcImRlZmF1bHRcIlxuICAgICAgICAgICAgOiBhcHByb3ZhbC5zdGF0dXMgPT09IFwiREVOSUVEXCIgPyBcImRlc3RydWN0aXZlXCJcbiAgICAgICAgICAgIDogXCJzZWNvbmRhcnlcIlxuICAgICAgICAgIH1cbiAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzXCJcbiAgICAgICAgPlxuICAgICAgICAgIHthcHByb3ZhbC5zdGF0dXN9XG4gICAgICAgIDwvQmFkZ2U+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1zbSBtdC0yXCI+e2FwcHJvdmFsLmFjdGlvblN1bW1hcnl9PC9wPlxuXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtdC0xLjUgd2hpdGVzcGFjZS1wcmUtd3JhcFwiPlxuICAgICAgICB7YXBwcm92YWwuanVzdGlmaWNhdGlvbn1cbiAgICAgIDwvcD5cblxuICAgICAgPHAgY2xhc3NOYW1lPXtjbihcInRleHQteHMgbXQtMlwiLCBtaW51dGVzUmVtYWluaW5nIDwgMTAgPyBcInRleHQtZGVzdHJ1Y3RpdmVcIiA6IFwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIpfT5cbiAgICAgICAgRXhwaXJlczoge2V4cGlyeVRleHR9ICh7bWludXRlc1JlbWFpbmluZyA+PSAwID8gYCR7bWludXRlc1JlbWFpbmluZ31tIGxlZnRgIDogXCJleHBpcmVkXCJ9KVxuICAgICAgPC9wPlxuXG4gICAgICB7YXBwcm92YWwuc3RhdHVzID09PSBcIkVTQ0FMQVRFRFwiICYmIChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW9yYW5nZS00MDAgbXQtMS41XCI+XG4gICAgICAgICAgRXNjYWxhdGVkOiB7ZXNjYWxhdGVkVGV4dCA/PyBcIm5vd1wifVxuICAgICAgICAgIHthcHByb3ZhbC5lc2NhbGF0aW9uUmVhc29uID8gYCDCtyAke2FwcHJvdmFsLmVzY2FsYXRpb25SZWFzb259YCA6IFwiXCJ9XG4gICAgICAgIDwvcD5cbiAgICAgICl9XG5cbiAgICAgIHthcHByb3ZhbC5maXJzdERlY2lzaW9uQXQgJiYgKFxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtd2FybiBtdC0xLjVcIj5cbiAgICAgICAgICBGaXJzdCBhcHByb3ZhbDoge2FwcHJvdmFsLmZpcnN0RGVjaXNpb25CeVVzZXJJZCA/PyBcIm9wZXJhdG9yXCJ9IGF0IHtuZXcgRGF0ZShhcHByb3ZhbC5maXJzdERlY2lzaW9uQXQpLnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgIDwvcD5cbiAgICAgICl9XG5cbiAgICAgIHshY2FuRGVjaWRlICYmIChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWZvcmVncm91bmQvNzAgbXQtMlwiPlxuICAgICAgICAgIERlY2lzaW9uIHJlYXNvbjoge2FwcHJvdmFsLmRlY2lzaW9uUmVhc29uIHx8IFwiTm8gcmVhc29uIHByb3ZpZGVkXCJ9XG4gICAgICAgICAge2RlY2lkZWRUZXh0ID8gYCDCtyAke2RlY2lkZWRUZXh0fWAgOiBcIlwifVxuICAgICAgICA8L3A+XG4gICAgICApfVxuXG4gICAgICB7Y2FuRGVjaWRlICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHB0LTMgYm9yZGVyLXQgYm9yZGVyLWJvcmRlclwiPlxuICAgICAgICAgIHtlcnJvciAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTIgcC0yIGJnLWRlc3RydWN0aXZlLzEwIGJvcmRlciBib3JkZXItZGVzdHJ1Y3RpdmUvMjAgcm91bmRlZC1tZCB0ZXh0LXhzIHRleHQtZGVzdHJ1Y3RpdmVcIj5cbiAgICAgICAgICAgICAge2Vycm9yfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHtpbmZvICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMiBwLTIgYmctcHJpbWFyeS8xMCBib3JkZXIgYm9yZGVyLXByaW1hcnkvMjAgcm91bmRlZC1tZCB0ZXh0LXhzIHRleHQtcHJpbWFyeVwiPlxuICAgICAgICAgICAgICB7aW5mb31cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7IXNob3dEZW55ID8gKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgdmFsdWU9e2FwcHJvdmVSZWFzb259XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0QXBwcm92ZVJlYXNvbihldmVudC50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQXBwcm92YWwgcmVhc29uIChyZXF1aXJlZClcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTJcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQXBwcm92ZX1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nIHx8ICFhcHByb3ZlUmVhc29uLnRyaW0oKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7bG9hZGluZyA/IFwiU2F2aW5nLi4uXCIgOiBuZWVkc0R1YWxDb250cm9sICYmICFhcHByb3ZhbC5maXJzdERlY2lzaW9uQXQgPyBcIlJlY29yZCAxc3QgQXBwcm92YWxcIiA6IFwiQXBwcm92ZVwifVxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwiZGVzdHJ1Y3RpdmVcIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0RlbnkodHJ1ZSl9XG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBEZW55XG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC8+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgIHZhbHVlPXtkZW55UmVhc29ufVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldERlbnlSZWFzb24oZXZlbnQudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRlbmlhbCByZWFzb24gKHJlcXVpcmVkKVwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMlwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwiZGVzdHJ1Y3RpdmVcIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRGVueX1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nIHx8ICFkZW55UmVhc29uLnRyaW0oKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7bG9hZGluZyA/IFwiU2F2aW5nLi4uXCIgOiBcIkNvbmZpcm0gRGVueVwifVxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldFNob3dEZW55KGZhbHNlKTsgc2V0RGVueVJlYXNvbihcIlwiKTsgfX1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL0FwcHJvdmFsc01vZGFsLnRzeCJ9