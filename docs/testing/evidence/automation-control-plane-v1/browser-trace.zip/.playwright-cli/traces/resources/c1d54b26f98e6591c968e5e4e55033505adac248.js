import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ImportPrdModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"]; const useRef = __vite__cjsImport3_react["useRef"];
import { useAction, useMutation } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { Button } from "/src/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "/src/components/ui/dialog.tsx";
import { Textarea } from "/src/components/ui/textarea.tsx";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "/src/components/ui/table.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
import { Loader2, FileUp, Trash2 } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
const TASK_TYPES = [
  "ENGINEERING",
  "CONTENT",
  "DOCS",
  "OPS",
  "SOCIAL",
  "EMAIL_MARKETING",
  "CUSTOMER_RESEARCH",
  "SEO_RESEARCH"
];
const PRIORITIES = [
  { value: 1, label: "Critical" },
  { value: 2, label: "High" },
  { value: 3, label: "Normal" },
  { value: 4, label: "Low" }
];
export function ImportPrdModal({
  projectId,
  onClose,
  onCreated
}) {
  _s();
  const [step, setStep] = useState("input");
  const [content, setContent] = useState("");
  const [tasks, setTasks] = useState([]);
  const [parseLoading, setParseLoading] = useState(false);
  const [createLoading, setCreateLoading] = useState(false);
  const [error, setError] = useState(null);
  const fileInputRef = useRef(null);
  const parsePrd = useAction(api.prd.parsePrd);
  const storePrdDocument = useMutation(api.prd.storePrdDocument);
  const bulkCreateFromPrd = useMutation(api.prd.bulkCreateFromPrd);
  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setContent(String(reader.result ?? ""));
      setError(null);
    };
    reader.readAsText(file);
    e.target.value = "";
  };
  const handleParse = async () => {
    const text = content.trim();
    if (!text) {
      setError("Paste or upload PRD content first.");
      return;
    }
    setParseLoading(true);
    setError(null);
    try {
      const result = await parsePrd({ content: text, maxTasks: 25 });
      const rows = (result.tasks ?? []).map((t) => ({
        title: t.title,
        description: t.description,
        type: t.type,
        priority: t.priority,
        dependencyIndices: t.dependencyIndices
      }));
      if (rows.length === 0) {
        setError(
          "No actionable requirements were found. Use FR-1 style requirements, numbered sections, or Markdown headings."
        );
        return;
      }
      setTasks(rows);
      setStep("preview");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to parse PRD");
    } finally {
      setParseLoading(false);
    }
  };
  const updateTask = (index, patch) => {
    setTasks(
      (prev) => prev.map((t, i) => i === index ? { ...t, ...patch } : t)
    );
  };
  const removeTask = (index) => {
    setTasks((prev) => prev.filter((_, i) => i !== index));
  };
  const handleCreateAll = async () => {
    if (tasks.length === 0) {
      setError("No tasks to create.");
      return;
    }
    setCreateLoading(true);
    setError(null);
    try {
      const productName = content.match(/(?:^|\n)\s*(?:\d+\.\s+)?Product Name\s*\n+\s*([^\n]+)/i)?.[1]?.trim();
      const title = productName || content.match(/^#\s+(.+)$/m)?.[1]?.trim() || "Imported PRD";
      const storedDocument = await storePrdDocument({
        projectId: projectId ?? void 0,
        title,
        content,
        taskCount: tasks.length,
        createdBy: "HUMAN"
      });
      const result = await bulkCreateFromPrd({
        projectId: projectId ?? void 0,
        prdDocumentId: storedDocument.prdDocumentId,
        tasks: tasks.map((t) => ({
          title: t.title,
          description: t.description,
          type: t.type,
          priority: t.priority,
          dependencyIndices: t.dependencyIndices
        })),
        createdBy: "HUMAN"
      });
      onCreated?.(result.createdCount);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to create tasks");
    } finally {
      setCreateLoading(false);
    }
  };
  const backToInput = () => {
    setStep("input");
    setTasks([]);
    setError(null);
  };
  return /* @__PURE__ */ jsxDEV(Dialog, { open: true, onOpenChange: (open) => {
    if (!open) onClose();
  }, children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "max-h-[90vh] overflow-y-auto sm:max-w-[720px]", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: step === "input" ? "Import PRD" : "Review tasks" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
        lineNumber: 202,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: step === "input" ? "Paste markdown or upload a .md file. We'll parse it into tasks." : "Edit types and priorities, then create all tasks in INBOX." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
        lineNumber: 205,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
      lineNumber: 201,
      columnNumber: 9
    }, this),
    step === "input" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV(
          Textarea,
          {
            placeholder: "Paste your PRD markdown here...",
            value: content,
            onChange: (e) => setContent(e.target.value),
            className: "min-h-[200px] font-mono text-sm",
            disabled: parseLoading
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
            lineNumber: 215,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              ref: fileInputRef,
              type: "file",
              accept: ".md,text/markdown,text/plain",
              className: "hidden",
              onChange: handleFileChange
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
              lineNumber: 223,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "button",
              variant: "outline",
              size: "sm",
              onClick: () => fileInputRef.current?.click(),
              disabled: parseLoading,
              children: [
                /* @__PURE__ */ jsxDEV(FileUp, { className: "h-4 w-4 mr-1" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
                  lineNumber: 237,
                  columnNumber: 19
                }, this),
                "Upload .md"
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
              lineNumber: 230,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
          lineNumber: 222,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
        lineNumber: 214,
        columnNumber: 13
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-destructive", role: "alert", children: error }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
        lineNumber: 243,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "outline", onClick: onClose, children: "Cancel" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
          lineNumber: 248,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { onClick: handleParse, disabled: parseLoading || !content.trim(), children: parseLoading ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(Loader2, { className: "h-4 w-4 mr-2 animate-spin" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
            lineNumber: 254,
            columnNumber: 21
          }, this),
          "Parsing…"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
          lineNumber: 253,
          columnNumber: 15
        }, this) : "Parse" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
          lineNumber: 251,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
        lineNumber: 247,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
      lineNumber: 213,
      columnNumber: 9
    }, this),
    step === "preview" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "border rounded-md overflow-auto max-h-[360px]", children: /* @__PURE__ */ jsxDEV(Table, { children: [
        /* @__PURE__ */ jsxDEV(TableHeader, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableHead, { className: "w-[8%]", children: "Priority" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
            lineNumber: 271,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(TableHead, { className: "w-[18%]", children: "Type" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
            lineNumber: 272,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(TableHead, { children: "Title" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
            lineNumber: 273,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV(TableHead, { className: "w-[60px]" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
            lineNumber: 274,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
          lineNumber: 270,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
          lineNumber: 269,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TableBody, { children: tasks.map(
          (t, i) => /* @__PURE__ */ jsxDEV(TableRow, { children: [
            /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: String(t.priority),
                onValueChange: (v) => updateTask(i, { priority: Number(v) }),
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-8", children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
                    lineNumber: 286,
                    columnNumber: 29
                  }, this) }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
                    lineNumber: 285,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: PRIORITIES.map(
                    (p) => /* @__PURE__ */ jsxDEV(SelectItem, { value: String(p.value), children: p.label }, p.value, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
                      lineNumber: 290,
                      columnNumber: 25
                    }, this)
                  ) }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
                    lineNumber: 288,
                    columnNumber: 27
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
                lineNumber: 281,
                columnNumber: 25
              },
              this
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
              lineNumber: 280,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: t.type,
                onValueChange: (v) => updateTask(i, { type: v }),
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-8", children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
                    lineNumber: 303,
                    columnNumber: 29
                  }, this) }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
                    lineNumber: 302,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: TASK_TYPES.map(
                    (type) => /* @__PURE__ */ jsxDEV(SelectItem, { value: type, children: type }, type, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
                      lineNumber: 307,
                      columnNumber: 25
                    }, this)
                  ) }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
                    lineNumber: 305,
                    columnNumber: 27
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
                lineNumber: 298,
                columnNumber: 25
              },
              this
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
              lineNumber: 297,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { className: "font-medium text-sm max-w-[240px] truncate", title: t.title, children: t.title }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
              lineNumber: 314,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "button",
                variant: "ghost",
                size: "icon",
                className: "h-8 w-8 text-muted-foreground hover:text-destructive",
                onClick: () => removeTask(i),
                "aria-label": "Remove task",
                children: /* @__PURE__ */ jsxDEV(Trash2, { className: "h-4 w-4" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
                  lineNumber: 326,
                  columnNumber: 27
                }, this)
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
                lineNumber: 318,
                columnNumber: 25
              },
              this
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
              lineNumber: 317,
              columnNumber: 23
            }, this)
          ] }, i, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
            lineNumber: 279,
            columnNumber: 17
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
          lineNumber: 277,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
        lineNumber: 268,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
        lineNumber: 267,
        columnNumber: 13
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-destructive", role: "alert", children: error }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
        lineNumber: 335,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "outline", onClick: backToInput, children: "Back" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
          lineNumber: 340,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: handleCreateAll,
            disabled: createLoading || tasks.length === 0,
            children: createLoading ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Loader2, { className: "h-4 w-4 mr-2 animate-spin" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
                lineNumber: 349,
                columnNumber: 21
              }, this),
              "Creating…"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
              lineNumber: 348,
              columnNumber: 15
            }, this) : `Create All (${tasks.length})`
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
            lineNumber: 343,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
        lineNumber: 339,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
      lineNumber: 266,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
    lineNumber: 200,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx",
    lineNumber: 199,
    columnNumber: 5
  }, this);
}
_s(ImportPrdModal, "PSUQXqJqMASwI9EZxlGl+QuI0w0=", false, function() {
  return [useAction, useMutation, useMutation];
});
_c = ImportPrdModal;
var _c;
$RefreshReg$(_c, "ImportPrdModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/ImportPrdModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0xVLFNBbURRLFVBbkRSOzs7Ozs7Ozs7Ozs7Ozs7OztBQXRMVixTQUFTQSxVQUFVQyxjQUFjO0FBQ2pDLFNBQVNDLFdBQVdDLG1CQUFtQjtBQUN2QyxTQUFTQyxXQUFXO0FBRXBCLFNBQVNDLGNBQWM7QUFDdkI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MsZ0JBQWdCO0FBQ3pCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLFNBQVNDLFFBQVFDLGNBQWM7QUFFeEMsTUFBTUMsYUFBYTtBQUFBLEVBQ2pCO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFjO0FBR2hCLE1BQU1DLGFBQWE7QUFBQSxFQUNqQixFQUFFQyxPQUFPLEdBQUdDLE9BQU8sV0FBVztBQUFBLEVBQzlCLEVBQUVELE9BQU8sR0FBR0MsT0FBTyxPQUFPO0FBQUEsRUFDMUIsRUFBRUQsT0FBTyxHQUFHQyxPQUFPLFNBQVM7QUFBQSxFQUM1QixFQUFFRCxPQUFPLEdBQUdDLE9BQU8sTUFBTTtBQUFDO0FBV3JCLGdCQUFTQyxlQUFlO0FBQUEsRUFDN0JDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBS0YsR0FBRztBQUFBQyxLQUFBO0FBQ0QsUUFBTSxDQUFDQyxNQUFNQyxPQUFPLElBQUlyQyxTQUE4QixPQUFPO0FBQzdELFFBQU0sQ0FBQ3NDLFNBQVNDLFVBQVUsSUFBSXZDLFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUN3QyxPQUFPQyxRQUFRLElBQUl6QyxTQUEwQixFQUFFO0FBQ3RELFFBQU0sQ0FBQzBDLGNBQWNDLGVBQWUsSUFBSTNDLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUM0QyxlQUFlQyxnQkFBZ0IsSUFBSTdDLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUM4QyxPQUFPQyxRQUFRLElBQUkvQyxTQUF3QixJQUFJO0FBQ3RELFFBQU1nRCxlQUFlL0MsT0FBeUIsSUFBSTtBQUVsRCxRQUFNZ0QsV0FBVy9DLFVBQVVFLElBQUk4QyxJQUFJRCxRQUFRO0FBQzNDLFFBQU1FLG1CQUFtQmhELFlBQVlDLElBQUk4QyxJQUFJQyxnQkFBZ0I7QUFDN0QsUUFBTUMsb0JBQW9CakQsWUFBWUMsSUFBSThDLElBQUlFLGlCQUFpQjtBQUUvRCxRQUFNQyxtQkFBbUJBLENBQUNDLE1BQTJDO0FBQ25FLFVBQU1DLE9BQU9ELEVBQUVFLE9BQU9DLFFBQVEsQ0FBQztBQUMvQixRQUFJLENBQUNGLEtBQU07QUFDWCxVQUFNRyxTQUFTLElBQUlDLFdBQVc7QUFDOUJELFdBQU9FLFNBQVMsTUFBTTtBQUNwQnJCLGlCQUFXc0IsT0FBT0gsT0FBT0ksVUFBVSxFQUFFLENBQUM7QUFDdENmLGVBQVMsSUFBSTtBQUFBLElBQ2Y7QUFDQVcsV0FBT0ssV0FBV1IsSUFBSTtBQUN0QkQsTUFBRUUsT0FBTzNCLFFBQVE7QUFBQSxFQUNuQjtBQUVBLFFBQU1tQyxjQUFjLFlBQVk7QUFDOUIsVUFBTUMsT0FBTzNCLFFBQVE0QixLQUFLO0FBQzFCLFFBQUksQ0FBQ0QsTUFBTTtBQUNUbEIsZUFBUyxvQ0FBb0M7QUFDN0M7QUFBQSxJQUNGO0FBQ0FKLG9CQUFnQixJQUFJO0FBQ3BCSSxhQUFTLElBQUk7QUFDYixRQUFJO0FBQ0YsWUFBTWUsU0FBUyxNQUFNYixTQUFTLEVBQUVYLFNBQVMyQixNQUFNRSxVQUFVLEdBQUcsQ0FBQztBQUM3RCxZQUFNQyxRQUF5Qk4sT0FBT3RCLFNBQVMsSUFBSTZCLElBQUksQ0FBQ0MsT0FBTztBQUFBLFFBQzdEQyxPQUFPRCxFQUFFQztBQUFBQSxRQUNUQyxhQUFhRixFQUFFRTtBQUFBQSxRQUNmQyxNQUFNSCxFQUFFRztBQUFBQSxRQUNSQyxVQUFVSixFQUFFSTtBQUFBQSxRQUNaQyxtQkFBbUJMLEVBQUVLO0FBQUFBLE1BQ3ZCLEVBQUU7QUFDRixVQUFJUCxLQUFLUSxXQUFXLEdBQUc7QUFDckI3QjtBQUFBQSxVQUNFO0FBQUEsUUFDRjtBQUNBO0FBQUEsTUFDRjtBQUNBTixlQUFTMkIsSUFBSTtBQUNiL0IsY0FBUSxTQUFTO0FBQUEsSUFDbkIsU0FBU3dDLEtBQUs7QUFDWjlCLGVBQVM4QixlQUFlQyxRQUFRRCxJQUFJRSxVQUFVLHFCQUFxQjtBQUFBLElBQ3JFLFVBQUM7QUFDQ3BDLHNCQUFnQixLQUFLO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBRUEsUUFBTXFDLGFBQWFBLENBQUNDLE9BQWVDLFVBQWtDO0FBQ25FekM7QUFBQUEsTUFBUyxDQUFDMEMsU0FDUkEsS0FBS2QsSUFBSSxDQUFDQyxHQUFHYyxNQUFPQSxNQUFNSCxRQUFRLEVBQUUsR0FBR1gsR0FBRyxHQUFHWSxNQUFNLElBQUlaLENBQUU7QUFBQSxJQUMzRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNZSxhQUFhQSxDQUFDSixVQUFrQjtBQUNwQ3hDLGFBQVMsQ0FBQzBDLFNBQVNBLEtBQUtHLE9BQU8sQ0FBQ0MsR0FBR0gsTUFBTUEsTUFBTUgsS0FBSyxDQUFDO0FBQUEsRUFDdkQ7QUFFQSxRQUFNTyxrQkFBa0IsWUFBWTtBQUNsQyxRQUFJaEQsTUFBTW9DLFdBQVcsR0FBRztBQUN0QjdCLGVBQVMscUJBQXFCO0FBQzlCO0FBQUEsSUFDRjtBQUNBRixxQkFBaUIsSUFBSTtBQUNyQkUsYUFBUyxJQUFJO0FBQ2IsUUFBSTtBQUNGLFlBQU0wQyxjQUNKbkQsUUFBUW9ELE1BQU0sd0RBQXdELElBQUksQ0FBQyxHQUFHeEIsS0FBSztBQUNyRixZQUFNSyxRQUNKa0IsZUFBZW5ELFFBQVFvRCxNQUFNLGFBQWEsSUFBSSxDQUFDLEdBQUd4QixLQUFLLEtBQUs7QUFDOUQsWUFBTXlCLGlCQUFpQixNQUFNeEMsaUJBQWlCO0FBQUEsUUFDNUNuQixXQUFXQSxhQUFhNEQ7QUFBQUEsUUFDeEJyQjtBQUFBQSxRQUNBakM7QUFBQUEsUUFDQXVELFdBQVdyRCxNQUFNb0M7QUFBQUEsUUFDakJrQixXQUFXO0FBQUEsTUFDYixDQUFDO0FBQ0QsWUFBTWhDLFNBQVMsTUFBTVYsa0JBQWtCO0FBQUEsUUFDckNwQixXQUFXQSxhQUFhNEQ7QUFBQUEsUUFDeEJHLGVBQWVKLGVBQWVJO0FBQUFBLFFBQzlCdkQsT0FBT0EsTUFBTTZCLElBQUksQ0FBQ0MsT0FBTztBQUFBLFVBQ3ZCQyxPQUFPRCxFQUFFQztBQUFBQSxVQUNUQyxhQUFhRixFQUFFRTtBQUFBQSxVQUNmQyxNQUFNSCxFQUFFRztBQUFBQSxVQUNSQyxVQUFVSixFQUFFSTtBQUFBQSxVQUNaQyxtQkFBbUJMLEVBQUVLO0FBQUFBLFFBQ3ZCLEVBQUU7QUFBQSxRQUNGbUIsV0FBVztBQUFBLE1BQ2IsQ0FBQztBQUNENUQsa0JBQVk0QixPQUFPa0MsWUFBWTtBQUMvQi9ELGNBQVE7QUFBQSxJQUNWLFNBQVM0QyxLQUFLO0FBQ1o5QixlQUFTOEIsZUFBZUMsUUFBUUQsSUFBSUUsVUFBVSx3QkFBd0I7QUFBQSxJQUN4RSxVQUFDO0FBQ0NsQyx1QkFBaUIsS0FBSztBQUFBLElBQ3hCO0FBQUEsRUFDRjtBQUVBLFFBQU1vRCxjQUFjQSxNQUFNO0FBQ3hCNUQsWUFBUSxPQUFPO0FBQ2ZJLGFBQVMsRUFBRTtBQUNYTSxhQUFTLElBQUk7QUFBQSxFQUNmO0FBRUEsU0FDRSx1QkFBQyxVQUFPLE1BQUksTUFBQyxjQUFjLENBQUNtRCxTQUFTO0FBQUUsUUFBSSxDQUFDQSxLQUFNakUsU0FBUTtBQUFBLEVBQUcsR0FDM0QsaUNBQUMsaUJBQWMsV0FBVSxpREFDdkI7QUFBQSwyQkFBQyxnQkFDQztBQUFBLDZCQUFDLGVBQ0VHLG1CQUFTLFVBQVUsZUFBZSxrQkFEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxxQkFDRUEsbUJBQVMsVUFDTixvRUFDQSxnRUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBRUNBLFNBQVMsV0FDUixtQ0FDRTtBQUFBLDZCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLGFBQVk7QUFBQSxZQUNaLE9BQU9FO0FBQUFBLFlBQ1AsVUFBVSxDQUFDZ0IsTUFBTWYsV0FBV2UsRUFBRUUsT0FBTzNCLEtBQUs7QUFBQSxZQUMxQyxXQUFVO0FBQUEsWUFDVixVQUFVYTtBQUFBQTtBQUFBQSxVQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUt5QjtBQUFBLFFBRXpCLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxLQUFLTTtBQUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLFFBQU87QUFBQSxjQUNQLFdBQVU7QUFBQSxjQUNWLFVBQVVLO0FBQUFBO0FBQUFBLFlBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSzZCO0FBQUEsVUFFN0I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVE7QUFBQSxjQUNSLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTUwsYUFBYW1ELFNBQVNDLE1BQU07QUFBQSxjQUMzQyxVQUFVMUQ7QUFBQUEsY0FFVjtBQUFBLHVDQUFDLFVBQU8sV0FBVSxrQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVBsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTQTtBQUFBLGFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxXQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkJBO0FBQUEsTUFDQ0ksU0FDQyx1QkFBQyxPQUFFLFdBQVUsNEJBQTJCLE1BQUssU0FDMUNBLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUYsdUJBQUMsZ0JBQ0M7QUFBQSwrQkFBQyxVQUFPLFNBQVEsV0FBVSxTQUFTYixTQUFRLHNCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFVBQU8sU0FBUytCLGFBQWEsVUFBVXRCLGdCQUFnQixDQUFDSixRQUFRNEIsS0FBSyxHQUNuRXhCLHlCQUNDLG1DQUNFO0FBQUEsaUNBQUMsV0FBUSxXQUFVLCtCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QztBQUFBO0FBQUEsYUFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLElBRUEsV0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLFNBaERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpREE7QUFBQSxJQUdETixTQUFTLGFBQ1IsbUNBQ0U7QUFBQSw2QkFBQyxTQUFJLFdBQVUsaURBQ2IsaUNBQUMsU0FDQztBQUFBLCtCQUFDLGVBQ0MsaUNBQUMsWUFDQztBQUFBLGlDQUFDLGFBQVUsV0FBVSxVQUFTLHdCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQztBQUFBLFVBQ3RDLHVCQUFDLGFBQVUsV0FBVSxXQUFVLG9CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtQztBQUFBLFVBQ25DLHVCQUFDLGFBQVUscUJBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0I7QUFBQSxVQUNoQix1QkFBQyxhQUFVLFdBQVUsY0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQSxhQUpsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLGFBQ0VJLGdCQUFNNkI7QUFBQUEsVUFBSSxDQUFDQyxHQUFHYyxNQUNiLHVCQUFDLFlBQ0M7QUFBQSxtQ0FBQyxhQUNDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT3ZCLE9BQU9TLEVBQUVJLFFBQVE7QUFBQSxnQkFDeEIsZUFBZSxDQUFDMkIsTUFBTXJCLFdBQVdJLEdBQUcsRUFBRVYsVUFBVTRCLE9BQU9ELENBQUMsRUFBRSxDQUFDO0FBQUEsZ0JBRTNEO0FBQUEseUNBQUMsaUJBQWMsV0FBVSxPQUN2QixpQ0FBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFZLEtBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLGlCQUNFekUscUJBQVd5QztBQUFBQSxvQkFBSSxDQUFDa0MsTUFDZix1QkFBQyxjQUF5QixPQUFPMUMsT0FBTzBDLEVBQUUxRSxLQUFLLEdBQzVDMEUsWUFBRXpFLFNBRFl5RSxFQUFFMUUsT0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBO0FBQUE7QUFBQSxjQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxZQUNBLHVCQUFDLGFBQ0M7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPeUMsRUFBRUc7QUFBQUEsZ0JBQ1QsZUFBZSxDQUFDNEIsTUFBTXJCLFdBQVdJLEdBQUcsRUFBRVgsTUFBTTRCLEVBQUUsQ0FBQztBQUFBLGdCQUUvQztBQUFBLHlDQUFDLGlCQUFjLFdBQVUsT0FDdkIsaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBWSxLQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxpQkFDRTFFLHFCQUFXMEM7QUFBQUEsb0JBQUksQ0FBQ0ksU0FDZix1QkFBQyxjQUFzQixPQUFPQSxNQUMzQkEsa0JBRGNBLE1BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTUE7QUFBQTtBQUFBO0FBQUEsY0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsWUFDQSx1QkFBQyxhQUFVLFdBQVUsOENBQTZDLE9BQU9ILEVBQUVDLE9BQ3hFRCxZQUFFQyxTQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLGFBQ0M7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUTtBQUFBLGdCQUNSLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsU0FBUyxNQUFNYyxXQUFXRCxDQUFDO0FBQUEsZ0JBQzNCLGNBQVc7QUFBQSxnQkFFWCxpQ0FBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkI7QUFBQTtBQUFBLGNBUjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLGVBakRhQSxHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0RBO0FBQUEsUUFDRCxLQXJESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0RBO0FBQUEsV0EvREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdFQSxLQWpFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0VBO0FBQUEsTUFDQ3RDLFNBQ0MsdUJBQUMsT0FBRSxXQUFVLDRCQUEyQixNQUFLLFNBQzFDQSxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVGLHVCQUFDLGdCQUNDO0FBQUEsK0JBQUMsVUFBTyxTQUFRLFdBQVUsU0FBU21ELGFBQVksb0JBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVNUO0FBQUFBLFlBQ1QsVUFBVTVDLGlCQUFpQkosTUFBTW9DLFdBQVc7QUFBQSxZQUUzQ2hDLDBCQUNDLG1DQUNFO0FBQUEscUNBQUMsV0FBUSxXQUFVLCtCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QztBQUFBO0FBQUEsaUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsSUFFQSxlQUFlSixNQUFNb0MsTUFBTTtBQUFBO0FBQUEsVUFWL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWUE7QUFBQSxXQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBO0FBQUEsU0ExRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJGQTtBQUFBLE9BN0pKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErSkEsS0FoS0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlLQTtBQUVKO0FBQUN6QyxHQTdSZUosZ0JBQWM7QUFBQSxVQWlCWDdCLFdBQ1FDLGFBQ0NBLFdBQVc7QUFBQTtBQUFBLEtBbkJ2QjRCO0FBQWMsSUFBQXlFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlUmVmIiwidXNlQWN0aW9uIiwidXNlTXV0YXRpb24iLCJhcGkiLCJCdXR0b24iLCJEaWFsb2ciLCJEaWFsb2dDb250ZW50IiwiRGlhbG9nRGVzY3JpcHRpb24iLCJEaWFsb2dGb290ZXIiLCJEaWFsb2dIZWFkZXIiLCJEaWFsb2dUaXRsZSIsIlRleHRhcmVhIiwiVGFibGUiLCJUYWJsZUJvZHkiLCJUYWJsZUNlbGwiLCJUYWJsZUhlYWQiLCJUYWJsZUhlYWRlciIsIlRhYmxlUm93IiwiU2VsZWN0IiwiU2VsZWN0Q29udGVudCIsIlNlbGVjdEl0ZW0iLCJTZWxlY3RUcmlnZ2VyIiwiU2VsZWN0VmFsdWUiLCJMb2FkZXIyIiwiRmlsZVVwIiwiVHJhc2gyIiwiVEFTS19UWVBFUyIsIlBSSU9SSVRJRVMiLCJ2YWx1ZSIsImxhYmVsIiwiSW1wb3J0UHJkTW9kYWwiLCJwcm9qZWN0SWQiLCJvbkNsb3NlIiwib25DcmVhdGVkIiwiX3MiLCJzdGVwIiwic2V0U3RlcCIsImNvbnRlbnQiLCJzZXRDb250ZW50IiwidGFza3MiLCJzZXRUYXNrcyIsInBhcnNlTG9hZGluZyIsInNldFBhcnNlTG9hZGluZyIsImNyZWF0ZUxvYWRpbmciLCJzZXRDcmVhdGVMb2FkaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsImZpbGVJbnB1dFJlZiIsInBhcnNlUHJkIiwicHJkIiwic3RvcmVQcmREb2N1bWVudCIsImJ1bGtDcmVhdGVGcm9tUHJkIiwiaGFuZGxlRmlsZUNoYW5nZSIsImUiLCJmaWxlIiwidGFyZ2V0IiwiZmlsZXMiLCJyZWFkZXIiLCJGaWxlUmVhZGVyIiwib25sb2FkIiwiU3RyaW5nIiwicmVzdWx0IiwicmVhZEFzVGV4dCIsImhhbmRsZVBhcnNlIiwidGV4dCIsInRyaW0iLCJtYXhUYXNrcyIsInJvd3MiLCJtYXAiLCJ0IiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsInR5cGUiLCJwcmlvcml0eSIsImRlcGVuZGVuY3lJbmRpY2VzIiwibGVuZ3RoIiwiZXJyIiwiRXJyb3IiLCJtZXNzYWdlIiwidXBkYXRlVGFzayIsImluZGV4IiwicGF0Y2giLCJwcmV2IiwiaSIsInJlbW92ZVRhc2siLCJmaWx0ZXIiLCJfIiwiaGFuZGxlQ3JlYXRlQWxsIiwicHJvZHVjdE5hbWUiLCJtYXRjaCIsInN0b3JlZERvY3VtZW50IiwidW5kZWZpbmVkIiwidGFza0NvdW50IiwiY3JlYXRlZEJ5IiwicHJkRG9jdW1lbnRJZCIsImNyZWF0ZWRDb3VudCIsImJhY2tUb0lucHV0Iiwib3BlbiIsImN1cnJlbnQiLCJjbGljayIsInYiLCJOdW1iZXIiLCJwIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSW1wb3J0UHJkTW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VSZWYgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZUFjdGlvbiwgdXNlTXV0YXRpb24gfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9idXR0b25cIjtcbmltcG9ydCB7XG4gIERpYWxvZyxcbiAgRGlhbG9nQ29udGVudCxcbiAgRGlhbG9nRGVzY3JpcHRpb24sXG4gIERpYWxvZ0Zvb3RlcixcbiAgRGlhbG9nSGVhZGVyLFxuICBEaWFsb2dUaXRsZSxcbn0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9kaWFsb2dcIjtcbmltcG9ydCB7IFRleHRhcmVhIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS90ZXh0YXJlYVwiO1xuaW1wb3J0IHtcbiAgVGFibGUsXG4gIFRhYmxlQm9keSxcbiAgVGFibGVDZWxsLFxuICBUYWJsZUhlYWQsXG4gIFRhYmxlSGVhZGVyLFxuICBUYWJsZVJvdyxcbn0gZnJvbSBcIkAvY29tcG9uZW50cy91aS90YWJsZVwiO1xuaW1wb3J0IHtcbiAgU2VsZWN0LFxuICBTZWxlY3RDb250ZW50LFxuICBTZWxlY3RJdGVtLFxuICBTZWxlY3RUcmlnZ2VyLFxuICBTZWxlY3RWYWx1ZSxcbn0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9zZWxlY3RcIjtcbmltcG9ydCB7IExvYWRlcjIsIEZpbGVVcCwgVHJhc2gyIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuXG5jb25zdCBUQVNLX1RZUEVTID0gW1xuICBcIkVOR0lORUVSSU5HXCIsXG4gIFwiQ09OVEVOVFwiLFxuICBcIkRPQ1NcIixcbiAgXCJPUFNcIixcbiAgXCJTT0NJQUxcIixcbiAgXCJFTUFJTF9NQVJLRVRJTkdcIixcbiAgXCJDVVNUT01FUl9SRVNFQVJDSFwiLFxuICBcIlNFT19SRVNFQVJDSFwiLFxuXSBhcyBjb25zdDtcblxuY29uc3QgUFJJT1JJVElFUyA9IFtcbiAgeyB2YWx1ZTogMSwgbGFiZWw6IFwiQ3JpdGljYWxcIiB9LFxuICB7IHZhbHVlOiAyLCBsYWJlbDogXCJIaWdoXCIgfSxcbiAgeyB2YWx1ZTogMywgbGFiZWw6IFwiTm9ybWFsXCIgfSxcbiAgeyB2YWx1ZTogNCwgbGFiZWw6IFwiTG93XCIgfSxcbl0gYXMgY29uc3Q7XG5cbmV4cG9ydCB0eXBlIFBhcnNlZFRhc2tSb3cgPSB7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuICB0eXBlOiBzdHJpbmc7XG4gIHByaW9yaXR5OiBudW1iZXI7XG4gIGRlcGVuZGVuY3lJbmRpY2VzPzogbnVtYmVyW107XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gSW1wb3J0UHJkTW9kYWwoe1xuICBwcm9qZWN0SWQsXG4gIG9uQ2xvc2UsXG4gIG9uQ3JlYXRlZCxcbn06IHtcbiAgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+IHwgbnVsbDtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbiAgb25DcmVhdGVkPzogKGNvdW50OiBudW1iZXIpID0+IHZvaWQ7XG59KSB7XG4gIGNvbnN0IFtzdGVwLCBzZXRTdGVwXSA9IHVzZVN0YXRlPFwiaW5wdXRcIiB8IFwicHJldmlld1wiPihcImlucHV0XCIpO1xuICBjb25zdCBbY29udGVudCwgc2V0Q29udGVudF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3Rhc2tzLCBzZXRUYXNrc10gPSB1c2VTdGF0ZTxQYXJzZWRUYXNrUm93W10+KFtdKTtcbiAgY29uc3QgW3BhcnNlTG9hZGluZywgc2V0UGFyc2VMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2NyZWF0ZUxvYWRpbmcsIHNldENyZWF0ZUxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBmaWxlSW5wdXRSZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbCk7XG5cbiAgY29uc3QgcGFyc2VQcmQgPSB1c2VBY3Rpb24oYXBpLnByZC5wYXJzZVByZCk7XG4gIGNvbnN0IHN0b3JlUHJkRG9jdW1lbnQgPSB1c2VNdXRhdGlvbihhcGkucHJkLnN0b3JlUHJkRG9jdW1lbnQpO1xuICBjb25zdCBidWxrQ3JlYXRlRnJvbVByZCA9IHVzZU11dGF0aW9uKGFwaS5wcmQuYnVsa0NyZWF0ZUZyb21QcmQpO1xuXG4gIGNvbnN0IGhhbmRsZUZpbGVDaGFuZ2UgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcbiAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXM/LlswXTtcbiAgICBpZiAoIWZpbGUpIHJldHVybjtcbiAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xuICAgIHJlYWRlci5vbmxvYWQgPSAoKSA9PiB7XG4gICAgICBzZXRDb250ZW50KFN0cmluZyhyZWFkZXIucmVzdWx0ID8/IFwiXCIpKTtcbiAgICAgIHNldEVycm9yKG51bGwpO1xuICAgIH07XG4gICAgcmVhZGVyLnJlYWRBc1RleHQoZmlsZSk7XG4gICAgZS50YXJnZXQudmFsdWUgPSBcIlwiO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVBhcnNlID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHRleHQgPSBjb250ZW50LnRyaW0oKTtcbiAgICBpZiAoIXRleHQpIHtcbiAgICAgIHNldEVycm9yKFwiUGFzdGUgb3IgdXBsb2FkIFBSRCBjb250ZW50IGZpcnN0LlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgc2V0UGFyc2VMb2FkaW5nKHRydWUpO1xuICAgIHNldEVycm9yKG51bGwpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBwYXJzZVByZCh7IGNvbnRlbnQ6IHRleHQsIG1heFRhc2tzOiAyNSB9KTtcbiAgICAgIGNvbnN0IHJvd3M6IFBhcnNlZFRhc2tSb3dbXSA9IChyZXN1bHQudGFza3MgPz8gW10pLm1hcCgodCkgPT4gKHtcbiAgICAgICAgdGl0bGU6IHQudGl0bGUsXG4gICAgICAgIGRlc2NyaXB0aW9uOiB0LmRlc2NyaXB0aW9uLFxuICAgICAgICB0eXBlOiB0LnR5cGUsXG4gICAgICAgIHByaW9yaXR5OiB0LnByaW9yaXR5LFxuICAgICAgICBkZXBlbmRlbmN5SW5kaWNlczogdC5kZXBlbmRlbmN5SW5kaWNlcyxcbiAgICAgIH0pKTtcbiAgICAgIGlmIChyb3dzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICBzZXRFcnJvcihcbiAgICAgICAgICBcIk5vIGFjdGlvbmFibGUgcmVxdWlyZW1lbnRzIHdlcmUgZm91bmQuIFVzZSBGUi0xIHN0eWxlIHJlcXVpcmVtZW50cywgbnVtYmVyZWQgc2VjdGlvbnMsIG9yIE1hcmtkb3duIGhlYWRpbmdzLlwiXG4gICAgICAgICk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHNldFRhc2tzKHJvd3MpO1xuICAgICAgc2V0U3RlcChcInByZXZpZXdcIik7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogXCJGYWlsZWQgdG8gcGFyc2UgUFJEXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRQYXJzZUxvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCB1cGRhdGVUYXNrID0gKGluZGV4OiBudW1iZXIsIHBhdGNoOiBQYXJ0aWFsPFBhcnNlZFRhc2tSb3c+KSA9PiB7XG4gICAgc2V0VGFza3MoKHByZXYpID0+XG4gICAgICBwcmV2Lm1hcCgodCwgaSkgPT4gKGkgPT09IGluZGV4ID8geyAuLi50LCAuLi5wYXRjaCB9IDogdCkpXG4gICAgKTtcbiAgfTtcblxuICBjb25zdCByZW1vdmVUYXNrID0gKGluZGV4OiBudW1iZXIpID0+IHtcbiAgICBzZXRUYXNrcygocHJldikgPT4gcHJldi5maWx0ZXIoKF8sIGkpID0+IGkgIT09IGluZGV4KSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ3JlYXRlQWxsID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICh0YXNrcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHNldEVycm9yKFwiTm8gdGFza3MgdG8gY3JlYXRlLlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgc2V0Q3JlYXRlTG9hZGluZyh0cnVlKTtcbiAgICBzZXRFcnJvcihudWxsKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcHJvZHVjdE5hbWUgPVxuICAgICAgICBjb250ZW50Lm1hdGNoKC8oPzpefFxcbilcXHMqKD86XFxkK1xcLlxccyspP1Byb2R1Y3QgTmFtZVxccypcXG4rXFxzKihbXlxcbl0rKS9pKT8uWzFdPy50cmltKCk7XG4gICAgICBjb25zdCB0aXRsZSA9XG4gICAgICAgIHByb2R1Y3ROYW1lIHx8IGNvbnRlbnQubWF0Y2goL14jXFxzKyguKykkL20pPy5bMV0/LnRyaW0oKSB8fCBcIkltcG9ydGVkIFBSRFwiO1xuICAgICAgY29uc3Qgc3RvcmVkRG9jdW1lbnQgPSBhd2FpdCBzdG9yZVByZERvY3VtZW50KHtcbiAgICAgICAgcHJvamVjdElkOiBwcm9qZWN0SWQgPz8gdW5kZWZpbmVkLFxuICAgICAgICB0aXRsZSxcbiAgICAgICAgY29udGVudCxcbiAgICAgICAgdGFza0NvdW50OiB0YXNrcy5sZW5ndGgsXG4gICAgICAgIGNyZWF0ZWRCeTogXCJIVU1BTlwiLFxuICAgICAgfSk7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBidWxrQ3JlYXRlRnJvbVByZCh7XG4gICAgICAgIHByb2plY3RJZDogcHJvamVjdElkID8/IHVuZGVmaW5lZCxcbiAgICAgICAgcHJkRG9jdW1lbnRJZDogc3RvcmVkRG9jdW1lbnQucHJkRG9jdW1lbnRJZCxcbiAgICAgICAgdGFza3M6IHRhc2tzLm1hcCgodCkgPT4gKHtcbiAgICAgICAgICB0aXRsZTogdC50aXRsZSxcbiAgICAgICAgICBkZXNjcmlwdGlvbjogdC5kZXNjcmlwdGlvbixcbiAgICAgICAgICB0eXBlOiB0LnR5cGUsXG4gICAgICAgICAgcHJpb3JpdHk6IHQucHJpb3JpdHksXG4gICAgICAgICAgZGVwZW5kZW5jeUluZGljZXM6IHQuZGVwZW5kZW5jeUluZGljZXMsXG4gICAgICAgIH0pKSxcbiAgICAgICAgY3JlYXRlZEJ5OiBcIkhVTUFOXCIsXG4gICAgICB9KTtcbiAgICAgIG9uQ3JlYXRlZD8uKHJlc3VsdC5jcmVhdGVkQ291bnQpO1xuICAgICAgb25DbG9zZSgpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6IFwiRmFpbGVkIHRvIGNyZWF0ZSB0YXNrc1wiKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0Q3JlYXRlTG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGJhY2tUb0lucHV0ID0gKCkgPT4ge1xuICAgIHNldFN0ZXAoXCJpbnB1dFwiKTtcbiAgICBzZXRUYXNrcyhbXSk7XG4gICAgc2V0RXJyb3IobnVsbCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8RGlhbG9nIG9wZW4gb25PcGVuQ2hhbmdlPXsob3BlbikgPT4geyBpZiAoIW9wZW4pIG9uQ2xvc2UoKTsgfX0+XG4gICAgICA8RGlhbG9nQ29udGVudCBjbGFzc05hbWU9XCJtYXgtaC1bOTB2aF0gb3ZlcmZsb3cteS1hdXRvIHNtOm1heC13LVs3MjBweF1cIj5cbiAgICAgICAgPERpYWxvZ0hlYWRlcj5cbiAgICAgICAgICA8RGlhbG9nVGl0bGU+XG4gICAgICAgICAgICB7c3RlcCA9PT0gXCJpbnB1dFwiID8gXCJJbXBvcnQgUFJEXCIgOiBcIlJldmlldyB0YXNrc1wifVxuICAgICAgICAgIDwvRGlhbG9nVGl0bGU+XG4gICAgICAgICAgPERpYWxvZ0Rlc2NyaXB0aW9uPlxuICAgICAgICAgICAge3N0ZXAgPT09IFwiaW5wdXRcIlxuICAgICAgICAgICAgICA/IFwiUGFzdGUgbWFya2Rvd24gb3IgdXBsb2FkIGEgLm1kIGZpbGUuIFdlJ2xsIHBhcnNlIGl0IGludG8gdGFza3MuXCJcbiAgICAgICAgICAgICAgOiBcIkVkaXQgdHlwZXMgYW5kIHByaW9yaXRpZXMsIHRoZW4gY3JlYXRlIGFsbCB0YXNrcyBpbiBJTkJPWC5cIn1cbiAgICAgICAgICA8L0RpYWxvZ0Rlc2NyaXB0aW9uPlxuICAgICAgICA8L0RpYWxvZ0hlYWRlcj5cblxuICAgICAgICB7c3RlcCA9PT0gXCJpbnB1dFwiICYmIChcbiAgICAgICAgICA8PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgPFRleHRhcmVhXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJQYXN0ZSB5b3VyIFBSRCBtYXJrZG93biBoZXJlLi4uXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Y29udGVudH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENvbnRlbnQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1pbi1oLVsyMDBweF0gZm9udC1tb25vIHRleHQtc21cIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwYXJzZUxvYWRpbmd9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHJlZj17ZmlsZUlucHV0UmVmfVxuICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxuICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiLm1kLHRleHQvbWFya2Rvd24sdGV4dC9wbGFpblwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbGVDaGFuZ2V9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBmaWxlSW5wdXRSZWYuY3VycmVudD8uY2xpY2soKX1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwYXJzZUxvYWRpbmd9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPEZpbGVVcCBjbGFzc05hbWU9XCJoLTQgdy00IG1yLTFcIiAvPlxuICAgICAgICAgICAgICAgICAgVXBsb2FkIC5tZFxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWRlc3RydWN0aXZlXCIgcm9sZT1cImFsZXJ0XCI+XG4gICAgICAgICAgICAgICAge2Vycm9yfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAgPERpYWxvZ0Zvb3Rlcj5cbiAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9e29uQ2xvc2V9PlxuICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVQYXJzZX0gZGlzYWJsZWQ9e3BhcnNlTG9hZGluZyB8fCAhY29udGVudC50cmltKCl9PlxuICAgICAgICAgICAgICAgIHtwYXJzZUxvYWRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJoLTQgdy00IG1yLTIgYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgUGFyc2luZ+KAplxuICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIFwiUGFyc2VcIlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC9EaWFsb2dGb290ZXI+XG4gICAgICAgICAgPC8+XG4gICAgICAgICl9XG5cbiAgICAgICAge3N0ZXAgPT09IFwicHJldmlld1wiICYmIChcbiAgICAgICAgICA8PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgcm91bmRlZC1tZCBvdmVyZmxvdy1hdXRvIG1heC1oLVszNjBweF1cIj5cbiAgICAgICAgICAgICAgPFRhYmxlPlxuICAgICAgICAgICAgICAgIDxUYWJsZUhlYWRlcj5cbiAgICAgICAgICAgICAgICAgIDxUYWJsZVJvdz5cbiAgICAgICAgICAgICAgICAgICAgPFRhYmxlSGVhZCBjbGFzc05hbWU9XCJ3LVs4JV1cIj5Qcmlvcml0eTwvVGFibGVIZWFkPlxuICAgICAgICAgICAgICAgICAgICA8VGFibGVIZWFkIGNsYXNzTmFtZT1cInctWzE4JV1cIj5UeXBlPC9UYWJsZUhlYWQ+XG4gICAgICAgICAgICAgICAgICAgIDxUYWJsZUhlYWQ+VGl0bGU8L1RhYmxlSGVhZD5cbiAgICAgICAgICAgICAgICAgICAgPFRhYmxlSGVhZCBjbGFzc05hbWU9XCJ3LVs2MHB4XVwiPjwvVGFibGVIZWFkPlxuICAgICAgICAgICAgICAgICAgPC9UYWJsZVJvdz5cbiAgICAgICAgICAgICAgICA8L1RhYmxlSGVhZGVyPlxuICAgICAgICAgICAgICAgIDxUYWJsZUJvZHk+XG4gICAgICAgICAgICAgICAgICB7dGFza3MubWFwKCh0LCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxUYWJsZVJvdyBrZXk9e2l9PlxuICAgICAgICAgICAgICAgICAgICAgIDxUYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtTdHJpbmcodC5wcmlvcml0eSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2KSA9PiB1cGRhdGVUYXNrKGksIHsgcHJpb3JpdHk6IE51bWJlcih2KSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwiaC04XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1BSSU9SSVRJRVMubWFwKChwKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSBrZXk9e3AudmFsdWV9IHZhbHVlPXtTdHJpbmcocC52YWx1ZSl9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cC5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3QudHlwZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHYpID0+IHVwZGF0ZVRhc2soaSwgeyB0eXBlOiB2IH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJoLThcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7VEFTS19UWVBFUy5tYXAoKHR5cGUpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17dHlwZX0gdmFsdWU9e3R5cGV9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHlwZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXNtIG1heC13LVsyNDBweF0gdHJ1bmNhdGVcIiB0aXRsZT17dC50aXRsZX0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dC50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgICAgICA8VGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImljb25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggdy04IHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBob3Zlcjp0ZXh0LWRlc3RydWN0aXZlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcmVtb3ZlVGFzayhpKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlJlbW92ZSB0YXNrXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9UYWJsZUJvZHk+XG4gICAgICAgICAgICAgIDwvVGFibGU+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIHtlcnJvciAmJiAoXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1kZXN0cnVjdGl2ZVwiIHJvbGU9XCJhbGVydFwiPlxuICAgICAgICAgICAgICAgIHtlcnJvcn1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDxEaWFsb2dGb290ZXI+XG4gICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBvbkNsaWNrPXtiYWNrVG9JbnB1dH0+XG4gICAgICAgICAgICAgICAgQmFja1xuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNyZWF0ZUFsbH1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17Y3JlYXRlTG9hZGluZyB8fCB0YXNrcy5sZW5ndGggPT09IDB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7Y3JlYXRlTG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cImgtNCB3LTQgbXItMiBhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICAgICAgICAgICAgICBDcmVhdGluZ+KAplxuICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIGBDcmVhdGUgQWxsICgke3Rhc2tzLmxlbmd0aH0pYFxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC9EaWFsb2dGb290ZXI+XG4gICAgICAgICAgPC8+XG4gICAgICAgICl9XG4gICAgICA8L0RpYWxvZ0NvbnRlbnQ+XG4gICAgPC9EaWFsb2c+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9JbXBvcnRQcmRNb2RhbC50c3gifQ==