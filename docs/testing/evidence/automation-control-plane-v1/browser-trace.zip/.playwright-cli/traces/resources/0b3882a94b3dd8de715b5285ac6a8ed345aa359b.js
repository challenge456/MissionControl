import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TabBar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TabBar.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { cn } from "/src/lib/utils.ts";
export function TabBar({ tabs, activeTab, onTabChange, className }) {
  const handleKeyDown = (event, index) => {
    if (!["ArrowRight", "ArrowLeft", "Home", "End"].includes(event.key)) return;
    event.preventDefault();
    if (tabs.length === 0) return;
    if (event.key === "Home") {
      onTabChange(tabs[0].id);
      return;
    }
    if (event.key === "End") {
      onTabChange(tabs[tabs.length - 1].id);
      return;
    }
    const delta = event.key === "ArrowRight" ? 1 : -1;
    const nextIndex = (index + delta + tabs.length) % tabs.length;
    onTabChange(tabs[nextIndex].id);
  };
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: cn(
        "border-b border-line bg-app px-4 py-2.5",
        className
      ),
      role: "tablist",
      children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 overflow-x-auto rounded-lg border border-line p-0.5", children: tabs.map((tab, index) => {
        const isActive = activeTab === tab.id;
        return /* @__PURE__ */ jsxDEV(
          "button",
          {
            role: "tab",
            "aria-selected": isActive,
            tabIndex: isActive ? 0 : -1,
            onClick: () => onTabChange(tab.id),
            onKeyDown: (event) => handleKeyDown(event, index),
            className: cn(
              "relative rounded-md px-4 py-2",
              "text-[12.5px] font-medium",
              "transition-colors duration-150",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1 focus-visible:ring-offset-background",
              isActive ? "bg-surface-2 text-ink" : "text-ink-secondary hover:text-ink"
            ),
            children: /* @__PURE__ */ jsxDEV("span", { className: "relative z-10 flex items-center gap-1.5 whitespace-nowrap", children: [
              tab.label,
              tab.count !== void 0 && tab.count > 0 && /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: cn(
                    "flex h-[17px] min-w-4.5 items-center justify-center rounded-full px-1 text-[10px] font-medium",
                    isActive ? "bg-surface-3 text-ink" : "bg-surface-2 text-ink-muted"
                  ),
                  children: tab.count
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TabBar.tsx",
                  lineNumber: 88,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TabBar.tsx",
              lineNumber: 85,
              columnNumber: 15
            }, this)
          },
          tab.id,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TabBar.tsx",
            lineNumber: 68,
            columnNumber: 13
          },
          this
        );
      }) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TabBar.tsx",
        lineNumber: 64,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TabBar.tsx",
      lineNumber: 57,
      columnNumber: 5
    },
    this
  );
}
_c = TabBar;
var _c;
$RefreshReg$(_c, "TabBar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TabBar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/TabBar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0VrQjs7Ozs7Ozs7Ozs7Ozs7OztBQW5FbEIsU0FBU0EsVUFBVTtBQWVaLGdCQUFTQyxPQUFPLEVBQUVDLE1BQU1DLFdBQVdDLGFBQWFDLFVBQXVCLEdBQUc7QUFDL0UsUUFBTUMsZ0JBQWdCQSxDQUFDQyxPQUF5Q0MsVUFBa0I7QUFDaEYsUUFBSSxDQUFDLENBQUMsY0FBYyxhQUFhLFFBQVEsS0FBSyxFQUFFQyxTQUFTRixNQUFNRyxHQUFHLEVBQUc7QUFDckVILFVBQU1JLGVBQWU7QUFDckIsUUFBSVQsS0FBS1UsV0FBVyxFQUFHO0FBRXZCLFFBQUlMLE1BQU1HLFFBQVEsUUFBUTtBQUN4Qk4sa0JBQVlGLEtBQUssQ0FBQyxFQUFFVyxFQUFFO0FBQ3RCO0FBQUEsSUFDRjtBQUNBLFFBQUlOLE1BQU1HLFFBQVEsT0FBTztBQUN2Qk4sa0JBQVlGLEtBQUtBLEtBQUtVLFNBQVMsQ0FBQyxFQUFFQyxFQUFFO0FBQ3BDO0FBQUEsSUFDRjtBQUVBLFVBQU1DLFFBQVFQLE1BQU1HLFFBQVEsZUFBZSxJQUFJO0FBQy9DLFVBQU1LLGFBQWFQLFFBQVFNLFFBQVFaLEtBQUtVLFVBQVVWLEtBQUtVO0FBQ3ZEUixnQkFBWUYsS0FBS2EsU0FBUyxFQUFFRixFQUFFO0FBQUEsRUFDaEM7QUFFQSxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxXQUFXYjtBQUFBQSxRQUNUO0FBQUEsUUFDQUs7QUFBQUEsTUFDRjtBQUFBLE1BQ0EsTUFBSztBQUFBLE1BRUwsaUNBQUMsU0FBSSxXQUFVLGlGQUNaSCxlQUFLYyxJQUFJLENBQUNDLEtBQUtULFVBQVU7QUFDeEIsY0FBTVUsV0FBV2YsY0FBY2MsSUFBSUo7QUFDbkMsZUFDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsTUFBSztBQUFBLFlBQ0wsaUJBQWVLO0FBQUFBLFlBQ2YsVUFBVUEsV0FBVyxJQUFJO0FBQUEsWUFDekIsU0FBUyxNQUFNZCxZQUFZYSxJQUFJSixFQUFFO0FBQUEsWUFDakMsV0FBVyxDQUFDTixVQUFVRCxjQUFjQyxPQUFPQyxLQUFLO0FBQUEsWUFDaEQsV0FBV1I7QUFBQUEsY0FDVDtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0FrQixXQUNJLDBCQUNBO0FBQUEsWUFDTjtBQUFBLFlBRUEsaUNBQUMsVUFBSyxXQUFVLDZEQUNiRDtBQUFBQSxrQkFBSUU7QUFBQUEsY0FDSkYsSUFBSUcsVUFBVUMsVUFBYUosSUFBSUcsUUFBUSxLQUN0QztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXcEI7QUFBQUEsb0JBQ1Q7QUFBQSxvQkFDQWtCLFdBQ0ksMEJBQ0E7QUFBQSxrQkFDTjtBQUFBLGtCQUVDRCxjQUFJRztBQUFBQTtBQUFBQSxnQkFSUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTQTtBQUFBLGlCQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBY0E7QUFBQTtBQUFBLFVBOUJLSCxJQUFJSjtBQUFBQSxVQURYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFnQ0E7QUFBQSxNQUVKLENBQUMsS0F0Q0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVDQTtBQUFBO0FBQUEsSUE5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBK0NBO0FBRUo7QUFBQ1MsS0F0RWVyQjtBQUFNLElBQUFxQjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJjbiIsIlRhYkJhciIsInRhYnMiLCJhY3RpdmVUYWIiLCJvblRhYkNoYW5nZSIsImNsYXNzTmFtZSIsImhhbmRsZUtleURvd24iLCJldmVudCIsImluZGV4IiwiaW5jbHVkZXMiLCJrZXkiLCJwcmV2ZW50RGVmYXVsdCIsImxlbmd0aCIsImlkIiwiZGVsdGEiLCJuZXh0SW5kZXgiLCJtYXAiLCJ0YWIiLCJpc0FjdGl2ZSIsImxhYmVsIiwiY291bnQiLCJ1bmRlZmluZWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUYWJCYXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgS2V5Ym9hcmRFdmVudCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcblxuZXhwb3J0IGludGVyZmFjZSBUYWJJdGVtIHtcbiAgaWQ6IHN0cmluZztcbiAgbGFiZWw6IHN0cmluZztcbiAgY291bnQ/OiBudW1iZXI7XG59XG5cbmludGVyZmFjZSBUYWJCYXJQcm9wcyB7XG4gIHRhYnM6IFRhYkl0ZW1bXTtcbiAgYWN0aXZlVGFiOiBzdHJpbmc7XG4gIG9uVGFiQ2hhbmdlOiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gVGFiQmFyKHsgdGFicywgYWN0aXZlVGFiLCBvblRhYkNoYW5nZSwgY2xhc3NOYW1lIH06IFRhYkJhclByb3BzKSB7XG4gIGNvbnN0IGhhbmRsZUtleURvd24gPSAoZXZlbnQ6IEtleWJvYXJkRXZlbnQ8SFRNTEJ1dHRvbkVsZW1lbnQ+LCBpbmRleDogbnVtYmVyKSA9PiB7XG4gICAgaWYgKCFbXCJBcnJvd1JpZ2h0XCIsIFwiQXJyb3dMZWZ0XCIsIFwiSG9tZVwiLCBcIkVuZFwiXS5pbmNsdWRlcyhldmVudC5rZXkpKSByZXR1cm47XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAodGFicy5sZW5ndGggPT09IDApIHJldHVybjtcblxuICAgIGlmIChldmVudC5rZXkgPT09IFwiSG9tZVwiKSB7XG4gICAgICBvblRhYkNoYW5nZSh0YWJzWzBdLmlkKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGV2ZW50LmtleSA9PT0gXCJFbmRcIikge1xuICAgICAgb25UYWJDaGFuZ2UodGFic1t0YWJzLmxlbmd0aCAtIDFdLmlkKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBkZWx0YSA9IGV2ZW50LmtleSA9PT0gXCJBcnJvd1JpZ2h0XCIgPyAxIDogLTE7XG4gICAgY29uc3QgbmV4dEluZGV4ID0gKGluZGV4ICsgZGVsdGEgKyB0YWJzLmxlbmd0aCkgJSB0YWJzLmxlbmd0aDtcbiAgICBvblRhYkNoYW5nZSh0YWJzW25leHRJbmRleF0uaWQpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJib3JkZXItYiBib3JkZXItbGluZSBiZy1hcHAgcHgtNCBweS0yLjVcIixcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgcm9sZT1cInRhYmxpc3RcIlxuICAgID5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBvdmVyZmxvdy14LWF1dG8gcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgcC0wLjVcIj5cbiAgICAgICAge3RhYnMubWFwKCh0YWIsIGluZGV4KSA9PiB7XG4gICAgICAgICAgY29uc3QgaXNBY3RpdmUgPSBhY3RpdmVUYWIgPT09IHRhYi5pZDtcbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBrZXk9e3RhYi5pZH1cbiAgICAgICAgICAgICAgcm9sZT1cInRhYlwiXG4gICAgICAgICAgICAgIGFyaWEtc2VsZWN0ZWQ9e2lzQWN0aXZlfVxuICAgICAgICAgICAgICB0YWJJbmRleD17aXNBY3RpdmUgPyAwIDogLTF9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uVGFiQ2hhbmdlKHRhYi5pZCl9XG4gICAgICAgICAgICAgIG9uS2V5RG93bj17KGV2ZW50KSA9PiBoYW5kbGVLZXlEb3duKGV2ZW50LCBpbmRleCl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgXCJyZWxhdGl2ZSByb3VuZGVkLW1kIHB4LTQgcHktMlwiLFxuICAgICAgICAgICAgICAgIFwidGV4dC1bMTIuNXB4XSBmb250LW1lZGl1bVwiLFxuICAgICAgICAgICAgICAgIFwidHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCIsXG4gICAgICAgICAgICAgICAgXCJmb2N1cy12aXNpYmxlOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctcmluZyBmb2N1cy12aXNpYmxlOnJpbmctb2Zmc2V0LTEgZm9jdXMtdmlzaWJsZTpyaW5nLW9mZnNldC1iYWNrZ3JvdW5kXCIsXG4gICAgICAgICAgICAgICAgaXNBY3RpdmVcbiAgICAgICAgICAgICAgICAgID8gXCJiZy1zdXJmYWNlLTIgdGV4dC1pbmtcIlxuICAgICAgICAgICAgICAgICAgOiBcInRleHQtaW5rLXNlY29uZGFyeSBob3Zlcjp0ZXh0LWlua1wiXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICAgIHt0YWIubGFiZWx9XG4gICAgICAgICAgICAgICAge3RhYi5jb3VudCAhPT0gdW5kZWZpbmVkICYmIHRhYi5jb3VudCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICBcImZsZXggaC1bMTdweF0gbWluLXctNC41IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgcHgtMSB0ZXh0LVsxMHB4XSBmb250LW1lZGl1bVwiLFxuICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctc3VyZmFjZS0zIHRleHQtaW5rXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1zdXJmYWNlLTIgdGV4dC1pbmstbXV0ZWRcIlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7dGFiLmNvdW50fVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICk7XG4gICAgICAgIH0pfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9jb21wb25lbnRzL1RhYkJhci50c3gifQ==