import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/command.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/command.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
"use client";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const React = ((m) => m?.__esModule ? m : { ...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {}, default: m })(__vite__cjsImport3_react);
import { Command as CommandPrimitive } from "/node_modules/.vite/deps/cmdk.js?v=d2f794f8";
import { Search } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { cn } from "/src/lib/utils.ts";
import { Dialog, DialogContent } from "/src/components/ui/dialog.tsx";
const Command = React.forwardRef(
  _c = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    CommandPrimitive,
    {
      ref,
      className: cn(
        "flex h-full w-full flex-col overflow-hidden rounded-md bg-popover text-popover-foreground",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/command.tsx",
      lineNumber: 34,
      columnNumber: 1
    },
    this
  )
);
_c2 = Command;
Command.displayName = CommandPrimitive.displayName;
const CommandDialog = ({ children, ...props }) => {
  return /* @__PURE__ */ jsxDEV(Dialog, { ...props, children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "overflow-hidden p-0 shadow-xl", children: /* @__PURE__ */ jsxDEV(Command, { className: "[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-2 [&_[cmdk-group-heading]]:text-[11px] [&_[cmdk-group-heading]]:font-semibold [&_[cmdk-group-heading]]:uppercase [&_[cmdk-group-heading]]:tracking-wide [&_[cmdk-group-heading]]:text-muted-foreground [&_[cmdk-group]:not([hidden])_~[cmdk-group]]:pt-0 [&_[cmdk-group]]:px-2 [&_[cmdk-input-wrapper]_svg]:h-4 [&_[cmdk-input-wrapper]_svg]:w-4 [&_[cmdk-input]]:h-11 [&_[cmdk-item]]:px-2 [&_[cmdk-item]]:py-2.5 [&_[cmdk-item]_svg]:h-4 [&_[cmdk-item]_svg]:w-4", children }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/command.tsx",
    lineNumber: 49,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/command.tsx",
    lineNumber: 48,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/command.tsx",
    lineNumber: 47,
    columnNumber: 5
  }, this);
};
_c3 = CommandDialog;
const CommandInput = React.forwardRef(
  _c4 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center border-b border-border px-3", "cmdk-input-wrapper": "", children: [
    /* @__PURE__ */ jsxDEV(Search, { className: "mr-2 h-4 w-4 shrink-0 text-muted-foreground" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/command.tsx",
      lineNumber: 62,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV(
      CommandPrimitive.Input,
      {
        ref,
        className: cn(
          "flex h-11 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50",
          className
        ),
        ...props
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/command.tsx",
        lineNumber: 63,
        columnNumber: 5
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/command.tsx",
    lineNumber: 61,
    columnNumber: 1
  }, this)
);
_c5 = CommandInput;
CommandInput.displayName = CommandPrimitive.Input.displayName;
const CommandList = React.forwardRef(
  _c6 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    CommandPrimitive.List,
    {
      ref,
      className: cn("max-h-[420px] overflow-y-auto overflow-x-hidden", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/command.tsx",
      lineNumber: 79,
      columnNumber: 1
    },
    this
  )
);
_c7 = CommandList;
CommandList.displayName = CommandPrimitive.List.displayName;
const CommandEmpty = React.forwardRef(
  _c8 = (props, ref) => /* @__PURE__ */ jsxDEV(
    CommandPrimitive.Empty,
    {
      ref,
      className: "py-6 text-center text-sm text-muted-foreground",
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/command.tsx",
      lineNumber: 91,
      columnNumber: 1
    },
    this
  )
);
_c9 = CommandEmpty;
CommandEmpty.displayName = CommandPrimitive.Empty.displayName;
const CommandGroup = React.forwardRef(
  _c0 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    CommandPrimitive.Group,
    {
      ref,
      className: cn(
        "overflow-hidden px-2 py-1 text-foreground [&_[cmdk-group-heading]]:px-1",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/command.tsx",
      lineNumber: 103,
      columnNumber: 1
    },
    this
  )
);
_c1 = CommandGroup;
CommandGroup.displayName = CommandPrimitive.Group.displayName;
const CommandSeparator = React.forwardRef(
  _c10 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    CommandPrimitive.Separator,
    {
      ref,
      className: cn("-mx-1 h-px bg-border", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/command.tsx",
      lineNumber: 118,
      columnNumber: 1
    },
    this
  )
);
_c11 = CommandSeparator;
CommandSeparator.displayName = CommandPrimitive.Separator.displayName;
const CommandItem = React.forwardRef(
  _c12 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    CommandPrimitive.Item,
    {
      ref,
      className: cn(
        "relative flex cursor-default select-none items-center gap-2 rounded-md px-2 py-2.5 text-sm outline-none data-[disabled=true]:pointer-events-none data-[selected=true]:bg-accent data-[selected=true]:text-accent-foreground data-[disabled=true]:opacity-50",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/command.tsx",
      lineNumber: 130,
      columnNumber: 1
    },
    this
  )
);
_c13 = CommandItem;
CommandItem.displayName = CommandPrimitive.Item.displayName;
const CommandShortcut = ({
  className,
  ...props
}) => {
  return /* @__PURE__ */ jsxDEV("span", { className: cn("ml-auto text-xs tracking-wide text-muted-foreground", className), ...props }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/command.tsx",
    lineNumber: 146,
    columnNumber: 5
  }, this);
};
_c14 = CommandShortcut;
CommandShortcut.displayName = "CommandShortcut";
export {
  Command,
  CommandDialog,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandShortcut,
  CommandSeparator
};
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0, _c1, _c10, _c11, _c12, _c13, _c14;
$RefreshReg$(_c, "Command$React.forwardRef");
$RefreshReg$(_c2, "Command");
$RefreshReg$(_c3, "CommandDialog");
$RefreshReg$(_c4, "CommandInput$React.forwardRef");
$RefreshReg$(_c5, "CommandInput");
$RefreshReg$(_c6, "CommandList$React.forwardRef");
$RefreshReg$(_c7, "CommandList");
$RefreshReg$(_c8, "CommandEmpty$React.forwardRef");
$RefreshReg$(_c9, "CommandEmpty");
$RefreshReg$(_c0, "CommandGroup$React.forwardRef");
$RefreshReg$(_c1, "CommandGroup");
$RefreshReg$(_c10, "CommandSeparator$React.forwardRef");
$RefreshReg$(_c11, "CommandSeparator");
$RefreshReg$(_c12, "CommandItem$React.forwardRef");
$RefreshReg$(_c13, "CommandItem");
$RefreshReg$(_c14, "CommandShortcut");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/command.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/command.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY0U7Ozs7Ozs7Ozs7Ozs7Ozs7QUFkRjtBQUVBLFlBQVlBLFdBQVc7QUFFdkIsU0FBU0MsV0FBV0Msd0JBQXdCO0FBQzVDLFNBQVNDLGNBQWM7QUFFdkIsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxRQUFRQyxxQkFBcUI7QUFFdEMsTUFBTUwsVUFBVUQsTUFBTU87QUFBQUEsRUFHckJDLEtBQUNBLENBQUMsRUFBRUMsV0FBVyxHQUFHQyxNQUFNLEdBQUdDLFFBQzFCO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQztBQUFBLE1BQ0EsV0FBV1A7QUFBQUEsUUFDVDtBQUFBLFFBQ0FLO0FBQUFBLE1BQ0Y7QUFBQSxNQUNBLEdBQUlDO0FBQUFBO0FBQUFBLElBTk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTVk7QUFFYjtBQUFDRSxNQVpJWDtBQWFOQSxRQUFRWSxjQUFjWCxpQkFBaUJXO0FBRXZDLE1BQU1DLGdCQUFnQkEsQ0FBQyxFQUFFQyxVQUFVLEdBQUdMLE1BQW1CLE1BQU07QUFDN0QsU0FDRSx1QkFBQyxVQUFPLEdBQUlBLE9BQ1YsaUNBQUMsaUJBQWMsV0FBVSxpQ0FDdkIsaUNBQUMsV0FBUSxXQUFVLGdnQkFDaEJLLFlBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BO0FBRUo7QUFBQ0MsTUFWS0Y7QUFZTixNQUFNRyxlQUFlakIsTUFBTU87QUFBQUEsRUFHMUJXLE1BQUNBLENBQUMsRUFBRVQsV0FBVyxHQUFHQyxNQUFNLEdBQUdDLFFBQzFCLHVCQUFDLFNBQUksV0FBVSxpREFBZ0Qsc0JBQW1CLElBQ2hGO0FBQUEsMkJBQUMsVUFBTyxXQUFVLGlEQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStEO0FBQUEsSUFDL0Q7QUFBQSxNQUFDLGlCQUFpQjtBQUFBLE1BQWpCO0FBQUEsUUFDQztBQUFBLFFBQ0EsV0FBV1A7QUFBQUEsVUFDVDtBQUFBLFVBQ0FLO0FBQUFBLFFBQ0Y7QUFBQSxRQUNBLEdBQUlDO0FBQUFBO0FBQUFBLE1BTk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTVk7QUFBQSxPQVJkO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FVQTtBQUNEO0FBQUNTLE1BZklGO0FBZ0JOQSxhQUFhSixjQUFjWCxpQkFBaUJrQixNQUFNUDtBQUVsRCxNQUFNUSxjQUFjckIsTUFBTU87QUFBQUEsRUFHekJlLE1BQUNBLENBQUMsRUFBRWIsV0FBVyxHQUFHQyxNQUFNLEdBQUdDLFFBQzFCO0FBQUEsSUFBQyxpQkFBaUI7QUFBQSxJQUFqQjtBQUFBLE1BQ0M7QUFBQSxNQUNBLFdBQVdQLEdBQUcsbURBQW1ESyxTQUFTO0FBQUEsTUFDMUUsR0FBSUM7QUFBQUE7QUFBQUEsSUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFHWTtBQUViO0FBQUNhLE1BVElGO0FBVU5BLFlBQVlSLGNBQWNYLGlCQUFpQnNCLEtBQUtYO0FBRWhELE1BQU1ZLGVBQWV6QixNQUFNTztBQUFBQSxFQUcxQm1CLE1BQUNBLENBQUNoQixPQUFPQyxRQUNSO0FBQUEsSUFBQyxpQkFBaUI7QUFBQSxJQUFqQjtBQUFBLE1BQ0M7QUFBQSxNQUNBLFdBQVU7QUFBQSxNQUNWLEdBQUlEO0FBQUFBO0FBQUFBLElBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBR1k7QUFFYjtBQUFDaUIsTUFUSUY7QUFVTkEsYUFBYVosY0FBY1gsaUJBQWlCMEIsTUFBTWY7QUFFbEQsTUFBTWdCLGVBQWU3QixNQUFNTztBQUFBQSxFQUcxQnVCLE1BQUNBLENBQUMsRUFBRXJCLFdBQVcsR0FBR0MsTUFBTSxHQUFHQyxRQUMxQjtBQUFBLElBQUMsaUJBQWlCO0FBQUEsSUFBakI7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXUDtBQUFBQSxRQUNUO0FBQUEsUUFDQUs7QUFBQUEsTUFDRjtBQUFBLE1BQ0EsR0FBSUM7QUFBQUE7QUFBQUEsSUFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNWTtBQUViO0FBQUNxQixNQVpJRjtBQWFOQSxhQUFhaEIsY0FBY1gsaUJBQWlCOEIsTUFBTW5CO0FBRWxELE1BQU1vQixtQkFBbUJqQyxNQUFNTztBQUFBQSxFQUc5QjJCLE9BQUNBLENBQUMsRUFBRXpCLFdBQVcsR0FBR0MsTUFBTSxHQUFHQyxRQUMxQjtBQUFBLElBQUMsaUJBQWlCO0FBQUEsSUFBakI7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXUCxHQUFHLHdCQUF3QkssU0FBUztBQUFBLE1BQy9DLEdBQUlDO0FBQUFBO0FBQUFBLElBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBR1k7QUFFYjtBQUFDeUIsT0FUSUY7QUFVTkEsaUJBQWlCcEIsY0FBY1gsaUJBQWlCa0MsVUFBVXZCO0FBRTFELE1BQU13QixjQUFjckMsTUFBTU87QUFBQUEsRUFHekIrQixPQUFDQSxDQUFDLEVBQUU3QixXQUFXLEdBQUdDLE1BQU0sR0FBR0MsUUFDMUI7QUFBQSxJQUFDLGlCQUFpQjtBQUFBLElBQWpCO0FBQUEsTUFDQztBQUFBLE1BQ0EsV0FBV1A7QUFBQUEsUUFDVDtBQUFBLFFBQ0FLO0FBQUFBLE1BQ0Y7QUFBQSxNQUNBLEdBQUlDO0FBQUFBO0FBQUFBLElBTk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTVk7QUFFYjtBQUFDNkIsT0FaSUY7QUFhTkEsWUFBWXhCLGNBQWNYLGlCQUFpQnNDLEtBQUszQjtBQUVoRCxNQUFNNEIsa0JBQWtCQSxDQUFDO0FBQUEsRUFDdkJoQztBQUFBQSxFQUNBLEdBQUdDO0FBQ2tDLE1BQU07QUFDM0MsU0FDRSx1QkFBQyxVQUFLLFdBQVdOLEdBQUcsdURBQXVESyxTQUFTLEdBQUcsR0FBSUMsU0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFpRztBQUVyRztBQUFDZ0MsT0FQS0Q7QUFRTkEsZ0JBQWdCNUIsY0FBYztBQUU5QjtBQUFBLEVBQ0VaO0FBQUFBLEVBQ0FhO0FBQUFBLEVBQ0FHO0FBQUFBLEVBQ0FJO0FBQUFBLEVBQ0FJO0FBQUFBLEVBQ0FJO0FBQUFBLEVBQ0FRO0FBQUFBLEVBQ0FJO0FBQUFBLEVBQ0FSO0FBQUFBO0FBQ0QsSUFBQXpCLElBQUFJLEtBQUFJLEtBQUFFLEtBQUFDLEtBQUFHLEtBQUFDLEtBQUFHLEtBQUFDLEtBQUFHLEtBQUFDLEtBQUFHLE1BQUFDLE1BQUFHLE1BQUFDLE1BQUFHO0FBQUEsYUFBQWxDLElBQUE7QUFBQSxhQUFBSSxLQUFBO0FBQUEsYUFBQUksS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUcsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBRyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFHLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUcsTUFBQTtBQUFBLGFBQUFDLE1BQUE7QUFBQSxhQUFBRyxNQUFBO0FBQUEsYUFBQUMsTUFBQTtBQUFBLGFBQUFHLE1BQUEiLCJuYW1lcyI6WyJSZWFjdCIsIkNvbW1hbmQiLCJDb21tYW5kUHJpbWl0aXZlIiwiU2VhcmNoIiwiY24iLCJEaWFsb2ciLCJEaWFsb2dDb250ZW50IiwiZm9yd2FyZFJlZiIsIl9jIiwiY2xhc3NOYW1lIiwicHJvcHMiLCJyZWYiLCJfYzIiLCJkaXNwbGF5TmFtZSIsIkNvbW1hbmREaWFsb2ciLCJjaGlsZHJlbiIsIl9jMyIsIkNvbW1hbmRJbnB1dCIsIl9jNCIsIl9jNSIsIklucHV0IiwiQ29tbWFuZExpc3QiLCJfYzYiLCJfYzciLCJMaXN0IiwiQ29tbWFuZEVtcHR5IiwiX2M4IiwiX2M5IiwiRW1wdHkiLCJDb21tYW5kR3JvdXAiLCJfYzAiLCJfYzEiLCJHcm91cCIsIkNvbW1hbmRTZXBhcmF0b3IiLCJfYzEwIiwiX2MxMSIsIlNlcGFyYXRvciIsIkNvbW1hbmRJdGVtIiwiX2MxMiIsIl9jMTMiLCJJdGVtIiwiQ29tbWFuZFNob3J0Y3V0IiwiX2MxNCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJjb21tYW5kLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBjbGllbnRcIlxuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIlxuaW1wb3J0IHsgdHlwZSBEaWFsb2dQcm9wcyB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtZGlhbG9nXCJcbmltcG9ydCB7IENvbW1hbmQgYXMgQ29tbWFuZFByaW1pdGl2ZSB9IGZyb20gXCJjbWRrXCJcbmltcG9ydCB7IFNlYXJjaCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIlxuXG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiXG5pbXBvcnQgeyBEaWFsb2csIERpYWxvZ0NvbnRlbnQgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2RpYWxvZ1wiXG5cbmNvbnN0IENvbW1hbmQgPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBSZWFjdC5FbGVtZW50UmVmPHR5cGVvZiBDb21tYW5kUHJpbWl0aXZlPixcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBDb21tYW5kUHJpbWl0aXZlPlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8Q29tbWFuZFByaW1pdGl2ZVxuICAgIHJlZj17cmVmfVxuICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICBcImZsZXggaC1mdWxsIHctZnVsbCBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1tZCBiZy1wb3BvdmVyIHRleHQtcG9wb3Zlci1mb3JlZ3JvdW5kXCIsXG4gICAgICBjbGFzc05hbWVcbiAgICApfVxuICAgIHsuLi5wcm9wc31cbiAgLz5cbikpXG5Db21tYW5kLmRpc3BsYXlOYW1lID0gQ29tbWFuZFByaW1pdGl2ZS5kaXNwbGF5TmFtZVxuXG5jb25zdCBDb21tYW5kRGlhbG9nID0gKHsgY2hpbGRyZW4sIC4uLnByb3BzIH06IERpYWxvZ1Byb3BzKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPERpYWxvZyB7Li4ucHJvcHN9PlxuICAgICAgPERpYWxvZ0NvbnRlbnQgY2xhc3NOYW1lPVwib3ZlcmZsb3ctaGlkZGVuIHAtMCBzaGFkb3cteGxcIj5cbiAgICAgICAgPENvbW1hbmQgY2xhc3NOYW1lPVwiWyZfW2NtZGstZ3JvdXAtaGVhZGluZ11dOnB4LTIgWyZfW2NtZGstZ3JvdXAtaGVhZGluZ11dOnB5LTIgWyZfW2NtZGstZ3JvdXAtaGVhZGluZ11dOnRleHQtWzExcHhdIFsmX1tjbWRrLWdyb3VwLWhlYWRpbmddXTpmb250LXNlbWlib2xkIFsmX1tjbWRrLWdyb3VwLWhlYWRpbmddXTp1cHBlcmNhc2UgWyZfW2NtZGstZ3JvdXAtaGVhZGluZ11dOnRyYWNraW5nLXdpZGUgWyZfW2NtZGstZ3JvdXAtaGVhZGluZ11dOnRleHQtbXV0ZWQtZm9yZWdyb3VuZCBbJl9bY21kay1ncm91cF06bm90KFtoaWRkZW5dKV9+W2NtZGstZ3JvdXBdXTpwdC0wIFsmX1tjbWRrLWdyb3VwXV06cHgtMiBbJl9bY21kay1pbnB1dC13cmFwcGVyXV9zdmddOmgtNCBbJl9bY21kay1pbnB1dC13cmFwcGVyXV9zdmddOnctNCBbJl9bY21kay1pbnB1dF1dOmgtMTEgWyZfW2NtZGstaXRlbV1dOnB4LTIgWyZfW2NtZGstaXRlbV1dOnB5LTIuNSBbJl9bY21kay1pdGVtXV9zdmddOmgtNCBbJl9bY21kay1pdGVtXV9zdmddOnctNFwiPlxuICAgICAgICAgIHtjaGlsZHJlbn1cbiAgICAgICAgPC9Db21tYW5kPlxuICAgICAgPC9EaWFsb2dDb250ZW50PlxuICAgIDwvRGlhbG9nPlxuICApXG59XG5cbmNvbnN0IENvbW1hbmRJbnB1dCA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIFJlYWN0LkVsZW1lbnRSZWY8dHlwZW9mIENvbW1hbmRQcmltaXRpdmUuSW5wdXQ+LFxuICBSZWFjdC5Db21wb25lbnRQcm9wc1dpdGhvdXRSZWY8dHlwZW9mIENvbW1hbmRQcmltaXRpdmUuSW5wdXQ+XG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgYm9yZGVyLWIgYm9yZGVyLWJvcmRlciBweC0zXCIgY21kay1pbnB1dC13cmFwcGVyPVwiXCI+XG4gICAgPFNlYXJjaCBjbGFzc05hbWU9XCJtci0yIGgtNCB3LTQgc2hyaW5rLTAgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgLz5cbiAgICA8Q29tbWFuZFByaW1pdGl2ZS5JbnB1dFxuICAgICAgcmVmPXtyZWZ9XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcImZsZXggaC0xMSB3LWZ1bGwgcm91bmRlZC1tZCBiZy10cmFuc3BhcmVudCBweS0zIHRleHQtc20gb3V0bGluZS1ub25lIHBsYWNlaG9sZGVyOnRleHQtbXV0ZWQtZm9yZWdyb3VuZCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgZGlzYWJsZWQ6b3BhY2l0eS01MFwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgPC9kaXY+XG4pKVxuQ29tbWFuZElucHV0LmRpc3BsYXlOYW1lID0gQ29tbWFuZFByaW1pdGl2ZS5JbnB1dC5kaXNwbGF5TmFtZVxuXG5jb25zdCBDb21tYW5kTGlzdCA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIFJlYWN0LkVsZW1lbnRSZWY8dHlwZW9mIENvbW1hbmRQcmltaXRpdmUuTGlzdD4sXG4gIFJlYWN0LkNvbXBvbmVudFByb3BzV2l0aG91dFJlZjx0eXBlb2YgQ29tbWFuZFByaW1pdGl2ZS5MaXN0PlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8Q29tbWFuZFByaW1pdGl2ZS5MaXN0XG4gICAgcmVmPXtyZWZ9XG4gICAgY2xhc3NOYW1lPXtjbihcIm1heC1oLVs0MjBweF0gb3ZlcmZsb3cteS1hdXRvIG92ZXJmbG93LXgtaGlkZGVuXCIsIGNsYXNzTmFtZSl9XG4gICAgey4uLnByb3BzfVxuICAvPlxuKSlcbkNvbW1hbmRMaXN0LmRpc3BsYXlOYW1lID0gQ29tbWFuZFByaW1pdGl2ZS5MaXN0LmRpc3BsYXlOYW1lXG5cbmNvbnN0IENvbW1hbmRFbXB0eSA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIFJlYWN0LkVsZW1lbnRSZWY8dHlwZW9mIENvbW1hbmRQcmltaXRpdmUuRW1wdHk+LFxuICBSZWFjdC5Db21wb25lbnRQcm9wc1dpdGhvdXRSZWY8dHlwZW9mIENvbW1hbmRQcmltaXRpdmUuRW1wdHk+XG4+KChwcm9wcywgcmVmKSA9PiAoXG4gIDxDb21tYW5kUHJpbWl0aXZlLkVtcHR5XG4gICAgcmVmPXtyZWZ9XG4gICAgY2xhc3NOYW1lPVwicHktNiB0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiXG4gICAgey4uLnByb3BzfVxuICAvPlxuKSlcbkNvbW1hbmRFbXB0eS5kaXNwbGF5TmFtZSA9IENvbW1hbmRQcmltaXRpdmUuRW1wdHkuZGlzcGxheU5hbWVcblxuY29uc3QgQ29tbWFuZEdyb3VwID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgUmVhY3QuRWxlbWVudFJlZjx0eXBlb2YgQ29tbWFuZFByaW1pdGl2ZS5Hcm91cD4sXG4gIFJlYWN0LkNvbXBvbmVudFByb3BzV2l0aG91dFJlZjx0eXBlb2YgQ29tbWFuZFByaW1pdGl2ZS5Hcm91cD5cbj4oKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9LCByZWYpID0+IChcbiAgPENvbW1hbmRQcmltaXRpdmUuR3JvdXBcbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgXCJvdmVyZmxvdy1oaWRkZW4gcHgtMiBweS0xIHRleHQtZm9yZWdyb3VuZCBbJl9bY21kay1ncm91cC1oZWFkaW5nXV06cHgtMVwiLFxuICAgICAgY2xhc3NOYW1lXG4gICAgKX1cbiAgICB7Li4ucHJvcHN9XG4gIC8+XG4pKVxuQ29tbWFuZEdyb3VwLmRpc3BsYXlOYW1lID0gQ29tbWFuZFByaW1pdGl2ZS5Hcm91cC5kaXNwbGF5TmFtZVxuXG5jb25zdCBDb21tYW5kU2VwYXJhdG9yID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgUmVhY3QuRWxlbWVudFJlZjx0eXBlb2YgQ29tbWFuZFByaW1pdGl2ZS5TZXBhcmF0b3I+LFxuICBSZWFjdC5Db21wb25lbnRQcm9wc1dpdGhvdXRSZWY8dHlwZW9mIENvbW1hbmRQcmltaXRpdmUuU2VwYXJhdG9yPlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8Q29tbWFuZFByaW1pdGl2ZS5TZXBhcmF0b3JcbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFwiLW14LTEgaC1weCBiZy1ib3JkZXJcIiwgY2xhc3NOYW1lKX1cbiAgICB7Li4ucHJvcHN9XG4gIC8+XG4pKVxuQ29tbWFuZFNlcGFyYXRvci5kaXNwbGF5TmFtZSA9IENvbW1hbmRQcmltaXRpdmUuU2VwYXJhdG9yLmRpc3BsYXlOYW1lXG5cbmNvbnN0IENvbW1hbmRJdGVtID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgUmVhY3QuRWxlbWVudFJlZjx0eXBlb2YgQ29tbWFuZFByaW1pdGl2ZS5JdGVtPixcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBDb21tYW5kUHJpbWl0aXZlLkl0ZW0+XG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDxDb21tYW5kUHJpbWl0aXZlLkl0ZW1cbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgXCJyZWxhdGl2ZSBmbGV4IGN1cnNvci1kZWZhdWx0IHNlbGVjdC1ub25lIGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLW1kIHB4LTIgcHktMi41IHRleHQtc20gb3V0bGluZS1ub25lIGRhdGEtW2Rpc2FibGVkPXRydWVdOnBvaW50ZXItZXZlbnRzLW5vbmUgZGF0YS1bc2VsZWN0ZWQ9dHJ1ZV06YmctYWNjZW50IGRhdGEtW3NlbGVjdGVkPXRydWVdOnRleHQtYWNjZW50LWZvcmVncm91bmQgZGF0YS1bZGlzYWJsZWQ9dHJ1ZV06b3BhY2l0eS01MFwiLFxuICAgICAgY2xhc3NOYW1lXG4gICAgKX1cbiAgICB7Li4ucHJvcHN9XG4gIC8+XG4pKVxuQ29tbWFuZEl0ZW0uZGlzcGxheU5hbWUgPSBDb21tYW5kUHJpbWl0aXZlLkl0ZW0uZGlzcGxheU5hbWVcblxuY29uc3QgQ29tbWFuZFNob3J0Y3V0ID0gKHtcbiAgY2xhc3NOYW1lLFxuICAuLi5wcm9wc1xufTogUmVhY3QuSFRNTEF0dHJpYnV0ZXM8SFRNTFNwYW5FbGVtZW50PikgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzcGFuIGNsYXNzTmFtZT17Y24oXCJtbC1hdXRvIHRleHQteHMgdHJhY2tpbmctd2lkZSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIiwgY2xhc3NOYW1lKX0gey4uLnByb3BzfSAvPlxuICApXG59XG5Db21tYW5kU2hvcnRjdXQuZGlzcGxheU5hbWUgPSBcIkNvbW1hbmRTaG9ydGN1dFwiXG5cbmV4cG9ydCB7XG4gIENvbW1hbmQsXG4gIENvbW1hbmREaWFsb2csXG4gIENvbW1hbmRJbnB1dCxcbiAgQ29tbWFuZExpc3QsXG4gIENvbW1hbmRFbXB0eSxcbiAgQ29tbWFuZEdyb3VwLFxuICBDb21tYW5kSXRlbSxcbiAgQ29tbWFuZFNob3J0Y3V0LFxuICBDb21tYW5kU2VwYXJhdG9yLFxufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvY29tcG9uZW50cy91aS9jb21tYW5kLnRzeCJ9