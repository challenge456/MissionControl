import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/sections/ControlSection.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { ClipboardList, Orbit, ShieldCheck, Waypoints } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { PageHeader } from "/src/components/PageHeader.tsx";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { FactoryOverviewView } from "/src/controlPlane/FactoryOverviewView.tsx";
import { WorkOrdersView } from "/src/controlPlane/WorkOrdersView.tsx";
import { WorkOrderApprovalsView } from "/src/controlPlane/WorkOrderApprovalsView.tsx";
const VIEW_COPY = {
  "control-portfolio": {
    title: "Portfolio",
    description: "Track operator-facing software factory work at the request and outcome layer."
  },
  "control-work-orders": {
    title: "Work Orders",
    description: "Create and inspect first-class software-factory requests, acceptance criteria, and linked execution runs."
  },
  "control-fleet": {
    title: "Fleet",
    description: "Inspect execution capacity and future fleet-level controls from one shell entrypoint."
  },
  "control-approvals": {
    title: "Approvals",
    description: "Route human decisions through a dedicated control-plane surface as approval workflows come online."
  }
};
const CONTROL_VIEWS = [
  { id: "control-portfolio", icon: Orbit },
  { id: "control-work-orders", icon: ClipboardList },
  { id: "control-fleet", icon: Waypoints },
  { id: "control-approvals", icon: ShieldCheck }
];
export function ControlSection({ currentView, projectId, onNavigate }) {
  const activeView = CONTROL_VIEWS.some((view) => view.id === currentView) ? currentView : "control-portfolio";
  if (activeView === "control-work-orders") {
    return /* @__PURE__ */ jsxDEV(WorkOrdersView, { projectId }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
      lineNumber: 73,
      columnNumber: 12
    }, this);
  }
  if (activeView === "control-approvals") {
    return /* @__PURE__ */ jsxDEV(WorkOrderApprovalsView, { projectId }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
      lineNumber: 77,
      columnNumber: 12
    }, this);
  }
  if (activeView === "control-portfolio") {
    return /* @__PURE__ */ jsxDEV(FactoryOverviewView, { projectId, onNavigate }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
      lineNumber: 81,
      columnNumber: 12
    }, this);
  }
  const activeCopy = VIEW_COPY[activeView];
  return /* @__PURE__ */ jsxDEV("section", { className: "flex flex-1 flex-col overflow-hidden", children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        eyebrow: "Control plane",
        title: "Control",
        description: "Minimal control-plane shell plus the Work Orders slice for governed software-factory execution.",
        icon: /* @__PURE__ */ jsxDEV(Orbit, { className: "h-5 w-5" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
          lineNumber: 92,
          columnNumber: 15
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
        lineNumber: 88,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "factory-content", children: /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 xl:grid-cols-[minmax(0,280px)_minmax(0,1fr)]", children: [
      /* @__PURE__ */ jsxDEV(Card, { children: [
        /* @__PURE__ */ jsxDEV(CardHeader, { children: [
          /* @__PURE__ */ jsxDEV(CardTitle, { children: "Surface navigation" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
            lineNumber: 99,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CardDescription, { children: "Stable shell entrypoints for the Control section. Work Orders is live; the other views remain intentionally lightweight until follow-on control-plane slices are wired." }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
            lineNumber: 100,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
          lineNumber: 98,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(CardContent, { className: "space-y-2", children: CONTROL_VIEWS.map(({ id, icon: Icon }) => {
          const isActive = id === activeView;
          return /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "button",
              variant: isActive ? "neon-cyan" : "outline",
              className: "w-full justify-start",
              onClick: () => onNavigate(id),
              children: [
                /* @__PURE__ */ jsxDEV(Icon, { className: "h-4 w-4" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
                  lineNumber: 115,
                  columnNumber: 21
                }, this),
                VIEW_COPY[id].title
              ]
            },
            id,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
              lineNumber: 108,
              columnNumber: 19
            },
            this
          );
        }) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
          lineNumber: 104,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
        lineNumber: 97,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { children: [
        /* @__PURE__ */ jsxDEV(CardHeader, { children: [
          /* @__PURE__ */ jsxDEV(CardTitle, { children: activeCopy.title }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
            lineNumber: 125,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CardDescription, { children: activeCopy.description }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
            lineNumber: 126,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
          lineNumber: 124,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(CardContent, { className: "space-y-4 text-sm text-muted-foreground", children: [
          /* @__PURE__ */ jsxDEV("p", { children: "This landing state keeps the application shell stable while follow-on control-plane work arrives incrementally. It preserves the section boundary introduced by the shell PR without pulling demo-heavy execution logic back into the WorkOrder slice." }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
            lineNumber: 129,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid gap-3 md:grid-cols-3", children: [
            /* @__PURE__ */ jsxDEV(
              ControlNote,
              {
                title: "Section boundary",
                body: "Control routes independently from Home, Ops, and Platform while preserving all existing shell views."
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
                lineNumber: 135,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              ControlNote,
              {
                title: "Live slice",
                body: "Work Orders now uses real Convex-backed data and governed dispatch behavior within this section."
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
                lineNumber: 139,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              ControlNote,
              {
                title: "Follow-on space",
                body: "Portfolio, Fleet, and Approvals remain stable placeholders until those slices are implemented on their own merits."
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
                lineNumber: 143,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
            lineNumber: 134,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
          lineNumber: 128,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
        lineNumber: 123,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
      lineNumber: 96,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
      lineNumber: 95,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
    lineNumber: 87,
    columnNumber: 5
  }, this);
}
_c = ControlSection;
function ControlNote({ title, body }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-[var(--panel-line)] bg-background/40 p-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold uppercase tracking-[0.16em] text-foreground/80", children: title }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
      lineNumber: 159,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm leading-relaxed text-muted-foreground", children: body }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
      lineNumber: 160,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx",
    lineNumber: 158,
    columnNumber: 5
  }, this);
}
_c2 = ControlNote;
var _c, _c2;
$RefreshReg$(_c, "ControlSection");
$RefreshReg$(_c2, "ControlNote");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/sections/ControlSection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcURXOzs7Ozs7Ozs7Ozs7Ozs7O0FBckRYLFNBQVNBLGVBQWVDLE9BQU9DLGFBQWFDLGlCQUFpQjtBQUU3RCxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsTUFBTUMsYUFBYUMsaUJBQWlCQyxZQUFZQyxpQkFBaUI7QUFDMUUsU0FBU0MsY0FBYztBQUV2QixTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLDhCQUE4QjtBQWF2QyxNQUFNQyxZQUF5RTtBQUFBLEVBQzdFLHFCQUFxQjtBQUFBLElBQ25CQyxPQUFPO0FBQUEsSUFDUEMsYUFBYTtBQUFBLEVBQ2Y7QUFBQSxFQUNBLHVCQUF1QjtBQUFBLElBQ3JCRCxPQUFPO0FBQUEsSUFDUEMsYUFBYTtBQUFBLEVBQ2Y7QUFBQSxFQUNBLGlCQUFpQjtBQUFBLElBQ2ZELE9BQU87QUFBQSxJQUNQQyxhQUFhO0FBQUEsRUFDZjtBQUFBLEVBQ0EscUJBQXFCO0FBQUEsSUFDbkJELE9BQU87QUFBQSxJQUNQQyxhQUFhO0FBQUEsRUFDZjtBQUNGO0FBRUEsTUFBTUMsZ0JBQWdFO0FBQUEsRUFDcEUsRUFBRUMsSUFBSSxxQkFBcUJDLE1BQU1sQixNQUFNO0FBQUEsRUFDdkMsRUFBRWlCLElBQUksdUJBQXVCQyxNQUFNbkIsY0FBYztBQUFBLEVBQ2pELEVBQUVrQixJQUFJLGlCQUFpQkMsTUFBTWhCLFVBQVU7QUFBQSxFQUN2QyxFQUFFZSxJQUFJLHFCQUFxQkMsTUFBTWpCLFlBQVk7QUFBQztBQUd6QyxnQkFBU2tCLGVBQWUsRUFBRUMsYUFBYUMsV0FBV0MsV0FBZ0MsR0FBRztBQUMxRixRQUFNQyxhQUFhUCxjQUFjUSxLQUFLLENBQUNDLFNBQVNBLEtBQUtSLE9BQU9HLFdBQVcsSUFDbEVBLGNBQ0Q7QUFFSixNQUFJRyxlQUFlLHVCQUF1QjtBQUN4QyxXQUFPLHVCQUFDLGtCQUFlLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUM7QUFBQSxFQUM5QztBQUVBLE1BQUlBLGVBQWUscUJBQXFCO0FBQ3RDLFdBQU8sdUJBQUMsMEJBQXVCLGFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkM7QUFBQSxFQUN0RDtBQUVBLE1BQUlBLGVBQWUscUJBQXFCO0FBQ3RDLFdBQU8sdUJBQUMsdUJBQW9CLFdBQXNCLGNBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0U7QUFBQSxFQUMzRTtBQUVBLFFBQU1HLGFBQWFiLFVBQVVVLFVBQVU7QUFFdkMsU0FDRSx1QkFBQyxhQUFRLFdBQVUsd0NBQ2pCO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVE7QUFBQSxRQUNSLE9BQU07QUFBQSxRQUNOLGFBQVk7QUFBQSxRQUNaLE1BQU0sdUJBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEI7QUFBQTtBQUFBLE1BSmxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUlzQztBQUFBLElBR3RDLHVCQUFDLFNBQUksV0FBVSxtQkFDYixpQ0FBQyxTQUFJLFdBQVUsMkRBQ2I7QUFBQSw2QkFBQyxRQUNDO0FBQUEsK0JBQUMsY0FDQztBQUFBLGlDQUFDLGFBQVUsa0NBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkI7QUFBQSxVQUM3Qix1QkFBQyxtQkFBZSx1TEFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFDQSx1QkFBQyxlQUFZLFdBQVUsYUFDcEJQLHdCQUFjVyxJQUFJLENBQUMsRUFBRVYsSUFBSUMsTUFBTVUsS0FBSyxNQUFNO0FBQ3pDLGdCQUFNQyxXQUFXWixPQUFPTTtBQUN4QixpQkFDRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsTUFBSztBQUFBLGNBQ0wsU0FBU00sV0FBVyxjQUFjO0FBQUEsY0FDbEMsV0FBVTtBQUFBLGNBQ1YsU0FBUyxNQUFNUCxXQUFXTCxFQUFFO0FBQUEsY0FFNUI7QUFBQSx1Q0FBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUI7QUFBQSxnQkFDeEJKLFVBQVVJLEVBQUUsRUFBRUg7QUFBQUE7QUFBQUE7QUFBQUEsWUFQVkc7QUFBQUEsWUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0E7QUFBQSxRQUVKLENBQUMsS0FmSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsV0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdCQTtBQUFBLE1BRUEsdUJBQUMsUUFDQztBQUFBLCtCQUFDLGNBQ0M7QUFBQSxpQ0FBQyxhQUFXUyxxQkFBV1osU0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkI7QUFBQSxVQUM3Qix1QkFBQyxtQkFBaUJZLHFCQUFXWCxlQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QztBQUFBLGFBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsZUFBWSxXQUFVLDJDQUNyQjtBQUFBLGlDQUFDLE9BQUMsc1FBQUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFNO0FBQUEsZ0JBQ04sTUFBSztBQUFBO0FBQUEsY0FGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFFNkc7QUFBQSxZQUU3RztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU07QUFBQSxnQkFDTixNQUFLO0FBQUE7QUFBQSxjQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUV5RztBQUFBLFlBRXpHO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTTtBQUFBLGdCQUNOLE1BQUs7QUFBQTtBQUFBLGNBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRTJIO0FBQUEsZUFYN0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLGFBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxXQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEJBO0FBQUEsU0FyREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNEQSxLQXZERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0RBO0FBQUEsT0FoRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlFQTtBQUVKO0FBQUNlLEtBdkZlWDtBQXlGaEIsU0FBU1ksWUFBWSxFQUFFakIsT0FBT2tCLEtBQXNDLEdBQUc7QUFDckUsU0FDRSx1QkFBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsd0VBQXdFbEIsbUJBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkY7QUFBQSxJQUM3Rix1QkFBQyxPQUFFLFdBQVUsc0RBQXNEa0Isa0JBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0U7QUFBQSxPQUYxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR0E7QUFFSjtBQUFDQyxNQVBRRjtBQUFXLElBQUFELElBQUFHO0FBQUEsYUFBQUgsSUFBQTtBQUFBLGFBQUFHLEtBQUEiLCJuYW1lcyI6WyJDbGlwYm9hcmRMaXN0IiwiT3JiaXQiLCJTaGllbGRDaGVjayIsIldheXBvaW50cyIsIlBhZ2VIZWFkZXIiLCJDYXJkIiwiQ2FyZENvbnRlbnQiLCJDYXJkRGVzY3JpcHRpb24iLCJDYXJkSGVhZGVyIiwiQ2FyZFRpdGxlIiwiQnV0dG9uIiwiRmFjdG9yeU92ZXJ2aWV3VmlldyIsIldvcmtPcmRlcnNWaWV3IiwiV29ya09yZGVyQXBwcm92YWxzVmlldyIsIlZJRVdfQ09QWSIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJDT05UUk9MX1ZJRVdTIiwiaWQiLCJpY29uIiwiQ29udHJvbFNlY3Rpb24iLCJjdXJyZW50VmlldyIsInByb2plY3RJZCIsIm9uTmF2aWdhdGUiLCJhY3RpdmVWaWV3Iiwic29tZSIsInZpZXciLCJhY3RpdmVDb3B5IiwibWFwIiwiSWNvbiIsImlzQWN0aXZlIiwiX2MiLCJDb250cm9sTm90ZSIsImJvZHkiLCJfYzIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29udHJvbFNlY3Rpb24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENsaXBib2FyZExpc3QsIE9yYml0LCBTaGllbGRDaGVjaywgV2F5cG9pbnRzIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHR5cGUgeyBJZCB9IGZyb20gXCIuLi8uLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9kYXRhTW9kZWxcIjtcbmltcG9ydCB7IFBhZ2VIZWFkZXIgfSBmcm9tIFwiQC9jb21wb25lbnRzL1BhZ2VIZWFkZXJcIjtcbmltcG9ydCB7IENhcmQsIENhcmRDb250ZW50LCBDYXJkRGVzY3JpcHRpb24sIENhcmRIZWFkZXIsIENhcmRUaXRsZSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvY2FyZFwiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9idXR0b25cIjtcbmltcG9ydCB0eXBlIHsgTWFpblZpZXcgfSBmcm9tIFwiLi4vVG9wTmF2XCI7XG5pbXBvcnQgeyBGYWN0b3J5T3ZlcnZpZXdWaWV3IH0gZnJvbSBcIi4uL2NvbnRyb2xQbGFuZS9GYWN0b3J5T3ZlcnZpZXdWaWV3XCI7XG5pbXBvcnQgeyBXb3JrT3JkZXJzVmlldyB9IGZyb20gXCIuLi9jb250cm9sUGxhbmUvV29ya09yZGVyc1ZpZXdcIjtcbmltcG9ydCB7IFdvcmtPcmRlckFwcHJvdmFsc1ZpZXcgfSBmcm9tIFwiLi4vY29udHJvbFBsYW5lL1dvcmtPcmRlckFwcHJvdmFsc1ZpZXdcIjtcblxuaW50ZXJmYWNlIENvbnRyb2xTZWN0aW9uUHJvcHMge1xuICBjdXJyZW50VmlldzogTWFpblZpZXc7XG4gIHByb2plY3RJZDogSWQ8XCJwcm9qZWN0c1wiPiB8IG51bGw7XG4gIG9uTmF2aWdhdGU6ICh2aWV3OiBNYWluVmlldykgPT4gdm9pZDtcbn1cblxudHlwZSBDb250cm9sVmlldyA9IEV4dHJhY3Q8XG4gIE1haW5WaWV3LFxuICBcImNvbnRyb2wtcG9ydGZvbGlvXCIgfCBcImNvbnRyb2wtd29yay1vcmRlcnNcIiB8IFwiY29udHJvbC1mbGVldFwiIHwgXCJjb250cm9sLWFwcHJvdmFsc1wiXG4+O1xuXG5jb25zdCBWSUVXX0NPUFk6IFJlY29yZDxDb250cm9sVmlldywgeyB0aXRsZTogc3RyaW5nOyBkZXNjcmlwdGlvbjogc3RyaW5nIH0+ID0ge1xuICBcImNvbnRyb2wtcG9ydGZvbGlvXCI6IHtcbiAgICB0aXRsZTogXCJQb3J0Zm9saW9cIixcbiAgICBkZXNjcmlwdGlvbjogXCJUcmFjayBvcGVyYXRvci1mYWNpbmcgc29mdHdhcmUgZmFjdG9yeSB3b3JrIGF0IHRoZSByZXF1ZXN0IGFuZCBvdXRjb21lIGxheWVyLlwiLFxuICB9LFxuICBcImNvbnRyb2wtd29yay1vcmRlcnNcIjoge1xuICAgIHRpdGxlOiBcIldvcmsgT3JkZXJzXCIsXG4gICAgZGVzY3JpcHRpb246IFwiQ3JlYXRlIGFuZCBpbnNwZWN0IGZpcnN0LWNsYXNzIHNvZnR3YXJlLWZhY3RvcnkgcmVxdWVzdHMsIGFjY2VwdGFuY2UgY3JpdGVyaWEsIGFuZCBsaW5rZWQgZXhlY3V0aW9uIHJ1bnMuXCIsXG4gIH0sXG4gIFwiY29udHJvbC1mbGVldFwiOiB7XG4gICAgdGl0bGU6IFwiRmxlZXRcIixcbiAgICBkZXNjcmlwdGlvbjogXCJJbnNwZWN0IGV4ZWN1dGlvbiBjYXBhY2l0eSBhbmQgZnV0dXJlIGZsZWV0LWxldmVsIGNvbnRyb2xzIGZyb20gb25lIHNoZWxsIGVudHJ5cG9pbnQuXCIsXG4gIH0sXG4gIFwiY29udHJvbC1hcHByb3ZhbHNcIjoge1xuICAgIHRpdGxlOiBcIkFwcHJvdmFsc1wiLFxuICAgIGRlc2NyaXB0aW9uOiBcIlJvdXRlIGh1bWFuIGRlY2lzaW9ucyB0aHJvdWdoIGEgZGVkaWNhdGVkIGNvbnRyb2wtcGxhbmUgc3VyZmFjZSBhcyBhcHByb3ZhbCB3b3JrZmxvd3MgY29tZSBvbmxpbmUuXCIsXG4gIH0sXG59O1xuXG5jb25zdCBDT05UUk9MX1ZJRVdTOiBBcnJheTx7IGlkOiBDb250cm9sVmlldzsgaWNvbjogdHlwZW9mIE9yYml0IH0+ID0gW1xuICB7IGlkOiBcImNvbnRyb2wtcG9ydGZvbGlvXCIsIGljb246IE9yYml0IH0sXG4gIHsgaWQ6IFwiY29udHJvbC13b3JrLW9yZGVyc1wiLCBpY29uOiBDbGlwYm9hcmRMaXN0IH0sXG4gIHsgaWQ6IFwiY29udHJvbC1mbGVldFwiLCBpY29uOiBXYXlwb2ludHMgfSxcbiAgeyBpZDogXCJjb250cm9sLWFwcHJvdmFsc1wiLCBpY29uOiBTaGllbGRDaGVjayB9LFxuXTtcblxuZXhwb3J0IGZ1bmN0aW9uIENvbnRyb2xTZWN0aW9uKHsgY3VycmVudFZpZXcsIHByb2plY3RJZCwgb25OYXZpZ2F0ZSB9OiBDb250cm9sU2VjdGlvblByb3BzKSB7XG4gIGNvbnN0IGFjdGl2ZVZpZXcgPSBDT05UUk9MX1ZJRVdTLnNvbWUoKHZpZXcpID0+IHZpZXcuaWQgPT09IGN1cnJlbnRWaWV3KVxuICAgID8gKGN1cnJlbnRWaWV3IGFzIENvbnRyb2xWaWV3KVxuICAgIDogXCJjb250cm9sLXBvcnRmb2xpb1wiO1xuXG4gIGlmIChhY3RpdmVWaWV3ID09PSBcImNvbnRyb2wtd29yay1vcmRlcnNcIikge1xuICAgIHJldHVybiA8V29ya09yZGVyc1ZpZXcgcHJvamVjdElkPXtwcm9qZWN0SWR9IC8+O1xuICB9XG5cbiAgaWYgKGFjdGl2ZVZpZXcgPT09IFwiY29udHJvbC1hcHByb3ZhbHNcIikge1xuICAgIHJldHVybiA8V29ya09yZGVyQXBwcm92YWxzVmlldyBwcm9qZWN0SWQ9e3Byb2plY3RJZH0gLz47XG4gIH1cblxuICBpZiAoYWN0aXZlVmlldyA9PT0gXCJjb250cm9sLXBvcnRmb2xpb1wiKSB7XG4gICAgcmV0dXJuIDxGYWN0b3J5T3ZlcnZpZXdWaWV3IHByb2plY3RJZD17cHJvamVjdElkfSBvbk5hdmlnYXRlPXtvbk5hdmlnYXRlfSAvPjtcbiAgfVxuXG4gIGNvbnN0IGFjdGl2ZUNvcHkgPSBWSUVXX0NPUFlbYWN0aXZlVmlld107XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtMSBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgIDxQYWdlSGVhZGVyXG4gICAgICAgIGV5ZWJyb3c9XCJDb250cm9sIHBsYW5lXCJcbiAgICAgICAgdGl0bGU9XCJDb250cm9sXCJcbiAgICAgICAgZGVzY3JpcHRpb249XCJNaW5pbWFsIGNvbnRyb2wtcGxhbmUgc2hlbGwgcGx1cyB0aGUgV29yayBPcmRlcnMgc2xpY2UgZm9yIGdvdmVybmVkIHNvZnR3YXJlLWZhY3RvcnkgZXhlY3V0aW9uLlwiXG4gICAgICAgIGljb249ezxPcmJpdCBjbGFzc05hbWU9XCJoLTUgdy01XCIgLz59XG4gICAgICAvPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZhY3RvcnktY29udGVudFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTQgeGw6Z3JpZC1jb2xzLVttaW5tYXgoMCwyODBweClfbWlubWF4KDAsMWZyKV1cIj5cbiAgICAgICAgICA8Q2FyZD5cbiAgICAgICAgICAgIDxDYXJkSGVhZGVyPlxuICAgICAgICAgICAgICA8Q2FyZFRpdGxlPlN1cmZhY2UgbmF2aWdhdGlvbjwvQ2FyZFRpdGxlPlxuICAgICAgICAgICAgICA8Q2FyZERlc2NyaXB0aW9uPlxuICAgICAgICAgICAgICAgIFN0YWJsZSBzaGVsbCBlbnRyeXBvaW50cyBmb3IgdGhlIENvbnRyb2wgc2VjdGlvbi4gV29yayBPcmRlcnMgaXMgbGl2ZTsgdGhlIG90aGVyIHZpZXdzIHJlbWFpbiBpbnRlbnRpb25hbGx5IGxpZ2h0d2VpZ2h0IHVudGlsIGZvbGxvdy1vbiBjb250cm9sLXBsYW5lIHNsaWNlcyBhcmUgd2lyZWQuXG4gICAgICAgICAgICAgIDwvQ2FyZERlc2NyaXB0aW9uPlxuICAgICAgICAgICAgPC9DYXJkSGVhZGVyPlxuICAgICAgICAgICAgPENhcmRDb250ZW50IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICB7Q09OVFJPTF9WSUVXUy5tYXAoKHsgaWQsIGljb246IEljb24gfSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlzQWN0aXZlID0gaWQgPT09IGFjdGl2ZVZpZXc7XG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAga2V5PXtpZH1cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9e2lzQWN0aXZlID8gXCJuZW9uLWN5YW5cIiA6IFwib3V0bGluZVwifVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwganVzdGlmeS1zdGFydFwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoaWQpfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAge1ZJRVdfQ09QWVtpZF0udGl0bGV9XG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgICAgICAgPC9DYXJkPlxuXG4gICAgICAgICAgPENhcmQ+XG4gICAgICAgICAgICA8Q2FyZEhlYWRlcj5cbiAgICAgICAgICAgICAgPENhcmRUaXRsZT57YWN0aXZlQ29weS50aXRsZX08L0NhcmRUaXRsZT5cbiAgICAgICAgICAgICAgPENhcmREZXNjcmlwdGlvbj57YWN0aXZlQ29weS5kZXNjcmlwdGlvbn08L0NhcmREZXNjcmlwdGlvbj5cbiAgICAgICAgICAgIDwvQ2FyZEhlYWRlcj5cbiAgICAgICAgICAgIDxDYXJkQ29udGVudCBjbGFzc05hbWU9XCJzcGFjZS15LTQgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgVGhpcyBsYW5kaW5nIHN0YXRlIGtlZXBzIHRoZSBhcHBsaWNhdGlvbiBzaGVsbCBzdGFibGUgd2hpbGUgZm9sbG93LW9uIGNvbnRyb2wtcGxhbmUgd29yayBhcnJpdmVzIGluY3JlbWVudGFsbHkuXG4gICAgICAgICAgICAgICAgSXQgcHJlc2VydmVzIHRoZSBzZWN0aW9uIGJvdW5kYXJ5IGludHJvZHVjZWQgYnkgdGhlIHNoZWxsIFBSIHdpdGhvdXQgcHVsbGluZyBkZW1vLWhlYXZ5IGV4ZWN1dGlvbiBsb2dpYyBiYWNrIGludG8gdGhlIFdvcmtPcmRlciBzbGljZS5cbiAgICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtMyBtZDpncmlkLWNvbHMtM1wiPlxuICAgICAgICAgICAgICAgIDxDb250cm9sTm90ZVxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJTZWN0aW9uIGJvdW5kYXJ5XCJcbiAgICAgICAgICAgICAgICAgIGJvZHk9XCJDb250cm9sIHJvdXRlcyBpbmRlcGVuZGVudGx5IGZyb20gSG9tZSwgT3BzLCBhbmQgUGxhdGZvcm0gd2hpbGUgcHJlc2VydmluZyBhbGwgZXhpc3Rpbmcgc2hlbGwgdmlld3MuXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxDb250cm9sTm90ZVxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJMaXZlIHNsaWNlXCJcbiAgICAgICAgICAgICAgICAgIGJvZHk9XCJXb3JrIE9yZGVycyBub3cgdXNlcyByZWFsIENvbnZleC1iYWNrZWQgZGF0YSBhbmQgZ292ZXJuZWQgZGlzcGF0Y2ggYmVoYXZpb3Igd2l0aGluIHRoaXMgc2VjdGlvbi5cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPENvbnRyb2xOb3RlXG4gICAgICAgICAgICAgICAgICB0aXRsZT1cIkZvbGxvdy1vbiBzcGFjZVwiXG4gICAgICAgICAgICAgICAgICBib2R5PVwiUG9ydGZvbGlvLCBGbGVldCwgYW5kIEFwcHJvdmFscyByZW1haW4gc3RhYmxlIHBsYWNlaG9sZGVycyB1bnRpbCB0aG9zZSBzbGljZXMgYXJlIGltcGxlbWVudGVkIG9uIHRoZWlyIG93biBtZXJpdHMuXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgICAgICAgPC9DYXJkPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gQ29udHJvbE5vdGUoeyB0aXRsZSwgYm9keSB9OiB7IHRpdGxlOiBzdHJpbmc7IGJvZHk6IHN0cmluZyB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLVt2YXIoLS1wYW5lbC1saW5lKV0gYmctYmFja2dyb3VuZC80MCBwLTRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy1bMC4xNmVtXSB0ZXh0LWZvcmVncm91bmQvODBcIj57dGl0bGV9PC9kaXY+XG4gICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntib2R5fTwvcD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL3NlY3Rpb25zL0NvbnRyb2xTZWN0aW9uLnRzeCJ9