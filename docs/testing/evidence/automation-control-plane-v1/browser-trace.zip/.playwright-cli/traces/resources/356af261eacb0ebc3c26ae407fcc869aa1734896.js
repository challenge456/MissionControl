import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/NotificationsModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
export function NotificationsModal({ onClose, onSelectTask }) {
  _s();
  const notifications = useQuery(api.notifications.listRecent, { limit: 50 });
  const agents = useQuery(api.agents.listAll, {});
  const agentMap = agents ? new Map(agents.map((a) => [a._id, a])) : /* @__PURE__ */ new Map();
  return /* @__PURE__ */ jsxDEV(Modal, { onClose, children: [
    /* @__PURE__ */ jsxDEV("h2", { style: { margin: "0 0 20px", fontSize: "1.25rem", fontWeight: 600 }, children: "Notifications (all agents)" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
      lineNumber: 31,
      columnNumber: 7
    }, this),
    notifications === void 0 ? /* @__PURE__ */ jsxDEV("div", { style: { padding: 24 }, children: "Loading…" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
      lineNumber: 35,
      columnNumber: 7
    }, this) : notifications.length === 0 ? /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--muted-foreground)", fontSize: "0.9rem" }, children: "No notifications." }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
      lineNumber: 37,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: 10 }, children: notifications.map(
      (n) => /* @__PURE__ */ jsxDEV(
        "div",
        {
          style: {
            padding: 12,
            background: n.readAt ? "var(--card)" : "var(--background)",
            border: "1px solid var(--border)",
            borderRadius: 8,
            opacity: n.readAt ? 0.85 : 1
          },
          children: [
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 8 }, children: [
              /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, minWidth: 0 }, children: [
                /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    style: {
                      fontSize: "0.7rem",
                      padding: "2px 6px",
                      background: "var(--border)",
                      color: "var(--muted-foreground)",
                      borderRadius: 4,
                      marginRight: 8
                    },
                    children: n.type
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
                    lineNumber: 53,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.75rem", color: "var(--muted-foreground)" }, children: [
                  "→ ",
                  agentMap.get(n.agentId)?.name ?? n.agentId
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
                  lineNumber: 65,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: 500, marginTop: 4 }, children: n.title }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
                  lineNumber: 68,
                  columnNumber: 19
                }, this),
                n.body && /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.85rem", color: "var(--muted-foreground)", marginTop: 4 }, children: [
                  n.body.slice(0, 120),
                  n.body.length > 120 ? "…" : ""
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
                  lineNumber: 70,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
                lineNumber: 52,
                columnNumber: 17
              }, this),
              n.taskId && onSelectTask && /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    onSelectTask(n.taskId);
                    onClose();
                  },
                  style: {
                    padding: "4px 10px",
                    background: "var(--border)",
                    border: "1px solid var(--border)",
                    borderRadius: 6,
                    color: "var(--foreground)",
                    fontSize: "0.75rem",
                    cursor: "pointer"
                  },
                  children: "Open task"
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
                  lineNumber: 74,
                  columnNumber: 13
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
              lineNumber: 51,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.7rem", color: "var(--muted-foreground)", marginTop: 6 }, children: [
              n.readAt ? "Read" : "Unread",
              " · ",
              new Date(n._creationTime ?? 0).toLocaleString()
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
              lineNumber: 91,
              columnNumber: 15
            }, this)
          ]
        },
        n._id,
        true,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
          lineNumber: 41,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
      lineNumber: 39,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
    lineNumber: 30,
    columnNumber: 5
  }, this);
}
_s(NotificationsModal, "ZA9QY385tT0xtqsdL49hhogtIdo=", false, function() {
  return [useQuery, useQuery];
});
_c = NotificationsModal;
function Modal({ children, onClose }) {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { style: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", zIndex: 9998 }, onClick: onClose, "aria-hidden": true }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
      lineNumber: 105,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        role: "dialog",
        "aria-modal": "true",
        style: {
          position: "fixed",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: "100%",
          maxWidth: 560,
          maxHeight: "90vh",
          overflow: "auto",
          background: "var(--card)",
          border: "1px solid var(--border)",
          borderRadius: 12,
          zIndex: 9999,
          padding: 24
        },
        children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: onClose,
              style: {
                position: "absolute",
                top: 16,
                right: 16,
                background: "none",
                border: "none",
                color: "var(--muted-foreground)",
                fontSize: "1.5rem",
                cursor: "pointer"
              },
              "aria-label": "Close",
              children: "×"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
              lineNumber: 125,
              columnNumber: 9
            },
            this
          ),
          children
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
        lineNumber: 106,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx",
    lineNumber: 104,
    columnNumber: 5
  }, this);
}
_c2 = Modal;
var _c, _c2;
$RefreshReg$(_c, "NotificationsModal");
$RefreshReg$(_c2, "Modal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/NotificationsModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV00sU0F5RUYsVUF6RUU7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBWE4sU0FBU0EsZ0JBQWdCO0FBQ3pCLFNBQVNDLFdBQVc7QUFHYixnQkFBU0MsbUJBQW1CLEVBQUVDLFNBQVNDLGFBQWdGLEdBQUc7QUFBQUMsS0FBQTtBQUMvSCxRQUFNQyxnQkFBZ0JOLFNBQVNDLElBQUlLLGNBQWNDLFlBQVksRUFBRUMsT0FBTyxHQUFHLENBQUM7QUFDMUUsUUFBTUMsU0FBU1QsU0FBU0MsSUFBSVEsT0FBT0MsU0FBUyxDQUFDLENBQUM7QUFDOUMsUUFBTUMsV0FBV0YsU0FBUyxJQUFJRyxJQUFJSCxPQUFPSSxJQUFJLENBQUNDLE1BQXFCLENBQUNBLEVBQUVDLEtBQUtELENBQUMsQ0FBQyxDQUFDLElBQUksb0JBQUlGLElBQUk7QUFFMUYsU0FDRSx1QkFBQyxTQUFNLFNBQ0w7QUFBQSwyQkFBQyxRQUFHLE9BQU8sRUFBRUksUUFBUSxZQUFZQyxVQUFVLFdBQVdDLFlBQVksSUFBSSxHQUFFLDBDQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNDWixrQkFBa0JhLFNBQ2pCLHVCQUFDLFNBQUksT0FBTyxFQUFFQyxTQUFTLEdBQUcsR0FBRyx3QkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQyxJQUNuQ2QsY0FBY2UsV0FBVyxJQUMzQix1QkFBQyxPQUFFLE9BQU8sRUFBRUMsT0FBTywyQkFBMkJMLFVBQVUsU0FBUyxHQUFHLGlDQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFGLElBRXJGLHVCQUFDLFNBQUksT0FBTyxFQUFFTSxTQUFTLFFBQVFDLGVBQWUsVUFBVUMsS0FBSyxHQUFHLEdBQzdEbkIsd0JBQWNPO0FBQUFBLE1BQUksQ0FBQ2EsTUFDbEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDLE9BQU87QUFBQSxZQUNMTixTQUFTO0FBQUEsWUFDVE8sWUFBWUQsRUFBRUUsU0FBUyxnQkFBZ0I7QUFBQSxZQUN2Q0MsUUFBUTtBQUFBLFlBQ1JDLGNBQWM7QUFBQSxZQUNkQyxTQUFTTCxFQUFFRSxTQUFTLE9BQU87QUFBQSxVQUM3QjtBQUFBLFVBRUE7QUFBQSxtQ0FBQyxTQUFJLE9BQU8sRUFBRUwsU0FBUyxRQUFRUyxnQkFBZ0IsaUJBQWlCQyxZQUFZLGNBQWNSLEtBQUssRUFBRSxHQUMvRjtBQUFBLHFDQUFDLFNBQUksT0FBTyxFQUFFUyxNQUFNLEdBQUdDLFVBQVUsRUFBRSxHQUNqQztBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU87QUFBQSxzQkFDTGxCLFVBQVU7QUFBQSxzQkFDVkcsU0FBUztBQUFBLHNCQUNUTyxZQUFZO0FBQUEsc0JBQ1pMLE9BQU87QUFBQSxzQkFDUFEsY0FBYztBQUFBLHNCQUNkTSxhQUFhO0FBQUEsb0JBQ2Y7QUFBQSxvQkFFQ1YsWUFBRVc7QUFBQUE7QUFBQUEsa0JBVkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVdBO0FBQUEsZ0JBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVwQixVQUFVLFdBQVdLLE9BQU8sMEJBQTBCLEdBQUU7QUFBQTtBQUFBLGtCQUNsRVgsU0FBUzJCLElBQUlaLEVBQUVhLE9BQU8sR0FBR0MsUUFBUWQsRUFBRWE7QUFBQUEscUJBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXJCLFlBQVksS0FBS3VCLFdBQVcsRUFBRSxHQUFJZixZQUFFZ0IsU0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0Q7QUFBQSxnQkFDdkRoQixFQUFFaUIsUUFDRCx1QkFBQyxTQUFJLE9BQU8sRUFBRTFCLFVBQVUsV0FBV0ssT0FBTywyQkFBMkJtQixXQUFXLEVBQUUsR0FBSWY7QUFBQUEsb0JBQUVpQixLQUFLQyxNQUFNLEdBQUcsR0FBRztBQUFBLGtCQUFHbEIsRUFBRWlCLEtBQUt0QixTQUFTLE1BQU0sTUFBTTtBQUFBLHFCQUF4STtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEySTtBQUFBLG1CQWxCL0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFvQkE7QUFBQSxjQUNDSyxFQUFFbUIsVUFBVXpDLGdCQUNYO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTLE1BQU07QUFBRUEsaUNBQWFzQixFQUFFbUIsTUFBTztBQUFHMUMsNEJBQVE7QUFBQSxrQkFBRztBQUFBLGtCQUNyRCxPQUFPO0FBQUEsb0JBQ0xpQixTQUFTO0FBQUEsb0JBQ1RPLFlBQVk7QUFBQSxvQkFDWkUsUUFBUTtBQUFBLG9CQUNSQyxjQUFjO0FBQUEsb0JBQ2RSLE9BQU87QUFBQSxvQkFDUEwsVUFBVTtBQUFBLG9CQUNWNkIsUUFBUTtBQUFBLGtCQUNWO0FBQUEsa0JBQUU7QUFBQTtBQUFBLGdCQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWNBO0FBQUEsaUJBckNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdUNBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRTdCLFVBQVUsVUFBVUssT0FBTywyQkFBMkJtQixXQUFXLEVBQUUsR0FDOUVmO0FBQUFBLGdCQUFFRSxTQUFTLFNBQVM7QUFBQSxjQUFTO0FBQUEsY0FBSSxJQUFJbUIsS0FBTXJCLEVBQWlDc0IsaUJBQWlCLENBQUMsRUFBRUMsZUFBZTtBQUFBLGlCQURsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUE7QUFBQTtBQUFBLFFBbkRLdkIsRUFBRVg7QUFBQUEsUUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BcURBO0FBQUEsSUFDRCxLQXhESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeURBO0FBQUEsT0FsRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9FQTtBQUVKO0FBQUNWLEdBNUVlSCxvQkFBa0I7QUFBQSxVQUNWRixVQUNQQSxRQUFRO0FBQUE7QUFBQSxLQUZURTtBQThFaEIsU0FBU2dELE1BQU0sRUFBRUMsVUFBVWhELFFBQTRELEdBQUc7QUFDeEYsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFNBQUksT0FBTyxFQUFFaUQsVUFBVSxTQUFTQyxPQUFPLEdBQUcxQixZQUFZLG1CQUFtQjJCLFFBQVEsS0FBSyxHQUFHLFNBQVNuRCxTQUFTLGVBQVcsUUFBdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1SDtBQUFBLElBQ3ZIO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxjQUFXO0FBQUEsUUFDWCxPQUFPO0FBQUEsVUFDTGlELFVBQVU7QUFBQSxVQUNWRyxLQUFLO0FBQUEsVUFDTEMsTUFBTTtBQUFBLFVBQ05DLFdBQVc7QUFBQSxVQUNYQyxPQUFPO0FBQUEsVUFDUEMsVUFBVTtBQUFBLFVBQ1ZDLFdBQVc7QUFBQSxVQUNYQyxVQUFVO0FBQUEsVUFDVmxDLFlBQVk7QUFBQSxVQUNaRSxRQUFRO0FBQUEsVUFDUkMsY0FBYztBQUFBLFVBQ2R3QixRQUFRO0FBQUEsVUFDUmxDLFNBQVM7QUFBQSxRQUNYO0FBQUEsUUFFQTtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTakI7QUFBQUEsY0FDVCxPQUFPO0FBQUEsZ0JBQ0xpRCxVQUFVO0FBQUEsZ0JBQ1ZHLEtBQUs7QUFBQSxnQkFDTE8sT0FBTztBQUFBLGdCQUNQbkMsWUFBWTtBQUFBLGdCQUNaRSxRQUFRO0FBQUEsZ0JBQ1JQLE9BQU87QUFBQSxnQkFDUEwsVUFBVTtBQUFBLGdCQUNWNkIsUUFBUTtBQUFBLGNBQ1Y7QUFBQSxjQUNBLGNBQVc7QUFBQSxjQUFPO0FBQUE7QUFBQSxZQWJwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFnQkE7QUFBQSxVQUNDSztBQUFBQTtBQUFBQTtBQUFBQSxNQXBDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFxQ0E7QUFBQSxPQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0NBO0FBRUo7QUFBQ1ksTUE1Q1FiO0FBQUssSUFBQWMsSUFBQUQ7QUFBQSxhQUFBQyxJQUFBO0FBQUEsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInVzZVF1ZXJ5IiwiYXBpIiwiTm90aWZpY2F0aW9uc01vZGFsIiwib25DbG9zZSIsIm9uU2VsZWN0VGFzayIsIl9zIiwibm90aWZpY2F0aW9ucyIsImxpc3RSZWNlbnQiLCJsaW1pdCIsImFnZW50cyIsImxpc3RBbGwiLCJhZ2VudE1hcCIsIk1hcCIsIm1hcCIsImEiLCJfaWQiLCJtYXJnaW4iLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJ1bmRlZmluZWQiLCJwYWRkaW5nIiwibGVuZ3RoIiwiY29sb3IiLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImdhcCIsIm4iLCJiYWNrZ3JvdW5kIiwicmVhZEF0IiwiYm9yZGVyIiwiYm9yZGVyUmFkaXVzIiwib3BhY2l0eSIsImp1c3RpZnlDb250ZW50IiwiYWxpZ25JdGVtcyIsImZsZXgiLCJtaW5XaWR0aCIsIm1hcmdpblJpZ2h0IiwidHlwZSIsImdldCIsImFnZW50SWQiLCJuYW1lIiwibWFyZ2luVG9wIiwidGl0bGUiLCJib2R5Iiwic2xpY2UiLCJ0YXNrSWQiLCJjdXJzb3IiLCJEYXRlIiwiX2NyZWF0aW9uVGltZSIsInRvTG9jYWxlU3RyaW5nIiwiTW9kYWwiLCJjaGlsZHJlbiIsInBvc2l0aW9uIiwiaW5zZXQiLCJ6SW5kZXgiLCJ0b3AiLCJsZWZ0IiwidHJhbnNmb3JtIiwid2lkdGgiLCJtYXhXaWR0aCIsIm1heEhlaWdodCIsIm92ZXJmbG93IiwicmlnaHQiLCJfYzIiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJOb3RpZmljYXRpb25zTW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVF1ZXJ5IH0gZnJvbSBcImNvbnZleC9yZWFjdFwiO1xuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2FwaVwiO1xuaW1wb3J0IHR5cGUgeyBEb2MsIElkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuXG5leHBvcnQgZnVuY3Rpb24gTm90aWZpY2F0aW9uc01vZGFsKHsgb25DbG9zZSwgb25TZWxlY3RUYXNrIH06IHsgb25DbG9zZTogKCkgPT4gdm9pZDsgb25TZWxlY3RUYXNrPzogKGlkOiBJZDxcInRhc2tzXCI+KSA9PiB2b2lkIH0pIHtcbiAgY29uc3Qgbm90aWZpY2F0aW9ucyA9IHVzZVF1ZXJ5KGFwaS5ub3RpZmljYXRpb25zLmxpc3RSZWNlbnQsIHsgbGltaXQ6IDUwIH0pO1xuICBjb25zdCBhZ2VudHMgPSB1c2VRdWVyeShhcGkuYWdlbnRzLmxpc3RBbGwsIHt9KTtcbiAgY29uc3QgYWdlbnRNYXAgPSBhZ2VudHMgPyBuZXcgTWFwKGFnZW50cy5tYXAoKGE6IERvYzxcImFnZW50c1wiPikgPT4gW2EuX2lkLCBhXSkpIDogbmV3IE1hcCgpO1xuXG4gIHJldHVybiAoXG4gICAgPE1vZGFsIG9uQ2xvc2U9e29uQ2xvc2V9PlxuICAgICAgPGgyIHN0eWxlPXt7IG1hcmdpbjogXCIwIDAgMjBweFwiLCBmb250U2l6ZTogXCIxLjI1cmVtXCIsIGZvbnRXZWlnaHQ6IDYwMCB9fT5cbiAgICAgICAgTm90aWZpY2F0aW9ucyAoYWxsIGFnZW50cylcbiAgICAgIDwvaDI+XG4gICAgICB7bm90aWZpY2F0aW9ucyA9PT0gdW5kZWZpbmVkID8gKFxuICAgICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmc6IDI0IH19PkxvYWRpbmfigKY8L2Rpdj5cbiAgICAgICkgOiBub3RpZmljYXRpb25zLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgPHAgc3R5bGU9e3sgY29sb3I6IFwidmFyKC0tbXV0ZWQtZm9yZWdyb3VuZClcIiwgZm9udFNpemU6IFwiMC45cmVtXCIgfX0+Tm8gbm90aWZpY2F0aW9ucy48L3A+XG4gICAgICApIDogKFxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLCBnYXA6IDEwIH19PlxuICAgICAgICAgIHtub3RpZmljYXRpb25zLm1hcCgobjogRG9jPFwibm90aWZpY2F0aW9uc1wiPikgPT4gKFxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBrZXk9e24uX2lkfVxuICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDEyLFxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IG4ucmVhZEF0ID8gXCJ2YXIoLS1jYXJkKVwiIDogXCJ2YXIoLS1iYWNrZ3JvdW5kKVwiLFxuICAgICAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWQgdmFyKC0tYm9yZGVyKVwiLFxuICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogOCxcbiAgICAgICAgICAgICAgICBvcGFjaXR5OiBuLnJlYWRBdCA/IDAuODUgOiAxLFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIsIGFsaWduSXRlbXM6IFwiZmxleC1zdGFydFwiLCBnYXA6IDggfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxLCBtaW5XaWR0aDogMCB9fT5cbiAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMC43cmVtXCIsXG4gICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCIycHggNnB4XCIsXG4gICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCJ2YXIoLS1ib3JkZXIpXCIsXG4gICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwidmFyKC0tbXV0ZWQtZm9yZWdyb3VuZClcIixcbiAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDQsXG4gICAgICAgICAgICAgICAgICAgICAgbWFyZ2luUmlnaHQ6IDgsXG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtuLnR5cGV9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogXCIwLjc1cmVtXCIsIGNvbG9yOiBcInZhcigtLW11dGVkLWZvcmVncm91bmQpXCIgfX0+XG4gICAgICAgICAgICAgICAgICAgIOKGkiB7YWdlbnRNYXAuZ2V0KG4uYWdlbnRJZCk/Lm5hbWUgPz8gbi5hZ2VudElkfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250V2VpZ2h0OiA1MDAsIG1hcmdpblRvcDogNCB9fT57bi50aXRsZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgIHtuLmJvZHkgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiBcIjAuODVyZW1cIiwgY29sb3I6IFwidmFyKC0tbXV0ZWQtZm9yZWdyb3VuZClcIiwgbWFyZ2luVG9wOiA0IH19PntuLmJvZHkuc2xpY2UoMCwgMTIwKX17bi5ib2R5Lmxlbmd0aCA+IDEyMCA/IFwi4oCmXCIgOiBcIlwifTwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB7bi50YXNrSWQgJiYgb25TZWxlY3RUYXNrICYmIChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgb25TZWxlY3RUYXNrKG4udGFza0lkISk7IG9uQ2xvc2UoKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjRweCAxMHB4XCIsXG4gICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCJ2YXIoLS1ib3JkZXIpXCIsXG4gICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCB2YXIoLS1ib3JkZXIpXCIsXG4gICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiA2LFxuICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcInZhcigtLWZvcmVncm91bmQpXCIsXG4gICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMC43NXJlbVwiLFxuICAgICAgICAgICAgICAgICAgICAgIGN1cnNvcjogXCJwb2ludGVyXCIsXG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIE9wZW4gdGFza1xuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6IFwiMC43cmVtXCIsIGNvbG9yOiBcInZhcigtLW11dGVkLWZvcmVncm91bmQpXCIsIG1hcmdpblRvcDogNiB9fT5cbiAgICAgICAgICAgICAgICB7bi5yZWFkQXQgPyBcIlJlYWRcIiA6IFwiVW5yZWFkXCJ9IMK3IHtuZXcgRGF0ZSgobiBhcyB7IF9jcmVhdGlvblRpbWU/OiBudW1iZXIgfSkuX2NyZWF0aW9uVGltZSA/PyAwKS50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9Nb2RhbD5cbiAgKTtcbn1cblxuZnVuY3Rpb24gTW9kYWwoeyBjaGlsZHJlbiwgb25DbG9zZSB9OiB7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7IG9uQ2xvc2U6ICgpID0+IHZvaWQgfSkge1xuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8ZGl2IHN0eWxlPXt7IHBvc2l0aW9uOiBcImZpeGVkXCIsIGluc2V0OiAwLCBiYWNrZ3JvdW5kOiBcInJnYmEoMCwwLDAsMC41KVwiLCB6SW5kZXg6IDk5OTggfX0gb25DbGljaz17b25DbG9zZX0gYXJpYS1oaWRkZW4gLz5cbiAgICAgIDxkaXZcbiAgICAgICAgcm9sZT1cImRpYWxvZ1wiXG4gICAgICAgIGFyaWEtbW9kYWw9XCJ0cnVlXCJcbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICBwb3NpdGlvbjogXCJmaXhlZFwiLFxuICAgICAgICAgIHRvcDogXCI1MCVcIixcbiAgICAgICAgICBsZWZ0OiBcIjUwJVwiLFxuICAgICAgICAgIHRyYW5zZm9ybTogXCJ0cmFuc2xhdGUoLTUwJSwgLTUwJSlcIixcbiAgICAgICAgICB3aWR0aDogXCIxMDAlXCIsXG4gICAgICAgICAgbWF4V2lkdGg6IDU2MCxcbiAgICAgICAgICBtYXhIZWlnaHQ6IFwiOTB2aFwiLFxuICAgICAgICAgIG92ZXJmbG93OiBcImF1dG9cIixcbiAgICAgICAgICBiYWNrZ3JvdW5kOiBcInZhcigtLWNhcmQpXCIsXG4gICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCB2YXIoLS1ib3JkZXIpXCIsXG4gICAgICAgICAgYm9yZGVyUmFkaXVzOiAxMixcbiAgICAgICAgICB6SW5kZXg6IDk5OTksXG4gICAgICAgICAgcGFkZGluZzogMjQsXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuICAgICAgICAgICAgdG9wOiAxNixcbiAgICAgICAgICAgIHJpZ2h0OiAxNixcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IFwibm9uZVwiLFxuICAgICAgICAgICAgYm9yZGVyOiBcIm5vbmVcIixcbiAgICAgICAgICAgIGNvbG9yOiBcInZhcigtLW11dGVkLWZvcmVncm91bmQpXCIsXG4gICAgICAgICAgICBmb250U2l6ZTogXCIxLjVyZW1cIixcbiAgICAgICAgICAgIGN1cnNvcjogXCJwb2ludGVyXCIsXG4gICAgICAgICAgfX1cbiAgICAgICAgICBhcmlhLWxhYmVsPVwiQ2xvc2VcIlxuICAgICAgICA+XG4gICAgICAgICAgw5dcbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIHtjaGlsZHJlbn1cbiAgICAgIDwvZGl2PlxuICAgIDwvPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvTm90aWZpY2F0aW9uc01vZGFsLnRzeCJ9