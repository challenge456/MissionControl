import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/factory/DetailLayout.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Breadcrumbs } from "/src/components/factory/Breadcrumbs.tsx";
import { cn } from "/src/lib/utils.ts";
export function MetadataPanel({
  entries,
  children,
  className
}) {
  return /* @__PURE__ */ jsxDEV("aside", { className: cn("flex w-[280px] shrink-0 flex-col gap-4", className), children: [
    /* @__PURE__ */ jsxDEV("dl", { className: "flex flex-col divide-y divide-line", children: entries.map(
      (entry) => /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-1 py-3 first:pt-0", children: [
        /* @__PURE__ */ jsxDEV("dt", { className: "text-[11.5px] font-medium uppercase tracking-[0.06em] text-ink-muted", children: entry.label }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
          lineNumber: 44,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "text-[13px] text-ink", children: entry.value }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
          lineNumber: 47,
          columnNumber: 13
        }, this)
      ] }, entry.label, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
        lineNumber: 43,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
      lineNumber: 41,
      columnNumber: 7
    }, this),
    children
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
    lineNumber: 40,
    columnNumber: 5
  }, this);
}
_c = MetadataPanel;
export function DetailTabs({
  tabs,
  activeId,
  onChange
}) {
  return /* @__PURE__ */ jsxDEV("div", { role: "tablist", className: "flex items-center gap-1 border-b border-line", children: tabs.map((tab) => {
    const active = tab.id === activeId;
    return /* @__PURE__ */ jsxDEV(
      "button",
      {
        role: "tab",
        type: "button",
        "aria-selected": active,
        onClick: () => onChange(tab.id),
        className: cn(
          "-mb-px flex items-center gap-1.5 border-b-2 px-3 py-2.5 text-[13px] transition-colors duration-150",
          active ? "border-registry-accent text-ink font-medium" : "border-transparent text-ink-muted hover:text-ink-secondary"
        ),
        children: [
          tab.icon,
          tab.label
        ]
      },
      tab.id,
      true,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
        lineNumber: 76,
        columnNumber: 11
      },
      this
    );
  }) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
    lineNumber: 72,
    columnNumber: 5
  }, this);
}
_c2 = DetailTabs;
export function DetailLayout({
  breadcrumbs,
  title,
  description,
  actions,
  metrics,
  tabs,
  activeTabId,
  onTabChange,
  aside,
  children
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "mx-auto flex max-w-[1200px] flex-col gap-5 px-6 py-5", children: [
    breadcrumbs && breadcrumbs.length > 0 && /* @__PURE__ */ jsxDEV(Breadcrumbs, { items: breadcrumbs }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
      lineNumber: 132,
      columnNumber: 49
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-[26px] font-semibold leading-tight tracking-tight text-ink", children: title }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
          lineNumber: 135,
          columnNumber: 11
        }, this),
        description && /* @__PURE__ */ jsxDEV("p", { className: "mt-1.5 max-w-[70ch] text-[14px] leading-relaxed text-ink-secondary", children: description }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
          lineNumber: 139,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
        lineNumber: 134,
        columnNumber: 9
      }, this),
      actions && /* @__PURE__ */ jsxDEV("div", { className: "shrink-0", children: actions }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
        lineNumber: 144,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
      lineNumber: 133,
      columnNumber: 7
    }, this),
    metrics,
    tabs && activeTabId && onTabChange && /* @__PURE__ */ jsxDEV(DetailTabs, { tabs, activeId: activeTabId, onChange: onTabChange }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
      lineNumber: 148,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
        lineNumber: 151,
        columnNumber: 9
      }, this),
      aside
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
      lineNumber: 150,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
    lineNumber: 131,
    columnNumber: 5
  }, this);
}
_c3 = DetailLayout;
export function PageHeader({
  title,
  description,
  actions,
  eyebrow
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-6 px-6 pb-4 pt-5", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
      eyebrow ? /* @__PURE__ */ jsxDEV("div", { className: "registry-kicker", children: eyebrow }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
        lineNumber: 172,
        columnNumber: 20
      }, this) : null,
      /* @__PURE__ */ jsxDEV("h1", { className: "text-[26px] font-semibold leading-tight tracking-tight text-ink", children: title }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
        lineNumber: 173,
        columnNumber: 9
      }, this),
      description ? /* @__PURE__ */ jsxDEV("p", { className: "mt-1.5 text-[14px] leading-relaxed text-ink-secondary", children: description }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
        lineNumber: 177,
        columnNumber: 9
      }, this) : null
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
      lineNumber: 171,
      columnNumber: 7
    }, this),
    actions ? /* @__PURE__ */ jsxDEV("div", { className: "shrink-0", children: actions }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
      lineNumber: 180,
      columnNumber: 18
    }, this) : null
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx",
    lineNumber: 170,
    columnNumber: 5
  }, this);
}
_c4 = PageHeader;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "MetadataPanel");
$RefreshReg$(_c2, "DetailTabs");
$RefreshReg$(_c3, "DetailLayout");
$RefreshReg$(_c4, "PageHeader");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/factory/DetailLayout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JZOzs7Ozs7Ozs7Ozs7Ozs7O0FBdkJaLFNBQVNBLG1CQUErQjtBQUN4QyxTQUFTQyxVQUFVO0FBUVosZ0JBQVNDLGNBQWM7QUFBQSxFQUM1QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFLRixHQUFnQjtBQUNkLFNBQ0UsdUJBQUMsV0FBTSxXQUFXSixHQUFHLDBDQUEwQ0ksU0FBUyxHQUN0RTtBQUFBLDJCQUFDLFFBQUcsV0FBVSxzQ0FDWEYsa0JBQVFHO0FBQUFBLE1BQUksQ0FBQ0MsVUFDWix1QkFBQyxTQUFzQixXQUFVLHVDQUMvQjtBQUFBLCtCQUFDLFFBQUcsV0FBVSx3RUFDWEEsZ0JBQU1DLFNBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxRQUFHLFdBQVUsd0JBQXdCRCxnQkFBTUUsU0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRDtBQUFBLFdBSjFDRixNQUFNQyxPQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxJQUNELEtBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFDQ0o7QUFBQUEsT0FYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBWUE7QUFFSjtBQUFDTSxLQXhCZVI7QUFnQ1QsZ0JBQVNTLFdBQVc7QUFBQSxFQUN6QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFLRixHQUFnQjtBQUNkLFNBQ0UsdUJBQUMsU0FBSSxNQUFLLFdBQVUsV0FBVSxnREFDM0JGLGVBQUtOLElBQUksQ0FBQ1MsUUFBUTtBQUNqQixVQUFNQyxTQUFTRCxJQUFJRSxPQUFPSjtBQUMxQixXQUNFO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFFQyxNQUFLO0FBQUEsUUFDTCxNQUFLO0FBQUEsUUFDTCxpQkFBZUc7QUFBQUEsUUFDZixTQUFTLE1BQU1GLFNBQVNDLElBQUlFLEVBQUU7QUFBQSxRQUM5QixXQUFXaEI7QUFBQUEsVUFDVDtBQUFBLFVBQ0FlLFNBQ0ksZ0RBQ0E7QUFBQSxRQUNOO0FBQUEsUUFFQ0Q7QUFBQUEsY0FBSUc7QUFBQUEsVUFDSkgsSUFBSVA7QUFBQUE7QUFBQUE7QUFBQUEsTUFiQU8sSUFBSUU7QUFBQUEsTUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZUE7QUFBQSxFQUVKLENBQUMsS0FyQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNCQTtBQUVKO0FBQUNFLE1BbENlUjtBQXdEVCxnQkFBU1MsYUFBYTtBQUFBLEVBQzNCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBYjtBQUFBQSxFQUNBYztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBeEI7QUFDaUIsR0FBZ0I7QUFDakMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsd0RBQ1ppQjtBQUFBQSxtQkFBZUEsWUFBWVEsU0FBUyxLQUFLLHVCQUFDLGVBQVksT0FBT1IsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQztBQUFBLElBQzFFLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLG1FQUNYQyxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNDQyxlQUNDLHVCQUFDLE9BQUUsV0FBVSxzRUFDVkEseUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUNDQyxXQUFXLHVCQUFDLFNBQUksV0FBVSxZQUFZQSxxQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQztBQUFBLFNBWGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBQ0NDO0FBQUFBLElBQ0FiLFFBQVFjLGVBQWVDLGVBQ3RCLHVCQUFDLGNBQVcsTUFBWSxVQUFVRCxhQUFhLFVBQVVDLGVBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUU7QUFBQSxJQUV2RSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxrQkFBa0J2QixZQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBDO0FBQUEsTUFDekN3QjtBQUFBQSxTQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLE9BdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1QkE7QUFFSjtBQUFDRSxNQXRDZVY7QUF3Q1QsZ0JBQVNXLFdBQVc7QUFBQSxFQUN6QlQ7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQVE7QUFNRixHQUFnQjtBQUNkLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHlEQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLFdBQ1pBO0FBQUFBLGdCQUFVLHVCQUFDLFNBQUksV0FBVSxtQkFBbUJBLHFCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBDLElBQVM7QUFBQSxNQUM5RCx1QkFBQyxRQUFHLFdBQVUsbUVBQ1hWLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0NDLGNBQ0MsdUJBQUMsT0FBRSxXQUFVLHlEQUF5REEseUJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0YsSUFDaEY7QUFBQSxTQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBQ0NDLFVBQVUsdUJBQUMsU0FBSSxXQUFVLFlBQVlBLHFCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1DLElBQVM7QUFBQSxPQVZ6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBV0E7QUFFSjtBQUFDUyxNQXpCZUY7QUFBVSxJQUFBckIsSUFBQVMsS0FBQVcsS0FBQUc7QUFBQSxhQUFBdkIsSUFBQTtBQUFBLGFBQUFTLEtBQUE7QUFBQSxhQUFBVyxLQUFBO0FBQUEsYUFBQUcsS0FBQSIsIm5hbWVzIjpbIkJyZWFkY3J1bWJzIiwiY24iLCJNZXRhZGF0YVBhbmVsIiwiZW50cmllcyIsImNoaWxkcmVuIiwiY2xhc3NOYW1lIiwibWFwIiwiZW50cnkiLCJsYWJlbCIsInZhbHVlIiwiX2MiLCJEZXRhaWxUYWJzIiwidGFicyIsImFjdGl2ZUlkIiwib25DaGFuZ2UiLCJ0YWIiLCJhY3RpdmUiLCJpZCIsImljb24iLCJfYzIiLCJEZXRhaWxMYXlvdXQiLCJicmVhZGNydW1icyIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJhY3Rpb25zIiwibWV0cmljcyIsImFjdGl2ZVRhYklkIiwib25UYWJDaGFuZ2UiLCJhc2lkZSIsImxlbmd0aCIsIl9jMyIsIlBhZ2VIZWFkZXIiLCJleWVicm93IiwiX2M0Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkRldGFpbExheW91dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEJyZWFkY3J1bWJzLCB0eXBlIENydW1iIH0gZnJvbSBcIi4vQnJlYWRjcnVtYnNcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIi4uLy4uL2xpYi91dGlsc1wiO1xuXG5leHBvcnQgaW50ZXJmYWNlIE1ldGFkYXRhRW50cnkge1xuICBsYWJlbDogc3RyaW5nO1xuICB2YWx1ZTogUmVhY3ROb2RlO1xufVxuXG4vKiogUmlnaHQtaGFuZCBtZXRhZGF0YSByYWlsOiBzdGFja2VkIGxhYmVsL3ZhbHVlIGVudHJpZXMgd2l0aCBzZXBhcmF0b3JzLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIE1ldGFkYXRhUGFuZWwoe1xuICBlbnRyaWVzLFxuICBjaGlsZHJlbixcbiAgY2xhc3NOYW1lLFxufToge1xuICBlbnRyaWVzOiBNZXRhZGF0YUVudHJ5W107XG4gIGNoaWxkcmVuPzogUmVhY3ROb2RlO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59KTogSlNYLkVsZW1lbnQge1xuICByZXR1cm4gKFxuICAgIDxhc2lkZSBjbGFzc05hbWU9e2NuKFwiZmxleCB3LVsyODBweF0gc2hyaW5rLTAgZmxleC1jb2wgZ2FwLTRcIiwgY2xhc3NOYW1lKX0+XG4gICAgICA8ZGwgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBkaXZpZGUteSBkaXZpZGUtbGluZVwiPlxuICAgICAgICB7ZW50cmllcy5tYXAoKGVudHJ5KSA9PiAoXG4gICAgICAgICAgPGRpdiBrZXk9e2VudHJ5LmxhYmVsfSBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xIHB5LTMgZmlyc3Q6cHQtMFwiPlxuICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtWzExLjVweF0gZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjA2ZW1dIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAgICAgIHtlbnRyeS5sYWJlbH1cbiAgICAgICAgICAgIDwvZHQ+XG4gICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1pbmtcIj57ZW50cnkudmFsdWV9PC9kZD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSl9XG4gICAgICA8L2RsPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvYXNpZGU+XG4gICk7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRGV0YWlsVGFiIHtcbiAgaWQ6IHN0cmluZztcbiAgbGFiZWw6IHN0cmluZztcbiAgaWNvbj86IFJlYWN0Tm9kZTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIERldGFpbFRhYnMoe1xuICB0YWJzLFxuICBhY3RpdmVJZCxcbiAgb25DaGFuZ2UsXG59OiB7XG4gIHRhYnM6IERldGFpbFRhYltdO1xuICBhY3RpdmVJZDogc3RyaW5nO1xuICBvbkNoYW5nZTogKGlkOiBzdHJpbmcpID0+IHZvaWQ7XG59KTogSlNYLkVsZW1lbnQge1xuICByZXR1cm4gKFxuICAgIDxkaXYgcm9sZT1cInRhYmxpc3RcIiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBib3JkZXItYiBib3JkZXItbGluZVwiPlxuICAgICAge3RhYnMubWFwKCh0YWIpID0+IHtcbiAgICAgICAgY29uc3QgYWN0aXZlID0gdGFiLmlkID09PSBhY3RpdmVJZDtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBrZXk9e3RhYi5pZH1cbiAgICAgICAgICAgIHJvbGU9XCJ0YWJcIlxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBhcmlhLXNlbGVjdGVkPXthY3RpdmV9XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkNoYW5nZSh0YWIuaWQpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgXCItbWItcHggZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBib3JkZXItYi0yIHB4LTMgcHktMi41IHRleHQtWzEzcHhdIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiLFxuICAgICAgICAgICAgICBhY3RpdmVcbiAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLXJlZ2lzdHJ5LWFjY2VudCB0ZXh0LWluayBmb250LW1lZGl1bVwiXG4gICAgICAgICAgICAgICAgOiBcImJvcmRlci10cmFuc3BhcmVudCB0ZXh0LWluay1tdXRlZCBob3Zlcjp0ZXh0LWluay1zZWNvbmRhcnlcIlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7dGFiLmljb259XG4gICAgICAgICAgICB7dGFiLmxhYmVsfVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApO1xuICAgICAgfSl9XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRGV0YWlsTGF5b3V0UHJvcHMge1xuICBicmVhZGNydW1icz86IENydW1iW107XG4gIHRpdGxlOiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuICAvKiogVG9wLXJpZ2h0IGFjdGlvbiBhcmVhIChpbnN0YWxsIGJ1dHRvbiwgY29tbWFuZCBzbmlwcGV0LCDigKYpICovXG4gIGFjdGlvbnM/OiBSZWFjdE5vZGU7XG4gIC8qKiBNZXRyaWMgcm93IHVuZGVyIHRoZSBoZWFkZXIgKHVzZSBNZXRyaWNSb3cgKyBNZXRyaWNCbG9jaykgKi9cbiAgbWV0cmljcz86IFJlYWN0Tm9kZTtcbiAgdGFicz86IERldGFpbFRhYltdO1xuICBhY3RpdmVUYWJJZD86IHN0cmluZztcbiAgb25UYWJDaGFuZ2U/OiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcbiAgLyoqIFJpZ2h0LWhhbmQgcmFpbCAodXNlIE1ldGFkYXRhUGFuZWwpICovXG4gIGFzaWRlPzogUmVhY3ROb2RlO1xuICBjaGlsZHJlbjogUmVhY3ROb2RlO1xufVxuXG4vKipcbiAqIENhbm9uaWNhbCBkZXRhaWwtcGFnZSBza2VsZXRvbjogYnJlYWRjcnVtYnMg4oaSIGhlYWRlciDihpIgbWV0cmljIHJvdyDihpJcbiAqIHRhYnMg4oaSIG1haW4gY29udGVudCArIHJpZ2h0IG1ldGFkYXRhIHJhaWwuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBEZXRhaWxMYXlvdXQoe1xuICBicmVhZGNydW1icyxcbiAgdGl0bGUsXG4gIGRlc2NyaXB0aW9uLFxuICBhY3Rpb25zLFxuICBtZXRyaWNzLFxuICB0YWJzLFxuICBhY3RpdmVUYWJJZCxcbiAgb25UYWJDaGFuZ2UsXG4gIGFzaWRlLFxuICBjaGlsZHJlbixcbn06IERldGFpbExheW91dFByb3BzKTogSlNYLkVsZW1lbnQge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibXgtYXV0byBmbGV4IG1heC13LVsxMjAwcHhdIGZsZXgtY29sIGdhcC01IHB4LTYgcHktNVwiPlxuICAgICAge2JyZWFkY3J1bWJzICYmIGJyZWFkY3J1bWJzLmxlbmd0aCA+IDAgJiYgPEJyZWFkY3J1bWJzIGl0ZW1zPXticmVhZGNydW1ic30gLz59XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC02XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LVsyNnB4XSBmb250LXNlbWlib2xkIGxlYWRpbmctdGlnaHQgdHJhY2tpbmctdGlnaHQgdGV4dC1pbmtcIj5cbiAgICAgICAgICAgIHt0aXRsZX1cbiAgICAgICAgICA8L2gxPlxuICAgICAgICAgIHtkZXNjcmlwdGlvbiAmJiAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xLjUgbWF4LXctWzcwY2hdIHRleHQtWzE0cHhdIGxlYWRpbmctcmVsYXhlZCB0ZXh0LWluay1zZWNvbmRhcnlcIj5cbiAgICAgICAgICAgICAge2Rlc2NyaXB0aW9ufVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICB7YWN0aW9ucyAmJiA8ZGl2IGNsYXNzTmFtZT1cInNocmluay0wXCI+e2FjdGlvbnN9PC9kaXY+fVxuICAgICAgPC9kaXY+XG4gICAgICB7bWV0cmljc31cbiAgICAgIHt0YWJzICYmIGFjdGl2ZVRhYklkICYmIG9uVGFiQ2hhbmdlICYmIChcbiAgICAgICAgPERldGFpbFRhYnMgdGFicz17dGFic30gYWN0aXZlSWQ9e2FjdGl2ZVRhYklkfSBvbkNoYW5nZT17b25UYWJDaGFuZ2V9IC8+XG4gICAgICApfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC04XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj57Y2hpbGRyZW59PC9kaXY+XG4gICAgICAgIHthc2lkZX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gUGFnZUhlYWRlcih7XG4gIHRpdGxlLFxuICBkZXNjcmlwdGlvbixcbiAgYWN0aW9ucyxcbiAgZXllYnJvdyxcbn06IHtcbiAgdGl0bGU6IHN0cmluZztcbiAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gIGFjdGlvbnM/OiBSZWFjdE5vZGU7XG4gIGV5ZWJyb3c/OiBzdHJpbmc7XG59KTogSlNYLkVsZW1lbnQge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTYgcHgtNiBwYi00IHB0LTVcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxuICAgICAgICB7ZXllYnJvdyA/IDxkaXYgY2xhc3NOYW1lPVwicmVnaXN0cnkta2lja2VyXCI+e2V5ZWJyb3d9PC9kaXY+IDogbnVsbH1cbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtWzI2cHhdIGZvbnQtc2VtaWJvbGQgbGVhZGluZy10aWdodCB0cmFja2luZy10aWdodCB0ZXh0LWlua1wiPlxuICAgICAgICAgIHt0aXRsZX1cbiAgICAgICAgPC9oMT5cbiAgICAgICAge2Rlc2NyaXB0aW9uID8gKFxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEuNSB0ZXh0LVsxNHB4XSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1pbmstc2Vjb25kYXJ5XCI+e2Rlc2NyaXB0aW9ufTwvcD5cbiAgICAgICAgKSA6IG51bGx9XG4gICAgICA8L2Rpdj5cbiAgICAgIHthY3Rpb25zID8gPGRpdiBjbGFzc05hbWU9XCJzaHJpbmstMFwiPnthY3Rpb25zfTwvZGl2PiA6IG51bGx9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9jb21wb25lbnRzL2ZhY3RvcnkvRGV0YWlsTGF5b3V0LnRzeCJ9