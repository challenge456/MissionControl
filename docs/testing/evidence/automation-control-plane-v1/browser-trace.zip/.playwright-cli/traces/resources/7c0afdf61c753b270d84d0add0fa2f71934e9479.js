import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/TaskEditMode.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { formatDateInputValue, parseDateInputValue } from "/src/lib/dateInput.ts";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Textarea } from "/src/components/ui/textarea.tsx";
import { Label } from "/src/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
import { Card } from "/src/components/ui/card.tsx";
import { cn } from "/src/lib/utils.ts";
import { Pencil, Save, Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
const DEFAULT_REVIEW_ITEMS = [
  "Acceptance criteria verified",
  "Tests or manual checks passed",
  "Evidence, risks, and limitations recorded"
];
function getRequiredOutputFields(metadata) {
  if (!metadata || typeof metadata !== "object" || Array.isArray(metadata)) return [];
  const outputContract = metadata.outputContract;
  if (!outputContract || typeof outputContract !== "object" || Array.isArray(outputContract)) {
    return [];
  }
  const requiredFields = outputContract.requiredFields;
  return Array.isArray(requiredFields) ? requiredFields.filter(
    (field) => typeof field === "string" && field.trim().length > 0
  ) : [];
}
function validateRequiredOutputFields(content, requiredFields) {
  if (requiredFields.length === 0) return null;
  if (!content.trim()) {
    return `Deliverable evidence must be JSON with required fields: ${requiredFields.join(", ")}.`;
  }
  try {
    const parsed = JSON.parse(content);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      return "Deliverable evidence must be a JSON object.";
    }
    const missing = requiredFields.filter(
      (field) => !Object.prototype.hasOwnProperty.call(parsed, field)
    );
    return missing.length > 0 ? `Deliverable evidence is missing required fields: ${missing.join(", ")}.` : null;
  } catch {
    return `Deliverable evidence must be valid JSON with required fields: ${requiredFields.join(", ")}.`;
  }
}
export function TaskEditMode({ task, onSave, onCancel, onSaveError }) {
  _s();
  const [title, setTitle] = useState(task.title);
  const [description, setDescription] = useState(task.description || "");
  const [priority, setPriority] = useState(task.priority);
  const [status, setStatus] = useState(task.status);
  const [type, setType] = useState(task.type);
  const [estimatedCost, setEstimatedCost] = useState(task.estimatedCost || 0);
  const [dueAt, setDueAt] = useState(formatDateInputValue(task.dueAt));
  const [assigneeIds, setAssigneeIds] = useState(task.assigneeIds || []);
  const [workPlanText, setWorkPlanText] = useState(
    task.workPlan?.bullets.join("\n") ?? ""
  );
  const [deliverableSummary, setDeliverableSummary] = useState(
    task.deliverable?.summary ?? ""
  );
  const [deliverableContent, setDeliverableContent] = useState(
    task.deliverable?.content ?? ""
  );
  const [reviewItems, setReviewItems] = useState(
    task.reviewChecklist?.items ?? DEFAULT_REVIEW_ITEMS.map((label) => ({ label, checked: false }))
  );
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState(null);
  const requiredOutputFields = getRequiredOutputFields(task.metadata);
  const updateTask = useMutation(api.tasks.update);
  const agents = useQuery(api.agents.listAll, { projectId: task.projectId });
  const allowedTransitions = useQuery(api.tasks.getAllowedTransitionsForHuman);
  const handleSave = async () => {
    setSaveError(null);
    if (status === "REVIEW") {
      const contractError = validateRequiredOutputFields(
        deliverableContent,
        requiredOutputFields
      );
      if (contractError) {
        setSaveError(contractError);
        onSaveError?.(contractError);
        return;
      }
    }
    setSaving(true);
    try {
      const workPlanBullets = workPlanText.split("\n").map((bullet) => bullet.trim()).filter(Boolean);
      await updateTask({
        taskId: task._id,
        title,
        description,
        priority,
        status,
        type,
        estimatedCost,
        dueAt: parseDateInputValue(dueAt),
        assigneeIds,
        workPlan: workPlanBullets.length > 0 ? {
          bullets: workPlanBullets,
          estimatedCost: estimatedCost || void 0
        } : void 0,
        deliverable: deliverableSummary.trim() || deliverableContent.trim() ? {
          summary: deliverableSummary.trim() || void 0,
          content: deliverableContent.trim() || void 0,
          artifactIds: task.deliverable?.artifactIds ?? []
        } : void 0,
        reviewChecklist: {
          type: task.reviewChecklist?.type ?? "SUBMISSION",
          items: reviewItems
        },
        actorUserId: "operator",
        idempotencyKey: `task-editor:${task._id}:${status}:${Date.now()}`
      });
      onSave();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to update task";
      setSaveError(message);
      onSaveError?.(message);
    } finally {
      setSaving(false);
    }
  };
  const statuses = [
    task.status,
    ...allowedTransitions?.[task.status] ?? []
  ].filter((value, index, values) => values.indexOf(value) === index);
  const types = [
    "CONTENT",
    "SOCIAL",
    "EMAIL_MARKETING",
    "CUSTOMER_RESEARCH",
    "SEO_RESEARCH",
    "ENGINEERING",
    "DOCS",
    "OPS"
  ];
  const priorities = [1, 2, 3, 4];
  return /* @__PURE__ */ jsxDEV("div", { className: "p-5 flex flex-col gap-5 max-h-[calc(100vh-8rem)] overflow-y-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-border", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "m-0 text-base font-semibold text-foreground flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(Pencil, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 202,
          columnNumber: 11
        }, this),
        "Edit task"
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
        lineNumber: 201,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: handleSave,
            disabled: saving || !title.trim(),
            size: "sm",
            className: "gap-1.5",
            children: [
              saving ? /* @__PURE__ */ jsxDEV(Loader2, { className: "h-3.5 w-3.5 animate-spin" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
                lineNumber: 213,
                columnNumber: 13
              }, this) : /* @__PURE__ */ jsxDEV(Save, { className: "h-3.5 w-3.5" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
                lineNumber: 215,
                columnNumber: 13
              }, this),
              saving ? "Saving…" : "Save"
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 206,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(Button, { variant: "outline", size: "sm", onClick: onCancel, disabled: saving, children: "Cancel" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 219,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
        lineNumber: 205,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
      lineNumber: 200,
      columnNumber: 7
    }, this),
    saveError && /* @__PURE__ */ jsxDEV(
      "div",
      {
        id: "task-edit-save-error",
        role: "alert",
        className: "rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive",
        children: saveError
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
        lineNumber: 225,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: "task-edit-title", children: "Title *" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 236,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            id: "task-edit-title",
            value: title,
            onChange: (e) => setTitle(e.target.value),
            placeholder: "Task title",
            autoFocus: true
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 237,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
        lineNumber: 235,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: "task-edit-description", children: "Description" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 247,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Textarea,
          {
            id: "task-edit-description",
            value: description,
            onChange: (e) => setDescription(e.target.value),
            rows: 6,
            placeholder: "Detailed task description…",
            className: "resize-y min-h-[120px]"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 248,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
        lineNumber: 246,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Status" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 260,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Select, { value: status, onValueChange: (v) => setStatus(v), children: [
            /* @__PURE__ */ jsxDEV(SelectTrigger, { children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
              lineNumber: 263,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
              lineNumber: 262,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(SelectContent, { children: statuses.map(
              (s) => /* @__PURE__ */ jsxDEV(SelectItem, { value: s, children: s }, s, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
                lineNumber: 267,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
              lineNumber: 265,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 261,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 259,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Priority" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 276,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: String(priority),
              onValueChange: (v) => setPriority(Number(v)),
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
                  lineNumber: 282,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
                  lineNumber: 281,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: priorities.map(
                  (p) => /* @__PURE__ */ jsxDEV(SelectItem, { value: String(p), children: [
                    "P",
                    p,
                    " —",
                    " ",
                    p === 1 ? "Critical" : p === 2 ? "High" : p === 3 ? "Normal" : "Low"
                  ] }, p, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
                    lineNumber: 286,
                    columnNumber: 17
                  }, this)
                ) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
                  lineNumber: 284,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
              lineNumber: 277,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 275,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxDEV(Label, { children: "Type" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 296,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Select, { value: type, onValueChange: (v) => setType(v), children: [
            /* @__PURE__ */ jsxDEV(SelectTrigger, { children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
              lineNumber: 299,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
              lineNumber: 298,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(SelectContent, { children: types.map(
              (t) => /* @__PURE__ */ jsxDEV(SelectItem, { value: t, children: t }, t, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
                lineNumber: 303,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
              lineNumber: 301,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 297,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 295,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
        lineNumber: 258,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: "task-edit-due", children: "Due date" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 313,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              id: "task-edit-due",
              type: "date",
              value: dueAt,
              onChange: (e) => setDueAt(e.target.value)
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
              lineNumber: 315,
              columnNumber: 13
            },
            this
          ),
          dueAt && /* @__PURE__ */ jsxDEV(Button, { type: "button", variant: "ghost", size: "sm", className: "h-9 px-2.5 text-xs", onClick: () => setDueAt(""), children: "Clear" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 322,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 314,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
        lineNumber: 312,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { children: [
          "Assigned agents (",
          assigneeIds.length,
          ")"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 330,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 p-3 rounded-md border border-border bg-muted/20 min-h-[3rem]", children: [
          agents?.map((agent) => {
            const isSelected = assigneeIds.includes(agent._id);
            return /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "button",
                variant: isSelected ? "default" : "outline",
                size: "sm",
                className: cn(
                  "h-8 text-xs",
                  isSelected && "ring-2 ring-primary/30"
                ),
                onClick: () => {
                  if (isSelected) {
                    setAssigneeIds(assigneeIds.filter((id) => id !== agent._id));
                  } else {
                    setAssigneeIds([...assigneeIds, agent._id]);
                  }
                },
                children: [
                  agent.emoji ? /* @__PURE__ */ jsxDEV("span", { className: "mr-1", children: agent.emoji }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
                    lineNumber: 352,
                    columnNumber: 34
                  }, this) : null,
                  agent.name
                ]
              },
              agent._id,
              true,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
                lineNumber: 335,
                columnNumber: 17
              },
              this
            );
          }),
          agents?.length === 0 && /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted-foreground py-1", children: "No agents in project." }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 358,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 331,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
        lineNumber: 329,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: "task-edit-cost", children: "Estimated cost ($)" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 364,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            id: "task-edit-cost",
            type: "number",
            value: estimatedCost,
            onChange: (e) => setEstimatedCost(Number(e.target.value)),
            step: "0.01",
            min: 0
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 365,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
        lineNumber: 363,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 border-t border-border pt-5", children: [
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: "task-edit-work-plan", children: "Work plan" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 376,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Textarea,
          {
            id: "task-edit-work-plan",
            value: workPlanText,
            onChange: (event) => setWorkPlanText(event.target.value),
            rows: 4,
            placeholder: "One plan item per line (3–6 required before starting)",
            className: "resize-y"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 377,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted-foreground", children: "Required to move an assigned task into progress." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 385,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
        lineNumber: 375,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 border-t border-border pt-5", children: [
        requiredOutputFields.length > 0 && /* @__PURE__ */ jsxDEV(Card, { className: "mb-4 border-border bg-muted/30 p-3", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-foreground", children: "Workflow output contract" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 393,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-muted-foreground", children: [
            "Required JSON fields: ",
            requiredOutputFields.join(", "),
            ". Submission is validated before the task can enter Review."
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 396,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 392,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: "task-edit-deliverable-summary", children: "Deliverable summary" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 402,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Textarea,
          {
            id: "task-edit-deliverable-summary",
            value: deliverableSummary,
            onChange: (event) => setDeliverableSummary(event.target.value),
            rows: 3,
            placeholder: "What was produced, what changed, and the outcome",
            className: "resize-y"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 403,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
        lineNumber: 390,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: "task-edit-deliverable-content", children: "Deliverable evidence" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 414,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Textarea,
          {
            id: "task-edit-deliverable-content",
            value: deliverableContent,
            onChange: (event) => setDeliverableContent(event.target.value),
            rows: 7,
            placeholder: "Evidence, source links, test output, artifact paths, risks, and limitations",
            className: "resize-y font-mono text-xs",
            "aria-describedby": saveError ? "task-edit-save-error" : void 0
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 415,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted-foreground", children: "Summary, evidence, and a checked review list are required before submission." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 424,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
        lineNumber: 413,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("fieldset", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV("legend", { className: "text-sm font-medium text-foreground", children: "Review checklist" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 430,
          columnNumber: 11
        }, this),
        reviewItems.map(
          (item, index) => /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "flex items-start gap-3 rounded-md border border-border bg-muted/20 px-3 py-2.5 text-sm",
              children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: item.checked,
                    onChange: (event) => setReviewItems(
                      (current) => current.map(
                        (candidate, candidateIndex) => candidateIndex === index ? { ...candidate, checked: event.target.checked } : candidate
                      )
                    ),
                    className: "mt-0.5 h-4 w-4"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
                    lineNumber: 436,
                    columnNumber: 15
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { children: item.label }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
                  lineNumber: 450,
                  columnNumber: 15
                }, this)
              ]
            },
            `${item.label}-${index}`,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
              lineNumber: 432,
              columnNumber: 11
            },
            this
          )
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
        lineNumber: 429,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-3 bg-muted/30 border-border/80", children: /* @__PURE__ */ jsxDEV("p", { className: "text-[0.7rem] text-muted-foreground space-y-1", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "block", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-foreground/90", children: "Task ID:" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 458,
            columnNumber: 15
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV("code", { className: "text-[0.65rem]", children: task._id }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 459,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 457,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "block", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-foreground/90", children: "Created:" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 462,
            columnNumber: 15
          }, this),
          " ",
          new Date(task._creationTime).toLocaleString()
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 461,
          columnNumber: 13
        }, this),
        task.actualCost > 0 && /* @__PURE__ */ jsxDEV("span", { className: "block", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-foreground/90", children: "Actual cost:" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
            lineNumber: 467,
            columnNumber: 17
          }, this),
          " $",
          task.actualCost.toFixed(2)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
          lineNumber: 466,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
        lineNumber: 456,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
        lineNumber: 455,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
      lineNumber: 234,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx",
    lineNumber: 199,
    columnNumber: 5
  }, this);
}
_s(TaskEditMode, "77+eUj99eRMqfKWZlqt4mg5VAOs=", false, function() {
  return [useMutation, useQuery, useQuery];
});
_c = TaskEditMode;
var _c;
$RefreshReg$(_c, "TaskEditMode");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskEditMode.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0xVOzs7Ozs7Ozs7Ozs7Ozs7OztBQXRMVixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLFdBQVc7QUFFcEIsU0FBU0Msc0JBQXNCQywyQkFBMkI7QUFDMUQsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxhQUFhO0FBQ3RCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxRQUFRQyxNQUFNQyxlQUFlO0FBRXRDLE1BQU1DLHVCQUF1QjtBQUFBLEVBQzNCO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBMkM7QUFHN0MsU0FBU0Msd0JBQXdCQyxVQUE2QjtBQUM1RCxNQUFJLENBQUNBLFlBQVksT0FBT0EsYUFBYSxZQUFZQyxNQUFNQyxRQUFRRixRQUFRLEVBQUcsUUFBTztBQUNqRixRQUFNRyxpQkFBa0JILFNBQXFDRztBQUM3RCxNQUFJLENBQUNBLGtCQUFrQixPQUFPQSxtQkFBbUIsWUFBWUYsTUFBTUMsUUFBUUMsY0FBYyxHQUFHO0FBQzFGLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTUMsaUJBQWtCRCxlQUEyQ0M7QUFDbkUsU0FBT0gsTUFBTUMsUUFBUUUsY0FBYyxJQUMvQkEsZUFBZUM7QUFBQUEsSUFDYixDQUFDQyxVQUEyQixPQUFPQSxVQUFVLFlBQVlBLE1BQU1DLEtBQUssRUFBRUMsU0FBUztBQUFBLEVBQ2pGLElBQ0E7QUFDTjtBQUVBLFNBQVNDLDZCQUE2QkMsU0FBaUJOLGdCQUF5QztBQUM5RixNQUFJQSxlQUFlSSxXQUFXLEVBQUcsUUFBTztBQUN4QyxNQUFJLENBQUNFLFFBQVFILEtBQUssR0FBRztBQUNuQixXQUFPLDJEQUEyREgsZUFBZU8sS0FBSyxJQUFJLENBQUM7QUFBQSxFQUM3RjtBQUNBLE1BQUk7QUFDRixVQUFNQyxTQUFrQkMsS0FBS0MsTUFBTUosT0FBTztBQUMxQyxRQUFJLENBQUNFLFVBQVUsT0FBT0EsV0FBVyxZQUFZWCxNQUFNQyxRQUFRVSxNQUFNLEdBQUc7QUFDbEUsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNRyxVQUFVWCxlQUFlQztBQUFBQSxNQUM3QixDQUFDQyxVQUFVLENBQUNVLE9BQU9DLFVBQVVDLGVBQWVDLEtBQUtQLFFBQVFOLEtBQUs7QUFBQSxJQUNoRTtBQUNBLFdBQU9TLFFBQVFQLFNBQVMsSUFDcEIsb0RBQW9ETyxRQUFRSixLQUFLLElBQUksQ0FBQyxNQUN0RTtBQUFBLEVBQ04sUUFBUTtBQUNOLFdBQU8saUVBQWlFUCxlQUFlTyxLQUFLLElBQUksQ0FBQztBQUFBLEVBQ25HO0FBQ0Y7QUFVTyxnQkFBU1MsYUFBYSxFQUFFQyxNQUFNQyxRQUFRQyxVQUFVQyxZQUErQixHQUFHO0FBQUFDLEtBQUE7QUFDdkYsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlqRCxTQUFTMkMsS0FBS0ssS0FBSztBQUM3QyxRQUFNLENBQUNFLGFBQWFDLGNBQWMsSUFBSW5ELFNBQVMyQyxLQUFLTyxlQUFlLEVBQUU7QUFDckUsUUFBTSxDQUFDRSxVQUFVQyxXQUFXLElBQUlyRCxTQUFTMkMsS0FBS1MsUUFBUTtBQUN0RCxRQUFNLENBQUNFLFFBQVFDLFNBQVMsSUFBSXZELFNBQVMyQyxLQUFLVyxNQUFNO0FBQ2hELFFBQU0sQ0FBQ0UsTUFBTUMsT0FBTyxJQUFJekQsU0FBUzJDLEtBQUthLElBQUk7QUFDMUMsUUFBTSxDQUFDRSxlQUFlQyxnQkFBZ0IsSUFBSTNELFNBQVMyQyxLQUFLZSxpQkFBaUIsQ0FBQztBQUMxRSxRQUFNLENBQUNFLE9BQU9DLFFBQVEsSUFBSTdELFNBQVNJLHFCQUFxQnVDLEtBQUtpQixLQUFLLENBQUM7QUFDbkUsUUFBTSxDQUFDRSxhQUFhQyxjQUFjLElBQUkvRCxTQUF5QjJDLEtBQUttQixlQUFlLEVBQUU7QUFDckYsUUFBTSxDQUFDRSxjQUFjQyxlQUFlLElBQUlqRTtBQUFBQSxJQUN0QzJDLEtBQUt1QixVQUFVQyxRQUFRbEMsS0FBSyxJQUFJLEtBQUs7QUFBQSxFQUN2QztBQUNBLFFBQU0sQ0FBQ21DLG9CQUFvQkMscUJBQXFCLElBQUlyRTtBQUFBQSxJQUNsRDJDLEtBQUsyQixhQUFhQyxXQUFXO0FBQUEsRUFDL0I7QUFDQSxRQUFNLENBQUNDLG9CQUFvQkMscUJBQXFCLElBQUl6RTtBQUFBQSxJQUNsRDJDLEtBQUsyQixhQUFhdEMsV0FBVztBQUFBLEVBQy9CO0FBQ0EsUUFBTSxDQUFDMEMsYUFBYUMsY0FBYyxJQUFJM0U7QUFBQUEsSUFDcEMyQyxLQUFLaUMsaUJBQWlCQyxTQUNwQnpELHFCQUFxQjBELElBQUksQ0FBQ0MsV0FBVyxFQUFFQSxPQUFPQyxTQUFTLE1BQU0sRUFBRTtBQUFBLEVBQ25FO0FBQ0EsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlsRixTQUFTLEtBQUs7QUFDMUMsUUFBTSxDQUFDbUYsV0FBV0MsWUFBWSxJQUFJcEYsU0FBd0IsSUFBSTtBQUM5RCxRQUFNcUYsdUJBQXVCaEUsd0JBQXdCc0IsS0FBS3JCLFFBQVE7QUFFbEUsUUFBTWdFLGFBQWFyRixZQUFZRSxJQUFJb0YsTUFBTUMsTUFBTTtBQUMvQyxRQUFNQyxTQUFTdkYsU0FBU0MsSUFBSXNGLE9BQU9DLFNBQVMsRUFBRUMsV0FBV2hELEtBQUtnRCxVQUFVLENBQUM7QUFDekUsUUFBTUMscUJBQXFCMUYsU0FBU0MsSUFBSW9GLE1BQU1NLDZCQUE2QjtBQUUzRSxRQUFNQyxhQUFhLFlBQVk7QUFDN0JWLGlCQUFhLElBQUk7QUFDakIsUUFBSTlCLFdBQVcsVUFBVTtBQUN2QixZQUFNeUMsZ0JBQWdCaEU7QUFBQUEsUUFDcEJ5QztBQUFBQSxRQUNBYTtBQUFBQSxNQUNGO0FBQ0EsVUFBSVUsZUFBZTtBQUNqQlgscUJBQWFXLGFBQWE7QUFDMUJqRCxzQkFBY2lELGFBQWE7QUFDM0I7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUVBYixjQUFVLElBQUk7QUFDZCxRQUFJO0FBQ0YsWUFBTWMsa0JBQWtCaEMsYUFDckJpQyxNQUFNLElBQUksRUFDVm5CLElBQUksQ0FBQ29CLFdBQVdBLE9BQU9yRSxLQUFLLENBQUMsRUFDN0JGLE9BQU93RSxPQUFPO0FBQ2pCLFlBQU1iLFdBQVc7QUFBQSxRQUNmYyxRQUFRekQsS0FBSzBEO0FBQUFBLFFBQ2JyRDtBQUFBQSxRQUNBRTtBQUFBQSxRQUNBRTtBQUFBQSxRQUNBRTtBQUFBQSxRQUNBRTtBQUFBQSxRQUNBRTtBQUFBQSxRQUNBRSxPQUFPdkQsb0JBQW9CdUQsS0FBSztBQUFBLFFBQ2hDRTtBQUFBQSxRQUNBSSxVQUNFOEIsZ0JBQWdCbEUsU0FBUyxJQUNyQjtBQUFBLFVBQ0VxQyxTQUFTNkI7QUFBQUEsVUFDVHRDLGVBQWVBLGlCQUFpQjRDO0FBQUFBLFFBQ2xDLElBQ0FBO0FBQUFBLFFBQ05oQyxhQUNFRixtQkFBbUJ2QyxLQUFLLEtBQUsyQyxtQkFBbUIzQyxLQUFLLElBQ2pEO0FBQUEsVUFDRTBDLFNBQVNILG1CQUFtQnZDLEtBQUssS0FBS3lFO0FBQUFBLFVBQ3RDdEUsU0FBU3dDLG1CQUFtQjNDLEtBQUssS0FBS3lFO0FBQUFBLFVBQ3RDQyxhQUFhNUQsS0FBSzJCLGFBQWFpQyxlQUFlO0FBQUEsUUFDaEQsSUFDQUQ7QUFBQUEsUUFDTjFCLGlCQUFpQjtBQUFBLFVBQ2ZwQixNQUFNYixLQUFLaUMsaUJBQWlCcEIsUUFBUTtBQUFBLFVBQ3BDcUIsT0FBT0g7QUFBQUEsUUFDVDtBQUFBLFFBQ0E4QixhQUFhO0FBQUEsUUFDYkMsZ0JBQWdCLGVBQWU5RCxLQUFLMEQsR0FBRyxJQUFJL0MsTUFBTSxJQUFJb0QsS0FBS0MsSUFBSSxDQUFDO0FBQUEsTUFDakUsQ0FBQztBQUNEL0QsYUFBTztBQUFBLElBQ1QsU0FBU2dFLE9BQU87QUFDZCxZQUFNQyxVQUNKRCxpQkFBaUJFLFFBQVFGLE1BQU1DLFVBQVU7QUFDM0N6QixtQkFBYXlCLE9BQU87QUFDcEIvRCxvQkFBYytELE9BQU87QUFBQSxJQUN2QixVQUFDO0FBQ0MzQixnQkFBVSxLQUFLO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBRUEsUUFBTTZCLFdBQTBDO0FBQUEsSUFDOUNwRSxLQUFLVztBQUFBQSxJQUNMLEdBQU1zQyxxQkFBcUJqRCxLQUFLVyxNQUFNLEtBQUs7QUFBQSxFQUFzQyxFQUNqRjNCLE9BQU8sQ0FBQ3FGLE9BQU9DLE9BQU9DLFdBQVdBLE9BQU9DLFFBQVFILEtBQUssTUFBTUMsS0FBSztBQUNsRSxRQUFNRyxRQUFxQztBQUFBLElBQ3pDO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQUs7QUFFUCxRQUFNQyxhQUE4QyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUM7QUFFL0QsU0FDRSx1QkFBQyxTQUFJLFdBQVUsb0VBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsaUZBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsdUVBQ1o7QUFBQSwrQkFBQyxVQUFPLFdBQVUsbUNBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQTtBQUFBLFdBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBU3ZCO0FBQUFBLFlBQ1QsVUFBVWIsVUFBVSxDQUFDakMsTUFBTW5CLEtBQUs7QUFBQSxZQUNoQyxNQUFLO0FBQUEsWUFDTCxXQUFVO0FBQUEsWUFFVG9EO0FBQUFBLHVCQUNDLHVCQUFDLFdBQVEsV0FBVSw4QkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkMsSUFFN0MsdUJBQUMsUUFBSyxXQUFVLGlCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QjtBQUFBLGNBRTlCQSxTQUFTLFlBQVk7QUFBQTtBQUFBO0FBQUEsVUFYeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWUE7QUFBQSxRQUNBLHVCQUFDLFVBQU8sU0FBUSxXQUFVLE1BQUssTUFBSyxTQUFTcEMsVUFBVSxVQUFVb0MsUUFBTyxzQkFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlCQTtBQUFBLFNBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkE7QUFBQSxJQUNDRSxhQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxJQUFHO0FBQUEsUUFDSCxNQUFLO0FBQUEsUUFDTCxXQUFVO0FBQUEsUUFFVEE7QUFBQUE7QUFBQUEsTUFMSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNQTtBQUFBLElBR0YsdUJBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxTQUFNLFNBQVEsbUJBQWtCLHVCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdDO0FBQUEsUUFDeEM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUc7QUFBQSxZQUNILE9BQU9uQztBQUFBQSxZQUNQLFVBQVUsQ0FBQ3NFLE1BQU1yRSxTQUFTcUUsRUFBRUMsT0FBT1AsS0FBSztBQUFBLFlBQ3hDLGFBQVk7QUFBQSxZQUNaLFdBQVM7QUFBQTtBQUFBLFVBTFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS1c7QUFBQSxXQVBiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxTQUFNLFNBQVEseUJBQXdCLDJCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUEsUUFDbEQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUc7QUFBQSxZQUNILE9BQU85RDtBQUFBQSxZQUNQLFVBQVUsQ0FBQ29FLE1BQU1uRSxlQUFlbUUsRUFBRUMsT0FBT1AsS0FBSztBQUFBLFlBQzlDLE1BQU07QUFBQSxZQUNOLGFBQVk7QUFBQSxZQUNaLFdBQVU7QUFBQTtBQUFBLFVBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTW9DO0FBQUEsV0FSdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFNBQU0sc0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYTtBQUFBLFVBQ2IsdUJBQUMsVUFBTyxPQUFPMUQsUUFBUSxlQUFlLENBQUNrRSxNQUFNakUsVUFBVWlFLENBQTJCLEdBQ2hGO0FBQUEsbUNBQUMsaUJBQ0MsaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBWSxLQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLGlCQUNFVCxtQkFBU2pDO0FBQUFBLGNBQUksQ0FBQzJDLE1BQ2IsdUJBQUMsY0FBbUIsT0FBT0EsR0FDeEJBLGVBRGNBLEdBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxZQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLGVBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFNBQU0sd0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZTtBQUFBLFVBQ2Y7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU9DLE9BQU90RSxRQUFRO0FBQUEsY0FDdEIsZUFBZSxDQUFDb0UsTUFBTW5FLFlBQVlzRSxPQUFPSCxDQUFDLENBQTZCO0FBQUEsY0FFdkU7QUFBQSx1Q0FBQyxpQkFDQyxpQ0FBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFZLEtBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLGlCQUNFSCxxQkFBV3ZDO0FBQUFBLGtCQUFJLENBQUM4QyxNQUNmLHVCQUFDLGNBQW1CLE9BQU9GLE9BQU9FLENBQUMsR0FBRTtBQUFBO0FBQUEsb0JBQ2pDQTtBQUFBQSxvQkFBRTtBQUFBLG9CQUFHO0FBQUEsb0JBQ05BLE1BQU0sSUFBSSxhQUFhQSxNQUFNLElBQUksU0FBU0EsTUFBTSxJQUFJLFdBQVc7QUFBQSx1QkFGakRBLEdBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxnQkFDRCxLQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQTtBQUFBO0FBQUEsWUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFlQTtBQUFBLGFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsU0FBTSxvQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFXO0FBQUEsVUFDWCx1QkFBQyxVQUFPLE9BQU9wRSxNQUFNLGVBQWUsQ0FBQ2dFLE1BQU0vRCxRQUFRK0QsQ0FBeUIsR0FDMUU7QUFBQSxtQ0FBQyxpQkFDQyxpQ0FBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFZLEtBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsaUJBQ0VKLGdCQUFNdEM7QUFBQUEsY0FBSSxDQUFDK0MsTUFDVix1QkFBQyxjQUFtQixPQUFPQSxHQUN4QkEsZUFEY0EsR0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsZUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsYUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0E7QUFBQSxXQW5ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0RBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFNBQU0sU0FBUSxpQkFBZ0Isd0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUM7QUFBQSxRQUN2Qyx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsT0FBT2pFO0FBQUFBLGNBQ1AsVUFBVSxDQUFDMEQsTUFBTXpELFNBQVN5RCxFQUFFQyxPQUFPUCxLQUFLO0FBQUE7QUFBQSxZQUoxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJNEM7QUFBQSxVQUUzQ3BELFNBQ0MsdUJBQUMsVUFBTyxNQUFLLFVBQVMsU0FBUSxTQUFRLE1BQUssTUFBSyxXQUFVLHNCQUFxQixTQUFTLE1BQU1DLFNBQVMsRUFBRSxHQUFFLHFCQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxXQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxTQUFNO0FBQUE7QUFBQSxVQUFrQkMsWUFBWWhDO0FBQUFBLFVBQU87QUFBQSxhQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDO0FBQUEsUUFDN0MsdUJBQUMsU0FBSSxXQUFVLHFGQUNaMkQ7QUFBQUEsa0JBQVFYLElBQUksQ0FBQ2dELFVBQVU7QUFDdEIsa0JBQU1DLGFBQWFqRSxZQUFZa0UsU0FBU0YsTUFBTXpCLEdBQUc7QUFDakQsbUJBQ0U7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUzBCLGFBQWEsWUFBWTtBQUFBLGdCQUNsQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVy9HO0FBQUFBLGtCQUNUO0FBQUEsa0JBQ0ErRyxjQUFjO0FBQUEsZ0JBQ2hCO0FBQUEsZ0JBQ0EsU0FBUyxNQUFNO0FBQ2Isc0JBQUlBLFlBQVk7QUFDZGhFLG1DQUFlRCxZQUFZbkMsT0FBTyxDQUFDc0csT0FBT0EsT0FBT0gsTUFBTXpCLEdBQUcsQ0FBQztBQUFBLGtCQUM3RCxPQUFPO0FBQ0x0QyxtQ0FBZSxDQUFDLEdBQUdELGFBQWFnRSxNQUFNekIsR0FBRyxDQUFDO0FBQUEsa0JBQzVDO0FBQUEsZ0JBQ0Y7QUFBQSxnQkFFQ3lCO0FBQUFBLHdCQUFNSSxRQUFRLHVCQUFDLFVBQUssV0FBVSxRQUFRSixnQkFBTUksU0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0MsSUFBVTtBQUFBLGtCQUM1REosTUFBTUs7QUFBQUE7QUFBQUE7QUFBQUEsY0FqQkZMLE1BQU16QjtBQUFBQSxjQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFtQkE7QUFBQSxVQUVKLENBQUM7QUFBQSxVQUNBWixRQUFRM0QsV0FBVyxLQUNsQix1QkFBQyxPQUFFLFdBQVUsc0NBQXFDLHFDQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RTtBQUFBLGFBM0IzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkJBO0FBQUEsV0EvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdDQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxTQUFNLFNBQVEsa0JBQWlCLGtDQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUEsUUFDbEQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUc7QUFBQSxZQUNILE1BQUs7QUFBQSxZQUNMLE9BQU80QjtBQUFBQSxZQUNQLFVBQVUsQ0FBQzRELE1BQU0zRCxpQkFBaUJnRSxPQUFPTCxFQUFFQyxPQUFPUCxLQUFLLENBQUM7QUFBQSxZQUN4RCxNQUFLO0FBQUEsWUFDTCxLQUFLO0FBQUE7QUFBQSxVQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1TO0FBQUEsV0FSWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLCtCQUFDLFNBQU0sU0FBUSx1QkFBc0IseUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUM5QztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsSUFBRztBQUFBLFlBQ0gsT0FBT2hEO0FBQUFBLFlBQ1AsVUFBVSxDQUFDb0UsVUFBVW5FLGdCQUFnQm1FLE1BQU1iLE9BQU9QLEtBQUs7QUFBQSxZQUN2RCxNQUFNO0FBQUEsWUFDTixhQUFhO0FBQUEsWUFDYixXQUFVO0FBQUE7QUFBQSxVQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1zQjtBQUFBLFFBRXRCLHVCQUFDLE9BQUUsV0FBVSxpQ0FBK0IsZ0VBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ1ozQjtBQUFBQSw2QkFBcUJ2RCxTQUFTLEtBQzdCLHVCQUFDLFFBQUssV0FBVSxzQ0FDZDtBQUFBLGlDQUFDLE9BQUUsV0FBVSx1Q0FBcUMsd0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxzQ0FBb0M7QUFBQTtBQUFBLFlBQ3hCdUQscUJBQXFCcEQsS0FBSyxJQUFJO0FBQUEsWUFBRTtBQUFBLGVBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUYsdUJBQUMsU0FBTSxTQUFRLGlDQUFnQyxtQ0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRTtBQUFBLFFBQ2xFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxJQUFHO0FBQUEsWUFDSCxPQUFPbUM7QUFBQUEsWUFDUCxVQUFVLENBQUNnRSxVQUFVL0Qsc0JBQXNCK0QsTUFBTWIsT0FBT1AsS0FBSztBQUFBLFlBQzdELE1BQU07QUFBQSxZQUNOLGFBQVk7QUFBQSxZQUNaLFdBQVU7QUFBQTtBQUFBLFVBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTXNCO0FBQUEsV0FuQnhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBTSxTQUFRLGlDQUFnQyxvQ0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRTtBQUFBLFFBQ25FO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxJQUFHO0FBQUEsWUFDSCxPQUFPeEM7QUFBQUEsWUFDUCxVQUFVLENBQUM0RCxVQUFVM0Qsc0JBQXNCMkQsTUFBTWIsT0FBT1AsS0FBSztBQUFBLFlBQzdELE1BQU07QUFBQSxZQUNOLGFBQVk7QUFBQSxZQUNaLFdBQVU7QUFBQSxZQUNWLG9CQUFrQjdCLFlBQVkseUJBQXlCbUI7QUFBQUE7QUFBQUEsVUFQekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT21FO0FBQUEsUUFFbkUsdUJBQUMsT0FBRSxXQUFVLGlDQUErQiw0RkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxNQUVBLHVCQUFDLGNBQVMsV0FBVSxhQUNsQjtBQUFBLCtCQUFDLFlBQU8sV0FBVSx1Q0FBc0MsZ0NBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0U7QUFBQSxRQUN2RTVCLFlBQVlJO0FBQUFBLFVBQUksQ0FBQ3VELE1BQU1wQixVQUN0QjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsV0FBVTtBQUFBLGNBRVY7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU29CLEtBQUtyRDtBQUFBQSxvQkFDZCxVQUFVLENBQUNvRCxVQUNUekQ7QUFBQUEsc0JBQWUsQ0FBQzJELFlBQ2RBLFFBQVF4RDtBQUFBQSx3QkFBSSxDQUFDeUQsV0FBV0MsbUJBQ3RCQSxtQkFBbUJ2QixRQUNmLEVBQUUsR0FBR3NCLFdBQVd2RCxTQUFTb0QsTUFBTWIsT0FBT3ZDLFFBQVEsSUFDOUN1RDtBQUFBQSxzQkFDTjtBQUFBLG9CQUNGO0FBQUEsb0JBRUYsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVk0QjtBQUFBLGdCQUU1Qix1QkFBQyxVQUFNRixlQUFLdEQsU0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQjtBQUFBO0FBQUE7QUFBQSxZQWpCYixHQUFHc0QsS0FBS3RELEtBQUssSUFBSWtDLEtBQUs7QUFBQSxZQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBbUJBO0FBQUEsUUFDRDtBQUFBLFdBdkJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3QkE7QUFBQSxNQUVBLHVCQUFDLFFBQUssV0FBVSxvQ0FDZCxpQ0FBQyxPQUFFLFdBQVUsaURBQ1g7QUFBQSwrQkFBQyxVQUFLLFdBQVUsU0FDZDtBQUFBLGlDQUFDLFVBQUssV0FBVSxrQ0FBaUMsd0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlEO0FBQUEsVUFBUTtBQUFBLFVBQ2pFLHVCQUFDLFVBQUssV0FBVSxrQkFBa0J0RSxlQUFLMEQsT0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkM7QUFBQSxhQUY3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFVBQUssV0FBVSxTQUNkO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGtDQUFpQyx3QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUQ7QUFBQSxVQUFRO0FBQUEsVUFDaEUsSUFBSUssS0FBSy9ELEtBQUs4RixhQUFhLEVBQUVDLGVBQWU7QUFBQSxhQUYvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNDL0YsS0FBS2dHLGFBQWEsS0FDakIsdUJBQUMsVUFBSyxXQUFVLFNBQ2Q7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsa0NBQWlDLDRCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBLFVBQU87QUFBQSxVQUNuRWhHLEtBQUtnRyxXQUFXQyxRQUFRLENBQUM7QUFBQSxhQUY1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBO0FBQUEsU0E5T0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStPQTtBQUFBLE9BbFJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtUkE7QUFFSjtBQUFDN0YsR0FuWWVMLGNBQVk7QUFBQSxVQTBCUHpDLGFBQ0pDLFVBQ1lBLFFBQVE7QUFBQTtBQUFBLEtBNUJyQndDO0FBQVksSUFBQW1HO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsImFwaSIsImZvcm1hdERhdGVJbnB1dFZhbHVlIiwicGFyc2VEYXRlSW5wdXRWYWx1ZSIsIkJ1dHRvbiIsIklucHV0IiwiVGV4dGFyZWEiLCJMYWJlbCIsIlNlbGVjdCIsIlNlbGVjdENvbnRlbnQiLCJTZWxlY3RJdGVtIiwiU2VsZWN0VHJpZ2dlciIsIlNlbGVjdFZhbHVlIiwiQ2FyZCIsImNuIiwiUGVuY2lsIiwiU2F2ZSIsIkxvYWRlcjIiLCJERUZBVUxUX1JFVklFV19JVEVNUyIsImdldFJlcXVpcmVkT3V0cHV0RmllbGRzIiwibWV0YWRhdGEiLCJBcnJheSIsImlzQXJyYXkiLCJvdXRwdXRDb250cmFjdCIsInJlcXVpcmVkRmllbGRzIiwiZmlsdGVyIiwiZmllbGQiLCJ0cmltIiwibGVuZ3RoIiwidmFsaWRhdGVSZXF1aXJlZE91dHB1dEZpZWxkcyIsImNvbnRlbnQiLCJqb2luIiwicGFyc2VkIiwiSlNPTiIsInBhcnNlIiwibWlzc2luZyIsIk9iamVjdCIsInByb3RvdHlwZSIsImhhc093blByb3BlcnR5IiwiY2FsbCIsIlRhc2tFZGl0TW9kZSIsInRhc2siLCJvblNhdmUiLCJvbkNhbmNlbCIsIm9uU2F2ZUVycm9yIiwiX3MiLCJ0aXRsZSIsInNldFRpdGxlIiwiZGVzY3JpcHRpb24iLCJzZXREZXNjcmlwdGlvbiIsInByaW9yaXR5Iiwic2V0UHJpb3JpdHkiLCJzdGF0dXMiLCJzZXRTdGF0dXMiLCJ0eXBlIiwic2V0VHlwZSIsImVzdGltYXRlZENvc3QiLCJzZXRFc3RpbWF0ZWRDb3N0IiwiZHVlQXQiLCJzZXREdWVBdCIsImFzc2lnbmVlSWRzIiwic2V0QXNzaWduZWVJZHMiLCJ3b3JrUGxhblRleHQiLCJzZXRXb3JrUGxhblRleHQiLCJ3b3JrUGxhbiIsImJ1bGxldHMiLCJkZWxpdmVyYWJsZVN1bW1hcnkiLCJzZXREZWxpdmVyYWJsZVN1bW1hcnkiLCJkZWxpdmVyYWJsZSIsInN1bW1hcnkiLCJkZWxpdmVyYWJsZUNvbnRlbnQiLCJzZXREZWxpdmVyYWJsZUNvbnRlbnQiLCJyZXZpZXdJdGVtcyIsInNldFJldmlld0l0ZW1zIiwicmV2aWV3Q2hlY2tsaXN0IiwiaXRlbXMiLCJtYXAiLCJsYWJlbCIsImNoZWNrZWQiLCJzYXZpbmciLCJzZXRTYXZpbmciLCJzYXZlRXJyb3IiLCJzZXRTYXZlRXJyb3IiLCJyZXF1aXJlZE91dHB1dEZpZWxkcyIsInVwZGF0ZVRhc2siLCJ0YXNrcyIsInVwZGF0ZSIsImFnZW50cyIsImxpc3RBbGwiLCJwcm9qZWN0SWQiLCJhbGxvd2VkVHJhbnNpdGlvbnMiLCJnZXRBbGxvd2VkVHJhbnNpdGlvbnNGb3JIdW1hbiIsImhhbmRsZVNhdmUiLCJjb250cmFjdEVycm9yIiwid29ya1BsYW5CdWxsZXRzIiwic3BsaXQiLCJidWxsZXQiLCJCb29sZWFuIiwidGFza0lkIiwiX2lkIiwidW5kZWZpbmVkIiwiYXJ0aWZhY3RJZHMiLCJhY3RvclVzZXJJZCIsImlkZW1wb3RlbmN5S2V5IiwiRGF0ZSIsIm5vdyIsImVycm9yIiwibWVzc2FnZSIsIkVycm9yIiwic3RhdHVzZXMiLCJ2YWx1ZSIsImluZGV4IiwidmFsdWVzIiwiaW5kZXhPZiIsInR5cGVzIiwicHJpb3JpdGllcyIsImUiLCJ0YXJnZXQiLCJ2IiwicyIsIlN0cmluZyIsIk51bWJlciIsInAiLCJ0IiwiYWdlbnQiLCJpc1NlbGVjdGVkIiwiaW5jbHVkZXMiLCJpZCIsImVtb2ppIiwibmFtZSIsImV2ZW50IiwiaXRlbSIsImN1cnJlbnQiLCJjYW5kaWRhdGUiLCJjYW5kaWRhdGVJbmRleCIsIl9jcmVhdGlvblRpbWUiLCJ0b0xvY2FsZVN0cmluZyIsImFjdHVhbENvc3QiLCJ0b0ZpeGVkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVGFza0VkaXRNb2RlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5IH0gZnJvbSBcImNvbnZleC9yZWFjdFwiO1xuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2FwaVwiO1xuaW1wb3J0IHR5cGUgeyBJZCwgRG9jIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgZm9ybWF0RGF0ZUlucHV0VmFsdWUsIHBhcnNlRGF0ZUlucHV0VmFsdWUgfSBmcm9tIFwiQC9saWIvZGF0ZUlucHV0XCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2lucHV0XCI7XG5pbXBvcnQgeyBUZXh0YXJlYSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvdGV4dGFyZWFcIjtcbmltcG9ydCB7IExhYmVsIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9sYWJlbFwiO1xuaW1wb3J0IHtcbiAgU2VsZWN0LFxuICBTZWxlY3RDb250ZW50LFxuICBTZWxlY3RJdGVtLFxuICBTZWxlY3RUcmlnZ2VyLFxuICBTZWxlY3RWYWx1ZSxcbn0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9zZWxlY3RcIjtcbmltcG9ydCB7IENhcmQgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2NhcmRcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5pbXBvcnQgeyBQZW5jaWwsIFNhdmUsIExvYWRlcjIgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5cbmNvbnN0IERFRkFVTFRfUkVWSUVXX0lURU1TID0gW1xuICBcIkFjY2VwdGFuY2UgY3JpdGVyaWEgdmVyaWZpZWRcIixcbiAgXCJUZXN0cyBvciBtYW51YWwgY2hlY2tzIHBhc3NlZFwiLFxuICBcIkV2aWRlbmNlLCByaXNrcywgYW5kIGxpbWl0YXRpb25zIHJlY29yZGVkXCIsXG5dO1xuXG5mdW5jdGlvbiBnZXRSZXF1aXJlZE91dHB1dEZpZWxkcyhtZXRhZGF0YTogdW5rbm93bik6IHN0cmluZ1tdIHtcbiAgaWYgKCFtZXRhZGF0YSB8fCB0eXBlb2YgbWV0YWRhdGEgIT09IFwib2JqZWN0XCIgfHwgQXJyYXkuaXNBcnJheShtZXRhZGF0YSkpIHJldHVybiBbXTtcbiAgY29uc3Qgb3V0cHV0Q29udHJhY3QgPSAobWV0YWRhdGEgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLm91dHB1dENvbnRyYWN0O1xuICBpZiAoIW91dHB1dENvbnRyYWN0IHx8IHR5cGVvZiBvdXRwdXRDb250cmFjdCAhPT0gXCJvYmplY3RcIiB8fCBBcnJheS5pc0FycmF5KG91dHB1dENvbnRyYWN0KSkge1xuICAgIHJldHVybiBbXTtcbiAgfVxuICBjb25zdCByZXF1aXJlZEZpZWxkcyA9IChvdXRwdXRDb250cmFjdCBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikucmVxdWlyZWRGaWVsZHM7XG4gIHJldHVybiBBcnJheS5pc0FycmF5KHJlcXVpcmVkRmllbGRzKVxuICAgID8gcmVxdWlyZWRGaWVsZHMuZmlsdGVyKFxuICAgICAgICAoZmllbGQpOiBmaWVsZCBpcyBzdHJpbmcgPT4gdHlwZW9mIGZpZWxkID09PSBcInN0cmluZ1wiICYmIGZpZWxkLnRyaW0oKS5sZW5ndGggPiAwXG4gICAgICApXG4gICAgOiBbXTtcbn1cblxuZnVuY3Rpb24gdmFsaWRhdGVSZXF1aXJlZE91dHB1dEZpZWxkcyhjb250ZW50OiBzdHJpbmcsIHJlcXVpcmVkRmllbGRzOiBzdHJpbmdbXSk6IHN0cmluZyB8IG51bGwge1xuICBpZiAocmVxdWlyZWRGaWVsZHMubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbDtcbiAgaWYgKCFjb250ZW50LnRyaW0oKSkge1xuICAgIHJldHVybiBgRGVsaXZlcmFibGUgZXZpZGVuY2UgbXVzdCBiZSBKU09OIHdpdGggcmVxdWlyZWQgZmllbGRzOiAke3JlcXVpcmVkRmllbGRzLmpvaW4oXCIsIFwiKX0uYDtcbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IHBhcnNlZDogdW5rbm93biA9IEpTT04ucGFyc2UoY29udGVudCk7XG4gICAgaWYgKCFwYXJzZWQgfHwgdHlwZW9mIHBhcnNlZCAhPT0gXCJvYmplY3RcIiB8fCBBcnJheS5pc0FycmF5KHBhcnNlZCkpIHtcbiAgICAgIHJldHVybiBcIkRlbGl2ZXJhYmxlIGV2aWRlbmNlIG11c3QgYmUgYSBKU09OIG9iamVjdC5cIjtcbiAgICB9XG4gICAgY29uc3QgbWlzc2luZyA9IHJlcXVpcmVkRmllbGRzLmZpbHRlcihcbiAgICAgIChmaWVsZCkgPT4gIU9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChwYXJzZWQsIGZpZWxkKVxuICAgICk7XG4gICAgcmV0dXJuIG1pc3NpbmcubGVuZ3RoID4gMFxuICAgICAgPyBgRGVsaXZlcmFibGUgZXZpZGVuY2UgaXMgbWlzc2luZyByZXF1aXJlZCBmaWVsZHM6ICR7bWlzc2luZy5qb2luKFwiLCBcIil9LmBcbiAgICAgIDogbnVsbDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIGBEZWxpdmVyYWJsZSBldmlkZW5jZSBtdXN0IGJlIHZhbGlkIEpTT04gd2l0aCByZXF1aXJlZCBmaWVsZHM6ICR7cmVxdWlyZWRGaWVsZHMuam9pbihcIiwgXCIpfS5gO1xuICB9XG59XG5cbmludGVyZmFjZSBUYXNrRWRpdE1vZGVQcm9wcyB7XG4gIHRhc2s6IERvYzxcInRhc2tzXCI+O1xuICBvblNhdmU6ICgpID0+IHZvaWQ7XG4gIG9uQ2FuY2VsOiAoKSA9PiB2b2lkO1xuICAvKiogU2hvd24gd2hlbiBzYXZlIGZhaWxzIChlLmcuIGludmFsaWQgc3RhdHVzIHRyYW5zaXRpb24pLiBGYWxscyBiYWNrIHRvIGFsZXJ0IGlmIG9taXR0ZWQuICovXG4gIG9uU2F2ZUVycm9yPzogKG1lc3NhZ2U6IHN0cmluZykgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFRhc2tFZGl0TW9kZSh7IHRhc2ssIG9uU2F2ZSwgb25DYW5jZWwsIG9uU2F2ZUVycm9yIH06IFRhc2tFZGl0TW9kZVByb3BzKSB7XG4gIGNvbnN0IFt0aXRsZSwgc2V0VGl0bGVdID0gdXNlU3RhdGUodGFzay50aXRsZSk7XG4gIGNvbnN0IFtkZXNjcmlwdGlvbiwgc2V0RGVzY3JpcHRpb25dID0gdXNlU3RhdGUodGFzay5kZXNjcmlwdGlvbiB8fCBcIlwiKTtcbiAgY29uc3QgW3ByaW9yaXR5LCBzZXRQcmlvcml0eV0gPSB1c2VTdGF0ZSh0YXNrLnByaW9yaXR5KTtcbiAgY29uc3QgW3N0YXR1cywgc2V0U3RhdHVzXSA9IHVzZVN0YXRlKHRhc2suc3RhdHVzKTtcbiAgY29uc3QgW3R5cGUsIHNldFR5cGVdID0gdXNlU3RhdGUodGFzay50eXBlKTtcbiAgY29uc3QgW2VzdGltYXRlZENvc3QsIHNldEVzdGltYXRlZENvc3RdID0gdXNlU3RhdGUodGFzay5lc3RpbWF0ZWRDb3N0IHx8IDApO1xuICBjb25zdCBbZHVlQXQsIHNldER1ZUF0XSA9IHVzZVN0YXRlKGZvcm1hdERhdGVJbnB1dFZhbHVlKHRhc2suZHVlQXQpKTtcbiAgY29uc3QgW2Fzc2lnbmVlSWRzLCBzZXRBc3NpZ25lZUlkc10gPSB1c2VTdGF0ZTxJZDxcImFnZW50c1wiPltdPih0YXNrLmFzc2lnbmVlSWRzIHx8IFtdKTtcbiAgY29uc3QgW3dvcmtQbGFuVGV4dCwgc2V0V29ya1BsYW5UZXh0XSA9IHVzZVN0YXRlKFxuICAgIHRhc2sud29ya1BsYW4/LmJ1bGxldHMuam9pbihcIlxcblwiKSA/PyBcIlwiXG4gICk7XG4gIGNvbnN0IFtkZWxpdmVyYWJsZVN1bW1hcnksIHNldERlbGl2ZXJhYmxlU3VtbWFyeV0gPSB1c2VTdGF0ZShcbiAgICB0YXNrLmRlbGl2ZXJhYmxlPy5zdW1tYXJ5ID8/IFwiXCJcbiAgKTtcbiAgY29uc3QgW2RlbGl2ZXJhYmxlQ29udGVudCwgc2V0RGVsaXZlcmFibGVDb250ZW50XSA9IHVzZVN0YXRlKFxuICAgIHRhc2suZGVsaXZlcmFibGU/LmNvbnRlbnQgPz8gXCJcIlxuICApO1xuICBjb25zdCBbcmV2aWV3SXRlbXMsIHNldFJldmlld0l0ZW1zXSA9IHVzZVN0YXRlKFxuICAgIHRhc2sucmV2aWV3Q2hlY2tsaXN0Py5pdGVtcyA/P1xuICAgICAgREVGQVVMVF9SRVZJRVdfSVRFTVMubWFwKChsYWJlbCkgPT4gKHsgbGFiZWwsIGNoZWNrZWQ6IGZhbHNlIH0pKVxuICApO1xuICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbc2F2ZUVycm9yLCBzZXRTYXZlRXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHJlcXVpcmVkT3V0cHV0RmllbGRzID0gZ2V0UmVxdWlyZWRPdXRwdXRGaWVsZHModGFzay5tZXRhZGF0YSk7XG5cbiAgY29uc3QgdXBkYXRlVGFzayA9IHVzZU11dGF0aW9uKGFwaS50YXNrcy51cGRhdGUpO1xuICBjb25zdCBhZ2VudHMgPSB1c2VRdWVyeShhcGkuYWdlbnRzLmxpc3RBbGwsIHsgcHJvamVjdElkOiB0YXNrLnByb2plY3RJZCB9KTtcbiAgY29uc3QgYWxsb3dlZFRyYW5zaXRpb25zID0gdXNlUXVlcnkoYXBpLnRhc2tzLmdldEFsbG93ZWRUcmFuc2l0aW9uc0Zvckh1bWFuKTtcblxuICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldFNhdmVFcnJvcihudWxsKTtcbiAgICBpZiAoc3RhdHVzID09PSBcIlJFVklFV1wiKSB7XG4gICAgICBjb25zdCBjb250cmFjdEVycm9yID0gdmFsaWRhdGVSZXF1aXJlZE91dHB1dEZpZWxkcyhcbiAgICAgICAgZGVsaXZlcmFibGVDb250ZW50LFxuICAgICAgICByZXF1aXJlZE91dHB1dEZpZWxkc1xuICAgICAgKTtcbiAgICAgIGlmIChjb250cmFjdEVycm9yKSB7XG4gICAgICAgIHNldFNhdmVFcnJvcihjb250cmFjdEVycm9yKTtcbiAgICAgICAgb25TYXZlRXJyb3I/Lihjb250cmFjdEVycm9yKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH1cblxuICAgIHNldFNhdmluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgd29ya1BsYW5CdWxsZXRzID0gd29ya1BsYW5UZXh0XG4gICAgICAgIC5zcGxpdChcIlxcblwiKVxuICAgICAgICAubWFwKChidWxsZXQpID0+IGJ1bGxldC50cmltKCkpXG4gICAgICAgIC5maWx0ZXIoQm9vbGVhbik7XG4gICAgICBhd2FpdCB1cGRhdGVUYXNrKHtcbiAgICAgICAgdGFza0lkOiB0YXNrLl9pZCxcbiAgICAgICAgdGl0bGUsXG4gICAgICAgIGRlc2NyaXB0aW9uLFxuICAgICAgICBwcmlvcml0eSxcbiAgICAgICAgc3RhdHVzLFxuICAgICAgICB0eXBlLFxuICAgICAgICBlc3RpbWF0ZWRDb3N0LFxuICAgICAgICBkdWVBdDogcGFyc2VEYXRlSW5wdXRWYWx1ZShkdWVBdCksXG4gICAgICAgIGFzc2lnbmVlSWRzLFxuICAgICAgICB3b3JrUGxhbjpcbiAgICAgICAgICB3b3JrUGxhbkJ1bGxldHMubGVuZ3RoID4gMFxuICAgICAgICAgICAgPyB7XG4gICAgICAgICAgICAgICAgYnVsbGV0czogd29ya1BsYW5CdWxsZXRzLFxuICAgICAgICAgICAgICAgIGVzdGltYXRlZENvc3Q6IGVzdGltYXRlZENvc3QgfHwgdW5kZWZpbmVkLFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgICAgZGVsaXZlcmFibGU6XG4gICAgICAgICAgZGVsaXZlcmFibGVTdW1tYXJ5LnRyaW0oKSB8fCBkZWxpdmVyYWJsZUNvbnRlbnQudHJpbSgpXG4gICAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgICBzdW1tYXJ5OiBkZWxpdmVyYWJsZVN1bW1hcnkudHJpbSgpIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICBjb250ZW50OiBkZWxpdmVyYWJsZUNvbnRlbnQudHJpbSgpIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICBhcnRpZmFjdElkczogdGFzay5kZWxpdmVyYWJsZT8uYXJ0aWZhY3RJZHMgPz8gW10sXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDogdW5kZWZpbmVkLFxuICAgICAgICByZXZpZXdDaGVja2xpc3Q6IHtcbiAgICAgICAgICB0eXBlOiB0YXNrLnJldmlld0NoZWNrbGlzdD8udHlwZSA/PyBcIlNVQk1JU1NJT05cIixcbiAgICAgICAgICBpdGVtczogcmV2aWV3SXRlbXMsXG4gICAgICAgIH0sXG4gICAgICAgIGFjdG9yVXNlcklkOiBcIm9wZXJhdG9yXCIsXG4gICAgICAgIGlkZW1wb3RlbmN5S2V5OiBgdGFzay1lZGl0b3I6JHt0YXNrLl9pZH06JHtzdGF0dXN9OiR7RGF0ZS5ub3coKX1gLFxuICAgICAgfSk7XG4gICAgICBvblNhdmUoKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc3QgbWVzc2FnZSA9XG4gICAgICAgIGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJGYWlsZWQgdG8gdXBkYXRlIHRhc2tcIjtcbiAgICAgIHNldFNhdmVFcnJvcihtZXNzYWdlKTtcbiAgICAgIG9uU2F2ZUVycm9yPy4obWVzc2FnZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFNhdmluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IHN0YXR1c2VzOiBBcnJheTxEb2M8XCJ0YXNrc1wiPltcInN0YXR1c1wiXT4gPSBbXG4gICAgdGFzay5zdGF0dXMsXG4gICAgLi4uKCgoYWxsb3dlZFRyYW5zaXRpb25zPy5bdGFzay5zdGF0dXNdID8/IFtdKSBhcyBBcnJheTxEb2M8XCJ0YXNrc1wiPltcInN0YXR1c1wiXT4pKSxcbiAgXS5maWx0ZXIoKHZhbHVlLCBpbmRleCwgdmFsdWVzKSA9PiB2YWx1ZXMuaW5kZXhPZih2YWx1ZSkgPT09IGluZGV4KTtcbiAgY29uc3QgdHlwZXM6IEFycmF5PERvYzxcInRhc2tzXCI+W1widHlwZVwiXT4gPSBbXG4gICAgXCJDT05URU5UXCIsXG4gICAgXCJTT0NJQUxcIixcbiAgICBcIkVNQUlMX01BUktFVElOR1wiLFxuICAgIFwiQ1VTVE9NRVJfUkVTRUFSQ0hcIixcbiAgICBcIlNFT19SRVNFQVJDSFwiLFxuICAgIFwiRU5HSU5FRVJJTkdcIixcbiAgICBcIkRPQ1NcIixcbiAgICBcIk9QU1wiLFxuICBdO1xuICBjb25zdCBwcmlvcml0aWVzOiBBcnJheTxEb2M8XCJ0YXNrc1wiPltcInByaW9yaXR5XCJdPiA9IFsxLCAyLCAzLCA0XTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IGZsZXggZmxleC1jb2wgZ2FwLTUgbWF4LWgtW2NhbGMoMTAwdmgtOHJlbSldIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHBiLTQgYm9yZGVyLWIgYm9yZGVyLWJvcmRlclwiPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwibS0wIHRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZm9yZWdyb3VuZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIDxQZW5jaWwgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIiAvPlxuICAgICAgICAgIEVkaXQgdGFza1xuICAgICAgICA8L2gzPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTYXZlfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e3NhdmluZyB8fCAhdGl0bGUudHJpbSgpfVxuICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImdhcC0xLjVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtzYXZpbmcgPyAoXG4gICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cImgtMy41IHctMy41IGFuaW1hdGUtc3BpblwiIC8+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8U2F2ZSBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAge3NhdmluZyA/IFwiU2F2aW5n4oCmXCIgOiBcIlNhdmVcIn1cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgc2l6ZT1cInNtXCIgb25DbGljaz17b25DYW5jZWx9IGRpc2FibGVkPXtzYXZpbmd9PlxuICAgICAgICAgICAgQ2FuY2VsXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICB7c2F2ZUVycm9yICYmIChcbiAgICAgICAgPGRpdlxuICAgICAgICAgIGlkPVwidGFzay1lZGl0LXNhdmUtZXJyb3JcIlxuICAgICAgICAgIHJvbGU9XCJhbGVydFwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWRlc3RydWN0aXZlLzQwIGJnLWRlc3RydWN0aXZlLzEwIHB4LTMgcHktMiB0ZXh0LXNtIHRleHQtZGVzdHJ1Y3RpdmVcIlxuICAgICAgICA+XG4gICAgICAgICAge3NhdmVFcnJvcn1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTVcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cInRhc2stZWRpdC10aXRsZVwiPlRpdGxlICo8L0xhYmVsPlxuICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgaWQ9XCJ0YXNrLWVkaXQtdGl0bGVcIlxuICAgICAgICAgICAgdmFsdWU9e3RpdGxlfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUaXRsZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlRhc2sgdGl0bGVcIlxuICAgICAgICAgICAgYXV0b0ZvY3VzXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cInRhc2stZWRpdC1kZXNjcmlwdGlvblwiPkRlc2NyaXB0aW9uPC9MYWJlbD5cbiAgICAgICAgICA8VGV4dGFyZWFcbiAgICAgICAgICAgIGlkPVwidGFzay1lZGl0LWRlc2NyaXB0aW9uXCJcbiAgICAgICAgICAgIHZhbHVlPXtkZXNjcmlwdGlvbn1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RGVzY3JpcHRpb24oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgcm93cz17Nn1cbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGV0YWlsZWQgdGFzayBkZXNjcmlwdGlvbuKAplwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJyZXNpemUteSBtaW4taC1bMTIwcHhdXCJcbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgPExhYmVsPlN0YXR1czwvTGFiZWw+XG4gICAgICAgICAgICA8U2VsZWN0IHZhbHVlPXtzdGF0dXN9IG9uVmFsdWVDaGFuZ2U9eyh2KSA9PiBzZXRTdGF0dXModiBhcyBEb2M8XCJ0YXNrc1wiPltcInN0YXR1c1wiXSl9PlxuICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgLz5cbiAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICB7c3RhdHVzZXMubWFwKChzKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSBrZXk9e3N9IHZhbHVlPXtzfT5cbiAgICAgICAgICAgICAgICAgICAge3N9XG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgIDwvU2VsZWN0PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgIDxMYWJlbD5Qcmlvcml0eTwvTGFiZWw+XG4gICAgICAgICAgICA8U2VsZWN0XG4gICAgICAgICAgICAgIHZhbHVlPXtTdHJpbmcocHJpb3JpdHkpfVxuICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodikgPT4gc2V0UHJpb3JpdHkoTnVtYmVyKHYpIGFzIERvYzxcInRhc2tzXCI+W1wicHJpb3JpdHlcIl0pfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgLz5cbiAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICB7cHJpb3JpdGllcy5tYXAoKHApID0+IChcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17cH0gdmFsdWU9e1N0cmluZyhwKX0+XG4gICAgICAgICAgICAgICAgICAgIFB7cH0g4oCUe1wiIFwifVxuICAgICAgICAgICAgICAgICAgICB7cCA9PT0gMSA/IFwiQ3JpdGljYWxcIiA6IHAgPT09IDIgPyBcIkhpZ2hcIiA6IHAgPT09IDMgPyBcIk5vcm1hbFwiIDogXCJMb3dcIn1cbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgPExhYmVsPlR5cGU8L0xhYmVsPlxuICAgICAgICAgICAgPFNlbGVjdCB2YWx1ZT17dHlwZX0gb25WYWx1ZUNoYW5nZT17KHYpID0+IHNldFR5cGUodiBhcyBEb2M8XCJ0YXNrc1wiPltcInR5cGVcIl0pfT5cbiAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIC8+XG4gICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAge3R5cGVzLm1hcCgodCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXt0fSB2YWx1ZT17dH0+XG4gICAgICAgICAgICAgICAgICAgIHt0fVxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cInRhc2stZWRpdC1kdWVcIj5EdWUgZGF0ZTwvTGFiZWw+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgIGlkPVwidGFzay1lZGl0LWR1ZVwiXG4gICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcbiAgICAgICAgICAgICAgdmFsdWU9e2R1ZUF0fVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldER1ZUF0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICB7ZHVlQXQgJiYgKFxuICAgICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIiB2YXJpYW50PVwiZ2hvc3RcIiBzaXplPVwic21cIiBjbGFzc05hbWU9XCJoLTkgcHgtMi41IHRleHQteHNcIiBvbkNsaWNrPXsoKSA9PiBzZXREdWVBdChcIlwiKX0+XG4gICAgICAgICAgICAgICAgQ2xlYXJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgIDxMYWJlbD5Bc3NpZ25lZCBhZ2VudHMgKHthc3NpZ25lZUlkcy5sZW5ndGh9KTwvTGFiZWw+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMiBwLTMgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1tdXRlZC8yMCBtaW4taC1bM3JlbV1cIj5cbiAgICAgICAgICAgIHthZ2VudHM/Lm1hcCgoYWdlbnQpID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IGFzc2lnbmVlSWRzLmluY2x1ZGVzKGFnZW50Ll9pZCk7XG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAga2V5PXthZ2VudC5faWR9XG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9e2lzU2VsZWN0ZWQgPyBcImRlZmF1bHRcIiA6IFwib3V0bGluZVwifVxuICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgIFwiaC04IHRleHQteHNcIixcbiAgICAgICAgICAgICAgICAgICAgaXNTZWxlY3RlZCAmJiBcInJpbmctMiByaW5nLXByaW1hcnkvMzBcIlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGlzU2VsZWN0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRBc3NpZ25lZUlkcyhhc3NpZ25lZUlkcy5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gYWdlbnQuX2lkKSk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0QXNzaWduZWVJZHMoWy4uLmFzc2lnbmVlSWRzLCBhZ2VudC5faWRdKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7YWdlbnQuZW1vamkgPyA8c3BhbiBjbGFzc05hbWU9XCJtci0xXCI+e2FnZW50LmVtb2ppfTwvc3Bhbj4gOiBudWxsfVxuICAgICAgICAgICAgICAgICAge2FnZW50Lm5hbWV9XG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICAgIHthZ2VudHM/Lmxlbmd0aCA9PT0gMCAmJiAoXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIHB5LTFcIj5ObyBhZ2VudHMgaW4gcHJvamVjdC48L3A+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwidGFzay1lZGl0LWNvc3RcIj5Fc3RpbWF0ZWQgY29zdCAoJCk8L0xhYmVsPlxuICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgaWQ9XCJ0YXNrLWVkaXQtY29zdFwiXG4gICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgIHZhbHVlPXtlc3RpbWF0ZWRDb3N0fVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFc3RpbWF0ZWRDb3N0KE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxuICAgICAgICAgICAgbWluPXswfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIGJvcmRlci10IGJvcmRlci1ib3JkZXIgcHQtNVwiPlxuICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwidGFzay1lZGl0LXdvcmstcGxhblwiPldvcmsgcGxhbjwvTGFiZWw+XG4gICAgICAgICAgPFRleHRhcmVhXG4gICAgICAgICAgICBpZD1cInRhc2stZWRpdC13b3JrLXBsYW5cIlxuICAgICAgICAgICAgdmFsdWU9e3dvcmtQbGFuVGV4dH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFdvcmtQbGFuVGV4dChldmVudC50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgcm93cz17NH1cbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtcIk9uZSBwbGFuIGl0ZW0gcGVyIGxpbmUgKDPigJM2IHJlcXVpcmVkIGJlZm9yZSBzdGFydGluZylcIn1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlc2l6ZS15XCJcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICBSZXF1aXJlZCB0byBtb3ZlIGFuIGFzc2lnbmVkIHRhc2sgaW50byBwcm9ncmVzcy5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIGJvcmRlci10IGJvcmRlci1ib3JkZXIgcHQtNVwiPlxuICAgICAgICAgIHtyZXF1aXJlZE91dHB1dEZpZWxkcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cIm1iLTQgYm9yZGVyLWJvcmRlciBiZy1tdXRlZC8zMCBwLTNcIj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICBXb3JrZmxvdyBvdXRwdXQgY29udHJhY3RcbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgUmVxdWlyZWQgSlNPTiBmaWVsZHM6IHtyZXF1aXJlZE91dHB1dEZpZWxkcy5qb2luKFwiLCBcIil9LiBTdWJtaXNzaW9uIGlzXG4gICAgICAgICAgICAgICAgdmFsaWRhdGVkIGJlZm9yZSB0aGUgdGFzayBjYW4gZW50ZXIgUmV2aWV3LlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgKX1cbiAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cInRhc2stZWRpdC1kZWxpdmVyYWJsZS1zdW1tYXJ5XCI+RGVsaXZlcmFibGUgc3VtbWFyeTwvTGFiZWw+XG4gICAgICAgICAgPFRleHRhcmVhXG4gICAgICAgICAgICBpZD1cInRhc2stZWRpdC1kZWxpdmVyYWJsZS1zdW1tYXJ5XCJcbiAgICAgICAgICAgIHZhbHVlPXtkZWxpdmVyYWJsZVN1bW1hcnl9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXREZWxpdmVyYWJsZVN1bW1hcnkoZXZlbnQudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIHJvd3M9ezN9XG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIldoYXQgd2FzIHByb2R1Y2VkLCB3aGF0IGNoYW5nZWQsIGFuZCB0aGUgb3V0Y29tZVwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJyZXNpemUteVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cInRhc2stZWRpdC1kZWxpdmVyYWJsZS1jb250ZW50XCI+RGVsaXZlcmFibGUgZXZpZGVuY2U8L0xhYmVsPlxuICAgICAgICAgIDxUZXh0YXJlYVxuICAgICAgICAgICAgaWQ9XCJ0YXNrLWVkaXQtZGVsaXZlcmFibGUtY29udGVudFwiXG4gICAgICAgICAgICB2YWx1ZT17ZGVsaXZlcmFibGVDb250ZW50fVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0RGVsaXZlcmFibGVDb250ZW50KGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICByb3dzPXs3fVxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFdmlkZW5jZSwgc291cmNlIGxpbmtzLCB0ZXN0IG91dHB1dCwgYXJ0aWZhY3QgcGF0aHMsIHJpc2tzLCBhbmQgbGltaXRhdGlvbnNcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVzaXplLXkgZm9udC1tb25vIHRleHQteHNcIlxuICAgICAgICAgICAgYXJpYS1kZXNjcmliZWRieT17c2F2ZUVycm9yID8gXCJ0YXNrLWVkaXQtc2F2ZS1lcnJvclwiIDogdW5kZWZpbmVkfVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgIFN1bW1hcnksIGV2aWRlbmNlLCBhbmQgYSBjaGVja2VkIHJldmlldyBsaXN0IGFyZSByZXF1aXJlZCBiZWZvcmUgc3VibWlzc2lvbi5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxmaWVsZHNldCBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICA8bGVnZW5kIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mb3JlZ3JvdW5kXCI+UmV2aWV3IGNoZWNrbGlzdDwvbGVnZW5kPlxuICAgICAgICAgIHtyZXZpZXdJdGVtcy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXG4gICAgICAgICAgICA8bGFiZWxcbiAgICAgICAgICAgICAga2V5PXtgJHtpdGVtLmxhYmVsfS0ke2luZGV4fWB9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1tdXRlZC8yMCBweC0zIHB5LTIuNSB0ZXh0LXNtXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICBjaGVja2VkPXtpdGVtLmNoZWNrZWR9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT5cbiAgICAgICAgICAgICAgICAgIHNldFJldmlld0l0ZW1zKChjdXJyZW50KSA9PlxuICAgICAgICAgICAgICAgICAgICBjdXJyZW50Lm1hcCgoY2FuZGlkYXRlLCBjYW5kaWRhdGVJbmRleCkgPT5cbiAgICAgICAgICAgICAgICAgICAgICBjYW5kaWRhdGVJbmRleCA9PT0gaW5kZXhcbiAgICAgICAgICAgICAgICAgICAgICAgID8geyAuLi5jYW5kaWRhdGUsIGNoZWNrZWQ6IGV2ZW50LnRhcmdldC5jaGVja2VkIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDogY2FuZGlkYXRlXG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMC41IGgtNCB3LTRcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8c3Bhbj57aXRlbS5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2ZpZWxkc2V0PlxuXG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtMyBiZy1tdXRlZC8zMCBib3JkZXItYm9yZGVyLzgwXCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMC43cmVtXSB0ZXh0LW11dGVkLWZvcmVncm91bmQgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9ja1wiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmQvOTBcIj5UYXNrIElEOjwvc3Bhbj57XCIgXCJ9XG4gICAgICAgICAgICAgIDxjb2RlIGNsYXNzTmFtZT1cInRleHQtWzAuNjVyZW1dXCI+e3Rhc2suX2lkfTwvY29kZT5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZm9yZWdyb3VuZC85MFwiPkNyZWF0ZWQ6PC9zcGFuPntcIiBcIn1cbiAgICAgICAgICAgICAge25ldyBEYXRlKHRhc2suX2NyZWF0aW9uVGltZSkudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIHt0YXNrLmFjdHVhbENvc3QgPiAwICYmIChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2tcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmQvOTBcIj5BY3R1YWwgY29zdDo8L3NwYW4+ICRcbiAgICAgICAgICAgICAgICB7dGFzay5hY3R1YWxDb3N0LnRvRml4ZWQoMil9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L0NhcmQ+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL1Rhc2tFZGl0TW9kZS50c3gifQ==