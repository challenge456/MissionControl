import {
  Activity,
  BarChart3,
  Bot,
  BookOpen,
  Brain,
  Building2,
  CalendarDays,
  CheckCircle2,
  ClipboardList,
  Code2,
  Cog,
  FileSearch,
  FlaskConical,
  Gauge,
  GitBranch,
  Landmark,
  LayoutDashboard,
  ListChecks,
  MessageSquare,
  Orbit,
  Radar,
  Radio,
  Rocket,
  ScrollText,
  Shield,
  Sparkles,
  Target,
  Users,
  Waypoints,
  Workflow,
  Compass,
  Wrench
} from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
export const NAV_GROUPS = [
  {
    id: "operate",
    label: "Operate",
    icon: LayoutDashboard,
    items: [
      { view: "home", label: "Overview", icon: LayoutDashboard },
      { view: "goals", label: "Missions", icon: Target },
      { view: "tasks", label: "Tasks", icon: ListChecks },
      { view: "dag", label: "Task Graph", icon: GitBranch },
      { view: "calendar", label: "Calendar", icon: CalendarDays },
      { view: "ops-schedule", label: "Schedule", icon: ClipboardList },
      { view: "audit", label: "Audit", icon: ScrollText }
    ]
  },
  {
    id: "control",
    label: "Control",
    icon: Orbit,
    items: [
      { view: "control-portfolio", label: "Portfolio", icon: Target },
      { view: "control-work-orders", label: "Work Orders", icon: ClipboardList },
      { view: "control-fleet", label: "Fleet", icon: Bot },
      { view: "control-approvals", label: "Approvals", icon: CheckCircle2 }
    ]
  },
  {
    id: "harness",
    label: "Harness",
    icon: GitBranch,
    items: [
      { view: "harness-patterns", label: "AI Patterns", icon: Brain },
      { view: "harness-architect", label: "Architect Mode", icon: Compass },
      { view: "harness-software-factory", label: "Software Factory", icon: Workflow },
      { view: "harness-workshop", label: "Workshop", icon: BookOpen },
      { view: "harness-health", label: "Factory Health", icon: Gauge },
      { view: "harness-agent-fleet", label: "Agent Fleet", icon: Bot },
      { view: "harness-automations", label: "Automations", icon: Sparkles },
      { view: "harness-loops", label: "Loop Engineering", icon: GitBranch },
      { view: "harness-control-plane", label: "Control Plane", icon: Waypoints },
      { view: "harness-work-ledger", label: "Work Ledger", icon: ClipboardList },
      { view: "harness-team-pulse", label: "Team Pulse", icon: Radio },
      { view: "harness-code-review-wizard", label: "Code Review Setup", icon: CheckCircle2 },
      { view: "harness-change-review", label: "Change Review", icon: FileSearch },
      { view: "harness-verifiers", label: "Verifiers", icon: Shield },
      { view: "harness-change-risk", label: "Change Risk", icon: Shield },
      { view: "harness-launch", label: "Launch", icon: Rocket },
      { view: "harness-meta-loop", label: "Meta Loop", icon: Sparkles },
      { view: "harness-maintenance", label: "Maintenance", icon: CalendarDays },
      { view: "harness-builder", label: "Factory Builder", icon: Wrench }
    ]
  },
  {
    id: "factory",
    label: "Factory",
    icon: Wrench,
    items: [
      { view: "code", label: "Pipelines", icon: GitBranch },
      { view: "codegen", label: "CodeGen", icon: Code2 },
      { view: "recorder", label: "Recorder", icon: Activity },
      { view: "test-generation", label: "Test Generation", icon: FlaskConical },
      { view: "api-import", label: "API Import", icon: FileSearch },
      { view: "execution", label: "Execution", icon: CheckCircle2 },
      { view: "flaky-steps", label: "Flaky Steps", icon: Activity },
      { view: "hybrid-workflows", label: "Hybrid Workflows", icon: GitBranch },
      { view: "gherkin", label: "Gherkin Studio", icon: ScrollText },
      { view: "schedule", label: "Run Schedule", icon: CalendarDays },
      { view: "pipeline", label: "Build Pipeline", icon: Cog },
      { view: "factory", label: "Factory Board", icon: Wrench }
    ]
  },
  {
    id: "intelligence",
    label: "Intelligence",
    icon: Brain,
    items: [
      { view: "agents", label: "Agents", icon: Bot },
      { view: "atc", label: "ATC Board", icon: Radar },
      { view: "directory", label: "Templates", icon: BookOpen },
      { view: "identity", label: "Identities", icon: Users },
      { view: "skills", label: "Discover skills", icon: Sparkles },
      { view: "registry-lifecycle", label: "Context CDL", icon: BookOpen },
      { view: "registry-evaluate", label: "Evaluate Skill", icon: FlaskConical },
      { view: "registry-inventory", label: "Skill Inventory", icon: ListChecks },
      { view: "registry-installations", label: "Installations", icon: ClipboardList },
      { view: "registry-runs", label: "Eval Runs", icon: FlaskConical },
      { view: "memory", label: "Memory", icon: Brain },
      { view: "docs", label: "Knowledge", icon: BookOpen },
      { view: "search", label: "Search", icon: FileSearch },
      { view: "hiring", label: "Hiring", icon: Users }
    ]
  },
  {
    id: "observe",
    label: "Observe",
    icon: Gauge,
    items: [
      { view: "telemetry", label: "Telemetry", icon: Activity },
      { view: "metrics", label: "Metrics", icon: BarChart3 },
      { view: "analytics", label: "Analytics", icon: BarChart3 },
      { view: "qc-dashboard", label: "QC Dashboard", icon: Gauge },
      { view: "qc-runs", label: "QC Runs", icon: FlaskConical },
      { view: "qc-findings", label: "QC Findings", icon: FileSearch },
      { view: "qc-metrics", label: "QC Metrics", icon: BarChart3 },
      { view: "qc-environments", label: "QC Environments", icon: Landmark },
      { view: "radar", label: "Radar", icon: Radar },
      { view: "system", label: "Database", icon: Cog }
    ]
  },
  {
    id: "platform",
    label: "Platform",
    icon: Target,
    items: [
      { view: "command-center", label: "Command Center", icon: LayoutDashboard },
      { view: "missions", label: "Missions", icon: Target },
      { view: "trace-inspector", label: "Trace Inspector", icon: GitBranch },
      { view: "effectiveness", label: "AI Effectiveness", icon: Gauge },
      { view: "factory-health", label: "Legacy Factory Health", icon: CheckCircle2 },
      { view: "readiness", label: "Readiness", icon: Landmark },
      { view: "friction", label: "Friction", icon: Activity },
      { view: "agent-catalog", label: "Agent Catalog", icon: Bot },
      { view: "dossier", label: "Dossiers", icon: ScrollText },
      { view: "recommendations", label: "Recommendations", icon: Sparkles }
    ]
  },
  {
    id: "govern",
    label: "Govern",
    icon: Shield,
    items: [
      { view: "policies", label: "Policies", icon: Shield },
      { view: "deployments", label: "Deployments", icon: GitBranch },
      { view: "qc-rulesets", label: "QC Rulesets", icon: ListChecks },
      { view: "gateway", label: "Gateway", icon: Cog },
      { view: "schedules", label: "Agent Schedules", icon: CalendarDays },
      { view: "design-system", label: "Design DNA", icon: Sparkles }
    ]
  },
  {
    id: "workspace",
    label: "Workspace",
    icon: Building2,
    items: [
      { view: "chat", label: "Chat", icon: MessageSquare },
      { view: "live-chat", label: "Live Chat", icon: MessageSquare },
      { view: "command", label: "Command", icon: Cog }
    ]
  },
  {
    id: "labs",
    label: "Labs",
    icon: FlaskConical,
    items: [
      { view: "council", label: "Council", icon: Users },
      { view: "content-pipeline", label: "Content", icon: ScrollText },
      { view: "captures", label: "Captures", icon: FileSearch },
      { view: "projects", label: "Projects", icon: Building2 },
      { view: "telegraph", label: "Telegraph", icon: MessageSquare },
      { view: "meetings", label: "Meetings", icon: CalendarDays },
      { view: "voice", label: "Voice", icon: Activity },
      { view: "crm", label: "CRM", icon: Users },
      { view: "people", label: "People", icon: Users },
      { view: "team", label: "Team", icon: Users },
      { view: "org", label: "Org Chart", icon: Building2 },
      { view: "office", label: "Office", icon: Building2 },
      { view: "live-office", label: "Live Office", icon: Building2 },
      { view: "feedback", label: "Feedback", icon: MessageSquare }
    ]
  }
];
export function groupForView(view) {
  return NAV_GROUPS.find((g) => g.items.some((i) => i.view === view));
}
export function itemForView(view) {
  for (const group of NAV_GROUPS) {
    const item = group.items.find((i) => i.view === view);
    if (item) return item;
  }
  return void 0;
}
export function allNavViews() {
  return NAV_GROUPS.flatMap((g) => g.items.map((i) => i.view));
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5hdkNvbmZpZy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IEx1Y2lkZUljb24gfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQge1xuICBBY3Rpdml0eSxcbiAgQmFyQ2hhcnQzLFxuICBCb3QsXG4gIEJvb2tPcGVuLFxuICBCcmFpbixcbiAgQnVpbGRpbmcyLFxuICBDYWxlbmRhckRheXMsXG4gIENoZWNrQ2lyY2xlMixcbiAgQ2xpcGJvYXJkTGlzdCxcbiAgQ29kZTIsXG4gIENvZyxcbiAgRmlsZVNlYXJjaCxcbiAgRmxhc2tDb25pY2FsLFxuICBHYXVnZSxcbiAgR2l0QnJhbmNoLFxuICBMYW5kbWFyayxcbiAgTGF5b3V0RGFzaGJvYXJkLFxuICBMaXN0Q2hlY2tzLFxuICBNZXNzYWdlU3F1YXJlLFxuICBPcmJpdCxcbiAgUmFkYXIsXG4gIFJhZGlvLFxuICBSb2NrZXQsXG4gIFNjcm9sbFRleHQsXG4gIFNoaWVsZCxcbiAgU3BhcmtsZXMsXG4gIFRhcmdldCxcbiAgVXNlcnMsXG4gIFdheXBvaW50cyxcbiAgV29ya2Zsb3csXG4gIENvbXBhc3MsXG4gIFdyZW5jaCxcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHR5cGUgeyBNYWluVmlldyB9IGZyb20gXCIuLi9Ub3BOYXZcIjtcblxuZXhwb3J0IGludGVyZmFjZSBOYXZJdGVtIHtcbiAgdmlldzogTWFpblZpZXc7XG4gIGxhYmVsOiBzdHJpbmc7XG4gIGljb246IEx1Y2lkZUljb247XG4gIC8qKiBPcHRpb25hbCBjb3VudCBiYWRnZSAod2FrdS1hZ2VudCBuYXYgcGF0dGVybikgKi9cbiAgY291bnQ/OiBudW1iZXI7XG4gIC8qKiBTY29wZSBvciBtYXR1cml0eSBsYWJlbCBhcHBsaWVkIGJ5IHRoZSByb3V0ZSBjYXBhYmlsaXR5IHJlZ2lzdHJ5LiAqL1xuICBiYWRnZT86IFwiR2xvYmFsXCIgfCBcIlByZXZpZXdcIiB8IFwiRGVtb1wiO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIE5hdkdyb3VwIHtcbiAgaWQ6IHN0cmluZztcbiAgbGFiZWw6IHN0cmluZztcbiAgaWNvbjogTHVjaWRlSWNvbjtcbiAgaXRlbXM6IE5hdkl0ZW1bXTtcbn1cblxuLyoqXG4gKiBTb2Z0d2FyZSBGYWN0b3J5IGluZm9ybWF0aW9uIGFyY2hpdGVjdHVyZSAodWkuc2hlbGwudjIpLlxuICogRml2ZSBwcmltYXJ5IGRvbWFpbnMgcGx1cyBhIHNlY29uZGFyeSBXb3Jrc3BhY2UgZ3JvdXAgc28gZXZlcnkgZXhpc3RpbmdcbiAqIHZpZXcgc3RheXMgcmVhY2hhYmxlLiBGYWN0b3J5LXNwZWNpZmljIHBhZ2VzIChXb3JrIE9yZGVycywgUmVwb3NpdG9yaWVzLFxuICogUHVsbCBSZXF1ZXN0cywgUmVnaXN0cnkpIGxhbmQgaW4gbGF0ZXIgUFJzIGFuZCBzbG90IGludG8gdGhlc2UgZ3JvdXBzLlxuICovXG5leHBvcnQgY29uc3QgTkFWX0dST1VQUzogTmF2R3JvdXBbXSA9IFtcbiAge1xuICAgIGlkOiBcIm9wZXJhdGVcIixcbiAgICBsYWJlbDogXCJPcGVyYXRlXCIsXG4gICAgaWNvbjogTGF5b3V0RGFzaGJvYXJkLFxuICAgIGl0ZW1zOiBbXG4gICAgICB7IHZpZXc6IFwiaG9tZVwiLCBsYWJlbDogXCJPdmVydmlld1wiLCBpY29uOiBMYXlvdXREYXNoYm9hcmQgfSxcbiAgICAgIHsgdmlldzogXCJnb2Fsc1wiLCBsYWJlbDogXCJNaXNzaW9uc1wiLCBpY29uOiBUYXJnZXQgfSxcbiAgICAgIHsgdmlldzogXCJ0YXNrc1wiLCBsYWJlbDogXCJUYXNrc1wiLCBpY29uOiBMaXN0Q2hlY2tzIH0sXG4gICAgICB7IHZpZXc6IFwiZGFnXCIsIGxhYmVsOiBcIlRhc2sgR3JhcGhcIiwgaWNvbjogR2l0QnJhbmNoIH0sXG4gICAgICB7IHZpZXc6IFwiY2FsZW5kYXJcIiwgbGFiZWw6IFwiQ2FsZW5kYXJcIiwgaWNvbjogQ2FsZW5kYXJEYXlzIH0sXG4gICAgICB7IHZpZXc6IFwib3BzLXNjaGVkdWxlXCIsIGxhYmVsOiBcIlNjaGVkdWxlXCIsIGljb246IENsaXBib2FyZExpc3QgfSxcbiAgICAgIHsgdmlldzogXCJhdWRpdFwiLCBsYWJlbDogXCJBdWRpdFwiLCBpY29uOiBTY3JvbGxUZXh0IH0sXG4gICAgXSxcbiAgfSxcbiAge1xuICAgIGlkOiBcImNvbnRyb2xcIixcbiAgICBsYWJlbDogXCJDb250cm9sXCIsXG4gICAgaWNvbjogT3JiaXQsXG4gICAgaXRlbXM6IFtcbiAgICAgIHsgdmlldzogXCJjb250cm9sLXBvcnRmb2xpb1wiLCBsYWJlbDogXCJQb3J0Zm9saW9cIiwgaWNvbjogVGFyZ2V0IH0sXG4gICAgICB7IHZpZXc6IFwiY29udHJvbC13b3JrLW9yZGVyc1wiLCBsYWJlbDogXCJXb3JrIE9yZGVyc1wiLCBpY29uOiBDbGlwYm9hcmRMaXN0IH0sXG4gICAgICB7IHZpZXc6IFwiY29udHJvbC1mbGVldFwiLCBsYWJlbDogXCJGbGVldFwiLCBpY29uOiBCb3QgfSxcbiAgICAgIHsgdmlldzogXCJjb250cm9sLWFwcHJvdmFsc1wiLCBsYWJlbDogXCJBcHByb3ZhbHNcIiwgaWNvbjogQ2hlY2tDaXJjbGUyIH0sXG4gICAgXSxcbiAgfSxcbiAge1xuICAgIGlkOiBcImhhcm5lc3NcIixcbiAgICBsYWJlbDogXCJIYXJuZXNzXCIsXG4gICAgaWNvbjogR2l0QnJhbmNoLFxuICAgIGl0ZW1zOiBbXG4gICAgICB7IHZpZXc6IFwiaGFybmVzcy1wYXR0ZXJuc1wiLCBsYWJlbDogXCJBSSBQYXR0ZXJuc1wiLCBpY29uOiBCcmFpbiB9LFxuICAgICAgeyB2aWV3OiBcImhhcm5lc3MtYXJjaGl0ZWN0XCIsIGxhYmVsOiBcIkFyY2hpdGVjdCBNb2RlXCIsIGljb246IENvbXBhc3MgfSxcbiAgICAgIHsgdmlldzogXCJoYXJuZXNzLXNvZnR3YXJlLWZhY3RvcnlcIiwgbGFiZWw6IFwiU29mdHdhcmUgRmFjdG9yeVwiLCBpY29uOiBXb3JrZmxvdyB9LFxuICAgICAgeyB2aWV3OiBcImhhcm5lc3Mtd29ya3Nob3BcIiwgbGFiZWw6IFwiV29ya3Nob3BcIiwgaWNvbjogQm9va09wZW4gfSxcbiAgICAgIHsgdmlldzogXCJoYXJuZXNzLWhlYWx0aFwiLCBsYWJlbDogXCJGYWN0b3J5IEhlYWx0aFwiLCBpY29uOiBHYXVnZSB9LFxuICAgICAgeyB2aWV3OiBcImhhcm5lc3MtYWdlbnQtZmxlZXRcIiwgbGFiZWw6IFwiQWdlbnQgRmxlZXRcIiwgaWNvbjogQm90IH0sXG4gICAgICB7IHZpZXc6IFwiaGFybmVzcy1hdXRvbWF0aW9uc1wiLCBsYWJlbDogXCJBdXRvbWF0aW9uc1wiLCBpY29uOiBTcGFya2xlcyB9LFxuICAgICAgeyB2aWV3OiBcImhhcm5lc3MtbG9vcHNcIiwgbGFiZWw6IFwiTG9vcCBFbmdpbmVlcmluZ1wiLCBpY29uOiBHaXRCcmFuY2ggfSxcbiAgICAgIHsgdmlldzogXCJoYXJuZXNzLWNvbnRyb2wtcGxhbmVcIiwgbGFiZWw6IFwiQ29udHJvbCBQbGFuZVwiLCBpY29uOiBXYXlwb2ludHMgfSxcbiAgICAgIHsgdmlldzogXCJoYXJuZXNzLXdvcmstbGVkZ2VyXCIsIGxhYmVsOiBcIldvcmsgTGVkZ2VyXCIsIGljb246IENsaXBib2FyZExpc3QgfSxcbiAgICAgIHsgdmlldzogXCJoYXJuZXNzLXRlYW0tcHVsc2VcIiwgbGFiZWw6IFwiVGVhbSBQdWxzZVwiLCBpY29uOiBSYWRpbyB9LFxuICAgICAgeyB2aWV3OiBcImhhcm5lc3MtY29kZS1yZXZpZXctd2l6YXJkXCIsIGxhYmVsOiBcIkNvZGUgUmV2aWV3IFNldHVwXCIsIGljb246IENoZWNrQ2lyY2xlMiB9LFxuICAgICAgeyB2aWV3OiBcImhhcm5lc3MtY2hhbmdlLXJldmlld1wiLCBsYWJlbDogXCJDaGFuZ2UgUmV2aWV3XCIsIGljb246IEZpbGVTZWFyY2ggfSxcbiAgICAgIHsgdmlldzogXCJoYXJuZXNzLXZlcmlmaWVyc1wiLCBsYWJlbDogXCJWZXJpZmllcnNcIiwgaWNvbjogU2hpZWxkIH0sXG4gICAgICB7IHZpZXc6IFwiaGFybmVzcy1jaGFuZ2Utcmlza1wiLCBsYWJlbDogXCJDaGFuZ2UgUmlza1wiLCBpY29uOiBTaGllbGQgfSxcbiAgICAgIHsgdmlldzogXCJoYXJuZXNzLWxhdW5jaFwiLCBsYWJlbDogXCJMYXVuY2hcIiwgaWNvbjogUm9ja2V0IH0sXG4gICAgICB7IHZpZXc6IFwiaGFybmVzcy1tZXRhLWxvb3BcIiwgbGFiZWw6IFwiTWV0YSBMb29wXCIsIGljb246IFNwYXJrbGVzIH0sXG4gICAgICB7IHZpZXc6IFwiaGFybmVzcy1tYWludGVuYW5jZVwiLCBsYWJlbDogXCJNYWludGVuYW5jZVwiLCBpY29uOiBDYWxlbmRhckRheXMgfSxcbiAgICAgIHsgdmlldzogXCJoYXJuZXNzLWJ1aWxkZXJcIiwgbGFiZWw6IFwiRmFjdG9yeSBCdWlsZGVyXCIsIGljb246IFdyZW5jaCB9LFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBpZDogXCJmYWN0b3J5XCIsXG4gICAgbGFiZWw6IFwiRmFjdG9yeVwiLFxuICAgIGljb246IFdyZW5jaCxcbiAgICBpdGVtczogW1xuICAgICAgeyB2aWV3OiBcImNvZGVcIiwgbGFiZWw6IFwiUGlwZWxpbmVzXCIsIGljb246IEdpdEJyYW5jaCB9LFxuICAgICAgeyB2aWV3OiBcImNvZGVnZW5cIiwgbGFiZWw6IFwiQ29kZUdlblwiLCBpY29uOiBDb2RlMiB9LFxuICAgICAgeyB2aWV3OiBcInJlY29yZGVyXCIsIGxhYmVsOiBcIlJlY29yZGVyXCIsIGljb246IEFjdGl2aXR5IH0sXG4gICAgICB7IHZpZXc6IFwidGVzdC1nZW5lcmF0aW9uXCIsIGxhYmVsOiBcIlRlc3QgR2VuZXJhdGlvblwiLCBpY29uOiBGbGFza0NvbmljYWwgfSxcbiAgICAgIHsgdmlldzogXCJhcGktaW1wb3J0XCIsIGxhYmVsOiBcIkFQSSBJbXBvcnRcIiwgaWNvbjogRmlsZVNlYXJjaCB9LFxuICAgICAgeyB2aWV3OiBcImV4ZWN1dGlvblwiLCBsYWJlbDogXCJFeGVjdXRpb25cIiwgaWNvbjogQ2hlY2tDaXJjbGUyIH0sXG4gICAgICB7IHZpZXc6IFwiZmxha3ktc3RlcHNcIiwgbGFiZWw6IFwiRmxha3kgU3RlcHNcIiwgaWNvbjogQWN0aXZpdHkgfSxcbiAgICAgIHsgdmlldzogXCJoeWJyaWQtd29ya2Zsb3dzXCIsIGxhYmVsOiBcIkh5YnJpZCBXb3JrZmxvd3NcIiwgaWNvbjogR2l0QnJhbmNoIH0sXG4gICAgICB7IHZpZXc6IFwiZ2hlcmtpblwiLCBsYWJlbDogXCJHaGVya2luIFN0dWRpb1wiLCBpY29uOiBTY3JvbGxUZXh0IH0sXG4gICAgICB7IHZpZXc6IFwic2NoZWR1bGVcIiwgbGFiZWw6IFwiUnVuIFNjaGVkdWxlXCIsIGljb246IENhbGVuZGFyRGF5cyB9LFxuICAgICAgeyB2aWV3OiBcInBpcGVsaW5lXCIsIGxhYmVsOiBcIkJ1aWxkIFBpcGVsaW5lXCIsIGljb246IENvZyB9LFxuICAgICAgeyB2aWV3OiBcImZhY3RvcnlcIiwgbGFiZWw6IFwiRmFjdG9yeSBCb2FyZFwiLCBpY29uOiBXcmVuY2ggfSxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgaWQ6IFwiaW50ZWxsaWdlbmNlXCIsXG4gICAgbGFiZWw6IFwiSW50ZWxsaWdlbmNlXCIsXG4gICAgaWNvbjogQnJhaW4sXG4gICAgaXRlbXM6IFtcbiAgICAgIHsgdmlldzogXCJhZ2VudHNcIiwgbGFiZWw6IFwiQWdlbnRzXCIsIGljb246IEJvdCB9LFxuICAgICAgeyB2aWV3OiBcImF0Y1wiLCBsYWJlbDogXCJBVEMgQm9hcmRcIiwgaWNvbjogUmFkYXIgfSxcbiAgICAgIHsgdmlldzogXCJkaXJlY3RvcnlcIiwgbGFiZWw6IFwiVGVtcGxhdGVzXCIsIGljb246IEJvb2tPcGVuIH0sXG4gICAgICB7IHZpZXc6IFwiaWRlbnRpdHlcIiwgbGFiZWw6IFwiSWRlbnRpdGllc1wiLCBpY29uOiBVc2VycyB9LFxuICAgICAgeyB2aWV3OiBcInNraWxsc1wiLCBsYWJlbDogXCJEaXNjb3ZlciBza2lsbHNcIiwgaWNvbjogU3BhcmtsZXMgfSxcbiAgICAgIHsgdmlldzogXCJyZWdpc3RyeS1saWZlY3ljbGVcIiwgbGFiZWw6IFwiQ29udGV4dCBDRExcIiwgaWNvbjogQm9va09wZW4gfSxcbiAgICAgIHsgdmlldzogXCJyZWdpc3RyeS1ldmFsdWF0ZVwiLCBsYWJlbDogXCJFdmFsdWF0ZSBTa2lsbFwiLCBpY29uOiBGbGFza0NvbmljYWwgfSxcbiAgICAgIHsgdmlldzogXCJyZWdpc3RyeS1pbnZlbnRvcnlcIiwgbGFiZWw6IFwiU2tpbGwgSW52ZW50b3J5XCIsIGljb246IExpc3RDaGVja3MgfSxcbiAgICAgIHsgdmlldzogXCJyZWdpc3RyeS1pbnN0YWxsYXRpb25zXCIsIGxhYmVsOiBcIkluc3RhbGxhdGlvbnNcIiwgaWNvbjogQ2xpcGJvYXJkTGlzdCB9LFxuICAgICAgeyB2aWV3OiBcInJlZ2lzdHJ5LXJ1bnNcIiwgbGFiZWw6IFwiRXZhbCBSdW5zXCIsIGljb246IEZsYXNrQ29uaWNhbCB9LFxuICAgICAgeyB2aWV3OiBcIm1lbW9yeVwiLCBsYWJlbDogXCJNZW1vcnlcIiwgaWNvbjogQnJhaW4gfSxcbiAgICAgIHsgdmlldzogXCJkb2NzXCIsIGxhYmVsOiBcIktub3dsZWRnZVwiLCBpY29uOiBCb29rT3BlbiB9LFxuICAgICAgeyB2aWV3OiBcInNlYXJjaFwiLCBsYWJlbDogXCJTZWFyY2hcIiwgaWNvbjogRmlsZVNlYXJjaCB9LFxuICAgICAgeyB2aWV3OiBcImhpcmluZ1wiLCBsYWJlbDogXCJIaXJpbmdcIiwgaWNvbjogVXNlcnMgfSxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgaWQ6IFwib2JzZXJ2ZVwiLFxuICAgIGxhYmVsOiBcIk9ic2VydmVcIixcbiAgICBpY29uOiBHYXVnZSxcbiAgICBpdGVtczogW1xuICAgICAgeyB2aWV3OiBcInRlbGVtZXRyeVwiLCBsYWJlbDogXCJUZWxlbWV0cnlcIiwgaWNvbjogQWN0aXZpdHkgfSxcbiAgICAgIHsgdmlldzogXCJtZXRyaWNzXCIsIGxhYmVsOiBcIk1ldHJpY3NcIiwgaWNvbjogQmFyQ2hhcnQzIH0sXG4gICAgICB7IHZpZXc6IFwiYW5hbHl0aWNzXCIsIGxhYmVsOiBcIkFuYWx5dGljc1wiLCBpY29uOiBCYXJDaGFydDMgfSxcbiAgICAgIHsgdmlldzogXCJxYy1kYXNoYm9hcmRcIiwgbGFiZWw6IFwiUUMgRGFzaGJvYXJkXCIsIGljb246IEdhdWdlIH0sXG4gICAgICB7IHZpZXc6IFwicWMtcnVuc1wiLCBsYWJlbDogXCJRQyBSdW5zXCIsIGljb246IEZsYXNrQ29uaWNhbCB9LFxuICAgICAgeyB2aWV3OiBcInFjLWZpbmRpbmdzXCIsIGxhYmVsOiBcIlFDIEZpbmRpbmdzXCIsIGljb246IEZpbGVTZWFyY2ggfSxcbiAgICAgIHsgdmlldzogXCJxYy1tZXRyaWNzXCIsIGxhYmVsOiBcIlFDIE1ldHJpY3NcIiwgaWNvbjogQmFyQ2hhcnQzIH0sXG4gICAgICB7IHZpZXc6IFwicWMtZW52aXJvbm1lbnRzXCIsIGxhYmVsOiBcIlFDIEVudmlyb25tZW50c1wiLCBpY29uOiBMYW5kbWFyayB9LFxuICAgICAgeyB2aWV3OiBcInJhZGFyXCIsIGxhYmVsOiBcIlJhZGFyXCIsIGljb246IFJhZGFyIH0sXG4gICAgICB7IHZpZXc6IFwic3lzdGVtXCIsIGxhYmVsOiBcIkRhdGFiYXNlXCIsIGljb246IENvZyB9LFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBpZDogXCJwbGF0Zm9ybVwiLFxuICAgIGxhYmVsOiBcIlBsYXRmb3JtXCIsXG4gICAgaWNvbjogVGFyZ2V0LFxuICAgIGl0ZW1zOiBbXG4gICAgICB7IHZpZXc6IFwiY29tbWFuZC1jZW50ZXJcIiwgbGFiZWw6IFwiQ29tbWFuZCBDZW50ZXJcIiwgaWNvbjogTGF5b3V0RGFzaGJvYXJkIH0sXG4gICAgICB7IHZpZXc6IFwibWlzc2lvbnNcIiwgbGFiZWw6IFwiTWlzc2lvbnNcIiwgaWNvbjogVGFyZ2V0IH0sXG4gICAgICB7IHZpZXc6IFwidHJhY2UtaW5zcGVjdG9yXCIsIGxhYmVsOiBcIlRyYWNlIEluc3BlY3RvclwiLCBpY29uOiBHaXRCcmFuY2ggfSxcbiAgICAgIHsgdmlldzogXCJlZmZlY3RpdmVuZXNzXCIsIGxhYmVsOiBcIkFJIEVmZmVjdGl2ZW5lc3NcIiwgaWNvbjogR2F1Z2UgfSxcbiAgICAgIHsgdmlldzogXCJmYWN0b3J5LWhlYWx0aFwiLCBsYWJlbDogXCJMZWdhY3kgRmFjdG9yeSBIZWFsdGhcIiwgaWNvbjogQ2hlY2tDaXJjbGUyIH0sXG4gICAgICB7IHZpZXc6IFwicmVhZGluZXNzXCIsIGxhYmVsOiBcIlJlYWRpbmVzc1wiLCBpY29uOiBMYW5kbWFyayB9LFxuICAgICAgeyB2aWV3OiBcImZyaWN0aW9uXCIsIGxhYmVsOiBcIkZyaWN0aW9uXCIsIGljb246IEFjdGl2aXR5IH0sXG4gICAgICB7IHZpZXc6IFwiYWdlbnQtY2F0YWxvZ1wiLCBsYWJlbDogXCJBZ2VudCBDYXRhbG9nXCIsIGljb246IEJvdCB9LFxuICAgICAgeyB2aWV3OiBcImRvc3NpZXJcIiwgbGFiZWw6IFwiRG9zc2llcnNcIiwgaWNvbjogU2Nyb2xsVGV4dCB9LFxuICAgICAgeyB2aWV3OiBcInJlY29tbWVuZGF0aW9uc1wiLCBsYWJlbDogXCJSZWNvbW1lbmRhdGlvbnNcIiwgaWNvbjogU3BhcmtsZXMgfSxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgaWQ6IFwiZ292ZXJuXCIsXG4gICAgbGFiZWw6IFwiR292ZXJuXCIsXG4gICAgaWNvbjogU2hpZWxkLFxuICAgIGl0ZW1zOiBbXG4gICAgICB7IHZpZXc6IFwicG9saWNpZXNcIiwgbGFiZWw6IFwiUG9saWNpZXNcIiwgaWNvbjogU2hpZWxkIH0sXG4gICAgICB7IHZpZXc6IFwiZGVwbG95bWVudHNcIiwgbGFiZWw6IFwiRGVwbG95bWVudHNcIiwgaWNvbjogR2l0QnJhbmNoIH0sXG4gICAgICB7IHZpZXc6IFwicWMtcnVsZXNldHNcIiwgbGFiZWw6IFwiUUMgUnVsZXNldHNcIiwgaWNvbjogTGlzdENoZWNrcyB9LFxuICAgICAgeyB2aWV3OiBcImdhdGV3YXlcIiwgbGFiZWw6IFwiR2F0ZXdheVwiLCBpY29uOiBDb2cgfSxcbiAgICAgIHsgdmlldzogXCJzY2hlZHVsZXNcIiwgbGFiZWw6IFwiQWdlbnQgU2NoZWR1bGVzXCIsIGljb246IENhbGVuZGFyRGF5cyB9LFxuICAgICAgeyB2aWV3OiBcImRlc2lnbi1zeXN0ZW1cIiwgbGFiZWw6IFwiRGVzaWduIEROQVwiLCBpY29uOiBTcGFya2xlcyB9LFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBpZDogXCJ3b3Jrc3BhY2VcIixcbiAgICBsYWJlbDogXCJXb3Jrc3BhY2VcIixcbiAgICBpY29uOiBCdWlsZGluZzIsXG4gICAgaXRlbXM6IFtcbiAgICAgIHsgdmlldzogXCJjaGF0XCIsIGxhYmVsOiBcIkNoYXRcIiwgaWNvbjogTWVzc2FnZVNxdWFyZSB9LFxuICAgICAgeyB2aWV3OiBcImxpdmUtY2hhdFwiLCBsYWJlbDogXCJMaXZlIENoYXRcIiwgaWNvbjogTWVzc2FnZVNxdWFyZSB9LFxuICAgICAgeyB2aWV3OiBcImNvbW1hbmRcIiwgbGFiZWw6IFwiQ29tbWFuZFwiLCBpY29uOiBDb2cgfSxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgaWQ6IFwibGFic1wiLFxuICAgIGxhYmVsOiBcIkxhYnNcIixcbiAgICBpY29uOiBGbGFza0NvbmljYWwsXG4gICAgaXRlbXM6IFtcbiAgICAgIHsgdmlldzogXCJjb3VuY2lsXCIsIGxhYmVsOiBcIkNvdW5jaWxcIiwgaWNvbjogVXNlcnMgfSxcbiAgICAgIHsgdmlldzogXCJjb250ZW50LXBpcGVsaW5lXCIsIGxhYmVsOiBcIkNvbnRlbnRcIiwgaWNvbjogU2Nyb2xsVGV4dCB9LFxuICAgICAgeyB2aWV3OiBcImNhcHR1cmVzXCIsIGxhYmVsOiBcIkNhcHR1cmVzXCIsIGljb246IEZpbGVTZWFyY2ggfSxcbiAgICAgIHsgdmlldzogXCJwcm9qZWN0c1wiLCBsYWJlbDogXCJQcm9qZWN0c1wiLCBpY29uOiBCdWlsZGluZzIgfSxcbiAgICAgIHsgdmlldzogXCJ0ZWxlZ3JhcGhcIiwgbGFiZWw6IFwiVGVsZWdyYXBoXCIsIGljb246IE1lc3NhZ2VTcXVhcmUgfSxcbiAgICAgIHsgdmlldzogXCJtZWV0aW5nc1wiLCBsYWJlbDogXCJNZWV0aW5nc1wiLCBpY29uOiBDYWxlbmRhckRheXMgfSxcbiAgICAgIHsgdmlldzogXCJ2b2ljZVwiLCBsYWJlbDogXCJWb2ljZVwiLCBpY29uOiBBY3Rpdml0eSB9LFxuICAgICAgeyB2aWV3OiBcImNybVwiLCBsYWJlbDogXCJDUk1cIiwgaWNvbjogVXNlcnMgfSxcbiAgICAgIHsgdmlldzogXCJwZW9wbGVcIiwgbGFiZWw6IFwiUGVvcGxlXCIsIGljb246IFVzZXJzIH0sXG4gICAgICB7IHZpZXc6IFwidGVhbVwiLCBsYWJlbDogXCJUZWFtXCIsIGljb246IFVzZXJzIH0sXG4gICAgICB7IHZpZXc6IFwib3JnXCIsIGxhYmVsOiBcIk9yZyBDaGFydFwiLCBpY29uOiBCdWlsZGluZzIgfSxcbiAgICAgIHsgdmlldzogXCJvZmZpY2VcIiwgbGFiZWw6IFwiT2ZmaWNlXCIsIGljb246IEJ1aWxkaW5nMiB9LFxuICAgICAgeyB2aWV3OiBcImxpdmUtb2ZmaWNlXCIsIGxhYmVsOiBcIkxpdmUgT2ZmaWNlXCIsIGljb246IEJ1aWxkaW5nMiB9LFxuICAgICAgeyB2aWV3OiBcImZlZWRiYWNrXCIsIGxhYmVsOiBcIkZlZWRiYWNrXCIsIGljb246IE1lc3NhZ2VTcXVhcmUgfSxcbiAgICBdLFxuICB9LFxuXTtcblxuZXhwb3J0IGZ1bmN0aW9uIGdyb3VwRm9yVmlldyh2aWV3OiBNYWluVmlldyk6IE5hdkdyb3VwIHwgdW5kZWZpbmVkIHtcbiAgcmV0dXJuIE5BVl9HUk9VUFMuZmluZCgoZykgPT4gZy5pdGVtcy5zb21lKChpKSA9PiBpLnZpZXcgPT09IHZpZXcpKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGl0ZW1Gb3JWaWV3KHZpZXc6IE1haW5WaWV3KTogTmF2SXRlbSB8IHVuZGVmaW5lZCB7XG4gIGZvciAoY29uc3QgZ3JvdXAgb2YgTkFWX0dST1VQUykge1xuICAgIGNvbnN0IGl0ZW0gPSBncm91cC5pdGVtcy5maW5kKChpKSA9PiBpLnZpZXcgPT09IHZpZXcpO1xuICAgIGlmIChpdGVtKSByZXR1cm4gaXRlbTtcbiAgfVxuICByZXR1cm4gdW5kZWZpbmVkO1xufVxuXG4vKiogRmxhdCBsaXN0IG9mIGFsbCB2aWV3cyByZWFjaGFibGUgZnJvbSB0aGUgdjIgbmF2aWdhdGlvbi4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhbGxOYXZWaWV3cygpOiBNYWluVmlld1tdIHtcbiAgcmV0dXJuIE5BVl9HUk9VUFMuZmxhdE1hcCgoZykgPT4gZy5pdGVtcy5tYXAoKGkpID0+IGkudmlldykpO1xufVxuIl0sIm1hcHBpbmdzIjoiQUFDQTtBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsT0FDSztBQTBCQSxhQUFNLGFBQXlCO0FBQUEsRUFDcEM7QUFBQSxJQUNFLElBQUk7QUFBQSxJQUNKLE9BQU87QUFBQSxJQUNQLE1BQU07QUFBQSxJQUNOLE9BQU87QUFBQSxNQUNMLEVBQUUsTUFBTSxRQUFRLE9BQU8sWUFBWSxNQUFNLGdCQUFnQjtBQUFBLE1BQ3pELEVBQUUsTUFBTSxTQUFTLE9BQU8sWUFBWSxNQUFNLE9BQU87QUFBQSxNQUNqRCxFQUFFLE1BQU0sU0FBUyxPQUFPLFNBQVMsTUFBTSxXQUFXO0FBQUEsTUFDbEQsRUFBRSxNQUFNLE9BQU8sT0FBTyxjQUFjLE1BQU0sVUFBVTtBQUFBLE1BQ3BELEVBQUUsTUFBTSxZQUFZLE9BQU8sWUFBWSxNQUFNLGFBQWE7QUFBQSxNQUMxRCxFQUFFLE1BQU0sZ0JBQWdCLE9BQU8sWUFBWSxNQUFNLGNBQWM7QUFBQSxNQUMvRCxFQUFFLE1BQU0sU0FBUyxPQUFPLFNBQVMsTUFBTSxXQUFXO0FBQUEsSUFDcEQ7QUFBQSxFQUNGO0FBQUEsRUFDQTtBQUFBLElBQ0UsSUFBSTtBQUFBLElBQ0osT0FBTztBQUFBLElBQ1AsTUFBTTtBQUFBLElBQ04sT0FBTztBQUFBLE1BQ0wsRUFBRSxNQUFNLHFCQUFxQixPQUFPLGFBQWEsTUFBTSxPQUFPO0FBQUEsTUFDOUQsRUFBRSxNQUFNLHVCQUF1QixPQUFPLGVBQWUsTUFBTSxjQUFjO0FBQUEsTUFDekUsRUFBRSxNQUFNLGlCQUFpQixPQUFPLFNBQVMsTUFBTSxJQUFJO0FBQUEsTUFDbkQsRUFBRSxNQUFNLHFCQUFxQixPQUFPLGFBQWEsTUFBTSxhQUFhO0FBQUEsSUFDdEU7QUFBQSxFQUNGO0FBQUEsRUFDQTtBQUFBLElBQ0UsSUFBSTtBQUFBLElBQ0osT0FBTztBQUFBLElBQ1AsTUFBTTtBQUFBLElBQ04sT0FBTztBQUFBLE1BQ0wsRUFBRSxNQUFNLG9CQUFvQixPQUFPLGVBQWUsTUFBTSxNQUFNO0FBQUEsTUFDOUQsRUFBRSxNQUFNLHFCQUFxQixPQUFPLGtCQUFrQixNQUFNLFFBQVE7QUFBQSxNQUNwRSxFQUFFLE1BQU0sNEJBQTRCLE9BQU8sb0JBQW9CLE1BQU0sU0FBUztBQUFBLE1BQzlFLEVBQUUsTUFBTSxvQkFBb0IsT0FBTyxZQUFZLE1BQU0sU0FBUztBQUFBLE1BQzlELEVBQUUsTUFBTSxrQkFBa0IsT0FBTyxrQkFBa0IsTUFBTSxNQUFNO0FBQUEsTUFDL0QsRUFBRSxNQUFNLHVCQUF1QixPQUFPLGVBQWUsTUFBTSxJQUFJO0FBQUEsTUFDL0QsRUFBRSxNQUFNLHVCQUF1QixPQUFPLGVBQWUsTUFBTSxTQUFTO0FBQUEsTUFDcEUsRUFBRSxNQUFNLGlCQUFpQixPQUFPLG9CQUFvQixNQUFNLFVBQVU7QUFBQSxNQUNwRSxFQUFFLE1BQU0seUJBQXlCLE9BQU8saUJBQWlCLE1BQU0sVUFBVTtBQUFBLE1BQ3pFLEVBQUUsTUFBTSx1QkFBdUIsT0FBTyxlQUFlLE1BQU0sY0FBYztBQUFBLE1BQ3pFLEVBQUUsTUFBTSxzQkFBc0IsT0FBTyxjQUFjLE1BQU0sTUFBTTtBQUFBLE1BQy9ELEVBQUUsTUFBTSw4QkFBOEIsT0FBTyxxQkFBcUIsTUFBTSxhQUFhO0FBQUEsTUFDckYsRUFBRSxNQUFNLHlCQUF5QixPQUFPLGlCQUFpQixNQUFNLFdBQVc7QUFBQSxNQUMxRSxFQUFFLE1BQU0scUJBQXFCLE9BQU8sYUFBYSxNQUFNLE9BQU87QUFBQSxNQUM5RCxFQUFFLE1BQU0sdUJBQXVCLE9BQU8sZUFBZSxNQUFNLE9BQU87QUFBQSxNQUNsRSxFQUFFLE1BQU0sa0JBQWtCLE9BQU8sVUFBVSxNQUFNLE9BQU87QUFBQSxNQUN4RCxFQUFFLE1BQU0scUJBQXFCLE9BQU8sYUFBYSxNQUFNLFNBQVM7QUFBQSxNQUNoRSxFQUFFLE1BQU0sdUJBQXVCLE9BQU8sZUFBZSxNQUFNLGFBQWE7QUFBQSxNQUN4RSxFQUFFLE1BQU0sbUJBQW1CLE9BQU8sbUJBQW1CLE1BQU0sT0FBTztBQUFBLElBQ3BFO0FBQUEsRUFDRjtBQUFBLEVBQ0E7QUFBQSxJQUNFLElBQUk7QUFBQSxJQUNKLE9BQU87QUFBQSxJQUNQLE1BQU07QUFBQSxJQUNOLE9BQU87QUFBQSxNQUNMLEVBQUUsTUFBTSxRQUFRLE9BQU8sYUFBYSxNQUFNLFVBQVU7QUFBQSxNQUNwRCxFQUFFLE1BQU0sV0FBVyxPQUFPLFdBQVcsTUFBTSxNQUFNO0FBQUEsTUFDakQsRUFBRSxNQUFNLFlBQVksT0FBTyxZQUFZLE1BQU0sU0FBUztBQUFBLE1BQ3RELEVBQUUsTUFBTSxtQkFBbUIsT0FBTyxtQkFBbUIsTUFBTSxhQUFhO0FBQUEsTUFDeEUsRUFBRSxNQUFNLGNBQWMsT0FBTyxjQUFjLE1BQU0sV0FBVztBQUFBLE1BQzVELEVBQUUsTUFBTSxhQUFhLE9BQU8sYUFBYSxNQUFNLGFBQWE7QUFBQSxNQUM1RCxFQUFFLE1BQU0sZUFBZSxPQUFPLGVBQWUsTUFBTSxTQUFTO0FBQUEsTUFDNUQsRUFBRSxNQUFNLG9CQUFvQixPQUFPLG9CQUFvQixNQUFNLFVBQVU7QUFBQSxNQUN2RSxFQUFFLE1BQU0sV0FBVyxPQUFPLGtCQUFrQixNQUFNLFdBQVc7QUFBQSxNQUM3RCxFQUFFLE1BQU0sWUFBWSxPQUFPLGdCQUFnQixNQUFNLGFBQWE7QUFBQSxNQUM5RCxFQUFFLE1BQU0sWUFBWSxPQUFPLGtCQUFrQixNQUFNLElBQUk7QUFBQSxNQUN2RCxFQUFFLE1BQU0sV0FBVyxPQUFPLGlCQUFpQixNQUFNLE9BQU87QUFBQSxJQUMxRDtBQUFBLEVBQ0Y7QUFBQSxFQUNBO0FBQUEsSUFDRSxJQUFJO0FBQUEsSUFDSixPQUFPO0FBQUEsSUFDUCxNQUFNO0FBQUEsSUFDTixPQUFPO0FBQUEsTUFDTCxFQUFFLE1BQU0sVUFBVSxPQUFPLFVBQVUsTUFBTSxJQUFJO0FBQUEsTUFDN0MsRUFBRSxNQUFNLE9BQU8sT0FBTyxhQUFhLE1BQU0sTUFBTTtBQUFBLE1BQy9DLEVBQUUsTUFBTSxhQUFhLE9BQU8sYUFBYSxNQUFNLFNBQVM7QUFBQSxNQUN4RCxFQUFFLE1BQU0sWUFBWSxPQUFPLGNBQWMsTUFBTSxNQUFNO0FBQUEsTUFDckQsRUFBRSxNQUFNLFVBQVUsT0FBTyxtQkFBbUIsTUFBTSxTQUFTO0FBQUEsTUFDM0QsRUFBRSxNQUFNLHNCQUFzQixPQUFPLGVBQWUsTUFBTSxTQUFTO0FBQUEsTUFDbkUsRUFBRSxNQUFNLHFCQUFxQixPQUFPLGtCQUFrQixNQUFNLGFBQWE7QUFBQSxNQUN6RSxFQUFFLE1BQU0sc0JBQXNCLE9BQU8sbUJBQW1CLE1BQU0sV0FBVztBQUFBLE1BQ3pFLEVBQUUsTUFBTSwwQkFBMEIsT0FBTyxpQkFBaUIsTUFBTSxjQUFjO0FBQUEsTUFDOUUsRUFBRSxNQUFNLGlCQUFpQixPQUFPLGFBQWEsTUFBTSxhQUFhO0FBQUEsTUFDaEUsRUFBRSxNQUFNLFVBQVUsT0FBTyxVQUFVLE1BQU0sTUFBTTtBQUFBLE1BQy9DLEVBQUUsTUFBTSxRQUFRLE9BQU8sYUFBYSxNQUFNLFNBQVM7QUFBQSxNQUNuRCxFQUFFLE1BQU0sVUFBVSxPQUFPLFVBQVUsTUFBTSxXQUFXO0FBQUEsTUFDcEQsRUFBRSxNQUFNLFVBQVUsT0FBTyxVQUFVLE1BQU0sTUFBTTtBQUFBLElBQ2pEO0FBQUEsRUFDRjtBQUFBLEVBQ0E7QUFBQSxJQUNFLElBQUk7QUFBQSxJQUNKLE9BQU87QUFBQSxJQUNQLE1BQU07QUFBQSxJQUNOLE9BQU87QUFBQSxNQUNMLEVBQUUsTUFBTSxhQUFhLE9BQU8sYUFBYSxNQUFNLFNBQVM7QUFBQSxNQUN4RCxFQUFFLE1BQU0sV0FBVyxPQUFPLFdBQVcsTUFBTSxVQUFVO0FBQUEsTUFDckQsRUFBRSxNQUFNLGFBQWEsT0FBTyxhQUFhLE1BQU0sVUFBVTtBQUFBLE1BQ3pELEVBQUUsTUFBTSxnQkFBZ0IsT0FBTyxnQkFBZ0IsTUFBTSxNQUFNO0FBQUEsTUFDM0QsRUFBRSxNQUFNLFdBQVcsT0FBTyxXQUFXLE1BQU0sYUFBYTtBQUFBLE1BQ3hELEVBQUUsTUFBTSxlQUFlLE9BQU8sZUFBZSxNQUFNLFdBQVc7QUFBQSxNQUM5RCxFQUFFLE1BQU0sY0FBYyxPQUFPLGNBQWMsTUFBTSxVQUFVO0FBQUEsTUFDM0QsRUFBRSxNQUFNLG1CQUFtQixPQUFPLG1CQUFtQixNQUFNLFNBQVM7QUFBQSxNQUNwRSxFQUFFLE1BQU0sU0FBUyxPQUFPLFNBQVMsTUFBTSxNQUFNO0FBQUEsTUFDN0MsRUFBRSxNQUFNLFVBQVUsT0FBTyxZQUFZLE1BQU0sSUFBSTtBQUFBLElBQ2pEO0FBQUEsRUFDRjtBQUFBLEVBQ0E7QUFBQSxJQUNFLElBQUk7QUFBQSxJQUNKLE9BQU87QUFBQSxJQUNQLE1BQU07QUFBQSxJQUNOLE9BQU87QUFBQSxNQUNMLEVBQUUsTUFBTSxrQkFBa0IsT0FBTyxrQkFBa0IsTUFBTSxnQkFBZ0I7QUFBQSxNQUN6RSxFQUFFLE1BQU0sWUFBWSxPQUFPLFlBQVksTUFBTSxPQUFPO0FBQUEsTUFDcEQsRUFBRSxNQUFNLG1CQUFtQixPQUFPLG1CQUFtQixNQUFNLFVBQVU7QUFBQSxNQUNyRSxFQUFFLE1BQU0saUJBQWlCLE9BQU8sb0JBQW9CLE1BQU0sTUFBTTtBQUFBLE1BQ2hFLEVBQUUsTUFBTSxrQkFBa0IsT0FBTyx5QkFBeUIsTUFBTSxhQUFhO0FBQUEsTUFDN0UsRUFBRSxNQUFNLGFBQWEsT0FBTyxhQUFhLE1BQU0sU0FBUztBQUFBLE1BQ3hELEVBQUUsTUFBTSxZQUFZLE9BQU8sWUFBWSxNQUFNLFNBQVM7QUFBQSxNQUN0RCxFQUFFLE1BQU0saUJBQWlCLE9BQU8saUJBQWlCLE1BQU0sSUFBSTtBQUFBLE1BQzNELEVBQUUsTUFBTSxXQUFXLE9BQU8sWUFBWSxNQUFNLFdBQVc7QUFBQSxNQUN2RCxFQUFFLE1BQU0sbUJBQW1CLE9BQU8sbUJBQW1CLE1BQU0sU0FBUztBQUFBLElBQ3RFO0FBQUEsRUFDRjtBQUFBLEVBQ0E7QUFBQSxJQUNFLElBQUk7QUFBQSxJQUNKLE9BQU87QUFBQSxJQUNQLE1BQU07QUFBQSxJQUNOLE9BQU87QUFBQSxNQUNMLEVBQUUsTUFBTSxZQUFZLE9BQU8sWUFBWSxNQUFNLE9BQU87QUFBQSxNQUNwRCxFQUFFLE1BQU0sZUFBZSxPQUFPLGVBQWUsTUFBTSxVQUFVO0FBQUEsTUFDN0QsRUFBRSxNQUFNLGVBQWUsT0FBTyxlQUFlLE1BQU0sV0FBVztBQUFBLE1BQzlELEVBQUUsTUFBTSxXQUFXLE9BQU8sV0FBVyxNQUFNLElBQUk7QUFBQSxNQUMvQyxFQUFFLE1BQU0sYUFBYSxPQUFPLG1CQUFtQixNQUFNLGFBQWE7QUFBQSxNQUNsRSxFQUFFLE1BQU0saUJBQWlCLE9BQU8sY0FBYyxNQUFNLFNBQVM7QUFBQSxJQUMvRDtBQUFBLEVBQ0Y7QUFBQSxFQUNBO0FBQUEsSUFDRSxJQUFJO0FBQUEsSUFDSixPQUFPO0FBQUEsSUFDUCxNQUFNO0FBQUEsSUFDTixPQUFPO0FBQUEsTUFDTCxFQUFFLE1BQU0sUUFBUSxPQUFPLFFBQVEsTUFBTSxjQUFjO0FBQUEsTUFDbkQsRUFBRSxNQUFNLGFBQWEsT0FBTyxhQUFhLE1BQU0sY0FBYztBQUFBLE1BQzdELEVBQUUsTUFBTSxXQUFXLE9BQU8sV0FBVyxNQUFNLElBQUk7QUFBQSxJQUNqRDtBQUFBLEVBQ0Y7QUFBQSxFQUNBO0FBQUEsSUFDRSxJQUFJO0FBQUEsSUFDSixPQUFPO0FBQUEsSUFDUCxNQUFNO0FBQUEsSUFDTixPQUFPO0FBQUEsTUFDTCxFQUFFLE1BQU0sV0FBVyxPQUFPLFdBQVcsTUFBTSxNQUFNO0FBQUEsTUFDakQsRUFBRSxNQUFNLG9CQUFvQixPQUFPLFdBQVcsTUFBTSxXQUFXO0FBQUEsTUFDL0QsRUFBRSxNQUFNLFlBQVksT0FBTyxZQUFZLE1BQU0sV0FBVztBQUFBLE1BQ3hELEVBQUUsTUFBTSxZQUFZLE9BQU8sWUFBWSxNQUFNLFVBQVU7QUFBQSxNQUN2RCxFQUFFLE1BQU0sYUFBYSxPQUFPLGFBQWEsTUFBTSxjQUFjO0FBQUEsTUFDN0QsRUFBRSxNQUFNLFlBQVksT0FBTyxZQUFZLE1BQU0sYUFBYTtBQUFBLE1BQzFELEVBQUUsTUFBTSxTQUFTLE9BQU8sU0FBUyxNQUFNLFNBQVM7QUFBQSxNQUNoRCxFQUFFLE1BQU0sT0FBTyxPQUFPLE9BQU8sTUFBTSxNQUFNO0FBQUEsTUFDekMsRUFBRSxNQUFNLFVBQVUsT0FBTyxVQUFVLE1BQU0sTUFBTTtBQUFBLE1BQy9DLEVBQUUsTUFBTSxRQUFRLE9BQU8sUUFBUSxNQUFNLE1BQU07QUFBQSxNQUMzQyxFQUFFLE1BQU0sT0FBTyxPQUFPLGFBQWEsTUFBTSxVQUFVO0FBQUEsTUFDbkQsRUFBRSxNQUFNLFVBQVUsT0FBTyxVQUFVLE1BQU0sVUFBVTtBQUFBLE1BQ25ELEVBQUUsTUFBTSxlQUFlLE9BQU8sZUFBZSxNQUFNLFVBQVU7QUFBQSxNQUM3RCxFQUFFLE1BQU0sWUFBWSxPQUFPLFlBQVksTUFBTSxjQUFjO0FBQUEsSUFDN0Q7QUFBQSxFQUNGO0FBQ0Y7QUFFTyxnQkFBUyxhQUFhLE1BQXNDO0FBQ2pFLFNBQU8sV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDLE1BQU0sRUFBRSxTQUFTLElBQUksQ0FBQztBQUNwRTtBQUVPLGdCQUFTLFlBQVksTUFBcUM7QUFDL0QsYUFBVyxTQUFTLFlBQVk7QUFDOUIsVUFBTSxPQUFPLE1BQU0sTUFBTSxLQUFLLENBQUMsTUFBTSxFQUFFLFNBQVMsSUFBSTtBQUNwRCxRQUFJLEtBQU0sUUFBTztBQUFBLEVBQ25CO0FBQ0EsU0FBTztBQUNUO0FBR08sZ0JBQVMsY0FBMEI7QUFDeEMsU0FBTyxXQUFXLFFBQVEsQ0FBQyxNQUFNLEVBQUUsTUFBTSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQztBQUM3RDsiLCJuYW1lcyI6W119