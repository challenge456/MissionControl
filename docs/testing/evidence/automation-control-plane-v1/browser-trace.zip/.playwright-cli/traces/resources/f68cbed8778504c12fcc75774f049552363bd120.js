import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/AuditView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { Card } from "/src/components/ui/card.tsx";
import { PageHeader } from "/src/components/PageHeader.tsx";
import { FileText, ShieldCheck, Clock, XCircle, Filter, Download } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { Button } from "/src/components/ui/button.tsx";
import { StatusBadge } from "/src/components/factory/badges.tsx";
import { cn } from "/src/lib/utils.ts";
function fmtTime(ts) {
  if (!ts) return "n/a";
  return new Date(ts).toLocaleString();
}
const PILL_TONES = {
  ACTIVE: "success",
  APPROVED: "success",
  ALLOW: "success",
  GREEN: "success",
  PENDING: "warning",
  YELLOW: "warning",
  NEEDS_APPROVAL: "warning",
  DENIED: "error",
  RED: "error",
  FAILED: "error",
  TASK_TRANSITIONED: "info",
  APPROVAL_REQUESTED: "info"
};
function StatusPill({ value }) {
  return /* @__PURE__ */ jsxDEV(StatusBadge, { tone: PILL_TONES[value.toUpperCase()] ?? "neutral", className: "whitespace-nowrap", children: value }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
    lineNumber: 53,
    columnNumber: 5
  }, this);
}
_c = StatusPill;
function StatCard({
  icon: Icon,
  label,
  value,
  accent
}) {
  return /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-1.5", children: [
      /* @__PURE__ */ jsxDEV(Icon, { className: "h-3.5 w-3.5 text-ink-muted", strokeWidth: 1.6 }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
        lineNumber: 65,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "text-[12.5px] font-medium text-ink-secondary", children: label }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
        lineNumber: 66,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
      lineNumber: 64,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: cn("text-[20px] font-semibold leading-none tabular-nums", accent ?? "text-ink"), children: value }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
      lineNumber: 68,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
    lineNumber: 63,
    columnNumber: 5
  }, this);
}
_c2 = StatCard;
function TableSection({
  title,
  children,
  controls,
  empty
}) {
  return /* @__PURE__ */ jsxDEV(Card, { className: "overflow-hidden", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-3 border-b border-line flex items-center justify-between gap-3 flex-wrap", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-[15px] font-semibold text-ink", children: title }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
        lineNumber: 87,
        columnNumber: 9
      }, this),
      controls
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
      lineNumber: 86,
      columnNumber: 7
    }, this),
    empty ? /* @__PURE__ */ jsxDEV("div", { className: "py-10 text-center text-[13.5px] text-ink-muted", children: "No records found." }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
      lineNumber: 91,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "overflow-auto", children }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
      lineNumber: 93,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
    lineNumber: 85,
    columnNumber: 5
  }, this);
}
_c3 = TableSection;
export function AuditView({ projectId }) {
  _s();
  const [limit, setLimit] = useState(100);
  const [changeTypeFilter, setChangeTypeFilter] = useState("");
  const changes = useQuery(
    api["governance/changeRecords"].listChangeRecords,
    projectId ? { projectId, type: changeTypeFilter || void 0, limit } : "skip"
  );
  const approvals = useQuery(
    api["governance/approvalRecords"].listApprovals,
    projectId ? { projectId } : "skip"
  );
  const pendingCount = (approvals ?? []).filter((r) => r.status === "PENDING").length;
  const deniedCount = (approvals ?? []).filter((r) => r.status === "DENIED").length;
  const handleExport = () => {
    const changeRows = (changes ?? []).map(
      (c) => [fmtTime(c.timestamp), c.type, c.summary, c.projectId ?? "", c.instanceId ?? "", c.versionId ?? "", `${c.relatedTable ?? ""} ${c.relatedId ?? ""}`].join(",")
    );
    const approvalRows = (approvals ?? []).map(
      (a2) => [fmtTime(a2.requestedAt), a2.actionType, a2.riskLevel, a2.status, fmtTime(a2.decidedAt), (a2.decisionReason ?? a2.justification ?? "").replace(/"/g, '""')].join(",")
    );
    const csv = "Change Records\nTime,Type,Summary,Project,Instance,Version,Related\n" + changeRows.join("\n") + "\n\nApproval Records\nRequested,Action,Risk,Status,Decided,Reason\n" + approvalRows.join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `arm-audit-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };
  return /* @__PURE__ */ jsxDEV("section", { className: "flex min-h-0 flex-1 flex-col overflow-hidden bg-app", children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: "ARM Audit",
        description: "Governance trail for approvals, lifecycle transitions, deployments, and policy decisions.",
        eyebrow: "Operations",
        actions: /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", onClick: handleExport, children: [
          /* @__PURE__ */ jsxDEV(Download, { className: "h-3.5 w-3.5 mr-1.5", strokeWidth: 1.7 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
            lineNumber: 144,
            columnNumber: 13
          }, this),
          "Export CSV"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
          lineNumber: 143,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
        lineNumber: 138,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "mx-auto flex min-h-0 w-full max-w-[1200px] flex-1 flex-col gap-4 overflow-hidden px-6 pb-6 pt-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid shrink-0 grid-cols-2 gap-3 sm:grid-cols-4", children: [
        /* @__PURE__ */ jsxDEV(StatCard, { icon: FileText, label: "Change Records", value: (changes ?? []).length }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
          lineNumber: 153,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(StatCard, { icon: ShieldCheck, label: "Approval Records", value: (approvals ?? []).length }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
          lineNumber: 154,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(StatCard, { icon: Clock, label: "Pending Approvals", value: pendingCount, accent: pendingCount > 0 ? "text-warn" : void 0 }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
          lineNumber: 155,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(StatCard, { icon: XCircle, label: "Denied Decisions", value: deniedCount, accent: deniedCount > 0 ? "text-err" : void 0 }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
          lineNumber: 156,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
        lineNumber: 152,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid min-h-0 flex-1 gap-4 overflow-hidden xl:grid-cols-[minmax(0,1fr)_320px]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto", children: [
          /* @__PURE__ */ jsxDEV(
            TableSection,
            {
              title: "Change Records",
              empty: (changes ?? []).length === 0,
              controls: /* @__PURE__ */ jsxDEV("div", { className: "flex shrink-0 items-center gap-3 overflow-x-auto flex-nowrap", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(Filter, { className: "h-3 w-3 text-ink-muted", strokeWidth: 1.6 }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                    lineNumber: 168,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      className: "h-9 rounded-lg border border-line bg-surface-1 px-3 text-[13.5px] text-ink placeholder:text-ink-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring w-44",
                      placeholder: "Filter by type…",
                      "aria-label": "Filter change records by type",
                      value: changeTypeFilter,
                      onChange: (e) => setChangeTypeFilter(e.target.value)
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                      lineNumber: 169,
                      columnNumber: 17
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                  lineNumber: 167,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    className: "h-9 rounded-lg border border-line bg-surface-1 px-3 text-[13.5px] text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                    "aria-label": "Row limit",
                    value: limit,
                    onChange: (e) => setLimit(Number(e.target.value)),
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: 50, children: "50 rows" }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                        lineNumber: 183,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: 100, children: "100 rows" }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                        lineNumber: 184,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: 200, children: "200 rows" }, void 0, false, {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                        lineNumber: 185,
                        columnNumber: 17
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                    lineNumber: 177,
                    columnNumber: 15
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                lineNumber: 166,
                columnNumber: 15
              }, this),
              children: /* @__PURE__ */ jsxDEV("table", { className: "w-full min-w-[980px] border-collapse text-left text-[13px]", children: [
                /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-line", children: ["Time", "Type", "Summary", "Project", "Instance", "Version", "Related"].map(
                  (h) => /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2.5 text-[11.5px] font-medium uppercase tracking-[0.06em] text-ink-muted", children: h }, h, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                    lineNumber: 194,
                    columnNumber: 21
                  }, this)
                ) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                  lineNumber: 192,
                  columnNumber: 15
                }, this) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                  lineNumber: 191,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("tbody", { children: (changes ?? []).map(
                  (change) => /* @__PURE__ */ jsxDEV(
                    "tr",
                    {
                      className: "border-b border-line last:border-b-0 hover:bg-surface-2 transition-colors duration-150",
                      children: [
                        /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5 text-ink-muted whitespace-nowrap font-mono", children: fmtTime(change.timestamp) }, void 0, false, {
                          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                          lineNumber: 204,
                          columnNumber: 19
                        }, this),
                        /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5", children: /* @__PURE__ */ jsxDEV(StatusPill, { value: change.type }, void 0, false, {
                          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                          lineNumber: 205,
                          columnNumber: 47
                        }, this) }, void 0, false, {
                          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                          lineNumber: 205,
                          columnNumber: 19
                        }, this),
                        /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5 text-ink-secondary max-w-[280px] truncate", children: change.summary }, void 0, false, {
                          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                          lineNumber: 206,
                          columnNumber: 19
                        }, this),
                        /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5 font-mono text-ink-muted truncate max-w-[140px]", children: change.projectId ?? "n/a" }, void 0, false, {
                          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                          lineNumber: 207,
                          columnNumber: 19
                        }, this),
                        /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5 font-mono text-ink-muted truncate max-w-[120px]", children: change.instanceId ?? "n/a" }, void 0, false, {
                          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                          lineNumber: 208,
                          columnNumber: 19
                        }, this),
                        /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5 font-mono text-ink-muted truncate max-w-[120px]", children: change.versionId ?? "n/a" }, void 0, false, {
                          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                          lineNumber: 209,
                          columnNumber: 19
                        }, this),
                        /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5 text-ink-muted truncate max-w-[180px]", children: [
                          change.relatedTable ?? "n/a",
                          change.relatedId ? ` · ${change.relatedId}` : ""
                        ] }, void 0, true, {
                          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                          lineNumber: 210,
                          columnNumber: 19
                        }, this)
                      ]
                    },
                    change._id,
                    true,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                      lineNumber: 200,
                      columnNumber: 19
                    },
                    this
                  )
                ) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                  lineNumber: 198,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                lineNumber: 190,
                columnNumber: 11
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
              lineNumber: 162,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(TableSection, { title: "Approval Records", empty: (approvals ?? []).length === 0, children: /* @__PURE__ */ jsxDEV("table", { className: "w-full min-w-[840px] border-collapse text-left text-[13px]", children: [
            /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-line", children: ["Requested", "Action", "Risk", "Status", "Decided", "Reason"].map(
              (h) => /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2.5 text-[11.5px] font-medium uppercase tracking-[0.06em] text-ink-muted", children: h }, h, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                lineNumber: 225,
                columnNumber: 21
              }, this)
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
              lineNumber: 223,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
              lineNumber: 222,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("tbody", { children: (approvals ?? []).map(
              (approval) => /* @__PURE__ */ jsxDEV(
                "tr",
                {
                  className: "border-b border-line last:border-b-0 hover:bg-surface-2 transition-colors duration-150",
                  children: [
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5 text-ink-muted whitespace-nowrap font-mono", children: fmtTime(approval.requestedAt) }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                      lineNumber: 235,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5 text-ink-secondary", children: approval.actionType }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                      lineNumber: 236,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5", children: /* @__PURE__ */ jsxDEV(StatusPill, { value: approval.riskLevel }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                      lineNumber: 237,
                      columnNumber: 47
                    }, this) }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                      lineNumber: 237,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5", children: /* @__PURE__ */ jsxDEV(StatusPill, { value: approval.status }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                      lineNumber: 238,
                      columnNumber: 47
                    }, this) }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                      lineNumber: 238,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5 text-ink-muted whitespace-nowrap font-mono", children: fmtTime(approval.decidedAt) }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                      lineNumber: 239,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3.5 text-ink-muted truncate max-w-[200px]", children: approval.decisionReason ?? approval.justification ?? "—" }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                      lineNumber: 240,
                      columnNumber: 19
                    }, this)
                  ]
                },
                approval._id,
                true,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
                  lineNumber: 231,
                  columnNumber: 19
                },
                this
              )
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
              lineNumber: 229,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
            lineNumber: 221,
            columnNumber: 11
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
            lineNumber: 220,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
          lineNumber: 160,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(Card, { className: "p-5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-[15px] font-semibold text-ink", children: "Audit guidance" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
            lineNumber: 251,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-2 space-y-3 text-[13.5px] leading-relaxed text-ink-secondary", children: [
            /* @__PURE__ */ jsxDEV("p", { children: "Use this surface to confirm that risky actions were reviewed and that the decision trail still makes sense after the fact." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
              lineNumber: 253,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "If audit volume becomes noisy, the real fix is tighter routing and better change summaries upstream, not more rows here." }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
              lineNumber: 254,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
            lineNumber: 252,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
          lineNumber: 250,
          columnNumber: 7
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
        lineNumber: 159,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
      lineNumber: 151,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx",
    lineNumber: 137,
    columnNumber: 5
  }, this);
}
_s(AuditView, "S6Y9jWu54MF2z7NoA1pQwuLdv+U=", false, function() {
  return [useQuery, useQuery];
});
_c4 = AuditView;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "StatusPill");
$RefreshReg$(_c2, "StatCard");
$RefreshReg$(_c3, "TableSection");
$RefreshReg$(_c4, "AuditView");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AuditView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUNJOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpDSixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFdBQVc7QUFFcEIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsVUFBVUMsYUFBYUMsT0FBT0MsU0FBU0MsUUFBUUMsZ0JBQWdCO0FBQ3hFLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsbUJBQTBDO0FBQ25ELFNBQVNDLFVBQVU7QUFFbkIsU0FBU0MsUUFBUUMsSUFBYTtBQUM1QixNQUFJLENBQUNBLEdBQUksUUFBTztBQUNoQixTQUFPLElBQUlDLEtBQUtELEVBQUUsRUFBRUUsZUFBZTtBQUNyQztBQUVBLE1BQU1DLGFBQXVEO0FBQUEsRUFDM0RDLFFBQW1CO0FBQUEsRUFDbkJDLFVBQW1CO0FBQUEsRUFDbkJDLE9BQW1CO0FBQUEsRUFDbkJDLE9BQW1CO0FBQUEsRUFDbkJDLFNBQW1CO0FBQUEsRUFDbkJDLFFBQW1CO0FBQUEsRUFDbkJDLGdCQUFtQjtBQUFBLEVBQ25CQyxRQUFtQjtBQUFBLEVBQ25CQyxLQUFtQjtBQUFBLEVBQ25CQyxRQUFtQjtBQUFBLEVBQ25CQyxtQkFBbUI7QUFBQSxFQUNuQkMsb0JBQW1CO0FBQ3JCO0FBRUEsU0FBU0MsV0FBVyxFQUFFQyxNQUF5QixHQUFHO0FBQ2hELFNBQ0UsdUJBQUMsZUFBWSxNQUFNZCxXQUFXYyxNQUFNQyxZQUFZLENBQUMsS0FBSyxXQUFXLFdBQVUscUJBQ3hFRCxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDRSxLQU5RSDtBQVFULFNBQVNJLFNBQVM7QUFBQSxFQUFFQyxNQUFNQztBQUFBQSxFQUFNQztBQUFBQSxFQUFPTjtBQUFBQSxFQUFPTztBQUU5QyxHQUFHO0FBQ0QsU0FDRSx1QkFBQyxRQUFLLFdBQVUsT0FDZDtBQUFBLDJCQUFDLFNBQUksV0FBVSxrQ0FDYjtBQUFBLDZCQUFDLFFBQUssV0FBVSw4QkFBNkIsYUFBYSxPQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThEO0FBQUEsTUFDOUQsdUJBQUMsVUFBSyxXQUFVLGdEQUFnREQsbUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0U7QUFBQSxTQUZ4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLE9BQUUsV0FBV3pCLEdBQUcsdURBQXVEMEIsVUFBVSxVQUFVLEdBQUlQLG1CQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNHO0FBQUEsT0FMeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BO0FBRUo7QUFBQ1EsTUFaUUw7QUFjVCxTQUFTTSxhQUFhO0FBQUEsRUFDcEJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBTUYsR0FBRztBQUNELFNBQ0UsdUJBQUMsUUFBSyxXQUFVLG1CQUNkO0FBQUEsMkJBQUMsU0FBSSxXQUFVLG9GQUNiO0FBQUEsNkJBQUMsT0FBRSxXQUFVLHNDQUFzQ0gsbUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUQ7QUFBQSxNQUN4REU7QUFBQUEsU0FGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNDQyxRQUNDLHVCQUFDLFNBQUksV0FBVSxrREFBaUQsaUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUYsSUFFakYsdUJBQUMsU0FBSSxXQUFVLGlCQUFpQkYsWUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QztBQUFBLE9BUjdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FVQTtBQUVKO0FBQUNHLE1BeEJRTDtBQTBCRixnQkFBU00sVUFBVSxFQUFFQyxVQUFnRCxHQUFHO0FBQUFDLEtBQUE7QUFDN0UsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUluRCxTQUFTLEdBQUc7QUFDdEMsUUFBTSxDQUFDb0Qsa0JBQWtCQyxtQkFBbUIsSUFBSXJELFNBQVMsRUFBRTtBQUUzRCxRQUFNc0QsVUFBVXJEO0FBQUFBLElBQ2RDLElBQUksMEJBQTBCLEVBQUVxRDtBQUFBQSxJQUNoQ1AsWUFDSSxFQUFFQSxXQUFXUSxNQUFNSixvQkFBb0JLLFFBQVdQLE1BQU0sSUFDeEQ7QUFBQSxFQUNOO0FBQ0EsUUFBTVEsWUFBWXpEO0FBQUFBLElBQ2hCQyxJQUFJLDRCQUE0QixFQUFFeUQ7QUFBQUEsSUFDbENYLFlBQVksRUFBRUEsVUFBVSxJQUFJO0FBQUEsRUFDOUI7QUFFQSxRQUFNWSxnQkFBZ0JGLGFBQWEsSUFBSUcsT0FBTyxDQUFDQyxNQUFNQSxFQUFFQyxXQUFXLFNBQVMsRUFBRUM7QUFDN0UsUUFBTUMsZUFBZ0JQLGFBQWEsSUFBSUcsT0FBTyxDQUFDQyxNQUFNQSxFQUFFQyxXQUFXLFFBQVEsRUFBRUM7QUFFNUUsUUFBTUUsZUFBZUEsTUFBTTtBQUN6QixVQUFNQyxjQUFjYixXQUFXLElBQUljO0FBQUFBLE1BQUksQ0FBQ0MsTUFDdEMsQ0FBQ3ZELFFBQVF1RCxFQUFFQyxTQUFTLEdBQUdELEVBQUViLE1BQU1hLEVBQUVFLFNBQVNGLEVBQUVyQixhQUFhLElBQUlxQixFQUFFRyxjQUFjLElBQUlILEVBQUVJLGFBQWEsSUFBSSxHQUFHSixFQUFFSyxnQkFBZ0IsRUFBRSxJQUFJTCxFQUFFTSxhQUFhLEVBQUUsRUFBRSxFQUFFQyxLQUFLLEdBQUc7QUFBQSxJQUM5SjtBQUNBLFVBQU1DLGdCQUFnQm5CLGFBQWEsSUFBSVU7QUFBQUEsTUFBSSxDQUFDVSxPQUMxQyxDQUFDaEUsUUFBUWdFLEdBQUVDLFdBQVcsR0FBR0QsR0FBRUUsWUFBWUYsR0FBRUcsV0FBV0gsR0FBRWYsUUFBUWpELFFBQVFnRSxHQUFFSSxTQUFTLElBQUlKLEdBQUVLLGtCQUFrQkwsR0FBRU0saUJBQWlCLElBQUlDLFFBQVEsTUFBTSxJQUFJLENBQUMsRUFBRVQsS0FBSyxHQUFHO0FBQUEsSUFDL0o7QUFDQSxVQUFNVSxNQUNKLHlFQUF5RW5CLFdBQVdTLEtBQUssSUFBSSxJQUM3Rix3RUFBd0VDLGFBQWFELEtBQUssSUFBSTtBQUNoRyxVQUFNVyxPQUFPLElBQUlDLEtBQUssQ0FBQ0YsR0FBRyxHQUFHLEVBQUU5QixNQUFNLHlCQUF5QixDQUFDO0FBQy9ELFVBQU1pQyxNQUFNQyxJQUFJQyxnQkFBZ0JKLElBQUk7QUFDcEMsVUFBTVQsSUFBSWMsU0FBU0MsY0FBYyxHQUFHO0FBQ3BDZixNQUFFZ0IsT0FBT0w7QUFDVFgsTUFBRWlCLFdBQVcsY0FBYSxvQkFBSS9FLEtBQUssR0FBRWdGLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUMvRG5CLE1BQUVvQixNQUFNO0FBQ1JSLFFBQUlTLGdCQUFnQlYsR0FBRztBQUFBLEVBQ3pCO0FBRUEsU0FDRSx1QkFBQyxhQUFRLFdBQVUsdURBQ2pCO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLGFBQVk7QUFBQSxRQUNaLFNBQVE7QUFBQSxRQUNSLFNBQ0UsdUJBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxXQUFVLFNBQVN2QixjQUMzQztBQUFBLGlDQUFDLFlBQVMsV0FBVSxzQkFBcUIsYUFBYSxPQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRDtBQUFBO0FBQUEsYUFENUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUE7QUFBQSxNQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVNHO0FBQUEsSUFJSCx1QkFBQyxTQUFJLFdBQVUsbUdBQ2Y7QUFBQSw2QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSwrQkFBQyxZQUFTLE1BQU03RCxVQUFZLE9BQU0sa0JBQW1CLFFBQVFpRCxXQUFXLElBQUlVLFVBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUY7QUFBQSxRQUNuRix1QkFBQyxZQUFTLE1BQU0xRCxhQUFhLE9BQU0sb0JBQW1CLFFBQVFvRCxhQUFhLElBQUlNLFVBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Y7QUFBQSxRQUN0Rix1QkFBQyxZQUFTLE1BQU16RCxPQUFZLE9BQU0scUJBQW9CLE9BQU9xRCxjQUFjLFFBQVFBLGVBQWUsSUFBSSxjQUFjSCxVQUFwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThIO0FBQUEsUUFDOUgsdUJBQUMsWUFBUyxNQUFNakQsU0FBWSxPQUFNLG9CQUFvQixPQUFPeUQsYUFBYyxRQUFRQSxjQUFlLElBQUksYUFBY1IsVUFBcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4SDtBQUFBLFdBSmhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGdGQUNmO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHNEQUViO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLFFBQVFILFdBQVcsSUFBSVUsV0FBVztBQUFBLGNBQ2xDLFVBQ0UsdUJBQUMsU0FBSSxXQUFVLGdFQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEseUNBQUMsVUFBTyxXQUFVLDBCQUF5QixhQUFhLE9BQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTREO0FBQUEsa0JBQzVEO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixhQUFZO0FBQUEsc0JBQ1osY0FBVztBQUFBLHNCQUNYLE9BQU9aO0FBQUFBLHNCQUNQLFVBQVUsQ0FBQ2dELE1BQU0vQyxvQkFBb0IrQyxFQUFFQyxPQUFPckUsS0FBSztBQUFBO0FBQUEsb0JBTHJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLdUQ7QUFBQSxxQkFQekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixjQUFXO0FBQUEsb0JBQ1gsT0FBT2tCO0FBQUFBLG9CQUNQLFVBQVUsQ0FBQ2tELE1BQU1qRCxTQUFTbUQsT0FBT0YsRUFBRUMsT0FBT3JFLEtBQUssQ0FBQztBQUFBLG9CQUVoRDtBQUFBLDZDQUFDLFlBQU8sT0FBTyxJQUFJLHVCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEwQjtBQUFBLHNCQUMxQix1QkFBQyxZQUFPLE9BQU8sS0FBSyx3QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNEI7QUFBQSxzQkFDNUIsdUJBQUMsWUFBTyxPQUFPLEtBQUssd0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTRCO0FBQUE7QUFBQTtBQUFBLGtCQVI5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU0E7QUFBQSxtQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxQkE7QUFBQSxjQUdGLGlDQUFDLFdBQU0sV0FBVSw4REFDZjtBQUFBLHVDQUFDLFdBQ0MsaUNBQUMsUUFBRyxXQUFVLHdCQUNYLFdBQUMsUUFBUSxRQUFRLFdBQVcsV0FBVyxZQUFZLFdBQVcsU0FBUyxFQUFFb0M7QUFBQUEsa0JBQUksQ0FBQ21DLE1BQzdFLHVCQUFDLFFBQVcsV0FBVSxvRkFBb0ZBLGVBQWpHQSxHQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTRHO0FBQUEsZ0JBQzdHLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTUE7QUFBQSxnQkFDQSx1QkFBQyxXQUNHakQsc0JBQVcsSUFBSWM7QUFBQUEsa0JBQUksQ0FBQ29DLFdBQ3BCO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUVDLFdBQVU7QUFBQSxzQkFFVjtBQUFBLCtDQUFDLFFBQUcsV0FBVSwwREFBMEQxRixrQkFBUTBGLE9BQU9sQyxTQUFTLEtBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWtHO0FBQUEsd0JBQ2xHLHVCQUFDLFFBQUcsV0FBVSxlQUFjLGlDQUFDLGNBQVcsT0FBT2tDLE9BQU9oRCxRQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUErQixLQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE4RDtBQUFBLHdCQUM5RCx1QkFBQyxRQUFHLFdBQVUseURBQXlEZ0QsaUJBQU9qQyxXQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFzRjtBQUFBLHdCQUN0Rix1QkFBQyxRQUFHLFdBQVUsK0RBQStEaUMsaUJBQU94RCxhQUFhLFNBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXVHO0FBQUEsd0JBQ3ZHLHVCQUFDLFFBQUcsV0FBVSwrREFBK0R3RCxpQkFBT2hDLGNBQWMsU0FBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBd0c7QUFBQSx3QkFDeEcsdUJBQUMsUUFBRyxXQUFVLCtEQUErRGdDLGlCQUFPL0IsYUFBYSxTQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUF1RztBQUFBLHdCQUN2Ryx1QkFBQyxRQUFHLFdBQVUscURBQ1grQjtBQUFBQSxpQ0FBTzlCLGdCQUFnQjtBQUFBLDBCQUFPOEIsT0FBTzdCLFlBQVksTUFBTTZCLE9BQU83QixTQUFTLEtBQUs7QUFBQSw2QkFEL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBO0FBQUE7QUFBQSxvQkFYSzZCLE9BQU9DO0FBQUFBLG9CQURkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBYUE7QUFBQSxnQkFDRCxLQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlCQTtBQUFBLG1CQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTBCQTtBQUFBO0FBQUEsWUF0REY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBdURBO0FBQUEsVUFHQSx1QkFBQyxnQkFBYSxPQUFNLG9CQUFtQixRQUFRL0MsYUFBYSxJQUFJTSxXQUFXLEdBQ3pFLGlDQUFDLFdBQU0sV0FBVSw4REFDZjtBQUFBLG1DQUFDLFdBQ0MsaUNBQUMsUUFBRyxXQUFVLHdCQUNYLFdBQUMsYUFBYSxVQUFVLFFBQVEsVUFBVSxXQUFXLFFBQVEsRUFBRUk7QUFBQUEsY0FBSSxDQUFDbUMsTUFDbkUsdUJBQUMsUUFBVyxXQUFVLG9GQUFvRkEsZUFBakdBLEdBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEc7QUFBQSxZQUM3RyxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUEsS0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsWUFDQSx1QkFBQyxXQUNHN0Msd0JBQWEsSUFBSVU7QUFBQUEsY0FBSSxDQUFDc0MsYUFDdEI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUMsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsUUFBRyxXQUFVLDBEQUEwRDVGLGtCQUFRNEYsU0FBUzNCLFdBQVcsS0FBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBc0c7QUFBQSxvQkFDdEcsdUJBQUMsUUFBRyxXQUFVLGtDQUFrQzJCLG1CQUFTMUIsY0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0U7QUFBQSxvQkFDcEUsdUJBQUMsUUFBRyxXQUFVLGVBQWMsaUNBQUMsY0FBVyxPQUFPMEIsU0FBU3pCLGFBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXNDLEtBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXFFO0FBQUEsb0JBQ3JFLHVCQUFDLFFBQUcsV0FBVSxlQUFjLGlDQUFDLGNBQVcsT0FBT3lCLFNBQVMzQyxVQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtQyxLQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrRTtBQUFBLG9CQUNsRSx1QkFBQyxRQUFHLFdBQVUsMERBQTBEakQsa0JBQVE0RixTQUFTeEIsU0FBUyxLQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFvRztBQUFBLG9CQUNwRyx1QkFBQyxRQUFHLFdBQVUscURBQ1h3QixtQkFBU3ZCLGtCQUFrQnVCLFNBQVN0QixpQkFBaUIsT0FEeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBO0FBQUE7QUFBQSxnQkFWS3NCLFNBQVNEO0FBQUFBLGdCQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWUE7QUFBQSxZQUNELEtBZkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxlQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlCQSxLQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTJCQTtBQUFBLGFBdkZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3RkE7QUFBQSxRQUVBLHVCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHNDQUFxQyw4QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0U7QUFBQSxVQUNsRSx1QkFBQyxTQUFJLFdBQVUsbUVBQ2I7QUFBQSxtQ0FBQyxPQUFFLDBJQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZIO0FBQUEsWUFDN0gsdUJBQUMsT0FBRSx3SUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEySDtBQUFBLGVBRjdIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFdBakdBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrR0E7QUFBQSxTQTFHQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkdBO0FBQUEsT0F6SEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBIQTtBQUVKO0FBQUN4RCxHQWxLZUYsV0FBUztBQUFBLFVBSVA5QyxVQU1FQSxRQUFRO0FBQUE7QUFBQSxNQVZaOEM7QUFBUyxJQUFBYixJQUFBTSxLQUFBTSxLQUFBNkQ7QUFBQSxhQUFBekUsSUFBQTtBQUFBLGFBQUFNLEtBQUE7QUFBQSxhQUFBTSxLQUFBO0FBQUEsYUFBQTZELEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZVF1ZXJ5IiwiYXBpIiwiQ2FyZCIsIlBhZ2VIZWFkZXIiLCJGaWxlVGV4dCIsIlNoaWVsZENoZWNrIiwiQ2xvY2siLCJYQ2lyY2xlIiwiRmlsdGVyIiwiRG93bmxvYWQiLCJCdXR0b24iLCJTdGF0dXNCYWRnZSIsImNuIiwiZm10VGltZSIsInRzIiwiRGF0ZSIsInRvTG9jYWxlU3RyaW5nIiwiUElMTF9UT05FUyIsIkFDVElWRSIsIkFQUFJPVkVEIiwiQUxMT1ciLCJHUkVFTiIsIlBFTkRJTkciLCJZRUxMT1ciLCJORUVEU19BUFBST1ZBTCIsIkRFTklFRCIsIlJFRCIsIkZBSUxFRCIsIlRBU0tfVFJBTlNJVElPTkVEIiwiQVBQUk9WQUxfUkVRVUVTVEVEIiwiU3RhdHVzUGlsbCIsInZhbHVlIiwidG9VcHBlckNhc2UiLCJfYyIsIlN0YXRDYXJkIiwiaWNvbiIsIkljb24iLCJsYWJlbCIsImFjY2VudCIsIl9jMiIsIlRhYmxlU2VjdGlvbiIsInRpdGxlIiwiY2hpbGRyZW4iLCJjb250cm9scyIsImVtcHR5IiwiX2MzIiwiQXVkaXRWaWV3IiwicHJvamVjdElkIiwiX3MiLCJsaW1pdCIsInNldExpbWl0IiwiY2hhbmdlVHlwZUZpbHRlciIsInNldENoYW5nZVR5cGVGaWx0ZXIiLCJjaGFuZ2VzIiwibGlzdENoYW5nZVJlY29yZHMiLCJ0eXBlIiwidW5kZWZpbmVkIiwiYXBwcm92YWxzIiwibGlzdEFwcHJvdmFscyIsInBlbmRpbmdDb3VudCIsImZpbHRlciIsInIiLCJzdGF0dXMiLCJsZW5ndGgiLCJkZW5pZWRDb3VudCIsImhhbmRsZUV4cG9ydCIsImNoYW5nZVJvd3MiLCJtYXAiLCJjIiwidGltZXN0YW1wIiwic3VtbWFyeSIsImluc3RhbmNlSWQiLCJ2ZXJzaW9uSWQiLCJyZWxhdGVkVGFibGUiLCJyZWxhdGVkSWQiLCJqb2luIiwiYXBwcm92YWxSb3dzIiwiYSIsInJlcXVlc3RlZEF0IiwiYWN0aW9uVHlwZSIsInJpc2tMZXZlbCIsImRlY2lkZWRBdCIsImRlY2lzaW9uUmVhc29uIiwianVzdGlmaWNhdGlvbiIsInJlcGxhY2UiLCJjc3YiLCJibG9iIiwiQmxvYiIsInVybCIsIlVSTCIsImNyZWF0ZU9iamVjdFVSTCIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsImhyZWYiLCJkb3dubG9hZCIsInRvSVNPU3RyaW5nIiwic2xpY2UiLCJjbGljayIsInJldm9rZU9iamVjdFVSTCIsImUiLCJ0YXJnZXQiLCJOdW1iZXIiLCJoIiwiY2hhbmdlIiwiX2lkIiwiYXBwcm92YWwiLCJfYzQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXVkaXRWaWV3LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgQ2FyZCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvY2FyZFwiO1xuaW1wb3J0IHsgUGFnZUhlYWRlciB9IGZyb20gXCIuL2NvbXBvbmVudHMvUGFnZUhlYWRlclwiO1xuaW1wb3J0IHsgRmlsZVRleHQsIFNoaWVsZENoZWNrLCBDbG9jaywgWENpcmNsZSwgRmlsdGVyLCBEb3dubG9hZCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQgeyBTdGF0dXNCYWRnZSwgdHlwZSBTdGF0dXNCYWRnZVByb3BzIH0gZnJvbSBcIkAvY29tcG9uZW50cy9mYWN0b3J5L2JhZGdlc1wiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcblxuZnVuY3Rpb24gZm10VGltZSh0cz86IG51bWJlcikge1xuICBpZiAoIXRzKSByZXR1cm4gXCJuL2FcIjtcbiAgcmV0dXJuIG5ldyBEYXRlKHRzKS50b0xvY2FsZVN0cmluZygpO1xufVxuXG5jb25zdCBQSUxMX1RPTkVTOiBSZWNvcmQ8c3RyaW5nLCBTdGF0dXNCYWRnZVByb3BzW1widG9uZVwiXT4gPSB7XG4gIEFDVElWRTogICAgICAgICAgICBcInN1Y2Nlc3NcIixcbiAgQVBQUk9WRUQ6ICAgICAgICAgIFwic3VjY2Vzc1wiLFxuICBBTExPVzogICAgICAgICAgICAgXCJzdWNjZXNzXCIsXG4gIEdSRUVOOiAgICAgICAgICAgICBcInN1Y2Nlc3NcIixcbiAgUEVORElORzogICAgICAgICAgIFwid2FybmluZ1wiLFxuICBZRUxMT1c6ICAgICAgICAgICAgXCJ3YXJuaW5nXCIsXG4gIE5FRURTX0FQUFJPVkFMOiAgICBcIndhcm5pbmdcIixcbiAgREVOSUVEOiAgICAgICAgICAgIFwiZXJyb3JcIixcbiAgUkVEOiAgICAgICAgICAgICAgIFwiZXJyb3JcIixcbiAgRkFJTEVEOiAgICAgICAgICAgIFwiZXJyb3JcIixcbiAgVEFTS19UUkFOU0lUSU9ORUQ6IFwiaW5mb1wiLFxuICBBUFBST1ZBTF9SRVFVRVNURUQ6XCJpbmZvXCIsXG59O1xuXG5mdW5jdGlvbiBTdGF0dXNQaWxsKHsgdmFsdWUgfTogeyB2YWx1ZTogc3RyaW5nIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8U3RhdHVzQmFkZ2UgdG9uZT17UElMTF9UT05FU1t2YWx1ZS50b1VwcGVyQ2FzZSgpXSA/PyBcIm5ldXRyYWxcIn0gY2xhc3NOYW1lPVwid2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgIHt2YWx1ZX1cbiAgICA8L1N0YXR1c0JhZGdlPlxuICApO1xufVxuXG5mdW5jdGlvbiBTdGF0Q2FyZCh7IGljb246IEljb24sIGxhYmVsLCB2YWx1ZSwgYWNjZW50IH06IHtcbiAgaWNvbjogUmVhY3QuRWxlbWVudFR5cGU7IGxhYmVsOiBzdHJpbmc7IHZhbHVlOiBudW1iZXI7IGFjY2VudD86IHN0cmluZztcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItMS41XCI+XG4gICAgICAgIDxJY29uIGNsYXNzTmFtZT1cImgtMy41IHctMy41IHRleHQtaW5rLW11dGVkXCIgc3Ryb2tlV2lkdGg9ezEuNn0gLz5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTIuNXB4XSBmb250LW1lZGl1bSB0ZXh0LWluay1zZWNvbmRhcnlcIj57bGFiZWx9PC9zcGFuPlxuICAgICAgPC9kaXY+XG4gICAgICA8cCBjbGFzc05hbWU9e2NuKFwidGV4dC1bMjBweF0gZm9udC1zZW1pYm9sZCBsZWFkaW5nLW5vbmUgdGFidWxhci1udW1zXCIsIGFjY2VudCA/PyBcInRleHQtaW5rXCIpfT57dmFsdWV9PC9wPlxuICAgIDwvQ2FyZD5cbiAgKTtcbn1cblxuZnVuY3Rpb24gVGFibGVTZWN0aW9uKHtcbiAgdGl0bGUsXG4gIGNoaWxkcmVuLFxuICBjb250cm9scyxcbiAgZW1wdHksXG59OiB7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG4gIGNvbnRyb2xzPzogUmVhY3QuUmVhY3ROb2RlO1xuICBlbXB0eTogYm9vbGVhbjtcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8Q2FyZCBjbGFzc05hbWU9XCJvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNSBweS0zIGJvcmRlci1iIGJvcmRlci1saW5lIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBmbGV4LXdyYXBcIj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPnt0aXRsZX08L3A+XG4gICAgICAgIHtjb250cm9sc31cbiAgICAgIDwvZGl2PlxuICAgICAge2VtcHR5ID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTEwIHRleHQtY2VudGVyIHRleHQtWzEzLjVweF0gdGV4dC1pbmstbXV0ZWRcIj5ObyByZWNvcmRzIGZvdW5kLjwvZGl2PlxuICAgICAgKSA6IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy1hdXRvXCI+e2NoaWxkcmVufTwvZGl2PlxuICAgICAgKX1cbiAgICA8L0NhcmQ+XG4gICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBBdWRpdFZpZXcoeyBwcm9qZWN0SWQgfTogeyBwcm9qZWN0SWQ6IElkPFwicHJvamVjdHNcIj4gfCBudWxsIH0pIHtcbiAgY29uc3QgW2xpbWl0LCBzZXRMaW1pdF0gPSB1c2VTdGF0ZSgxMDApO1xuICBjb25zdCBbY2hhbmdlVHlwZUZpbHRlciwgc2V0Q2hhbmdlVHlwZUZpbHRlcl0gPSB1c2VTdGF0ZShcIlwiKTtcblxuICBjb25zdCBjaGFuZ2VzID0gdXNlUXVlcnkoXG4gICAgYXBpW1wiZ292ZXJuYW5jZS9jaGFuZ2VSZWNvcmRzXCJdLmxpc3RDaGFuZ2VSZWNvcmRzLFxuICAgIHByb2plY3RJZFxuICAgICAgPyB7IHByb2plY3RJZCwgdHlwZTogY2hhbmdlVHlwZUZpbHRlciB8fCB1bmRlZmluZWQsIGxpbWl0IH1cbiAgICAgIDogXCJza2lwXCJcbiAgKTtcbiAgY29uc3QgYXBwcm92YWxzID0gdXNlUXVlcnkoXG4gICAgYXBpW1wiZ292ZXJuYW5jZS9hcHByb3ZhbFJlY29yZHNcIl0ubGlzdEFwcHJvdmFscyxcbiAgICBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCB9IDogXCJza2lwXCJcbiAgKTtcblxuICBjb25zdCBwZW5kaW5nQ291bnQgPSAoYXBwcm92YWxzID8/IFtdKS5maWx0ZXIoKHIpID0+IHIuc3RhdHVzID09PSBcIlBFTkRJTkdcIikubGVuZ3RoO1xuICBjb25zdCBkZW5pZWRDb3VudCAgPSAoYXBwcm92YWxzID8/IFtdKS5maWx0ZXIoKHIpID0+IHIuc3RhdHVzID09PSBcIkRFTklFRFwiKS5sZW5ndGg7XG5cbiAgY29uc3QgaGFuZGxlRXhwb3J0ID0gKCkgPT4ge1xuICAgIGNvbnN0IGNoYW5nZVJvd3MgPSAoY2hhbmdlcyA/PyBbXSkubWFwKChjKSA9PlxuICAgICAgW2ZtdFRpbWUoYy50aW1lc3RhbXApLCBjLnR5cGUsIGMuc3VtbWFyeSwgYy5wcm9qZWN0SWQgPz8gXCJcIiwgYy5pbnN0YW5jZUlkID8/IFwiXCIsIGMudmVyc2lvbklkID8/IFwiXCIsIGAke2MucmVsYXRlZFRhYmxlID8/IFwiXCJ9ICR7Yy5yZWxhdGVkSWQgPz8gXCJcIn1gXS5qb2luKFwiLFwiKVxuICAgICk7XG4gICAgY29uc3QgYXBwcm92YWxSb3dzID0gKGFwcHJvdmFscyA/PyBbXSkubWFwKChhKSA9PlxuICAgICAgW2ZtdFRpbWUoYS5yZXF1ZXN0ZWRBdCksIGEuYWN0aW9uVHlwZSwgYS5yaXNrTGV2ZWwsIGEuc3RhdHVzLCBmbXRUaW1lKGEuZGVjaWRlZEF0KSwgKGEuZGVjaXNpb25SZWFzb24gPz8gYS5qdXN0aWZpY2F0aW9uID8/IFwiXCIpLnJlcGxhY2UoL1wiL2csICdcIlwiJyldLmpvaW4oXCIsXCIpXG4gICAgKTtcbiAgICBjb25zdCBjc3YgPVxuICAgICAgXCJDaGFuZ2UgUmVjb3Jkc1xcblRpbWUsVHlwZSxTdW1tYXJ5LFByb2plY3QsSW5zdGFuY2UsVmVyc2lvbixSZWxhdGVkXFxuXCIgKyBjaGFuZ2VSb3dzLmpvaW4oXCJcXG5cIikgK1xuICAgICAgXCJcXG5cXG5BcHByb3ZhbCBSZWNvcmRzXFxuUmVxdWVzdGVkLEFjdGlvbixSaXNrLFN0YXR1cyxEZWNpZGVkLFJlYXNvblxcblwiICsgYXBwcm92YWxSb3dzLmpvaW4oXCJcXG5cIik7XG4gICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtjc3ZdLCB7IHR5cGU6IFwidGV4dC9jc3Y7Y2hhcnNldD11dGYtOFwiIH0pO1xuICAgIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XG4gICAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJhXCIpO1xuICAgIGEuaHJlZiA9IHVybDtcbiAgICBhLmRvd25sb2FkID0gYGFybS1hdWRpdC0ke25ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCl9LmNzdmA7XG4gICAgYS5jbGljaygpO1xuICAgIFVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImZsZXggbWluLWgtMCBmbGV4LTEgZmxleC1jb2wgb3ZlcmZsb3ctaGlkZGVuIGJnLWFwcFwiPlxuICAgICAgPFBhZ2VIZWFkZXJcbiAgICAgICAgdGl0bGU9XCJBUk0gQXVkaXRcIlxuICAgICAgICBkZXNjcmlwdGlvbj1cIkdvdmVybmFuY2UgdHJhaWwgZm9yIGFwcHJvdmFscywgbGlmZWN5Y2xlIHRyYW5zaXRpb25zLCBkZXBsb3ltZW50cywgYW5kIHBvbGljeSBkZWNpc2lvbnMuXCJcbiAgICAgICAgZXllYnJvdz1cIk9wZXJhdGlvbnNcIlxuICAgICAgICBhY3Rpb25zPXtcbiAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17aGFuZGxlRXhwb3J0fT5cbiAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSBtci0xLjVcIiBzdHJva2VXaWR0aD17MS43fSAvPlxuICAgICAgICAgICAgRXhwb3J0IENTVlxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICB9XG4gICAgICAvPlxuXG4gICAgICB7LyogU3RhdHMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gZmxleCBtaW4taC0wIHctZnVsbCBtYXgtdy1bMTIwMHB4XSBmbGV4LTEgZmxleC1jb2wgZ2FwLTQgb3ZlcmZsb3ctaGlkZGVuIHB4LTYgcGItNiBwdC00XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgc2hyaW5rLTAgZ3JpZC1jb2xzLTIgZ2FwLTMgc206Z3JpZC1jb2xzLTRcIj5cbiAgICAgICAgPFN0YXRDYXJkIGljb249e0ZpbGVUZXh0fSAgIGxhYmVsPVwiQ2hhbmdlIFJlY29yZHNcIiAgIHZhbHVlPXsoY2hhbmdlcyA/PyBbXSkubGVuZ3RofSAvPlxuICAgICAgICA8U3RhdENhcmQgaWNvbj17U2hpZWxkQ2hlY2t9IGxhYmVsPVwiQXBwcm92YWwgUmVjb3Jkc1wiIHZhbHVlPXsoYXBwcm92YWxzID8/IFtdKS5sZW5ndGh9IC8+XG4gICAgICAgIDxTdGF0Q2FyZCBpY29uPXtDbG9ja30gICAgICBsYWJlbD1cIlBlbmRpbmcgQXBwcm92YWxzXCIgdmFsdWU9e3BlbmRpbmdDb3VudH0gYWNjZW50PXtwZW5kaW5nQ291bnQgPiAwID8gXCJ0ZXh0LXdhcm5cIiA6IHVuZGVmaW5lZH0gLz5cbiAgICAgICAgPFN0YXRDYXJkIGljb249e1hDaXJjbGV9ICAgIGxhYmVsPVwiRGVuaWVkIERlY2lzaW9uc1wiICB2YWx1ZT17ZGVuaWVkQ291bnR9ICBhY2NlbnQ9e2RlbmllZENvdW50ICA+IDAgPyBcInRleHQtZXJyXCIgIDogdW5kZWZpbmVkfSAvPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBtaW4taC0wIGZsZXgtMSBnYXAtNCBvdmVyZmxvdy1oaWRkZW4geGw6Z3JpZC1jb2xzLVttaW5tYXgoMCwxZnIpXzMyMHB4XVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLTAgZmxleC0xIGZsZXgtY29sIGdhcC00IG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICB7LyogQ2hhbmdlIHJlY29yZHMgKi99XG4gICAgICAgIDxUYWJsZVNlY3Rpb25cbiAgICAgICAgICB0aXRsZT1cIkNoYW5nZSBSZWNvcmRzXCJcbiAgICAgICAgICBlbXB0eT17KGNoYW5nZXMgPz8gW10pLmxlbmd0aCA9PT0gMH1cbiAgICAgICAgICBjb250cm9scz17XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggc2hyaW5rLTAgaXRlbXMtY2VudGVyIGdhcC0zIG92ZXJmbG93LXgtYXV0byBmbGV4LW5vd3JhcFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPEZpbHRlciBjbGFzc05hbWU9XCJoLTMgdy0zIHRleHQtaW5rLW11dGVkXCIgc3Ryb2tlV2lkdGg9ezEuNn0gLz5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgcHgtMyB0ZXh0LVsxMy41cHhdIHRleHQtaW5rIHBsYWNlaG9sZGVyOnRleHQtaW5rLW11dGVkIGZvY3VzLXZpc2libGU6b3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy1yaW5nIHctNDRcIlxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJGaWx0ZXIgYnkgdHlwZeKAplwiXG4gICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiRmlsdGVyIGNoYW5nZSByZWNvcmRzIGJ5IHR5cGVcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2NoYW5nZVR5cGVGaWx0ZXJ9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENoYW5nZVR5cGVGaWx0ZXIoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC05IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMSBweC0zIHRleHQtWzEzLjVweF0gdGV4dC1pbmsgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLXJpbmdcIlxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJSb3cgbGltaXRcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtsaW1pdH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldExpbWl0KE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17NTB9PjUwIHJvd3M8L29wdGlvbj5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXsxMDB9PjEwMCByb3dzPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17MjAwfT4yMDAgcm93czwvb3B0aW9uPlxuICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIH1cbiAgICAgICAgPlxuICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgbWluLXctWzk4MHB4XSBib3JkZXItY29sbGFwc2UgdGV4dC1sZWZ0IHRleHQtWzEzcHhdXCI+XG4gICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItbGluZVwiPlxuICAgICAgICAgICAgICAgIHtbXCJUaW1lXCIsIFwiVHlwZVwiLCBcIlN1bW1hcnlcIiwgXCJQcm9qZWN0XCIsIFwiSW5zdGFuY2VcIiwgXCJWZXJzaW9uXCIsIFwiUmVsYXRlZFwiXS5tYXAoKGgpID0+IChcbiAgICAgICAgICAgICAgICAgIDx0aCBrZXk9e2h9IGNsYXNzTmFtZT1cInB4LTQgcHktMi41IHRleHQtWzExLjVweF0gZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjA2ZW1dIHRleHQtaW5rLW11dGVkXCI+e2h9PC90aD5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgIHsoY2hhbmdlcyA/PyBbXSkubWFwKChjaGFuZ2UpID0+IChcbiAgICAgICAgICAgICAgICA8dHJcbiAgICAgICAgICAgICAgICAgIGtleT17Y2hhbmdlLl9pZH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1saW5lIGxhc3Q6Ym9yZGVyLWItMCBob3ZlcjpiZy1zdXJmYWNlLTIgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zLjUgdGV4dC1pbmstbXV0ZWQgd2hpdGVzcGFjZS1ub3dyYXAgZm9udC1tb25vXCI+e2ZtdFRpbWUoY2hhbmdlLnRpbWVzdGFtcCl9PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMuNVwiPjxTdGF0dXNQaWxsIHZhbHVlPXtjaGFuZ2UudHlwZX0gLz48L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMy41IHRleHQtaW5rLXNlY29uZGFyeSBtYXgtdy1bMjgwcHhdIHRydW5jYXRlXCI+e2NoYW5nZS5zdW1tYXJ5fTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zLjUgZm9udC1tb25vIHRleHQtaW5rLW11dGVkIHRydW5jYXRlIG1heC13LVsxNDBweF1cIj57Y2hhbmdlLnByb2plY3RJZCA/PyBcIm4vYVwifTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zLjUgZm9udC1tb25vIHRleHQtaW5rLW11dGVkIHRydW5jYXRlIG1heC13LVsxMjBweF1cIj57Y2hhbmdlLmluc3RhbmNlSWQgPz8gXCJuL2FcIn08L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMy41IGZvbnQtbW9ubyB0ZXh0LWluay1tdXRlZCB0cnVuY2F0ZSBtYXgtdy1bMTIwcHhdXCI+e2NoYW5nZS52ZXJzaW9uSWQgPz8gXCJuL2FcIn08L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMy41IHRleHQtaW5rLW11dGVkIHRydW5jYXRlIG1heC13LVsxODBweF1cIj5cbiAgICAgICAgICAgICAgICAgICAge2NoYW5nZS5yZWxhdGVkVGFibGUgPz8gXCJuL2FcIn17Y2hhbmdlLnJlbGF0ZWRJZCA/IGAgwrcgJHtjaGFuZ2UucmVsYXRlZElkfWAgOiBcIlwifVxuICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgPC9UYWJsZVNlY3Rpb24+XG5cbiAgICAgICAgey8qIEFwcHJvdmFsIHJlY29yZHMgKi99XG4gICAgICAgIDxUYWJsZVNlY3Rpb24gdGl0bGU9XCJBcHByb3ZhbCBSZWNvcmRzXCIgZW1wdHk9eyhhcHByb3ZhbHMgPz8gW10pLmxlbmd0aCA9PT0gMH0+XG4gICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCBtaW4tdy1bODQwcHhdIGJvcmRlci1jb2xsYXBzZSB0ZXh0LWxlZnQgdGV4dC1bMTNweF1cIj5cbiAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1saW5lXCI+XG4gICAgICAgICAgICAgICAge1tcIlJlcXVlc3RlZFwiLCBcIkFjdGlvblwiLCBcIlJpc2tcIiwgXCJTdGF0dXNcIiwgXCJEZWNpZGVkXCIsIFwiUmVhc29uXCJdLm1hcCgoaCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPHRoIGtleT17aH0gY2xhc3NOYW1lPVwicHgtNCBweS0yLjUgdGV4dC1bMTEuNXB4XSBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMDZlbV0gdGV4dC1pbmstbXV0ZWRcIj57aH08L3RoPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgeyhhcHByb3ZhbHMgPz8gW10pLm1hcCgoYXBwcm92YWwpID0+IChcbiAgICAgICAgICAgICAgICA8dHJcbiAgICAgICAgICAgICAgICAgIGtleT17YXBwcm92YWwuX2lkfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWxpbmUgbGFzdDpib3JkZXItYi0wIGhvdmVyOmJnLXN1cmZhY2UtMiB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMuNSB0ZXh0LWluay1tdXRlZCB3aGl0ZXNwYWNlLW5vd3JhcCBmb250LW1vbm9cIj57Zm10VGltZShhcHByb3ZhbC5yZXF1ZXN0ZWRBdCl9PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMuNSB0ZXh0LWluay1zZWNvbmRhcnlcIj57YXBwcm92YWwuYWN0aW9uVHlwZX08L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMy41XCI+PFN0YXR1c1BpbGwgdmFsdWU9e2FwcHJvdmFsLnJpc2tMZXZlbH0gLz48L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMy41XCI+PFN0YXR1c1BpbGwgdmFsdWU9e2FwcHJvdmFsLnN0YXR1c30gLz48L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMy41IHRleHQtaW5rLW11dGVkIHdoaXRlc3BhY2Utbm93cmFwIGZvbnQtbW9ub1wiPntmbXRUaW1lKGFwcHJvdmFsLmRlY2lkZWRBdCl9PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMuNSB0ZXh0LWluay1tdXRlZCB0cnVuY2F0ZSBtYXgtdy1bMjAwcHhdXCI+XG4gICAgICAgICAgICAgICAgICAgIHthcHByb3ZhbC5kZWNpc2lvblJlYXNvbiA/PyBhcHByb3ZhbC5qdXN0aWZpY2F0aW9uID8/IFwi4oCUXCJ9XG4gICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICA8L1RhYmxlU2VjdGlvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTVcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+QXVkaXQgZ3VpZGFuY2U8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIHNwYWNlLXktMyB0ZXh0LVsxMy41cHhdIGxlYWRpbmctcmVsYXhlZCB0ZXh0LWluay1zZWNvbmRhcnlcIj5cbiAgICAgICAgICA8cD5Vc2UgdGhpcyBzdXJmYWNlIHRvIGNvbmZpcm0gdGhhdCByaXNreSBhY3Rpb25zIHdlcmUgcmV2aWV3ZWQgYW5kIHRoYXQgdGhlIGRlY2lzaW9uIHRyYWlsIHN0aWxsIG1ha2VzIHNlbnNlIGFmdGVyIHRoZSBmYWN0LjwvcD5cbiAgICAgICAgICA8cD5JZiBhdWRpdCB2b2x1bWUgYmVjb21lcyBub2lzeSwgdGhlIHJlYWwgZml4IGlzIHRpZ2h0ZXIgcm91dGluZyBhbmQgYmV0dGVyIGNoYW5nZSBzdW1tYXJpZXMgdXBzdHJlYW0sIG5vdCBtb3JlIHJvd3MgaGVyZS48L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9DYXJkPlxuICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9BdWRpdFZpZXcudHN4In0=