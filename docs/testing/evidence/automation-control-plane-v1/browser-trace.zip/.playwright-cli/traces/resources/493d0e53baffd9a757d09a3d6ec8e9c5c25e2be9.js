import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_CONVEX_URL": "http://127.0.0.1:3214", "VITE_FLAG_CONTEXT_REGISTRY": "true", "VITE_FLAG_EOS_COMMAND_CENTER_PREVIEW": "true", "VITE_FLAG_UI_SHELL_V2": "true"};import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
export function useFlag(key) {
  const envKey = `VITE_FLAG_${key.replace(/[.-]/g, "_").toUpperCase()}`;
  const envValue = import.meta.env[envKey];
  const hasEnvOverride = envValue !== void 0;
  const remote = useQuery(
    api.featureFlags.isEnabled,
    hasEnvOverride ? "skip" : { key }
  );
  if (hasEnvOverride) {
    return envValue === "true" || envValue === "1";
  }
  return remote ?? false;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZUZsYWcudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5cbi8qKlxuICogRmVhdHVyZS1mbGFnIGhvb2suIFJlc29sdXRpb246XG4gKiAgIDEuIGBWSVRFX0ZMQUdfPEtFWT5gIGVudiBvdmVycmlkZSAoXCJ0cnVlXCIvXCIxXCIgPSBvbikg4oCUIGZvciBDSSBhbmQgbG9jYWwgZGV2XG4gKiAgIDIuIENvbnZleCBgZmVhdHVyZUZsYWdzYCB0YWJsZSAoZ2xvYmFsIHNjb3BlKVxuICogICAzLiBmYWxzZSB3aGlsZSBsb2FkaW5nIG9yIHdoZW4gdGhlIGZsYWcgaXMgdW5rbm93blxuICpcbiAqIEtleSB0cmFuc2Zvcm0gZm9yIHRoZSBlbnYgb3ZlcnJpZGU6IGRvdHMvZGFzaGVzIOKGkiB1bmRlcnNjb3JlcywgdXBwZXJjYXNlZC5cbiAqIGUuZy4gYHVpLnNoZWxsLnYyYCDihpIgYFZJVEVfRkxBR19VSV9TSEVMTF9WMmAuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VGbGFnKGtleTogc3RyaW5nKTogYm9vbGVhbiB7XG4gIGNvbnN0IGVudktleSA9IGBWSVRFX0ZMQUdfJHtrZXkucmVwbGFjZSgvWy4tXS9nLCBcIl9cIikudG9VcHBlckNhc2UoKX1gO1xuICBjb25zdCBlbnZWYWx1ZSA9IChcbiAgICBpbXBvcnQubWV0YS5lbnYgYXMgdW5rbm93biBhcyBSZWNvcmQ8c3RyaW5nLCBzdHJpbmcgfCB1bmRlZmluZWQ+XG4gIClbZW52S2V5XTtcbiAgY29uc3QgaGFzRW52T3ZlcnJpZGUgPSBlbnZWYWx1ZSAhPT0gdW5kZWZpbmVkO1xuXG4gIGNvbnN0IHJlbW90ZSA9IHVzZVF1ZXJ5KFxuICAgIGFwaS5mZWF0dXJlRmxhZ3MuaXNFbmFibGVkLFxuICAgIGhhc0Vudk92ZXJyaWRlID8gXCJza2lwXCIgOiB7IGtleSB9XG4gICk7XG5cbiAgaWYgKGhhc0Vudk92ZXJyaWRlKSB7XG4gICAgcmV0dXJuIGVudlZhbHVlID09PSBcInRydWVcIiB8fCBlbnZWYWx1ZSA9PT0gXCIxXCI7XG4gIH1cbiAgcmV0dXJuIHJlbW90ZSA/PyBmYWxzZTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxXQUFXO0FBV2IsZ0JBQVMsUUFBUSxLQUFzQjtBQUM1QyxRQUFNLFNBQVMsYUFBYSxJQUFJLFFBQVEsU0FBUyxHQUFHLEVBQUUsWUFBWSxDQUFDO0FBQ25FLFFBQU0sV0FDSixZQUFZLElBQ1osTUFBTTtBQUNSLFFBQU0saUJBQWlCLGFBQWE7QUFFcEMsUUFBTSxTQUFTO0FBQUEsSUFDYixJQUFJLGFBQWE7QUFBQSxJQUNqQixpQkFBaUIsU0FBUyxFQUFFLElBQUk7QUFBQSxFQUNsQztBQUVBLE1BQUksZ0JBQWdCO0FBQ2xCLFdBQU8sYUFBYSxVQUFVLGFBQWE7QUFBQSxFQUM3QztBQUNBLFNBQU8sVUFBVTtBQUNuQjsiLCJuYW1lcyI6W119