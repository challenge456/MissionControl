import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/BudgetBurnDown.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { cn } from "/src/lib/utils.ts";
import { PageHeader } from "/src/components/factory/DetailLayout.tsx";
import { MetricBlock, MetricRow } from "/src/components/factory/MetricBlock.tsx";
import { StatusBadge } from "/src/components/factory/badges.tsx";
function getSpendClasses(ratio) {
  if (ratio >= 1) return { text: "text-err", bg: "bg-err" };
  if (ratio >= 0.8) return { text: "text-warn", bg: "bg-warn" };
  return { text: "text-ok", bg: "bg-ok" };
}
function getStatusLabel(ratio) {
  if (ratio >= 1) return "Exceeded";
  if (ratio >= 0.8) return "Warning";
  if (ratio >= 0.5) return "On track";
  return "Healthy";
}
function getStatusTone(ratio) {
  if (ratio >= 1) return "error";
  if (ratio >= 0.8) return "warning";
  return "success";
}
export function BudgetBurnDown({ projectId }) {
  _s();
  const agents = useQuery(api.agents.listAll, projectId ? { projectId } : {});
  const budgetData = useMemo(() => {
    if (!agents) return null;
    const agentBudgets = agents.map((agent) => {
      const daily = agent.budgetDaily ?? 5;
      const spent = agent.spendToday ?? 0;
      const ratio = daily > 0 ? spent / daily : 0;
      return {
        id: agent._id,
        name: agent.name,
        role: agent.role ?? "UNKNOWN",
        status: agent.status,
        budgetDaily: daily,
        spendToday: spent,
        ratio,
        remaining: Math.max(0, daily - spent),
        classes: getSpendClasses(ratio),
        statusLabel: getStatusLabel(ratio),
        statusTone: getStatusTone(ratio)
      };
    });
    const totalBudget = agentBudgets.reduce((sum, a) => sum + a.budgetDaily, 0);
    const totalSpent = agentBudgets.reduce((sum, a) => sum + a.spendToday, 0);
    const activeCount = agentBudgets.filter((a) => a.status === "ACTIVE").length;
    const overBudgetCount = agentBudgets.filter((a) => a.ratio >= 1).length;
    const warningCount = agentBudgets.filter((a) => a.ratio >= 0.8 && a.ratio < 1).length;
    return {
      agents: agentBudgets.sort((a, b) => b.ratio - a.ratio),
      totalBudget,
      totalSpent,
      totalRatio: totalBudget > 0 ? totalSpent / totalBudget : 0,
      activeCount,
      overBudgetCount,
      warningCount
    };
  }, [agents]);
  if (!budgetData) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-0 flex-1 flex-col overflow-y-auto bg-app", children: [
      /* @__PURE__ */ jsxDEV(PageHeader, { title: "Budget burn-down", description: "Daily budget consumption across all agents" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
        lineNumber: 107,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mx-auto flex w-full max-w-[1200px] flex-col gap-3 px-6 py-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "h-4 w-48 animate-pulse rounded bg-surface-2" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
          lineNumber: 109,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "h-24 animate-pulse rounded-xl bg-surface-2" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
          lineNumber: 110,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
        lineNumber: 108,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
      lineNumber: 106,
      columnNumber: 7
    }, this);
  }
  const totalClasses = getSpendClasses(budgetData.totalRatio);
  return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-0 flex-1 flex-col overflow-y-auto bg-app", children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: "Budget burn-down", description: "Daily budget consumption across all agents" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
      lineNumber: 120,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mx-auto flex w-full max-w-[1200px] flex-col gap-6 px-6 py-6", children: [
      /* @__PURE__ */ jsxDEV(MetricRow, { className: "xl:grid-cols-6", children: [
        /* @__PURE__ */ jsxDEV(MetricBlock, { label: "Total budget", value: `$${budgetData.totalBudget.toFixed(2)}` }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
          lineNumber: 124,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Total spent",
            value: /* @__PURE__ */ jsxDEV("span", { className: totalClasses.text, children: [
              "$",
              budgetData.totalSpent.toFixed(2)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
              lineNumber: 128,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
            lineNumber: 125,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Remaining",
            value: `$${Math.max(0, budgetData.totalBudget - budgetData.totalSpent).toFixed(2)}`
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
            lineNumber: 131,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(MetricBlock, { label: "Active agents", value: budgetData.activeCount }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
          lineNumber: 135,
          columnNumber: 11
        }, this),
        budgetData.overBudgetCount > 0 && /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Over budget",
            value: budgetData.overBudgetCount,
            adornment: /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "error", children: "Exceeded" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
              lineNumber: 140,
              columnNumber: 24
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
            lineNumber: 137,
            columnNumber: 11
          },
          this
        ),
        budgetData.warningCount > 0 && /* @__PURE__ */ jsxDEV(
          MetricBlock,
          {
            label: "Warning",
            value: budgetData.warningCount,
            adornment: /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "warning", children: "80%+" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
              lineNumber: 147,
              columnNumber: 24
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
            lineNumber: 144,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
        lineNumber: 123,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-line bg-surface-1 p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-2 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-semibold text-ink", children: [
            "Overall: ",
            (budgetData.totalRatio * 100).toFixed(0),
            "% consumed"
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
            lineNumber: 155,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-[12.5px] text-ink-muted", children: [
            "$",
            budgetData.totalSpent.toFixed(2),
            " / $",
            budgetData.totalBudget.toFixed(2)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
            lineNumber: 158,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
          lineNumber: 154,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative h-2 overflow-hidden rounded-full bg-surface-2", children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: cn("absolute left-0 top-0 h-full rounded-full transition-[width] duration-200", totalClasses.bg),
              style: { width: `${Math.min(budgetData.totalRatio * 100, 100)}%` }
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
              lineNumber: 163,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-y-0 w-px bg-line-strong", style: { left: "80%" } }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
            lineNumber: 167,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
          lineNumber: 162,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
        lineNumber: 153,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2.5", children: budgetData.agents.map(
        (agent) => /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-line bg-surface-1 px-4 py-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2 flex flex-wrap items-center justify-between gap-1.5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[13px] font-semibold text-ink", children: agent.name }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
                lineNumber: 177,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] text-ink-muted", children: agent.role }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
                lineNumber: 178,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: cn(
                    "inline-block h-1.5 w-1.5 rounded-full",
                    agent.status === "ACTIVE" ? "bg-ok" : agent.status === "PAUSED" ? "bg-warn" : "bg-ink-muted"
                  ),
                  "aria-hidden": true
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
                  lineNumber: 179,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
              lineNumber: 176,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(StatusBadge, { tone: agent.statusTone, children: agent.statusLabel }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
                lineNumber: 192,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-[12.5px] text-ink-muted", children: [
                "$",
                agent.spendToday.toFixed(2),
                " / $",
                agent.budgetDaily.toFixed(2)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
                lineNumber: 193,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
              lineNumber: 191,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
            lineNumber: 175,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative h-1.5 overflow-hidden rounded-full bg-surface-2", children: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: cn("absolute left-0 top-0 h-full rounded-full transition-[width] duration-200", agent.classes.bg),
              style: { width: `${Math.min(agent.ratio * 100, 100)}%` }
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
              lineNumber: 199,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
            lineNumber: 198,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-1.5 flex justify-between", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] text-ink-muted", children: [
              "Remaining: $",
              agent.remaining.toFixed(2)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
              lineNumber: 205,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] text-ink-muted", children: [
              (agent.ratio * 100).toFixed(0),
              "% used"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
              lineNumber: 208,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
            lineNumber: 204,
            columnNumber: 15
          }, this)
        ] }, agent.id, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
          lineNumber: 174,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
        lineNumber: 172,
        columnNumber: 9
      }, this),
      budgetData.agents.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-line bg-surface-1 px-5 py-10 text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-ink-muted", children: "No agents found. Budget tracking will appear once agents are registered." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
        lineNumber: 218,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
        lineNumber: 217,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
      lineNumber: 121,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx",
    lineNumber: 119,
    columnNumber: 5
  }, this);
}
_s(BudgetBurnDown, "DDhP+1YoL3wSy4Jxe0mkXHfFBpg=", false, function() {
  return [useQuery];
});
_c = BudgetBurnDown;
var _c;
$RefreshReg$(_c, "BudgetBurnDown");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/BudgetBurnDown.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUZROzs7Ozs7Ozs7Ozs7Ozs7OztBQTlFUixTQUFTQSxlQUFlO0FBQ3hCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxXQUFXO0FBRXBCLFNBQVNDLFVBQVU7QUFDbkIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGFBQWFDLGlCQUFpQjtBQUN2QyxTQUFTQyxtQkFBMEM7QUFNbkQsU0FBU0MsZ0JBQWdCQyxPQUE2QztBQUNwRSxNQUFJQSxTQUFTLEVBQUcsUUFBTyxFQUFFQyxNQUFNLFlBQVlDLElBQUksU0FBUztBQUN4RCxNQUFJRixTQUFTLElBQUssUUFBTyxFQUFFQyxNQUFNLGFBQWFDLElBQUksVUFBVTtBQUM1RCxTQUFPLEVBQUVELE1BQU0sV0FBV0MsSUFBSSxRQUFRO0FBQ3hDO0FBRUEsU0FBU0MsZUFBZUgsT0FBdUI7QUFDN0MsTUFBSUEsU0FBUyxFQUFHLFFBQU87QUFDdkIsTUFBSUEsU0FBUyxJQUFLLFFBQU87QUFDekIsTUFBSUEsU0FBUyxJQUFLLFFBQU87QUFDekIsU0FBTztBQUNUO0FBRUEsU0FBU0ksY0FBY0osT0FBeUM7QUFDOUQsTUFBSUEsU0FBUyxFQUFHLFFBQU87QUFDdkIsTUFBSUEsU0FBUyxJQUFLLFFBQU87QUFDekIsU0FBTztBQUNUO0FBRU8sZ0JBQVNLLGVBQWUsRUFBRUMsVUFBK0IsR0FBRztBQUFBQyxLQUFBO0FBQ2pFLFFBQU1DLFNBQVNoQixTQUFTQyxJQUFJZSxPQUFPQyxTQUFTSCxZQUFZLEVBQUVBLFVBQVUsSUFBSSxDQUFDLENBQUM7QUFFMUUsUUFBTUksYUFBYW5CLFFBQVEsTUFBTTtBQUMvQixRQUFJLENBQUNpQixPQUFRLFFBQU87QUFFcEIsVUFBTUcsZUFBZUgsT0FBT0ksSUFBSSxDQUFDQyxVQUF5QjtBQUN4RCxZQUFNQyxRQUFTRCxNQUFjRSxlQUFlO0FBQzVDLFlBQU1DLFFBQVNILE1BQWNJLGNBQWM7QUFDM0MsWUFBTWpCLFFBQVFjLFFBQVEsSUFBSUUsUUFBUUYsUUFBUTtBQUUxQyxhQUFPO0FBQUEsUUFDTEksSUFBSUwsTUFBTU07QUFBQUEsUUFDVkMsTUFBTVAsTUFBTU87QUFBQUEsUUFDWkMsTUFBT1IsTUFBY1EsUUFBUTtBQUFBLFFBQzdCQyxRQUFRVCxNQUFNUztBQUFBQSxRQUNkUCxhQUFhRDtBQUFBQSxRQUNiRyxZQUFZRDtBQUFBQSxRQUNaaEI7QUFBQUEsUUFDQXVCLFdBQVdDLEtBQUtDLElBQUksR0FBR1gsUUFBUUUsS0FBSztBQUFBLFFBQ3BDVSxTQUFTM0IsZ0JBQWdCQyxLQUFLO0FBQUEsUUFDOUIyQixhQUFheEIsZUFBZUgsS0FBSztBQUFBLFFBQ2pDNEIsWUFBWXhCLGNBQWNKLEtBQUs7QUFBQSxNQUNqQztBQUFBLElBQ0YsQ0FBQztBQUVELFVBQU02QixjQUFjbEIsYUFBYW1CLE9BQU8sQ0FBQ0MsS0FBS0MsTUFBTUQsTUFBTUMsRUFBRWpCLGFBQWEsQ0FBQztBQUMxRSxVQUFNa0IsYUFBYXRCLGFBQWFtQixPQUFPLENBQUNDLEtBQUtDLE1BQU1ELE1BQU1DLEVBQUVmLFlBQVksQ0FBQztBQUN4RSxVQUFNaUIsY0FBY3ZCLGFBQWF3QixPQUFPLENBQUNILE1BQU1BLEVBQUVWLFdBQVcsUUFBUSxFQUFFYztBQUN0RSxVQUFNQyxrQkFBa0IxQixhQUFhd0IsT0FBTyxDQUFDSCxNQUFNQSxFQUFFaEMsU0FBUyxDQUFDLEVBQUVvQztBQUNqRSxVQUFNRSxlQUFlM0IsYUFBYXdCLE9BQU8sQ0FBQ0gsTUFBTUEsRUFBRWhDLFNBQVMsT0FBT2dDLEVBQUVoQyxRQUFRLENBQUMsRUFBRW9DO0FBRS9FLFdBQU87QUFBQSxNQUNMNUIsUUFBUUcsYUFBYTRCLEtBQUssQ0FBQ1AsR0FBR1EsTUFBTUEsRUFBRXhDLFFBQVFnQyxFQUFFaEMsS0FBSztBQUFBLE1BQ3JENkI7QUFBQUEsTUFDQUk7QUFBQUEsTUFDQVEsWUFBWVosY0FBYyxJQUFJSSxhQUFhSixjQUFjO0FBQUEsTUFDekRLO0FBQUFBLE1BQ0FHO0FBQUFBLE1BQ0FDO0FBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQUcsQ0FBQzlCLE1BQU0sQ0FBQztBQUVYLE1BQUksQ0FBQ0UsWUFBWTtBQUNmLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLHVEQUNiO0FBQUEsNkJBQUMsY0FBVyxPQUFNLG9CQUFtQixhQUFZLGdEQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZGO0FBQUEsTUFDN0YsdUJBQUMsU0FBSSxXQUFVLCtEQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGlEQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEQ7QUFBQSxRQUM1RCx1QkFBQyxTQUFJLFdBQVUsZ0RBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRDtBQUFBLFdBRjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsRUFFSjtBQUVBLFFBQU1nQyxlQUFlM0MsZ0JBQWdCVyxXQUFXK0IsVUFBVTtBQUUxRCxTQUNFLHVCQUFDLFNBQUksV0FBVSx1REFDYjtBQUFBLDJCQUFDLGNBQVcsT0FBTSxvQkFBbUIsYUFBWSxnREFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2RjtBQUFBLElBQzdGLHVCQUFDLFNBQUksV0FBVSwrREFFYjtBQUFBLDZCQUFDLGFBQVUsV0FBVSxrQkFDbkI7QUFBQSwrQkFBQyxlQUFZLE9BQU0sZ0JBQWUsT0FBTyxJQUFJL0IsV0FBV21CLFlBQVljLFFBQVEsQ0FBQyxDQUFDLE1BQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUY7QUFBQSxRQUNqRjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sT0FDRSx1QkFBQyxVQUFLLFdBQVdELGFBQWF6QyxNQUFNO0FBQUE7QUFBQSxjQUFFUyxXQUFXdUIsV0FBV1UsUUFBUSxDQUFDO0FBQUEsaUJBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVFO0FBQUE7QUFBQSxVQUgzRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJRztBQUFBLFFBRUg7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE9BQU8sSUFBSW5CLEtBQUtDLElBQUksR0FBR2YsV0FBV21CLGNBQWNuQixXQUFXdUIsVUFBVSxFQUFFVSxRQUFRLENBQUMsQ0FBQztBQUFBO0FBQUEsVUFGbkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRXNGO0FBQUEsUUFFdEYsdUJBQUMsZUFBWSxPQUFNLGlCQUFnQixPQUFPakMsV0FBV3dCLGVBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUU7QUFBQSxRQUNoRXhCLFdBQVcyQixrQkFBa0IsS0FDNUI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE9BQU8zQixXQUFXMkI7QUFBQUEsWUFDbEIsV0FBVyx1QkFBQyxlQUFZLE1BQUssU0FBUSx3QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0M7QUFBQTtBQUFBLFVBSC9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUc4RDtBQUFBLFFBRy9EM0IsV0FBVzRCLGVBQWUsS0FDekI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE9BQU81QixXQUFXNEI7QUFBQUEsWUFDbEIsV0FBVyx1QkFBQyxlQUFZLE1BQUssV0FBVSxvQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQTtBQUFBLFVBSDdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUc0RDtBQUFBLFdBeEJoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkJBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsc0NBQW9DO0FBQUE7QUFBQSxhQUN2QzVCLFdBQVcrQixhQUFhLEtBQUtFLFFBQVEsQ0FBQztBQUFBLFlBQUU7QUFBQSxlQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVUsMENBQXdDO0FBQUE7QUFBQSxZQUNwRGpDLFdBQVd1QixXQUFXVSxRQUFRLENBQUM7QUFBQSxZQUFFO0FBQUEsWUFBS2pDLFdBQVdtQixZQUFZYyxRQUFRLENBQUM7QUFBQSxlQUQxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwwREFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFXakQsR0FBRyw2RUFBNkVnRCxhQUFheEMsRUFBRTtBQUFBLGNBQzFHLE9BQU8sRUFBRTBDLE9BQU8sR0FBR3BCLEtBQUtxQixJQUFJbkMsV0FBVytCLGFBQWEsS0FBSyxHQUFHLENBQUMsSUFBSTtBQUFBO0FBQUEsWUFGbkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRXFFO0FBQUEsVUFFckUsdUJBQUMsU0FBSSxXQUFVLDBDQUF5QyxPQUFPLEVBQUVLLE1BQU0sTUFBTSxLQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLGFBTGpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFdBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNacEMscUJBQVdGLE9BQU9JO0FBQUFBLFFBQUksQ0FBQ0MsVUFDdEIsdUJBQUMsU0FBbUIsV0FBVSx3REFDNUI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsc0NBQXNDQSxnQkFBTU8sUUFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUU7QUFBQSxjQUNqRSx1QkFBQyxVQUFLLFdBQVUsZ0NBQWdDUCxnQkFBTVEsUUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkQ7QUFBQSxjQUMzRDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXM0I7QUFBQUEsb0JBQ1Q7QUFBQSxvQkFDQW1CLE1BQU1TLFdBQVcsV0FDYixVQUNBVCxNQUFNUyxXQUFXLFdBQ2YsWUFDQTtBQUFBLGtCQUNSO0FBQUEsa0JBQ0EsZUFBVztBQUFBO0FBQUEsZ0JBVGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBU2E7QUFBQSxpQkFaZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxlQUFZLE1BQU1ULE1BQU1lLFlBQWFmLGdCQUFNYyxlQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RDtBQUFBLGNBQ3hELHVCQUFDLFVBQUssV0FBVSwwQ0FBd0M7QUFBQTtBQUFBLGdCQUNwRGQsTUFBTUksV0FBVzBCLFFBQVEsQ0FBQztBQUFBLGdCQUFFO0FBQUEsZ0JBQUs5QixNQUFNRSxZQUFZNEIsUUFBUSxDQUFDO0FBQUEsbUJBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBV2pELEdBQUcsNkVBQTZFbUIsTUFBTWEsUUFBUXhCLEVBQUU7QUFBQSxjQUMzRyxPQUFPLEVBQUUwQyxPQUFPLEdBQUdwQixLQUFLcUIsSUFBSWhDLE1BQU1iLFFBQVEsS0FBSyxHQUFHLENBQUMsSUFBSTtBQUFBO0FBQUEsWUFGekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRTJELEtBSDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSw4QkFBNEI7QUFBQTtBQUFBLGNBQzdCYSxNQUFNVSxVQUFVb0IsUUFBUSxDQUFDO0FBQUEsaUJBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSw4QkFDWjlCO0FBQUFBLHFCQUFNYixRQUFRLEtBQUsyQyxRQUFRLENBQUM7QUFBQSxjQUFFO0FBQUEsaUJBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxhQXJDUTlCLE1BQU1LLElBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQ0E7QUFBQSxNQUNELEtBekNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwQ0E7QUFBQSxNQUVDUixXQUFXRixPQUFPNEIsV0FBVyxLQUM1Qix1QkFBQyxTQUFJLFdBQVUscUVBQ2IsaUNBQUMsT0FBRSxXQUFVLDhCQUE0Qix3RkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsU0FwR0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNHQTtBQUFBLE9BeEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5R0E7QUFFSjtBQUFDN0IsR0FyS2VGLGdCQUFjO0FBQUEsVUFDYmIsUUFBUTtBQUFBO0FBQUEsS0FEVGE7QUFBYyxJQUFBMEM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsInVzZVF1ZXJ5IiwiYXBpIiwiY24iLCJQYWdlSGVhZGVyIiwiTWV0cmljQmxvY2siLCJNZXRyaWNSb3ciLCJTdGF0dXNCYWRnZSIsImdldFNwZW5kQ2xhc3NlcyIsInJhdGlvIiwidGV4dCIsImJnIiwiZ2V0U3RhdHVzTGFiZWwiLCJnZXRTdGF0dXNUb25lIiwiQnVkZ2V0QnVybkRvd24iLCJwcm9qZWN0SWQiLCJfcyIsImFnZW50cyIsImxpc3RBbGwiLCJidWRnZXREYXRhIiwiYWdlbnRCdWRnZXRzIiwibWFwIiwiYWdlbnQiLCJkYWlseSIsImJ1ZGdldERhaWx5Iiwic3BlbnQiLCJzcGVuZFRvZGF5IiwiaWQiLCJfaWQiLCJuYW1lIiwicm9sZSIsInN0YXR1cyIsInJlbWFpbmluZyIsIk1hdGgiLCJtYXgiLCJjbGFzc2VzIiwic3RhdHVzTGFiZWwiLCJzdGF0dXNUb25lIiwidG90YWxCdWRnZXQiLCJyZWR1Y2UiLCJzdW0iLCJhIiwidG90YWxTcGVudCIsImFjdGl2ZUNvdW50IiwiZmlsdGVyIiwibGVuZ3RoIiwib3ZlckJ1ZGdldENvdW50Iiwid2FybmluZ0NvdW50Iiwic29ydCIsImIiLCJ0b3RhbFJhdGlvIiwidG90YWxDbGFzc2VzIiwidG9GaXhlZCIsIndpZHRoIiwibWluIiwibGVmdCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJ1ZGdldEJ1cm5Eb3duLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEJ1ZGdldCBCdXJuLURvd24gRGFzaGJvYXJkXG4gKlxuICogU2hvd3MgcGVyLWFnZW50IGFuZCBhZ2dyZWdhdGUgYnVkZ2V0IGNvbnN1bXB0aW9uOlxuICogICAtIERhaWx5IGJ1ZGdldCBjYXAgdnMuIGFjdHVhbCBzcGVuZCBwZXIgYWdlbnRcbiAqICAgLSBBZ2dyZWdhdGUgcHJvamVjdC13aWRlIGJ1cm4gcmF0ZVxuICogICAtIEFsZXJ0cyB3aGVuIGFnZW50cyBhcHByb2FjaCBvciBleGNlZWQgYnVkZ2V0XG4gKi9cblxuaW1wb3J0IHsgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkLCBEb2MgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvZGF0YU1vZGVsXCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiO1xuaW1wb3J0IHsgUGFnZUhlYWRlciB9IGZyb20gXCIuL2NvbXBvbmVudHMvZmFjdG9yeS9EZXRhaWxMYXlvdXRcIjtcbmltcG9ydCB7IE1ldHJpY0Jsb2NrLCBNZXRyaWNSb3cgfSBmcm9tIFwiLi9jb21wb25lbnRzL2ZhY3RvcnkvTWV0cmljQmxvY2tcIjtcbmltcG9ydCB7IFN0YXR1c0JhZGdlLCB0eXBlIFN0YXR1c0JhZGdlUHJvcHMgfSBmcm9tIFwiLi9jb21wb25lbnRzL2ZhY3RvcnkvYmFkZ2VzXCI7XG5cbmludGVyZmFjZSBCdWRnZXRCdXJuRG93blByb3BzIHtcbiAgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+IHwgbnVsbDtcbn1cblxuZnVuY3Rpb24gZ2V0U3BlbmRDbGFzc2VzKHJhdGlvOiBudW1iZXIpOiB7IHRleHQ6IHN0cmluZzsgYmc6IHN0cmluZyB9IHtcbiAgaWYgKHJhdGlvID49IDEpIHJldHVybiB7IHRleHQ6IFwidGV4dC1lcnJcIiwgYmc6IFwiYmctZXJyXCIgfTtcbiAgaWYgKHJhdGlvID49IDAuOCkgcmV0dXJuIHsgdGV4dDogXCJ0ZXh0LXdhcm5cIiwgYmc6IFwiYmctd2FyblwiIH07XG4gIHJldHVybiB7IHRleHQ6IFwidGV4dC1va1wiLCBiZzogXCJiZy1va1wiIH07XG59XG5cbmZ1bmN0aW9uIGdldFN0YXR1c0xhYmVsKHJhdGlvOiBudW1iZXIpOiBzdHJpbmcge1xuICBpZiAocmF0aW8gPj0gMSkgcmV0dXJuIFwiRXhjZWVkZWRcIjtcbiAgaWYgKHJhdGlvID49IDAuOCkgcmV0dXJuIFwiV2FybmluZ1wiO1xuICBpZiAocmF0aW8gPj0gMC41KSByZXR1cm4gXCJPbiB0cmFja1wiO1xuICByZXR1cm4gXCJIZWFsdGh5XCI7XG59XG5cbmZ1bmN0aW9uIGdldFN0YXR1c1RvbmUocmF0aW86IG51bWJlcik6IFN0YXR1c0JhZGdlUHJvcHNbXCJ0b25lXCJdIHtcbiAgaWYgKHJhdGlvID49IDEpIHJldHVybiBcImVycm9yXCI7XG4gIGlmIChyYXRpbyA+PSAwLjgpIHJldHVybiBcIndhcm5pbmdcIjtcbiAgcmV0dXJuIFwic3VjY2Vzc1wiO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQnVkZ2V0QnVybkRvd24oeyBwcm9qZWN0SWQgfTogQnVkZ2V0QnVybkRvd25Qcm9wcykge1xuICBjb25zdCBhZ2VudHMgPSB1c2VRdWVyeShhcGkuYWdlbnRzLmxpc3RBbGwsIHByb2plY3RJZCA/IHsgcHJvamVjdElkIH0gOiB7fSk7XG5cbiAgY29uc3QgYnVkZ2V0RGF0YSA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGlmICghYWdlbnRzKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IGFnZW50QnVkZ2V0cyA9IGFnZW50cy5tYXAoKGFnZW50OiBEb2M8XCJhZ2VudHNcIj4pID0+IHtcbiAgICAgIGNvbnN0IGRhaWx5ID0gKGFnZW50IGFzIGFueSkuYnVkZ2V0RGFpbHkgPz8gNTtcbiAgICAgIGNvbnN0IHNwZW50ID0gKGFnZW50IGFzIGFueSkuc3BlbmRUb2RheSA/PyAwO1xuICAgICAgY29uc3QgcmF0aW8gPSBkYWlseSA+IDAgPyBzcGVudCAvIGRhaWx5IDogMDtcblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgaWQ6IGFnZW50Ll9pZCxcbiAgICAgICAgbmFtZTogYWdlbnQubmFtZSxcbiAgICAgICAgcm9sZTogKGFnZW50IGFzIGFueSkucm9sZSA/PyBcIlVOS05PV05cIixcbiAgICAgICAgc3RhdHVzOiBhZ2VudC5zdGF0dXMsXG4gICAgICAgIGJ1ZGdldERhaWx5OiBkYWlseSxcbiAgICAgICAgc3BlbmRUb2RheTogc3BlbnQsXG4gICAgICAgIHJhdGlvLFxuICAgICAgICByZW1haW5pbmc6IE1hdGgubWF4KDAsIGRhaWx5IC0gc3BlbnQpLFxuICAgICAgICBjbGFzc2VzOiBnZXRTcGVuZENsYXNzZXMocmF0aW8pLFxuICAgICAgICBzdGF0dXNMYWJlbDogZ2V0U3RhdHVzTGFiZWwocmF0aW8pLFxuICAgICAgICBzdGF0dXNUb25lOiBnZXRTdGF0dXNUb25lKHJhdGlvKSxcbiAgICAgIH07XG4gICAgfSk7XG5cbiAgICBjb25zdCB0b3RhbEJ1ZGdldCA9IGFnZW50QnVkZ2V0cy5yZWR1Y2UoKHN1bSwgYSkgPT4gc3VtICsgYS5idWRnZXREYWlseSwgMCk7XG4gICAgY29uc3QgdG90YWxTcGVudCA9IGFnZW50QnVkZ2V0cy5yZWR1Y2UoKHN1bSwgYSkgPT4gc3VtICsgYS5zcGVuZFRvZGF5LCAwKTtcbiAgICBjb25zdCBhY3RpdmVDb3VudCA9IGFnZW50QnVkZ2V0cy5maWx0ZXIoKGEpID0+IGEuc3RhdHVzID09PSBcIkFDVElWRVwiKS5sZW5ndGg7XG4gICAgY29uc3Qgb3ZlckJ1ZGdldENvdW50ID0gYWdlbnRCdWRnZXRzLmZpbHRlcigoYSkgPT4gYS5yYXRpbyA+PSAxKS5sZW5ndGg7XG4gICAgY29uc3Qgd2FybmluZ0NvdW50ID0gYWdlbnRCdWRnZXRzLmZpbHRlcigoYSkgPT4gYS5yYXRpbyA+PSAwLjggJiYgYS5yYXRpbyA8IDEpLmxlbmd0aDtcblxuICAgIHJldHVybiB7XG4gICAgICBhZ2VudHM6IGFnZW50QnVkZ2V0cy5zb3J0KChhLCBiKSA9PiBiLnJhdGlvIC0gYS5yYXRpbyksXG4gICAgICB0b3RhbEJ1ZGdldCxcbiAgICAgIHRvdGFsU3BlbnQsXG4gICAgICB0b3RhbFJhdGlvOiB0b3RhbEJ1ZGdldCA+IDAgPyB0b3RhbFNwZW50IC8gdG90YWxCdWRnZXQgOiAwLFxuICAgICAgYWN0aXZlQ291bnQsXG4gICAgICBvdmVyQnVkZ2V0Q291bnQsXG4gICAgICB3YXJuaW5nQ291bnQsXG4gICAgfTtcbiAgfSwgW2FnZW50c10pO1xuXG4gIGlmICghYnVkZ2V0RGF0YSkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtMCBmbGV4LTEgZmxleC1jb2wgb3ZlcmZsb3cteS1hdXRvIGJnLWFwcFwiPlxuICAgICAgICA8UGFnZUhlYWRlciB0aXRsZT1cIkJ1ZGdldCBidXJuLWRvd25cIiBkZXNjcmlwdGlvbj1cIkRhaWx5IGJ1ZGdldCBjb25zdW1wdGlvbiBhY3Jvc3MgYWxsIGFnZW50c1wiIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXgtYXV0byBmbGV4IHctZnVsbCBtYXgtdy1bMTIwMHB4XSBmbGV4LWNvbCBnYXAtMyBweC02IHB5LTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtNCB3LTQ4IGFuaW1hdGUtcHVsc2Ugcm91bmRlZCBiZy1zdXJmYWNlLTJcIiAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0yNCBhbmltYXRlLXB1bHNlIHJvdW5kZWQteGwgYmctc3VyZmFjZS0yXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgY29uc3QgdG90YWxDbGFzc2VzID0gZ2V0U3BlbmRDbGFzc2VzKGJ1ZGdldERhdGEudG90YWxSYXRpbyk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtMCBmbGV4LTEgZmxleC1jb2wgb3ZlcmZsb3cteS1hdXRvIGJnLWFwcFwiPlxuICAgICAgPFBhZ2VIZWFkZXIgdGl0bGU9XCJCdWRnZXQgYnVybi1kb3duXCIgZGVzY3JpcHRpb249XCJEYWlseSBidWRnZXQgY29uc3VtcHRpb24gYWNyb3NzIGFsbCBhZ2VudHNcIiAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIGZsZXggdy1mdWxsIG1heC13LVsxMjAwcHhdIGZsZXgtY29sIGdhcC02IHB4LTYgcHktNlwiPlxuICAgICAgICB7LyogQWdncmVnYXRlIFN1bW1hcnkgKi99XG4gICAgICAgIDxNZXRyaWNSb3cgY2xhc3NOYW1lPVwieGw6Z3JpZC1jb2xzLTZcIj5cbiAgICAgICAgICA8TWV0cmljQmxvY2sgbGFiZWw9XCJUb3RhbCBidWRnZXRcIiB2YWx1ZT17YCQke2J1ZGdldERhdGEudG90YWxCdWRnZXQudG9GaXhlZCgyKX1gfSAvPlxuICAgICAgICAgIDxNZXRyaWNCbG9ja1xuICAgICAgICAgICAgbGFiZWw9XCJUb3RhbCBzcGVudFwiXG4gICAgICAgICAgICB2YWx1ZT17XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17dG90YWxDbGFzc2VzLnRleHR9PiR7YnVkZ2V0RGF0YS50b3RhbFNwZW50LnRvRml4ZWQoMil9PC9zcGFuPlxuICAgICAgICAgICAgfVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPE1ldHJpY0Jsb2NrXG4gICAgICAgICAgICBsYWJlbD1cIlJlbWFpbmluZ1wiXG4gICAgICAgICAgICB2YWx1ZT17YCQke01hdGgubWF4KDAsIGJ1ZGdldERhdGEudG90YWxCdWRnZXQgLSBidWRnZXREYXRhLnRvdGFsU3BlbnQpLnRvRml4ZWQoMil9YH1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxNZXRyaWNCbG9jayBsYWJlbD1cIkFjdGl2ZSBhZ2VudHNcIiB2YWx1ZT17YnVkZ2V0RGF0YS5hY3RpdmVDb3VudH0gLz5cbiAgICAgICAgICB7YnVkZ2V0RGF0YS5vdmVyQnVkZ2V0Q291bnQgPiAwICYmIChcbiAgICAgICAgICAgIDxNZXRyaWNCbG9ja1xuICAgICAgICAgICAgICBsYWJlbD1cIk92ZXIgYnVkZ2V0XCJcbiAgICAgICAgICAgICAgdmFsdWU9e2J1ZGdldERhdGEub3ZlckJ1ZGdldENvdW50fVxuICAgICAgICAgICAgICBhZG9ybm1lbnQ9ezxTdGF0dXNCYWRnZSB0b25lPVwiZXJyb3JcIj5FeGNlZWRlZDwvU3RhdHVzQmFkZ2U+fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApfVxuICAgICAgICAgIHtidWRnZXREYXRhLndhcm5pbmdDb3VudCA+IDAgJiYgKFxuICAgICAgICAgICAgPE1ldHJpY0Jsb2NrXG4gICAgICAgICAgICAgIGxhYmVsPVwiV2FybmluZ1wiXG4gICAgICAgICAgICAgIHZhbHVlPXtidWRnZXREYXRhLndhcm5pbmdDb3VudH1cbiAgICAgICAgICAgICAgYWRvcm5tZW50PXs8U3RhdHVzQmFkZ2UgdG9uZT1cIndhcm5pbmdcIj44MCUrPC9TdGF0dXNCYWRnZT59XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvTWV0cmljUm93PlxuXG4gICAgICAgIHsvKiBBZ2dyZWdhdGUgUHJvZ3Jlc3MgQmFyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMSBwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+XG4gICAgICAgICAgICAgIE92ZXJhbGw6IHsoYnVkZ2V0RGF0YS50b3RhbFJhdGlvICogMTAwKS50b0ZpeGVkKDApfSUgY29uc3VtZWRcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LVsxMi41cHhdIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAgICAgICR7YnVkZ2V0RGF0YS50b3RhbFNwZW50LnRvRml4ZWQoMil9IC8gJHtidWRnZXREYXRhLnRvdGFsQnVkZ2V0LnRvRml4ZWQoMil9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBoLTIgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtZnVsbCBiZy1zdXJmYWNlLTJcIj5cbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcImFic29sdXRlIGxlZnQtMCB0b3AtMCBoLWZ1bGwgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tW3dpZHRoXSBkdXJhdGlvbi0yMDBcIiwgdG90YWxDbGFzc2VzLmJnKX1cbiAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAke01hdGgubWluKGJ1ZGdldERhdGEudG90YWxSYXRpbyAqIDEwMCwgMTAwKX0lYCB9fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIHctcHggYmctbGluZS1zdHJvbmdcIiBzdHlsZT17eyBsZWZ0OiBcIjgwJVwiIH19IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBQZXItQWdlbnQgQnJlYWtkb3duICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTIuNVwiPlxuICAgICAgICAgIHtidWRnZXREYXRhLmFnZW50cy5tYXAoKGFnZW50KSA9PiAoXG4gICAgICAgICAgICA8ZGl2IGtleT17YWdlbnQuaWR9IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMSBweC00IHB5LTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yIGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj57YWdlbnQubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMS41cHhdIHRleHQtaW5rLW11dGVkXCI+e2FnZW50LnJvbGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICBcImlubGluZS1ibG9jayBoLTEuNSB3LTEuNSByb3VuZGVkLWZ1bGxcIixcbiAgICAgICAgICAgICAgICAgICAgICBhZ2VudC5zdGF0dXMgPT09IFwiQUNUSVZFXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1va1wiXG4gICAgICAgICAgICAgICAgICAgICAgICA6IGFnZW50LnN0YXR1cyA9PT0gXCJQQVVTRURcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctd2FyblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1pbmstbXV0ZWRcIlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICBhcmlhLWhpZGRlblxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8U3RhdHVzQmFkZ2UgdG9uZT17YWdlbnQuc3RhdHVzVG9uZX0+e2FnZW50LnN0YXR1c0xhYmVsfTwvU3RhdHVzQmFkZ2U+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAke2FnZW50LnNwZW5kVG9kYXkudG9GaXhlZCgyKX0gLyAke2FnZW50LmJ1ZGdldERhaWx5LnRvRml4ZWQoMil9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtMS41IG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLWZ1bGwgYmctc3VyZmFjZS0yXCI+XG4gICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcImFic29sdXRlIGxlZnQtMCB0b3AtMCBoLWZ1bGwgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tW3dpZHRoXSBkdXJhdGlvbi0yMDBcIiwgYWdlbnQuY2xhc3Nlcy5iZyl9XG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7TWF0aC5taW4oYWdlbnQucmF0aW8gKiAxMDAsIDEwMCl9JWAgfX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xLjUgZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgUmVtYWluaW5nOiAke2FnZW50LnJlbWFpbmluZy50b0ZpeGVkKDIpfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgeyhhZ2VudC5yYXRpbyAqIDEwMCkudG9GaXhlZCgwKX0lIHVzZWRcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHtidWRnZXREYXRhLmFnZW50cy5sZW5ndGggPT09IDAgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xIHB4LTUgcHktMTAgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAgICAgIE5vIGFnZW50cyBmb3VuZC4gQnVkZ2V0IHRyYWNraW5nIHdpbGwgYXBwZWFyIG9uY2UgYWdlbnRzIGFyZSByZWdpc3RlcmVkLlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9CdWRnZXRCdXJuRG93bi50c3gifQ==