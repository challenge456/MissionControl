import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/CreateAgentModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { cn } from "/src/lib/utils.ts";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "/src/components/ui/dialog.tsx";
import { ScrollArea } from "/src/components/ui/scroll-area.tsx";
import { Shield, Wrench } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
export const defaultCreateForm = {
  name: "",
  emoji: "",
  role: "SPECIALIST",
  workspacePath: "/workspace",
  allowedTaskTypes: "",
  allowedTools: "",
  budgetDaily: "",
  budgetPerRun: "",
  canSpawn: false,
  maxSubAgents: "0",
  email: "",
  telegram: "",
  whatsapp: "",
  discord: ""
};
const roleOptions = [
  { value: "INTERN", label: "Intern", desc: "Limited access, lower budget ($2/day)" },
  { value: "SPECIALIST", label: "Specialist", desc: "Standard agent, focused tasks ($5/day)" },
  { value: "LEAD", label: "Lead", desc: "Full access, coordination role ($12/day)" }
];
const TOOL_PRESETS = [
  { label: "Read-only", value: "read,web_fetch" },
  { label: "Code", value: "read,write,shell,git,convex" },
  { label: "Research", value: "read,web_search,web_fetch,planner" },
  { label: "Full", value: "read,write,shell,web_search,web_fetch,git,github,convex,tasks,content,planner" }
];
function ModalSection({ title, children }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "pt-5 pb-4 border-b border-border last:border-b-0", children: [
    /* @__PURE__ */ jsxDEV("h3", { className: "text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3", children: title }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
      lineNumber: 91,
      columnNumber: 7
    }, this),
    children
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
    lineNumber: 90,
    columnNumber: 5
  }, this);
}
_c = ModalSection;
export function CreateAgentModal({
  open,
  projectId,
  parentAgentId,
  onClose,
  onCreate
}) {
  _s();
  const [form, setForm] = useState({ ...defaultCreateForm });
  const [submitting, setSubmitting] = useState(false);
  const update = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };
  const canSubmit = form.name.trim().length > 0 && form.role && form.workspacePath.trim().length > 0;
  const handleSubmit = async () => {
    if (!canSubmit || submitting) return;
    setSubmitting(true);
    try {
      await onCreate(form);
      setForm({ ...defaultCreateForm });
      onClose();
    } catch {
    } finally {
      setSubmitting(false);
    }
  };
  const handleOpenChange = (v) => {
    if (!v) onClose();
  };
  return /* @__PURE__ */ jsxDEV(Dialog, { open, onOpenChange: handleOpenChange, children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "max-w-[560px] max-h-[90vh] flex flex-col p-0", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { className: "px-6 py-5 border-b border-border", children: /* @__PURE__ */ jsxDEV(DialogTitle, { children: parentAgentId ? "Add Sub-Agent" : "Create Agent" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
      lineNumber: 143,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
      lineNumber: 142,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(ScrollArea, { className: "flex-1 px-6", children: [
      /* @__PURE__ */ jsxDEV(ModalSection, { title: "Identity", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs text-muted-foreground mb-1", children: "Name *" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 150,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: form.name, onChange: (e) => update("name", e.target.value), placeholder: "e.g. Research Agent", autoFocus: true }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 151,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
          lineNumber: 149,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-20", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs text-muted-foreground mb-1", children: "Emoji" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 154,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: form.emoji, onChange: (e) => update("emoji", e.target.value), placeholder: "🤖" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 155,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
          lineNumber: 153,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
        lineNumber: 148,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
        lineNumber: 147,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(ModalSection, { title: "Role", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2", children: roleOptions.map(
        (opt) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => update("role", opt.value),
            className: cn(
              "p-3 rounded-lg border text-left transition-colors",
              form.role === opt.value ? "border-primary bg-primary/5" : "border-border bg-background hover:bg-muted"
            ),
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-sm text-foreground", children: opt.label }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
                  lineNumber: 173,
                  columnNumber: 21
                }, this),
                form.role === opt.value && /* @__PURE__ */ jsxDEV("span", { className: "text-primary text-sm", children: "✓" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
                  lineNumber: 174,
                  columnNumber: 49
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
                lineNumber: 172,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-muted-foreground mt-0.5", children: opt.desc }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
                lineNumber: 176,
                columnNumber: 19
              }, this)
            ]
          },
          opt.value,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 163,
            columnNumber: 15
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
        lineNumber: 161,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
        lineNumber: 160,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(ModalSection, { title: "Configuration", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs text-muted-foreground mb-1", children: "Workspace Path *" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 184,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { value: form.workspacePath, onChange: (e) => update("workspacePath", e.target.value), placeholder: "/workspace" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 185,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
          lineNumber: 183,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs text-muted-foreground mb-1", children: "Allowed Task Types" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 188,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              value: form.allowedTaskTypes,
              onChange: (e) => update("allowedTaskTypes", e.target.value),
              placeholder: "ENGINEERING, CONTENT, OPS (comma-separated)"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
              lineNumber: 189,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted-foreground mt-1", children: "Leave empty to allow all" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 194,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
          lineNumber: 187,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
        lineNumber: 182,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(ModalSection, { title: "Tool policy (allowed tools)", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 mb-2", children: TOOL_PRESETS.map(
          (preset) => /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "button",
              variant: "outline",
              size: "sm",
              className: "h-7 text-xs",
              onClick: () => update("allowedTools", preset.value),
              children: [
                /* @__PURE__ */ jsxDEV(Wrench, { className: "h-3 w-3 mr-1" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
                  lineNumber: 209,
                  columnNumber: 19
                }, this),
                preset.label
              ]
            },
            preset.label,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
              lineNumber: 201,
              columnNumber: 15
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
          lineNumber: 199,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            value: form.allowedTools,
            onChange: (e) => update("allowedTools", e.target.value),
            placeholder: "read, write, shell, web_search, git (comma-separated)"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 214,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted-foreground mt-1", children: "Allowlist only. RED-risk tool calls require human approval below." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
          lineNumber: 219,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
        lineNumber: 198,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(ModalSection, { title: "Exec approvals", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 rounded-lg border border-border bg-muted/30 p-3", children: [
        /* @__PURE__ */ jsxDEV(Shield, { className: "h-4 w-4 text-primary shrink-0 mt-0.5" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
          lineNumber: 224,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-muted-foreground", children: "High-risk (RED) tool calls—e.g. destructive or external writes—require human approval before the agent can proceed. Approve or deny from the Approvals center (top bar)." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
          lineNumber: 225,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
        lineNumber: 223,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
        lineNumber: 222,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(ModalSection, { title: "Budget", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted-foreground mb-3", children: "Leave empty for role defaults" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
          lineNumber: 232,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs text-muted-foreground mb-1", children: "Daily ($)" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
              lineNumber: 235,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                value: form.budgetDaily,
                onChange: (e) => update("budgetDaily", e.target.value),
                placeholder: form.role === "LEAD" ? "12" : form.role === "SPECIALIST" ? "5" : "2",
                step: "0.50"
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
                lineNumber: 236,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 234,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs text-muted-foreground mb-1", children: "Per run ($)" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
              lineNumber: 245,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                value: form.budgetPerRun,
                onChange: (e) => update("budgetPerRun", e.target.value),
                placeholder: form.role === "LEAD" ? "1.50" : form.role === "SPECIALIST" ? "0.75" : "0.25",
                step: "0.25"
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
                lineNumber: 246,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 244,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
          lineNumber: 233,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
        lineNumber: 231,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(ModalSection, { title: "Contact (optional)", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs text-muted-foreground mb-1", children: "Email" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 259,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { type: "email", value: form.email, onChange: (e) => update("email", e.target.value), placeholder: "agent@example.com" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 260,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
          lineNumber: 258,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs text-muted-foreground mb-1", children: "Telegram" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
              lineNumber: 264,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { value: form.telegram, onChange: (e) => update("telegram", e.target.value), placeholder: "@username" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
              lineNumber: 265,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 263,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs text-muted-foreground mb-1", children: "WhatsApp" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
              lineNumber: 268,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { value: form.whatsapp, onChange: (e) => update("whatsapp", e.target.value), placeholder: "+1234567890" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
              lineNumber: 269,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 267,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
          lineNumber: 262,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
        lineNumber: 257,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(ModalSection, { title: "Sub-agent spawning", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-3", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => update("canSpawn", !form.canSpawn),
              className: cn(
                "relative w-10 h-6 rounded-full transition-colors shrink-0",
                form.canSpawn ? "bg-primary" : "bg-border"
              ),
              "aria-label": "Toggle sub-agent spawning",
              children: /* @__PURE__ */ jsxDEV("div", { className: cn("absolute top-[3px] left-[3px] w-4.5 h-4.5 rounded-full bg-white transition-transform", form.canSpawn && "translate-x-4") }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
                lineNumber: 285,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
              lineNumber: 276,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-foreground", children: "Can spawn sub-agents" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 287,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
          lineNumber: 275,
          columnNumber: 13
        }, this),
        form.canSpawn && /* @__PURE__ */ jsxDEV("div", { className: "w-[120px]", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs text-muted-foreground mb-1", children: "Max sub-agents" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 291,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { type: "number", value: form.maxSubAgents, onChange: (e) => update("maxSubAgents", e.target.value), min: 0, max: 10 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
            lineNumber: 292,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
          lineNumber: 290,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
        lineNumber: 274,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
      lineNumber: 146,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DialogFooter, { className: "px-6 py-4 border-t border-border", children: [
      /* @__PURE__ */ jsxDEV(Button, { onClick: handleSubmit, disabled: !canSubmit || submitting, children: submitting ? "Creating…" : "Create Agent" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
        lineNumber: 299,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "outline", onClick: onClose, disabled: submitting, children: "Cancel" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
        lineNumber: 302,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
      lineNumber: 298,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
    lineNumber: 141,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx",
    lineNumber: 140,
    columnNumber: 5
  }, this);
}
_s(CreateAgentModal, "zTnsFneis7BCivY9PRVImQV4u2E=");
_c2 = CreateAgentModal;
var _c, _c2;
$RefreshReg$(_c, "ModalSection");
$RefreshReg$(_c2, "CreateAgentModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/CreateAgentModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUVNOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpFTixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGFBQWE7QUFDdEI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLFFBQVFDLGNBQWM7QUFvQnhCLGFBQU1DLG9CQUFxQztBQUFBLEVBQ2hEQyxNQUFNO0FBQUEsRUFDTkMsT0FBTztBQUFBLEVBQ1BDLE1BQU07QUFBQSxFQUNOQyxlQUFlO0FBQUEsRUFDZkMsa0JBQWtCO0FBQUEsRUFDbEJDLGNBQWM7QUFBQSxFQUNkQyxhQUFhO0FBQUEsRUFDYkMsY0FBYztBQUFBLEVBQ2RDLFVBQVU7QUFBQSxFQUNWQyxjQUFjO0FBQUEsRUFDZEMsT0FBTztBQUFBLEVBQ1BDLFVBQVU7QUFBQSxFQUNWQyxVQUFVO0FBQUEsRUFDVkMsU0FBUztBQUNYO0FBRUEsTUFBTUMsY0FBYztBQUFBLEVBQ2xCLEVBQUVDLE9BQU8sVUFBVUMsT0FBTyxVQUFVQyxNQUFNLHdDQUF3QztBQUFBLEVBQ2xGLEVBQUVGLE9BQU8sY0FBY0MsT0FBTyxjQUFjQyxNQUFNLHlDQUF5QztBQUFBLEVBQzNGLEVBQUVGLE9BQU8sUUFBUUMsT0FBTyxRQUFRQyxNQUFNLDJDQUEyQztBQUFDO0FBR3BGLE1BQU1DLGVBQWU7QUFBQSxFQUNuQixFQUFFRixPQUFPLGFBQWFELE9BQU8saUJBQWlCO0FBQUEsRUFDOUMsRUFBRUMsT0FBTyxRQUFRRCxPQUFPLDhCQUE4QjtBQUFBLEVBQ3RELEVBQUVDLE9BQU8sWUFBWUQsT0FBTyxvQ0FBb0M7QUFBQSxFQUNoRSxFQUFFQyxPQUFPLFFBQVFELE9BQU8sZ0ZBQWdGO0FBQUM7QUFHM0csU0FBU0ksYUFBYSxFQUFFQyxPQUFPQyxTQUF1RCxHQUFHO0FBQ3ZGLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLG9EQUNiO0FBQUEsMkJBQUMsUUFBRyxXQUFVLDZFQUE2RUQsbUJBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUc7QUFBQSxJQUNoR0M7QUFBQUEsT0FGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR0E7QUFFSjtBQUFDQyxLQVBRSDtBQWlCRixnQkFBU0ksaUJBQWlCO0FBQUEsRUFDL0JDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ3FCLEdBQUc7QUFBQUMsS0FBQTtBQUN4QixRQUFNLENBQUNDLE1BQU1DLE9BQU8sSUFBSTVDLFNBQTBCLEVBQUUsR0FBR1ksa0JBQWtCLENBQUM7QUFDMUUsUUFBTSxDQUFDaUMsWUFBWUMsYUFBYSxJQUFJOUMsU0FBUyxLQUFLO0FBRWxELFFBQU0rQyxTQUFTQSxDQUFDQyxPQUE4QnBCLFVBQWtEO0FBQzlGZ0IsWUFBUSxDQUFDSyxVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDRCxLQUFLLEdBQUdwQixNQUFNLEVBQUU7QUFBQSxFQUNqRDtBQUVBLFFBQU1zQixZQUFZUCxLQUFLOUIsS0FBS3NDLEtBQUssRUFBRUMsU0FBUyxLQUFLVCxLQUFLNUIsUUFBUTRCLEtBQUszQixjQUFjbUMsS0FBSyxFQUFFQyxTQUFTO0FBRWpHLFFBQU1DLGVBQWUsWUFBWTtBQUMvQixRQUFJLENBQUNILGFBQWFMLFdBQVk7QUFDOUJDLGtCQUFjLElBQUk7QUFDbEIsUUFBSTtBQUNGLFlBQU1MLFNBQVNFLElBQUk7QUFDbkJDLGNBQVEsRUFBRSxHQUFHaEMsa0JBQWtCLENBQUM7QUFDaEM0QixjQUFRO0FBQUEsSUFDVixRQUFRO0FBQUEsSUFDTixVQUNEO0FBQ0NNLG9CQUFjLEtBQUs7QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNUSxtQkFBbUJBLENBQUNDLE1BQWU7QUFDdkMsUUFBSSxDQUFDQSxFQUFHZixTQUFRO0FBQUEsRUFDbEI7QUFFQSxTQUNFLHVCQUFDLFVBQU8sTUFBWSxjQUFjYyxrQkFDaEMsaUNBQUMsaUJBQWMsV0FBVSxnREFDdkI7QUFBQSwyQkFBQyxnQkFBYSxXQUFVLG9DQUN0QixpQ0FBQyxlQUFhZiwwQkFBZ0Isa0JBQWtCLGtCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStELEtBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUEsdUJBQUMsY0FBVyxXQUFVLGVBQ3BCO0FBQUEsNkJBQUMsZ0JBQWEsT0FBTSxZQUNsQixpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDRDQUEyQyxzQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0U7QUFBQSxVQUNsRSx1QkFBQyxTQUFNLE9BQU9JLEtBQUs5QixNQUFNLFVBQVUsQ0FBQzJDLE1BQU1ULE9BQU8sUUFBUVMsRUFBRUMsT0FBTzdCLEtBQUssR0FBRyxhQUFZLHVCQUFzQixXQUFTLFFBQXJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFIO0FBQUEsYUFGdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSw0Q0FBMkMscUJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlFO0FBQUEsVUFDakUsdUJBQUMsU0FBTSxPQUFPZSxLQUFLN0IsT0FBTyxVQUFVLENBQUMwQyxNQUFNVCxPQUFPLFNBQVNTLEVBQUVDLE9BQU83QixLQUFLLEdBQUcsYUFBWSxRQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RjtBQUFBLGFBRjlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFFQSx1QkFBQyxnQkFBYSxPQUFNLFFBQ2xCLGlDQUFDLFNBQUksV0FBVSx1QkFDWkQsc0JBQVkrQjtBQUFBQSxRQUFJLENBQUNDLFFBQ2hCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU1aLE9BQU8sUUFBUVksSUFBSS9CLEtBQUs7QUFBQSxZQUN2QyxXQUFXM0I7QUFBQUEsY0FDVDtBQUFBLGNBQ0EwQyxLQUFLNUIsU0FBUzRDLElBQUkvQixRQUFRLGdDQUFnQztBQUFBLFlBQzVEO0FBQUEsWUFFQTtBQUFBLHFDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSx5Q0FBeUMrQixjQUFJOUIsU0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUU7QUFBQSxnQkFDbEVjLEtBQUs1QixTQUFTNEMsSUFBSS9CLFNBQVMsdUJBQUMsVUFBSyxXQUFVLHdCQUF1QixpQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0M7QUFBQSxtQkFGdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHdDQUF3QytCLGNBQUk3QixRQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRTtBQUFBO0FBQUE7QUFBQSxVQVozRDZCLElBQUkvQjtBQUFBQSxVQURYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFjQTtBQUFBLE1BQ0QsS0FqQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0JBO0FBQUEsTUFFQSx1QkFBQyxnQkFBYSxPQUFNLGlCQUNsQjtBQUFBLCtCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDRDQUEyQyxnQ0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEU7QUFBQSxVQUM1RSx1QkFBQyxTQUFNLE9BQU9lLEtBQUszQixlQUFlLFVBQVUsQ0FBQ3dDLE1BQU1ULE9BQU8saUJBQWlCUyxFQUFFQyxPQUFPN0IsS0FBSyxHQUFHLGFBQVksZ0JBQXhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9IO0FBQUEsYUFGdEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSw0Q0FBMkMsa0NBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThFO0FBQUEsVUFDOUU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU9lLEtBQUsxQjtBQUFBQSxjQUNaLFVBQVUsQ0FBQ3VDLE1BQU1ULE9BQU8sb0JBQW9CUyxFQUFFQyxPQUFPN0IsS0FBSztBQUFBLGNBQzFELGFBQVk7QUFBQTtBQUFBLFlBSGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRzJEO0FBQUEsVUFFM0QsdUJBQUMsT0FBRSxXQUFVLHNDQUFxQyx3Q0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEU7QUFBQSxhQVA1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLE1BRUEsdUJBQUMsZ0JBQWEsT0FBTSwrQkFDbEI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsNkJBQ1pHLHVCQUFhMkI7QUFBQUEsVUFBSSxDQUFDRSxXQUNqQjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsTUFBSztBQUFBLGNBQ0wsU0FBUTtBQUFBLGNBQ1IsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsU0FBUyxNQUFNYixPQUFPLGdCQUFnQmEsT0FBT2hDLEtBQUs7QUFBQSxjQUVsRDtBQUFBLHVDQUFDLFVBQU8sV0FBVSxrQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxnQkFDL0JnQyxPQUFPL0I7QUFBQUE7QUFBQUE7QUFBQUEsWUFSSCtCLE9BQU8vQjtBQUFBQSxZQURkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLFFBQ0QsS0FiSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPYyxLQUFLekI7QUFBQUEsWUFDWixVQUFVLENBQUNzQyxNQUFNVCxPQUFPLGdCQUFnQlMsRUFBRUMsT0FBTzdCLEtBQUs7QUFBQSxZQUN0RCxhQUFZO0FBQUE7QUFBQSxVQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdxRTtBQUFBLFFBRXJFLHVCQUFDLE9BQUUsV0FBVSxzQ0FBcUMsaUZBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUg7QUFBQSxXQXJCckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQTtBQUFBLE1BRUEsdUJBQUMsZ0JBQWEsT0FBTSxrQkFDbEIsaUNBQUMsU0FBSSxXQUFVLDhEQUNiO0FBQUEsK0JBQUMsVUFBTyxXQUFVLDBDQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdEO0FBQUEsUUFDeEQsdUJBQUMsU0FBSSxXQUFVLGlDQUErQix3TEFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUVBLHVCQUFDLGdCQUFhLE9BQU0sVUFDbEI7QUFBQSwrQkFBQyxPQUFFLFdBQVUsc0NBQXFDLDZDQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStFO0FBQUEsUUFDL0UsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSw0Q0FBMkMseUJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFO0FBQUEsWUFDckU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT2UsS0FBS3hCO0FBQUFBLGdCQUNaLFVBQVUsQ0FBQ3FDLE1BQU1ULE9BQU8sZUFBZVMsRUFBRUMsT0FBTzdCLEtBQUs7QUFBQSxnQkFDckQsYUFBYWUsS0FBSzVCLFNBQVMsU0FBUyxPQUFPNEIsS0FBSzVCLFNBQVMsZUFBZSxNQUFNO0FBQUEsZ0JBQzlFLE1BQUs7QUFBQTtBQUFBLGNBTFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS2E7QUFBQSxlQVBmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDRDQUEyQywyQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUU7QUFBQSxZQUN2RTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPNEIsS0FBS3ZCO0FBQUFBLGdCQUNaLFVBQVUsQ0FBQ29DLE1BQU1ULE9BQU8sZ0JBQWdCUyxFQUFFQyxPQUFPN0IsS0FBSztBQUFBLGdCQUN0RCxhQUFhZSxLQUFLNUIsU0FBUyxTQUFTLFNBQVM0QixLQUFLNUIsU0FBUyxlQUFlLFNBQVM7QUFBQSxnQkFDbkYsTUFBSztBQUFBO0FBQUEsY0FMUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLYTtBQUFBLGVBUGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLGFBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxQkE7QUFBQSxXQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsTUFFQSx1QkFBQyxnQkFBYSxPQUFNLHNCQUNsQjtBQUFBLCtCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDRDQUEyQyxxQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUU7QUFBQSxVQUNqRSx1QkFBQyxTQUFNLE1BQUssU0FBUSxPQUFPNEIsS0FBS3BCLE9BQU8sVUFBVSxDQUFDaUMsTUFBTVQsT0FBTyxTQUFTUyxFQUFFQyxPQUFPN0IsS0FBSyxHQUFHLGFBQVksdUJBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdIO0FBQUEsYUFGMUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDRDQUEyQyx3QkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQSxZQUNwRSx1QkFBQyxTQUFNLE9BQU9lLEtBQUtuQixVQUFVLFVBQVUsQ0FBQ2dDLE1BQU1ULE9BQU8sWUFBWVMsRUFBRUMsT0FBTzdCLEtBQUssR0FBRyxhQUFZLGVBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlHO0FBQUEsZUFGM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsNENBQTJDLHdCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRTtBQUFBLFlBQ3BFLHVCQUFDLFNBQU0sT0FBT2UsS0FBS2xCLFVBQVUsVUFBVSxDQUFDK0IsTUFBTVQsT0FBTyxZQUFZUyxFQUFFQyxPQUFPN0IsS0FBSyxHQUFHLGFBQVksaUJBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJHO0FBQUEsZUFGN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsV0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxNQUVBLHVCQUFDLGdCQUFhLE9BQU0sc0JBQ2xCO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTW1CLE9BQU8sWUFBWSxDQUFDSixLQUFLdEIsUUFBUTtBQUFBLGNBQ2hELFdBQVdwQjtBQUFBQSxnQkFDVDtBQUFBLGdCQUNBMEMsS0FBS3RCLFdBQVcsZUFBZTtBQUFBLGNBQ2pDO0FBQUEsY0FDQSxjQUFXO0FBQUEsY0FFWCxpQ0FBQyxTQUFJLFdBQVdwQixHQUFHLHdGQUF3RjBDLEtBQUt0QixZQUFZLGVBQWUsS0FBM0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkk7QUFBQTtBQUFBLFlBVC9JO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVUsMkJBQTBCLG9DQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RDtBQUFBLGFBWmhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBQ0NzQixLQUFLdEIsWUFDSix1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSw0Q0FBMkMsOEJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBFO0FBQUEsVUFDMUUsdUJBQUMsU0FBTSxNQUFLLFVBQVMsT0FBT3NCLEtBQUtyQixjQUFjLFVBQVUsQ0FBQ2tDLE1BQU1ULE9BQU8sZ0JBQWdCUyxFQUFFQyxPQUFPN0IsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLE1BQXJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdIO0FBQUEsYUFGMUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCQTtBQUFBLFNBckpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzSkE7QUFBQSxJQUVBLHVCQUFDLGdCQUFhLFdBQVUsb0NBQ3RCO0FBQUEsNkJBQUMsVUFBTyxTQUFTeUIsY0FBYyxVQUFVLENBQUNILGFBQWFMLFlBQ3BEQSx1QkFBYSxjQUFjLGtCQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQU8sU0FBUSxXQUFVLFNBQVNMLFNBQVMsVUFBVUssWUFBVyxzQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxPQXBLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUtBLEtBdEtGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1S0E7QUFFSjtBQUFDSCxHQTVNZU4sa0JBQWdCO0FBQUEsTUFBaEJBO0FBQWdCLElBQUFELElBQUEwQjtBQUFBLGFBQUExQixJQUFBO0FBQUEsYUFBQTBCLEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsImNuIiwiQnV0dG9uIiwiSW5wdXQiLCJEaWFsb2ciLCJEaWFsb2dDb250ZW50IiwiRGlhbG9nSGVhZGVyIiwiRGlhbG9nVGl0bGUiLCJEaWFsb2dGb290ZXIiLCJTY3JvbGxBcmVhIiwiU2hpZWxkIiwiV3JlbmNoIiwiZGVmYXVsdENyZWF0ZUZvcm0iLCJuYW1lIiwiZW1vamkiLCJyb2xlIiwid29ya3NwYWNlUGF0aCIsImFsbG93ZWRUYXNrVHlwZXMiLCJhbGxvd2VkVG9vbHMiLCJidWRnZXREYWlseSIsImJ1ZGdldFBlclJ1biIsImNhblNwYXduIiwibWF4U3ViQWdlbnRzIiwiZW1haWwiLCJ0ZWxlZ3JhbSIsIndoYXRzYXBwIiwiZGlzY29yZCIsInJvbGVPcHRpb25zIiwidmFsdWUiLCJsYWJlbCIsImRlc2MiLCJUT09MX1BSRVNFVFMiLCJNb2RhbFNlY3Rpb24iLCJ0aXRsZSIsImNoaWxkcmVuIiwiX2MiLCJDcmVhdGVBZ2VudE1vZGFsIiwib3BlbiIsInByb2plY3RJZCIsInBhcmVudEFnZW50SWQiLCJvbkNsb3NlIiwib25DcmVhdGUiLCJfcyIsImZvcm0iLCJzZXRGb3JtIiwic3VibWl0dGluZyIsInNldFN1Ym1pdHRpbmciLCJ1cGRhdGUiLCJmaWVsZCIsInByZXYiLCJjYW5TdWJtaXQiLCJ0cmltIiwibGVuZ3RoIiwiaGFuZGxlU3VibWl0IiwiaGFuZGxlT3BlbkNoYW5nZSIsInYiLCJlIiwidGFyZ2V0IiwibWFwIiwib3B0IiwicHJlc2V0IiwiX2MyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNyZWF0ZUFnZW50TW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogU2hhcmVkIENyZWF0ZSBBZ2VudCBtb2RhbCAoT3BlbkNsYXcgU3R1ZGlvIHBhcml0eSkuXG4gKiBJZGVudGl0eSwgcm9sZSwgY29uZmlnLCB0b29sIHBvbGljeSAoYWxsb3dlZCB0b29scyksIGJ1ZGdldCwgZXhlYyBhcHByb3ZhbCBub3RlLCBzcGF3bmluZy5cbiAqIFVzZWQgZnJvbSBPcmdWaWV3ICh3aXRoIG9wdGlvbmFsIHBhcmVudEFnZW50SWQpIGFuZCBmcm9tIEFnZW50IFJlZ2lzdHJ5IC8gQ29tbWFuZCBQYWxldHRlLlxuICovXG5cbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9idXR0b25cIjtcbmltcG9ydCB7IElucHV0IH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9pbnB1dFwiO1xuaW1wb3J0IHtcbiAgRGlhbG9nLFxuICBEaWFsb2dDb250ZW50LFxuICBEaWFsb2dIZWFkZXIsXG4gIERpYWxvZ1RpdGxlLFxuICBEaWFsb2dGb290ZXIsXG59IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvZGlhbG9nXCI7XG5pbXBvcnQgeyBTY3JvbGxBcmVhIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9zY3JvbGwtYXJlYVwiO1xuaW1wb3J0IHsgU2hpZWxkLCBXcmVuY2ggfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuXG5leHBvcnQgaW50ZXJmYWNlIENyZWF0ZUFnZW50Rm9ybSB7XG4gIG5hbWU6IHN0cmluZztcbiAgZW1vamk6IHN0cmluZztcbiAgcm9sZTogc3RyaW5nO1xuICB3b3Jrc3BhY2VQYXRoOiBzdHJpbmc7XG4gIGFsbG93ZWRUYXNrVHlwZXM6IHN0cmluZztcbiAgYWxsb3dlZFRvb2xzOiBzdHJpbmc7XG4gIGJ1ZGdldERhaWx5OiBzdHJpbmc7XG4gIGJ1ZGdldFBlclJ1bjogc3RyaW5nO1xuICBjYW5TcGF3bjogYm9vbGVhbjtcbiAgbWF4U3ViQWdlbnRzOiBzdHJpbmc7XG4gIGVtYWlsOiBzdHJpbmc7XG4gIHRlbGVncmFtOiBzdHJpbmc7XG4gIHdoYXRzYXBwOiBzdHJpbmc7XG4gIGRpc2NvcmQ6IHN0cmluZztcbn1cblxuZXhwb3J0IGNvbnN0IGRlZmF1bHRDcmVhdGVGb3JtOiBDcmVhdGVBZ2VudEZvcm0gPSB7XG4gIG5hbWU6IFwiXCIsXG4gIGVtb2ppOiBcIlwiLFxuICByb2xlOiBcIlNQRUNJQUxJU1RcIixcbiAgd29ya3NwYWNlUGF0aDogXCIvd29ya3NwYWNlXCIsXG4gIGFsbG93ZWRUYXNrVHlwZXM6IFwiXCIsXG4gIGFsbG93ZWRUb29sczogXCJcIixcbiAgYnVkZ2V0RGFpbHk6IFwiXCIsXG4gIGJ1ZGdldFBlclJ1bjogXCJcIixcbiAgY2FuU3Bhd246IGZhbHNlLFxuICBtYXhTdWJBZ2VudHM6IFwiMFwiLFxuICBlbWFpbDogXCJcIixcbiAgdGVsZWdyYW06IFwiXCIsXG4gIHdoYXRzYXBwOiBcIlwiLFxuICBkaXNjb3JkOiBcIlwiLFxufTtcblxuY29uc3Qgcm9sZU9wdGlvbnMgPSBbXG4gIHsgdmFsdWU6IFwiSU5URVJOXCIsIGxhYmVsOiBcIkludGVyblwiLCBkZXNjOiBcIkxpbWl0ZWQgYWNjZXNzLCBsb3dlciBidWRnZXQgKCQyL2RheSlcIiB9LFxuICB7IHZhbHVlOiBcIlNQRUNJQUxJU1RcIiwgbGFiZWw6IFwiU3BlY2lhbGlzdFwiLCBkZXNjOiBcIlN0YW5kYXJkIGFnZW50LCBmb2N1c2VkIHRhc2tzICgkNS9kYXkpXCIgfSxcbiAgeyB2YWx1ZTogXCJMRUFEXCIsIGxhYmVsOiBcIkxlYWRcIiwgZGVzYzogXCJGdWxsIGFjY2VzcywgY29vcmRpbmF0aW9uIHJvbGUgKCQxMi9kYXkpXCIgfSxcbl07XG5cbmNvbnN0IFRPT0xfUFJFU0VUUyA9IFtcbiAgeyBsYWJlbDogXCJSZWFkLW9ubHlcIiwgdmFsdWU6IFwicmVhZCx3ZWJfZmV0Y2hcIiB9LFxuICB7IGxhYmVsOiBcIkNvZGVcIiwgdmFsdWU6IFwicmVhZCx3cml0ZSxzaGVsbCxnaXQsY29udmV4XCIgfSxcbiAgeyBsYWJlbDogXCJSZXNlYXJjaFwiLCB2YWx1ZTogXCJyZWFkLHdlYl9zZWFyY2gsd2ViX2ZldGNoLHBsYW5uZXJcIiB9LFxuICB7IGxhYmVsOiBcIkZ1bGxcIiwgdmFsdWU6IFwicmVhZCx3cml0ZSxzaGVsbCx3ZWJfc2VhcmNoLHdlYl9mZXRjaCxnaXQsZ2l0aHViLGNvbnZleCx0YXNrcyxjb250ZW50LHBsYW5uZXJcIiB9LFxuXTtcblxuZnVuY3Rpb24gTW9kYWxTZWN0aW9uKHsgdGl0bGUsIGNoaWxkcmVuIH06IHsgdGl0bGU6IHN0cmluZzsgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZSB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwdC01IHBiLTQgYm9yZGVyLWIgYm9yZGVyLWJvcmRlciBsYXN0OmJvcmRlci1iLTBcIj5cbiAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0zXCI+e3RpdGxlfTwvaDM+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ3JlYXRlQWdlbnRNb2RhbFByb3BzIHtcbiAgb3BlbjogYm9vbGVhbjtcbiAgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+IHwgbnVsbDtcbiAgcGFyZW50QWdlbnRJZD86IElkPFwiYWdlbnRzXCI+O1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBvbkNyZWF0ZTogKGZvcm06IENyZWF0ZUFnZW50Rm9ybSkgPT4gdm9pZCB8IFByb21pc2U8dm9pZD47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBDcmVhdGVBZ2VudE1vZGFsKHtcbiAgb3BlbixcbiAgcHJvamVjdElkLFxuICBwYXJlbnRBZ2VudElkLFxuICBvbkNsb3NlLFxuICBvbkNyZWF0ZSxcbn06IENyZWF0ZUFnZW50TW9kYWxQcm9wcykge1xuICBjb25zdCBbZm9ybSwgc2V0Rm9ybV0gPSB1c2VTdGF0ZTxDcmVhdGVBZ2VudEZvcm0+KHsgLi4uZGVmYXVsdENyZWF0ZUZvcm0gfSk7XG4gIGNvbnN0IFtzdWJtaXR0aW5nLCBzZXRTdWJtaXR0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCB1cGRhdGUgPSAoZmllbGQ6IGtleW9mIENyZWF0ZUFnZW50Rm9ybSwgdmFsdWU6IENyZWF0ZUFnZW50Rm9ybVtrZXlvZiBDcmVhdGVBZ2VudEZvcm1dKSA9PiB7XG4gICAgc2V0Rm9ybSgocHJldikgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogdmFsdWUgfSkpO1xuICB9O1xuXG4gIGNvbnN0IGNhblN1Ym1pdCA9IGZvcm0ubmFtZS50cmltKCkubGVuZ3RoID4gMCAmJiBmb3JtLnJvbGUgJiYgZm9ybS53b3Jrc3BhY2VQYXRoLnRyaW0oKS5sZW5ndGggPiAwO1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIWNhblN1Ym1pdCB8fCBzdWJtaXR0aW5nKSByZXR1cm47XG4gICAgc2V0U3VibWl0dGluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgb25DcmVhdGUoZm9ybSk7XG4gICAgICBzZXRGb3JtKHsgLi4uZGVmYXVsdENyZWF0ZUZvcm0gfSk7XG4gICAgICBvbkNsb3NlKCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBLZWVwIG1vZGFsIG9wZW4gb24gZXJyb3IgKGNhbGxlciBtYXkgc2V0IGVycm9yIHN0YXRlKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTdWJtaXR0aW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlT3BlbkNoYW5nZSA9ICh2OiBib29sZWFuKSA9PiB7XG4gICAgaWYgKCF2KSBvbkNsb3NlKCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8RGlhbG9nIG9wZW49e29wZW59IG9uT3BlbkNoYW5nZT17aGFuZGxlT3BlbkNoYW5nZX0+XG4gICAgICA8RGlhbG9nQ29udGVudCBjbGFzc05hbWU9XCJtYXgtdy1bNTYwcHhdIG1heC1oLVs5MHZoXSBmbGV4IGZsZXgtY29sIHAtMFwiPlxuICAgICAgICA8RGlhbG9nSGVhZGVyIGNsYXNzTmFtZT1cInB4LTYgcHktNSBib3JkZXItYiBib3JkZXItYm9yZGVyXCI+XG4gICAgICAgICAgPERpYWxvZ1RpdGxlPntwYXJlbnRBZ2VudElkID8gXCJBZGQgU3ViLUFnZW50XCIgOiBcIkNyZWF0ZSBBZ2VudFwifTwvRGlhbG9nVGl0bGU+XG4gICAgICAgIDwvRGlhbG9nSGVhZGVyPlxuXG4gICAgICAgIDxTY3JvbGxBcmVhIGNsYXNzTmFtZT1cImZsZXgtMSBweC02XCI+XG4gICAgICAgICAgPE1vZGFsU2VjdGlvbiB0aXRsZT1cIklkZW50aXR5XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmQgbWItMVwiPk5hbWUgKjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPElucHV0IHZhbHVlPXtmb3JtLm5hbWV9IG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlKFwibmFtZVwiLCBlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiZS5nLiBSZXNlYXJjaCBBZ2VudFwiIGF1dG9Gb2N1cyAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTIwXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIG1iLTFcIj5FbW9qaTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPElucHV0IHZhbHVlPXtmb3JtLmVtb2ppfSBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZShcImVtb2ppXCIsIGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCLwn6SWXCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L01vZGFsU2VjdGlvbj5cblxuICAgICAgICAgIDxNb2RhbFNlY3Rpb24gdGl0bGU9XCJSb2xlXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTJcIj5cbiAgICAgICAgICAgICAge3JvbGVPcHRpb25zLm1hcCgob3B0KSA9PiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAga2V5PXtvcHQudmFsdWV9XG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZShcInJvbGVcIiwgb3B0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgIFwicC0zIHJvdW5kZWQtbGcgYm9yZGVyIHRleHQtbGVmdCB0cmFuc2l0aW9uLWNvbG9yc1wiLFxuICAgICAgICAgICAgICAgICAgICBmb3JtLnJvbGUgPT09IG9wdC52YWx1ZSA/IFwiYm9yZGVyLXByaW1hcnkgYmctcHJpbWFyeS81XCIgOiBcImJvcmRlci1ib3JkZXIgYmctYmFja2dyb3VuZCBob3ZlcjpiZy1tdXRlZFwiXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbSB0ZXh0LWZvcmVncm91bmRcIj57b3B0LmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAge2Zvcm0ucm9sZSA9PT0gb3B0LnZhbHVlICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSB0ZXh0LXNtXCI+4pyTPC9zcGFuPn1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtdC0wLjVcIj57b3B0LmRlc2N9PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9Nb2RhbFNlY3Rpb24+XG5cbiAgICAgICAgICA8TW9kYWxTZWN0aW9uIHRpdGxlPVwiQ29uZmlndXJhdGlvblwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zXCI+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtYi0xXCI+V29ya3NwYWNlIFBhdGggKjwvbGFiZWw+XG4gICAgICAgICAgICAgIDxJbnB1dCB2YWx1ZT17Zm9ybS53b3Jrc3BhY2VQYXRofSBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZShcIndvcmtzcGFjZVBhdGhcIiwgZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIi93b3Jrc3BhY2VcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTNcIj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIG1iLTFcIj5BbGxvd2VkIFRhc2sgVHlwZXM8L2xhYmVsPlxuICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5hbGxvd2VkVGFza1R5cGVzfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlKFwiYWxsb3dlZFRhc2tUeXBlc1wiLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFTkdJTkVFUklORywgQ09OVEVOVCwgT1BTIChjb21tYS1zZXBhcmF0ZWQpXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmQgbXQtMVwiPkxlYXZlIGVtcHR5IHRvIGFsbG93IGFsbDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvTW9kYWxTZWN0aW9uPlxuXG4gICAgICAgICAgPE1vZGFsU2VjdGlvbiB0aXRsZT1cIlRvb2wgcG9saWN5IChhbGxvd2VkIHRvb2xzKVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMiBtYi0yXCI+XG4gICAgICAgICAgICAgIHtUT09MX1BSRVNFVFMubWFwKChwcmVzZXQpID0+IChcbiAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e3ByZXNldC5sYWJlbH1cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtNyB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZShcImFsbG93ZWRUb29sc1wiLCBwcmVzZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxXcmVuY2ggY2xhc3NOYW1lPVwiaC0zIHctMyBtci0xXCIgLz5cbiAgICAgICAgICAgICAgICAgIHtwcmVzZXQubGFiZWx9XG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0uYWxsb3dlZFRvb2xzfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZShcImFsbG93ZWRUb29sc1wiLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwicmVhZCwgd3JpdGUsIHNoZWxsLCB3ZWJfc2VhcmNoLCBnaXQgKGNvbW1hLXNlcGFyYXRlZClcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIG10LTFcIj5BbGxvd2xpc3Qgb25seS4gUkVELXJpc2sgdG9vbCBjYWxscyByZXF1aXJlIGh1bWFuIGFwcHJvdmFsIGJlbG93LjwvcD5cbiAgICAgICAgICA8L01vZGFsU2VjdGlvbj5cblxuICAgICAgICAgIDxNb2RhbFNlY3Rpb24gdGl0bGU9XCJFeGVjIGFwcHJvdmFsc1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctbXV0ZWQvMzAgcC0zXCI+XG4gICAgICAgICAgICAgIDxTaGllbGQgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LXByaW1hcnkgc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgIEhpZ2gtcmlzayAoUkVEKSB0b29sIGNhbGxz4oCUZS5nLiBkZXN0cnVjdGl2ZSBvciBleHRlcm5hbCB3cml0ZXPigJRyZXF1aXJlIGh1bWFuIGFwcHJvdmFsIGJlZm9yZSB0aGUgYWdlbnQgY2FuIHByb2NlZWQuIEFwcHJvdmUgb3IgZGVueSBmcm9tIHRoZSBBcHByb3ZhbHMgY2VudGVyICh0b3AgYmFyKS5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L01vZGFsU2VjdGlvbj5cblxuICAgICAgICAgIDxNb2RhbFNlY3Rpb24gdGl0bGU9XCJCdWRnZXRcIj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIG1iLTNcIj5MZWF2ZSBlbXB0eSBmb3Igcm9sZSBkZWZhdWx0czwvcD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtM1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtYi0xXCI+RGFpbHkgKCQpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0uYnVkZ2V0RGFpbHl9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZShcImJ1ZGdldERhaWx5XCIsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtmb3JtLnJvbGUgPT09IFwiTEVBRFwiID8gXCIxMlwiIDogZm9ybS5yb2xlID09PSBcIlNQRUNJQUxJU1RcIiA/IFwiNVwiIDogXCIyXCJ9XG4gICAgICAgICAgICAgICAgICBzdGVwPVwiMC41MFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIG1iLTFcIj5QZXIgcnVuICgkKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLmJ1ZGdldFBlclJ1bn1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlKFwiYnVkZ2V0UGVyUnVuXCIsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtmb3JtLnJvbGUgPT09IFwiTEVBRFwiID8gXCIxLjUwXCIgOiBmb3JtLnJvbGUgPT09IFwiU1BFQ0lBTElTVFwiID8gXCIwLjc1XCIgOiBcIjAuMjVcIn1cbiAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjI1XCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvTW9kYWxTZWN0aW9uPlxuXG4gICAgICAgICAgPE1vZGFsU2VjdGlvbiB0aXRsZT1cIkNvbnRhY3QgKG9wdGlvbmFsKVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zXCI+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtYi0xXCI+RW1haWw8L2xhYmVsPlxuICAgICAgICAgICAgICA8SW5wdXQgdHlwZT1cImVtYWlsXCIgdmFsdWU9e2Zvcm0uZW1haWx9IG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlKFwiZW1haWxcIiwgZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cImFnZW50QGV4YW1wbGUuY29tXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIG1iLTFcIj5UZWxlZ3JhbTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPElucHV0IHZhbHVlPXtmb3JtLnRlbGVncmFtfSBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZShcInRlbGVncmFtXCIsIGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJAdXNlcm5hbWVcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmQgbWItMVwiPldoYXRzQXBwPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8SW5wdXQgdmFsdWU9e2Zvcm0ud2hhdHNhcHB9IG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlKFwid2hhdHNhcHBcIiwgZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIisxMjM0NTY3ODkwXCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L01vZGFsU2VjdGlvbj5cblxuICAgICAgICAgIDxNb2RhbFNlY3Rpb24gdGl0bGU9XCJTdWItYWdlbnQgc3Bhd25pbmdcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItM1wiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdXBkYXRlKFwiY2FuU3Bhd25cIiwgIWZvcm0uY2FuU3Bhd24pfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICBcInJlbGF0aXZlIHctMTAgaC02IHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLWNvbG9ycyBzaHJpbmstMFwiLFxuICAgICAgICAgICAgICAgICAgZm9ybS5jYW5TcGF3biA/IFwiYmctcHJpbWFyeVwiIDogXCJiZy1ib3JkZXJcIlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlRvZ2dsZSBzdWItYWdlbnQgc3Bhd25pbmdcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2NuKFwiYWJzb2x1dGUgdG9wLVszcHhdIGxlZnQtWzNweF0gdy00LjUgaC00LjUgcm91bmRlZC1mdWxsIGJnLXdoaXRlIHRyYW5zaXRpb24tdHJhbnNmb3JtXCIsIGZvcm0uY2FuU3Bhd24gJiYgXCJ0cmFuc2xhdGUteC00XCIpfSAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWZvcmVncm91bmRcIj5DYW4gc3Bhd24gc3ViLWFnZW50czwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAge2Zvcm0uY2FuU3Bhd24gJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctWzEyMHB4XVwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtYi0xXCI+TWF4IHN1Yi1hZ2VudHM8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxJbnB1dCB0eXBlPVwibnVtYmVyXCIgdmFsdWU9e2Zvcm0ubWF4U3ViQWdlbnRzfSBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZShcIm1heFN1YkFnZW50c1wiLCBlLnRhcmdldC52YWx1ZSl9IG1pbj17MH0gbWF4PXsxMH0gLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvTW9kYWxTZWN0aW9uPlxuICAgICAgICA8L1Njcm9sbEFyZWE+XG5cbiAgICAgICAgPERpYWxvZ0Zvb3RlciBjbGFzc05hbWU9XCJweC02IHB5LTQgYm9yZGVyLXQgYm9yZGVyLWJvcmRlclwiPlxuICAgICAgICAgIDxCdXR0b24gb25DbGljaz17aGFuZGxlU3VibWl0fSBkaXNhYmxlZD17IWNhblN1Ym1pdCB8fCBzdWJtaXR0aW5nfT5cbiAgICAgICAgICAgIHtzdWJtaXR0aW5nID8gXCJDcmVhdGluZ+KAplwiIDogXCJDcmVhdGUgQWdlbnRcIn1cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17b25DbG9zZX0gZGlzYWJsZWQ9e3N1Ym1pdHRpbmd9PlxuICAgICAgICAgICAgQ2FuY2VsXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIDwvRGlhbG9nRm9vdGVyPlxuICAgICAgPC9EaWFsb2dDb250ZW50PlxuICAgIDwvRGlhbG9nPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvQ3JlYXRlQWdlbnRNb2RhbC50c3gifQ==