import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/PeerReviewPanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
import { useQuery, useMutation } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport5_react["useState"];
import { cn } from "/src/lib/utils.ts";
import { StatusBadge } from "/src/components/factory/badges.tsx";
import { HarnessFirstReviewModal } from "/src/harness/components/HarnessFirstReviewModal.tsx";
import {
  AlertTriangle,
  CheckCircle2,
  FileText,
  Minus,
  Pencil,
  Plus,
  ThumbsUp,
  Wrench
} from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
export function PeerReviewPanel({ taskId, projectId }) {
  _s();
  const [showCreateReview, setShowCreateReview] = useState(false);
  const reviews = useQuery(api.reviews.listByTask, { taskId });
  const stats = useQuery(api.reviews.getStats, { projectId });
  if (!reviews || !stats) {
    return /* @__PURE__ */ jsxDEV("div", { className: "p-5 text-ink-muted", children: "Loading reviews..." }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
      lineNumber: 50,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "p-5", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-[repeat(auto-fit,minmax(150px,1fr))] gap-3 mb-5", children: [
      /* @__PURE__ */ jsxDEV(StatCard, { label: "Total Reviews", value: reviews.length }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 57,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(StatCard, { label: "Praise", value: stats.byType.PRAISE, colorClass: "text-ok" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 58,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(StatCard, { label: "Refutes", value: stats.byType.REFUTE, colorClass: "text-warn" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 59,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(StatCard, { label: "Changesets", value: stats.byType.CHANGESET, colorClass: "text-info-accent" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 60,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(StatCard, { label: "Avg Score", value: stats.avgScore.toFixed(1) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 61,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
      lineNumber: 56,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: () => setShowCreateReview(true),
        className: "w-full h-9 bg-act text-act-ink border-none rounded-lg text-[13px] font-medium cursor-pointer mb-5 transition-opacity duration-150 hover:opacity-90",
        children: "Create Review"
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 65,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3", children: reviews.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center text-center py-10 text-ink-muted", children: [
      /* @__PURE__ */ jsxDEV(FileText, { className: "h-7 w-7 mb-3", strokeWidth: 1.5 }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 76,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-[15px] font-semibold text-ink", children: "No reviews yet" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 77,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] mt-2", children: "Be the first to review this task." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 78,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
      lineNumber: 75,
      columnNumber: 9
    }, this) : reviews.map(
      (review) => /* @__PURE__ */ jsxDEV(ReviewCard, { review }, review._id, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 82,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
      lineNumber: 73,
      columnNumber: 7
    }, this),
    showCreateReview && /* @__PURE__ */ jsxDEV(
      CreateReviewModal,
      {
        taskId,
        projectId,
        onClose: () => setShowCreateReview(false)
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 88,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
    lineNumber: 54,
    columnNumber: 5
  }, this);
}
_s(PeerReviewPanel, "Rqihszx9nGsCTmHRUWeBMAJcZ9A=", false, function() {
  return [useQuery, useQuery];
});
_c = PeerReviewPanel;
const STAT_DEFAULT_CLASS = "text-ink";
function StatCard({ label, value, colorClass }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "bg-surface-2 rounded-lg p-3 border border-line", children: [
    /* @__PURE__ */ jsxDEV("div", { className: cn("text-[19px] font-semibold tabular-nums", colorClass || STAT_DEFAULT_CLASS), children: value }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
      lineNumber: 103,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted mt-0.5", children: label }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
      lineNumber: 106,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
    lineNumber: 102,
    columnNumber: 5
  }, this);
}
_c2 = StatCard;
const TYPE_BORDER_CLASSES = {
  PRAISE: "border-l-ok",
  REFUTE: "border-l-warn",
  CHANGESET: "border-l-info-accent",
  APPROVE: "border-l-ok"
};
const TYPE_TEXT_CLASSES = {
  PRAISE: "text-ok",
  REFUTE: "text-warn",
  CHANGESET: "text-info-accent",
  APPROVE: "text-ok"
};
const TYPE_ICONS = {
  PRAISE: ThumbsUp,
  REFUTE: AlertTriangle,
  CHANGESET: Wrench,
  APPROVE: CheckCircle2
};
function ReviewCard({ review }) {
  _s2();
  const respondToReview = useMutation(api.reviews.respond);
  const [responding, setResponding] = useState(false);
  const [responseText, setResponseText] = useState("");
  const handleRespond = async (accept) => {
    if (!responseText.trim()) return;
    try {
      await respondToReview({
        reviewId: review._id,
        responseBy: review.reviewerAgentId,
        responseText,
        accept
      });
      setResponding(false);
      setResponseText("");
    } catch (error) {
      console.error("Error responding to review:", error);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: cn(
    "bg-surface-1 rounded-lg p-4 border border-line border-l-2",
    TYPE_BORDER_CLASSES[review.type] || "border-l-line-strong"
  ), children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between mb-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        (() => {
          const TypeIcon = TYPE_ICONS[review.type] ?? FileText;
          return /* @__PURE__ */ jsxDEV(TypeIcon, { className: cn("h-4 w-4", TYPE_TEXT_CLASSES[review.type] || "text-ink-muted"), strokeWidth: 1.75 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
            lineNumber: 164,
            columnNumber: 20
          }, this);
        })(),
        /* @__PURE__ */ jsxDEV("span", { className: cn("text-[13px] font-semibold", TYPE_TEXT_CLASSES[review.type] || "text-ink-muted"), children: review.type }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
          lineNumber: 166,
          columnNumber: 11
        }, this),
        review.score && /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-ink-muted", children: [
          "Score: ",
          review.score,
          "/10"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
          lineNumber: 170,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 161,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted", children: new Date(review._creationTime).toLocaleString() }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 175,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
      lineNumber: 160,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium mb-2 text-ink", children: review.summary }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
      lineNumber: 181,
      columnNumber: 7
    }, this),
    review.details && /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] text-ink-muted mb-3", children: review.details }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
      lineNumber: 187,
      columnNumber: 7
    }, this),
    review.changeset && /* @__PURE__ */ jsxDEV("div", { className: "bg-surface-2 border border-line rounded-md p-3 mb-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold mb-2 text-ink", children: "Files Changed:" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 195,
        columnNumber: 11
      }, this),
      review.changeset.files.map(
        (file, idx) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 text-[11px] text-ink-muted mb-1", children: [
          file.action === "ADD" && /* @__PURE__ */ jsxDEV(Plus, { className: "h-3 w-3", strokeWidth: 1.75 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
            lineNumber: 200,
            columnNumber: 41
          }, this),
          file.action === "MODIFY" && /* @__PURE__ */ jsxDEV(Pencil, { className: "h-3 w-3", strokeWidth: 1.75 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
            lineNumber: 201,
            columnNumber: 44
          }, this),
          file.action === "DELETE" && /* @__PURE__ */ jsxDEV(Minus, { className: "h-3 w-3", strokeWidth: 1.75 }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
            lineNumber: 202,
            columnNumber: 44
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-mono", children: file.path }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
            lineNumber: 203,
            columnNumber: 15
          }, this)
        ] }, idx, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
          lineNumber: 199,
          columnNumber: 9
        }, this)
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
      lineNumber: 194,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsxDEV(StatusBadge, { tone: review.status === "PENDING" ? "warning" : "success", children: review.status }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 211,
        columnNumber: 9
      }, this),
      review.severity && /* @__PURE__ */ jsxDEV(StatusBadge, { tone: review.severity === "CRITICAL" ? "error" : "warning", children: review.severity }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 215,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
      lineNumber: 210,
      columnNumber: 7
    }, this),
    review.status === "PENDING" && !responding && /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: () => setResponding(true),
        className: "mt-3 px-3 py-2 bg-transparent border border-line rounded-lg text-ink-secondary text-xs cursor-pointer hover:text-ink hover:border-line-strong transition-colors duration-150",
        children: "Respond"
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 223,
        columnNumber: 7
      },
      this
    ),
    responding && /* @__PURE__ */ jsxDEV("div", { className: "mt-3", children: [
      /* @__PURE__ */ jsxDEV(
        "textarea",
        {
          value: responseText,
          onChange: (e) => setResponseText(e.target.value),
          placeholder: "Your response...",
          className: "w-full min-h-[60px] p-2 bg-surface-1 border border-line rounded-lg text-ink text-xs mb-2 resize-y placeholder:text-ink-muted"
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
          lineNumber: 233,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handleRespond(true),
            className: "px-3 py-1.5 bg-act text-act-ink border-none rounded-lg text-xs cursor-pointer transition-opacity duration-150 hover:opacity-90",
            children: "Accept"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
            lineNumber: 240,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handleRespond(false),
            className: "px-3 py-1.5 bg-err-soft text-err border border-transparent rounded-lg text-xs cursor-pointer transition-opacity duration-150 hover:opacity-90",
            children: "Reject"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
            lineNumber: 246,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setResponding(false),
            className: "px-3 py-1.5 bg-transparent border border-line rounded-lg text-ink-secondary text-xs cursor-pointer hover:text-ink hover:border-line-strong transition-colors duration-150",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
            lineNumber: 252,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 239,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
      lineNumber: 232,
      columnNumber: 7
    }, this),
    review.responseText && /* @__PURE__ */ jsxDEV("div", { className: "mt-3 p-2 bg-surface-2 border border-line rounded-md text-xs text-ink-muted", children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Response:" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
        lineNumber: 265,
        columnNumber: 11
      }, this),
      " ",
      review.responseText
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
      lineNumber: 264,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
    lineNumber: 155,
    columnNumber: 5
  }, this);
}
_s2(ReviewCard, "EXdJY7tZVikSBsA1PGuBvQTUg0s=", false, function() {
  return [useMutation];
});
_c3 = ReviewCard;
function CreateReviewModal({ taskId, projectId, onClose }) {
  _s3();
  const createReview = useMutation(api.reviews.create);
  const agents = useQuery(api.agents.listAll, { projectId });
  const [type, setType] = useState("PRAISE");
  const [summary, setSummary] = useState("");
  const [details, setDetails] = useState("");
  const [score, setScore] = useState(8);
  const [severity, setSeverity] = useState("MINOR");
  const [showHarnessGate, setShowHarnessGate] = useState(false);
  const submitReview = async () => {
    if (!summary.trim()) return;
    try {
      await createReview({
        projectId,
        taskId,
        type,
        summary,
        details: details || void 0,
        targetType: "TASK",
        score: type === "PRAISE" ? score : void 0,
        severity: type === "REFUTE" ? severity : void 0,
        reviewerAgentId: agents?.[0]?._id
      });
      onClose();
    } catch (error) {
      console.error("Error creating review:", error);
    }
  };
  const handleSubmit = () => {
    if (!summary.trim()) return;
    if (type === "REFUTE" || type === "CHANGESET") {
      setShowHarnessGate(true);
      return;
    }
    void submitReview();
  };
  const inputClasses = "w-full h-9 px-3 bg-surface-1 border border-line rounded-lg text-ink text-[13.5px] placeholder:text-ink-muted";
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "fixed inset-0 bg-black/80 flex items-center justify-center z-[1000]",
      onClick: onClose,
      children: [
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "bg-surface-3 border border-line rounded-xl shadow-[var(--shadow-elevation-2)] max-w-[500px] w-full p-6 text-ink",
            onClick: (e) => e.stopPropagation(),
            children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "mb-5 text-lg font-semibold", children: "Create Review" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                lineNumber: 324,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm mb-2", children: "Review Type" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                  lineNumber: 328,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("select", { value: type, onChange: (e) => setType(e.target.value), className: inputClasses, children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "PRAISE", children: "Praise" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                    lineNumber: 330,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "REFUTE", children: "Refute" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                    lineNumber: 331,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "CHANGESET", children: "Changeset" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                    lineNumber: 332,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "APPROVE", children: "Approve" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                    lineNumber: 333,
                    columnNumber: 13
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                  lineNumber: 329,
                  columnNumber: 11
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                lineNumber: 327,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm mb-2", children: "Summary *" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                  lineNumber: 339,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: summary,
                    onChange: (e) => setSummary(e.target.value),
                    placeholder: "Brief summary of your review",
                    className: inputClasses
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                    lineNumber: 340,
                    columnNumber: 11
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                lineNumber: 338,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm mb-2", children: "Details" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                  lineNumber: 351,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "textarea",
                  {
                    value: details,
                    onChange: (e) => setDetails(e.target.value),
                    placeholder: "Detailed explanation...",
                    className: cn(inputClasses, "min-h-[80px] resize-y")
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                    lineNumber: 352,
                    columnNumber: 11
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                lineNumber: 350,
                columnNumber: 9
              }, this),
              type === "PRAISE" && /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm mb-2", children: [
                  "Score: ",
                  score,
                  "/10"
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                  lineNumber: 363,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "range",
                    min: "1",
                    max: "10",
                    value: score,
                    onChange: (e) => setScore(parseInt(e.target.value)),
                    className: "w-full"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                    lineNumber: 364,
                    columnNumber: 13
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                lineNumber: 362,
                columnNumber: 9
              }, this),
              type === "REFUTE" && /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm mb-2", children: "Severity" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                  lineNumber: 377,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("select", { value: severity, onChange: (e) => setSeverity(e.target.value), className: inputClasses, children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "MINOR", children: "Minor" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                    lineNumber: 379,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "MAJOR", children: "Major" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                    lineNumber: 380,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "CRITICAL", children: "Critical" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                    lineNumber: 381,
                    columnNumber: 15
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                  lineNumber: 378,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                lineNumber: 376,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 justify-end", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: onClose,
                    className: "h-9 px-3 bg-transparent border border-line rounded-lg text-ink-secondary text-[13px] font-medium cursor-pointer hover:text-ink hover:border-line-strong transition-colors duration-150",
                    children: "Cancel"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                    lineNumber: 388,
                    columnNumber: 11
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: handleSubmit,
                    disabled: !summary.trim(),
                    className: cn(
                      "h-9 px-3 border-none rounded-lg text-[13px] font-medium transition-opacity duration-150",
                      summary.trim() ? "bg-act text-act-ink cursor-pointer hover:opacity-90" : "bg-surface-2 text-ink-muted cursor-not-allowed"
                    ),
                    children: "Create Review"
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                    lineNumber: 394,
                    columnNumber: 11
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
                lineNumber: 387,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
            lineNumber: 320,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          HarnessFirstReviewModal,
          {
            open: showHarnessGate,
            onClose: () => setShowHarnessGate(false),
            onProceedComment: () => {
              setShowHarnessGate(false);
              void submitReview();
            }
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
            lineNumber: 408,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx",
      lineNumber: 316,
      columnNumber: 5
    },
    this
  );
}
_s3(CreateReviewModal, "Bm+RPrZOSkDwyqyDr8XKH/EvVsg=", false, function() {
  return [useMutation, useQuery];
});
_c4 = CreateReviewModal;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "PeerReviewPanel");
$RefreshReg$(_c2, "StatCard");
$RefreshReg$(_c3, "ReviewCard");
$RefreshReg$(_c4, "CreateReviewModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PeerReviewPanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEJXOzs7Ozs7Ozs7Ozs7Ozs7OztBQTlCWCxTQUFTQSxVQUFVQyxtQkFBbUI7QUFDdEMsU0FBU0MsV0FBVztBQUNwQixTQUFTQyxnQkFBZ0I7QUFFekIsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsK0JBQStCO0FBQ3hDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FFSztBQU9BLGdCQUFTQyxnQkFBZ0IsRUFBRUMsUUFBUUMsVUFBZ0MsR0FBRztBQUFBQyxLQUFBO0FBQzNFLFFBQU0sQ0FBQ0Msa0JBQWtCQyxtQkFBbUIsSUFBSWpCLFNBQVMsS0FBSztBQUM5RCxRQUFNa0IsVUFBVXJCLFNBQVNFLElBQUltQixRQUFRQyxZQUFZLEVBQUVOLE9BQU8sQ0FBQztBQUMzRCxRQUFNTyxRQUFRdkIsU0FBU0UsSUFBSW1CLFFBQVFHLFVBQVUsRUFBRVAsVUFBVSxDQUFDO0FBRTFELE1BQUksQ0FBQ0ksV0FBVyxDQUFDRSxPQUFPO0FBQ3RCLFdBQU8sdUJBQUMsU0FBSSxXQUFVLHNCQUFxQixrQ0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRDtBQUFBLEVBQy9EO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsT0FFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxrRUFDYjtBQUFBLDZCQUFDLFlBQVMsT0FBTSxpQkFBZ0IsT0FBT0YsUUFBUUksVUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRDtBQUFBLE1BQ3RELHVCQUFDLFlBQVMsT0FBTSxVQUFTLE9BQU9GLE1BQU1HLE9BQU9DLFFBQVEsWUFBVyxhQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlFO0FBQUEsTUFDekUsdUJBQUMsWUFBUyxPQUFNLFdBQVUsT0FBT0osTUFBTUcsT0FBT0UsUUFBUSxZQUFXLGVBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEU7QUFBQSxNQUM1RSx1QkFBQyxZQUFTLE9BQU0sY0FBYSxPQUFPTCxNQUFNRyxPQUFPRyxXQUFXLFlBQVcsc0JBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUY7QUFBQSxNQUN6Rix1QkFBQyxZQUFTLE9BQU0sYUFBWSxPQUFPTixNQUFNTyxTQUFTQyxRQUFRLENBQUMsS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLFNBTC9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVMsTUFBTVgsb0JBQW9CLElBQUk7QUFBQSxRQUN2QyxXQUFVO0FBQUEsUUFBb0o7QUFBQTtBQUFBLE1BRmhLO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsdUJBQ1pDLGtCQUFRSSxXQUFXLElBQ2xCLHVCQUFDLFNBQUksV0FBVSwrREFDYjtBQUFBLDZCQUFDLFlBQVMsV0FBVSxnQkFBZSxhQUFhLE9BQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0Q7QUFBQSxNQUNwRCx1QkFBQyxTQUFJLFdBQVUsc0NBQXFDLDhCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtFO0FBQUEsTUFDbEUsdUJBQUMsU0FBSSxXQUFVLG9CQUFtQixpREFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRTtBQUFBLFNBSHJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQSxJQUVBSixRQUFRVztBQUFBQSxNQUFJLENBQUNDLFdBQ1gsdUJBQUMsY0FBNEIsVUFBWkEsT0FBT0MsS0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QztBQUFBLElBQzdDLEtBVkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsSUFFQ2Ysb0JBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQTtBQUFBLFFBQ0EsU0FBUyxNQUFNQyxvQkFBb0IsS0FBSztBQUFBO0FBQUEsTUFIMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRzRDO0FBQUEsT0FyQ2hEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3Q0E7QUFFSjtBQUFDRixHQXBEZUgsaUJBQWU7QUFBQSxVQUViZixVQUNGQSxRQUFRO0FBQUE7QUFBQSxLQUhSZTtBQXNEaEIsTUFBTW9CLHFCQUFxQjtBQUUzQixTQUFTQyxTQUFTLEVBQUVDLE9BQU9DLE9BQU9DLFdBQTJFLEdBQUc7QUFDOUcsU0FDRSx1QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVduQyxHQUFHLDBDQUEwQ21DLGNBQWNKLGtCQUFrQixHQUMxRkcsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsaUNBQWlDRCxtQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRDtBQUFBLE9BSnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLQTtBQUVKO0FBQUNHLE1BVFFKO0FBV1QsTUFBTUssc0JBQThDO0FBQUEsRUFDbERkLFFBQVE7QUFBQSxFQUNSQyxRQUFRO0FBQUEsRUFDUkMsV0FBVztBQUFBLEVBQ1hhLFNBQVM7QUFDWDtBQUVBLE1BQU1DLG9CQUE0QztBQUFBLEVBQ2hEaEIsUUFBUTtBQUFBLEVBQ1JDLFFBQVE7QUFBQSxFQUNSQyxXQUFXO0FBQUEsRUFDWGEsU0FBUztBQUNYO0FBRUEsTUFBTUUsYUFBeUM7QUFBQSxFQUM3Q2pCLFFBQVFkO0FBQUFBLEVBQ1JlLFFBQVFyQjtBQUFBQSxFQUNSc0IsV0FBV2Y7QUFBQUEsRUFDWDRCLFNBQVNsQztBQUNYO0FBRUEsU0FBU3FDLFdBQVcsRUFBRVosT0FBWSxHQUFHO0FBQUFhLE1BQUE7QUFDbkMsUUFBTUMsa0JBQWtCOUMsWUFBWUMsSUFBSW1CLFFBQVEyQixPQUFPO0FBQ3ZELFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJL0MsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQ2dELGNBQWNDLGVBQWUsSUFBSWpELFNBQVMsRUFBRTtBQUVuRCxRQUFNa0QsZ0JBQWdCLE9BQU9DLFdBQW9CO0FBQy9DLFFBQUksQ0FBQ0gsYUFBYUksS0FBSyxFQUFHO0FBRTFCLFFBQUk7QUFDRixZQUFNUixnQkFBZ0I7QUFBQSxRQUNwQlMsVUFBVXZCLE9BQU9DO0FBQUFBLFFBQ2pCdUIsWUFBWXhCLE9BQU95QjtBQUFBQSxRQUNuQlA7QUFBQUEsUUFDQUc7QUFBQUEsTUFDRixDQUFDO0FBQ0RKLG9CQUFjLEtBQUs7QUFDbkJFLHNCQUFnQixFQUFFO0FBQUEsSUFDcEIsU0FBU08sT0FBTztBQUNkQyxjQUFRRCxNQUFNLCtCQUErQkEsS0FBSztBQUFBLElBQ3BEO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFXdkQ7QUFBQUEsSUFDZDtBQUFBLElBQ0FxQyxvQkFBb0JSLE9BQU80QixJQUFJLEtBQUs7QUFBQSxFQUN0QyxHQUVFO0FBQUEsMkJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUEsZUFBTTtBQUNOLGdCQUFNQyxXQUFXbEIsV0FBV1gsT0FBTzRCLElBQUksS0FBS3BEO0FBQzVDLGlCQUFPLHVCQUFDLFlBQVMsV0FBV0wsR0FBRyxXQUFXdUMsa0JBQWtCVixPQUFPNEIsSUFBSSxLQUFLLGdCQUFnQixHQUFHLGFBQWEsUUFBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEc7QUFBQSxRQUNuSCxHQUFHO0FBQUEsUUFDSCx1QkFBQyxVQUFLLFdBQVd6RCxHQUFHLDZCQUE2QnVDLGtCQUFrQlYsT0FBTzRCLElBQUksS0FBSyxnQkFBZ0IsR0FDaEc1QixpQkFBTzRCLFFBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQzVCLE9BQU84QixTQUNOLHVCQUFDLFVBQUssV0FBVSwwQkFBd0I7QUFBQTtBQUFBLFVBQzlCOUIsT0FBTzhCO0FBQUFBLFVBQU07QUFBQSxhQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNaLGNBQUlDLEtBQUsvQixPQUFPZ0MsYUFBYSxFQUFFQyxlQUFlLEtBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxxQ0FDWmpDLGlCQUFPa0MsV0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUdDbEMsT0FBT21DLFdBQ04sdUJBQUMsU0FBSSxXQUFVLG1DQUNabkMsaUJBQU9tQyxXQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBSURuQyxPQUFPb0MsYUFDTix1QkFBQyxTQUFJLFdBQVUsdURBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsdUNBQXFDLDhCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNDcEMsT0FBT29DLFVBQVVDLE1BQU10QztBQUFBQSxRQUFJLENBQUN1QyxNQUFXQyxRQUN0Qyx1QkFBQyxTQUFjLFdBQVUsNkRBQ3RCRDtBQUFBQSxlQUFLRSxXQUFXLFNBQVMsdUJBQUMsUUFBSyxXQUFVLFdBQVUsYUFBYSxRQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QztBQUFBLFVBQ3JFRixLQUFLRSxXQUFXLFlBQVksdUJBQUMsVUFBTyxXQUFVLFdBQVUsYUFBYSxRQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QztBQUFBLFVBQzFFRixLQUFLRSxXQUFXLFlBQVksdUJBQUMsU0FBTSxXQUFVLFdBQVUsYUFBYSxRQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QztBQUFBLFVBQzFFLHVCQUFDLFVBQUssV0FBVSxhQUFhRixlQUFLRyxRQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QztBQUFBLGFBSi9CRixLQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLE1BQ0Q7QUFBQSxTQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBSUYsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsNkJBQUMsZUFBWSxNQUFNdkMsT0FBTzBDLFdBQVcsWUFBWSxZQUFZLFdBQzFEMUMsaUJBQU8wQyxVQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0MxQyxPQUFPMkMsWUFDTix1QkFBQyxlQUFZLE1BQU0zQyxPQUFPMkMsYUFBYSxhQUFhLFVBQVUsV0FDM0QzQyxpQkFBTzJDLFlBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUdDM0MsT0FBTzBDLFdBQVcsYUFBYSxDQUFDMUIsY0FDL0I7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVMsTUFBTUMsY0FBYyxJQUFJO0FBQUEsUUFDakMsV0FBVTtBQUFBLFFBQThLO0FBQUE7QUFBQSxNQUYxTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLQTtBQUFBLElBR0RELGNBQ0MsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBT0U7QUFBQUEsVUFDUCxVQUFVLENBQUMwQixNQUFNekIsZ0JBQWdCeUIsRUFBRUMsT0FBT3hDLEtBQUs7QUFBQSxVQUMvQyxhQUFZO0FBQUEsVUFDWixXQUFVO0FBQUE7QUFBQSxRQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUkwSTtBQUFBLE1BRTFJLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTWUsY0FBYyxJQUFJO0FBQUEsWUFDakMsV0FBVTtBQUFBLFlBQWdJO0FBQUE7QUFBQSxVQUY1STtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUEsY0FBYyxLQUFLO0FBQUEsWUFDbEMsV0FBVTtBQUFBLFlBQStJO0FBQUE7QUFBQSxVQUYzSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUgsY0FBYyxLQUFLO0FBQUEsWUFDbEMsV0FBVTtBQUFBLFlBQTJLO0FBQUE7QUFBQSxVQUZ2TDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtQkE7QUFBQSxTQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkJBO0FBQUEsSUFJRGpCLE9BQU9rQixnQkFDTix1QkFBQyxTQUFJLFdBQVUsOEVBQ2I7QUFBQSw2QkFBQyxZQUFPLHlCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUI7QUFBQSxNQUFTO0FBQUEsTUFBRWxCLE9BQU9rQjtBQUFBQSxTQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQS9HSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUhBO0FBRUo7QUFBQ0wsSUExSVFELFlBQVU7QUFBQSxVQUNPNUMsV0FBVztBQUFBO0FBQUEsTUFENUI0QztBQTRJVCxTQUFTa0Msa0JBQWtCLEVBQUUvRCxRQUFRQyxXQUFXK0QsUUFBYSxHQUFHO0FBQUFDLE1BQUE7QUFDOUQsUUFBTUMsZUFBZWpGLFlBQVlDLElBQUltQixRQUFROEQsTUFBTTtBQUNuRCxRQUFNQyxTQUFTcEYsU0FBU0UsSUFBSWtGLE9BQU9DLFNBQVMsRUFBRXBFLFVBQVUsQ0FBQztBQUV6RCxRQUFNLENBQUM0QyxNQUFNeUIsT0FBTyxJQUFJbkYsU0FBd0QsUUFBUTtBQUN4RixRQUFNLENBQUNnRSxTQUFTb0IsVUFBVSxJQUFJcEYsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQ2lFLFNBQVNvQixVQUFVLElBQUlyRixTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDNEQsT0FBTzBCLFFBQVEsSUFBSXRGLFNBQVMsQ0FBQztBQUNwQyxRQUFNLENBQUN5RSxVQUFVYyxXQUFXLElBQUl2RixTQUF5QyxPQUFPO0FBQ2hGLFFBQU0sQ0FBQ3dGLGlCQUFpQkMsa0JBQWtCLElBQUl6RixTQUFTLEtBQUs7QUFFNUQsUUFBTTBGLGVBQWUsWUFBWTtBQUMvQixRQUFJLENBQUMxQixRQUFRWixLQUFLLEVBQUc7QUFFckIsUUFBSTtBQUNGLFlBQU0yQixhQUFhO0FBQUEsUUFDakJqRTtBQUFBQSxRQUNBRDtBQUFBQSxRQUNBNkM7QUFBQUEsUUFDQU07QUFBQUEsUUFDQUMsU0FBU0EsV0FBVzBCO0FBQUFBLFFBQ3BCQyxZQUFZO0FBQUEsUUFDWmhDLE9BQU9GLFNBQVMsV0FBV0UsUUFBUStCO0FBQUFBLFFBQ25DbEIsVUFBVWYsU0FBUyxXQUFXZSxXQUFXa0I7QUFBQUEsUUFDekNwQyxpQkFBaUIwQixTQUFTLENBQUMsR0FBR2xEO0FBQUFBLE1BQ2hDLENBQUM7QUFDRDhDLGNBQVE7QUFBQSxJQUNWLFNBQVNyQixPQUFPO0FBQ2RDLGNBQVFELE1BQU0sMEJBQTBCQSxLQUFLO0FBQUEsSUFDL0M7QUFBQSxFQUNGO0FBRUEsUUFBTXFDLGVBQWVBLE1BQU07QUFDekIsUUFBSSxDQUFDN0IsUUFBUVosS0FBSyxFQUFHO0FBQ3JCLFFBQUlNLFNBQVMsWUFBWUEsU0FBUyxhQUFhO0FBQzdDK0IseUJBQW1CLElBQUk7QUFDdkI7QUFBQSxJQUNGO0FBQ0EsU0FBS0MsYUFBYTtBQUFBLEVBQ3BCO0FBRUEsUUFBTUksZUFBZTtBQUVyQixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxXQUFVO0FBQUEsTUFDVixTQUFTakI7QUFBQUEsTUFFVDtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixTQUFTLENBQUNILE1BQU1BLEVBQUVxQixnQkFBZ0I7QUFBQSxZQUVsQztBQUFBLHFDQUFDLFFBQUcsV0FBVSw4QkFBNkIsNkJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdEO0FBQUEsY0FHeEQsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsc0JBQXFCLDJCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRDtBQUFBLGdCQUNqRCx1QkFBQyxZQUFPLE9BQU9yQyxNQUFNLFVBQVUsQ0FBQ2dCLE1BQU1TLFFBQVFULEVBQUVDLE9BQU94QyxLQUFZLEdBQUcsV0FBVzJELGNBQy9FO0FBQUEseUNBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZCO0FBQUEsa0JBQzdCLHVCQUFDLFlBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QjtBQUFBLGtCQUM3Qix1QkFBQyxZQUFPLE9BQU0sYUFBWSx5QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUM7QUFBQSxrQkFDbkMsdUJBQUMsWUFBTyxPQUFNLFdBQVUsdUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStCO0FBQUEscUJBSmpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxtQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxzQkFBcUIseUJBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStDO0FBQUEsZ0JBQy9DO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPOUI7QUFBQUEsb0JBQ1AsVUFBVSxDQUFDVSxNQUFNVSxXQUFXVixFQUFFQyxPQUFPeEMsS0FBSztBQUFBLG9CQUMxQyxhQUFZO0FBQUEsb0JBQ1osV0FBVzJEO0FBQUFBO0FBQUFBLGtCQUxiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLMEI7QUFBQSxtQkFQNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsc0JBQXFCLHVCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QztBQUFBLGdCQUM3QztBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUFPN0I7QUFBQUEsb0JBQ1AsVUFBVSxDQUFDUyxNQUFNVyxXQUFXWCxFQUFFQyxPQUFPeEMsS0FBSztBQUFBLG9CQUMxQyxhQUFZO0FBQUEsb0JBQ1osV0FBV2xDLEdBQUc2RixjQUFjLHVCQUF1QjtBQUFBO0FBQUEsa0JBSnJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJdUQ7QUFBQSxtQkFOekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGNBR0NwQyxTQUFTLFlBQ1IsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsc0JBQXFCO0FBQUE7QUFBQSxrQkFBUUU7QUFBQUEsa0JBQU07QUFBQSxxQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUQ7QUFBQSxnQkFDdkQ7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLEtBQUk7QUFBQSxvQkFDSixLQUFJO0FBQUEsb0JBQ0osT0FBT0E7QUFBQUEsb0JBQ1AsVUFBVSxDQUFDYyxNQUFNWSxTQUFTVSxTQUFTdEIsRUFBRUMsT0FBT3hDLEtBQUssQ0FBQztBQUFBLG9CQUNsRCxXQUFVO0FBQUE7QUFBQSxrQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTW9CO0FBQUEsbUJBUnRCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUdEdUIsU0FBUyxZQUNSLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLHNCQUFxQix3QkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEM7QUFBQSxnQkFDOUMsdUJBQUMsWUFBTyxPQUFPZSxVQUFVLFVBQVUsQ0FBQ0MsTUFBTWEsWUFBWWIsRUFBRUMsT0FBT3hDLEtBQVksR0FBRyxXQUFXMkQsY0FDdkY7QUFBQSx5Q0FBQyxZQUFPLE9BQU0sU0FBUSxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkI7QUFBQSxrQkFDM0IsdUJBQUMsWUFBTyxPQUFNLFNBQVEscUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJCO0FBQUEsa0JBQzNCLHVCQUFDLFlBQU8sT0FBTSxZQUFXLHdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQztBQUFBLHFCQUhuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBSUYsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBU2pCO0FBQUFBLG9CQUNULFdBQVU7QUFBQSxvQkFBd0w7QUFBQTtBQUFBLGtCQUZwTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTZ0I7QUFBQUEsb0JBQ1QsVUFBVSxDQUFDN0IsUUFBUVosS0FBSztBQUFBLG9CQUN4QixXQUFXbkQ7QUFBQUEsc0JBQ1Q7QUFBQSxzQkFDQStELFFBQVFaLEtBQUssSUFDVCx3REFDQTtBQUFBLG9CQUNOO0FBQUEsb0JBQUU7QUFBQTtBQUFBLGtCQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFXQTtBQUFBLG1CQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1CQTtBQUFBO0FBQUE7QUFBQSxVQXRGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUF1RkE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNb0M7QUFBQUEsWUFDTixTQUFTLE1BQU1DLG1CQUFtQixLQUFLO0FBQUEsWUFDdkMsa0JBQWtCLE1BQU07QUFDdEJBLGlDQUFtQixLQUFLO0FBQ3hCLG1CQUFLQyxhQUFhO0FBQUEsWUFDcEI7QUFBQTtBQUFBLFVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUk7QUFBQTtBQUFBO0FBQUEsSUFsR047QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBb0dBO0FBRUo7QUFBQ1osSUFsSlFGLG1CQUFpQjtBQUFBLFVBQ0g5RSxhQUNORCxRQUFRO0FBQUE7QUFBQSxNQUZoQitFO0FBQWlCLElBQUFxQixJQUFBNUQsS0FBQTZELEtBQUFDO0FBQUEsYUFBQUYsSUFBQTtBQUFBLGFBQUE1RCxLQUFBO0FBQUEsYUFBQTZELEtBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsidXNlUXVlcnkiLCJ1c2VNdXRhdGlvbiIsImFwaSIsInVzZVN0YXRlIiwiY24iLCJTdGF0dXNCYWRnZSIsIkhhcm5lc3NGaXJzdFJldmlld01vZGFsIiwiQWxlcnRUcmlhbmdsZSIsIkNoZWNrQ2lyY2xlMiIsIkZpbGVUZXh0IiwiTWludXMiLCJQZW5jaWwiLCJQbHVzIiwiVGh1bWJzVXAiLCJXcmVuY2giLCJQZWVyUmV2aWV3UGFuZWwiLCJ0YXNrSWQiLCJwcm9qZWN0SWQiLCJfcyIsInNob3dDcmVhdGVSZXZpZXciLCJzZXRTaG93Q3JlYXRlUmV2aWV3IiwicmV2aWV3cyIsImxpc3RCeVRhc2siLCJzdGF0cyIsImdldFN0YXRzIiwibGVuZ3RoIiwiYnlUeXBlIiwiUFJBSVNFIiwiUkVGVVRFIiwiQ0hBTkdFU0VUIiwiYXZnU2NvcmUiLCJ0b0ZpeGVkIiwibWFwIiwicmV2aWV3IiwiX2lkIiwiU1RBVF9ERUZBVUxUX0NMQVNTIiwiU3RhdENhcmQiLCJsYWJlbCIsInZhbHVlIiwiY29sb3JDbGFzcyIsIl9jMiIsIlRZUEVfQk9SREVSX0NMQVNTRVMiLCJBUFBST1ZFIiwiVFlQRV9URVhUX0NMQVNTRVMiLCJUWVBFX0lDT05TIiwiUmV2aWV3Q2FyZCIsIl9zMiIsInJlc3BvbmRUb1JldmlldyIsInJlc3BvbmQiLCJyZXNwb25kaW5nIiwic2V0UmVzcG9uZGluZyIsInJlc3BvbnNlVGV4dCIsInNldFJlc3BvbnNlVGV4dCIsImhhbmRsZVJlc3BvbmQiLCJhY2NlcHQiLCJ0cmltIiwicmV2aWV3SWQiLCJyZXNwb25zZUJ5IiwicmV2aWV3ZXJBZ2VudElkIiwiZXJyb3IiLCJjb25zb2xlIiwidHlwZSIsIlR5cGVJY29uIiwic2NvcmUiLCJEYXRlIiwiX2NyZWF0aW9uVGltZSIsInRvTG9jYWxlU3RyaW5nIiwic3VtbWFyeSIsImRldGFpbHMiLCJjaGFuZ2VzZXQiLCJmaWxlcyIsImZpbGUiLCJpZHgiLCJhY3Rpb24iLCJwYXRoIiwic3RhdHVzIiwic2V2ZXJpdHkiLCJlIiwidGFyZ2V0IiwiQ3JlYXRlUmV2aWV3TW9kYWwiLCJvbkNsb3NlIiwiX3MzIiwiY3JlYXRlUmV2aWV3IiwiY3JlYXRlIiwiYWdlbnRzIiwibGlzdEFsbCIsInNldFR5cGUiLCJzZXRTdW1tYXJ5Iiwic2V0RGV0YWlscyIsInNldFNjb3JlIiwic2V0U2V2ZXJpdHkiLCJzaG93SGFybmVzc0dhdGUiLCJzZXRTaG93SGFybmVzc0dhdGUiLCJzdWJtaXRSZXZpZXciLCJ1bmRlZmluZWQiLCJ0YXJnZXRUeXBlIiwiaGFuZGxlU3VibWl0IiwiaW5wdXRDbGFzc2VzIiwic3RvcFByb3BhZ2F0aW9uIiwicGFyc2VJbnQiLCJfYyIsIl9jMyIsIl9jNCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQZWVyUmV2aWV3UGFuZWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVF1ZXJ5LCB1c2VNdXRhdGlvbiB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcbmltcG9ydCB7IFN0YXR1c0JhZGdlIH0gZnJvbSBcIkAvY29tcG9uZW50cy9mYWN0b3J5L2JhZGdlc1wiO1xuaW1wb3J0IHsgSGFybmVzc0ZpcnN0UmV2aWV3TW9kYWwgfSBmcm9tIFwiLi9oYXJuZXNzL2NvbXBvbmVudHMvSGFybmVzc0ZpcnN0UmV2aWV3TW9kYWxcIjtcbmltcG9ydCB7XG4gIEFsZXJ0VHJpYW5nbGUsXG4gIENoZWNrQ2lyY2xlMixcbiAgRmlsZVRleHQsXG4gIE1pbnVzLFxuICBQZW5jaWwsXG4gIFBsdXMsXG4gIFRodW1ic1VwLFxuICBXcmVuY2gsXG4gIHR5cGUgTHVjaWRlSWNvbixcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuXG5pbnRlcmZhY2UgUGVlclJldmlld1BhbmVsUHJvcHMge1xuICB0YXNrSWQ6IElkPFwidGFza3NcIj47XG4gIHByb2plY3RJZDogSWQ8XCJwcm9qZWN0c1wiPjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFBlZXJSZXZpZXdQYW5lbCh7IHRhc2tJZCwgcHJvamVjdElkIH06IFBlZXJSZXZpZXdQYW5lbFByb3BzKSB7XG4gIGNvbnN0IFtzaG93Q3JlYXRlUmV2aWV3LCBzZXRTaG93Q3JlYXRlUmV2aWV3XSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgcmV2aWV3cyA9IHVzZVF1ZXJ5KGFwaS5yZXZpZXdzLmxpc3RCeVRhc2ssIHsgdGFza0lkIH0pO1xuICBjb25zdCBzdGF0cyA9IHVzZVF1ZXJ5KGFwaS5yZXZpZXdzLmdldFN0YXRzLCB7IHByb2plY3RJZCB9KTtcblxuICBpZiAoIXJldmlld3MgfHwgIXN0YXRzKSB7XG4gICAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwicC01IHRleHQtaW5rLW11dGVkXCI+TG9hZGluZyByZXZpZXdzLi4uPC9kaXY+O1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNVwiPlxuICAgICAgey8qIFN0YXRzIFN1bW1hcnkgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLVtyZXBlYXQoYXV0by1maXQsbWlubWF4KDE1MHB4LDFmcikpXSBnYXAtMyBtYi01XCI+XG4gICAgICAgIDxTdGF0Q2FyZCBsYWJlbD1cIlRvdGFsIFJldmlld3NcIiB2YWx1ZT17cmV2aWV3cy5sZW5ndGh9IC8+XG4gICAgICAgIDxTdGF0Q2FyZCBsYWJlbD1cIlByYWlzZVwiIHZhbHVlPXtzdGF0cy5ieVR5cGUuUFJBSVNFfSBjb2xvckNsYXNzPVwidGV4dC1va1wiIC8+XG4gICAgICAgIDxTdGF0Q2FyZCBsYWJlbD1cIlJlZnV0ZXNcIiB2YWx1ZT17c3RhdHMuYnlUeXBlLlJFRlVURX0gY29sb3JDbGFzcz1cInRleHQtd2FyblwiIC8+XG4gICAgICAgIDxTdGF0Q2FyZCBsYWJlbD1cIkNoYW5nZXNldHNcIiB2YWx1ZT17c3RhdHMuYnlUeXBlLkNIQU5HRVNFVH0gY29sb3JDbGFzcz1cInRleHQtaW5mby1hY2NlbnRcIiAvPlxuICAgICAgICA8U3RhdENhcmQgbGFiZWw9XCJBdmcgU2NvcmVcIiB2YWx1ZT17c3RhdHMuYXZnU2NvcmUudG9GaXhlZCgxKX0gLz5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQ3JlYXRlIFJldmlldyBCdXR0b24gKi99XG4gICAgICA8YnV0dG9uXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dDcmVhdGVSZXZpZXcodHJ1ZSl9XG4gICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTkgYmctYWN0IHRleHQtYWN0LWluayBib3JkZXItbm9uZSByb3VuZGVkLWxnIHRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIGN1cnNvci1wb2ludGVyIG1iLTUgdHJhbnNpdGlvbi1vcGFjaXR5IGR1cmF0aW9uLTE1MCBob3ZlcjpvcGFjaXR5LTkwXCJcbiAgICAgID5cbiAgICAgICAgQ3JlYXRlIFJldmlld1xuICAgICAgPC9idXR0b24+XG5cbiAgICAgIHsvKiBSZXZpZXdzIExpc3QgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTNcIj5cbiAgICAgICAge3Jldmlld3MubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgdGV4dC1jZW50ZXIgcHktMTAgdGV4dC1pbmstbXV0ZWRcIj5cbiAgICAgICAgICAgIDxGaWxlVGV4dCBjbGFzc05hbWU9XCJoLTcgdy03IG1iLTNcIiBzdHJva2VXaWR0aD17MS41fSAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxNXB4XSBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+Tm8gcmV2aWV3cyB5ZXQ8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gbXQtMlwiPkJlIHRoZSBmaXJzdCB0byByZXZpZXcgdGhpcyB0YXNrLjwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIHJldmlld3MubWFwKChyZXZpZXcpID0+IChcbiAgICAgICAgICAgIDxSZXZpZXdDYXJkIGtleT17cmV2aWV3Ll9pZH0gcmV2aWV3PXtyZXZpZXd9IC8+XG4gICAgICAgICAgKSlcbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7c2hvd0NyZWF0ZVJldmlldyAmJiAoXG4gICAgICAgIDxDcmVhdGVSZXZpZXdNb2RhbFxuICAgICAgICAgIHRhc2tJZD17dGFza0lkfVxuICAgICAgICAgIHByb2plY3RJZD17cHJvamVjdElkfVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dDcmVhdGVSZXZpZXcoZmFsc2UpfVxuICAgICAgICAvPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuY29uc3QgU1RBVF9ERUZBVUxUX0NMQVNTID0gXCJ0ZXh0LWlua1wiO1xuXG5mdW5jdGlvbiBTdGF0Q2FyZCh7IGxhYmVsLCB2YWx1ZSwgY29sb3JDbGFzcyB9OiB7IGxhYmVsOiBzdHJpbmc7IHZhbHVlOiBudW1iZXIgfCBzdHJpbmc7IGNvbG9yQ2xhc3M/OiBzdHJpbmcgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc3VyZmFjZS0yIHJvdW5kZWQtbGcgcC0zIGJvcmRlciBib3JkZXItbGluZVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9e2NuKFwidGV4dC1bMTlweF0gZm9udC1zZW1pYm9sZCB0YWJ1bGFyLW51bXNcIiwgY29sb3JDbGFzcyB8fCBTVEFUX0RFRkFVTFRfQ0xBU1MpfT5cbiAgICAgICAge3ZhbHVlfVxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1pbmstbXV0ZWQgbXQtMC41XCI+e2xhYmVsfTwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5jb25zdCBUWVBFX0JPUkRFUl9DTEFTU0VTOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICBQUkFJU0U6IFwiYm9yZGVyLWwtb2tcIixcbiAgUkVGVVRFOiBcImJvcmRlci1sLXdhcm5cIixcbiAgQ0hBTkdFU0VUOiBcImJvcmRlci1sLWluZm8tYWNjZW50XCIsXG4gIEFQUFJPVkU6IFwiYm9yZGVyLWwtb2tcIixcbn07XG5cbmNvbnN0IFRZUEVfVEVYVF9DTEFTU0VTOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICBQUkFJU0U6IFwidGV4dC1va1wiLFxuICBSRUZVVEU6IFwidGV4dC13YXJuXCIsXG4gIENIQU5HRVNFVDogXCJ0ZXh0LWluZm8tYWNjZW50XCIsXG4gIEFQUFJPVkU6IFwidGV4dC1va1wiLFxufTtcblxuY29uc3QgVFlQRV9JQ09OUzogUmVjb3JkPHN0cmluZywgTHVjaWRlSWNvbj4gPSB7XG4gIFBSQUlTRTogVGh1bWJzVXAsXG4gIFJFRlVURTogQWxlcnRUcmlhbmdsZSxcbiAgQ0hBTkdFU0VUOiBXcmVuY2gsXG4gIEFQUFJPVkU6IENoZWNrQ2lyY2xlMixcbn07XG5cbmZ1bmN0aW9uIFJldmlld0NhcmQoeyByZXZpZXcgfTogYW55KSB7XG4gIGNvbnN0IHJlc3BvbmRUb1JldmlldyA9IHVzZU11dGF0aW9uKGFwaS5yZXZpZXdzLnJlc3BvbmQpO1xuICBjb25zdCBbcmVzcG9uZGluZywgc2V0UmVzcG9uZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtyZXNwb25zZVRleHQsIHNldFJlc3BvbnNlVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcblxuICBjb25zdCBoYW5kbGVSZXNwb25kID0gYXN5bmMgKGFjY2VwdDogYm9vbGVhbikgPT4ge1xuICAgIGlmICghcmVzcG9uc2VUZXh0LnRyaW0oKSkgcmV0dXJuO1xuICAgIFxuICAgIHRyeSB7XG4gICAgICBhd2FpdCByZXNwb25kVG9SZXZpZXcoe1xuICAgICAgICByZXZpZXdJZDogcmV2aWV3Ll9pZCxcbiAgICAgICAgcmVzcG9uc2VCeTogcmV2aWV3LnJldmlld2VyQWdlbnRJZCxcbiAgICAgICAgcmVzcG9uc2VUZXh0LFxuICAgICAgICBhY2NlcHQsXG4gICAgICB9KTtcbiAgICAgIHNldFJlc3BvbmRpbmcoZmFsc2UpO1xuICAgICAgc2V0UmVzcG9uc2VUZXh0KFwiXCIpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgcmVzcG9uZGluZyB0byByZXZpZXc6XCIsIGVycm9yKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17Y24oXG4gICAgICBcImJnLXN1cmZhY2UtMSByb3VuZGVkLWxnIHAtNCBib3JkZXIgYm9yZGVyLWxpbmUgYm9yZGVyLWwtMlwiLFxuICAgICAgVFlQRV9CT1JERVJfQ0xBU1NFU1tyZXZpZXcudHlwZV0gfHwgXCJib3JkZXItbC1saW5lLXN0cm9uZ1wiXG4gICAgKX0+XG4gICAgICB7LyogSGVhZGVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBtYi0zXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICB7KCgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IFR5cGVJY29uID0gVFlQRV9JQ09OU1tyZXZpZXcudHlwZV0gPz8gRmlsZVRleHQ7XG4gICAgICAgICAgICByZXR1cm4gPFR5cGVJY29uIGNsYXNzTmFtZT17Y24oXCJoLTQgdy00XCIsIFRZUEVfVEVYVF9DTEFTU0VTW3Jldmlldy50eXBlXSB8fCBcInRleHQtaW5rLW11dGVkXCIpfSBzdHJva2VXaWR0aD17MS43NX0gLz47XG4gICAgICAgICAgfSkoKX1cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2NuKFwidGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZFwiLCBUWVBFX1RFWFRfQ0xBU1NFU1tyZXZpZXcudHlwZV0gfHwgXCJ0ZXh0LWluay1tdXRlZFwiKX0+XG4gICAgICAgICAgICB7cmV2aWV3LnR5cGV9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIHtyZXZpZXcuc2NvcmUgJiYgKFxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICBTY29yZToge3Jldmlldy5zY29yZX0vMTBcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAge25ldyBEYXRlKHJldmlldy5fY3JlYXRpb25UaW1lKS50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogU3VtbWFyeSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSBtYi0yIHRleHQtaW5rXCI+XG4gICAgICAgIHtyZXZpZXcuc3VtbWFyeX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogRGV0YWlscyAqL31cbiAgICAgIHtyZXZpZXcuZGV0YWlscyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gdGV4dC1pbmstbXV0ZWQgbWItM1wiPlxuICAgICAgICAgIHtyZXZpZXcuZGV0YWlsc31cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogQ2hhbmdlc2V0ICovfVxuICAgICAge3Jldmlldy5jaGFuZ2VzZXQgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXN1cmZhY2UtMiBib3JkZXIgYm9yZGVyLWxpbmUgcm91bmRlZC1tZCBwLTMgbWItM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIG1iLTIgdGV4dC1pbmtcIj5cbiAgICAgICAgICAgIEZpbGVzIENoYW5nZWQ6XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAge3Jldmlldy5jaGFuZ2VzZXQuZmlsZXMubWFwKChmaWxlOiBhbnksIGlkeDogbnVtYmVyKSA9PiAoXG4gICAgICAgICAgICA8ZGl2IGtleT17aWR4fSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtWzExcHhdIHRleHQtaW5rLW11dGVkIG1iLTFcIj5cbiAgICAgICAgICAgICAge2ZpbGUuYWN0aW9uID09PSBcIkFERFwiICYmIDxQbHVzIGNsYXNzTmFtZT1cImgtMyB3LTNcIiBzdHJva2VXaWR0aD17MS43NX0gLz59XG4gICAgICAgICAgICAgIHtmaWxlLmFjdGlvbiA9PT0gXCJNT0RJRllcIiAmJiA8UGVuY2lsIGNsYXNzTmFtZT1cImgtMyB3LTNcIiBzdHJva2VXaWR0aD17MS43NX0gLz59XG4gICAgICAgICAgICAgIHtmaWxlLmFjdGlvbiA9PT0gXCJERUxFVEVcIiAmJiA8TWludXMgY2xhc3NOYW1lPVwiaC0zIHctM1wiIHN0cm9rZVdpZHRoPXsxLjc1fSAvPn1cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vXCI+e2ZpbGUucGF0aH08L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogU3RhdHVzIEJhZGdlICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICA8U3RhdHVzQmFkZ2UgdG9uZT17cmV2aWV3LnN0YXR1cyA9PT0gXCJQRU5ESU5HXCIgPyBcIndhcm5pbmdcIiA6IFwic3VjY2Vzc1wifT5cbiAgICAgICAgICB7cmV2aWV3LnN0YXR1c31cbiAgICAgICAgPC9TdGF0dXNCYWRnZT5cbiAgICAgICAge3Jldmlldy5zZXZlcml0eSAmJiAoXG4gICAgICAgICAgPFN0YXR1c0JhZGdlIHRvbmU9e3Jldmlldy5zZXZlcml0eSA9PT0gXCJDUklUSUNBTFwiID8gXCJlcnJvclwiIDogXCJ3YXJuaW5nXCJ9PlxuICAgICAgICAgICAge3Jldmlldy5zZXZlcml0eX1cbiAgICAgICAgICA8L1N0YXR1c0JhZGdlPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBSZXNwb25zZSBTZWN0aW9uICovfVxuICAgICAge3Jldmlldy5zdGF0dXMgPT09IFwiUEVORElOR1wiICYmICFyZXNwb25kaW5nICYmIChcbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJlc3BvbmRpbmcodHJ1ZSl9XG4gICAgICAgICAgY2xhc3NOYW1lPVwibXQtMyBweC0zIHB5LTIgYmctdHJhbnNwYXJlbnQgYm9yZGVyIGJvcmRlci1saW5lIHJvdW5kZWQtbGcgdGV4dC1pbmstc2Vjb25kYXJ5IHRleHQteHMgY3Vyc29yLXBvaW50ZXIgaG92ZXI6dGV4dC1pbmsgaG92ZXI6Ym9yZGVyLWxpbmUtc3Ryb25nIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiXG4gICAgICAgID5cbiAgICAgICAgICBSZXNwb25kXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgKX1cblxuICAgICAge3Jlc3BvbmRpbmcgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTNcIj5cbiAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgIHZhbHVlPXtyZXNwb25zZVRleHR9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJlc3BvbnNlVGV4dChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIllvdXIgcmVzcG9uc2UuLi5cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1pbi1oLVs2MHB4XSBwLTIgYmctc3VyZmFjZS0xIGJvcmRlciBib3JkZXItbGluZSByb3VuZGVkLWxnIHRleHQtaW5rIHRleHQteHMgbWItMiByZXNpemUteSBwbGFjZWhvbGRlcjp0ZXh0LWluay1tdXRlZFwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUmVzcG9uZCh0cnVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgYmctYWN0IHRleHQtYWN0LWluayBib3JkZXItbm9uZSByb3VuZGVkLWxnIHRleHQteHMgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1vcGFjaXR5IGR1cmF0aW9uLTE1MCBob3ZlcjpvcGFjaXR5LTkwXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgQWNjZXB0XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUmVzcG9uZChmYWxzZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IGJnLWVyci1zb2Z0IHRleHQtZXJyIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcm91bmRlZC1sZyB0ZXh0LXhzIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tb3BhY2l0eSBkdXJhdGlvbi0xNTAgaG92ZXI6b3BhY2l0eS05MFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIFJlamVjdFxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJlc3BvbmRpbmcoZmFsc2UpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSBiZy10cmFuc3BhcmVudCBib3JkZXIgYm9yZGVyLWxpbmUgcm91bmRlZC1sZyB0ZXh0LWluay1zZWNvbmRhcnkgdGV4dC14cyBjdXJzb3ItcG9pbnRlciBob3Zlcjp0ZXh0LWluayBob3Zlcjpib3JkZXItbGluZS1zdHJvbmcgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgQ2FuY2VsXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogUmVzb2x2ZWQgUmVzcG9uc2UgKi99XG4gICAgICB7cmV2aWV3LnJlc3BvbnNlVGV4dCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBwLTIgYmctc3VyZmFjZS0yIGJvcmRlciBib3JkZXItbGluZSByb3VuZGVkLW1kIHRleHQteHMgdGV4dC1pbmstbXV0ZWRcIj5cbiAgICAgICAgICA8c3Ryb25nPlJlc3BvbnNlOjwvc3Ryb25nPiB7cmV2aWV3LnJlc3BvbnNlVGV4dH1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufVxuXG5mdW5jdGlvbiBDcmVhdGVSZXZpZXdNb2RhbCh7IHRhc2tJZCwgcHJvamVjdElkLCBvbkNsb3NlIH06IGFueSkge1xuICBjb25zdCBjcmVhdGVSZXZpZXcgPSB1c2VNdXRhdGlvbihhcGkucmV2aWV3cy5jcmVhdGUpO1xuICBjb25zdCBhZ2VudHMgPSB1c2VRdWVyeShhcGkuYWdlbnRzLmxpc3RBbGwsIHsgcHJvamVjdElkIH0pO1xuICBcbiAgY29uc3QgW3R5cGUsIHNldFR5cGVdID0gdXNlU3RhdGU8XCJQUkFJU0VcIiB8IFwiUkVGVVRFXCIgfCBcIkNIQU5HRVNFVFwiIHwgXCJBUFBST1ZFXCI+KFwiUFJBSVNFXCIpO1xuICBjb25zdCBbc3VtbWFyeSwgc2V0U3VtbWFyeV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2RldGFpbHMsIHNldERldGFpbHNdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtzY29yZSwgc2V0U2NvcmVdID0gdXNlU3RhdGUoOCk7XG4gIGNvbnN0IFtzZXZlcml0eSwgc2V0U2V2ZXJpdHldID0gdXNlU3RhdGU8XCJNSU5PUlwiIHwgXCJNQUpPUlwiIHwgXCJDUklUSUNBTFwiPihcIk1JTk9SXCIpO1xuICBjb25zdCBbc2hvd0hhcm5lc3NHYXRlLCBzZXRTaG93SGFybmVzc0dhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IHN1Ym1pdFJldmlldyA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXN1bW1hcnkudHJpbSgpKSByZXR1cm47XG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgY3JlYXRlUmV2aWV3KHtcbiAgICAgICAgcHJvamVjdElkLFxuICAgICAgICB0YXNrSWQsXG4gICAgICAgIHR5cGUsXG4gICAgICAgIHN1bW1hcnksXG4gICAgICAgIGRldGFpbHM6IGRldGFpbHMgfHwgdW5kZWZpbmVkLFxuICAgICAgICB0YXJnZXRUeXBlOiBcIlRBU0tcIixcbiAgICAgICAgc2NvcmU6IHR5cGUgPT09IFwiUFJBSVNFXCIgPyBzY29yZSA6IHVuZGVmaW5lZCxcbiAgICAgICAgc2V2ZXJpdHk6IHR5cGUgPT09IFwiUkVGVVRFXCIgPyBzZXZlcml0eSA6IHVuZGVmaW5lZCxcbiAgICAgICAgcmV2aWV3ZXJBZ2VudElkOiBhZ2VudHM/LlswXT8uX2lkLFxuICAgICAgfSk7XG4gICAgICBvbkNsb3NlKCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBjcmVhdGluZyByZXZpZXc6XCIsIGVycm9yKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gKCkgPT4ge1xuICAgIGlmICghc3VtbWFyeS50cmltKCkpIHJldHVybjtcbiAgICBpZiAodHlwZSA9PT0gXCJSRUZVVEVcIiB8fCB0eXBlID09PSBcIkNIQU5HRVNFVFwiKSB7XG4gICAgICBzZXRTaG93SGFybmVzc0dhdGUodHJ1ZSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHZvaWQgc3VibWl0UmV2aWV3KCk7XG4gIH07XG5cbiAgY29uc3QgaW5wdXRDbGFzc2VzID0gXCJ3LWZ1bGwgaC05IHB4LTMgYmctc3VyZmFjZS0xIGJvcmRlciBib3JkZXItbGluZSByb3VuZGVkLWxnIHRleHQtaW5rIHRleHQtWzEzLjVweF0gcGxhY2Vob2xkZXI6dGV4dC1pbmstbXV0ZWRcIjtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svODAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgei1bMTAwMF1cIlxuICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICA+XG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzTmFtZT1cImJnLXN1cmZhY2UtMyBib3JkZXIgYm9yZGVyLWxpbmUgcm91bmRlZC14bCBzaGFkb3ctW3ZhcigtLXNoYWRvdy1lbGV2YXRpb24tMildIG1heC13LVs1MDBweF0gdy1mdWxsIHAtNiB0ZXh0LWlua1wiXG4gICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNSB0ZXh0LWxnIGZvbnQtc2VtaWJvbGRcIj5DcmVhdGUgUmV2aWV3PC9oMz5cblxuICAgICAgICB7LyogVHlwZSBTZWxlY3Rpb24gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIG1iLTJcIj5SZXZpZXcgVHlwZTwvbGFiZWw+XG4gICAgICAgICAgPHNlbGVjdCB2YWx1ZT17dHlwZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRUeXBlKGUudGFyZ2V0LnZhbHVlIGFzIGFueSl9IGNsYXNzTmFtZT17aW5wdXRDbGFzc2VzfT5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJQUkFJU0VcIj5QcmFpc2U8L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJSRUZVVEVcIj5SZWZ1dGU8L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDSEFOR0VTRVRcIj5DaGFuZ2VzZXQ8L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBUFBST1ZFXCI+QXBwcm92ZTwvb3B0aW9uPlxuICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogU3VtbWFyeSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gbWItMlwiPlN1bW1hcnkgKjwvbGFiZWw+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICB2YWx1ZT17c3VtbWFyeX1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U3VtbWFyeShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkJyaWVmIHN1bW1hcnkgb2YgeW91ciByZXZpZXdcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPXtpbnB1dENsYXNzZXN9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIERldGFpbHMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIG1iLTJcIj5EZXRhaWxzPC9sYWJlbD5cbiAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgIHZhbHVlPXtkZXRhaWxzfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREZXRhaWxzKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGV0YWlsZWQgZXhwbGFuYXRpb24uLi5cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihpbnB1dENsYXNzZXMsIFwibWluLWgtWzgwcHhdIHJlc2l6ZS15XCIpfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBDb25kaXRpb25hbCBGaWVsZHMgKi99XG4gICAgICAgIHt0eXBlID09PSBcIlBSQUlTRVwiICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIG1iLTJcIj5TY29yZToge3Njb3JlfS8xMDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgbWluPVwiMVwiXG4gICAgICAgICAgICAgIG1heD1cIjEwXCJcbiAgICAgICAgICAgICAgdmFsdWU9e3Njb3JlfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNjb3JlKHBhcnNlSW50KGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHt0eXBlID09PSBcIlJFRlVURVwiICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIG1iLTJcIj5TZXZlcml0eTwvbGFiZWw+XG4gICAgICAgICAgICA8c2VsZWN0IHZhbHVlPXtzZXZlcml0eX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRTZXZlcml0eShlLnRhcmdldC52YWx1ZSBhcyBhbnkpfSBjbGFzc05hbWU9e2lucHV0Q2xhc3Nlc30+XG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNSU5PUlwiPk1pbm9yPC9vcHRpb24+XG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNQUpPUlwiPk1ham9yPC9vcHRpb24+XG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDUklUSUNBTFwiPkNyaXRpY2FsPC9vcHRpb24+XG4gICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogQWN0aW9ucyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0zIGp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOSBweC0zIGJnLXRyYW5zcGFyZW50IGJvcmRlciBib3JkZXItbGluZSByb3VuZGVkLWxnIHRleHQtaW5rLXNlY29uZGFyeSB0ZXh0LVsxM3B4XSBmb250LW1lZGl1bSBjdXJzb3ItcG9pbnRlciBob3Zlcjp0ZXh0LWluayBob3Zlcjpib3JkZXItbGluZS1zdHJvbmcgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTdWJtaXR9XG4gICAgICAgICAgICBkaXNhYmxlZD17IXN1bW1hcnkudHJpbSgpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgXCJoLTkgcHgtMyBib3JkZXItbm9uZSByb3VuZGVkLWxnIHRleHQtWzEzcHhdIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tb3BhY2l0eSBkdXJhdGlvbi0xNTBcIixcbiAgICAgICAgICAgICAgc3VtbWFyeS50cmltKClcbiAgICAgICAgICAgICAgICA/IFwiYmctYWN0IHRleHQtYWN0LWluayBjdXJzb3ItcG9pbnRlciBob3ZlcjpvcGFjaXR5LTkwXCJcbiAgICAgICAgICAgICAgICA6IFwiYmctc3VyZmFjZS0yIHRleHQtaW5rLW11dGVkIGN1cnNvci1ub3QtYWxsb3dlZFwiXG4gICAgICAgICAgICApfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIENyZWF0ZSBSZXZpZXdcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxIYXJuZXNzRmlyc3RSZXZpZXdNb2RhbFxuICAgICAgICBvcGVuPXtzaG93SGFybmVzc0dhdGV9XG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dIYXJuZXNzR2F0ZShmYWxzZSl9XG4gICAgICAgIG9uUHJvY2VlZENvbW1lbnQ9eygpID0+IHtcbiAgICAgICAgICBzZXRTaG93SGFybmVzc0dhdGUoZmFsc2UpO1xuICAgICAgICAgIHZvaWQgc3VibWl0UmV2aWV3KCk7XG4gICAgICAgIH19XG4gICAgICAvPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvUGVlclJldmlld1BhbmVsLnRzeCJ9