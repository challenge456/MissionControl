import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PageHeader.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PageHeader.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { cn } from "/src/lib/utils.ts";
export function PageHeader({
  title,
  description,
  actions,
  status,
  icon,
  eyebrow,
  tabs
}) {
  return /* @__PURE__ */ jsxDEV("header", { className: "relative shrink-0 border-b border-line bg-app", children: /* @__PURE__ */ jsxDEV("div", { className: "relative px-6 py-5", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
        eyebrow ? /* @__PURE__ */ jsxDEV("div", { className: "registry-kicker", children: eyebrow }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PageHeader.tsx",
          lineNumber: 50,
          columnNumber: 26
        }, this) : null,
        /* @__PURE__ */ jsxDEV("div", { className: "flex min-w-0 items-start gap-3", children: [
          icon ? /* @__PURE__ */ jsxDEV("div", { className: "mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-line bg-surface-1 text-registry-accent", children: icon }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PageHeader.tsx",
            lineNumber: 53,
            columnNumber: 17
          }, this) : null,
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2.5", children: [
              /* @__PURE__ */ jsxDEV("h1", { className: "text-[26px] font-semibold leading-tight tracking-tight text-ink", children: title }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PageHeader.tsx",
                lineNumber: 59,
                columnNumber: 21
              }, this),
              status
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PageHeader.tsx",
              lineNumber: 58,
              columnNumber: 19
            }, this),
            description ? /* @__PURE__ */ jsxDEV("p", { className: "mt-1.5 max-w-3xl text-[14px] leading-relaxed text-ink-secondary", children: description }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PageHeader.tsx",
              lineNumber: 65,
              columnNumber: 19
            }, this) : null
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PageHeader.tsx",
            lineNumber: 57,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PageHeader.tsx",
          lineNumber: 51,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PageHeader.tsx",
        lineNumber: 49,
        columnNumber: 13
      }, this),
      actions ? /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: cn(
            "flex flex-wrap items-center gap-2 xl:max-w-[48%] xl:justify-end",
            !description && "xl:self-center"
          ),
          children: actions
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PageHeader.tsx",
          lineNumber: 73,
          columnNumber: 13
        },
        this
      ) : null
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PageHeader.tsx",
      lineNumber: 48,
      columnNumber: 11
    }, this),
    tabs
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PageHeader.tsx",
    lineNumber: 47,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PageHeader.tsx",
    lineNumber: 46,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PageHeader.tsx",
    lineNumber: 45,
    columnNumber: 5
  }, this);
}
_c = PageHeader;
var _c;
$RefreshReg$(_c, "PageHeader");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PageHeader.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/PageHeader.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEJ5Qjs7Ozs7Ozs7Ozs7Ozs7OztBQTdCekIsU0FBU0EsVUFBVTtBQWNaLGdCQUFTQyxXQUFXO0FBQUEsRUFDekJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ2UsR0FBZ0I7QUFDL0IsU0FDRSx1QkFBQyxZQUFPLFdBQVUsaURBQ2hCLGlDQUFDLFNBQUksV0FBVSxzQkFDYixpQ0FBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsbUVBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsV0FDWkQ7QUFBQUEsa0JBQVUsdUJBQUMsU0FBSSxXQUFVLG1CQUFtQkEscUJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEMsSUFBUztBQUFBLFFBQzlELHVCQUFDLFNBQUksV0FBVSxrQ0FDWkQ7QUFBQUEsaUJBQ0MsdUJBQUMsU0FBSSxXQUFVLDhIQUNaQSxrQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLElBQ0U7QUFBQSxVQUNKLHVCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEscUNBQUMsUUFBRyxXQUFVLG1FQUNYSixtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQ0c7QUFBQUEsaUJBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0NGLGNBQ0MsdUJBQUMsT0FBRSxXQUFVLG1FQUNWQSx5QkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLElBQ0U7QUFBQSxlQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxhQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBO0FBQUEsV0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQTtBQUFBLE1BQ0NDLFVBQ0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVdKO0FBQUFBLFlBQ1Q7QUFBQSxZQUNBLENBQUNHLGVBQWU7QUFBQSxVQUNsQjtBQUFBLFVBRUNDO0FBQUFBO0FBQUFBLFFBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0EsSUFDRTtBQUFBLFNBakNOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQ0E7QUFBQSxJQUNDSTtBQUFBQSxPQXBDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUNBLEtBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1Q0EsS0F4Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlDQTtBQUVKO0FBQUNDLEtBckRlUjtBQUFVLElBQUFRO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbImNuIiwiUGFnZUhlYWRlciIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJhY3Rpb25zIiwic3RhdHVzIiwiaWNvbiIsImV5ZWJyb3ciLCJ0YWJzIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGFnZUhlYWRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5cbmludGVyZmFjZSBQYWdlSGVhZGVyUHJvcHMge1xuICB0aXRsZTogc3RyaW5nO1xuICBkZXNjcmlwdGlvbj86IHN0cmluZztcbiAgYWN0aW9ucz86IFJlYWN0Tm9kZTtcbiAgc3RhdHVzPzogUmVhY3ROb2RlO1xuICBpY29uPzogUmVhY3ROb2RlO1xuICAvKiogVXBwZXJjYXNlIGdyZWVuIGtpY2tlciDigJQgVGVzc2wgLyByZWdpc3RyeSBwYXR0ZXJuICovXG4gIGV5ZWJyb3c/OiBzdHJpbmc7XG4gIC8qKiBPcHRpb25hbCBwaWxsIHRhYiBiYXIgYmVsb3cgaGVhZGVyICovXG4gIHRhYnM/OiBSZWFjdE5vZGU7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBQYWdlSGVhZGVyKHtcbiAgdGl0bGUsXG4gIGRlc2NyaXB0aW9uLFxuICBhY3Rpb25zLFxuICBzdGF0dXMsXG4gIGljb24sXG4gIGV5ZWJyb3csXG4gIHRhYnMsXG59OiBQYWdlSGVhZGVyUHJvcHMpOiBKU1guRWxlbWVudCB7XG4gIHJldHVybiAoXG4gICAgPGhlYWRlciBjbGFzc05hbWU9XCJyZWxhdGl2ZSBzaHJpbmstMCBib3JkZXItYiBib3JkZXItbGluZSBiZy1hcHBcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcHgtNiBweS01XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNCB4bDpmbGV4LXJvdyB4bDppdGVtcy1lbmQgeGw6anVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTBcIj5cbiAgICAgICAgICAgICAge2V5ZWJyb3cgPyA8ZGl2IGNsYXNzTmFtZT1cInJlZ2lzdHJ5LWtpY2tlclwiPntleWVicm93fTwvZGl2PiA6IG51bGx9XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4tdy0wIGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XG4gICAgICAgICAgICAgICAge2ljb24gPyAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTAuNSBmbGV4IGgtMTAgdy0xMCBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xIHRleHQtcmVnaXN0cnktYWNjZW50XCI+XG4gICAgICAgICAgICAgICAgICAgIHtpY29ufVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LVsyNnB4XSBmb250LXNlbWlib2xkIGxlYWRpbmctdGlnaHQgdHJhY2tpbmctdGlnaHQgdGV4dC1pbmtcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7dGl0bGV9XG4gICAgICAgICAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICAgICAgICAgIHtzdGF0dXN9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIHtkZXNjcmlwdGlvbiA/IChcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMS41IG1heC13LTN4bCB0ZXh0LVsxNHB4XSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1pbmstc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgICAgICAge2Rlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIHthY3Rpb25zID8gKFxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgIFwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yIHhsOm1heC13LVs0OCVdIHhsOmp1c3RpZnktZW5kXCIsXG4gICAgICAgICAgICAgICAgICAhZGVzY3JpcHRpb24gJiYgXCJ4bDpzZWxmLWNlbnRlclwiXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHthY3Rpb25zfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHt0YWJzfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvaGVhZGVyPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvY29tcG9uZW50cy9QYWdlSGVhZGVyLnRzeCJ9