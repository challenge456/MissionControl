import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/automations/AutomationOverview.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { AlertTriangle, ArrowRight, CheckCircle2, Clock3, PauseCircle, ReceiptText } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { Badge } from "/src/components/ui/badge.tsx";
import { Card } from "/src/components/ui/card.tsx";
import { formatDate, formatPercent, statusTone } from "/src/automations/automationModel.ts";
export function AutomationOverview({
  data,
  onTabChange
}) {
  const next = data.definitions.filter((definition) => definition.status === "ACTIVE" && definition.nextRunAt).sort((a, b) => a.nextRunAt - b.nextRunAt)[0];
  const priority = data.metrics.suspended > 0 ? `${data.metrics.suspended} suspended Automation${data.metrics.suspended === 1 ? "" : "s"} require review` : data.metrics.waitingApprovals > 0 ? `${data.metrics.waitingApprovals} review gate${data.metrics.waitingApprovals === 1 ? "" : "s"} await approval` : data.candidates.some((candidate) => candidate.eligible) ? "An evidenced Automation Candidate is ready for review" : "No urgent Automation action";
  const cards = [
    ["Active", data.metrics.active, CheckCircle2, "definitions"],
    ["Paused / suspended", data.metrics.paused + data.metrics.suspended, PauseCircle, "definitions"],
    ["Waiting approvals", data.metrics.waitingApprovals, Clock3, "runs"],
    ["Missing receipts", data.metrics.missingReceipts, ReceiptText, "receipts"],
    ["Verification pass", formatPercent(data.metrics.verificationPassRate), CheckCircle2, "receipts"],
    ["Cost", `$${data.metrics.costUsd.toFixed(2)}`, AlertTriangle, "runs"]
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-5", children: [
    /* @__PURE__ */ jsxDEV(Card, { className: "border-amber-500/20 bg-amber-500/[0.04] p-5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold uppercase tracking-[0.17em] text-amber-200", children: "Highest-priority operator action" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
        lineNumber: 53,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-2 flex flex-wrap items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-base font-medium text-foreground", children: priority }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
          lineNumber: 55,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => onTabChange(data.metrics.suspended ? "definitions" : "runs"), className: "flex items-center gap-1 text-sm font-medium text-amber-200 hover:text-amber-100", children: [
          "Inspect ",
          /* @__PURE__ */ jsxDEV(ArrowRight, { className: "h-4 w-4" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
            lineNumber: 57,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
          lineNumber: 56,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
        lineNumber: 54,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
      lineNumber: 52,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-3", children: cards.map(
      ([label, value, Icon, tab]) => /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => onTabChange(tab), className: "text-left", children: /* @__PURE__ */ jsxDEV(Card, { className: "h-full p-4 transition-colors hover:border-registry-accent/30", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-muted-foreground", children: label }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
            lineNumber: 66,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Icon, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
            lineNumber: 67,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
          lineNumber: 65,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-3 text-2xl font-semibold text-foreground", children: value }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
          lineNumber: 69,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
        lineNumber: 64,
        columnNumber: 13
      }, this) }, label, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
        lineNumber: 63,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
      lineNumber: 61,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 lg:grid-cols-2", children: [
      /* @__PURE__ */ jsxDEV(Card, { className: "p-5", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-sm font-semibold text-foreground", children: "Upcoming execution" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
          lineNumber: 76,
          columnNumber: 11
        }, this),
        next ? /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-foreground", children: next.name }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
              lineNumber: 80,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", className: statusTone(next.status), children: next.status }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
              lineNumber: 81,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
            lineNumber: 79,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-muted-foreground", children: [
            formatDate(next.nextRunAt),
            " · ",
            next.workflowId,
            "@",
            next.workflowVersion
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
            lineNumber: 83,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
          lineNumber: 78,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-sm text-muted-foreground", children: "No active Automation is scheduled." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
          lineNumber: 85,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
        lineNumber: 75,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { className: "p-5", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-sm font-semibold text-foreground", children: "Control boundary" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
          lineNumber: 88,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-sm leading-relaxed text-muted-foreground", children: "V1 scheduled Automations are restricted to read-only WorkOrders. Every review gate requires normal operator approval and dispatch." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
          lineNumber: 89,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
        lineNumber: 87,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
      lineNumber: 74,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx",
    lineNumber: 51,
    columnNumber: 5
  }, this);
}
_c = AutomationOverview;
var _c;
$RefreshReg$(_c, "AutomationOverview");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationOverview.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUNROzs7Ozs7Ozs7Ozs7Ozs7O0FBakNSLFNBQVNBLGVBQWVDLFlBQVlDLGNBQWNDLFFBQVFDLGFBQWFDLG1CQUFtQjtBQUMxRixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsWUFBWUMsZUFBZUMsa0JBQXNDO0FBRW5FLGdCQUFTQyxtQkFBbUI7QUFBQSxFQUNqQ0M7QUFBQUEsRUFDQUM7QUFJRixHQUFHO0FBQ0QsUUFBTUMsT0FBT0YsS0FBS0csWUFDZkMsT0FBTyxDQUFDQyxlQUFvQkEsV0FBV0MsV0FBVyxZQUFZRCxXQUFXRSxTQUFTLEVBQ2xGQyxLQUFLLENBQUNDLEdBQVFDLE1BQVdELEVBQUVGLFlBQVlHLEVBQUVILFNBQVMsRUFBRSxDQUFDO0FBQ3hELFFBQU1JLFdBQVdYLEtBQUtZLFFBQVFDLFlBQVksSUFDdEMsR0FBR2IsS0FBS1ksUUFBUUMsU0FBUyx3QkFBd0JiLEtBQUtZLFFBQVFDLGNBQWMsSUFBSSxLQUFLLEdBQUcsb0JBQ3hGYixLQUFLWSxRQUFRRSxtQkFBbUIsSUFDOUIsR0FBR2QsS0FBS1ksUUFBUUUsZ0JBQWdCLGVBQWVkLEtBQUtZLFFBQVFFLHFCQUFxQixJQUFJLEtBQUssR0FBRyxvQkFDN0ZkLEtBQUtlLFdBQVdDLEtBQUssQ0FBQ0MsY0FBbUJBLFVBQVVDLFFBQVEsSUFDekQsMERBQ0E7QUFDUixRQUFNQyxRQUFRO0FBQUEsSUFDWixDQUFDLFVBQVVuQixLQUFLWSxRQUFRUSxRQUFROUIsY0FBYyxhQUFhO0FBQUEsSUFDM0QsQ0FBQyxzQkFBc0JVLEtBQUtZLFFBQVFTLFNBQVNyQixLQUFLWSxRQUFRQyxXQUFXckIsYUFBYSxhQUFhO0FBQUEsSUFDL0YsQ0FBQyxxQkFBcUJRLEtBQUtZLFFBQVFFLGtCQUFrQnZCLFFBQVEsTUFBTTtBQUFBLElBQ25FLENBQUMsb0JBQW9CUyxLQUFLWSxRQUFRVSxpQkFBaUI3QixhQUFhLFVBQVU7QUFBQSxJQUMxRSxDQUFDLHFCQUFxQkksY0FBY0csS0FBS1ksUUFBUVcsb0JBQW9CLEdBQUdqQyxjQUFjLFVBQVU7QUFBQSxJQUNoRyxDQUFDLFFBQVEsSUFBSVUsS0FBS1ksUUFBUVksUUFBUUMsUUFBUSxDQUFDLENBQUMsSUFBSXJDLGVBQWUsTUFBTTtBQUFBLEVBQUM7QUFFeEUsU0FDRSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDJCQUFDLFFBQUssV0FBVSwrQ0FDZDtBQUFBLDZCQUFDLFNBQUksV0FBVSx3RUFBdUUsZ0RBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0g7QUFBQSxNQUN0SCx1QkFBQyxTQUFJLFdBQVUsMERBQ2I7QUFBQSwrQkFBQyxPQUFFLFdBQVUseUNBQXlDdUIsc0JBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0Q7QUFBQSxRQUMvRCx1QkFBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU1WLFlBQVlELEtBQUtZLFFBQVFDLFlBQVksZ0JBQWdCLE1BQU0sR0FBRyxXQUFVLG1GQUFpRjtBQUFBO0FBQUEsVUFDcEwsdUJBQUMsY0FBVyxXQUFVLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStCO0FBQUEsYUFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLDRDQUNaTSxnQkFBTU87QUFBQUEsTUFBSSxDQUFDLENBQUNDLE9BQU9DLE9BQU9DLE1BQU1DLEdBQUcsTUFDbEMsdUJBQUMsWUFBbUIsTUFBSyxVQUFTLFNBQVMsTUFBTTdCLFlBQVk2QixHQUFHLEdBQUcsV0FBVSxhQUMzRSxpQ0FBQyxRQUFLLFdBQVUsZ0VBQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsaUNBQWlDSCxtQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUQ7QUFBQSxVQUN2RCx1QkFBQyxRQUFLLFdBQVUsbUNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDO0FBQUEsYUFGakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsK0NBQStDQyxtQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRTtBQUFBLFdBTHRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQSxLQVBXRCxPQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLElBQ0QsS0FYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLDZCQUFDLFFBQUssV0FBVSxPQUNkO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHlDQUF3QyxrQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RTtBQUFBLFFBQ3ZFekIsT0FDQyx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSwrQkFBK0JBLGVBQUs2QixRQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RDtBQUFBLFlBQ3pELHVCQUFDLFNBQU0sU0FBUSxXQUFVLFdBQVdqQyxXQUFXSSxLQUFLSSxNQUFNLEdBQUlKLGVBQUtJLFVBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBFO0FBQUEsZUFGNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLHNDQUFzQ1Y7QUFBQUEsdUJBQVdNLEtBQUtLLFNBQVM7QUFBQSxZQUFFO0FBQUEsWUFBSUwsS0FBSzhCO0FBQUFBLFlBQVc7QUFBQSxZQUFFOUIsS0FBSytCO0FBQUFBLGVBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlIO0FBQUEsYUFMM0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BLElBQ0UsdUJBQUMsT0FBRSxXQUFVLHNDQUFxQyxrREFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRjtBQUFBLFdBVjFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxXQUFVLE9BQ2Q7QUFBQSwrQkFBQyxRQUFHLFdBQVUseUNBQXdDLGdDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNFO0FBQUEsUUFDdEUsdUJBQUMsT0FBRSxXQUFVLHNEQUFvRCxrSkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBO0FBQUEsT0ExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJDQTtBQUVKO0FBQUNDLEtBdkVlbkM7QUFBa0IsSUFBQW1DO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkFsZXJ0VHJpYW5nbGUiLCJBcnJvd1JpZ2h0IiwiQ2hlY2tDaXJjbGUyIiwiQ2xvY2szIiwiUGF1c2VDaXJjbGUiLCJSZWNlaXB0VGV4dCIsIkJhZGdlIiwiQ2FyZCIsImZvcm1hdERhdGUiLCJmb3JtYXRQZXJjZW50Iiwic3RhdHVzVG9uZSIsIkF1dG9tYXRpb25PdmVydmlldyIsImRhdGEiLCJvblRhYkNoYW5nZSIsIm5leHQiLCJkZWZpbml0aW9ucyIsImZpbHRlciIsImRlZmluaXRpb24iLCJzdGF0dXMiLCJuZXh0UnVuQXQiLCJzb3J0IiwiYSIsImIiLCJwcmlvcml0eSIsIm1ldHJpY3MiLCJzdXNwZW5kZWQiLCJ3YWl0aW5nQXBwcm92YWxzIiwiY2FuZGlkYXRlcyIsInNvbWUiLCJjYW5kaWRhdGUiLCJlbGlnaWJsZSIsImNhcmRzIiwiYWN0aXZlIiwicGF1c2VkIiwibWlzc2luZ1JlY2VpcHRzIiwidmVyaWZpY2F0aW9uUGFzc1JhdGUiLCJjb3N0VXNkIiwidG9GaXhlZCIsIm1hcCIsImxhYmVsIiwidmFsdWUiLCJJY29uIiwidGFiIiwibmFtZSIsIndvcmtmbG93SWQiLCJ3b3JrZmxvd1ZlcnNpb24iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBdXRvbWF0aW9uT3ZlcnZpZXcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFsZXJ0VHJpYW5nbGUsIEFycm93UmlnaHQsIENoZWNrQ2lyY2xlMiwgQ2xvY2szLCBQYXVzZUNpcmNsZSwgUmVjZWlwdFRleHQgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBCYWRnZSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYmFkZ2VcIjtcbmltcG9ydCB7IENhcmQgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2NhcmRcIjtcbmltcG9ydCB7IGZvcm1hdERhdGUsIGZvcm1hdFBlcmNlbnQsIHN0YXR1c1RvbmUsIHR5cGUgQXV0b21hdGlvblRhYiB9IGZyb20gXCIuL2F1dG9tYXRpb25Nb2RlbFwiO1xuXG5leHBvcnQgZnVuY3Rpb24gQXV0b21hdGlvbk92ZXJ2aWV3KHtcbiAgZGF0YSxcbiAgb25UYWJDaGFuZ2UsXG59OiB7XG4gIGRhdGE6IGFueTtcbiAgb25UYWJDaGFuZ2U6ICh0YWI6IEF1dG9tYXRpb25UYWIpID0+IHZvaWQ7XG59KSB7XG4gIGNvbnN0IG5leHQgPSBkYXRhLmRlZmluaXRpb25zXG4gICAgLmZpbHRlcigoZGVmaW5pdGlvbjogYW55KSA9PiBkZWZpbml0aW9uLnN0YXR1cyA9PT0gXCJBQ1RJVkVcIiAmJiBkZWZpbml0aW9uLm5leHRSdW5BdClcbiAgICAuc29ydCgoYTogYW55LCBiOiBhbnkpID0+IGEubmV4dFJ1bkF0IC0gYi5uZXh0UnVuQXQpWzBdO1xuICBjb25zdCBwcmlvcml0eSA9IGRhdGEubWV0cmljcy5zdXNwZW5kZWQgPiAwXG4gICAgPyBgJHtkYXRhLm1ldHJpY3Muc3VzcGVuZGVkfSBzdXNwZW5kZWQgQXV0b21hdGlvbiR7ZGF0YS5tZXRyaWNzLnN1c3BlbmRlZCA9PT0gMSA/IFwiXCIgOiBcInNcIn0gcmVxdWlyZSByZXZpZXdgXG4gICAgOiBkYXRhLm1ldHJpY3Mud2FpdGluZ0FwcHJvdmFscyA+IDBcbiAgICAgID8gYCR7ZGF0YS5tZXRyaWNzLndhaXRpbmdBcHByb3ZhbHN9IHJldmlldyBnYXRlJHtkYXRhLm1ldHJpY3Mud2FpdGluZ0FwcHJvdmFscyA9PT0gMSA/IFwiXCIgOiBcInNcIn0gYXdhaXQgYXBwcm92YWxgXG4gICAgICA6IGRhdGEuY2FuZGlkYXRlcy5zb21lKChjYW5kaWRhdGU6IGFueSkgPT4gY2FuZGlkYXRlLmVsaWdpYmxlKVxuICAgICAgICA/IFwiQW4gZXZpZGVuY2VkIEF1dG9tYXRpb24gQ2FuZGlkYXRlIGlzIHJlYWR5IGZvciByZXZpZXdcIlxuICAgICAgICA6IFwiTm8gdXJnZW50IEF1dG9tYXRpb24gYWN0aW9uXCI7XG4gIGNvbnN0IGNhcmRzID0gW1xuICAgIFtcIkFjdGl2ZVwiLCBkYXRhLm1ldHJpY3MuYWN0aXZlLCBDaGVja0NpcmNsZTIsIFwiZGVmaW5pdGlvbnNcIl0sXG4gICAgW1wiUGF1c2VkIC8gc3VzcGVuZGVkXCIsIGRhdGEubWV0cmljcy5wYXVzZWQgKyBkYXRhLm1ldHJpY3Muc3VzcGVuZGVkLCBQYXVzZUNpcmNsZSwgXCJkZWZpbml0aW9uc1wiXSxcbiAgICBbXCJXYWl0aW5nIGFwcHJvdmFsc1wiLCBkYXRhLm1ldHJpY3Mud2FpdGluZ0FwcHJvdmFscywgQ2xvY2szLCBcInJ1bnNcIl0sXG4gICAgW1wiTWlzc2luZyByZWNlaXB0c1wiLCBkYXRhLm1ldHJpY3MubWlzc2luZ1JlY2VpcHRzLCBSZWNlaXB0VGV4dCwgXCJyZWNlaXB0c1wiXSxcbiAgICBbXCJWZXJpZmljYXRpb24gcGFzc1wiLCBmb3JtYXRQZXJjZW50KGRhdGEubWV0cmljcy52ZXJpZmljYXRpb25QYXNzUmF0ZSksIENoZWNrQ2lyY2xlMiwgXCJyZWNlaXB0c1wiXSxcbiAgICBbXCJDb3N0XCIsIGAkJHtkYXRhLm1ldHJpY3MuY29zdFVzZC50b0ZpeGVkKDIpfWAsIEFsZXJ0VHJpYW5nbGUsIFwicnVuc1wiXSxcbiAgXSBhcyBjb25zdDtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNVwiPlxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwiYm9yZGVyLWFtYmVyLTUwMC8yMCBiZy1hbWJlci01MDAvWzAuMDRdIHAtNVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLVswLjE3ZW1dIHRleHQtYW1iZXItMjAwXCI+SGlnaGVzdC1wcmlvcml0eSBvcGVyYXRvciBhY3Rpb248L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1tZWRpdW0gdGV4dC1mb3JlZ3JvdW5kXCI+e3ByaW9yaXR5fTwvcD5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBvblRhYkNoYW5nZShkYXRhLm1ldHJpY3Muc3VzcGVuZGVkID8gXCJkZWZpbml0aW9uc1wiIDogXCJydW5zXCIpfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtYW1iZXItMjAwIGhvdmVyOnRleHQtYW1iZXItMTAwXCI+XG4gICAgICAgICAgICBJbnNwZWN0IDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvQ2FyZD5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtMyBzbTpncmlkLWNvbHMtMiB4bDpncmlkLWNvbHMtM1wiPlxuICAgICAgICB7Y2FyZHMubWFwKChbbGFiZWwsIHZhbHVlLCBJY29uLCB0YWJdKSA9PiAoXG4gICAgICAgICAgPGJ1dHRvbiBrZXk9e2xhYmVsfSB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gb25UYWJDaGFuZ2UodGFiKX0gY2xhc3NOYW1lPVwidGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJoLWZ1bGwgcC00IHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOmJvcmRlci1yZWdpc3RyeS1hY2NlbnQvMzBcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntsYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHRleHQtMnhsIGZvbnQtc2VtaWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+e3ZhbHVlfTwvZGl2PlxuICAgICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC00IGxnOmdyaWQtY29scy0yXCI+XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtNVwiPlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+VXBjb21pbmcgZXhlY3V0aW9uPC9oMj5cbiAgICAgICAgICB7bmV4dCA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1mb3JlZ3JvdW5kXCI+e25leHQubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCIgY2xhc3NOYW1lPXtzdGF0dXNUb25lKG5leHQuc3RhdHVzKX0+e25leHQuc3RhdHVzfTwvQmFkZ2U+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e2Zvcm1hdERhdGUobmV4dC5uZXh0UnVuQXQpfSDCtyB7bmV4dC53b3JrZmxvd0lkfUB7bmV4dC53b3JrZmxvd1ZlcnNpb259PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IDxwIGNsYXNzTmFtZT1cIm10LTQgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5ObyBhY3RpdmUgQXV0b21hdGlvbiBpcyBzY2hlZHVsZWQuPC9wPn1cbiAgICAgICAgPC9DYXJkPlxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTVcIj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZm9yZWdyb3VuZFwiPkNvbnRyb2wgYm91bmRhcnk8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICBWMSBzY2hlZHVsZWQgQXV0b21hdGlvbnMgYXJlIHJlc3RyaWN0ZWQgdG8gcmVhZC1vbmx5IFdvcmtPcmRlcnMuIEV2ZXJ5IHJldmlldyBnYXRlIHJlcXVpcmVzIG5vcm1hbCBvcGVyYXRvciBhcHByb3ZhbCBhbmQgZGlzcGF0Y2guXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L0NhcmQ+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL2F1dG9tYXRpb25zL0F1dG9tYXRpb25PdmVydmlldy50c3gifQ==