import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/MissionModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useMutation, useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { Save, Target } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { Button } from "/src/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from "/src/components/ui/dialog.tsx";
export function MissionModal({ projectId, onClose }) {
  _s();
  const missionData = useQuery(api.mission.getMission, projectId ? { projectId } : {});
  const setMission = useMutation(api.mission.setMission);
  const [missionText, setMissionText] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState(null);
  useEffect(() => {
    if (missionData?.missionStatement) {
      setMissionText(missionData.missionStatement);
    }
  }, [missionData]);
  const handleSave = async () => {
    if (!missionText.trim()) {
      setError("Mission statement cannot be empty");
      return;
    }
    setIsSaving(true);
    setError(null);
    try {
      await setMission({
        missionStatement: missionText.trim(),
        projectId: projectId ?? void 0
      });
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save mission statement");
    } finally {
      setIsSaving(false);
    }
  };
  const handleKeyDown = (e) => {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
      handleSave();
    }
  };
  return /* @__PURE__ */ jsxDEV(Dialog, { open: true, onOpenChange: (open) => {
    if (!open) onClose();
  }, children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "max-w-2xl", onKeyDown: handleKeyDown, children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg bg-muted p-2 border border-border", children: /* @__PURE__ */ jsxDEV(Target, { className: "h-5 w-5 text-primary", strokeWidth: 1.5 }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
        lineNumber: 88,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
        lineNumber: 87,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Mission Statement" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
          lineNumber: 91,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Define the north star that guides your autonomous agents" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
          lineNumber: 92,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
        lineNumber: 90,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
      lineNumber: 86,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
      lineNumber: 85,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "mission-textarea", className: "block text-sm font-medium text-foreground mb-2", children: "Your Mission" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
          lineNumber: 101,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "textarea",
          {
            id: "mission-textarea",
            value: missionText,
            onChange: (e) => setMissionText(e.target.value),
            placeholder: "e.g., Build an autonomous organization of AI agents that does work for me and produces value continuously",
            className: "w-full h-32 px-4 py-3 bg-background border border-border rounded-md text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none",
            autoFocus: true
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
            lineNumber: 104,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted-foreground mt-2", children: "This mission statement will be included in every agent's context and used for reverse prompting." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
          lineNumber: 112,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
        lineNumber: 100,
        columnNumber: 11
      }, this),
      error && /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-destructive/10 border border-destructive/20 rounded-md", children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-destructive", children: error }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
        lineNumber: 119,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
        lineNumber: 118,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-muted/50 border border-border rounded-md p-4", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-medium text-foreground mb-2", children: "Tips for a Great Mission" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
          lineNumber: 124,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("ul", { className: "text-xs text-muted-foreground space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV("li", { children: "Be specific about the outcomes you want to achieve" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
            lineNumber: 126,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Focus on value creation, not just task completion" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
            lineNumber: 127,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Make it measurable where possible — name a real target" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
            lineNumber: 128,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Keep it concise but inspiring (1-2 sentences ideal)" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
            lineNumber: 129,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
          lineNumber: 125,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
        lineNumber: 123,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
      lineNumber: 99,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DialogFooter, { className: "flex items-center justify-between sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted-foreground", children: [
        /* @__PURE__ */ jsxDEV("kbd", { className: "px-1.5 py-0.5 bg-muted border border-border rounded text-xs", children: "Esc" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
          lineNumber: 136,
          columnNumber: 13
        }, this),
        " to cancel",
        " · ",
        /* @__PURE__ */ jsxDEV("kbd", { className: "px-1.5 py-0.5 bg-muted border border-border rounded text-xs", children: "⌘ Enter" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
          lineNumber: 138,
          columnNumber: 13
        }, this),
        " to save"
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
        lineNumber: 135,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", onClick: onClose, disabled: isSaving, children: "Cancel" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
          lineNumber: 141,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: handleSave,
            disabled: isSaving || !missionText.trim(),
            className: "gap-1.5",
            children: [
              /* @__PURE__ */ jsxDEV(Save, { className: "h-4 w-4", strokeWidth: 1.5 }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
                lineNumber: 149,
                columnNumber: 15
              }, this),
              isSaving ? "Saving..." : "Save Mission"
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
            lineNumber: 144,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
        lineNumber: 140,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
      lineNumber: 134,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
    lineNumber: 84,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx",
    lineNumber: 83,
    columnNumber: 5
  }, this);
}
_s(MissionModal, "81lqdB1U7v3ugx0ElozXKBuYq3Q=", false, function() {
  return [useQuery, useMutation];
});
_c = MissionModal;
var _c;
$RefreshReg$(_c, "MissionModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/MissionModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0VjOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBFZCxTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLFdBQVc7QUFFcEIsU0FBU0MsTUFBTUMsY0FBYztBQUM3QixTQUFTQyxjQUFjO0FBQ3ZCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQU9BLGdCQUFTQyxhQUFhLEVBQUVDLFdBQVdDLFFBQTJCLEdBQUc7QUFBQUMsS0FBQTtBQUN0RSxRQUFNQyxjQUFjZixTQUFTQyxJQUFJZSxRQUFRQyxZQUFZTCxZQUFZLEVBQUVBLFVBQVUsSUFBSSxDQUFDLENBQUM7QUFDbkYsUUFBTU0sYUFBYW5CLFlBQVlFLElBQUllLFFBQVFFLFVBQVU7QUFFckQsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUl2QixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDd0IsVUFBVUMsV0FBVyxJQUFJekIsU0FBUyxLQUFLO0FBQzlDLFFBQU0sQ0FBQzBCLE9BQU9DLFFBQVEsSUFBSTNCLFNBQXdCLElBQUk7QUFFdERDLFlBQVUsTUFBTTtBQUNkLFFBQUlpQixhQUFhVSxrQkFBa0I7QUFDakNMLHFCQUFlTCxZQUFZVSxnQkFBZ0I7QUFBQSxJQUM3QztBQUFBLEVBQ0YsR0FBRyxDQUFDVixXQUFXLENBQUM7QUFFaEIsUUFBTVcsYUFBYSxZQUFZO0FBQzdCLFFBQUksQ0FBQ1AsWUFBWVEsS0FBSyxHQUFHO0FBQ3ZCSCxlQUFTLG1DQUFtQztBQUM1QztBQUFBLElBQ0Y7QUFFQUYsZ0JBQVksSUFBSTtBQUNoQkUsYUFBUyxJQUFJO0FBRWIsUUFBSTtBQUNGLFlBQU1OLFdBQVc7QUFBQSxRQUNmTyxrQkFBa0JOLFlBQVlRLEtBQUs7QUFBQSxRQUNuQ2YsV0FBV0EsYUFBYWdCO0FBQUFBLE1BQzFCLENBQUM7QUFDRGYsY0FBUTtBQUFBLElBQ1YsU0FBU2dCLEtBQUs7QUFDWkwsZUFBU0ssZUFBZUMsUUFBUUQsSUFBSUUsVUFBVSxrQ0FBa0M7QUFBQSxJQUNsRixVQUFDO0FBQ0NULGtCQUFZLEtBQUs7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNVSxnQkFBZ0JBLENBQUNDLE1BQTJCO0FBQ2hELFFBQUlBLEVBQUVDLFFBQVEsWUFBWUQsRUFBRUUsV0FBV0YsRUFBRUcsVUFBVTtBQUNqRFYsaUJBQVc7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsVUFBTyxNQUFJLE1BQUMsY0FBYyxDQUFDVyxTQUFTO0FBQUUsUUFBSSxDQUFDQSxLQUFNeEIsU0FBUTtBQUFBLEVBQUcsR0FDM0QsaUNBQUMsaUJBQWMsV0FBVSxhQUFZLFdBQVdtQixlQUM5QztBQUFBLDJCQUFDLGdCQUNDLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxnREFDYixpQ0FBQyxVQUFPLFdBQVUsd0JBQXVCLGFBQWEsT0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRCxLQUQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxlQUFZLGlDQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEI7QUFBQSxRQUM5Qix1QkFBQyxxQkFBaUIsd0VBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFdBQU0sU0FBUSxvQkFBbUIsV0FBVSxrREFBZ0QsNEJBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUc7QUFBQSxZQUNILE9BQU9iO0FBQUFBLFlBQ1AsVUFBVSxDQUFDYyxNQUFNYixlQUFlYSxFQUFFSyxPQUFPQyxLQUFLO0FBQUEsWUFDOUMsYUFBWTtBQUFBLFlBQ1osV0FBVTtBQUFBLFlBQ1YsV0FBUztBQUFBO0FBQUEsVUFOWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNVztBQUFBLFFBRVgsdUJBQUMsT0FBRSxXQUFVLHNDQUFvQyxnSEFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxNQUVDaEIsU0FDQyx1QkFBQyxTQUFJLFdBQVUsaUVBQ2IsaUNBQUMsT0FBRSxXQUFVLDRCQUE0QkEsbUJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0MsS0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFHRix1QkFBQyxTQUFJLFdBQVUsbURBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsNENBQTJDLHdDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlGO0FBQUEsUUFDakYsdUJBQUMsUUFBRyxXQUFVLDZDQUNaO0FBQUEsaUNBQUMsUUFBRyxrRUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRDtBQUFBLFVBQ3RELHVCQUFDLFFBQUcsaUVBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUQ7QUFBQSxVQUNyRCx1QkFBQyxRQUFHLHNFQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBEO0FBQUEsVUFDMUQsdUJBQUMsUUFBRyxtRUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RDtBQUFBLGFBSnpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsU0FoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlDQTtBQUFBLElBRUEsdUJBQUMsZ0JBQWEsV0FBVSx3REFDdEI7QUFBQSw2QkFBQyxPQUFFLFdBQVUsaUNBQ1g7QUFBQSwrQkFBQyxTQUFJLFdBQVUsK0RBQThELG1CQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdGO0FBQUEsUUFBTTtBQUFBLFFBQ3JGO0FBQUEsUUFDRCx1QkFBQyxTQUFJLFdBQVUsK0RBQThELHVCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9GO0FBQUEsUUFBTTtBQUFBLFdBSDVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwrQkFBQyxVQUFPLFNBQVEsU0FBUSxTQUFTVixTQUFTLFVBQVVRLFVBQVMsc0JBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVNLO0FBQUFBLFlBQ1QsVUFBVUwsWUFBWSxDQUFDRixZQUFZUSxLQUFLO0FBQUEsWUFDeEMsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxRQUFLLFdBQVUsV0FBVSxhQUFhLE9BQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJDO0FBQUEsY0FDMUNOLFdBQVcsY0FBYztBQUFBO0FBQUE7QUFBQSxVQU41QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFdBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsU0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLE9BckVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzRUEsS0F2RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdFQTtBQUVKO0FBQUNQLEdBckhlSCxjQUFZO0FBQUEsVUFDTlgsVUFDREQsV0FBVztBQUFBO0FBQUEsS0FGaEJZO0FBQVksSUFBQTZCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsImFwaSIsIlNhdmUiLCJUYXJnZXQiLCJCdXR0b24iLCJEaWFsb2ciLCJEaWFsb2dDb250ZW50IiwiRGlhbG9nSGVhZGVyIiwiRGlhbG9nVGl0bGUiLCJEaWFsb2dEZXNjcmlwdGlvbiIsIkRpYWxvZ0Zvb3RlciIsIk1pc3Npb25Nb2RhbCIsInByb2plY3RJZCIsIm9uQ2xvc2UiLCJfcyIsIm1pc3Npb25EYXRhIiwibWlzc2lvbiIsImdldE1pc3Npb24iLCJzZXRNaXNzaW9uIiwibWlzc2lvblRleHQiLCJzZXRNaXNzaW9uVGV4dCIsImlzU2F2aW5nIiwic2V0SXNTYXZpbmciLCJlcnJvciIsInNldEVycm9yIiwibWlzc2lvblN0YXRlbWVudCIsImhhbmRsZVNhdmUiLCJ0cmltIiwidW5kZWZpbmVkIiwiZXJyIiwiRXJyb3IiLCJtZXNzYWdlIiwiaGFuZGxlS2V5RG93biIsImUiLCJrZXkiLCJtZXRhS2V5IiwiY3RybEtleSIsIm9wZW4iLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1pc3Npb25Nb2RhbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5IH0gZnJvbSBcImNvbnZleC9yZWFjdFwiO1xuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2FwaVwiO1xuaW1wb3J0IHR5cGUgeyBJZCB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9kYXRhTW9kZWxcIjtcbmltcG9ydCB7IFNhdmUsIFRhcmdldCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQge1xuICBEaWFsb2csXG4gIERpYWxvZ0NvbnRlbnQsXG4gIERpYWxvZ0hlYWRlcixcbiAgRGlhbG9nVGl0bGUsXG4gIERpYWxvZ0Rlc2NyaXB0aW9uLFxuICBEaWFsb2dGb290ZXIsXG59IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvZGlhbG9nXCI7XG5cbmludGVyZmFjZSBNaXNzaW9uTW9kYWxQcm9wcyB7XG4gIHByb2plY3RJZDogSWQ8XCJwcm9qZWN0c1wiPiB8IG51bGw7XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBNaXNzaW9uTW9kYWwoeyBwcm9qZWN0SWQsIG9uQ2xvc2UgfTogTWlzc2lvbk1vZGFsUHJvcHMpIHtcbiAgY29uc3QgbWlzc2lvbkRhdGEgPSB1c2VRdWVyeShhcGkubWlzc2lvbi5nZXRNaXNzaW9uLCBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCB9IDoge30pO1xuICBjb25zdCBzZXRNaXNzaW9uID0gdXNlTXV0YXRpb24oYXBpLm1pc3Npb24uc2V0TWlzc2lvbik7XG5cbiAgY29uc3QgW21pc3Npb25UZXh0LCBzZXRNaXNzaW9uVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2lzU2F2aW5nLCBzZXRJc1NhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAobWlzc2lvbkRhdGE/Lm1pc3Npb25TdGF0ZW1lbnQpIHtcbiAgICAgIHNldE1pc3Npb25UZXh0KG1pc3Npb25EYXRhLm1pc3Npb25TdGF0ZW1lbnQpO1xuICAgIH1cbiAgfSwgW21pc3Npb25EYXRhXSk7XG5cbiAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIW1pc3Npb25UZXh0LnRyaW0oKSkge1xuICAgICAgc2V0RXJyb3IoXCJNaXNzaW9uIHN0YXRlbWVudCBjYW5ub3QgYmUgZW1wdHlcIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgc2V0SXNTYXZpbmcodHJ1ZSk7XG4gICAgc2V0RXJyb3IobnVsbCk7XG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgc2V0TWlzc2lvbih7XG4gICAgICAgIG1pc3Npb25TdGF0ZW1lbnQ6IG1pc3Npb25UZXh0LnRyaW0oKSxcbiAgICAgICAgcHJvamVjdElkOiBwcm9qZWN0SWQgPz8gdW5kZWZpbmVkLFxuICAgICAgfSk7XG4gICAgICBvbkNsb3NlKCk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogXCJGYWlsZWQgdG8gc2F2ZSBtaXNzaW9uIHN0YXRlbWVudFwiKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNTYXZpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVLZXlEb3duID0gKGU6IFJlYWN0LktleWJvYXJkRXZlbnQpID0+IHtcbiAgICBpZiAoZS5rZXkgPT09IFwiRW50ZXJcIiAmJiAoZS5tZXRhS2V5IHx8IGUuY3RybEtleSkpIHtcbiAgICAgIGhhbmRsZVNhdmUoKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8RGlhbG9nIG9wZW4gb25PcGVuQ2hhbmdlPXsob3BlbikgPT4geyBpZiAoIW9wZW4pIG9uQ2xvc2UoKTsgfX0+XG4gICAgICA8RGlhbG9nQ29udGVudCBjbGFzc05hbWU9XCJtYXgtdy0yeGxcIiBvbktleURvd249e2hhbmRsZUtleURvd259PlxuICAgICAgICA8RGlhbG9nSGVhZGVyPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBiZy1tdXRlZCBwLTIgYm9yZGVyIGJvcmRlci1ib3JkZXJcIj5cbiAgICAgICAgICAgICAgPFRhcmdldCBjbGFzc05hbWU9XCJoLTUgdy01IHRleHQtcHJpbWFyeVwiIHN0cm9rZVdpZHRoPXsxLjV9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxEaWFsb2dUaXRsZT5NaXNzaW9uIFN0YXRlbWVudDwvRGlhbG9nVGl0bGU+XG4gICAgICAgICAgICAgIDxEaWFsb2dEZXNjcmlwdGlvbj5cbiAgICAgICAgICAgICAgICBEZWZpbmUgdGhlIG5vcnRoIHN0YXIgdGhhdCBndWlkZXMgeW91ciBhdXRvbm9tb3VzIGFnZW50c1xuICAgICAgICAgICAgICA8L0RpYWxvZ0Rlc2NyaXB0aW9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvRGlhbG9nSGVhZGVyPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwibWlzc2lvbi10ZXh0YXJlYVwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mb3JlZ3JvdW5kIG1iLTJcIj5cbiAgICAgICAgICAgICAgWW91ciBNaXNzaW9uXG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgIGlkPVwibWlzc2lvbi10ZXh0YXJlYVwiXG4gICAgICAgICAgICAgIHZhbHVlPXttaXNzaW9uVGV4dH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNaXNzaW9uVGV4dChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiwgQnVpbGQgYW4gYXV0b25vbW91cyBvcmdhbml6YXRpb24gb2YgQUkgYWdlbnRzIHRoYXQgZG9lcyB3b3JrIGZvciBtZSBhbmQgcHJvZHVjZXMgdmFsdWUgY29udGludW91c2x5XCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMzIgcHgtNCBweS0zIGJnLWJhY2tncm91bmQgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1tZCB0ZXh0LXNtIHRleHQtZm9yZWdyb3VuZCBwbGFjZWhvbGRlcjp0ZXh0LW11dGVkLWZvcmVncm91bmQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXJpbmcgcmVzaXplLW5vbmVcIlxuICAgICAgICAgICAgICBhdXRvRm9jdXNcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtdC0yXCI+XG4gICAgICAgICAgICAgIFRoaXMgbWlzc2lvbiBzdGF0ZW1lbnQgd2lsbCBiZSBpbmNsdWRlZCBpbiBldmVyeSBhZ2VudCdzIGNvbnRleHQgYW5kIHVzZWQgZm9yIHJldmVyc2UgcHJvbXB0aW5nLlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLWRlc3RydWN0aXZlLzEwIGJvcmRlciBib3JkZXItZGVzdHJ1Y3RpdmUvMjAgcm91bmRlZC1tZFwiPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZGVzdHJ1Y3RpdmVcIj57ZXJyb3J9PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctbXV0ZWQvNTAgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1tZCBwLTRcIj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZm9yZWdyb3VuZCBtYi0yXCI+VGlwcyBmb3IgYSBHcmVhdCBNaXNzaW9uPC9oMz5cbiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICA8bGk+QmUgc3BlY2lmaWMgYWJvdXQgdGhlIG91dGNvbWVzIHlvdSB3YW50IHRvIGFjaGlldmU8L2xpPlxuICAgICAgICAgICAgICA8bGk+Rm9jdXMgb24gdmFsdWUgY3JlYXRpb24sIG5vdCBqdXN0IHRhc2sgY29tcGxldGlvbjwvbGk+XG4gICAgICAgICAgICAgIDxsaT5NYWtlIGl0IG1lYXN1cmFibGUgd2hlcmUgcG9zc2libGUg4oCUIG5hbWUgYSByZWFsIHRhcmdldDwvbGk+XG4gICAgICAgICAgICAgIDxsaT5LZWVwIGl0IGNvbmNpc2UgYnV0IGluc3BpcmluZyAoMS0yIHNlbnRlbmNlcyBpZGVhbCk8L2xpPlxuICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPERpYWxvZ0Zvb3RlciBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gc206anVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgIDxrYmQgY2xhc3NOYW1lPVwicHgtMS41IHB5LTAuNSBiZy1tdXRlZCBib3JkZXIgYm9yZGVyLWJvcmRlciByb3VuZGVkIHRleHQteHNcIj5Fc2M8L2tiZD4gdG8gY2FuY2VsXG4gICAgICAgICAgICB7XCIgwrcgXCJ9XG4gICAgICAgICAgICA8a2JkIGNsYXNzTmFtZT1cInB4LTEuNSBweS0wLjUgYmctbXV0ZWQgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZCB0ZXh0LXhzXCI+4oyYIEVudGVyPC9rYmQ+IHRvIHNhdmVcbiAgICAgICAgICA8L3A+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9e29uQ2xvc2V9IGRpc2FibGVkPXtpc1NhdmluZ30+XG4gICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNhdmV9XG4gICAgICAgICAgICAgIGRpc2FibGVkPXtpc1NhdmluZyB8fCAhbWlzc2lvblRleHQudHJpbSgpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnYXAtMS41XCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFNhdmUgY2xhc3NOYW1lPVwiaC00IHctNFwiIHN0cm9rZVdpZHRoPXsxLjV9IC8+XG4gICAgICAgICAgICAgIHtpc1NhdmluZyA/IFwiU2F2aW5nLi4uXCIgOiBcIlNhdmUgTWlzc2lvblwifVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvRGlhbG9nRm9vdGVyPlxuICAgICAgPC9EaWFsb2dDb250ZW50PlxuICAgIDwvRGlhbG9nPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvTWlzc2lvbk1vZGFsLnRzeCJ9