import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/select.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
"use client";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const React = ((m) => m?.__esModule ? m : { ...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {}, default: m })(__vite__cjsImport3_react);
import * as SelectPrimitive from "/node_modules/.vite/deps/@radix-ui_react-select.js?v=cbc3f0b7";
import { Check, ChevronDown, ChevronUp } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { cn } from "/src/lib/utils.ts";
const Select = SelectPrimitive.Root;
const SelectGroup = SelectPrimitive.Group;
const SelectValue = SelectPrimitive.Value;
const SelectTrigger = React.forwardRef(
  _c = ({ className, children, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    SelectPrimitive.Trigger,
    {
      ref,
      className: cn(
        "flex h-9 w-full items-center justify-between rounded-lg border border-line bg-surface-1 px-3 py-2 text-[13.5px] text-ink ring-offset-background data-[placeholder]:text-ink-muted focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-0 focus:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1",
        className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsxDEV(SelectPrimitive.Icon, { asChild: true, children: /* @__PURE__ */ jsxDEV(ChevronDown, { className: "h-4 w-4 opacity-50" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
          lineNumber: 48,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
          lineNumber: 47,
          columnNumber: 5
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
      lineNumber: 38,
      columnNumber: 1
    },
    this
  )
);
_c2 = SelectTrigger;
SelectTrigger.displayName = SelectPrimitive.Trigger.displayName;
const SelectScrollUpButton = React.forwardRef(
  _c3 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    SelectPrimitive.ScrollUpButton,
    {
      ref,
      className: cn(
        "flex cursor-default items-center justify-center py-1",
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsxDEV(ChevronUp, { className: "h-4 w-4" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
        lineNumber: 66,
        columnNumber: 5
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
      lineNumber: 58,
      columnNumber: 1
    },
    this
  )
);
_c4 = SelectScrollUpButton;
SelectScrollUpButton.displayName = SelectPrimitive.ScrollUpButton.displayName;
const SelectScrollDownButton = React.forwardRef(
  _c5 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    SelectPrimitive.ScrollDownButton,
    {
      ref,
      className: cn(
        "flex cursor-default items-center justify-center py-1",
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsxDEV(ChevronDown, { className: "h-4 w-4" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
        lineNumber: 83,
        columnNumber: 5
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
      lineNumber: 75,
      columnNumber: 1
    },
    this
  )
);
_c6 = SelectScrollDownButton;
SelectScrollDownButton.displayName = SelectPrimitive.ScrollDownButton.displayName;
const SelectContent = React.forwardRef(_c7 = ({ className, children, position = "popper", ...props }, ref) => {
  const resolvedPosition = position === "item-aligned" ? "item-aligned" : "popper";
  return /* @__PURE__ */ jsxDEV(SelectPrimitive.Portal, { children: /* @__PURE__ */ jsxDEV(
    SelectPrimitive.Content,
    {
      ref,
      className: cn(
        "relative z-50 max-h-[--radix-select-content-available-height] min-w-[10rem] overflow-y-auto overflow-x-hidden rounded-lg border border-line bg-surface-3 text-ink shadow-[var(--shadow-elevation-2)] data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-[--radix-select-content-transform-origin]",
        resolvedPosition === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1",
        className
      ),
      position: resolvedPosition,
      ...props,
      children: [
        /* @__PURE__ */ jsxDEV(SelectScrollUpButton, {}, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
          lineNumber: 109,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(
          SelectPrimitive.Viewport,
          {
            className: cn(
              "p-1",
              resolvedPosition === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"
            ),
            children
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
            lineNumber: 110,
            columnNumber: 9
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(SelectScrollDownButton, {}, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
          lineNumber: 119,
          columnNumber: 9
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
      lineNumber: 98,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
    lineNumber: 97,
    columnNumber: 5
  }, this);
});
_c8 = SelectContent;
SelectContent.displayName = SelectPrimitive.Content.displayName;
const SelectLabel = React.forwardRef(
  _c9 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    SelectPrimitive.Label,
    {
      ref,
      className: cn("px-3 py-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
      lineNumber: 130,
      columnNumber: 1
    },
    this
  )
);
_c0 = SelectLabel;
SelectLabel.displayName = SelectPrimitive.Label.displayName;
const SelectItem = React.forwardRef(
  _c1 = ({ className, children, value, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    SelectPrimitive.Item,
    {
      ref,
      value,
      className: cn(
        "relative flex w-full cursor-default select-none items-center rounded-2xl py-2 pl-9 pr-3 text-sm outline-none focus:bg-registry-accent-soft focus:text-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        className
      ),
      ...props,
      children: [
        /* @__PURE__ */ jsxDEV("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ jsxDEV(SelectPrimitive.ItemIndicator, { children: /* @__PURE__ */ jsxDEV(Check, { className: "h-4 w-4" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
          lineNumber: 153,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
          lineNumber: 152,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
          lineNumber: 151,
          columnNumber: 5
        }, this),
        /* @__PURE__ */ jsxDEV(SelectPrimitive.ItemText, { children }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
          lineNumber: 157,
          columnNumber: 5
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
      lineNumber: 142,
      columnNumber: 1
    },
    this
  )
);
_c10 = SelectItem;
SelectItem.displayName = SelectPrimitive.Item.displayName;
const SelectSeparator = React.forwardRef(
  _c11 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    SelectPrimitive.Separator,
    {
      ref,
      className: cn("-mx-1 my-1 h-px bg-muted", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx",
      lineNumber: 166,
      columnNumber: 1
    },
    this
  )
);
_c12 = SelectSeparator;
SelectSeparator.displayName = SelectPrimitive.Separator.displayName;
export {
  Select,
  SelectGroup,
  SelectValue,
  SelectTrigger,
  SelectContent,
  SelectLabel,
  SelectItem,
  SelectSeparator,
  SelectScrollUpButton,
  SelectScrollDownButton
};
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0, _c1, _c10, _c11, _c12;
$RefreshReg$(_c, "SelectTrigger$React.forwardRef");
$RefreshReg$(_c2, "SelectTrigger");
$RefreshReg$(_c3, "SelectScrollUpButton$React.forwardRef");
$RefreshReg$(_c4, "SelectScrollUpButton");
$RefreshReg$(_c5, "SelectScrollDownButton$React.forwardRef");
$RefreshReg$(_c6, "SelectScrollDownButton");
$RefreshReg$(_c7, "SelectContent$React.forwardRef");
$RefreshReg$(_c8, "SelectContent");
$RefreshReg$(_c9, "SelectLabel$React.forwardRef");
$RefreshReg$(_c0, "SelectLabel");
$RefreshReg$(_c1, "SelectItem$React.forwardRef");
$RefreshReg$(_c10, "SelectItem");
$RefreshReg$(_c11, "SelectSeparator$React.forwardRef");
$RefreshReg$(_c12, "SelectSeparator");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/ui/select.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJNOzs7Ozs7Ozs7Ozs7Ozs7O0FBNUJOO0FBRUEsWUFBWUEsV0FBVztBQUN2QixZQUFZQyxxQkFBcUI7QUFDakMsU0FBU0MsT0FBT0MsYUFBYUMsaUJBQWlCO0FBRTlDLFNBQVNDLFVBQVU7QUFFbkIsTUFBTUMsU0FBU0wsZ0JBQWdCTTtBQUUvQixNQUFNQyxjQUFjUCxnQkFBZ0JRO0FBRXBDLE1BQU1DLGNBQWNULGdCQUFnQlU7QUFFcEMsTUFBTUMsZ0JBQWdCWixNQUFNYTtBQUFBQSxFQUczQkMsS0FBQ0EsQ0FBQyxFQUFFQyxXQUFXQyxVQUFVLEdBQUdDLE1BQU0sR0FBR0MsUUFDcEM7QUFBQSxJQUFDLGdCQUFnQjtBQUFBLElBQWhCO0FBQUEsTUFDQztBQUFBLE1BQ0EsV0FBV2I7QUFBQUEsUUFDVDtBQUFBLFFBQ0FVO0FBQUFBLE1BQ0Y7QUFBQSxNQUNBLEdBQUlFO0FBQUFBLE1BRUhEO0FBQUFBO0FBQUFBLFFBQ0QsdUJBQUMsZ0JBQWdCLE1BQWhCLEVBQXFCLFNBQU8sTUFDM0IsaUNBQUMsZUFBWSxXQUFVLHdCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJDLEtBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBO0FBQUE7QUFBQSxJQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVlBO0FBQ0Q7QUFBQ0csTUFqQklQO0FBa0JOQSxjQUFjUSxjQUFjbkIsZ0JBQWdCb0IsUUFBUUQ7QUFFcEQsTUFBTUUsdUJBQXVCdEIsTUFBTWE7QUFBQUEsRUFHbENVLE1BQUNBLENBQUMsRUFBRVIsV0FBVyxHQUFHRSxNQUFNLEdBQUdDLFFBQzFCO0FBQUEsSUFBQyxnQkFBZ0I7QUFBQSxJQUFoQjtBQUFBLE1BQ0M7QUFBQSxNQUNBLFdBQVdiO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBVTtBQUFBQSxNQUNGO0FBQUEsTUFDQSxHQUFJRTtBQUFBQSxNQUVKLGlDQUFDLGFBQVUsV0FBVSxhQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThCO0FBQUE7QUFBQSxJQVJoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQTtBQUNEO0FBQUNPLE1BZElGO0FBZU5BLHFCQUFxQkYsY0FBY25CLGdCQUFnQndCLGVBQWVMO0FBRWxFLE1BQU1NLHlCQUF5QjFCLE1BQU1hO0FBQUFBLEVBR3BDYyxNQUFDQSxDQUFDLEVBQUVaLFdBQVcsR0FBR0UsTUFBTSxHQUFHQyxRQUMxQjtBQUFBLElBQUMsZ0JBQWdCO0FBQUEsSUFBaEI7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXYjtBQUFBQSxRQUNUO0FBQUEsUUFDQVU7QUFBQUEsTUFDRjtBQUFBLE1BQ0EsR0FBSUU7QUFBQUEsTUFFSixpQ0FBQyxlQUFZLFdBQVUsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQztBQUFBO0FBQUEsSUFSbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBU0E7QUFDRDtBQUFDVyxNQWRJRjtBQWVOQSx1QkFBdUJOLGNBQ3JCbkIsZ0JBQWdCNEIsaUJBQWlCVDtBQUVuQyxNQUFNVSxnQkFBZ0I5QixNQUFNYSxXQUczQmtCLE1BQUNBLENBQUMsRUFBRWhCLFdBQVdDLFVBQVVnQixXQUFXLFVBQVUsR0FBR2YsTUFBTSxHQUFHQyxRQUFRO0FBQ2pFLFFBQU1lLG1CQUNKRCxhQUFhLGlCQUFpQixpQkFBaUI7QUFFakQsU0FDRSx1QkFBQyxnQkFBZ0IsUUFBaEIsRUFDQztBQUFBLElBQUMsZ0JBQWdCO0FBQUEsSUFBaEI7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXM0I7QUFBQUEsUUFDVDtBQUFBLFFBQ0E0QixxQkFBcUIsWUFDbkI7QUFBQSxRQUNGbEI7QUFBQUEsTUFDRjtBQUFBLE1BQ0EsVUFBVWtCO0FBQUFBLE1BQ1YsR0FBSWhCO0FBQUFBLE1BRUo7QUFBQSwrQkFBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFCO0FBQUEsUUFDckI7QUFBQSxVQUFDLGdCQUFnQjtBQUFBLFVBQWhCO0FBQUEsWUFDQyxXQUFXWjtBQUFBQSxjQUNUO0FBQUEsY0FDQTRCLHFCQUFxQixZQUNuQjtBQUFBLFlBQ0o7QUFBQSxZQUVDakI7QUFBQUE7QUFBQUEsVUFQSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLFFBQ0EsdUJBQUMsNEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QjtBQUFBO0FBQUE7QUFBQSxJQXJCekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBc0JBLEtBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QkE7QUFFSixDQUFDO0FBQUNrQixNQWxDSUo7QUFtQ05BLGNBQWNWLGNBQWNuQixnQkFBZ0JrQyxRQUFRZjtBQUVwRCxNQUFNZ0IsY0FBY3BDLE1BQU1hO0FBQUFBLEVBR3pCd0IsTUFBQ0EsQ0FBQyxFQUFFdEIsV0FBVyxHQUFHRSxNQUFNLEdBQUdDLFFBQzFCO0FBQUEsSUFBQyxnQkFBZ0I7QUFBQSxJQUFoQjtBQUFBLE1BQ0M7QUFBQSxNQUNBLFdBQVdiLEdBQUcseUZBQXlGVSxTQUFTO0FBQUEsTUFDaEgsR0FBSUU7QUFBQUE7QUFBQUEsSUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFHWTtBQUViO0FBQUNxQixNQVRJRjtBQVVOQSxZQUFZaEIsY0FBY25CLGdCQUFnQnNDLE1BQU1uQjtBQUVoRCxNQUFNb0IsYUFBYXhDLE1BQU1hO0FBQUFBLEVBR3hCNEIsTUFBQ0EsQ0FBQyxFQUFFMUIsV0FBV0MsVUFBVTBCLE9BQU8sR0FBR3pCLE1BQU0sR0FBR0MsUUFDM0M7QUFBQSxJQUFDLGdCQUFnQjtBQUFBLElBQWhCO0FBQUEsTUFDQztBQUFBLE1BQ0E7QUFBQSxNQUNBLFdBQVdiO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBVTtBQUFBQSxNQUNGO0FBQUEsTUFDQSxHQUFJRTtBQUFBQSxNQUVKO0FBQUEsK0JBQUMsVUFBSyxXQUFVLGdFQUNkLGlDQUFDLGdCQUFnQixlQUFoQixFQUNDLGlDQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBCLEtBRDVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBRUEsdUJBQUMsZ0JBQWdCLFVBQWhCLEVBQTBCRCxZQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DO0FBQUE7QUFBQTtBQUFBLElBZnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWdCQTtBQUNEO0FBQUMyQixPQXJCSUg7QUFzQk5BLFdBQVdwQixjQUFjbkIsZ0JBQWdCMkMsS0FBS3hCO0FBRTlDLE1BQU15QixrQkFBa0I3QyxNQUFNYTtBQUFBQSxFQUc3QmlDLE9BQUNBLENBQUMsRUFBRS9CLFdBQVcsR0FBR0UsTUFBTSxHQUFHQyxRQUMxQjtBQUFBLElBQUMsZ0JBQWdCO0FBQUEsSUFBaEI7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXYixHQUFHLDRCQUE0QlUsU0FBUztBQUFBLE1BQ25ELEdBQUlFO0FBQUFBO0FBQUFBLElBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBR1k7QUFFYjtBQUFDOEIsT0FUSUY7QUFVTkEsZ0JBQWdCekIsY0FBY25CLGdCQUFnQitDLFVBQVU1QjtBQUV4RDtBQUFBLEVBQ0VkO0FBQUFBLEVBQ0FFO0FBQUFBLEVBQ0FFO0FBQUFBLEVBQ0FFO0FBQUFBLEVBQ0FrQjtBQUFBQSxFQUNBTTtBQUFBQSxFQUNBSTtBQUFBQSxFQUNBSztBQUFBQSxFQUNBdkI7QUFBQUEsRUFDQUk7QUFBQUE7QUFDRCxJQUFBWixJQUFBSyxLQUFBSSxLQUFBQyxLQUFBRyxLQUFBQyxLQUFBRyxLQUFBRyxLQUFBRyxLQUFBQyxLQUFBRyxLQUFBRSxNQUFBRyxNQUFBQztBQUFBLGFBQUFqQyxJQUFBO0FBQUEsYUFBQUssS0FBQTtBQUFBLGFBQUFJLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUcsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBRyxLQUFBO0FBQUEsYUFBQUcsS0FBQTtBQUFBLGFBQUFHLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUcsS0FBQTtBQUFBLGFBQUFFLE1BQUE7QUFBQSxhQUFBRyxNQUFBO0FBQUEsYUFBQUMsTUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiU2VsZWN0UHJpbWl0aXZlIiwiQ2hlY2siLCJDaGV2cm9uRG93biIsIkNoZXZyb25VcCIsImNuIiwiU2VsZWN0IiwiUm9vdCIsIlNlbGVjdEdyb3VwIiwiR3JvdXAiLCJTZWxlY3RWYWx1ZSIsIlZhbHVlIiwiU2VsZWN0VHJpZ2dlciIsImZvcndhcmRSZWYiLCJfYyIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwicHJvcHMiLCJyZWYiLCJfYzIiLCJkaXNwbGF5TmFtZSIsIlRyaWdnZXIiLCJTZWxlY3RTY3JvbGxVcEJ1dHRvbiIsIl9jMyIsIl9jNCIsIlNjcm9sbFVwQnV0dG9uIiwiU2VsZWN0U2Nyb2xsRG93bkJ1dHRvbiIsIl9jNSIsIl9jNiIsIlNjcm9sbERvd25CdXR0b24iLCJTZWxlY3RDb250ZW50IiwiX2M3IiwicG9zaXRpb24iLCJyZXNvbHZlZFBvc2l0aW9uIiwiX2M4IiwiQ29udGVudCIsIlNlbGVjdExhYmVsIiwiX2M5IiwiX2MwIiwiTGFiZWwiLCJTZWxlY3RJdGVtIiwiX2MxIiwidmFsdWUiLCJfYzEwIiwiSXRlbSIsIlNlbGVjdFNlcGFyYXRvciIsIl9jMTEiLCJfYzEyIiwiU2VwYXJhdG9yIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInNlbGVjdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2UgY2xpZW50XCJcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCJcbmltcG9ydCAqIGFzIFNlbGVjdFByaW1pdGl2ZSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXNlbGVjdFwiXG5pbXBvcnQgeyBDaGVjaywgQ2hldnJvbkRvd24sIENoZXZyb25VcCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIlxuXG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiXG5cbmNvbnN0IFNlbGVjdCA9IFNlbGVjdFByaW1pdGl2ZS5Sb290XG5cbmNvbnN0IFNlbGVjdEdyb3VwID0gU2VsZWN0UHJpbWl0aXZlLkdyb3VwXG5cbmNvbnN0IFNlbGVjdFZhbHVlID0gU2VsZWN0UHJpbWl0aXZlLlZhbHVlXG5cbmNvbnN0IFNlbGVjdFRyaWdnZXIgPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBSZWFjdC5FbGVtZW50UmVmPHR5cGVvZiBTZWxlY3RQcmltaXRpdmUuVHJpZ2dlcj4sXG4gIFJlYWN0LkNvbXBvbmVudFByb3BzV2l0aG91dFJlZjx0eXBlb2YgU2VsZWN0UHJpbWl0aXZlLlRyaWdnZXI+XG4+KCh7IGNsYXNzTmFtZSwgY2hpbGRyZW4sIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8U2VsZWN0UHJpbWl0aXZlLlRyaWdnZXJcbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgXCJmbGV4IGgtOSB3LWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgcHgtMyBweS0yIHRleHQtWzEzLjVweF0gdGV4dC1pbmsgcmluZy1vZmZzZXQtYmFja2dyb3VuZCBkYXRhLVtwbGFjZWhvbGRlcl06dGV4dC1pbmstbXV0ZWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXJpbmcgZm9jdXM6cmluZy1vZmZzZXQtMCBmb2N1czpyaW5nLW9mZnNldC1iYWNrZ3JvdW5kIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBkaXNhYmxlZDpvcGFjaXR5LTUwIFsmPnNwYW5dOmxpbmUtY2xhbXAtMVwiLFxuICAgICAgY2xhc3NOYW1lXG4gICAgKX1cbiAgICB7Li4ucHJvcHN9XG4gID5cbiAgICB7Y2hpbGRyZW59XG4gICAgPFNlbGVjdFByaW1pdGl2ZS5JY29uIGFzQ2hpbGQ+XG4gICAgICA8Q2hldnJvbkRvd24gY2xhc3NOYW1lPVwiaC00IHctNCBvcGFjaXR5LTUwXCIgLz5cbiAgICA8L1NlbGVjdFByaW1pdGl2ZS5JY29uPlxuICA8L1NlbGVjdFByaW1pdGl2ZS5UcmlnZ2VyPlxuKSlcblNlbGVjdFRyaWdnZXIuZGlzcGxheU5hbWUgPSBTZWxlY3RQcmltaXRpdmUuVHJpZ2dlci5kaXNwbGF5TmFtZVxuXG5jb25zdCBTZWxlY3RTY3JvbGxVcEJ1dHRvbiA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIFJlYWN0LkVsZW1lbnRSZWY8dHlwZW9mIFNlbGVjdFByaW1pdGl2ZS5TY3JvbGxVcEJ1dHRvbj4sXG4gIFJlYWN0LkNvbXBvbmVudFByb3BzV2l0aG91dFJlZjx0eXBlb2YgU2VsZWN0UHJpbWl0aXZlLlNjcm9sbFVwQnV0dG9uPlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8U2VsZWN0UHJpbWl0aXZlLlNjcm9sbFVwQnV0dG9uXG4gICAgcmVmPXtyZWZ9XG4gICAgY2xhc3NOYW1lPXtjbihcbiAgICAgIFwiZmxleCBjdXJzb3ItZGVmYXVsdCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktMVwiLFxuICAgICAgY2xhc3NOYW1lXG4gICAgKX1cbiAgICB7Li4ucHJvcHN9XG4gID5cbiAgICA8Q2hldnJvblVwIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICA8L1NlbGVjdFByaW1pdGl2ZS5TY3JvbGxVcEJ1dHRvbj5cbikpXG5TZWxlY3RTY3JvbGxVcEJ1dHRvbi5kaXNwbGF5TmFtZSA9IFNlbGVjdFByaW1pdGl2ZS5TY3JvbGxVcEJ1dHRvbi5kaXNwbGF5TmFtZVxuXG5jb25zdCBTZWxlY3RTY3JvbGxEb3duQnV0dG9uID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgUmVhY3QuRWxlbWVudFJlZjx0eXBlb2YgU2VsZWN0UHJpbWl0aXZlLlNjcm9sbERvd25CdXR0b24+LFxuICBSZWFjdC5Db21wb25lbnRQcm9wc1dpdGhvdXRSZWY8dHlwZW9mIFNlbGVjdFByaW1pdGl2ZS5TY3JvbGxEb3duQnV0dG9uPlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8U2VsZWN0UHJpbWl0aXZlLlNjcm9sbERvd25CdXR0b25cbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgXCJmbGV4IGN1cnNvci1kZWZhdWx0IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBweS0xXCIsXG4gICAgICBjbGFzc05hbWVcbiAgICApfVxuICAgIHsuLi5wcm9wc31cbiAgPlxuICAgIDxDaGV2cm9uRG93biBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgPC9TZWxlY3RQcmltaXRpdmUuU2Nyb2xsRG93bkJ1dHRvbj5cbikpXG5TZWxlY3RTY3JvbGxEb3duQnV0dG9uLmRpc3BsYXlOYW1lID1cbiAgU2VsZWN0UHJpbWl0aXZlLlNjcm9sbERvd25CdXR0b24uZGlzcGxheU5hbWVcblxuY29uc3QgU2VsZWN0Q29udGVudCA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIFJlYWN0LkVsZW1lbnRSZWY8dHlwZW9mIFNlbGVjdFByaW1pdGl2ZS5Db250ZW50PixcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBTZWxlY3RQcmltaXRpdmUuQ29udGVudD5cbj4oKHsgY2xhc3NOYW1lLCBjaGlsZHJlbiwgcG9zaXRpb24gPSBcInBvcHBlclwiLCAuLi5wcm9wcyB9LCByZWYpID0+IHtcbiAgY29uc3QgcmVzb2x2ZWRQb3NpdGlvbjogXCJpdGVtLWFsaWduZWRcIiB8IFwicG9wcGVyXCIgPVxuICAgIHBvc2l0aW9uID09PSBcIml0ZW0tYWxpZ25lZFwiID8gXCJpdGVtLWFsaWduZWRcIiA6IFwicG9wcGVyXCJcblxuICByZXR1cm4gKFxuICAgIDxTZWxlY3RQcmltaXRpdmUuUG9ydGFsPlxuICAgICAgPFNlbGVjdFByaW1pdGl2ZS5Db250ZW50XG4gICAgICAgIHJlZj17cmVmfVxuICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgIFwicmVsYXRpdmUgei01MCBtYXgtaC1bLS1yYWRpeC1zZWxlY3QtY29udGVudC1hdmFpbGFibGUtaGVpZ2h0XSBtaW4tdy1bMTByZW1dIG92ZXJmbG93LXktYXV0byBvdmVyZmxvdy14LWhpZGRlbiByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTMgdGV4dC1pbmsgc2hhZG93LVt2YXIoLS1zaGFkb3ctZWxldmF0aW9uLTIpXSBkYXRhLVtzdGF0ZT1vcGVuXTphbmltYXRlLWluIGRhdGEtW3N0YXRlPWNsb3NlZF06YW5pbWF0ZS1vdXQgZGF0YS1bc3RhdGU9Y2xvc2VkXTpmYWRlLW91dC0wIGRhdGEtW3N0YXRlPW9wZW5dOmZhZGUtaW4tMCBkYXRhLVtzdGF0ZT1jbG9zZWRdOnpvb20tb3V0LTk1IGRhdGEtW3N0YXRlPW9wZW5dOnpvb20taW4tOTUgZGF0YS1bc2lkZT1ib3R0b21dOnNsaWRlLWluLWZyb20tdG9wLTIgZGF0YS1bc2lkZT1sZWZ0XTpzbGlkZS1pbi1mcm9tLXJpZ2h0LTIgZGF0YS1bc2lkZT1yaWdodF06c2xpZGUtaW4tZnJvbS1sZWZ0LTIgZGF0YS1bc2lkZT10b3BdOnNsaWRlLWluLWZyb20tYm90dG9tLTIgb3JpZ2luLVstLXJhZGl4LXNlbGVjdC1jb250ZW50LXRyYW5zZm9ybS1vcmlnaW5dXCIsXG4gICAgICAgICAgcmVzb2x2ZWRQb3NpdGlvbiA9PT0gXCJwb3BwZXJcIiAmJlxuICAgICAgICAgICAgXCJkYXRhLVtzaWRlPWJvdHRvbV06dHJhbnNsYXRlLXktMSBkYXRhLVtzaWRlPWxlZnRdOi10cmFuc2xhdGUteC0xIGRhdGEtW3NpZGU9cmlnaHRdOnRyYW5zbGF0ZS14LTEgZGF0YS1bc2lkZT10b3BdOi10cmFuc2xhdGUteS0xXCIsXG4gICAgICAgICAgY2xhc3NOYW1lXG4gICAgICAgICl9XG4gICAgICAgIHBvc2l0aW9uPXtyZXNvbHZlZFBvc2l0aW9ufVxuICAgICAgICB7Li4ucHJvcHN9XG4gICAgICA+XG4gICAgICAgIDxTZWxlY3RTY3JvbGxVcEJ1dHRvbiAvPlxuICAgICAgICA8U2VsZWN0UHJpbWl0aXZlLlZpZXdwb3J0XG4gICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgIFwicC0xXCIsXG4gICAgICAgICAgICByZXNvbHZlZFBvc2l0aW9uID09PSBcInBvcHBlclwiICYmXG4gICAgICAgICAgICAgIFwiaC1bdmFyKC0tcmFkaXgtc2VsZWN0LXRyaWdnZXItaGVpZ2h0KV0gdy1mdWxsIG1pbi13LVt2YXIoLS1yYWRpeC1zZWxlY3QtdHJpZ2dlci13aWR0aCldXCJcbiAgICAgICAgICApfVxuICAgICAgICA+XG4gICAgICAgICAge2NoaWxkcmVufVxuICAgICAgICA8L1NlbGVjdFByaW1pdGl2ZS5WaWV3cG9ydD5cbiAgICAgICAgPFNlbGVjdFNjcm9sbERvd25CdXR0b24gLz5cbiAgICAgIDwvU2VsZWN0UHJpbWl0aXZlLkNvbnRlbnQ+XG4gICAgPC9TZWxlY3RQcmltaXRpdmUuUG9ydGFsPlxuICApXG59KVxuU2VsZWN0Q29udGVudC5kaXNwbGF5TmFtZSA9IFNlbGVjdFByaW1pdGl2ZS5Db250ZW50LmRpc3BsYXlOYW1lXG5cbmNvbnN0IFNlbGVjdExhYmVsID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgUmVhY3QuRWxlbWVudFJlZjx0eXBlb2YgU2VsZWN0UHJpbWl0aXZlLkxhYmVsPixcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBTZWxlY3RQcmltaXRpdmUuTGFiZWw+XG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDxTZWxlY3RQcmltaXRpdmUuTGFiZWxcbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFwicHgtMyBweS0yIHRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLVswLjE4ZW1dIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiLCBjbGFzc05hbWUpfVxuICAgIHsuLi5wcm9wc31cbiAgLz5cbikpXG5TZWxlY3RMYWJlbC5kaXNwbGF5TmFtZSA9IFNlbGVjdFByaW1pdGl2ZS5MYWJlbC5kaXNwbGF5TmFtZVxuXG5jb25zdCBTZWxlY3RJdGVtID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgUmVhY3QuRWxlbWVudFJlZjx0eXBlb2YgU2VsZWN0UHJpbWl0aXZlLkl0ZW0+LFxuICBSZWFjdC5Db21wb25lbnRQcm9wc1dpdGhvdXRSZWY8dHlwZW9mIFNlbGVjdFByaW1pdGl2ZS5JdGVtPlxuPigoeyBjbGFzc05hbWUsIGNoaWxkcmVuLCB2YWx1ZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDxTZWxlY3RQcmltaXRpdmUuSXRlbVxuICAgIHJlZj17cmVmfVxuICAgIHZhbHVlPXt2YWx1ZX1cbiAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgXCJyZWxhdGl2ZSBmbGV4IHctZnVsbCBjdXJzb3ItZGVmYXVsdCBzZWxlY3Qtbm9uZSBpdGVtcy1jZW50ZXIgcm91bmRlZC0yeGwgcHktMiBwbC05IHByLTMgdGV4dC1zbSBvdXRsaW5lLW5vbmUgZm9jdXM6YmctcmVnaXN0cnktYWNjZW50LXNvZnQgZm9jdXM6dGV4dC1mb3JlZ3JvdW5kIGRhdGEtW2Rpc2FibGVkXTpwb2ludGVyLWV2ZW50cy1ub25lIGRhdGEtW2Rpc2FibGVkXTpvcGFjaXR5LTUwXCIsXG4gICAgICBjbGFzc05hbWVcbiAgICApfVxuICAgIHsuLi5wcm9wc31cbiAgPlxuICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMiBmbGV4IGgtMy41IHctMy41IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgPFNlbGVjdFByaW1pdGl2ZS5JdGVtSW5kaWNhdG9yPlxuICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICA8L1NlbGVjdFByaW1pdGl2ZS5JdGVtSW5kaWNhdG9yPlxuICAgIDwvc3Bhbj5cblxuICAgIDxTZWxlY3RQcmltaXRpdmUuSXRlbVRleHQ+e2NoaWxkcmVufTwvU2VsZWN0UHJpbWl0aXZlLkl0ZW1UZXh0PlxuICA8L1NlbGVjdFByaW1pdGl2ZS5JdGVtPlxuKSlcblNlbGVjdEl0ZW0uZGlzcGxheU5hbWUgPSBTZWxlY3RQcmltaXRpdmUuSXRlbS5kaXNwbGF5TmFtZVxuXG5jb25zdCBTZWxlY3RTZXBhcmF0b3IgPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBSZWFjdC5FbGVtZW50UmVmPHR5cGVvZiBTZWxlY3RQcmltaXRpdmUuU2VwYXJhdG9yPixcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBTZWxlY3RQcmltaXRpdmUuU2VwYXJhdG9yPlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8U2VsZWN0UHJpbWl0aXZlLlNlcGFyYXRvclxuICAgIHJlZj17cmVmfVxuICAgIGNsYXNzTmFtZT17Y24oXCItbXgtMSBteS0xIGgtcHggYmctbXV0ZWRcIiwgY2xhc3NOYW1lKX1cbiAgICB7Li4ucHJvcHN9XG4gIC8+XG4pKVxuU2VsZWN0U2VwYXJhdG9yLmRpc3BsYXlOYW1lID0gU2VsZWN0UHJpbWl0aXZlLlNlcGFyYXRvci5kaXNwbGF5TmFtZVxuXG5leHBvcnQge1xuICBTZWxlY3QsXG4gIFNlbGVjdEdyb3VwLFxuICBTZWxlY3RWYWx1ZSxcbiAgU2VsZWN0VHJpZ2dlcixcbiAgU2VsZWN0Q29udGVudCxcbiAgU2VsZWN0TGFiZWwsXG4gIFNlbGVjdEl0ZW0sXG4gIFNlbGVjdFNlcGFyYXRvcixcbiAgU2VsZWN0U2Nyb2xsVXBCdXR0b24sXG4gIFNlbGVjdFNjcm9sbERvd25CdXR0b24sXG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9jb21wb25lbnRzL3VpL3NlbGVjdC50c3gifQ==