import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/automations/AutomationCandidates.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { ReceiptText, ShieldAlert } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { Badge } from "/src/components/ui/badge.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Card } from "/src/components/ui/card.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "/src/components/ui/dialog.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { Textarea } from "/src/components/ui/textarea.tsx";
export function AutomationCandidates({ projectId, candidates }) {
  _s();
  const accept = useMutation(api.automations.acceptCandidate);
  const [selected, setSelected] = useState(null);
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState(null);
  async function confirm() {
    if (!selected || reason.trim().length < 5) return;
    setBusy(true);
    try {
      const result = await accept({
        projectId,
        candidateId: selected.id,
        actorId: "operator",
        reason: reason.trim(),
        policyVersion: "automation-v1"
      });
      setMessage({ text: result.created ? "Disabled Automation Definition created. Activation remains a separate decision." : "This candidate already has an Automation Definition." });
      setSelected(null);
      setReason("");
    } catch (error) {
      setMessage({ error: true, text: error instanceof Error ? error.message : "Candidate acceptance failed" });
    } finally {
      setBusy(false);
    }
  }
  if (candidates.length === 0) {
    return /* @__PURE__ */ jsxDEV(Card, { className: "border-dashed p-8 text-center text-sm text-muted-foreground", children: "No repeated-work candidates yet. Two completed WorkOrders with comparable scope are required." }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
      lineNumber: 63,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
    message ? /* @__PURE__ */ jsxDEV("p", { role: message.error ? "alert" : "status", className: message.error ? "text-sm text-red-300" : "text-sm text-emerald-300", children: message.text }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
      lineNumber: 67,
      columnNumber: 18
    }, this) : null,
    /* @__PURE__ */ jsxDEV("div", { className: "grid gap-3", children: candidates.map(
      (candidate) => /* @__PURE__ */ jsxDEV(Card, { className: "p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-start justify-between gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "font-medium text-foreground", children: candidate.pattern }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
                lineNumber: 74,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: [
                Math.round(candidate.confidence * 100),
                "% confidence"
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
                lineNumber: 75,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", children: [
                candidate.riskLevel,
                " risk"
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
                lineNumber: 76,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
              lineNumber: 73,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-3 grid gap-2 text-sm text-muted-foreground sm:grid-cols-2 xl:grid-cols-5", children: [
              /* @__PURE__ */ jsxDEV("span", { children: [
                candidate.occurrences,
                " occurrences"
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
                lineNumber: 79,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1", children: [
                /* @__PURE__ */ jsxDEV(ReceiptText, { className: "h-4 w-4" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
                  lineNumber: 80,
                  columnNumber: 61
                }, this),
                " ",
                candidate.receiptCount,
                " eligible receipts"
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
                lineNumber: 80,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: candidate.workflowId ? `Workflow ${candidate.workflowId}` : "Workflow required" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
                lineNumber: 81,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: candidate.suggestedCadence }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
                lineNumber: 82,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: [
                "~",
                candidate.estimatedHumanMinutesSaved,
                " min saved"
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
                lineNumber: 83,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
              lineNumber: 78,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
            lineNumber: 72,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { disabled: !candidate.eligible, onClick: () => setSelected(candidate), children: candidate.eligible ? "Review candidate" : "Workflow design required" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
            lineNumber: 86,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
          lineNumber: 71,
          columnNumber: 13
        }, this),
        !candidate.eligible ? /* @__PURE__ */ jsxDEV("p", { className: "mt-3 flex items-center gap-1.5 text-xs text-amber-200", children: [
          /* @__PURE__ */ jsxDEV(ShieldAlert, { className: "h-3.5 w-3.5" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
            lineNumber: 90,
            columnNumber: 105
          }, this),
          " Repository-only patterns cannot activate until they reference a versioned Workflow and passing receipt."
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
          lineNumber: 90,
          columnNumber: 36
        }, this) : null
      ] }, candidate.id, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
        lineNumber: 70,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
      lineNumber: 68,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Dialog, { open: !!selected, onOpenChange: (open) => {
      if (!open) setSelected(null);
    }, children: /* @__PURE__ */ jsxDEV(DialogContent, { children: [
      /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
        /* @__PURE__ */ jsxDEV(DialogTitle, { children: [
          "Accept candidate: ",
          selected?.pattern
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
          lineNumber: 97,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(DialogDescription, { children: "This creates a disabled LEVEL_1 Automation Definition. It does not activate, approve, or dispatch work." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
          lineNumber: 98,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
        lineNumber: 96,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-border bg-muted/20 p-3 text-sm text-muted-foreground", children: [
        selected?.occurrences,
        " occurrences · ",
        selected?.receiptCount,
        " receipts · ",
        selected?.workflowId,
        "@current"
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
        lineNumber: 100,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: "candidate-decision-reason", children: "Acceptance reason" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
          lineNumber: 104,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Textarea, { id: "candidate-decision-reason", value: reason, onChange: (event) => setReason(event.target.value), placeholder: "Why should this pattern become a governed definition?" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
          lineNumber: 105,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
        lineNumber: 103,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "outline", onClick: () => setSelected(null), children: "Cancel" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
          lineNumber: 108,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { disabled: busy || reason.trim().length < 5, onClick: () => void confirm(), children: busy ? "Creating…" : "Create disabled definition" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
          lineNumber: 109,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
        lineNumber: 107,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
      lineNumber: 95,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
      lineNumber: 94,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx",
    lineNumber: 66,
    columnNumber: 5
  }, this);
}
_s(AutomationCandidates, "N9GG0D6UVnocmhd3D6Mxvp5Jcns=", false, function() {
  return [useMutation];
});
_c = AutomationCandidates;
var _c;
$RefreshReg$(_c, "AutomationCandidates");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/automations/AutomationCandidates.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNXOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNDWCxTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGFBQWFDLG1CQUFtQjtBQUN6QyxTQUFTQyxXQUFXO0FBRXBCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxZQUFZO0FBQ3JCO0FBQUEsRUFDRUM7QUFBQUEsRUFBUUM7QUFBQUEsRUFBZUM7QUFBQUEsRUFBbUJDO0FBQUFBLEVBQWNDO0FBQUFBLEVBQWNDO0FBQUFBLE9BQ2pFO0FBQ1AsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxnQkFBZ0I7QUFFbEIsZ0JBQVNDLHFCQUFxQixFQUFFQyxXQUFXQyxXQUE2RCxHQUFHO0FBQUFDLEtBQUE7QUFDaEgsUUFBTUMsU0FBU25CLFlBQVlHLElBQUlpQixZQUFZQyxlQUFlO0FBQzFELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJeEIsU0FBcUIsSUFBSTtBQUN6RCxRQUFNLENBQUN5QixRQUFRQyxTQUFTLElBQUkxQixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDMkIsTUFBTUMsT0FBTyxJQUFJNUIsU0FBUyxLQUFLO0FBQ3RDLFFBQU0sQ0FBQzZCLFNBQVNDLFVBQVUsSUFBSTlCLFNBQW1ELElBQUk7QUFFckYsaUJBQWUrQixVQUFVO0FBQ3ZCLFFBQUksQ0FBQ1IsWUFBWUUsT0FBT08sS0FBSyxFQUFFQyxTQUFTLEVBQUc7QUFDM0NMLFlBQVEsSUFBSTtBQUNaLFFBQUk7QUFDRixZQUFNTSxTQUFTLE1BQU1kLE9BQU87QUFBQSxRQUMxQkg7QUFBQUEsUUFDQWtCLGFBQWFaLFNBQVNhO0FBQUFBLFFBQ3RCQyxTQUFTO0FBQUEsUUFDVFosUUFBUUEsT0FBT08sS0FBSztBQUFBLFFBQ3BCTSxlQUFlO0FBQUEsTUFDakIsQ0FBQztBQUNEUixpQkFBVyxFQUFFUyxNQUFNTCxPQUFPTSxVQUFVLG9GQUFvRix1REFBdUQsQ0FBQztBQUNoTGhCLGtCQUFZLElBQUk7QUFDaEJFLGdCQUFVLEVBQUU7QUFBQSxJQUNkLFNBQVNlLE9BQU87QUFDZFgsaUJBQVcsRUFBRVcsT0FBTyxNQUFNRixNQUFNRSxpQkFBaUJDLFFBQVFELE1BQU1aLFVBQVUsOEJBQThCLENBQUM7QUFBQSxJQUMxRyxVQUFDO0FBQ0NELGNBQVEsS0FBSztBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBRUEsTUFBSVYsV0FBV2UsV0FBVyxHQUFHO0FBQzNCLFdBQU8sdUJBQUMsUUFBSyxXQUFVLCtEQUE4RCw2R0FBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEySztBQUFBLEVBQ3BMO0FBQ0EsU0FDRSx1QkFBQyxTQUFJLFdBQVUsYUFDWko7QUFBQUEsY0FBVSx1QkFBQyxPQUFFLE1BQU1BLFFBQVFZLFFBQVEsVUFBVSxVQUFVLFdBQVdaLFFBQVFZLFFBQVEseUJBQXlCLDRCQUE2Qlosa0JBQVFVLFFBQXRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkksSUFBTztBQUFBLElBQzdKLHVCQUFDLFNBQUksV0FBVSxjQUNackIscUJBQVd5QjtBQUFBQSxNQUFJLENBQUNDLGNBQ2YsdUJBQUMsUUFBd0IsV0FBVSxPQUNqQztBQUFBLCtCQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSwrQkFBK0JBLG9CQUFVQyxXQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErRDtBQUFBLGNBQy9ELHVCQUFDLFNBQU0sU0FBUSxXQUFXQztBQUFBQSxxQkFBS0MsTUFBTUgsVUFBVUksYUFBYSxHQUFHO0FBQUEsZ0JBQUU7QUFBQSxtQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkU7QUFBQSxjQUM3RSx1QkFBQyxTQUFNLFNBQVEsV0FBV0o7QUFBQUEsMEJBQVVLO0FBQUFBLGdCQUFVO0FBQUEsbUJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1EO0FBQUEsaUJBSHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwrRUFDYjtBQUFBLHFDQUFDLFVBQU1MO0FBQUFBLDBCQUFVTTtBQUFBQSxnQkFBWTtBQUFBLG1CQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QztBQUFBLGNBQ3pDLHVCQUFDLFVBQUssV0FBVSwyQkFBMEI7QUFBQSx1Q0FBQyxlQUFZLFdBQVUsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxnQkFBRztBQUFBLGdCQUFFTixVQUFVTztBQUFBQSxnQkFBYTtBQUFBLG1CQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3SDtBQUFBLGNBQ3hILHVCQUFDLFVBQU1QLG9CQUFVUSxhQUFhLFlBQVlSLFVBQVVRLFVBQVUsS0FBSyx1QkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUY7QUFBQSxjQUN2Rix1QkFBQyxVQUFNUixvQkFBVVMsb0JBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtDO0FBQUEsY0FDbEMsdUJBQUMsVUFBSztBQUFBO0FBQUEsZ0JBQUVULFVBQVVVO0FBQUFBLGdCQUEyQjtBQUFBLG1CQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RDtBQUFBLGlCQUx6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFDQSx1QkFBQyxVQUFPLFVBQVUsQ0FBQ1YsVUFBVVcsVUFBVSxTQUFTLE1BQU0vQixZQUFZb0IsU0FBUyxHQUN4RUEsb0JBQVVXLFdBQVcscUJBQXFCLDhCQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQTtBQUFBLFFBQ0MsQ0FBQ1gsVUFBVVcsV0FBVyx1QkFBQyxPQUFFLFdBQVUseURBQXdEO0FBQUEsaUNBQUMsZUFBWSxXQUFVLGlCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQztBQUFBLFVBQUc7QUFBQSxhQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9OLElBQU87QUFBQSxXQXBCek9YLFVBQVVSLElBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxJQUNELEtBeEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkE7QUFBQSxJQUNBLHVCQUFDLFVBQU8sTUFBTSxDQUFDLENBQUNiLFVBQVUsY0FBYyxDQUFDaUMsU0FBUztBQUFFLFVBQUksQ0FBQ0EsS0FBTWhDLGFBQVksSUFBSTtBQUFBLElBQUcsR0FDaEYsaUNBQUMsaUJBQ0M7QUFBQSw2QkFBQyxnQkFDQztBQUFBLCtCQUFDLGVBQVk7QUFBQTtBQUFBLFVBQW1CRCxVQUFVc0I7QUFBQUEsYUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRDtBQUFBLFFBQ2xELHVCQUFDLHFCQUFrQix1SEFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwSDtBQUFBLFdBRjVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlGQUNadEI7QUFBQUEsa0JBQVUyQjtBQUFBQSxRQUFZO0FBQUEsUUFBZ0IzQixVQUFVNEI7QUFBQUEsUUFBYTtBQUFBLFFBQWE1QixVQUFVNkI7QUFBQUEsUUFBVztBQUFBLFdBRGxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxTQUFNLFNBQVEsNkJBQTRCLGlDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTREO0FBQUEsUUFDNUQsdUJBQUMsWUFBUyxJQUFHLDZCQUE0QixPQUFPM0IsUUFBUSxVQUFVLENBQUNnQyxVQUFVL0IsVUFBVStCLE1BQU1DLE9BQU9DLEtBQUssR0FBRyxhQUFZLDJEQUF4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStLO0FBQUEsV0FGakw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxnQkFDQztBQUFBLCtCQUFDLFVBQU8sU0FBUSxXQUFVLFNBQVMsTUFBTW5DLFlBQVksSUFBSSxHQUFHLHNCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtFO0FBQUEsUUFDbEUsdUJBQUMsVUFBTyxVQUFVRyxRQUFRRixPQUFPTyxLQUFLLEVBQUVDLFNBQVMsR0FBRyxTQUFTLE1BQU0sS0FBS0YsUUFBUSxHQUFJSixpQkFBTyxjQUFjLGdDQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNJO0FBQUEsV0FGeEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JBLEtBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQkE7QUFBQSxPQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0NBO0FBRUo7QUFBQ1IsR0FqRmVILHNCQUFvQjtBQUFBLFVBQ25CZixXQUFXO0FBQUE7QUFBQSxLQURaZTtBQUFvQixJQUFBNEM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNdXRhdGlvbiIsIlJlY2VpcHRUZXh0IiwiU2hpZWxkQWxlcnQiLCJhcGkiLCJCYWRnZSIsIkJ1dHRvbiIsIkNhcmQiLCJEaWFsb2ciLCJEaWFsb2dDb250ZW50IiwiRGlhbG9nRGVzY3JpcHRpb24iLCJEaWFsb2dGb290ZXIiLCJEaWFsb2dIZWFkZXIiLCJEaWFsb2dUaXRsZSIsIkxhYmVsIiwiVGV4dGFyZWEiLCJBdXRvbWF0aW9uQ2FuZGlkYXRlcyIsInByb2plY3RJZCIsImNhbmRpZGF0ZXMiLCJfcyIsImFjY2VwdCIsImF1dG9tYXRpb25zIiwiYWNjZXB0Q2FuZGlkYXRlIiwic2VsZWN0ZWQiLCJzZXRTZWxlY3RlZCIsInJlYXNvbiIsInNldFJlYXNvbiIsImJ1c3kiLCJzZXRCdXN5IiwibWVzc2FnZSIsInNldE1lc3NhZ2UiLCJjb25maXJtIiwidHJpbSIsImxlbmd0aCIsInJlc3VsdCIsImNhbmRpZGF0ZUlkIiwiaWQiLCJhY3RvcklkIiwicG9saWN5VmVyc2lvbiIsInRleHQiLCJjcmVhdGVkIiwiZXJyb3IiLCJFcnJvciIsIm1hcCIsImNhbmRpZGF0ZSIsInBhdHRlcm4iLCJNYXRoIiwicm91bmQiLCJjb25maWRlbmNlIiwicmlza0xldmVsIiwib2NjdXJyZW5jZXMiLCJyZWNlaXB0Q291bnQiLCJ3b3JrZmxvd0lkIiwic3VnZ2VzdGVkQ2FkZW5jZSIsImVzdGltYXRlZEh1bWFuTWludXRlc1NhdmVkIiwiZWxpZ2libGUiLCJvcGVuIiwiZXZlbnQiLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkF1dG9tYXRpb25DYW5kaWRhdGVzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlTXV0YXRpb24gfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBSZWNlaXB0VGV4dCwgU2hpZWxkQWxlcnQgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgQmFkZ2UgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2JhZGdlXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuaW1wb3J0IHsgQ2FyZCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvY2FyZFwiO1xuaW1wb3J0IHtcbiAgRGlhbG9nLCBEaWFsb2dDb250ZW50LCBEaWFsb2dEZXNjcmlwdGlvbiwgRGlhbG9nRm9vdGVyLCBEaWFsb2dIZWFkZXIsIERpYWxvZ1RpdGxlLFxufSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2RpYWxvZ1wiO1xuaW1wb3J0IHsgTGFiZWwgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2xhYmVsXCI7XG5pbXBvcnQgeyBUZXh0YXJlYSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvdGV4dGFyZWFcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIEF1dG9tYXRpb25DYW5kaWRhdGVzKHsgcHJvamVjdElkLCBjYW5kaWRhdGVzIH06IHsgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+OyBjYW5kaWRhdGVzOiBhbnlbXSB9KSB7XG4gIGNvbnN0IGFjY2VwdCA9IHVzZU11dGF0aW9uKGFwaS5hdXRvbWF0aW9ucy5hY2NlcHRDYW5kaWRhdGUpO1xuICBjb25zdCBbc2VsZWN0ZWQsIHNldFNlbGVjdGVkXSA9IHVzZVN0YXRlPGFueSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbcmVhc29uLCBzZXRSZWFzb25dID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtidXN5LCBzZXRCdXN5XSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGU8eyBlcnJvcj86IGJvb2xlYW47IHRleHQ6IHN0cmluZyB9IHwgbnVsbD4obnVsbCk7XG5cbiAgYXN5bmMgZnVuY3Rpb24gY29uZmlybSgpIHtcbiAgICBpZiAoIXNlbGVjdGVkIHx8IHJlYXNvbi50cmltKCkubGVuZ3RoIDwgNSkgcmV0dXJuO1xuICAgIHNldEJ1c3kodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGFjY2VwdCh7XG4gICAgICAgIHByb2plY3RJZCxcbiAgICAgICAgY2FuZGlkYXRlSWQ6IHNlbGVjdGVkLmlkLFxuICAgICAgICBhY3RvcklkOiBcIm9wZXJhdG9yXCIsXG4gICAgICAgIHJlYXNvbjogcmVhc29uLnRyaW0oKSxcbiAgICAgICAgcG9saWN5VmVyc2lvbjogXCJhdXRvbWF0aW9uLXYxXCIsXG4gICAgICB9KTtcbiAgICAgIHNldE1lc3NhZ2UoeyB0ZXh0OiByZXN1bHQuY3JlYXRlZCA/IFwiRGlzYWJsZWQgQXV0b21hdGlvbiBEZWZpbml0aW9uIGNyZWF0ZWQuIEFjdGl2YXRpb24gcmVtYWlucyBhIHNlcGFyYXRlIGRlY2lzaW9uLlwiIDogXCJUaGlzIGNhbmRpZGF0ZSBhbHJlYWR5IGhhcyBhbiBBdXRvbWF0aW9uIERlZmluaXRpb24uXCIgfSk7XG4gICAgICBzZXRTZWxlY3RlZChudWxsKTtcbiAgICAgIHNldFJlYXNvbihcIlwiKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgc2V0TWVzc2FnZSh7IGVycm9yOiB0cnVlLCB0ZXh0OiBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiQ2FuZGlkYXRlIGFjY2VwdGFuY2UgZmFpbGVkXCIgfSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEJ1c3koZmFsc2UpO1xuICAgIH1cbiAgfVxuXG4gIGlmIChjYW5kaWRhdGVzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiA8Q2FyZCBjbGFzc05hbWU9XCJib3JkZXItZGFzaGVkIHAtOCB0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPk5vIHJlcGVhdGVkLXdvcmsgY2FuZGlkYXRlcyB5ZXQuIFR3byBjb21wbGV0ZWQgV29ya09yZGVycyB3aXRoIGNvbXBhcmFibGUgc2NvcGUgYXJlIHJlcXVpcmVkLjwvQ2FyZD47XG4gIH1cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAge21lc3NhZ2UgPyA8cCByb2xlPXttZXNzYWdlLmVycm9yID8gXCJhbGVydFwiIDogXCJzdGF0dXNcIn0gY2xhc3NOYW1lPXttZXNzYWdlLmVycm9yID8gXCJ0ZXh0LXNtIHRleHQtcmVkLTMwMFwiIDogXCJ0ZXh0LXNtIHRleHQtZW1lcmFsZC0zMDBcIn0+e21lc3NhZ2UudGV4dH08L3A+IDogbnVsbH1cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtM1wiPlxuICAgICAgICB7Y2FuZGlkYXRlcy5tYXAoKGNhbmRpZGF0ZSkgPT4gKFxuICAgICAgICAgIDxDYXJkIGtleT17Y2FuZGlkYXRlLmlkfSBjbGFzc05hbWU9XCJwLTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZm9yZWdyb3VuZFwiPntjYW5kaWRhdGUucGF0dGVybn08L2gyPlxuICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCI+e01hdGgucm91bmQoY2FuZGlkYXRlLmNvbmZpZGVuY2UgKiAxMDApfSUgY29uZmlkZW5jZTwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cIm91dGxpbmVcIj57Y2FuZGlkYXRlLnJpc2tMZXZlbH0gcmlzazwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGdyaWQgZ2FwLTIgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmQgc206Z3JpZC1jb2xzLTIgeGw6Z3JpZC1jb2xzLTVcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPntjYW5kaWRhdGUub2NjdXJyZW5jZXN9IG9jY3VycmVuY2VzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj48UmVjZWlwdFRleHQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IHtjYW5kaWRhdGUucmVjZWlwdENvdW50fSBlbGlnaWJsZSByZWNlaXB0czwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPntjYW5kaWRhdGUud29ya2Zsb3dJZCA/IGBXb3JrZmxvdyAke2NhbmRpZGF0ZS53b3JrZmxvd0lkfWAgOiBcIldvcmtmbG93IHJlcXVpcmVkXCJ9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2NhbmRpZGF0ZS5zdWdnZXN0ZWRDYWRlbmNlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPn57Y2FuZGlkYXRlLmVzdGltYXRlZEh1bWFuTWludXRlc1NhdmVkfSBtaW4gc2F2ZWQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8QnV0dG9uIGRpc2FibGVkPXshY2FuZGlkYXRlLmVsaWdpYmxlfSBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZChjYW5kaWRhdGUpfT5cbiAgICAgICAgICAgICAgICB7Y2FuZGlkYXRlLmVsaWdpYmxlID8gXCJSZXZpZXcgY2FuZGlkYXRlXCIgOiBcIldvcmtmbG93IGRlc2lnbiByZXF1aXJlZFwifVxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgeyFjYW5kaWRhdGUuZWxpZ2libGUgPyA8cCBjbGFzc05hbWU9XCJtdC0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyB0ZXh0LWFtYmVyLTIwMFwiPjxTaGllbGRBbGVydCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+IFJlcG9zaXRvcnktb25seSBwYXR0ZXJucyBjYW5ub3QgYWN0aXZhdGUgdW50aWwgdGhleSByZWZlcmVuY2UgYSB2ZXJzaW9uZWQgV29ya2Zsb3cgYW5kIHBhc3NpbmcgcmVjZWlwdC48L3A+IDogbnVsbH1cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG4gICAgICA8RGlhbG9nIG9wZW49eyEhc2VsZWN0ZWR9IG9uT3BlbkNoYW5nZT17KG9wZW4pID0+IHsgaWYgKCFvcGVuKSBzZXRTZWxlY3RlZChudWxsKTsgfX0+XG4gICAgICAgIDxEaWFsb2dDb250ZW50PlxuICAgICAgICAgIDxEaWFsb2dIZWFkZXI+XG4gICAgICAgICAgICA8RGlhbG9nVGl0bGU+QWNjZXB0IGNhbmRpZGF0ZToge3NlbGVjdGVkPy5wYXR0ZXJufTwvRGlhbG9nVGl0bGU+XG4gICAgICAgICAgICA8RGlhbG9nRGVzY3JpcHRpb24+VGhpcyBjcmVhdGVzIGEgZGlzYWJsZWQgTEVWRUxfMSBBdXRvbWF0aW9uIERlZmluaXRpb24uIEl0IGRvZXMgbm90IGFjdGl2YXRlLCBhcHByb3ZlLCBvciBkaXNwYXRjaCB3b3JrLjwvRGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgICAgPC9EaWFsb2dIZWFkZXI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLW11dGVkLzIwIHAtMyB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAge3NlbGVjdGVkPy5vY2N1cnJlbmNlc30gb2NjdXJyZW5jZXMgwrcge3NlbGVjdGVkPy5yZWNlaXB0Q291bnR9IHJlY2VpcHRzIMK3IHtzZWxlY3RlZD8ud29ya2Zsb3dJZH1AY3VycmVudFxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cImNhbmRpZGF0ZS1kZWNpc2lvbi1yZWFzb25cIj5BY2NlcHRhbmNlIHJlYXNvbjwvTGFiZWw+XG4gICAgICAgICAgICA8VGV4dGFyZWEgaWQ9XCJjYW5kaWRhdGUtZGVjaXNpb24tcmVhc29uXCIgdmFsdWU9e3JlYXNvbn0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0UmVhc29uKGV2ZW50LnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiV2h5IHNob3VsZCB0aGlzIHBhdHRlcm4gYmVjb21lIGEgZ292ZXJuZWQgZGVmaW5pdGlvbj9cIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxEaWFsb2dGb290ZXI+XG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWQobnVsbCl9PkNhbmNlbDwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvbiBkaXNhYmxlZD17YnVzeSB8fCByZWFzb24udHJpbSgpLmxlbmd0aCA8IDV9IG9uQ2xpY2s9eygpID0+IHZvaWQgY29uZmlybSgpfT57YnVzeSA/IFwiQ3JlYXRpbmfigKZcIiA6IFwiQ3JlYXRlIGRpc2FibGVkIGRlZmluaXRpb25cIn08L0J1dHRvbj5cbiAgICAgICAgICA8L0RpYWxvZ0Zvb3Rlcj5cbiAgICAgICAgPC9EaWFsb2dDb250ZW50PlxuICAgICAgPC9EaWFsb2c+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9hdXRvbWF0aW9ucy9BdXRvbWF0aW9uQ2FuZGlkYXRlcy50c3gifQ==