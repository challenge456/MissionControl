import {
  require_react
} from "/node_modules/.vite/deps/chunk-GMP6FTHE.js?v=738cb978";
import "/node_modules/.vite/deps/chunk-G3PMV62Z.js?v=738cb978";
export default require_react();
//# sourceMappingURL=react.js.map
