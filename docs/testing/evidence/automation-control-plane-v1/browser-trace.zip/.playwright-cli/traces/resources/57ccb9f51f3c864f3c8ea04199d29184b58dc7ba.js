import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/operator/TurnCard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/TurnCard.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { cn } from "/src/lib/utils.ts";
import { ToolCallRow } from "/src/components/operator/ToolCallRow.tsx";
import { formatMoney, formatSeconds } from "/src/lib/schematicFormatters.ts";
function GateBadge({ gate }) {
  const retrieve = gate.decision.toLowerCase().includes("retrieve");
  return /* @__PURE__ */ jsxDEV("div", { className: "mt-1 flex flex-wrap items-center gap-2", children: [
    /* @__PURE__ */ jsxDEV(
      "span",
      {
        className: cn(
          "schematic-badge",
          retrieve && "schematic-badge-retrieve"
        ),
        children: [
          "gate · ",
          gate.decision
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/TurnCard.tsx",
        lineNumber: 51,
        columnNumber: 7
      },
      this
    ),
    gate.reason ? /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-[11.5px] text-ink-muted", children: gate.reason }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/TurnCard.tsx",
      lineNumber: 60,
      columnNumber: 7
    }, this) : null
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/TurnCard.tsx",
    lineNumber: 50,
    columnNumber: 5
  }, this);
}
_c = GateBadge;
export function TurnCard({ turn, className }) {
  if (turn.historical) {
    return /* @__PURE__ */ jsxDEV("div", { className: cn("schematic-card", className), children: /* @__PURE__ */ jsxDEV("div", { className: "schematic-reply whitespace-pre-wrap", children: turn.reply }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/TurnCard.tsx",
      lineNumber: 71,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/TurnCard.tsx",
      lineNumber: 70,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: cn("schematic-card", className), children: [
    turn.userMessage ? /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-ink", children: turn.userMessage }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/TurnCard.tsx",
      lineNumber: 79,
      columnNumber: 7
    }, this) : null,
    turn.gate ? /* @__PURE__ */ jsxDEV(GateBadge, { gate: turn.gate }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/TurnCard.tsx",
      lineNumber: 81,
      columnNumber: 20
    }, this) : null,
    (turn.tools ?? []).map(
      (t, i) => /* @__PURE__ */ jsxDEV(ToolCallRow, { call: t }, `${t.tool}-${i}`, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/TurnCard.tsx",
        lineNumber: 83,
        columnNumber: 7
      }, this)
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "schematic-reply mt-1.5 whitespace-pre-wrap", children: turn.reply }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/TurnCard.tsx",
      lineNumber: 85,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "schematic-meta mt-2", children: [
      turn.timestamp ? `${turn.timestamp} · ` : "",
      formatSeconds(turn.latencyMs),
      " · ",
      turn.iterations ?? "?",
      " iter",
      turn.cost != null ? ` · ${formatMoney(turn.cost)}` : "",
      turn.model ? ` · ${turn.model}` : ""
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/TurnCard.tsx",
      lineNumber: 86,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/TurnCard.tsx",
    lineNumber: 77,
    columnNumber: 5
  }, this);
}
_c2 = TurnCard;
var _c, _c2;
$RefreshReg$(_c, "GateBadge");
$RefreshReg$(_c2, "TurnCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/TurnCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/operator/TurnCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JNOzs7Ozs7Ozs7Ozs7Ozs7O0FBL0JOLFNBQVNBLFVBQVU7QUFDbkIsU0FBU0MsbUJBQXNDO0FBQy9DLFNBQVNDLGFBQWFDLHFCQUFxQjtBQXlCM0MsU0FBU0MsVUFBVSxFQUFFQyxLQUE2QixHQUFnQjtBQUNoRSxRQUFNQyxXQUFXRCxLQUFLRSxTQUFTQyxZQUFZLEVBQUVDLFNBQVMsVUFBVTtBQUNoRSxTQUNFLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXVDtBQUFBQSxVQUNUO0FBQUEsVUFDQU0sWUFBWTtBQUFBLFFBQ2Q7QUFBQSxRQUFFO0FBQUE7QUFBQSxVQUVNRCxLQUFLRTtBQUFBQTtBQUFBQTtBQUFBQSxNQU5mO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9BO0FBQUEsSUFDQ0YsS0FBS0ssU0FDSix1QkFBQyxVQUFLLFdBQVUsMENBQTBDTCxlQUFLSyxVQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNFLElBQ3BFO0FBQUEsT0FYTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBWUE7QUFFSjtBQUVBQyxLQW5CU1A7QUFvQkYsZ0JBQVNRLFNBQVMsRUFBRUMsTUFBTUMsVUFBeUIsR0FBZ0I7QUFDeEUsTUFBSUQsS0FBS0UsWUFBWTtBQUNuQixXQUNFLHVCQUFDLFNBQUksV0FBV2YsR0FBRyxrQkFBa0JjLFNBQVMsR0FDNUMsaUNBQUMsU0FBSSxXQUFVLHVDQUF1Q0QsZUFBS0csU0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpRSxLQURuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVdoQixHQUFHLGtCQUFrQmMsU0FBUyxHQUMzQ0Q7QUFBQUEsU0FBS0ksY0FDSix1QkFBQyxTQUFJLFdBQVUsMEJBQTBCSixlQUFLSSxlQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBELElBQ3hEO0FBQUEsSUFDSEosS0FBS1IsT0FBTyx1QkFBQyxhQUFVLE1BQU1RLEtBQUtSLFFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkIsSUFBTTtBQUFBLEtBQzVDUSxLQUFLSyxTQUFTLElBQUlDO0FBQUFBLE1BQUksQ0FBQ0MsR0FBR0MsTUFDMUIsdUJBQUMsZUFBbUMsTUFBTUQsS0FBeEIsR0FBR0EsRUFBRUUsSUFBSSxJQUFJRCxDQUFDLElBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEM7QUFBQSxJQUM3QztBQUFBLElBQ0QsdUJBQUMsU0FBSSxXQUFVLDhDQUE4Q1IsZUFBS0csU0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RTtBQUFBLElBQ3hFLHVCQUFDLFNBQUksV0FBVSx1QkFDWkg7QUFBQUEsV0FBS1UsWUFBWSxHQUFHVixLQUFLVSxTQUFTLFFBQVE7QUFBQSxNQUMxQ3BCLGNBQWNVLEtBQUtXLFNBQVM7QUFBQSxNQUFFO0FBQUEsTUFBSVgsS0FBS1ksY0FBYztBQUFBLE1BQUk7QUFBQSxNQUN6RFosS0FBS2EsUUFBUSxPQUFPLE1BQU14QixZQUFZVyxLQUFLYSxJQUFJLENBQUMsS0FBSztBQUFBLE1BQ3JEYixLQUFLYyxRQUFRLE1BQU1kLEtBQUtjLEtBQUssS0FBSztBQUFBLFNBSnJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLE9BZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWVBO0FBRUo7QUFBQ0MsTUEzQmVoQjtBQUFRLElBQUFELElBQUFpQjtBQUFBLGFBQUFqQixJQUFBO0FBQUEsYUFBQWlCLEtBQUEiLCJuYW1lcyI6WyJjbiIsIlRvb2xDYWxsUm93IiwiZm9ybWF0TW9uZXkiLCJmb3JtYXRTZWNvbmRzIiwiR2F0ZUJhZGdlIiwiZ2F0ZSIsInJldHJpZXZlIiwiZGVjaXNpb24iLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwicmVhc29uIiwiX2MiLCJUdXJuQ2FyZCIsInR1cm4iLCJjbGFzc05hbWUiLCJoaXN0b3JpY2FsIiwicmVwbHkiLCJ1c2VyTWVzc2FnZSIsInRvb2xzIiwibWFwIiwidCIsImkiLCJ0b29sIiwidGltZXN0YW1wIiwibGF0ZW5jeU1zIiwiaXRlcmF0aW9ucyIsImNvc3QiLCJtb2RlbCIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUdXJuQ2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcbmltcG9ydCB7IFRvb2xDYWxsUm93LCB0eXBlIFRvb2xDYWxsRGF0YSB9IGZyb20gXCIuL1Rvb2xDYWxsUm93XCI7XG5pbXBvcnQgeyBmb3JtYXRNb25leSwgZm9ybWF0U2Vjb25kcyB9IGZyb20gXCJAL2xpYi9zY2hlbWF0aWNGb3JtYXR0ZXJzXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgR2F0ZURlY2lzaW9uIHtcbiAgZGVjaXNpb246IHN0cmluZztcbiAgcmVhc29uPzogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFR1cm5DYXJkRGF0YSB7XG4gIHVzZXJNZXNzYWdlPzogc3RyaW5nO1xuICByZXBseTogc3RyaW5nO1xuICBnYXRlPzogR2F0ZURlY2lzaW9uO1xuICB0b29scz86IFRvb2xDYWxsRGF0YVtdO1xuICB0aW1lc3RhbXA/OiBzdHJpbmc7XG4gIGxhdGVuY3lNcz86IG51bWJlciB8IG51bGw7XG4gIGl0ZXJhdGlvbnM/OiBudW1iZXI7XG4gIGNvc3Q/OiBudW1iZXI7XG4gIG1vZGVsPzogc3RyaW5nO1xuICBoaXN0b3JpY2FsPzogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBUdXJuQ2FyZFByb3BzIHtcbiAgdHVybjogVHVybkNhcmREYXRhO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59XG5cbmZ1bmN0aW9uIEdhdGVCYWRnZSh7IGdhdGUgfTogeyBnYXRlOiBHYXRlRGVjaXNpb24gfSk6IEpTWC5FbGVtZW50IHtcbiAgY29uc3QgcmV0cmlldmUgPSBnYXRlLmRlY2lzaW9uLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoXCJyZXRyaWV2ZVwiKTtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICA8c3BhblxuICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgIFwic2NoZW1hdGljLWJhZGdlXCIsXG4gICAgICAgICAgcmV0cmlldmUgJiYgXCJzY2hlbWF0aWMtYmFkZ2UtcmV0cmlldmVcIlxuICAgICAgICApfVxuICAgICAgPlxuICAgICAgICBnYXRlIMK3IHtnYXRlLmRlY2lzaW9ufVxuICAgICAgPC9zcGFuPlxuICAgICAge2dhdGUucmVhc29uID8gKFxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1bMTEuNXB4XSB0ZXh0LWluay1tdXRlZFwiPntnYXRlLnJlYXNvbn08L3NwYW4+XG4gICAgICApIDogbnVsbH1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuLyoqIENvbXBsZXRlZCB0dXJuIGNhcmQgZm9yIExvb3AgLyBPdmVydmlldyAod2FrdSB0dXJuQ2FyZCkuICovXG5leHBvcnQgZnVuY3Rpb24gVHVybkNhcmQoeyB0dXJuLCBjbGFzc05hbWUgfTogVHVybkNhcmRQcm9wcyk6IEpTWC5FbGVtZW50IHtcbiAgaWYgKHR1cm4uaGlzdG9yaWNhbCkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17Y24oXCJzY2hlbWF0aWMtY2FyZFwiLCBjbGFzc05hbWUpfT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzY2hlbWF0aWMtcmVwbHkgd2hpdGVzcGFjZS1wcmUtd3JhcFwiPnt0dXJuLnJlcGx5fTwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2NuKFwic2NoZW1hdGljLWNhcmRcIiwgY2xhc3NOYW1lKX0+XG4gICAgICB7dHVybi51c2VyTWVzc2FnZSA/IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtaW5rXCI+e3R1cm4udXNlck1lc3NhZ2V9PC9kaXY+XG4gICAgICApIDogbnVsbH1cbiAgICAgIHt0dXJuLmdhdGUgPyA8R2F0ZUJhZGdlIGdhdGU9e3R1cm4uZ2F0ZX0gLz4gOiBudWxsfVxuICAgICAgeyh0dXJuLnRvb2xzID8/IFtdKS5tYXAoKHQsIGkpID0+IChcbiAgICAgICAgPFRvb2xDYWxsUm93IGtleT17YCR7dC50b29sfS0ke2l9YH0gY2FsbD17dH0gLz5cbiAgICAgICkpfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzY2hlbWF0aWMtcmVwbHkgbXQtMS41IHdoaXRlc3BhY2UtcHJlLXdyYXBcIj57dHVybi5yZXBseX08L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2NoZW1hdGljLW1ldGEgbXQtMlwiPlxuICAgICAgICB7dHVybi50aW1lc3RhbXAgPyBgJHt0dXJuLnRpbWVzdGFtcH0gwrcgYCA6IFwiXCJ9XG4gICAgICAgIHtmb3JtYXRTZWNvbmRzKHR1cm4ubGF0ZW5jeU1zKX0gwrcge3R1cm4uaXRlcmF0aW9ucyA/PyBcIj9cIn0gaXRlclxuICAgICAgICB7dHVybi5jb3N0ICE9IG51bGwgPyBgIMK3ICR7Zm9ybWF0TW9uZXkodHVybi5jb3N0KX1gIDogXCJcIn1cbiAgICAgICAge3R1cm4ubW9kZWwgPyBgIMK3ICR7dHVybi5tb2RlbH1gIDogXCJcIn1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvY29tcG9uZW50cy9vcGVyYXRvci9UdXJuQ2FyZC50c3gifQ==