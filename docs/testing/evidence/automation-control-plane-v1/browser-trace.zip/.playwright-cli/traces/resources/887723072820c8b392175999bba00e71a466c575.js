import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const lazy = __vite__cjsImport3_react["lazy"]; const Suspense = __vite__cjsImport3_react["Suspense"];
import { useMutation, useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { AnimatePresence, motion } from "/node_modules/.vite/deps/framer-motion.js?v=1645aaff";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { CommandNav } from "/src/components/CommandNav.tsx";
import { TabBar } from "/src/components/TabBar.tsx";
import { AppTopBar } from "/src/components/AppTopBar.tsx";
import { SIDEBAR_WIDTH } from "/src/Sidebar.tsx";
import { SearchBar } from "/src/SearchBar.tsx";
import { useToast } from "/src/Toast.tsx";
import { useKeyboardShortcuts } from "/src/KeyboardShortcuts.tsx";
import { useModalState } from "/src/hooks/useModalState.ts";
import { PrivacyProvider } from "/src/contexts/PrivacyContext.tsx";
import { useFlag } from "/src/hooks/useFlag.ts";
import { AppShellV2 } from "/src/shellV2/AppShellV2.tsx";
import { useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=83faf592";
import {
  WorkspaceScopeProvider,
  useWorkspaceScope
} from "/src/workspace/WorkspaceScopeProvider.tsx";
const DashboardOverview = lazy(
  _c = () => import("/src/DashboardOverview.tsx").then((module) => ({ default: module.DashboardOverview }))
);
_c2 = DashboardOverview;
const TaskDrawerTabs = lazy(
  _c3 = () => import("/src/TaskDrawerTabs.tsx").then((module) => ({ default: module.TaskDrawerTabs }))
);
_c4 = TaskDrawerTabs;
const ModalLayer = lazy(
  _c5 = () => import("/src/ModalLayer.tsx").then((module) => ({ default: module.ModalLayer }))
);
_c6 = ModalLayer;
const OpsSection = lazy(
  _c7 = () => import("/src/sections/OpsSection.tsx?t=1785283753032").then((module) => ({ default: module.OpsSection }))
);
_c8 = OpsSection;
const AgentsSection = lazy(
  _c9 = () => import("/src/sections/AgentsSection.tsx").then((module) => ({ default: module.AgentsSection }))
);
_c0 = AgentsSection;
const ChatSection = lazy(
  _c1 = () => import("/src/sections/ChatSection.tsx").then((module) => ({ default: module.ChatSection }))
);
_c10 = ChatSection;
const ContentSection = lazy(
  _c11 = () => import("/src/sections/ContentSection.tsx").then((module) => ({ default: module.ContentSection }))
);
_c12 = ContentSection;
const CommsSection = lazy(
  _c13 = () => import("/src/sections/CommsSection.tsx").then((module) => ({ default: module.CommsSection }))
);
_c14 = CommsSection;
const KnowledgeSection = lazy(
  _c15 = () => import("/src/sections/KnowledgeSection.tsx").then((module) => ({ default: module.KnowledgeSection }))
);
_c16 = KnowledgeSection;
const CodeSection = lazy(
  _c17 = () => import("/src/sections/CodeSection.tsx").then((module) => ({ default: module.CodeSection }))
);
_c18 = CodeSection;
const QualitySection = lazy(
  _c19 = () => import("/src/sections/QualitySection.tsx").then((module) => ({ default: module.QualitySection }))
);
_c20 = QualitySection;
const PlatformSection = lazy(
  _c21 = () => import("/src/sections/PlatformSection.tsx").then((module) => ({ default: module.PlatformSection }))
);
_c22 = PlatformSection;
const HarnessSection = lazy(
  _c23 = () => import("/src/harness/HarnessSection.tsx").then((module) => ({ default: module.HarnessSection }))
);
_c24 = HarnessSection;
const ControlSection = lazy(
  _c25 = () => import("/src/sections/ControlSection.tsx").then((module) => ({ default: module.ControlSection }))
);
_c26 = ControlSection;
function ProjectSwitcher({
  onManage,
  showDetails = false
}) {
  _s();
  const projects = useQuery(api.projects.list);
  const { projectId, setProjectId, project } = useWorkspaceScope();
  if (!projects) {
    return /* @__PURE__ */ jsxDEV("div", { className: "h-8 min-w-[140px] rounded-md border border-input bg-secondary/50 px-3 text-sm text-muted-foreground flex items-center", children: "Loading projects..." }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
      lineNumber: 113,
      columnNumber: 7
    }, this);
  }
  const availableProjects = projects.filter((item) => item.status !== "ARCHIVED");
  const repositoryStatus = project?.repositoryStatus ?? (project?.githubRepo ? "CONFIGURED" : "UNCONFIGURED");
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
    /* @__PURE__ */ jsxDEV(
      "select",
      {
        "aria-label": "Workspace",
        value: projectId ?? "",
        onChange: (e) => {
          const value = e.target.value;
          if (value) setProjectId(value);
        },
        className: "h-9 min-w-[168px] rounded-lg border border-line bg-surface-1 px-3 text-[13.5px] font-medium text-ink transition-colors duration-150 cursor-pointer hover:border-line-strong focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
        children: [
          /* @__PURE__ */ jsxDEV("option", { value: "", disabled: true, children: availableProjects.length === 0 ? "No workspaces" : "Select workspace" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 134,
            columnNumber: 9
          }, this),
          availableProjects.map(
            (p) => /* @__PURE__ */ jsxDEV("option", { value: p._id, children: p.name }, p._id, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
              lineNumber: 138,
              columnNumber: 9
            }, this)
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
        lineNumber: 125,
        columnNumber: 7
      },
      this
    ),
    showDetails ? /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-line bg-surface-2 px-2.5 py-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "truncate font-mono text-[10.5px] text-ink-secondary", children: project?.githubRepo ?? "No repository connected" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
        lineNumber: 145,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-1 flex items-center justify-between gap-2 text-[10px] text-ink-muted", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "truncate", children: project?.githubRepo ? `${project.githubBranch || "main"} · ${repositoryStatus.toLowerCase()}` : "Setup required" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
          lineNumber: 149,
          columnNumber: 13
        }, this),
        onManage ? /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: onManage,
            className: "shrink-0 font-medium text-ink-secondary hover:text-ink",
            children: "Manage"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 155,
            columnNumber: 11
          },
          this
        ) : null
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
        lineNumber: 148,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
      lineNumber: 144,
      columnNumber: 7
    }, this) : null
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
    lineNumber: 124,
    columnNumber: 5
  }, this);
}
_s(ProjectSwitcher, "I6ZsQ1tEqnFrh9PN3AB5sgeklms=", false, function() {
  return [useQuery, useWorkspaceScope];
});
_c27 = ProjectSwitcher;
const STORAGE_KEY_VIEW = "mc.last_view";
const STORAGE_KEY_PROJECT = "mc.last_project";
function readRequestedProjectId() {
  if (typeof window === "undefined") return null;
  try {
    const fromUrl = new URL(window.location.href).searchParams.get("workspace");
    if (fromUrl) return fromUrl;
    const persisted = window.localStorage.getItem(STORAGE_KEY_PROJECT);
    return persisted ? persisted : null;
  } catch {
    return null;
  }
}
const VALID_MAIN_VIEWS = [
  "home",
  "atc",
  "tasks",
  "agents",
  "directory",
  "policies",
  "deployments",
  "audit",
  "telemetry",
  "automations",
  "automation-runs",
  "dag",
  "chat",
  "council",
  "calendar",
  "projects",
  "model-routing",
  "memory",
  "captures",
  "docs",
  "skills",
  "people",
  "org",
  "design-system",
  "office",
  "live-office",
  "search",
  "identity",
  "telegraph",
  "meetings",
  "voice",
  "content-pipeline",
  "crm",
  "command",
  "code",
  "recorder",
  "test-generation",
  "api-import",
  "execution",
  "flaky-steps",
  "hybrid-workflows",
  "schedule",
  "codegen",
  "gherkin",
  "metrics",
  "qc-dashboard",
  "qc-runs",
  "qc-environments",
  "qc-findings",
  "qc-metrics",
  "qc-rulesets",
  "gateway",
  "live-chat",
  "schedules",
  "hiring",
  "team",
  "system",
  "radar",
  "factory",
  "pipeline",
  "feedback",
  "ops-schedule",
  "goals",
  "analytics",
  "command-center",
  "missions",
  "mission-detail",
  "trace-inspector",
  "effectiveness",
  "factory-health",
  "readiness",
  "friction",
  "agent-catalog",
  "dossier",
  "recommendations",
  "control-portfolio",
  "control-work-orders",
  "control-fleet",
  "control-approvals",
  "harness-health",
  "harness-loops",
  "harness-control-plane",
  "harness-work-ledger",
  "harness-verifiers",
  "harness-change-review",
  "harness-change-risk",
  "harness-launch",
  "harness-meta-loop",
  "harness-team-pulse",
  "harness-builder",
  "harness-maintenance",
  "harness-code-review-wizard",
  "harness-workshop",
  "harness-automations",
  "harness-agent-fleet",
  "harness-software-factory",
  "harness-architect",
  "harness-patterns",
  "registry-lifecycle",
  "registry-evaluate",
  "registry-inventory",
  "registry-installations",
  "registry-runs"
];
function readPersistedView() {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY_VIEW);
    if (!raw) return null;
    const view = raw;
    return VALID_MAIN_VIEWS.includes(view) ? view : null;
  } catch {
    return null;
  }
}
const SECTION_DEFAULT_VIEW = {
  home: "home",
  control: "harness-health",
  ops: "tasks",
  agents: "agents",
  chat: "chat",
  content: "content-pipeline",
  comms: "telegraph",
  knowledge: "docs",
  code: "code",
  quality: "qc-dashboard",
  platform: "system"
};
const SECTION_TABS = {
  home: null,
  control: [
    { id: "control-portfolio", label: "Portfolio" },
    { id: "control-work-orders", label: "Work Orders" },
    { id: "control-fleet", label: "Fleet" },
    { id: "control-approvals", label: "Approvals" }
  ],
  ops: [
    { id: "tasks", label: "Tasks" },
    { id: "goals", label: "Goals" },
    { id: "dag", label: "DAG" },
    { id: "calendar", label: "Calendar" },
    { id: "ops-schedule", label: "Schedule" },
    { id: "audit", label: "Audit" },
    { id: "telemetry", label: "Telemetry" },
    { id: "automations", label: "Automations" }
  ],
  agents: [
    { id: "atc", label: "ATC" },
    { id: "agents", label: "Registry" },
    { id: "directory", label: "Templates" },
    { id: "identity", label: "Identities" },
    { id: "policies", label: "Policies" },
    { id: "deployments", label: "Deployments" },
    { id: "gateway", label: "Gateway" },
    { id: "schedules", label: "Schedules" }
  ],
  chat: [
    { id: "chat", label: "Chat" },
    { id: "live-chat", label: "Live" },
    { id: "council", label: "Council" },
    { id: "command", label: "Command" }
  ],
  content: [
    { id: "content-pipeline", label: "Pipeline" },
    { id: "captures", label: "Captures" },
    { id: "projects", label: "Projects" }
  ],
  comms: [
    { id: "telegraph", label: "Telegraph" },
    { id: "meetings", label: "Meetings" },
    { id: "voice", label: "Voice" },
    { id: "crm", label: "CRM" },
    { id: "people", label: "People" },
    { id: "team", label: "Team" },
    { id: "org", label: "Org Chart" },
    { id: "office", label: "Office" },
    { id: "live-office", label: "Live Office" },
    { id: "hiring", label: "Hiring" }
  ],
  knowledge: [
    { id: "docs", label: "Knowledge" },
    { id: "design-system", label: "Design DNA" },
    { id: "skills", label: "Discover skills" },
    { id: "memory", label: "Memory" },
    { id: "search", label: "Search" }
  ],
  code: [
    { id: "code", label: "Pipeline" },
    { id: "recorder", label: "Recorder" },
    { id: "test-generation", label: "Tests" },
    { id: "api-import", label: "API Import" },
    { id: "execution", label: "Execution" },
    { id: "flaky-steps", label: "Flaky" },
    { id: "hybrid-workflows", label: "Hybrid" },
    { id: "schedule", label: "Schedule" },
    { id: "codegen", label: "CodeGen" },
    { id: "gherkin", label: "Gherkin" },
    { id: "metrics", label: "Metrics" }
  ],
  quality: [
    { id: "qc-dashboard", label: "Dashboard" },
    { id: "qc-runs", label: "Runs" },
    { id: "qc-environments", label: "Environments" },
    { id: "qc-findings", label: "Findings" },
    { id: "qc-metrics", label: "Metrics" },
    { id: "qc-rulesets", label: "Rulesets" }
  ],
  platform: [
    { id: "system", label: "Database" },
    { id: "radar", label: "Radar" },
    { id: "factory", label: "Factory" },
    { id: "pipeline", label: "Build Pipeline" },
    { id: "feedback", label: "Feedback" },
    { id: "analytics", label: "Analytics" }
  ]
};
function viewToSection(view) {
  if (view === "home") return "home";
  if ([
    "control-portfolio",
    "control-work-orders",
    "control-fleet",
    "control-approvals"
  ].includes(view)) {
    return "control";
  }
  if ([
    "harness-health",
    "harness-loops",
    "harness-control-plane",
    "harness-work-ledger",
    "harness-team-pulse",
    "harness-meta-loop",
    "harness-builder",
    "harness-verifiers",
    "harness-change-review",
    "harness-change-risk",
    "harness-launch",
    "harness-maintenance",
    "harness-code-review-wizard",
    "harness-workshop",
    "harness-automations",
    "harness-agent-fleet",
    "harness-software-factory",
    "harness-architect",
    "harness-patterns"
  ].includes(view)) {
    return "control";
  }
  if (["tasks", "goals", "dag", "calendar", "ops-schedule", "audit", "telemetry", "automations", "automation-runs"].includes(view)) return "ops";
  if (["atc", "agents", "directory", "identity", "policies", "deployments", "gateway", "schedules"].includes(view)) return "agents";
  if (["chat", "live-chat", "council", "command"].includes(view)) return "chat";
  if (["captures", "projects", "content-pipeline"].includes(view)) return "content";
  if (["qc-dashboard", "qc-runs", "qc-environments", "qc-findings", "qc-metrics", "qc-rulesets"].includes(view)) return "quality";
  if (["telegraph", "meetings", "voice", "people", "org", "office", "live-office", "crm", "hiring", "team"].includes(view)) return "comms";
  if ([
    "docs",
    "design-system",
    "skills",
    "registry-lifecycle",
    "registry-evaluate",
    "registry-inventory",
    "registry-installations",
    "registry-runs",
    "search",
    "memory"
  ].includes(view))
    return "knowledge";
  if (["system", "radar", "factory", "pipeline", "feedback", "analytics", "model-routing", "command-center", "missions", "mission-detail", "trace-inspector", "effectiveness", "factory-health", "readiness", "friction", "agent-catalog", "dossier", "recommendations"].includes(view)) return "platform";
  if ([
    "code",
    "recorder",
    "test-generation",
    "api-import",
    "execution",
    "flaky-steps",
    "hybrid-workflows",
    "schedule",
    "codegen",
    "gherkin",
    "metrics"
  ].includes(view)) return "code";
  return "home";
}
function useHeaderMetrics(projectId) {
  _s2();
  const agents = useQuery(api.agents.listAll, projectId ? { projectId } : "skip");
  const tasks = useQuery(api.tasks.listAll, projectId ? { projectId } : "skip");
  const [statusTick, setStatusTick] = useState(() => Date.now());
  const activeCount = agents?.filter((a) => a.status === "ACTIVE").length ?? 0;
  const taskCount = tasks?.length ?? 0;
  useEffect(() => {
    const timer = window.setInterval(() => {
      setStatusTick(Date.now());
    }, 15e3);
    return () => window.clearInterval(timer);
  }, []);
  const aiStatus = useMemo(() => {
    if (!agents || agents.length === 0) {
      return {
        tone: "offline",
        label: "No active fleet",
        detail: "Register or resume an agent to bring Mission Control online.",
        lastSeenLabel: "No heartbeat",
        agentId: null,
        taskId: null
      };
    }
    const taskTitleById = new Map(tasks?.map((task) => [task._id, task.title]) ?? []);
    const freshestAgent = [...agents].sort((left, right) => {
      const leftStamp = left.lastHeartbeatAt ?? 0;
      const rightStamp = right.lastHeartbeatAt ?? 0;
      return rightStamp - leftStamp;
    })[0];
    const lastHeartbeatAt = freshestAgent?.lastHeartbeatAt ?? null;
    const ageMs = lastHeartbeatAt ? statusTick - lastHeartbeatAt : Number.POSITIVE_INFINITY;
    const taskTitle = freshestAgent?.currentTaskId ? taskTitleById.get(freshestAgent.currentTaskId) ?? "active task" : null;
    const lastSeenLabel = !lastHeartbeatAt ? "No signal" : ageMs < 6e4 ? "Live now" : ageMs < 36e5 ? `Last signal ${Math.floor(ageMs / 6e4)}m ago` : ageMs < 864e5 ? `Last signal ${Math.floor(ageMs / 36e5)}h ago` : `Last signal ${Math.floor(ageMs / 864e5)}d ago`;
    if (!freshestAgent || freshestAgent.status === "OFFLINE") {
      return {
        tone: "offline",
        label: "Fleet offline",
        detail: "No agents are currently reporting into Mission Control.",
        lastSeenLabel,
        agentId: freshestAgent?._id ?? null,
        taskId: freshestAgent?.currentTaskId ?? null
      };
    }
    if (freshestAgent.status === "PAUSED") {
      return {
        tone: "idle",
        label: "Paused by operator",
        detail: `${freshestAgent.name} is standing by until work resumes.`,
        lastSeenLabel,
        agentId: freshestAgent._id,
        taskId: freshestAgent.currentTaskId ?? null
      };
    }
    if (freshestAgent.status === "QUARANTINED" || freshestAgent.status === "DRAINED") {
      return {
        tone: "thinking",
        label: "Needs operator review",
        detail: `${freshestAgent.name} is ${freshestAgent.status.toLowerCase()} and may need intervention.`,
        lastSeenLabel,
        agentId: freshestAgent._id,
        taskId: freshestAgent.currentTaskId ?? null
      };
    }
    if (ageMs <= 45e3) {
      return {
        tone: "active",
        label: taskTitle ? "Working now" : "Live and responding",
        detail: taskTitle ? `${freshestAgent.name} is working on ${taskTitle}.` : `${freshestAgent.name} is actively reporting heartbeat traffic.`,
        lastSeenLabel,
        agentId: freshestAgent._id,
        taskId: freshestAgent.currentTaskId ?? null
      };
    }
    if (ageMs <= 18e4) {
      return {
        tone: "thinking",
        label: taskTitle ? "Thinking through execution" : "Thinking",
        detail: taskTitle ? `${freshestAgent.name} last reported while working on ${taskTitle}.` : `${freshestAgent.name} is between updates but still warm.`,
        lastSeenLabel,
        agentId: freshestAgent._id,
        taskId: freshestAgent.currentTaskId ?? null
      };
    }
    if (ageMs > 216e5) {
      return {
        tone: "offline",
        label: "Stale signal",
        detail: `${freshestAgent.name} has not reported a trustworthy heartbeat recently. Inspect the fleet before relying on this state.`,
        lastSeenLabel,
        agentId: freshestAgent._id,
        taskId: freshestAgent.currentTaskId ?? null
      };
    }
    return {
      tone: "idle",
      label: "Ready for next assignment",
      detail: `${freshestAgent.name} is online but hasn’t reported activity recently.`,
      lastSeenLabel,
      agentId: freshestAgent._id,
      taskId: freshestAgent.currentTaskId ?? null
    };
  }, [agents, statusTick, tasks]);
  return { activeCount, taskCount, aiStatus };
}
_s2(useHeaderMetrics, "nzzznBeUC0rOe5znaeiG1+j0btQ=", false, function() {
  return [useQuery, useQuery];
});
function PageTransition({ children, viewKey }) {
  return /* @__PURE__ */ jsxDEV(AnimatePresence, { mode: "wait", children: /* @__PURE__ */ jsxDEV(
    motion.div,
    {
      initial: { opacity: 0, y: 6 },
      animate: { opacity: 1, y: 0 },
      exit: { opacity: 0, y: -6 },
      transition: { duration: 0.2, ease: "easeOut" },
      className: "flex flex-1 overflow-hidden",
      children
    },
    viewKey,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
      lineNumber: 536,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
    lineNumber: 535,
    columnNumber: 5
  }, this);
}
_c28 = PageTransition;
function SectionLoadingState() {
  return /* @__PURE__ */ jsxDEV("main", { className: "flex flex-1 overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-1 flex-col gap-4 p-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "h-16 rounded-xl border border-line animate-pulse bg-surface-2" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
      lineNumber: 554,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid flex-1 gap-4 lg:grid-cols-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-line animate-pulse bg-surface-2" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
        lineNumber: 556,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-line animate-pulse bg-surface-2 lg:col-span-2" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
        lineNumber: 557,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
      lineNumber: 555,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
    lineNumber: 553,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
    lineNumber: 552,
    columnNumber: 5
  }, this);
}
_c29 = SectionLoadingState;
export default function App() {
  _s3();
  const [searchParams, setSearchParams] = useSearchParams();
  const [currentView, setCurrentView] = useState(() => readPersistedView() ?? "home");
  const [requestedProjectId] = useState(readRequestedProjectId);
  const [projectId, setProjectId] = useState(null);
  const [selectedTaskId, setSelectedTaskId] = useState(null);
  const [selectedQcRunId, setSelectedQcRunId] = useState(null);
  const [sidebarSelectedAgentId, setSidebarSelectedAgentId] = useState(null);
  const [sidebarWidth, setSidebarWidth] = useState(SIDEBAR_WIDTH);
  const [liveFeedExpanded, setLiveFeedExpanded] = useState(() => {
    if (typeof window === "undefined") return false;
    return window.localStorage.getItem("mc.live_feed_expanded") === "1";
  });
  const [kanbanFilters, setKanbanFilters] = useState({ agents: [], priorities: [], types: [] });
  const { modals, open, close, closeAll } = useModalState();
  const activeSection = useMemo(() => viewToSection(currentView), [currentView]);
  const sectionTabs = SECTION_TABS[activeSection];
  const project = useQuery(api.projects.get, projectId ? { projectId } : "skip");
  const projects = useQuery(api.projects.list);
  const availableProjects = useMemo(
    () => projects?.filter((item) => item.status !== "ARCHIVED"),
    [projects]
  );
  const pendingApprovals = useQuery(
    api.approvals.listPending,
    projectId ? { projectId, limit: 10 } : "skip"
  );
  useEffect(() => {
    if (projects && availableProjects && availableProjects.length > 0 && (!projectId || !availableProjects.some((item) => item._id === projectId))) {
      const preferred = availableProjects.find((p) => p._id === projectId) ?? availableProjects.find((p) => p._id === requestedProjectId) ?? availableProjects.find((p) => p.name.trim().toLowerCase() === "mission control") ?? availableProjects.find((p) => p.name.toLowerCase().includes("mission control")) ?? availableProjects[0];
      setProjectId(preferred._id);
    } else if (availableProjects && availableProjects.length === 0 && projectId) {
      setProjectId(null);
    }
  }, [availableProjects, projectId, requestedProjectId]);
  useEffect(() => {
    if (!projectId || typeof window === "undefined") return;
    try {
      window.localStorage.setItem(STORAGE_KEY_PROJECT, projectId);
      if (searchParams.get("workspace") !== projectId) {
        setSearchParams((current) => {
          const next = new URLSearchParams(current);
          next.set("workspace", projectId);
          return next;
        }, { replace: true });
      }
    } catch {
    }
  }, [projectId, searchParams, setSearchParams]);
  useEffect(() => {
    setSelectedTaskId(null);
    setSelectedQcRunId(null);
    setSidebarSelectedAgentId(null);
    setKanbanFilters({ agents: [], priorities: [], types: [] });
    closeAll();
  }, [projectId, closeAll]);
  useEffect(() => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem("mc.live_feed_expanded", liveFeedExpanded ? "1" : "0");
    }
  }, [liveFeedExpanded]);
  useEffect(() => {
    if (typeof window !== "undefined") {
      try {
        window.localStorage.setItem(STORAGE_KEY_VIEW, currentView);
      } catch {
      }
    }
  }, [currentView]);
  useEffect(() => {
    if (currentView !== "tasks") setSidebarSelectedAgentId(null);
  }, [currentView]);
  useEffect(() => {
    if (!modals.pauseConfirm) return;
    const handler = (e) => {
      if (e.key === "Escape") close("pauseConfirm");
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [modals.pauseConfirm, close]);
  const pauseAll = useMutation(api.agents.pauseAll);
  const resumeAll = useMutation(api.agents.resumeAll);
  const { toast } = useToast();
  useKeyboardShortcuts({
    onNewTask: () => open("createTask"),
    onSearch: () => open("commandPalette"),
    onApprovals: () => open("approvals"),
    onAgents: () => {
      setSidebarSelectedAgentId(null);
      open("agentsFlyout");
    },
    onCostAnalytics: () => open("costAnalytics"),
    onGoToBoard: () => setCurrentView("tasks"),
    onShowHelp: () => open("keyboardHelp"),
    onMission: () => open("missionModal")
  });
  const handleConfirmPauseSquad = useCallback(async () => {
    close("pauseConfirm");
    if (!projectId) {
      toast("Select a workspace before pausing agents.", true);
      return;
    }
    try {
      const result = await pauseAll({
        projectId,
        reason: "Pause squad from Mission Control",
        userId: "operator"
      });
      toast(`Paused ${result.paused} agent(s)`);
    } catch (e) {
      toast(e instanceof Error ? e.message : "Pause failed", true);
    }
  }, [pauseAll, projectId, toast, close]);
  const handleResumeSquad = useCallback(async () => {
    if (!projectId) {
      toast("Select a workspace before resuming agents.", true);
      return;
    }
    try {
      const result = await resumeAll({
        projectId,
        reason: "Resume squad from Mission Control",
        userId: "operator"
      });
      toast(`Resumed ${result.resumed} agent(s)`);
    } catch (e) {
      toast(e instanceof Error ? e.message : "Resume failed", true);
    }
  }, [resumeAll, projectId, toast]);
  const handleSectionChange = useCallback((section) => {
    close("agentsFlyout");
    setSidebarSelectedAgentId(null);
    setCurrentView(SECTION_DEFAULT_VIEW[section]);
  }, [close]);
  const handleTabChange = useCallback((tabId) => {
    close("agentsFlyout");
    setSidebarSelectedAgentId(null);
    setCurrentView(tabId);
  }, [close]);
  const now = /* @__PURE__ */ new Date();
  const timeStr = now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const dateStr = now.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" }).toUpperCase();
  const { activeCount, taskCount, aiStatus } = useHeaderMetrics(projectId);
  function renderSection() {
    if (currentView !== "projects") {
      if (!projects || projectId && project === void 0) {
        return /* @__PURE__ */ jsxDEV(SectionLoadingState, {}, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
          lineNumber: 760,
          columnNumber: 16
        }, this);
      }
      if (availableProjects.length === 0) {
        return /* @__PURE__ */ jsxDEV("main", { className: "flex flex-1 items-center justify-center bg-app p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-md rounded-xl border border-line bg-surface-1 p-6 text-center", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-lg font-semibold text-ink", children: "Create a workspace" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 766,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-ink-secondary", children: "Work Orders, agents, runs, and evidence require an explicit workspace boundary." }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 767,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setCurrentView("projects"),
              className: "mt-4 h-9 rounded-lg bg-act px-3 text-[13px] font-medium text-act-ink",
              children: "Open workspace settings"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
              lineNumber: 770,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
          lineNumber: 765,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
          lineNumber: 764,
          columnNumber: 11
        }, this);
      }
      if (!projectId || !project) {
        return /* @__PURE__ */ jsxDEV(SectionLoadingState, {}, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
          lineNumber: 782,
          columnNumber: 16
        }, this);
      }
    }
    if ([
      "harness-health",
      "harness-loops",
      "harness-control-plane",
      "harness-work-ledger",
      "harness-verifiers",
      "harness-change-review",
      "harness-change-risk",
      "harness-launch",
      "harness-meta-loop",
      "harness-team-pulse",
      "harness-builder",
      "harness-maintenance",
      "harness-code-review-wizard",
      "harness-workshop",
      "harness-automations",
      "harness-agent-fleet",
      "harness-software-factory",
      "harness-architect",
      "harness-patterns"
    ].includes(currentView)) {
      return /* @__PURE__ */ jsxDEV(
        HarnessSection,
        {
          currentView,
          projectId,
          onNavigate: setCurrentView
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
          lineNumber: 810,
          columnNumber: 9
        },
        this
      );
    }
    switch (activeSection) {
      case "home":
        return /* @__PURE__ */ jsxDEV(
          DashboardOverview,
          {
            projectId,
            onClose: () => {
            },
            onOpenMissionModal: () => open("missionModal"),
            onOpenSuggestionsDrawer: () => open("suggestionsDrawer"),
            onNavigate: setCurrentView,
            onOpenApprovals: () => open("approvals"),
            onOpenCostAnalytics: () => open("costAnalytics"),
            onOpenAlertRules: () => open("alertRules"),
            onTaskSelect: setSelectedTaskId,
            onNavigateToGateway: () => {
              handleSectionChange("agents");
              handleTabChange("gateway");
            },
            onOpenCreateTask: () => open("createTask"),
            onSelectAgent: (id) => {
              setSidebarSelectedAgentId(id);
              open("agentsFlyout");
            }
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 821,
            columnNumber: 11
          },
          this
        );
      case "control":
        return /* @__PURE__ */ jsxDEV(
          ControlSection,
          {
            currentView,
            projectId,
            onNavigate: setCurrentView
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 844,
            columnNumber: 11
          },
          this
        );
      case "ops":
        return /* @__PURE__ */ jsxDEV(
          OpsSection,
          {
            currentView,
            projectId,
            taskCount,
            onTaskSelect: setSelectedTaskId,
            liveFeedExpanded,
            onToggleLiveFeed: () => setLiveFeedExpanded((v) => !v),
            kanbanFilters,
            onFiltersChange: setKanbanFilters,
            sidebarSelectedAgentId,
            onAgentSelect: setSidebarSelectedAgentId,
            onSidebarWidthChange: setSidebarWidth,
            onOpenApprovals: () => open("approvals"),
            onOpenPolicy: () => open("policy"),
            onOpenOperatorControls: () => open("operatorControls"),
            onOpenNotifications: () => open("notifications"),
            onOpenStandup: () => open("standup"),
            onPauseSquad: () => open("pauseConfirm"),
            onResumeSquad: handleResumeSquad,
            onOpenImportPrd: () => open("importPrd"),
            onNavigate: setCurrentView,
            onNewTask: () => open("createTask")
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 852,
            columnNumber: 11
          },
          this
        );
      case "agents":
        return /* @__PURE__ */ jsxDEV(
          AgentsSection,
          {
            currentView,
            projectId,
            onNavigateToIdentity: () => setCurrentView("identity"),
            onNavigateToTask: (taskId) => {
              setSelectedTaskId(taskId);
              setCurrentView("tasks");
            },
            onNavigateToTasks: () => setCurrentView("tasks"),
            onNavigateToAgent: (agentId) => {
              setSidebarSelectedAgentId(agentId);
              setCurrentView("agents");
            },
            onOpenCreateAgent: () => open("createAgent")
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 878,
            columnNumber: 11
          },
          this
        );
      case "chat":
        return /* @__PURE__ */ jsxDEV(
          ChatSection,
          {
            currentView,
            projectId,
            onOpenSuggestionsDrawer: () => open("suggestionsDrawer")
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 896,
            columnNumber: 11
          },
          this
        );
      case "content":
        return /* @__PURE__ */ jsxDEV(
          ContentSection,
          {
            currentView,
            projectId,
            onProjectSelect: setProjectId
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 904,
            columnNumber: 11
          },
          this
        );
      case "comms":
        return /* @__PURE__ */ jsxDEV(
          CommsSection,
          {
            currentView,
            projectId,
            onNavigate: setCurrentView
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 912,
            columnNumber: 11
          },
          this
        );
      case "knowledge":
        return /* @__PURE__ */ jsxDEV(
          KnowledgeSection,
          {
            currentView,
            projectId,
            onNavigate: setCurrentView,
            onTaskSelect: (taskId) => {
              setSelectedTaskId(taskId);
              setCurrentView("tasks");
            }
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 920,
            columnNumber: 11
          },
          this
        );
      case "code":
        return /* @__PURE__ */ jsxDEV(
          CodeSection,
          {
            currentView,
            projectId,
            onTaskSelect: (taskId) => {
              setSelectedTaskId(taskId);
              setCurrentView("tasks");
            }
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 932,
            columnNumber: 11
          },
          this
        );
      case "quality":
        return /* @__PURE__ */ jsxDEV(
          QualitySection,
          {
            currentView,
            projectId,
            selectedQcRunId,
            setSelectedQcRunId,
            onNavigate: setCurrentView,
            onOpenStartQcRun: () => open("startQcRun")
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 943,
            columnNumber: 11
          },
          this
        );
      case "platform":
        return /* @__PURE__ */ jsxDEV(
          PlatformSection,
          {
            currentView,
            projectId,
            onNavigate: setCurrentView,
            onOpenHealthDashboard: () => open("healthDashboard"),
            onOpenMonitoringDashboard: () => open("monitoringDashboard"),
            onTaskSelect: (taskId) => {
              setSelectedTaskId(taskId);
              setCurrentView("tasks");
            }
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 954,
            columnNumber: 11
          },
          this
        );
      default:
        return null;
    }
  }
  const legacyShell = useFlag("ui.shell.v1");
  if (!legacyShell) {
    return /* @__PURE__ */ jsxDEV(WorkspaceScopeProvider, { value: { projectId, setProjectId, project }, children: /* @__PURE__ */ jsxDEV(PrivacyProvider, { children: [
      /* @__PURE__ */ jsxDEV(
        AppShellV2,
        {
          activeView: currentView,
          onNavigate: setCurrentView,
          workspaceSwitcher: /* @__PURE__ */ jsxDEV(
            ProjectSwitcher,
            {
              showDetails: true,
              onManage: () => setCurrentView("projects")
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
              lineNumber: 984,
              columnNumber: 13
            },
            this
          ),
          onOpenSearch: () => open("commandPalette"),
          pendingApprovals: pendingApprovals?.length ?? 0,
          onOpenApprovals: () => open("approvals"),
          projectId,
          children: /* @__PURE__ */ jsxDEV(Suspense, { fallback: /* @__PURE__ */ jsxDEV(SectionLoadingState, {}, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 994,
            columnNumber: 33
          }, this), children: renderSection() }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 994,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
          lineNumber: 980,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Suspense, { fallback: null, children: /* @__PURE__ */ jsxDEV(TaskDrawerTabs, { taskId: selectedTaskId, onClose: () => setSelectedTaskId(null) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
        lineNumber: 997,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
        lineNumber: 996,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Suspense, { fallback: null, children: /* @__PURE__ */ jsxDEV(
        ModalLayer,
        {
          projectId,
          modals,
          open,
          close,
          selectedTaskId,
          setSelectedTaskId,
          sidebarSelectedAgentId,
          setSidebarSelectedAgentId,
          sidebarWidth,
          onNavigate: setCurrentView,
          onConfirmPauseSquad: handleConfirmPauseSquad,
          onResumeSquad: handleResumeSquad,
          onToast: toast,
          onNavigateToGateway: () => {
            handleSectionChange("agents");
            handleTabChange("gateway");
          }
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
          lineNumber: 1e3,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
        lineNumber: 999,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
      lineNumber: 979,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
      lineNumber: 978,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(WorkspaceScopeProvider, { value: { projectId, setProjectId, project }, children: /* @__PURE__ */ jsxDEV(PrivacyProvider, { children: /* @__PURE__ */ jsxDEV("div", { className: "flex h-screen flex-col bg-background text-foreground", children: [
    /* @__PURE__ */ jsxDEV(
      AppTopBar,
      {
        projectSwitcher: /* @__PURE__ */ jsxDEV(ProjectSwitcher, {}, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
          lineNumber: 1030,
          columnNumber: 30
        }, this),
        searchBar: /* @__PURE__ */ jsxDEV(
          SearchBar,
          {
            projectId: projectId ?? void 0,
            onResultClick: (taskId) => setSelectedTaskId(taskId)
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
            lineNumber: 1032,
            columnNumber: 13
          },
          this
        ),
        activeCount,
        taskCount,
        aiStatus,
        timeStr,
        dateStr,
        pendingApprovals: pendingApprovals?.length ?? 0,
        projectId,
        onNewTask: () => open("createTask"),
        onOpenControls: () => open("operatorControls"),
        onOpenCommandPalette: () => open("commandPalette"),
        onOpenCostAnalytics: () => open("costAnalytics"),
        onOpenBudgetBurnDown: () => open("budgetBurnDown"),
        onOpenAdvancedAnalytics: () => open("advancedAnalytics"),
        onOpenHealthDashboard: () => open("healthDashboard"),
        onOpenMonitoringDashboard: () => open("monitoringDashboard"),
        onOpenDashboardOverview: () => handleSectionChange("home"),
        onOpenActivityFeed: () => open("activityFeed"),
        onOpenKeyboardHelp: () => open("keyboardHelp"),
        onOpenApprovals: () => open("approvals"),
        onOpenNotifications: () => open("notifications"),
        onOpenAgentsFlyout: () => {
          setSidebarSelectedAgentId(null);
          open("agentsFlyout");
        },
        onOpenAiStatus: () => {
          if (aiStatus.taskId) {
            setSelectedTaskId(aiStatus.taskId);
            setCurrentView("tasks");
            return;
          }
          setCurrentView("agents");
        },
        onOpenMissionModal: () => open("missionModal"),
        onOpenSuggestionsDrawer: () => open("suggestionsDrawer")
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
        lineNumber: 1029,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(CommandNav, { activeSection, onSectionChange: handleSectionChange }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
      lineNumber: 1070,
      columnNumber: 9
    }, this),
    sectionTabs && /* @__PURE__ */ jsxDEV(TabBar, { tabs: sectionTabs, activeTab: currentView, onTabChange: handleTabChange }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
      lineNumber: 1073,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-1 overflow-hidden", children: /* @__PURE__ */ jsxDEV(PageTransition, { viewKey: currentView, children: /* @__PURE__ */ jsxDEV(Suspense, { fallback: /* @__PURE__ */ jsxDEV(SectionLoadingState, {}, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
      lineNumber: 1078,
      columnNumber: 33
    }, this), children: renderSection() }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
      lineNumber: 1078,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
      lineNumber: 1077,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
      lineNumber: 1076,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Suspense, { fallback: null, children: /* @__PURE__ */ jsxDEV(TaskDrawerTabs, { taskId: selectedTaskId, onClose: () => setSelectedTaskId(null) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
      lineNumber: 1085,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
      lineNumber: 1084,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Suspense, { fallback: null, children: /* @__PURE__ */ jsxDEV(
      ModalLayer,
      {
        projectId,
        modals,
        open,
        close,
        selectedTaskId,
        setSelectedTaskId,
        sidebarSelectedAgentId,
        setSidebarSelectedAgentId,
        sidebarWidth,
        onNavigate: setCurrentView,
        onConfirmPauseSquad: handleConfirmPauseSquad,
        onResumeSquad: handleResumeSquad,
        onToast: toast,
        onNavigateToGateway: () => {
          handleSectionChange("agents");
          handleTabChange("gateway");
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
        lineNumber: 1089,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
      lineNumber: 1088,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
    lineNumber: 1028,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
    lineNumber: 1027,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx",
    lineNumber: 1026,
    columnNumber: 5
  }, this);
}
_s3(App, "6qPEOO2unb4ETujVNDSAo4cHmss=", false, function() {
  return [useSearchParams, useModalState, useQuery, useQuery, useQuery, useMutation, useMutation, useToast, useKeyboardShortcuts, useHeaderMetrics, useFlag];
});
_c30 = App;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0, _c1, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17, _c18, _c19, _c20, _c21, _c22, _c23, _c24, _c25, _c26, _c27, _c28, _c29, _c30;
$RefreshReg$(_c, "DashboardOverview$lazy");
$RefreshReg$(_c2, "DashboardOverview");
$RefreshReg$(_c3, "TaskDrawerTabs$lazy");
$RefreshReg$(_c4, "TaskDrawerTabs");
$RefreshReg$(_c5, "ModalLayer$lazy");
$RefreshReg$(_c6, "ModalLayer");
$RefreshReg$(_c7, "OpsSection$lazy");
$RefreshReg$(_c8, "OpsSection");
$RefreshReg$(_c9, "AgentsSection$lazy");
$RefreshReg$(_c0, "AgentsSection");
$RefreshReg$(_c1, "ChatSection$lazy");
$RefreshReg$(_c10, "ChatSection");
$RefreshReg$(_c11, "ContentSection$lazy");
$RefreshReg$(_c12, "ContentSection");
$RefreshReg$(_c13, "CommsSection$lazy");
$RefreshReg$(_c14, "CommsSection");
$RefreshReg$(_c15, "KnowledgeSection$lazy");
$RefreshReg$(_c16, "KnowledgeSection");
$RefreshReg$(_c17, "CodeSection$lazy");
$RefreshReg$(_c18, "CodeSection");
$RefreshReg$(_c19, "QualitySection$lazy");
$RefreshReg$(_c20, "QualitySection");
$RefreshReg$(_c21, "PlatformSection$lazy");
$RefreshReg$(_c22, "PlatformSection");
$RefreshReg$(_c23, "HarnessSection$lazy");
$RefreshReg$(_c24, "HarnessSection");
$RefreshReg$(_c25, "ControlSection$lazy");
$RefreshReg$(_c26, "ControlSection");
$RefreshReg$(_c27, "ProjectSwitcher");
$RefreshReg$(_c28, "PageTransition");
$RefreshReg$(_c29, "SectionLoadingState");
$RefreshReg$(_c30, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkZNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTdGTixTQUFTQSxVQUFVQyxXQUFXQyxTQUFTQyxhQUFhQyxNQUFNQyxnQkFBZ0I7QUFDMUUsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLGlCQUFpQkMsY0FBYztBQUN4QyxTQUFTQyxXQUFXO0FBR3BCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxjQUE0QjtBQUNyQyxTQUFTQyxpQkFBaUI7QUFDMUIsU0FBa0JDLHFCQUFxQjtBQUN2QyxTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLDRCQUE0QjtBQUNyQyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLHVCQUF1QjtBQUNoQztBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxNQUFNQyxvQkFBb0JyQjtBQUFBQSxFQUFJc0IsS0FBQ0EsTUFDN0IsT0FBTyxxQkFBcUIsRUFBRUMsS0FBSyxDQUFDQyxZQUFZLEVBQUVDLFNBQVNELE9BQU9ILGtCQUFrQixFQUFFO0FBQ3hGO0FBQUVLLE1BRklMO0FBR04sTUFBTU0saUJBQWlCM0I7QUFBQUEsRUFBSTRCLE1BQUNBLE1BQzFCLE9BQU8sa0JBQWtCLEVBQUVMLEtBQUssQ0FBQ0MsWUFBWSxFQUFFQyxTQUFTRCxPQUFPRyxlQUFlLEVBQUU7QUFDbEY7QUFBRUUsTUFGSUY7QUFHTixNQUFNRyxhQUFhOUI7QUFBQUEsRUFBSStCLE1BQUNBLE1BQ3RCLE9BQU8sY0FBYyxFQUFFUixLQUFLLENBQUNDLFlBQVksRUFBRUMsU0FBU0QsT0FBT00sV0FBVyxFQUFFO0FBQzFFO0FBQUVFLE1BRklGO0FBR04sTUFBTUcsYUFBYWpDO0FBQUFBLEVBQUlrQyxNQUFDQSxNQUN0QixPQUFPLHVCQUF1QixFQUFFWCxLQUFLLENBQUNDLFlBQVksRUFBRUMsU0FBU0QsT0FBT1MsV0FBVyxFQUFFO0FBQ25GO0FBQUVFLE1BRklGO0FBR04sTUFBTUcsZ0JBQWdCcEM7QUFBQUEsRUFBSXFDLE1BQUNBLE1BQ3pCLE9BQU8sMEJBQTBCLEVBQUVkLEtBQUssQ0FBQ0MsWUFBWSxFQUFFQyxTQUFTRCxPQUFPWSxjQUFjLEVBQUU7QUFDekY7QUFBRUUsTUFGSUY7QUFHTixNQUFNRyxjQUFjdkM7QUFBQUEsRUFBSXdDLE1BQUNBLE1BQ3ZCLE9BQU8sd0JBQXdCLEVBQUVqQixLQUFLLENBQUNDLFlBQVksRUFBRUMsU0FBU0QsT0FBT2UsWUFBWSxFQUFFO0FBQ3JGO0FBQUVFLE9BRklGO0FBR04sTUFBTUcsaUJBQWlCMUM7QUFBQUEsRUFBSTJDLE9BQUNBLE1BQzFCLE9BQU8sMkJBQTJCLEVBQUVwQixLQUFLLENBQUNDLFlBQVksRUFBRUMsU0FBU0QsT0FBT2tCLGVBQWUsRUFBRTtBQUMzRjtBQUFFRSxPQUZJRjtBQUdOLE1BQU1HLGVBQWU3QztBQUFBQSxFQUFJOEMsT0FBQ0EsTUFDeEIsT0FBTyx5QkFBeUIsRUFBRXZCLEtBQUssQ0FBQ0MsWUFBWSxFQUFFQyxTQUFTRCxPQUFPcUIsYUFBYSxFQUFFO0FBQ3ZGO0FBQUVFLE9BRklGO0FBR04sTUFBTUcsbUJBQW1CaEQ7QUFBQUEsRUFBSWlELE9BQUNBLE1BQzVCLE9BQU8sNkJBQTZCLEVBQUUxQixLQUFLLENBQUNDLFlBQVksRUFBRUMsU0FBU0QsT0FBT3dCLGlCQUFpQixFQUFFO0FBQy9GO0FBQUVFLE9BRklGO0FBR04sTUFBTUcsY0FBY25EO0FBQUFBLEVBQUlvRCxPQUFDQSxNQUN2QixPQUFPLHdCQUF3QixFQUFFN0IsS0FBSyxDQUFDQyxZQUFZLEVBQUVDLFNBQVNELE9BQU8yQixZQUFZLEVBQUU7QUFDckY7QUFBRUUsT0FGSUY7QUFHTixNQUFNRyxpQkFBaUJ0RDtBQUFBQSxFQUFJdUQsT0FBQ0EsTUFDMUIsT0FBTywyQkFBMkIsRUFBRWhDLEtBQUssQ0FBQ0MsWUFBWSxFQUFFQyxTQUFTRCxPQUFPOEIsZUFBZSxFQUFFO0FBQzNGO0FBQUVFLE9BRklGO0FBR04sTUFBTUcsa0JBQWtCekQ7QUFBQUEsRUFBSTBELE9BQUNBLE1BQzNCLE9BQU8sNEJBQTRCLEVBQUVuQyxLQUFLLENBQUNDLFlBQVksRUFBRUMsU0FBU0QsT0FBT2lDLGdCQUFnQixFQUFFO0FBQzdGO0FBQUVFLE9BRklGO0FBR04sTUFBTUcsaUJBQWlCNUQ7QUFBQUEsRUFBSTZELE9BQUNBLE1BQzFCLE9BQU8sMEJBQTBCLEVBQUV0QyxLQUFLLENBQUNDLFlBQVksRUFBRUMsU0FBU0QsT0FBT29DLGVBQWUsRUFBRTtBQUMxRjtBQUFFRSxPQUZJRjtBQUdOLE1BQU1HLGlCQUFpQi9EO0FBQUFBLEVBQUlnRSxPQUFDQSxNQUMxQixPQUFPLDJCQUEyQixFQUFFekMsS0FBSyxDQUFDQyxZQUFZLEVBQUVDLFNBQVNELE9BQU91QyxlQUFlLEVBQUU7QUFDM0Y7QUFBRUUsT0FGSUY7QUFtQk4sU0FBU0csZ0JBQWdCO0FBQUEsRUFDdkJDO0FBQUFBLEVBQ0FDLGNBQWM7QUFJaEIsR0FBRztBQUFBQyxLQUFBO0FBQ0QsUUFBTUMsV0FBV25FLFNBQVNHLElBQUlnRSxTQUFTQyxJQUFJO0FBQzNDLFFBQU0sRUFBRUMsV0FBV0MsY0FBY0MsUUFBUSxJQUFJdEQsa0JBQWtCO0FBRS9ELE1BQUksQ0FBQ2tELFVBQVU7QUFDYixXQUNFLHVCQUFDLFNBQUksV0FBVSx5SEFBdUgsbUNBQXRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFFQSxRQUFNSyxvQkFBb0JMLFNBQVNNLE9BQU8sQ0FBQ0MsU0FBU0EsS0FBS0MsV0FBVyxVQUFVO0FBQzlFLFFBQU1DLG1CQUNKTCxTQUFTSyxxQkFBcUJMLFNBQVNNLGFBQWEsZUFBZTtBQUVyRSxTQUNFLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLGNBQVc7QUFBQSxRQUNYLE9BQU9SLGFBQWE7QUFBQSxRQUNwQixVQUFVLENBQUNTLE1BQU07QUFDZixnQkFBTUMsUUFBUUQsRUFBRUUsT0FBT0Q7QUFDdkIsY0FBSUEsTUFBT1QsY0FBYVMsS0FBdUI7QUFBQSxRQUNqRDtBQUFBLFFBQ0EsV0FBVTtBQUFBLFFBRVY7QUFBQSxpQ0FBQyxZQUFPLE9BQU0sSUFBRyxVQUFRLE1BQ3RCUCw0QkFBa0JTLFdBQVcsSUFBSSxrQkFBa0Isc0JBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDVCxrQkFBa0JVO0FBQUFBLFlBQUksQ0FBQ0MsTUFDdEIsdUJBQUMsWUFBbUIsT0FBT0EsRUFBRUMsS0FDMUJELFlBQUVFLFFBRFFGLEVBQUVDLEtBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFVBQ0Q7QUFBQTtBQUFBO0FBQUEsTUFoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBaUJBO0FBQUEsSUFDQ25CLGNBQ0MsdUJBQUMsU0FBSSxXQUFVLDBEQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVEQUNaTSxtQkFBU00sY0FBYyw2QkFEMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsMkVBQ2I7QUFBQSwrQkFBQyxVQUFLLFdBQVUsWUFDYk4sbUJBQVNNLGFBQ04sR0FBR04sUUFBUWUsZ0JBQWdCLE1BQU0sTUFBTVYsaUJBQWlCVyxZQUFZLENBQUMsS0FDckUsb0JBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFDQ3ZCLFdBQ0M7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVNBO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBQXdEO0FBQUE7QUFBQSxVQUhwRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQSxJQUNFO0FBQUEsV0FkTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxTQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBLElBQ0U7QUFBQSxPQXpDTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMENBO0FBRUo7QUFJQUUsR0F2RVNILGlCQUFlO0FBQUEsVUFPTC9ELFVBQzRCaUIsaUJBQWlCO0FBQUE7QUFBQSxPQVJ2RDhDO0FBeUVULE1BQU15QixtQkFBbUI7QUFDekIsTUFBTUMsc0JBQXNCO0FBRTVCLFNBQVNDLHlCQUF3QztBQUMvQyxNQUFJLE9BQU9DLFdBQVcsWUFBYSxRQUFPO0FBQzFDLE1BQUk7QUFDRixVQUFNQyxVQUFVLElBQUlDLElBQUlGLE9BQU9HLFNBQVNDLElBQUksRUFBRUMsYUFBYUMsSUFBSSxXQUFXO0FBQzFFLFFBQUlMLFFBQVMsUUFBT0E7QUFDcEIsVUFBTU0sWUFBWVAsT0FBT1EsYUFBYUMsUUFBUVgsbUJBQW1CO0FBQ2pFLFdBQU9TLFlBQWFBLFlBQStCO0FBQUEsRUFDckQsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFQSxNQUFNRyxtQkFBK0I7QUFBQSxFQUNuQztBQUFBLEVBQVE7QUFBQSxFQUFPO0FBQUEsRUFBUztBQUFBLEVBQVU7QUFBQSxFQUFhO0FBQUEsRUFBWTtBQUFBLEVBQWU7QUFBQSxFQUFTO0FBQUEsRUFBYTtBQUFBLEVBQWU7QUFBQSxFQUMvRztBQUFBLEVBQU87QUFBQSxFQUFRO0FBQUEsRUFBVztBQUFBLEVBQVk7QUFBQSxFQUFZO0FBQUEsRUFBaUI7QUFBQSxFQUFVO0FBQUEsRUFBWTtBQUFBLEVBQVE7QUFBQSxFQUFVO0FBQUEsRUFBVTtBQUFBLEVBQ3JIO0FBQUEsRUFDQTtBQUFBLEVBQVU7QUFBQSxFQUFlO0FBQUEsRUFBVTtBQUFBLEVBQVk7QUFBQSxFQUFhO0FBQUEsRUFBWTtBQUFBLEVBQVM7QUFBQSxFQUNqRjtBQUFBLEVBQU87QUFBQSxFQUFXO0FBQUEsRUFBUTtBQUFBLEVBQVk7QUFBQSxFQUFtQjtBQUFBLEVBQWM7QUFBQSxFQUFhO0FBQUEsRUFDcEY7QUFBQSxFQUFvQjtBQUFBLEVBQVk7QUFBQSxFQUFXO0FBQUEsRUFBVztBQUFBLEVBQVc7QUFBQSxFQUFnQjtBQUFBLEVBQ2pGO0FBQUEsRUFBbUI7QUFBQSxFQUFlO0FBQUEsRUFBYztBQUFBLEVBQWU7QUFBQSxFQUFXO0FBQUEsRUFBYTtBQUFBLEVBQ3ZGO0FBQUEsRUFBVTtBQUFBLEVBQVE7QUFBQSxFQUFVO0FBQUEsRUFBUztBQUFBLEVBQVc7QUFBQSxFQUFZO0FBQUEsRUFBWTtBQUFBLEVBQWdCO0FBQUEsRUFDeEY7QUFBQSxFQUFhO0FBQUEsRUFBa0I7QUFBQSxFQUFZO0FBQUEsRUFBa0I7QUFBQSxFQUFtQjtBQUFBLEVBQ2hGO0FBQUEsRUFBa0I7QUFBQSxFQUFhO0FBQUEsRUFBWTtBQUFBLEVBQWlCO0FBQUEsRUFBVztBQUFBLEVBQ3ZFO0FBQUEsRUFBcUI7QUFBQSxFQUF1QjtBQUFBLEVBQWlCO0FBQUEsRUFDN0Q7QUFBQSxFQUFrQjtBQUFBLEVBQWlCO0FBQUEsRUFBeUI7QUFBQSxFQUM1RDtBQUFBLEVBQXFCO0FBQUEsRUFBeUI7QUFBQSxFQUF1QjtBQUFBLEVBQ3JFO0FBQUEsRUFBcUI7QUFBQSxFQUFzQjtBQUFBLEVBQW1CO0FBQUEsRUFBdUI7QUFBQSxFQUNyRjtBQUFBLEVBQW9CO0FBQUEsRUFBdUI7QUFBQSxFQUF1QjtBQUFBLEVBQTRCO0FBQUEsRUFBcUI7QUFBQSxFQUNuSDtBQUFBLEVBQXNCO0FBQUEsRUFBcUI7QUFBQSxFQUFzQjtBQUFBLEVBQTBCO0FBQWU7QUFHNUcsU0FBU0Msb0JBQXFDO0FBQzVDLE1BQUksT0FBT1gsV0FBVyxZQUFhLFFBQU87QUFDMUMsTUFBSTtBQUNGLFVBQU1ZLE1BQU1aLE9BQU9RLGFBQWFDLFFBQVFaLGdCQUFnQjtBQUN4RCxRQUFJLENBQUNlLElBQUssUUFBTztBQUNqQixVQUFNQyxPQUFPRDtBQUNiLFdBQU9GLGlCQUFpQkksU0FBU0QsSUFBSSxJQUFJQSxPQUFPO0FBQUEsRUFDbEQsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFNQSxNQUFNRSx1QkFBeUQ7QUFBQSxFQUM3REMsTUFBTTtBQUFBLEVBQ05DLFNBQVM7QUFBQSxFQUNUQyxLQUFLO0FBQUEsRUFDTEMsUUFBUTtBQUFBLEVBQ1JDLE1BQU07QUFBQSxFQUNOQyxTQUFTO0FBQUEsRUFDVEMsT0FBTztBQUFBLEVBQ1BDLFdBQVc7QUFBQSxFQUNYQyxNQUFNO0FBQUEsRUFDTkMsU0FBUztBQUFBLEVBQ1RDLFVBQVU7QUFDWjtBQUVBLE1BQU1DLGVBQXlEO0FBQUEsRUFDN0RYLE1BQU07QUFBQSxFQUNOQyxTQUFTO0FBQUEsSUFDUCxFQUFFVyxJQUFJLHFCQUFxQkMsT0FBTyxZQUFZO0FBQUEsSUFDOUMsRUFBRUQsSUFBSSx1QkFBdUJDLE9BQU8sY0FBYztBQUFBLElBQ2xELEVBQUVELElBQUksaUJBQWlCQyxPQUFPLFFBQVE7QUFBQSxJQUN0QyxFQUFFRCxJQUFJLHFCQUFxQkMsT0FBTyxZQUFZO0FBQUEsRUFBQztBQUFBLEVBRWpEWCxLQUFLO0FBQUEsSUFDSCxFQUFFVSxJQUFJLFNBQVNDLE9BQU8sUUFBUTtBQUFBLElBQzlCLEVBQUVELElBQUksU0FBU0MsT0FBTyxRQUFRO0FBQUEsSUFDOUIsRUFBRUQsSUFBSSxPQUFPQyxPQUFPLE1BQU07QUFBQSxJQUMxQixFQUFFRCxJQUFJLFlBQVlDLE9BQU8sV0FBVztBQUFBLElBQ3BDLEVBQUVELElBQUksZ0JBQWdCQyxPQUFPLFdBQVc7QUFBQSxJQUN4QyxFQUFFRCxJQUFJLFNBQVNDLE9BQU8sUUFBUTtBQUFBLElBQzlCLEVBQUVELElBQUksYUFBYUMsT0FBTyxZQUFZO0FBQUEsSUFDdEMsRUFBRUQsSUFBSSxlQUFlQyxPQUFPLGNBQWM7QUFBQSxFQUFDO0FBQUEsRUFFN0NWLFFBQVE7QUFBQSxJQUNOLEVBQUVTLElBQUksT0FBT0MsT0FBTyxNQUFNO0FBQUEsSUFDMUIsRUFBRUQsSUFBSSxVQUFVQyxPQUFPLFdBQVc7QUFBQSxJQUNsQyxFQUFFRCxJQUFJLGFBQWFDLE9BQU8sWUFBWTtBQUFBLElBQ3RDLEVBQUVELElBQUksWUFBWUMsT0FBTyxhQUFhO0FBQUEsSUFDdEMsRUFBRUQsSUFBSSxZQUFZQyxPQUFPLFdBQVc7QUFBQSxJQUNwQyxFQUFFRCxJQUFJLGVBQWVDLE9BQU8sY0FBYztBQUFBLElBQzFDLEVBQUVELElBQUksV0FBV0MsT0FBTyxVQUFVO0FBQUEsSUFDbEMsRUFBRUQsSUFBSSxhQUFhQyxPQUFPLFlBQVk7QUFBQSxFQUFDO0FBQUEsRUFFekNULE1BQU07QUFBQSxJQUNKLEVBQUVRLElBQUksUUFBUUMsT0FBTyxPQUFPO0FBQUEsSUFDNUIsRUFBRUQsSUFBSSxhQUFhQyxPQUFPLE9BQU87QUFBQSxJQUNqQyxFQUFFRCxJQUFJLFdBQVdDLE9BQU8sVUFBVTtBQUFBLElBQ2xDLEVBQUVELElBQUksV0FBV0MsT0FBTyxVQUFVO0FBQUEsRUFBQztBQUFBLEVBRXJDUixTQUFTO0FBQUEsSUFDUCxFQUFFTyxJQUFJLG9CQUFvQkMsT0FBTyxXQUFXO0FBQUEsSUFDNUMsRUFBRUQsSUFBSSxZQUFZQyxPQUFPLFdBQVc7QUFBQSxJQUNwQyxFQUFFRCxJQUFJLFlBQVlDLE9BQU8sV0FBVztBQUFBLEVBQUM7QUFBQSxFQUV2Q1AsT0FBTztBQUFBLElBQ0wsRUFBRU0sSUFBSSxhQUFhQyxPQUFPLFlBQVk7QUFBQSxJQUN0QyxFQUFFRCxJQUFJLFlBQVlDLE9BQU8sV0FBVztBQUFBLElBQ3BDLEVBQUVELElBQUksU0FBU0MsT0FBTyxRQUFRO0FBQUEsSUFDOUIsRUFBRUQsSUFBSSxPQUFPQyxPQUFPLE1BQU07QUFBQSxJQUMxQixFQUFFRCxJQUFJLFVBQVVDLE9BQU8sU0FBUztBQUFBLElBQ2hDLEVBQUVELElBQUksUUFBUUMsT0FBTyxPQUFPO0FBQUEsSUFDNUIsRUFBRUQsSUFBSSxPQUFPQyxPQUFPLFlBQVk7QUFBQSxJQUNoQyxFQUFFRCxJQUFJLFVBQVVDLE9BQU8sU0FBUztBQUFBLElBQ2hDLEVBQUVELElBQUksZUFBZUMsT0FBTyxjQUFjO0FBQUEsSUFDMUMsRUFBRUQsSUFBSSxVQUFVQyxPQUFPLFNBQVM7QUFBQSxFQUFDO0FBQUEsRUFFbkNOLFdBQVc7QUFBQSxJQUNULEVBQUVLLElBQUksUUFBUUMsT0FBTyxZQUFZO0FBQUEsSUFDakMsRUFBRUQsSUFBSSxpQkFBaUJDLE9BQU8sYUFBYTtBQUFBLElBQzNDLEVBQUVELElBQUksVUFBVUMsT0FBTyxrQkFBa0I7QUFBQSxJQUN6QyxFQUFFRCxJQUFJLFVBQVVDLE9BQU8sU0FBUztBQUFBLElBQ2hDLEVBQUVELElBQUksVUFBVUMsT0FBTyxTQUFTO0FBQUEsRUFBQztBQUFBLEVBRW5DTCxNQUFNO0FBQUEsSUFDSixFQUFFSSxJQUFJLFFBQVFDLE9BQU8sV0FBVztBQUFBLElBQ2hDLEVBQUVELElBQUksWUFBWUMsT0FBTyxXQUFXO0FBQUEsSUFDcEMsRUFBRUQsSUFBSSxtQkFBbUJDLE9BQU8sUUFBUTtBQUFBLElBQ3hDLEVBQUVELElBQUksY0FBY0MsT0FBTyxhQUFhO0FBQUEsSUFDeEMsRUFBRUQsSUFBSSxhQUFhQyxPQUFPLFlBQVk7QUFBQSxJQUN0QyxFQUFFRCxJQUFJLGVBQWVDLE9BQU8sUUFBUTtBQUFBLElBQ3BDLEVBQUVELElBQUksb0JBQW9CQyxPQUFPLFNBQVM7QUFBQSxJQUMxQyxFQUFFRCxJQUFJLFlBQVlDLE9BQU8sV0FBVztBQUFBLElBQ3BDLEVBQUVELElBQUksV0FBV0MsT0FBTyxVQUFVO0FBQUEsSUFDbEMsRUFBRUQsSUFBSSxXQUFXQyxPQUFPLFVBQVU7QUFBQSxJQUNsQyxFQUFFRCxJQUFJLFdBQVdDLE9BQU8sVUFBVTtBQUFBLEVBQUM7QUFBQSxFQUVyQ0osU0FBUztBQUFBLElBQ1AsRUFBRUcsSUFBSSxnQkFBZ0JDLE9BQU8sWUFBWTtBQUFBLElBQ3pDLEVBQUVELElBQUksV0FBV0MsT0FBTyxPQUFPO0FBQUEsSUFDL0IsRUFBRUQsSUFBSSxtQkFBbUJDLE9BQU8sZUFBZTtBQUFBLElBQy9DLEVBQUVELElBQUksZUFBZUMsT0FBTyxXQUFXO0FBQUEsSUFDdkMsRUFBRUQsSUFBSSxjQUFjQyxPQUFPLFVBQVU7QUFBQSxJQUNyQyxFQUFFRCxJQUFJLGVBQWVDLE9BQU8sV0FBVztBQUFBLEVBQUM7QUFBQSxFQUUxQ0gsVUFBVTtBQUFBLElBQ1IsRUFBRUUsSUFBSSxVQUFVQyxPQUFPLFdBQVc7QUFBQSxJQUNsQyxFQUFFRCxJQUFJLFNBQVNDLE9BQU8sUUFBUTtBQUFBLElBQzlCLEVBQUVELElBQUksV0FBV0MsT0FBTyxVQUFVO0FBQUEsSUFDbEMsRUFBRUQsSUFBSSxZQUFZQyxPQUFPLGlCQUFpQjtBQUFBLElBQzFDLEVBQUVELElBQUksWUFBWUMsT0FBTyxXQUFXO0FBQUEsSUFDcEMsRUFBRUQsSUFBSSxhQUFhQyxPQUFPLFlBQVk7QUFBQSxFQUFDO0FBRTNDO0FBRUEsU0FBU0MsY0FBY2pCLE1BQWdDO0FBQ3JELE1BQUlBLFNBQVMsT0FBUSxRQUFPO0FBQzVCLE1BQ0U7QUFBQSxJQUNFO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFBbUIsRUFDbkJDLFNBQVNELElBQUksR0FDZjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFDRTtBQUFBLElBQ0U7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUFrQixFQUNsQkMsU0FBU0QsSUFBSSxHQUNmO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLENBQUMsU0FBUyxTQUFTLE9BQU8sWUFBWSxnQkFBZ0IsU0FBUyxhQUFhLGVBQWUsaUJBQWlCLEVBQUVDLFNBQVNELElBQUksRUFBRyxRQUFPO0FBQ3pJLE1BQUksQ0FBQyxPQUFPLFVBQVUsYUFBYSxZQUFZLFlBQVksZUFBZSxXQUFXLFdBQVcsRUFBRUMsU0FBU0QsSUFBSSxFQUFHLFFBQU87QUFDekgsTUFBSSxDQUFDLFFBQVEsYUFBYSxXQUFXLFNBQVMsRUFBRUMsU0FBU0QsSUFBSSxFQUFHLFFBQU87QUFDdkUsTUFBSSxDQUFDLFlBQVksWUFBWSxrQkFBa0IsRUFBRUMsU0FBU0QsSUFBSSxFQUFHLFFBQU87QUFDeEUsTUFBSSxDQUFDLGdCQUFnQixXQUFXLG1CQUFtQixlQUFlLGNBQWMsYUFBYSxFQUFFQyxTQUFTRCxJQUFJLEVBQUcsUUFBTztBQUN0SCxNQUFJLENBQUMsYUFBYSxZQUFZLFNBQVMsVUFBVSxPQUFPLFVBQVUsZUFBZSxPQUFPLFVBQVUsTUFBTSxFQUFFQyxTQUFTRCxJQUFJLEVBQUcsUUFBTztBQUNqSSxNQUNFO0FBQUEsSUFDRTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQVEsRUFDUkMsU0FBU0QsSUFBSTtBQUVmLFdBQU87QUFDVCxNQUFJLENBQUMsVUFBVSxTQUFTLFdBQVcsWUFBWSxZQUFZLGFBQWEsaUJBQWlCLGtCQUFrQixZQUFZLGtCQUFrQixtQkFBbUIsaUJBQWlCLGtCQUFrQixhQUFhLFlBQVksaUJBQWlCLFdBQVcsaUJBQWlCLEVBQUVDLFNBQVNELElBQUksRUFBRyxRQUFPO0FBQzlSLE1BQUk7QUFBQSxJQUNGO0FBQUEsSUFBUTtBQUFBLElBQVk7QUFBQSxJQUFtQjtBQUFBLElBQWM7QUFBQSxJQUNyRDtBQUFBLElBQWU7QUFBQSxJQUFvQjtBQUFBLElBQVk7QUFBQSxJQUFXO0FBQUEsSUFBVztBQUFBLEVBQVMsRUFDOUVDLFNBQVNELElBQUksRUFBRyxRQUFPO0FBQ3pCLFNBQU87QUFDVDtBQU1BLFNBQVNrQixpQkFBaUJyRCxXQUFrQztBQUFBc0QsTUFBQTtBQUMxRCxRQUFNYixTQUFTOUcsU0FBU0csSUFBSTJHLE9BQU9jLFNBQVN2RCxZQUFZLEVBQUVBLFVBQVUsSUFBSSxNQUFNO0FBQzlFLFFBQU13RCxRQUFRN0gsU0FBU0csSUFBSTBILE1BQU1ELFNBQVN2RCxZQUFZLEVBQUVBLFVBQVUsSUFBSSxNQUFNO0FBQzVFLFFBQU0sQ0FBQ3lELFlBQVlDLGFBQWEsSUFBSXRJLFNBQVMsTUFBTXVJLEtBQUtDLElBQUksQ0FBQztBQUM3RCxRQUFNQyxjQUFjcEIsUUFBUXJDLE9BQU8sQ0FBQzBELE1BQU1BLEVBQUV4RCxXQUFXLFFBQVEsRUFBRU0sVUFBVTtBQUMzRSxRQUFNbUQsWUFBWVAsT0FBTzVDLFVBQVU7QUFFbkN2RixZQUFVLE1BQU07QUFDZCxVQUFNMkksUUFBUTFDLE9BQU8yQyxZQUFZLE1BQU07QUFDckNQLG9CQUFjQyxLQUFLQyxJQUFJLENBQUM7QUFBQSxJQUMxQixHQUFHLElBQU07QUFDVCxXQUFPLE1BQU10QyxPQUFPNEMsY0FBY0YsS0FBSztBQUFBLEVBQ3pDLEdBQUcsRUFBRTtBQUVMLFFBQU1HLFdBQVc3SSxRQUF1QixNQUFNO0FBQzVDLFFBQUksQ0FBQ21ILFVBQVVBLE9BQU83QixXQUFXLEdBQUc7QUFDbEMsYUFBTztBQUFBLFFBQ0x3RCxNQUFNO0FBQUEsUUFDTmpCLE9BQU87QUFBQSxRQUNQa0IsUUFBUTtBQUFBLFFBQ1JDLGVBQWU7QUFBQSxRQUNmQyxTQUFTO0FBQUEsUUFDVEMsUUFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBRUEsVUFBTUMsZ0JBQWdCLElBQUlDLElBQUlsQixPQUFPM0MsSUFBSSxDQUFDOEQsU0FBUyxDQUFDQSxLQUFLNUQsS0FBSzRELEtBQUtDLEtBQUssQ0FBQyxLQUFLLEVBQUU7QUFDaEYsVUFBTUMsZ0JBQWdCLENBQUMsR0FBR3BDLE1BQU0sRUFBRXFDLEtBQUssQ0FBQ0MsTUFBTUMsVUFBVTtBQUN0RCxZQUFNQyxZQUFZRixLQUFLRyxtQkFBbUI7QUFDMUMsWUFBTUMsYUFBYUgsTUFBTUUsbUJBQW1CO0FBQzVDLGFBQU9DLGFBQWFGO0FBQUFBLElBQ3RCLENBQUMsRUFBRSxDQUFDO0FBRUosVUFBTUMsa0JBQWtCTCxlQUFlSyxtQkFBbUI7QUFDMUQsVUFBTUUsUUFBUUYsa0JBQWtCekIsYUFBYXlCLGtCQUFrQkcsT0FBT0M7QUFDdEUsVUFBTUMsWUFBWVYsZUFBZVcsZ0JBQzdCZixjQUFjN0MsSUFBSWlELGNBQWNXLGFBQWEsS0FBSyxnQkFDbEQ7QUFFSixVQUFNbEIsZ0JBQWdCLENBQUNZLGtCQUNuQixjQUNBRSxRQUFRLE1BQ04sYUFDQUEsUUFBUSxPQUNOLGVBQWVLLEtBQUtDLE1BQU1OLFFBQVEsR0FBTSxDQUFDLFVBQ3pDQSxRQUFRLFFBQ04sZUFBZUssS0FBS0MsTUFBTU4sUUFBUSxJQUFTLENBQUMsVUFDNUMsZUFBZUssS0FBS0MsTUFBTU4sUUFBUSxLQUFVLENBQUM7QUFFdkQsUUFBSSxDQUFDUCxpQkFBaUJBLGNBQWN2RSxXQUFXLFdBQVc7QUFDeEQsYUFBTztBQUFBLFFBQ0w4RCxNQUFNO0FBQUEsUUFDTmpCLE9BQU87QUFBQSxRQUNQa0IsUUFBUTtBQUFBLFFBQ1JDO0FBQUFBLFFBQ0FDLFNBQVNNLGVBQWU5RCxPQUFPO0FBQUEsUUFDL0J5RCxRQUFRSyxlQUFlVyxpQkFBaUI7QUFBQSxNQUMxQztBQUFBLElBQ0Y7QUFFQSxRQUFJWCxjQUFjdkUsV0FBVyxVQUFVO0FBQ3JDLGFBQU87QUFBQSxRQUNMOEQsTUFBTTtBQUFBLFFBQ05qQixPQUFPO0FBQUEsUUFDUGtCLFFBQVEsR0FBR1EsY0FBYzdELElBQUk7QUFBQSxRQUM3QnNEO0FBQUFBLFFBQ0FDLFNBQVNNLGNBQWM5RDtBQUFBQSxRQUN2QnlELFFBQVFLLGNBQWNXLGlCQUFpQjtBQUFBLE1BQ3pDO0FBQUEsSUFDRjtBQUVBLFFBQUlYLGNBQWN2RSxXQUFXLGlCQUFpQnVFLGNBQWN2RSxXQUFXLFdBQVc7QUFDaEYsYUFBTztBQUFBLFFBQ0w4RCxNQUFNO0FBQUEsUUFDTmpCLE9BQU87QUFBQSxRQUNQa0IsUUFBUSxHQUFHUSxjQUFjN0QsSUFBSSxPQUFPNkQsY0FBY3ZFLE9BQU9ZLFlBQVksQ0FBQztBQUFBLFFBQ3RFb0Q7QUFBQUEsUUFDQUMsU0FBU00sY0FBYzlEO0FBQUFBLFFBQ3ZCeUQsUUFBUUssY0FBY1csaUJBQWlCO0FBQUEsTUFDekM7QUFBQSxJQUNGO0FBRUEsUUFBSUosU0FBUyxNQUFRO0FBQ25CLGFBQU87QUFBQSxRQUNMaEIsTUFBTTtBQUFBLFFBQ05qQixPQUFPb0MsWUFBWSxnQkFBZ0I7QUFBQSxRQUNuQ2xCLFFBQVFrQixZQUNKLEdBQUdWLGNBQWM3RCxJQUFJLGtCQUFrQnVFLFNBQVMsTUFDaEQsR0FBR1YsY0FBYzdELElBQUk7QUFBQSxRQUN6QnNEO0FBQUFBLFFBQ0FDLFNBQVNNLGNBQWM5RDtBQUFBQSxRQUN2QnlELFFBQVFLLGNBQWNXLGlCQUFpQjtBQUFBLE1BQ3pDO0FBQUEsSUFDRjtBQUVBLFFBQUlKLFNBQVMsTUFBUztBQUNwQixhQUFPO0FBQUEsUUFDTGhCLE1BQU07QUFBQSxRQUNOakIsT0FBT29DLFlBQVksK0JBQStCO0FBQUEsUUFDbERsQixRQUFRa0IsWUFDSixHQUFHVixjQUFjN0QsSUFBSSxtQ0FBbUN1RSxTQUFTLE1BQ2pFLEdBQUdWLGNBQWM3RCxJQUFJO0FBQUEsUUFDekJzRDtBQUFBQSxRQUNBQyxTQUFTTSxjQUFjOUQ7QUFBQUEsUUFDdkJ5RCxRQUFRSyxjQUFjVyxpQkFBaUI7QUFBQSxNQUN6QztBQUFBLElBQ0Y7QUFFQSxRQUFJSixRQUFRLE9BQVk7QUFDdEIsYUFBTztBQUFBLFFBQ0xoQixNQUFNO0FBQUEsUUFDTmpCLE9BQU87QUFBQSxRQUNQa0IsUUFBUSxHQUFHUSxjQUFjN0QsSUFBSTtBQUFBLFFBQzdCc0Q7QUFBQUEsUUFDQUMsU0FBU00sY0FBYzlEO0FBQUFBLFFBQ3ZCeUQsUUFBUUssY0FBY1csaUJBQWlCO0FBQUEsTUFDekM7QUFBQSxJQUNGO0FBRUEsV0FBTztBQUFBLE1BQ0xwQixNQUFNO0FBQUEsTUFDTmpCLE9BQU87QUFBQSxNQUNQa0IsUUFBUSxHQUFHUSxjQUFjN0QsSUFBSTtBQUFBLE1BQzdCc0Q7QUFBQUEsTUFDQUMsU0FBU00sY0FBYzlEO0FBQUFBLE1BQ3ZCeUQsUUFBUUssY0FBY1csaUJBQWlCO0FBQUEsSUFDekM7QUFBQSxFQUNGLEdBQUcsQ0FBQy9DLFFBQVFnQixZQUFZRCxLQUFLLENBQUM7QUFFOUIsU0FBTyxFQUFFSyxhQUFhRSxXQUFXSSxTQUFTO0FBQzVDO0FBSUFiLElBdElTRCxrQkFBZ0I7QUFBQSxVQUNSMUgsVUFDREEsUUFBUTtBQUFBO0FBc0l4QixTQUFTZ0ssZUFBZSxFQUFFQyxVQUFVQyxRQUF3RCxHQUFHO0FBQzdGLFNBQ0UsdUJBQUMsbUJBQWdCLE1BQUssUUFDcEI7QUFBQSxJQUFDLE9BQU87QUFBQSxJQUFQO0FBQUEsTUFFQyxTQUFTLEVBQUVDLFNBQVMsR0FBR0MsR0FBRyxFQUFFO0FBQUEsTUFDNUIsU0FBUyxFQUFFRCxTQUFTLEdBQUdDLEdBQUcsRUFBRTtBQUFBLE1BQzVCLE1BQU0sRUFBRUQsU0FBUyxHQUFHQyxHQUFHLEdBQUc7QUFBQSxNQUMxQixZQUFZLEVBQUVDLFVBQVUsS0FBS0MsTUFBTSxVQUFVO0FBQUEsTUFDN0MsV0FBVTtBQUFBLE1BRVRMO0FBQUFBO0FBQUFBLElBUElDO0FBQUFBLElBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdBO0FBRUo7QUFBQ0ssT0FmUVA7QUFpQlQsU0FBU1Esc0JBQXNCO0FBQzdCLFNBQ0UsdUJBQUMsVUFBSyxXQUFVLCtCQUNkLGlDQUFDLFNBQUksV0FBVSxrQ0FDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxtRUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThFO0FBQUEsSUFDOUUsdUJBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDhEQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUU7QUFBQSxNQUN6RSx1QkFBQyxTQUFJLFdBQVUsNEVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RjtBQUFBLFNBRnpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLE9BTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRUo7QUFJQUMsT0FoQlNEO0FBa0JULHdCQUF3QkUsTUFBTTtBQUFBQyxNQUFBO0FBQzVCLFFBQU0sQ0FBQzNFLGNBQWM0RSxlQUFlLElBQUk3SixnQkFBZ0I7QUFFeEQsUUFBTSxDQUFDOEosYUFBYUMsY0FBYyxJQUFJckwsU0FBbUIsTUFBTTZHLGtCQUFrQixLQUFLLE1BQU07QUFJNUYsUUFBTSxDQUFDeUUsa0JBQWtCLElBQUl0TCxTQUFTaUcsc0JBQXNCO0FBQzVELFFBQU0sQ0FBQ3JCLFdBQVdDLFlBQVksSUFBSTdFLFNBQWdDLElBQUk7QUFDdEUsUUFBTSxDQUFDdUwsZ0JBQWdCQyxpQkFBaUIsSUFBSXhMLFNBQTZCLElBQUk7QUFDN0UsUUFBTSxDQUFDeUwsaUJBQWlCQyxrQkFBa0IsSUFBSTFMLFNBQThCLElBQUk7QUFHaEYsUUFBTSxDQUFDMkwsd0JBQXdCQyx5QkFBeUIsSUFBSTVMLFNBQThCLElBQUk7QUFDOUYsUUFBTSxDQUFDNkwsY0FBY0MsZUFBZSxJQUFJOUwsU0FBU2MsYUFBYTtBQUM5RCxRQUFNLENBQUNpTCxrQkFBa0JDLG1CQUFtQixJQUFJaE0sU0FBUyxNQUFNO0FBQzdELFFBQUksT0FBT2tHLFdBQVcsWUFBYSxRQUFPO0FBQzFDLFdBQU9BLE9BQU9RLGFBQWFDLFFBQVEsdUJBQXVCLE1BQU07QUFBQSxFQUNsRSxDQUFDO0FBQ0QsUUFBTSxDQUFDc0YsZUFBZUMsZ0JBQWdCLElBQUlsTSxTQUl2QyxFQUFFcUgsUUFBUSxJQUFJOEUsWUFBWSxJQUFJQyxPQUFPLEdBQUcsQ0FBQztBQUc1QyxRQUFNLEVBQUVDLFFBQVFDLE1BQU1DLE9BQU9DLFNBQVMsSUFBSXRMLGNBQWM7QUFHeEQsUUFBTXVMLGdCQUFnQnZNLFFBQVEsTUFBTThILGNBQWNvRCxXQUFXLEdBQUcsQ0FBQ0EsV0FBVyxDQUFDO0FBQzdFLFFBQU1zQixjQUFjN0UsYUFBYTRFLGFBQWE7QUFHOUMsUUFBTTNILFVBQVV2RSxTQUFTRyxJQUFJZ0UsU0FBUzhCLEtBQUs1QixZQUFZLEVBQUVBLFVBQVUsSUFBSSxNQUFNO0FBQzdFLFFBQU1GLFdBQVduRSxTQUFTRyxJQUFJZ0UsU0FBU0MsSUFBSTtBQUMzQyxRQUFNSSxvQkFBb0I3RTtBQUFBQSxJQUN4QixNQUFNd0UsVUFBVU0sT0FBTyxDQUFDQyxTQUFTQSxLQUFLQyxXQUFXLFVBQVU7QUFBQSxJQUMzRCxDQUFDUixRQUFRO0FBQUEsRUFDWDtBQUNBLFFBQU1pSSxtQkFBbUJwTTtBQUFBQSxJQUN2QkcsSUFBSWtNLFVBQVVDO0FBQUFBLElBQ2RqSSxZQUFZLEVBQUVBLFdBQVdrSSxPQUFPLEdBQUcsSUFBSTtBQUFBLEVBQ3pDO0FBR0E3TSxZQUFVLE1BQU07QUFDZCxRQUNFeUUsWUFDQUsscUJBQ0FBLGtCQUFrQlMsU0FBUyxNQUMxQixDQUFDWixhQUFhLENBQUNHLGtCQUFrQmdJLEtBQUssQ0FBQzlILFNBQVNBLEtBQUtVLFFBQVFmLFNBQVMsSUFDdkU7QUFDQSxZQUFNb0ksWUFDSmpJLGtCQUFrQmtJLEtBQUssQ0FBQ3ZILE1BQU1BLEVBQUVDLFFBQVFmLFNBQVMsS0FDakRHLGtCQUFrQmtJLEtBQUssQ0FBQ3ZILE1BQU1BLEVBQUVDLFFBQVEyRixrQkFBa0IsS0FDMUR2RyxrQkFBa0JrSSxLQUFLLENBQUN2SCxNQUFNQSxFQUFFRSxLQUFLc0gsS0FBSyxFQUFFcEgsWUFBWSxNQUFNLGlCQUFpQixLQUMvRWYsa0JBQWtCa0ksS0FBSyxDQUFDdkgsTUFBTUEsRUFBRUUsS0FBS0UsWUFBWSxFQUFFa0IsU0FBUyxpQkFBaUIsQ0FBQyxLQUM5RWpDLGtCQUFrQixDQUFDO0FBQ3JCRixtQkFBYW1JLFVBQVVySCxHQUFHO0FBQUEsSUFDNUIsV0FBV1oscUJBQXFCQSxrQkFBa0JTLFdBQVcsS0FBS1osV0FBVztBQUMzRUMsbUJBQWEsSUFBSTtBQUFBLElBQ25CO0FBQUEsRUFDRixHQUFHLENBQUNFLG1CQUFtQkgsV0FBVzBHLGtCQUFrQixDQUFDO0FBRXJEckwsWUFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFDMkUsYUFBYSxPQUFPc0IsV0FBVyxZQUFhO0FBQ2pELFFBQUk7QUFDRkEsYUFBT1EsYUFBYXlHLFFBQVFuSCxxQkFBcUJwQixTQUFTO0FBQzFELFVBQUkyQixhQUFhQyxJQUFJLFdBQVcsTUFBTTVCLFdBQVc7QUFDL0N1Ryx3QkFBZ0IsQ0FBQ2lDLFlBQVk7QUFDM0IsZ0JBQU1DLE9BQU8sSUFBSUMsZ0JBQWdCRixPQUFPO0FBQ3hDQyxlQUFLRSxJQUFJLGFBQWEzSSxTQUFTO0FBQy9CLGlCQUFPeUk7QUFBQUEsUUFDVCxHQUFHLEVBQUVHLFNBQVMsS0FBSyxDQUFDO0FBQUEsTUFDdEI7QUFBQSxJQUNGLFFBQVE7QUFBQSxJQUNOO0FBQUEsRUFFSixHQUFHLENBQUM1SSxXQUFXMkIsY0FBYzRFLGVBQWUsQ0FBQztBQUU3Q2xMLFlBQVUsTUFBTTtBQUNkdUwsc0JBQWtCLElBQUk7QUFDdEJFLHVCQUFtQixJQUFJO0FBQ3ZCRSw4QkFBMEIsSUFBSTtBQUM5Qk0scUJBQWlCLEVBQUU3RSxRQUFRLElBQUk4RSxZQUFZLElBQUlDLE9BQU8sR0FBRyxDQUFDO0FBQzFESSxhQUFTO0FBQUEsRUFDWCxHQUFHLENBQUM1SCxXQUFXNEgsUUFBUSxDQUFDO0FBRXhCdk0sWUFBVSxNQUFNO0FBQ2QsUUFBSSxPQUFPaUcsV0FBVyxhQUFhO0FBQ2pDQSxhQUFPUSxhQUFheUcsUUFBUSx5QkFBeUJwQixtQkFBbUIsTUFBTSxHQUFHO0FBQUEsSUFDbkY7QUFBQSxFQUNGLEdBQUcsQ0FBQ0EsZ0JBQWdCLENBQUM7QUFFckI5TCxZQUFVLE1BQU07QUFDZCxRQUFJLE9BQU9pRyxXQUFXLGFBQWE7QUFDakMsVUFBSTtBQUNGQSxlQUFPUSxhQUFheUcsUUFBUXBILGtCQUFrQnFGLFdBQVc7QUFBQSxNQUMzRCxRQUFRO0FBQUEsTUFDTjtBQUFBLElBRUo7QUFBQSxFQUNGLEdBQUcsQ0FBQ0EsV0FBVyxDQUFDO0FBRWhCbkwsWUFBVSxNQUFNO0FBQ2QsUUFBSW1MLGdCQUFnQixRQUFTUSwyQkFBMEIsSUFBSTtBQUFBLEVBQzdELEdBQUcsQ0FBQ1IsV0FBVyxDQUFDO0FBRWhCbkwsWUFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFDb00sT0FBT29CLGFBQWM7QUFDMUIsVUFBTUMsVUFBVUEsQ0FBQ3JJLE1BQXFCO0FBQ3BDLFVBQUlBLEVBQUVzSSxRQUFRLFNBQVVwQixPQUFNLGNBQWM7QUFBQSxJQUM5QztBQUNBckcsV0FBTzBILGlCQUFpQixXQUFXRixPQUFPO0FBQzFDLFdBQU8sTUFBTXhILE9BQU8ySCxvQkFBb0IsV0FBV0gsT0FBTztBQUFBLEVBQzVELEdBQUcsQ0FBQ3JCLE9BQU9vQixjQUFjbEIsS0FBSyxDQUFDO0FBRy9CLFFBQU11QixXQUFXeE4sWUFBWUksSUFBSTJHLE9BQU95RyxRQUFRO0FBQ2hELFFBQU1DLFlBQVl6TixZQUFZSSxJQUFJMkcsT0FBTzBHLFNBQVM7QUFDbEQsUUFBTSxFQUFFQyxNQUFNLElBQUloTixTQUFTO0FBRzNCQyx1QkFBcUI7QUFBQSxJQUNuQmdOLFdBQVdBLE1BQU0zQixLQUFLLFlBQVk7QUFBQSxJQUNsQzRCLFVBQVVBLE1BQU01QixLQUFLLGdCQUFnQjtBQUFBLElBQ3JDNkIsYUFBYUEsTUFBTTdCLEtBQUssV0FBVztBQUFBLElBQ25DOEIsVUFBVUEsTUFBTTtBQUFFeEMsZ0NBQTBCLElBQUk7QUFBR1UsV0FBSyxjQUFjO0FBQUEsSUFBRztBQUFBLElBQ3pFK0IsaUJBQWlCQSxNQUFNL0IsS0FBSyxlQUFlO0FBQUEsSUFDM0NnQyxhQUFhQSxNQUFNakQsZUFBZSxPQUFPO0FBQUEsSUFDekNrRCxZQUFZQSxNQUFNakMsS0FBSyxjQUFjO0FBQUEsSUFDckNrQyxXQUFXQSxNQUFNbEMsS0FBSyxjQUFjO0FBQUEsRUFDdEMsQ0FBQztBQUdELFFBQU1tQywwQkFBMEJ0TyxZQUFZLFlBQVk7QUFDdERvTSxVQUFNLGNBQWM7QUFDcEIsUUFBSSxDQUFDM0gsV0FBVztBQUNkb0osWUFBTSw2Q0FBNkMsSUFBSTtBQUN2RDtBQUFBLElBQ0Y7QUFDQSxRQUFJO0FBQ0YsWUFBTVUsU0FBUyxNQUFNWixTQUFTO0FBQUEsUUFDNUJsSjtBQUFBQSxRQUNBK0osUUFBUTtBQUFBLFFBQ1JDLFFBQVE7QUFBQSxNQUNWLENBQUM7QUFDRFosWUFBTSxVQUFXVSxPQUE4QkcsTUFBTSxXQUFXO0FBQUEsSUFDbEUsU0FBU3hKLEdBQUc7QUFDVjJJLFlBQU0zSSxhQUFheUosUUFBUXpKLEVBQUUwSixVQUFVLGdCQUFnQixJQUFJO0FBQUEsSUFDN0Q7QUFBQSxFQUNGLEdBQUcsQ0FBQ2pCLFVBQVVsSixXQUFXb0osT0FBT3pCLEtBQUssQ0FBQztBQUV0QyxRQUFNeUMsb0JBQW9CN08sWUFBWSxZQUFZO0FBQ2hELFFBQUksQ0FBQ3lFLFdBQVc7QUFDZG9KLFlBQU0sOENBQThDLElBQUk7QUFDeEQ7QUFBQSxJQUNGO0FBQ0EsUUFBSTtBQUNGLFlBQU1VLFNBQVMsTUFBTVgsVUFBVTtBQUFBLFFBQzdCbko7QUFBQUEsUUFDQStKLFFBQVE7QUFBQSxRQUNSQyxRQUFRO0FBQUEsTUFDVixDQUFDO0FBQ0RaLFlBQU0sV0FBWVUsT0FBK0JPLE9BQU8sV0FBVztBQUFBLElBQ3JFLFNBQVM1SixHQUFHO0FBQ1YySSxZQUFNM0ksYUFBYXlKLFFBQVF6SixFQUFFMEosVUFBVSxpQkFBaUIsSUFBSTtBQUFBLElBQzlEO0FBQUEsRUFDRixHQUFHLENBQUNoQixXQUFXbkosV0FBV29KLEtBQUssQ0FBQztBQUVoQyxRQUFNa0Isc0JBQXNCL08sWUFBWSxDQUFDZ1AsWUFBNEI7QUFDbkU1QyxVQUFNLGNBQWM7QUFDcEJYLDhCQUEwQixJQUFJO0FBQzlCUCxtQkFBZXBFLHFCQUFxQmtJLE9BQU8sQ0FBQztBQUFBLEVBQzlDLEdBQUcsQ0FBQzVDLEtBQUssQ0FBQztBQUVWLFFBQU02QyxrQkFBa0JqUCxZQUFZLENBQUNrUCxVQUFrQjtBQUNyRDlDLFVBQU0sY0FBYztBQUNwQlgsOEJBQTBCLElBQUk7QUFDOUJQLG1CQUFlZ0UsS0FBaUI7QUFBQSxFQUNsQyxHQUFHLENBQUM5QyxLQUFLLENBQUM7QUFHVixRQUFNL0QsTUFBTSxvQkFBSUQsS0FBSztBQUNyQixRQUFNK0csVUFBVTlHLElBQUkrRyxtQkFBbUIsU0FBUyxFQUFFQyxNQUFNLFdBQVdDLFFBQVEsV0FBV0MsUUFBUSxVQUFVLENBQUM7QUFDekcsUUFBTUMsVUFBVW5ILElBQUlvSCxtQkFBbUIsU0FBUyxFQUFFQyxTQUFTLFNBQVNDLE9BQU8sU0FBU0MsS0FBSyxVQUFVLENBQUMsRUFBRUMsWUFBWTtBQUNsSCxRQUFNLEVBQUV2SCxhQUFhRSxXQUFXSSxTQUFTLElBQUlkLGlCQUFpQnJELFNBQVM7QUFHdkUsV0FBU3FMLGdCQUFnQjtBQUN2QixRQUFJN0UsZ0JBQWdCLFlBQVk7QUFDOUIsVUFBSSxDQUFDMUcsWUFBYUUsYUFBYUUsWUFBWW9MLFFBQVk7QUFDckQsZUFBTyx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9CO0FBQUEsTUFDN0I7QUFDQSxVQUFJbkwsa0JBQWtCUyxXQUFXLEdBQUc7QUFDbEMsZUFDRSx1QkFBQyxVQUFLLFdBQVUsc0RBQ2QsaUNBQUMsU0FBSSxXQUFVLHVFQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGtDQUFpQyxrQ0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUU7QUFBQSxVQUNqRSx1QkFBQyxPQUFFLFdBQVUsbUNBQWlDLCtGQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNNkYsZUFBZSxVQUFVO0FBQUEsY0FDeEMsV0FBVTtBQUFBLGNBQXNFO0FBQUE7QUFBQSxZQUhsRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsTUFFSjtBQUNBLFVBQUksQ0FBQ3pHLGFBQWEsQ0FBQ0UsU0FBUztBQUMxQixlQUFPLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0I7QUFBQSxNQUM3QjtBQUFBLElBQ0Y7QUFFQSxRQUNFO0FBQUEsTUFDRTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDRjtBQUFBLElBQWtCLEVBQ2hCa0MsU0FBU29FLFdBQVcsR0FDdEI7QUFDQSxhQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0E7QUFBQSxVQUNBLFlBQVlDO0FBQUFBO0FBQUFBLFFBSGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRzZCO0FBQUEsSUFHakM7QUFFQSxZQUFRb0IsZUFBYTtBQUFBLE1BQ25CLEtBQUs7QUFDSCxlQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsU0FBUyxNQUFNO0FBQUEsWUFBQztBQUFBLFlBQ2hCLG9CQUFvQixNQUFNSCxLQUFLLGNBQWM7QUFBQSxZQUM3Qyx5QkFBeUIsTUFBTUEsS0FBSyxtQkFBbUI7QUFBQSxZQUN2RCxZQUFZakI7QUFBQUEsWUFDWixpQkFBaUIsTUFBTWlCLEtBQUssV0FBVztBQUFBLFlBQ3ZDLHFCQUFxQixNQUFNQSxLQUFLLGVBQWU7QUFBQSxZQUMvQyxrQkFBa0IsTUFBTUEsS0FBSyxZQUFZO0FBQUEsWUFDekMsY0FBY2Q7QUFBQUEsWUFDZCxxQkFBcUIsTUFBTTtBQUN6QjBELGtDQUFvQixRQUFRO0FBQzVCRSw4QkFBZ0IsU0FBUztBQUFBLFlBQzNCO0FBQUEsWUFDQSxrQkFBa0IsTUFBTTlDLEtBQUssWUFBWTtBQUFBLFlBQ3pDLGVBQWUsQ0FBQ3hFLE9BQU87QUFDckI4RCx3Q0FBMEI5RCxFQUFFO0FBQzVCd0UsbUJBQUssY0FBYztBQUFBLFlBQ3JCO0FBQUE7QUFBQSxVQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFrQkk7QUFBQSxNQUdSLEtBQUs7QUFDSCxlQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0E7QUFBQSxZQUNBLFlBQVlqQjtBQUFBQTtBQUFBQSxVQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUc2QjtBQUFBLE1BR2pDLEtBQUs7QUFDSCxlQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQSxjQUFjRztBQUFBQSxZQUNkO0FBQUEsWUFDQSxrQkFBa0IsTUFBTVEsb0JBQW9CLENBQUNtRSxNQUFNLENBQUNBLENBQUM7QUFBQSxZQUNyRDtBQUFBLFlBQ0EsaUJBQWlCakU7QUFBQUEsWUFDakI7QUFBQSxZQUNBLGVBQWVOO0FBQUFBLFlBQ2Ysc0JBQXNCRTtBQUFBQSxZQUN0QixpQkFBaUIsTUFBTVEsS0FBSyxXQUFXO0FBQUEsWUFDdkMsY0FBYyxNQUFNQSxLQUFLLFFBQVE7QUFBQSxZQUNqQyx3QkFBd0IsTUFBTUEsS0FBSyxrQkFBa0I7QUFBQSxZQUNyRCxxQkFBcUIsTUFBTUEsS0FBSyxlQUFlO0FBQUEsWUFDL0MsZUFBZSxNQUFNQSxLQUFLLFNBQVM7QUFBQSxZQUNuQyxjQUFjLE1BQU1BLEtBQUssY0FBYztBQUFBLFlBQ3ZDLGVBQWUwQztBQUFBQSxZQUNmLGlCQUFpQixNQUFNMUMsS0FBSyxXQUFXO0FBQUEsWUFDdkMsWUFBWWpCO0FBQUFBLFlBQ1osV0FBVyxNQUFNaUIsS0FBSyxZQUFZO0FBQUE7QUFBQSxVQXJCcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBcUJzQztBQUFBLE1BRzFDLEtBQUs7QUFDSCxlQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0E7QUFBQSxZQUNBLHNCQUFzQixNQUFNakIsZUFBZSxVQUFVO0FBQUEsWUFDckQsa0JBQWtCLENBQUNqQyxXQUFXO0FBQzVCb0MsZ0NBQWtCcEMsTUFBTTtBQUN4QmlDLDZCQUFlLE9BQU87QUFBQSxZQUN4QjtBQUFBLFlBQ0EsbUJBQW1CLE1BQU1BLGVBQWUsT0FBTztBQUFBLFlBQy9DLG1CQUFtQixDQUFDbEMsWUFBWTtBQUM5QnlDLHdDQUEwQnpDLE9BQU87QUFDakNrQyw2QkFBZSxRQUFRO0FBQUEsWUFDekI7QUFBQSxZQUNBLG1CQUFtQixNQUFNaUIsS0FBSyxhQUFhO0FBQUE7QUFBQSxVQWI3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFhK0M7QUFBQSxNQUduRCxLQUFLO0FBQ0gsZUFDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBO0FBQUEsWUFDQSx5QkFBeUIsTUFBTUEsS0FBSyxtQkFBbUI7QUFBQTtBQUFBLFVBSHpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUcyRDtBQUFBLE1BRy9ELEtBQUs7QUFDSCxlQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0E7QUFBQSxZQUNBLGlCQUFpQnpIO0FBQUFBO0FBQUFBLFVBSG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdnQztBQUFBLE1BR3BDLEtBQUs7QUFDSCxlQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0E7QUFBQSxZQUNBLFlBQVl3RztBQUFBQTtBQUFBQSxVQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUc2QjtBQUFBLE1BR2pDLEtBQUs7QUFDSCxlQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0E7QUFBQSxZQUNBLFlBQVlBO0FBQUFBLFlBQ1osY0FBYyxDQUFDakMsV0FBVztBQUN4Qm9DLGdDQUFrQnBDLE1BQXFCO0FBQ3ZDaUMsNkJBQWUsT0FBTztBQUFBLFlBQ3hCO0FBQUE7QUFBQSxVQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9JO0FBQUEsTUFHUixLQUFLO0FBQ0gsZUFDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBO0FBQUEsWUFDQSxjQUFjLENBQUNqQyxXQUFXO0FBQ3hCb0MsZ0NBQWtCcEMsTUFBTTtBQUN4QmlDLDZCQUFlLE9BQU87QUFBQSxZQUN4QjtBQUFBO0FBQUEsVUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNSTtBQUFBLE1BR1IsS0FBSztBQUNILGVBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQSxZQUFZQTtBQUFBQSxZQUNaLGtCQUFrQixNQUFNaUIsS0FBSyxZQUFZO0FBQUE7QUFBQSxVQU4zQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNNkM7QUFBQSxNQUdqRCxLQUFLO0FBQ0gsZUFDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBO0FBQUEsWUFDQSxZQUFZakI7QUFBQUEsWUFDWix1QkFBdUIsTUFBTWlCLEtBQUssaUJBQWlCO0FBQUEsWUFDbkQsMkJBQTJCLE1BQU1BLEtBQUsscUJBQXFCO0FBQUEsWUFDM0QsY0FBYyxDQUFDbEQsV0FBVztBQUN4Qm9DLGdDQUFrQnBDLE1BQU07QUFDeEJpQyw2QkFBZSxPQUFPO0FBQUEsWUFDeEI7QUFBQTtBQUFBLFVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU0k7QUFBQSxNQUdSO0FBQ0UsZUFBTztBQUFBLElBQ1g7QUFBQSxFQUNGO0FBS0EsUUFBTStFLGNBQWNoUCxRQUFRLGFBQWE7QUFFekMsTUFBSSxDQUFDZ1AsYUFBYTtBQUNoQixXQUNFLHVCQUFDLDBCQUF1QixPQUFPLEVBQUV4TCxXQUFXQyxjQUFjQyxRQUFRLEdBQ2hFLGlDQUFDLG1CQUNDO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFlBQVlzRztBQUFBQSxVQUNaLFlBQVlDO0FBQUFBLFVBQ1osbUJBQ0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQSxVQUFVLE1BQU1BLGVBQWUsVUFBVTtBQUFBO0FBQUEsWUFGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRTZDO0FBQUEsVUFHL0MsY0FBYyxNQUFNaUIsS0FBSyxnQkFBZ0I7QUFBQSxVQUN6QyxrQkFBa0JLLGtCQUFrQm5ILFVBQVU7QUFBQSxVQUM5QyxpQkFBaUIsTUFBTThHLEtBQUssV0FBVztBQUFBLFVBQ3ZDO0FBQUEsVUFFQSxpQ0FBQyxZQUFTLFVBQVUsdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0IsR0FBTTJELHdCQUFjLEtBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThEO0FBQUE7QUFBQSxRQWRoRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFlQTtBQUFBLE1BQ0EsdUJBQUMsWUFBUyxVQUFVLE1BQ2xCLGlDQUFDLGtCQUFlLFFBQVExRSxnQkFBZ0IsU0FBUyxNQUFNQyxrQkFBa0IsSUFBSSxLQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStFLEtBRGpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsWUFBUyxVQUFVLE1BQ2xCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQSxZQUFZSDtBQUFBQSxVQUNaLHFCQUFxQm9EO0FBQUFBLFVBQ3JCLGVBQWVPO0FBQUFBLFVBQ2YsU0FBU2hCO0FBQUFBLFVBQ1QscUJBQXFCLE1BQU07QUFDekJrQixnQ0FBb0IsUUFBUTtBQUM1QkUsNEJBQWdCLFNBQVM7QUFBQSxVQUMzQjtBQUFBO0FBQUEsUUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BaUJJLEtBbEJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxTQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUNBLEtBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQ0E7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQywwQkFBdUIsT0FBTyxFQUFFeEssV0FBV0MsY0FBY0MsUUFBUSxHQUNoRSxpQ0FBQyxtQkFDRCxpQ0FBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsaUJBQWlCLHVCQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0I7QUFBQSxRQUNqQyxXQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFXRixhQUFhc0w7QUFBQUEsWUFDeEIsZUFBZSxDQUFDOUcsV0FBV29DLGtCQUFrQnBDLE1BQXFCO0FBQUE7QUFBQSxVQUZwRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFc0U7QUFBQSxRQUd4RTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLGtCQUFrQnVELGtCQUFrQm5ILFVBQVU7QUFBQSxRQUM5QztBQUFBLFFBQ0EsV0FBVyxNQUFNOEcsS0FBSyxZQUFZO0FBQUEsUUFDbEMsZ0JBQWdCLE1BQU1BLEtBQUssa0JBQWtCO0FBQUEsUUFDN0Msc0JBQXNCLE1BQU1BLEtBQUssZ0JBQWdCO0FBQUEsUUFDakQscUJBQXFCLE1BQU1BLEtBQUssZUFBZTtBQUFBLFFBQy9DLHNCQUFzQixNQUFNQSxLQUFLLGdCQUFnQjtBQUFBLFFBQ2pELHlCQUF5QixNQUFNQSxLQUFLLG1CQUFtQjtBQUFBLFFBQ3ZELHVCQUF1QixNQUFNQSxLQUFLLGlCQUFpQjtBQUFBLFFBQ25ELDJCQUEyQixNQUFNQSxLQUFLLHFCQUFxQjtBQUFBLFFBQzNELHlCQUF5QixNQUFNNEMsb0JBQW9CLE1BQU07QUFBQSxRQUN6RCxvQkFBb0IsTUFBTTVDLEtBQUssY0FBYztBQUFBLFFBQzdDLG9CQUFvQixNQUFNQSxLQUFLLGNBQWM7QUFBQSxRQUM3QyxpQkFBaUIsTUFBTUEsS0FBSyxXQUFXO0FBQUEsUUFDdkMscUJBQXFCLE1BQU1BLEtBQUssZUFBZTtBQUFBLFFBQy9DLG9CQUFvQixNQUFNO0FBQUVWLG9DQUEwQixJQUFJO0FBQUdVLGVBQUssY0FBYztBQUFBLFFBQUc7QUFBQSxRQUNuRixnQkFBZ0IsTUFBTTtBQUNwQixjQUFJdkQsU0FBU0ssUUFBUTtBQUNuQm9DLDhCQUFrQnpDLFNBQVNLLE1BQU07QUFDakNpQywyQkFBZSxPQUFPO0FBQ3RCO0FBQUEsVUFDRjtBQUNBQSx5QkFBZSxRQUFRO0FBQUEsUUFDekI7QUFBQSxRQUNBLG9CQUFvQixNQUFNaUIsS0FBSyxjQUFjO0FBQUEsUUFDN0MseUJBQXlCLE1BQU1BLEtBQUssbUJBQW1CO0FBQUE7QUFBQSxNQXRDekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBc0MyRDtBQUFBLElBRzNELHVCQUFDLGNBQVcsZUFBOEIsaUJBQWlCNEMsdUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0U7QUFBQSxJQUU5RXhDLGVBQ0MsdUJBQUMsVUFBTyxNQUFNQSxhQUFhLFdBQVd0QixhQUFhLGFBQWFnRSxtQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRjtBQUFBLElBR2xGLHVCQUFDLFNBQUksV0FBVSwrQkFDYixpQ0FBQyxrQkFBZSxTQUFTaEUsYUFDdkIsaUNBQUMsWUFBUyxVQUFVLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0IsR0FDckM2RSx3QkFBYyxLQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUEsS0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUVBLHVCQUFDLFlBQVMsVUFBVSxNQUNsQixpQ0FBQyxrQkFBZSxRQUFRMUUsZ0JBQWdCLFNBQVMsTUFBTUMsa0JBQWtCLElBQUksS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRSxLQURqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLFlBQVMsVUFBVSxNQUNsQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsWUFBWUg7QUFBQUEsUUFDWixxQkFBcUJvRDtBQUFBQSxRQUNyQixlQUFlTztBQUFBQSxRQUNmLFNBQVNoQjtBQUFBQSxRQUNULHFCQUFxQixNQUFNO0FBQ3pCa0IsOEJBQW9CLFFBQVE7QUFDNUJFLDBCQUFnQixTQUFTO0FBQUEsUUFDM0I7QUFBQTtBQUFBLE1BakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWlCSSxLQWxCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBO0FBQUEsT0FoRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlGQSxLQWxGQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUZBLEtBcEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxRkE7QUFFSjtBQUFDbEUsSUFqaUJ1QkQsS0FBRztBQUFBLFVBQ2UzSixpQkF5QkVKLGVBTzFCWCxVQUNDQSxVQUtRQSxVQStFUkQsYUFDQ0EsYUFDQVUsVUFHbEJDLHNCQStENkNnSCxrQkE0TnpCN0csT0FBTztBQUFBO0FBQUEsT0F0Wkw2SjtBQUFHLElBQUF2SixJQUFBSSxLQUFBRSxLQUFBQyxLQUFBRSxLQUFBQyxLQUFBRSxLQUFBQyxLQUFBRSxLQUFBQyxLQUFBRSxLQUFBQyxNQUFBRSxNQUFBQyxNQUFBRSxNQUFBQyxNQUFBRSxNQUFBQyxNQUFBRSxNQUFBQyxNQUFBRSxNQUFBQyxNQUFBRSxNQUFBQyxNQUFBRSxNQUFBQyxNQUFBRSxNQUFBQyxNQUFBZ00sTUFBQXZGLE1BQUFFLE1BQUFzRjtBQUFBLGFBQUE1TyxJQUFBO0FBQUEsYUFBQUksS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFDLE1BQUE7QUFBQSxhQUFBRSxNQUFBO0FBQUEsYUFBQUMsTUFBQTtBQUFBLGFBQUFFLE1BQUE7QUFBQSxhQUFBQyxNQUFBO0FBQUEsYUFBQUUsTUFBQTtBQUFBLGFBQUFDLE1BQUE7QUFBQSxhQUFBRSxNQUFBO0FBQUEsYUFBQUMsTUFBQTtBQUFBLGFBQUFFLE1BQUE7QUFBQSxhQUFBQyxNQUFBO0FBQUEsYUFBQUUsTUFBQTtBQUFBLGFBQUFDLE1BQUE7QUFBQSxhQUFBRSxNQUFBO0FBQUEsYUFBQUMsTUFBQTtBQUFBLGFBQUFFLE1BQUE7QUFBQSxhQUFBQyxNQUFBO0FBQUEsYUFBQWdNLE1BQUE7QUFBQSxhQUFBdkYsTUFBQTtBQUFBLGFBQUFFLE1BQUE7QUFBQSxhQUFBc0YsTUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZUNhbGxiYWNrIiwibGF6eSIsIlN1c3BlbnNlIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsIkFuaW1hdGVQcmVzZW5jZSIsIm1vdGlvbiIsImFwaSIsIkNvbW1hbmROYXYiLCJUYWJCYXIiLCJBcHBUb3BCYXIiLCJTSURFQkFSX1dJRFRIIiwiU2VhcmNoQmFyIiwidXNlVG9hc3QiLCJ1c2VLZXlib2FyZFNob3J0Y3V0cyIsInVzZU1vZGFsU3RhdGUiLCJQcml2YWN5UHJvdmlkZXIiLCJ1c2VGbGFnIiwiQXBwU2hlbGxWMiIsInVzZVNlYXJjaFBhcmFtcyIsIldvcmtzcGFjZVNjb3BlUHJvdmlkZXIiLCJ1c2VXb3Jrc3BhY2VTY29wZSIsIkRhc2hib2FyZE92ZXJ2aWV3IiwiX2MiLCJ0aGVuIiwibW9kdWxlIiwiZGVmYXVsdCIsIl9jMiIsIlRhc2tEcmF3ZXJUYWJzIiwiX2MzIiwiX2M0IiwiTW9kYWxMYXllciIsIl9jNSIsIl9jNiIsIk9wc1NlY3Rpb24iLCJfYzciLCJfYzgiLCJBZ2VudHNTZWN0aW9uIiwiX2M5IiwiX2MwIiwiQ2hhdFNlY3Rpb24iLCJfYzEiLCJfYzEwIiwiQ29udGVudFNlY3Rpb24iLCJfYzExIiwiX2MxMiIsIkNvbW1zU2VjdGlvbiIsIl9jMTMiLCJfYzE0IiwiS25vd2xlZGdlU2VjdGlvbiIsIl9jMTUiLCJfYzE2IiwiQ29kZVNlY3Rpb24iLCJfYzE3IiwiX2MxOCIsIlF1YWxpdHlTZWN0aW9uIiwiX2MxOSIsIl9jMjAiLCJQbGF0Zm9ybVNlY3Rpb24iLCJfYzIxIiwiX2MyMiIsIkhhcm5lc3NTZWN0aW9uIiwiX2MyMyIsIl9jMjQiLCJDb250cm9sU2VjdGlvbiIsIl9jMjUiLCJfYzI2IiwiUHJvamVjdFN3aXRjaGVyIiwib25NYW5hZ2UiLCJzaG93RGV0YWlscyIsIl9zIiwicHJvamVjdHMiLCJsaXN0IiwicHJvamVjdElkIiwic2V0UHJvamVjdElkIiwicHJvamVjdCIsImF2YWlsYWJsZVByb2plY3RzIiwiZmlsdGVyIiwiaXRlbSIsInN0YXR1cyIsInJlcG9zaXRvcnlTdGF0dXMiLCJnaXRodWJSZXBvIiwiZSIsInZhbHVlIiwidGFyZ2V0IiwibGVuZ3RoIiwibWFwIiwicCIsIl9pZCIsIm5hbWUiLCJnaXRodWJCcmFuY2giLCJ0b0xvd2VyQ2FzZSIsIlNUT1JBR0VfS0VZX1ZJRVciLCJTVE9SQUdFX0tFWV9QUk9KRUNUIiwicmVhZFJlcXVlc3RlZFByb2plY3RJZCIsIndpbmRvdyIsImZyb21VcmwiLCJVUkwiLCJsb2NhdGlvbiIsImhyZWYiLCJzZWFyY2hQYXJhbXMiLCJnZXQiLCJwZXJzaXN0ZWQiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiVkFMSURfTUFJTl9WSUVXUyIsInJlYWRQZXJzaXN0ZWRWaWV3IiwicmF3IiwidmlldyIsImluY2x1ZGVzIiwiU0VDVElPTl9ERUZBVUxUX1ZJRVciLCJob21lIiwiY29udHJvbCIsIm9wcyIsImFnZW50cyIsImNoYXQiLCJjb250ZW50IiwiY29tbXMiLCJrbm93bGVkZ2UiLCJjb2RlIiwicXVhbGl0eSIsInBsYXRmb3JtIiwiU0VDVElPTl9UQUJTIiwiaWQiLCJsYWJlbCIsInZpZXdUb1NlY3Rpb24iLCJ1c2VIZWFkZXJNZXRyaWNzIiwiX3MyIiwibGlzdEFsbCIsInRhc2tzIiwic3RhdHVzVGljayIsInNldFN0YXR1c1RpY2siLCJEYXRlIiwibm93IiwiYWN0aXZlQ291bnQiLCJhIiwidGFza0NvdW50IiwidGltZXIiLCJzZXRJbnRlcnZhbCIsImNsZWFySW50ZXJ2YWwiLCJhaVN0YXR1cyIsInRvbmUiLCJkZXRhaWwiLCJsYXN0U2VlbkxhYmVsIiwiYWdlbnRJZCIsInRhc2tJZCIsInRhc2tUaXRsZUJ5SWQiLCJNYXAiLCJ0YXNrIiwidGl0bGUiLCJmcmVzaGVzdEFnZW50Iiwic29ydCIsImxlZnQiLCJyaWdodCIsImxlZnRTdGFtcCIsImxhc3RIZWFydGJlYXRBdCIsInJpZ2h0U3RhbXAiLCJhZ2VNcyIsIk51bWJlciIsIlBPU0lUSVZFX0lORklOSVRZIiwidGFza1RpdGxlIiwiY3VycmVudFRhc2tJZCIsIk1hdGgiLCJmbG9vciIsIlBhZ2VUcmFuc2l0aW9uIiwiY2hpbGRyZW4iLCJ2aWV3S2V5Iiwib3BhY2l0eSIsInkiLCJkdXJhdGlvbiIsImVhc2UiLCJfYzI4IiwiU2VjdGlvbkxvYWRpbmdTdGF0ZSIsIl9jMjkiLCJBcHAiLCJfczMiLCJzZXRTZWFyY2hQYXJhbXMiLCJjdXJyZW50VmlldyIsInNldEN1cnJlbnRWaWV3IiwicmVxdWVzdGVkUHJvamVjdElkIiwic2VsZWN0ZWRUYXNrSWQiLCJzZXRTZWxlY3RlZFRhc2tJZCIsInNlbGVjdGVkUWNSdW5JZCIsInNldFNlbGVjdGVkUWNSdW5JZCIsInNpZGViYXJTZWxlY3RlZEFnZW50SWQiLCJzZXRTaWRlYmFyU2VsZWN0ZWRBZ2VudElkIiwic2lkZWJhcldpZHRoIiwic2V0U2lkZWJhcldpZHRoIiwibGl2ZUZlZWRFeHBhbmRlZCIsInNldExpdmVGZWVkRXhwYW5kZWQiLCJrYW5iYW5GaWx0ZXJzIiwic2V0S2FuYmFuRmlsdGVycyIsInByaW9yaXRpZXMiLCJ0eXBlcyIsIm1vZGFscyIsIm9wZW4iLCJjbG9zZSIsImNsb3NlQWxsIiwiYWN0aXZlU2VjdGlvbiIsInNlY3Rpb25UYWJzIiwicGVuZGluZ0FwcHJvdmFscyIsImFwcHJvdmFscyIsImxpc3RQZW5kaW5nIiwibGltaXQiLCJzb21lIiwicHJlZmVycmVkIiwiZmluZCIsInRyaW0iLCJzZXRJdGVtIiwiY3VycmVudCIsIm5leHQiLCJVUkxTZWFyY2hQYXJhbXMiLCJzZXQiLCJyZXBsYWNlIiwicGF1c2VDb25maXJtIiwiaGFuZGxlciIsImtleSIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwicGF1c2VBbGwiLCJyZXN1bWVBbGwiLCJ0b2FzdCIsIm9uTmV3VGFzayIsIm9uU2VhcmNoIiwib25BcHByb3ZhbHMiLCJvbkFnZW50cyIsIm9uQ29zdEFuYWx5dGljcyIsIm9uR29Ub0JvYXJkIiwib25TaG93SGVscCIsIm9uTWlzc2lvbiIsImhhbmRsZUNvbmZpcm1QYXVzZVNxdWFkIiwicmVzdWx0IiwicmVhc29uIiwidXNlcklkIiwicGF1c2VkIiwiRXJyb3IiLCJtZXNzYWdlIiwiaGFuZGxlUmVzdW1lU3F1YWQiLCJyZXN1bWVkIiwiaGFuZGxlU2VjdGlvbkNoYW5nZSIsInNlY3Rpb24iLCJoYW5kbGVUYWJDaGFuZ2UiLCJ0YWJJZCIsInRpbWVTdHIiLCJ0b0xvY2FsZVRpbWVTdHJpbmciLCJob3VyIiwibWludXRlIiwic2Vjb25kIiwiZGF0ZVN0ciIsInRvTG9jYWxlRGF0ZVN0cmluZyIsIndlZWtkYXkiLCJtb250aCIsImRheSIsInRvVXBwZXJDYXNlIiwicmVuZGVyU2VjdGlvbiIsInVuZGVmaW5lZCIsInYiLCJsZWdhY3lTaGVsbCIsIl9jMjciLCJfYzMwIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlQ2FsbGJhY2ssIGxhenksIFN1c3BlbnNlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnkgfSBmcm9tIFwiY29udmV4L3JlYWN0XCI7XG5pbXBvcnQgeyBBbmltYXRlUHJlc2VuY2UsIG1vdGlvbiB9IGZyb20gXCJmcmFtZXItbW90aW9uXCI7XG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvYXBpXCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgdHlwZSBNYWluVmlldywgdHlwZSBDb21tYW5kU2VjdGlvbiB9IGZyb20gXCIuL1RvcE5hdlwiO1xuaW1wb3J0IHsgQ29tbWFuZE5hdiB9IGZyb20gXCIuL2NvbXBvbmVudHMvQ29tbWFuZE5hdlwiO1xuaW1wb3J0IHsgVGFiQmFyLCB0eXBlIFRhYkl0ZW0gfSBmcm9tIFwiLi9jb21wb25lbnRzL1RhYkJhclwiO1xuaW1wb3J0IHsgQXBwVG9wQmFyIH0gZnJvbSBcIi4vY29tcG9uZW50cy9BcHBUb3BCYXJcIjtcbmltcG9ydCB7IFNpZGViYXIsIFNJREVCQVJfV0lEVEggfSBmcm9tIFwiLi9TaWRlYmFyXCI7XG5pbXBvcnQgeyBTZWFyY2hCYXIgfSBmcm9tIFwiLi9TZWFyY2hCYXJcIjtcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSBcIi4vVG9hc3RcIjtcbmltcG9ydCB7IHVzZUtleWJvYXJkU2hvcnRjdXRzIH0gZnJvbSBcIi4vS2V5Ym9hcmRTaG9ydGN1dHNcIjtcbmltcG9ydCB7IHVzZU1vZGFsU3RhdGUgfSBmcm9tIFwiLi9ob29rcy91c2VNb2RhbFN0YXRlXCI7XG5pbXBvcnQgeyBQcml2YWN5UHJvdmlkZXIgfSBmcm9tIFwiLi9jb250ZXh0cy9Qcml2YWN5Q29udGV4dFwiO1xuaW1wb3J0IHsgdXNlRmxhZyB9IGZyb20gXCIuL2hvb2tzL3VzZUZsYWdcIjtcbmltcG9ydCB7IEFwcFNoZWxsVjIgfSBmcm9tIFwiLi9zaGVsbFYyL0FwcFNoZWxsVjJcIjtcbmltcG9ydCB7IHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQge1xuICBXb3Jrc3BhY2VTY29wZVByb3ZpZGVyLFxuICB1c2VXb3Jrc3BhY2VTY29wZSxcbn0gZnJvbSBcIi4vd29ya3NwYWNlL1dvcmtzcGFjZVNjb3BlUHJvdmlkZXJcIjtcblxuY29uc3QgRGFzaGJvYXJkT3ZlcnZpZXcgPSBsYXp5KCgpID0+XG4gIGltcG9ydChcIi4vRGFzaGJvYXJkT3ZlcnZpZXdcIikudGhlbigobW9kdWxlKSA9PiAoeyBkZWZhdWx0OiBtb2R1bGUuRGFzaGJvYXJkT3ZlcnZpZXcgfSkpXG4pO1xuY29uc3QgVGFza0RyYXdlclRhYnMgPSBsYXp5KCgpID0+XG4gIGltcG9ydChcIi4vVGFza0RyYXdlclRhYnNcIikudGhlbigobW9kdWxlKSA9PiAoeyBkZWZhdWx0OiBtb2R1bGUuVGFza0RyYXdlclRhYnMgfSkpXG4pO1xuY29uc3QgTW9kYWxMYXllciA9IGxhenkoKCkgPT5cbiAgaW1wb3J0KFwiLi9Nb2RhbExheWVyXCIpLnRoZW4oKG1vZHVsZSkgPT4gKHsgZGVmYXVsdDogbW9kdWxlLk1vZGFsTGF5ZXIgfSkpXG4pO1xuY29uc3QgT3BzU2VjdGlvbiA9IGxhenkoKCkgPT5cbiAgaW1wb3J0KFwiLi9zZWN0aW9ucy9PcHNTZWN0aW9uXCIpLnRoZW4oKG1vZHVsZSkgPT4gKHsgZGVmYXVsdDogbW9kdWxlLk9wc1NlY3Rpb24gfSkpXG4pO1xuY29uc3QgQWdlbnRzU2VjdGlvbiA9IGxhenkoKCkgPT5cbiAgaW1wb3J0KFwiLi9zZWN0aW9ucy9BZ2VudHNTZWN0aW9uXCIpLnRoZW4oKG1vZHVsZSkgPT4gKHsgZGVmYXVsdDogbW9kdWxlLkFnZW50c1NlY3Rpb24gfSkpXG4pO1xuY29uc3QgQ2hhdFNlY3Rpb24gPSBsYXp5KCgpID0+XG4gIGltcG9ydChcIi4vc2VjdGlvbnMvQ2hhdFNlY3Rpb25cIikudGhlbigobW9kdWxlKSA9PiAoeyBkZWZhdWx0OiBtb2R1bGUuQ2hhdFNlY3Rpb24gfSkpXG4pO1xuY29uc3QgQ29udGVudFNlY3Rpb24gPSBsYXp5KCgpID0+XG4gIGltcG9ydChcIi4vc2VjdGlvbnMvQ29udGVudFNlY3Rpb25cIikudGhlbigobW9kdWxlKSA9PiAoeyBkZWZhdWx0OiBtb2R1bGUuQ29udGVudFNlY3Rpb24gfSkpXG4pO1xuY29uc3QgQ29tbXNTZWN0aW9uID0gbGF6eSgoKSA9PlxuICBpbXBvcnQoXCIuL3NlY3Rpb25zL0NvbW1zU2VjdGlvblwiKS50aGVuKChtb2R1bGUpID0+ICh7IGRlZmF1bHQ6IG1vZHVsZS5Db21tc1NlY3Rpb24gfSkpXG4pO1xuY29uc3QgS25vd2xlZGdlU2VjdGlvbiA9IGxhenkoKCkgPT5cbiAgaW1wb3J0KFwiLi9zZWN0aW9ucy9Lbm93bGVkZ2VTZWN0aW9uXCIpLnRoZW4oKG1vZHVsZSkgPT4gKHsgZGVmYXVsdDogbW9kdWxlLktub3dsZWRnZVNlY3Rpb24gfSkpXG4pO1xuY29uc3QgQ29kZVNlY3Rpb24gPSBsYXp5KCgpID0+XG4gIGltcG9ydChcIi4vc2VjdGlvbnMvQ29kZVNlY3Rpb25cIikudGhlbigobW9kdWxlKSA9PiAoeyBkZWZhdWx0OiBtb2R1bGUuQ29kZVNlY3Rpb24gfSkpXG4pO1xuY29uc3QgUXVhbGl0eVNlY3Rpb24gPSBsYXp5KCgpID0+XG4gIGltcG9ydChcIi4vc2VjdGlvbnMvUXVhbGl0eVNlY3Rpb25cIikudGhlbigobW9kdWxlKSA9PiAoeyBkZWZhdWx0OiBtb2R1bGUuUXVhbGl0eVNlY3Rpb24gfSkpXG4pO1xuY29uc3QgUGxhdGZvcm1TZWN0aW9uID0gbGF6eSgoKSA9PlxuICBpbXBvcnQoXCIuL3NlY3Rpb25zL1BsYXRmb3JtU2VjdGlvblwiKS50aGVuKChtb2R1bGUpID0+ICh7IGRlZmF1bHQ6IG1vZHVsZS5QbGF0Zm9ybVNlY3Rpb24gfSkpXG4pO1xuY29uc3QgSGFybmVzc1NlY3Rpb24gPSBsYXp5KCgpID0+XG4gIGltcG9ydChcIi4vaGFybmVzcy9IYXJuZXNzU2VjdGlvblwiKS50aGVuKChtb2R1bGUpID0+ICh7IGRlZmF1bHQ6IG1vZHVsZS5IYXJuZXNzU2VjdGlvbiB9KSlcbik7XG5jb25zdCBDb250cm9sU2VjdGlvbiA9IGxhenkoKCkgPT5cbiAgaW1wb3J0KFwiLi9zZWN0aW9ucy9Db250cm9sU2VjdGlvblwiKS50aGVuKChtb2R1bGUpID0+ICh7IGRlZmF1bHQ6IG1vZHVsZS5Db250cm9sU2VjdGlvbiB9KSlcbik7XG5cbnR5cGUgU2hlbGxBaVRvbmUgPSBcImFjdGl2ZVwiIHwgXCJ0aGlua2luZ1wiIHwgXCJpZGxlXCIgfCBcIm9mZmxpbmVcIjtcblxuaW50ZXJmYWNlIFNoZWxsQWlTdGF0dXMge1xuICB0b25lOiBTaGVsbEFpVG9uZTtcbiAgbGFiZWw6IHN0cmluZztcbiAgZGV0YWlsOiBzdHJpbmc7XG4gIGxhc3RTZWVuTGFiZWw6IHN0cmluZztcbiAgYWdlbnRJZDogSWQ8XCJhZ2VudHNcIj4gfCBudWxsO1xuICB0YXNrSWQ6IElkPFwidGFza3NcIj4gfCBudWxsO1xufVxuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBQUk9KRUNUIFNXSVRDSEVSXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbmZ1bmN0aW9uIFByb2plY3RTd2l0Y2hlcih7XG4gIG9uTWFuYWdlLFxuICBzaG93RGV0YWlscyA9IGZhbHNlLFxufToge1xuICBvbk1hbmFnZT86ICgpID0+IHZvaWQ7XG4gIHNob3dEZXRhaWxzPzogYm9vbGVhbjtcbn0pIHtcbiAgY29uc3QgcHJvamVjdHMgPSB1c2VRdWVyeShhcGkucHJvamVjdHMubGlzdCk7XG4gIGNvbnN0IHsgcHJvamVjdElkLCBzZXRQcm9qZWN0SWQsIHByb2plY3QgfSA9IHVzZVdvcmtzcGFjZVNjb3BlKCk7XG5cbiAgaWYgKCFwcm9qZWN0cykge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtOCBtaW4tdy1bMTQwcHhdIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1pbnB1dCBiZy1zZWNvbmRhcnkvNTAgcHgtMyB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICBMb2FkaW5nIHByb2plY3RzLi4uXG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgY29uc3QgYXZhaWxhYmxlUHJvamVjdHMgPSBwcm9qZWN0cy5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0uc3RhdHVzICE9PSBcIkFSQ0hJVkVEXCIpO1xuICBjb25zdCByZXBvc2l0b3J5U3RhdHVzID1cbiAgICBwcm9qZWN0Py5yZXBvc2l0b3J5U3RhdHVzID8/IChwcm9qZWN0Py5naXRodWJSZXBvID8gXCJDT05GSUdVUkVEXCIgOiBcIlVOQ09ORklHVVJFRFwiKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICA8c2VsZWN0XG4gICAgICAgIGFyaWEtbGFiZWw9XCJXb3Jrc3BhY2VcIlxuICAgICAgICB2YWx1ZT17cHJvamVjdElkID8/IFwiXCJ9XG4gICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgIGNvbnN0IHZhbHVlID0gZS50YXJnZXQudmFsdWU7XG4gICAgICAgICAgaWYgKHZhbHVlKSBzZXRQcm9qZWN0SWQodmFsdWUgYXMgSWQ8XCJwcm9qZWN0c1wiPik7XG4gICAgICAgIH19XG4gICAgICAgIGNsYXNzTmFtZT1cImgtOSBtaW4tdy1bMTY4cHhdIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMSBweC0zIHRleHQtWzEzLjVweF0gZm9udC1tZWRpdW0gdGV4dC1pbmsgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGN1cnNvci1wb2ludGVyIGhvdmVyOmJvcmRlci1saW5lLXN0cm9uZyBmb2N1cy12aXNpYmxlOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctcmluZ1wiXG4gICAgICA+XG4gICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIiBkaXNhYmxlZD5cbiAgICAgICAgICB7YXZhaWxhYmxlUHJvamVjdHMubGVuZ3RoID09PSAwID8gXCJObyB3b3Jrc3BhY2VzXCIgOiBcIlNlbGVjdCB3b3Jrc3BhY2VcIn1cbiAgICAgICAgPC9vcHRpb24+XG4gICAgICAgIHthdmFpbGFibGVQcm9qZWN0cy5tYXAoKHApID0+IChcbiAgICAgICAgICA8b3B0aW9uIGtleT17cC5faWR9IHZhbHVlPXtwLl9pZH0+XG4gICAgICAgICAgICB7cC5uYW1lfVxuICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICApKX1cbiAgICAgIDwvc2VsZWN0PlxuICAgICAge3Nob3dEZXRhaWxzID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMiBweC0yLjUgcHktMlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidHJ1bmNhdGUgZm9udC1tb25vIHRleHQtWzEwLjVweF0gdGV4dC1pbmstc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICB7cHJvamVjdD8uZ2l0aHViUmVwbyA/PyBcIk5vIHJlcG9zaXRvcnkgY29ubmVjdGVkXCJ9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiB0ZXh0LVsxMHB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAge3Byb2plY3Q/LmdpdGh1YlJlcG9cbiAgICAgICAgICAgICAgICA/IGAke3Byb2plY3QuZ2l0aHViQnJhbmNoIHx8IFwibWFpblwifSDCtyAke3JlcG9zaXRvcnlTdGF0dXMudG9Mb3dlckNhc2UoKX1gXG4gICAgICAgICAgICAgICAgOiBcIlNldHVwIHJlcXVpcmVkXCJ9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICB7b25NYW5hZ2UgPyAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbk1hbmFnZX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzaHJpbmstMCBmb250LW1lZGl1bSB0ZXh0LWluay1zZWNvbmRhcnkgaG92ZXI6dGV4dC1pbmtcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgTWFuYWdlXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IG51bGx9XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbi8vIFZJRVcgUEVSU0lTVEVOQ0UgKHJlb3BlbiB3aGVyZSBvcGVyYXRvciBsZWZ0IG9mZilcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuY29uc3QgU1RPUkFHRV9LRVlfVklFVyA9IFwibWMubGFzdF92aWV3XCI7XG5jb25zdCBTVE9SQUdFX0tFWV9QUk9KRUNUID0gXCJtYy5sYXN0X3Byb2plY3RcIjtcblxuZnVuY3Rpb24gcmVhZFJlcXVlc3RlZFByb2plY3RJZCgpOiBzdHJpbmcgfCBudWxsIHtcbiAgaWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBudWxsO1xuICB0cnkge1xuICAgIGNvbnN0IGZyb21VcmwgPSBuZXcgVVJMKHdpbmRvdy5sb2NhdGlvbi5ocmVmKS5zZWFyY2hQYXJhbXMuZ2V0KFwid29ya3NwYWNlXCIpO1xuICAgIGlmIChmcm9tVXJsKSByZXR1cm4gZnJvbVVybCBhcyBJZDxcInByb2plY3RzXCI+O1xuICAgIGNvbnN0IHBlcnNpc3RlZCA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShTVE9SQUdFX0tFWV9QUk9KRUNUKTtcbiAgICByZXR1cm4gcGVyc2lzdGVkID8gKHBlcnNpc3RlZCBhcyBJZDxcInByb2plY3RzXCI+KSA6IG51bGw7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbmNvbnN0IFZBTElEX01BSU5fVklFV1M6IE1haW5WaWV3W10gPSBbXG4gIFwiaG9tZVwiLCBcImF0Y1wiLCBcInRhc2tzXCIsIFwiYWdlbnRzXCIsIFwiZGlyZWN0b3J5XCIsIFwicG9saWNpZXNcIiwgXCJkZXBsb3ltZW50c1wiLCBcImF1ZGl0XCIsIFwidGVsZW1ldHJ5XCIsIFwiYXV0b21hdGlvbnNcIiwgXCJhdXRvbWF0aW9uLXJ1bnNcIixcbiAgXCJkYWdcIiwgXCJjaGF0XCIsIFwiY291bmNpbFwiLCBcImNhbGVuZGFyXCIsIFwicHJvamVjdHNcIiwgXCJtb2RlbC1yb3V0aW5nXCIsIFwibWVtb3J5XCIsIFwiY2FwdHVyZXNcIiwgXCJkb2NzXCIsIFwic2tpbGxzXCIsIFwicGVvcGxlXCIsIFwib3JnXCIsXG4gIFwiZGVzaWduLXN5c3RlbVwiLFxuICBcIm9mZmljZVwiLCBcImxpdmUtb2ZmaWNlXCIsIFwic2VhcmNoXCIsIFwiaWRlbnRpdHlcIiwgXCJ0ZWxlZ3JhcGhcIiwgXCJtZWV0aW5nc1wiLCBcInZvaWNlXCIsIFwiY29udGVudC1waXBlbGluZVwiLFxuICBcImNybVwiLCBcImNvbW1hbmRcIiwgXCJjb2RlXCIsIFwicmVjb3JkZXJcIiwgXCJ0ZXN0LWdlbmVyYXRpb25cIiwgXCJhcGktaW1wb3J0XCIsIFwiZXhlY3V0aW9uXCIsIFwiZmxha3ktc3RlcHNcIixcbiAgXCJoeWJyaWQtd29ya2Zsb3dzXCIsIFwic2NoZWR1bGVcIiwgXCJjb2RlZ2VuXCIsIFwiZ2hlcmtpblwiLCBcIm1ldHJpY3NcIiwgXCJxYy1kYXNoYm9hcmRcIiwgXCJxYy1ydW5zXCIsXG4gIFwicWMtZW52aXJvbm1lbnRzXCIsIFwicWMtZmluZGluZ3NcIiwgXCJxYy1tZXRyaWNzXCIsIFwicWMtcnVsZXNldHNcIiwgXCJnYXRld2F5XCIsIFwibGl2ZS1jaGF0XCIsIFwic2NoZWR1bGVzXCIsXG4gIFwiaGlyaW5nXCIsIFwidGVhbVwiLCBcInN5c3RlbVwiLCBcInJhZGFyXCIsIFwiZmFjdG9yeVwiLCBcInBpcGVsaW5lXCIsIFwiZmVlZGJhY2tcIiwgXCJvcHMtc2NoZWR1bGVcIiwgXCJnb2Fsc1wiLFxuICBcImFuYWx5dGljc1wiLCBcImNvbW1hbmQtY2VudGVyXCIsIFwibWlzc2lvbnNcIiwgXCJtaXNzaW9uLWRldGFpbFwiLCBcInRyYWNlLWluc3BlY3RvclwiLCBcImVmZmVjdGl2ZW5lc3NcIixcbiAgXCJmYWN0b3J5LWhlYWx0aFwiLCBcInJlYWRpbmVzc1wiLCBcImZyaWN0aW9uXCIsIFwiYWdlbnQtY2F0YWxvZ1wiLCBcImRvc3NpZXJcIiwgXCJyZWNvbW1lbmRhdGlvbnNcIixcbiAgXCJjb250cm9sLXBvcnRmb2xpb1wiLCBcImNvbnRyb2wtd29yay1vcmRlcnNcIiwgXCJjb250cm9sLWZsZWV0XCIsIFwiY29udHJvbC1hcHByb3ZhbHNcIixcbiAgXCJoYXJuZXNzLWhlYWx0aFwiLCBcImhhcm5lc3MtbG9vcHNcIiwgXCJoYXJuZXNzLWNvbnRyb2wtcGxhbmVcIiwgXCJoYXJuZXNzLXdvcmstbGVkZ2VyXCIsXG4gIFwiaGFybmVzcy12ZXJpZmllcnNcIiwgXCJoYXJuZXNzLWNoYW5nZS1yZXZpZXdcIiwgXCJoYXJuZXNzLWNoYW5nZS1yaXNrXCIsIFwiaGFybmVzcy1sYXVuY2hcIixcbiAgXCJoYXJuZXNzLW1ldGEtbG9vcFwiLCBcImhhcm5lc3MtdGVhbS1wdWxzZVwiLCBcImhhcm5lc3MtYnVpbGRlclwiLCBcImhhcm5lc3MtbWFpbnRlbmFuY2VcIiwgXCJoYXJuZXNzLWNvZGUtcmV2aWV3LXdpemFyZFwiLFxuICBcImhhcm5lc3Mtd29ya3Nob3BcIiwgXCJoYXJuZXNzLWF1dG9tYXRpb25zXCIsIFwiaGFybmVzcy1hZ2VudC1mbGVldFwiLCBcImhhcm5lc3Mtc29mdHdhcmUtZmFjdG9yeVwiLCBcImhhcm5lc3MtYXJjaGl0ZWN0XCIsIFwiaGFybmVzcy1wYXR0ZXJuc1wiLFxuICBcInJlZ2lzdHJ5LWxpZmVjeWNsZVwiLCBcInJlZ2lzdHJ5LWV2YWx1YXRlXCIsIFwicmVnaXN0cnktaW52ZW50b3J5XCIsIFwicmVnaXN0cnktaW5zdGFsbGF0aW9uc1wiLCBcInJlZ2lzdHJ5LXJ1bnNcIixcbl07XG5cbmZ1bmN0aW9uIHJlYWRQZXJzaXN0ZWRWaWV3KCk6IE1haW5WaWV3IHwgbnVsbCB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gbnVsbDtcbiAgdHJ5IHtcbiAgICBjb25zdCByYXcgPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oU1RPUkFHRV9LRVlfVklFVyk7XG4gICAgaWYgKCFyYXcpIHJldHVybiBudWxsO1xuICAgIGNvbnN0IHZpZXcgPSByYXcgYXMgTWFpblZpZXc7XG4gICAgcmV0dXJuIFZBTElEX01BSU5fVklFV1MuaW5jbHVkZXModmlldykgPyB2aWV3IDogbnVsbDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gU0VDVElPTiA8LT4gVklFVyBNQVBQSU5HXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbmNvbnN0IFNFQ1RJT05fREVGQVVMVF9WSUVXOiBSZWNvcmQ8Q29tbWFuZFNlY3Rpb24sIE1haW5WaWV3PiA9IHtcbiAgaG9tZTogXCJob21lXCIsXG4gIGNvbnRyb2w6IFwiaGFybmVzcy1oZWFsdGhcIixcbiAgb3BzOiBcInRhc2tzXCIsXG4gIGFnZW50czogXCJhZ2VudHNcIixcbiAgY2hhdDogXCJjaGF0XCIsXG4gIGNvbnRlbnQ6IFwiY29udGVudC1waXBlbGluZVwiLFxuICBjb21tczogXCJ0ZWxlZ3JhcGhcIixcbiAga25vd2xlZGdlOiBcImRvY3NcIixcbiAgY29kZTogXCJjb2RlXCIsXG4gIHF1YWxpdHk6IFwicWMtZGFzaGJvYXJkXCIsXG4gIHBsYXRmb3JtOiBcInN5c3RlbVwiLFxufTtcblxuY29uc3QgU0VDVElPTl9UQUJTOiBSZWNvcmQ8Q29tbWFuZFNlY3Rpb24sIFRhYkl0ZW1bXSB8IG51bGw+ID0ge1xuICBob21lOiBudWxsLFxuICBjb250cm9sOiBbXG4gICAgeyBpZDogXCJjb250cm9sLXBvcnRmb2xpb1wiLCBsYWJlbDogXCJQb3J0Zm9saW9cIiB9LFxuICAgIHsgaWQ6IFwiY29udHJvbC13b3JrLW9yZGVyc1wiLCBsYWJlbDogXCJXb3JrIE9yZGVyc1wiIH0sXG4gICAgeyBpZDogXCJjb250cm9sLWZsZWV0XCIsIGxhYmVsOiBcIkZsZWV0XCIgfSxcbiAgICB7IGlkOiBcImNvbnRyb2wtYXBwcm92YWxzXCIsIGxhYmVsOiBcIkFwcHJvdmFsc1wiIH0sXG4gIF0sXG4gIG9wczogW1xuICAgIHsgaWQ6IFwidGFza3NcIiwgbGFiZWw6IFwiVGFza3NcIiB9LFxuICAgIHsgaWQ6IFwiZ29hbHNcIiwgbGFiZWw6IFwiR29hbHNcIiB9LFxuICAgIHsgaWQ6IFwiZGFnXCIsIGxhYmVsOiBcIkRBR1wiIH0sXG4gICAgeyBpZDogXCJjYWxlbmRhclwiLCBsYWJlbDogXCJDYWxlbmRhclwiIH0sXG4gICAgeyBpZDogXCJvcHMtc2NoZWR1bGVcIiwgbGFiZWw6IFwiU2NoZWR1bGVcIiB9LFxuICAgIHsgaWQ6IFwiYXVkaXRcIiwgbGFiZWw6IFwiQXVkaXRcIiB9LFxuICAgIHsgaWQ6IFwidGVsZW1ldHJ5XCIsIGxhYmVsOiBcIlRlbGVtZXRyeVwiIH0sXG4gICAgeyBpZDogXCJhdXRvbWF0aW9uc1wiLCBsYWJlbDogXCJBdXRvbWF0aW9uc1wiIH0sXG4gIF0sXG4gIGFnZW50czogW1xuICAgIHsgaWQ6IFwiYXRjXCIsIGxhYmVsOiBcIkFUQ1wiIH0sXG4gICAgeyBpZDogXCJhZ2VudHNcIiwgbGFiZWw6IFwiUmVnaXN0cnlcIiB9LFxuICAgIHsgaWQ6IFwiZGlyZWN0b3J5XCIsIGxhYmVsOiBcIlRlbXBsYXRlc1wiIH0sXG4gICAgeyBpZDogXCJpZGVudGl0eVwiLCBsYWJlbDogXCJJZGVudGl0aWVzXCIgfSxcbiAgICB7IGlkOiBcInBvbGljaWVzXCIsIGxhYmVsOiBcIlBvbGljaWVzXCIgfSxcbiAgICB7IGlkOiBcImRlcGxveW1lbnRzXCIsIGxhYmVsOiBcIkRlcGxveW1lbnRzXCIgfSxcbiAgICB7IGlkOiBcImdhdGV3YXlcIiwgbGFiZWw6IFwiR2F0ZXdheVwiIH0sXG4gICAgeyBpZDogXCJzY2hlZHVsZXNcIiwgbGFiZWw6IFwiU2NoZWR1bGVzXCIgfSxcbiAgXSxcbiAgY2hhdDogW1xuICAgIHsgaWQ6IFwiY2hhdFwiLCBsYWJlbDogXCJDaGF0XCIgfSxcbiAgICB7IGlkOiBcImxpdmUtY2hhdFwiLCBsYWJlbDogXCJMaXZlXCIgfSxcbiAgICB7IGlkOiBcImNvdW5jaWxcIiwgbGFiZWw6IFwiQ291bmNpbFwiIH0sXG4gICAgeyBpZDogXCJjb21tYW5kXCIsIGxhYmVsOiBcIkNvbW1hbmRcIiB9LFxuICBdLFxuICBjb250ZW50OiBbXG4gICAgeyBpZDogXCJjb250ZW50LXBpcGVsaW5lXCIsIGxhYmVsOiBcIlBpcGVsaW5lXCIgfSxcbiAgICB7IGlkOiBcImNhcHR1cmVzXCIsIGxhYmVsOiBcIkNhcHR1cmVzXCIgfSxcbiAgICB7IGlkOiBcInByb2plY3RzXCIsIGxhYmVsOiBcIlByb2plY3RzXCIgfSxcbiAgXSxcbiAgY29tbXM6IFtcbiAgICB7IGlkOiBcInRlbGVncmFwaFwiLCBsYWJlbDogXCJUZWxlZ3JhcGhcIiB9LFxuICAgIHsgaWQ6IFwibWVldGluZ3NcIiwgbGFiZWw6IFwiTWVldGluZ3NcIiB9LFxuICAgIHsgaWQ6IFwidm9pY2VcIiwgbGFiZWw6IFwiVm9pY2VcIiB9LFxuICAgIHsgaWQ6IFwiY3JtXCIsIGxhYmVsOiBcIkNSTVwiIH0sXG4gICAgeyBpZDogXCJwZW9wbGVcIiwgbGFiZWw6IFwiUGVvcGxlXCIgfSxcbiAgICB7IGlkOiBcInRlYW1cIiwgbGFiZWw6IFwiVGVhbVwiIH0sXG4gICAgeyBpZDogXCJvcmdcIiwgbGFiZWw6IFwiT3JnIENoYXJ0XCIgfSxcbiAgICB7IGlkOiBcIm9mZmljZVwiLCBsYWJlbDogXCJPZmZpY2VcIiB9LFxuICAgIHsgaWQ6IFwibGl2ZS1vZmZpY2VcIiwgbGFiZWw6IFwiTGl2ZSBPZmZpY2VcIiB9LFxuICAgIHsgaWQ6IFwiaGlyaW5nXCIsIGxhYmVsOiBcIkhpcmluZ1wiIH0sXG4gIF0sXG4gIGtub3dsZWRnZTogW1xuICAgIHsgaWQ6IFwiZG9jc1wiLCBsYWJlbDogXCJLbm93bGVkZ2VcIiB9LFxuICAgIHsgaWQ6IFwiZGVzaWduLXN5c3RlbVwiLCBsYWJlbDogXCJEZXNpZ24gRE5BXCIgfSxcbiAgICB7IGlkOiBcInNraWxsc1wiLCBsYWJlbDogXCJEaXNjb3ZlciBza2lsbHNcIiB9LFxuICAgIHsgaWQ6IFwibWVtb3J5XCIsIGxhYmVsOiBcIk1lbW9yeVwiIH0sXG4gICAgeyBpZDogXCJzZWFyY2hcIiwgbGFiZWw6IFwiU2VhcmNoXCIgfSxcbiAgXSxcbiAgY29kZTogW1xuICAgIHsgaWQ6IFwiY29kZVwiLCBsYWJlbDogXCJQaXBlbGluZVwiIH0sXG4gICAgeyBpZDogXCJyZWNvcmRlclwiLCBsYWJlbDogXCJSZWNvcmRlclwiIH0sXG4gICAgeyBpZDogXCJ0ZXN0LWdlbmVyYXRpb25cIiwgbGFiZWw6IFwiVGVzdHNcIiB9LFxuICAgIHsgaWQ6IFwiYXBpLWltcG9ydFwiLCBsYWJlbDogXCJBUEkgSW1wb3J0XCIgfSxcbiAgICB7IGlkOiBcImV4ZWN1dGlvblwiLCBsYWJlbDogXCJFeGVjdXRpb25cIiB9LFxuICAgIHsgaWQ6IFwiZmxha3ktc3RlcHNcIiwgbGFiZWw6IFwiRmxha3lcIiB9LFxuICAgIHsgaWQ6IFwiaHlicmlkLXdvcmtmbG93c1wiLCBsYWJlbDogXCJIeWJyaWRcIiB9LFxuICAgIHsgaWQ6IFwic2NoZWR1bGVcIiwgbGFiZWw6IFwiU2NoZWR1bGVcIiB9LFxuICAgIHsgaWQ6IFwiY29kZWdlblwiLCBsYWJlbDogXCJDb2RlR2VuXCIgfSxcbiAgICB7IGlkOiBcImdoZXJraW5cIiwgbGFiZWw6IFwiR2hlcmtpblwiIH0sXG4gICAgeyBpZDogXCJtZXRyaWNzXCIsIGxhYmVsOiBcIk1ldHJpY3NcIiB9LFxuICBdLFxuICBxdWFsaXR5OiBbXG4gICAgeyBpZDogXCJxYy1kYXNoYm9hcmRcIiwgbGFiZWw6IFwiRGFzaGJvYXJkXCIgfSxcbiAgICB7IGlkOiBcInFjLXJ1bnNcIiwgbGFiZWw6IFwiUnVuc1wiIH0sXG4gICAgeyBpZDogXCJxYy1lbnZpcm9ubWVudHNcIiwgbGFiZWw6IFwiRW52aXJvbm1lbnRzXCIgfSxcbiAgICB7IGlkOiBcInFjLWZpbmRpbmdzXCIsIGxhYmVsOiBcIkZpbmRpbmdzXCIgfSxcbiAgICB7IGlkOiBcInFjLW1ldHJpY3NcIiwgbGFiZWw6IFwiTWV0cmljc1wiIH0sXG4gICAgeyBpZDogXCJxYy1ydWxlc2V0c1wiLCBsYWJlbDogXCJSdWxlc2V0c1wiIH0sXG4gIF0sXG4gIHBsYXRmb3JtOiBbXG4gICAgeyBpZDogXCJzeXN0ZW1cIiwgbGFiZWw6IFwiRGF0YWJhc2VcIiB9LFxuICAgIHsgaWQ6IFwicmFkYXJcIiwgbGFiZWw6IFwiUmFkYXJcIiB9LFxuICAgIHsgaWQ6IFwiZmFjdG9yeVwiLCBsYWJlbDogXCJGYWN0b3J5XCIgfSxcbiAgICB7IGlkOiBcInBpcGVsaW5lXCIsIGxhYmVsOiBcIkJ1aWxkIFBpcGVsaW5lXCIgfSxcbiAgICB7IGlkOiBcImZlZWRiYWNrXCIsIGxhYmVsOiBcIkZlZWRiYWNrXCIgfSxcbiAgICB7IGlkOiBcImFuYWx5dGljc1wiLCBsYWJlbDogXCJBbmFseXRpY3NcIiB9LFxuICBdLFxufTtcblxuZnVuY3Rpb24gdmlld1RvU2VjdGlvbih2aWV3OiBNYWluVmlldyk6IENvbW1hbmRTZWN0aW9uIHtcbiAgaWYgKHZpZXcgPT09IFwiaG9tZVwiKSByZXR1cm4gXCJob21lXCI7XG4gIGlmIChcbiAgICBbXG4gICAgICBcImNvbnRyb2wtcG9ydGZvbGlvXCIsXG4gICAgICBcImNvbnRyb2wtd29yay1vcmRlcnNcIixcbiAgICAgIFwiY29udHJvbC1mbGVldFwiLFxuICAgICAgXCJjb250cm9sLWFwcHJvdmFsc1wiLFxuICAgIF0uaW5jbHVkZXModmlldylcbiAgKSB7XG4gICAgcmV0dXJuIFwiY29udHJvbFwiO1xuICB9XG4gIGlmIChcbiAgICBbXG4gICAgICBcImhhcm5lc3MtaGVhbHRoXCIsXG4gICAgICBcImhhcm5lc3MtbG9vcHNcIixcbiAgICAgIFwiaGFybmVzcy1jb250cm9sLXBsYW5lXCIsXG4gICAgICBcImhhcm5lc3Mtd29yay1sZWRnZXJcIixcbiAgICAgIFwiaGFybmVzcy10ZWFtLXB1bHNlXCIsXG4gICAgICBcImhhcm5lc3MtbWV0YS1sb29wXCIsXG4gICAgICBcImhhcm5lc3MtYnVpbGRlclwiLFxuICAgICAgXCJoYXJuZXNzLXZlcmlmaWVyc1wiLFxuICAgICAgXCJoYXJuZXNzLWNoYW5nZS1yZXZpZXdcIixcbiAgICAgIFwiaGFybmVzcy1jaGFuZ2Utcmlza1wiLFxuICAgICAgXCJoYXJuZXNzLWxhdW5jaFwiLFxuICAgICAgXCJoYXJuZXNzLW1haW50ZW5hbmNlXCIsXG4gICAgICBcImhhcm5lc3MtY29kZS1yZXZpZXctd2l6YXJkXCIsXG4gICAgICBcImhhcm5lc3Mtd29ya3Nob3BcIixcbiAgICAgIFwiaGFybmVzcy1hdXRvbWF0aW9uc1wiLFxuICAgICAgXCJoYXJuZXNzLWFnZW50LWZsZWV0XCIsXG4gICAgICBcImhhcm5lc3Mtc29mdHdhcmUtZmFjdG9yeVwiLFxuICAgICAgXCJoYXJuZXNzLWFyY2hpdGVjdFwiLFxuICAgICAgXCJoYXJuZXNzLXBhdHRlcm5zXCIsXG4gICAgXS5pbmNsdWRlcyh2aWV3KVxuICApIHtcbiAgICByZXR1cm4gXCJjb250cm9sXCI7XG4gIH1cbiAgaWYgKFtcInRhc2tzXCIsIFwiZ29hbHNcIiwgXCJkYWdcIiwgXCJjYWxlbmRhclwiLCBcIm9wcy1zY2hlZHVsZVwiLCBcImF1ZGl0XCIsIFwidGVsZW1ldHJ5XCIsIFwiYXV0b21hdGlvbnNcIiwgXCJhdXRvbWF0aW9uLXJ1bnNcIl0uaW5jbHVkZXModmlldykpIHJldHVybiBcIm9wc1wiO1xuICBpZiAoW1wiYXRjXCIsIFwiYWdlbnRzXCIsIFwiZGlyZWN0b3J5XCIsIFwiaWRlbnRpdHlcIiwgXCJwb2xpY2llc1wiLCBcImRlcGxveW1lbnRzXCIsIFwiZ2F0ZXdheVwiLCBcInNjaGVkdWxlc1wiXS5pbmNsdWRlcyh2aWV3KSkgcmV0dXJuIFwiYWdlbnRzXCI7XG4gIGlmIChbXCJjaGF0XCIsIFwibGl2ZS1jaGF0XCIsIFwiY291bmNpbFwiLCBcImNvbW1hbmRcIl0uaW5jbHVkZXModmlldykpIHJldHVybiBcImNoYXRcIjtcbiAgaWYgKFtcImNhcHR1cmVzXCIsIFwicHJvamVjdHNcIiwgXCJjb250ZW50LXBpcGVsaW5lXCJdLmluY2x1ZGVzKHZpZXcpKSByZXR1cm4gXCJjb250ZW50XCI7XG4gIGlmIChbXCJxYy1kYXNoYm9hcmRcIiwgXCJxYy1ydW5zXCIsIFwicWMtZW52aXJvbm1lbnRzXCIsIFwicWMtZmluZGluZ3NcIiwgXCJxYy1tZXRyaWNzXCIsIFwicWMtcnVsZXNldHNcIl0uaW5jbHVkZXModmlldykpIHJldHVybiBcInF1YWxpdHlcIjtcbiAgaWYgKFtcInRlbGVncmFwaFwiLCBcIm1lZXRpbmdzXCIsIFwidm9pY2VcIiwgXCJwZW9wbGVcIiwgXCJvcmdcIiwgXCJvZmZpY2VcIiwgXCJsaXZlLW9mZmljZVwiLCBcImNybVwiLCBcImhpcmluZ1wiLCBcInRlYW1cIl0uaW5jbHVkZXModmlldykpIHJldHVybiBcImNvbW1zXCI7XG4gIGlmIChcbiAgICBbXG4gICAgICBcImRvY3NcIixcbiAgICAgIFwiZGVzaWduLXN5c3RlbVwiLFxuICAgICAgXCJza2lsbHNcIixcbiAgICAgIFwicmVnaXN0cnktbGlmZWN5Y2xlXCIsXG4gICAgICBcInJlZ2lzdHJ5LWV2YWx1YXRlXCIsXG4gICAgICBcInJlZ2lzdHJ5LWludmVudG9yeVwiLFxuICAgICAgXCJyZWdpc3RyeS1pbnN0YWxsYXRpb25zXCIsXG4gICAgICBcInJlZ2lzdHJ5LXJ1bnNcIixcbiAgICAgIFwic2VhcmNoXCIsXG4gICAgICBcIm1lbW9yeVwiLFxuICAgIF0uaW5jbHVkZXModmlldylcbiAgKVxuICAgIHJldHVybiBcImtub3dsZWRnZVwiO1xuICBpZiAoW1wic3lzdGVtXCIsIFwicmFkYXJcIiwgXCJmYWN0b3J5XCIsIFwicGlwZWxpbmVcIiwgXCJmZWVkYmFja1wiLCBcImFuYWx5dGljc1wiLCBcIm1vZGVsLXJvdXRpbmdcIiwgXCJjb21tYW5kLWNlbnRlclwiLCBcIm1pc3Npb25zXCIsIFwibWlzc2lvbi1kZXRhaWxcIiwgXCJ0cmFjZS1pbnNwZWN0b3JcIiwgXCJlZmZlY3RpdmVuZXNzXCIsIFwiZmFjdG9yeS1oZWFsdGhcIiwgXCJyZWFkaW5lc3NcIiwgXCJmcmljdGlvblwiLCBcImFnZW50LWNhdGFsb2dcIiwgXCJkb3NzaWVyXCIsIFwicmVjb21tZW5kYXRpb25zXCJdLmluY2x1ZGVzKHZpZXcpKSByZXR1cm4gXCJwbGF0Zm9ybVwiO1xuICBpZiAoW1xuICAgIFwiY29kZVwiLCBcInJlY29yZGVyXCIsIFwidGVzdC1nZW5lcmF0aW9uXCIsIFwiYXBpLWltcG9ydFwiLCBcImV4ZWN1dGlvblwiLFxuICAgIFwiZmxha3ktc3RlcHNcIiwgXCJoeWJyaWQtd29ya2Zsb3dzXCIsIFwic2NoZWR1bGVcIiwgXCJjb2RlZ2VuXCIsIFwiZ2hlcmtpblwiLCBcIm1ldHJpY3NcIixcbiAgXS5pbmNsdWRlcyh2aWV3KSkgcmV0dXJuIFwiY29kZVwiO1xuICByZXR1cm4gXCJob21lXCI7XG59XG5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbi8vIEhFQURFUiBNRVRSSUNTXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbmZ1bmN0aW9uIHVzZUhlYWRlck1ldHJpY3MocHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+IHwgbnVsbCkge1xuICBjb25zdCBhZ2VudHMgPSB1c2VRdWVyeShhcGkuYWdlbnRzLmxpc3RBbGwsIHByb2plY3RJZCA/IHsgcHJvamVjdElkIH0gOiBcInNraXBcIik7XG4gIGNvbnN0IHRhc2tzID0gdXNlUXVlcnkoYXBpLnRhc2tzLmxpc3RBbGwsIHByb2plY3RJZCA/IHsgcHJvamVjdElkIH0gOiBcInNraXBcIik7XG4gIGNvbnN0IFtzdGF0dXNUaWNrLCBzZXRTdGF0dXNUaWNrXSA9IHVzZVN0YXRlKCgpID0+IERhdGUubm93KCkpO1xuICBjb25zdCBhY3RpdmVDb3VudCA9IGFnZW50cz8uZmlsdGVyKChhKSA9PiBhLnN0YXR1cyA9PT0gXCJBQ1RJVkVcIikubGVuZ3RoID8/IDA7XG4gIGNvbnN0IHRhc2tDb3VudCA9IHRhc2tzPy5sZW5ndGggPz8gMDtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHRpbWVyID0gd2luZG93LnNldEludGVydmFsKCgpID0+IHtcbiAgICAgIHNldFN0YXR1c1RpY2soRGF0ZS5ub3coKSk7XG4gICAgfSwgMTVfMDAwKTtcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LmNsZWFySW50ZXJ2YWwodGltZXIpO1xuICB9LCBbXSk7XG5cbiAgY29uc3QgYWlTdGF0dXMgPSB1c2VNZW1vPFNoZWxsQWlTdGF0dXM+KCgpID0+IHtcbiAgICBpZiAoIWFnZW50cyB8fCBhZ2VudHMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB0b25lOiBcIm9mZmxpbmVcIixcbiAgICAgICAgbGFiZWw6IFwiTm8gYWN0aXZlIGZsZWV0XCIsXG4gICAgICAgIGRldGFpbDogXCJSZWdpc3RlciBvciByZXN1bWUgYW4gYWdlbnQgdG8gYnJpbmcgTWlzc2lvbiBDb250cm9sIG9ubGluZS5cIixcbiAgICAgICAgbGFzdFNlZW5MYWJlbDogXCJObyBoZWFydGJlYXRcIixcbiAgICAgICAgYWdlbnRJZDogbnVsbCxcbiAgICAgICAgdGFza0lkOiBudWxsLFxuICAgICAgfTtcbiAgICB9XG5cbiAgICBjb25zdCB0YXNrVGl0bGVCeUlkID0gbmV3IE1hcCh0YXNrcz8ubWFwKCh0YXNrKSA9PiBbdGFzay5faWQsIHRhc2sudGl0bGVdKSA/PyBbXSk7XG4gICAgY29uc3QgZnJlc2hlc3RBZ2VudCA9IFsuLi5hZ2VudHNdLnNvcnQoKGxlZnQsIHJpZ2h0KSA9PiB7XG4gICAgICBjb25zdCBsZWZ0U3RhbXAgPSBsZWZ0Lmxhc3RIZWFydGJlYXRBdCA/PyAwO1xuICAgICAgY29uc3QgcmlnaHRTdGFtcCA9IHJpZ2h0Lmxhc3RIZWFydGJlYXRBdCA/PyAwO1xuICAgICAgcmV0dXJuIHJpZ2h0U3RhbXAgLSBsZWZ0U3RhbXA7XG4gICAgfSlbMF07XG5cbiAgICBjb25zdCBsYXN0SGVhcnRiZWF0QXQgPSBmcmVzaGVzdEFnZW50Py5sYXN0SGVhcnRiZWF0QXQgPz8gbnVsbDtcbiAgICBjb25zdCBhZ2VNcyA9IGxhc3RIZWFydGJlYXRBdCA/IHN0YXR1c1RpY2sgLSBsYXN0SGVhcnRiZWF0QXQgOiBOdW1iZXIuUE9TSVRJVkVfSU5GSU5JVFk7XG4gICAgY29uc3QgdGFza1RpdGxlID0gZnJlc2hlc3RBZ2VudD8uY3VycmVudFRhc2tJZFxuICAgICAgPyB0YXNrVGl0bGVCeUlkLmdldChmcmVzaGVzdEFnZW50LmN1cnJlbnRUYXNrSWQpID8/IFwiYWN0aXZlIHRhc2tcIlxuICAgICAgOiBudWxsO1xuXG4gICAgY29uc3QgbGFzdFNlZW5MYWJlbCA9ICFsYXN0SGVhcnRiZWF0QXRcbiAgICAgID8gXCJObyBzaWduYWxcIlxuICAgICAgOiBhZ2VNcyA8IDYwXzAwMFxuICAgICAgICA/IFwiTGl2ZSBub3dcIlxuICAgICAgICA6IGFnZU1zIDwgM182MDBfMDAwXG4gICAgICAgICAgPyBgTGFzdCBzaWduYWwgJHtNYXRoLmZsb29yKGFnZU1zIC8gNjBfMDAwKX1tIGFnb2BcbiAgICAgICAgICA6IGFnZU1zIDwgODZfNDAwXzAwMFxuICAgICAgICAgICAgPyBgTGFzdCBzaWduYWwgJHtNYXRoLmZsb29yKGFnZU1zIC8gM182MDBfMDAwKX1oIGFnb2BcbiAgICAgICAgICAgIDogYExhc3Qgc2lnbmFsICR7TWF0aC5mbG9vcihhZ2VNcyAvIDg2XzQwMF8wMDApfWQgYWdvYDtcblxuICAgIGlmICghZnJlc2hlc3RBZ2VudCB8fCBmcmVzaGVzdEFnZW50LnN0YXR1cyA9PT0gXCJPRkZMSU5FXCIpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHRvbmU6IFwib2ZmbGluZVwiLFxuICAgICAgICBsYWJlbDogXCJGbGVldCBvZmZsaW5lXCIsXG4gICAgICAgIGRldGFpbDogXCJObyBhZ2VudHMgYXJlIGN1cnJlbnRseSByZXBvcnRpbmcgaW50byBNaXNzaW9uIENvbnRyb2wuXCIsXG4gICAgICAgIGxhc3RTZWVuTGFiZWwsXG4gICAgICAgIGFnZW50SWQ6IGZyZXNoZXN0QWdlbnQ/Ll9pZCA/PyBudWxsLFxuICAgICAgICB0YXNrSWQ6IGZyZXNoZXN0QWdlbnQ/LmN1cnJlbnRUYXNrSWQgPz8gbnVsbCxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgaWYgKGZyZXNoZXN0QWdlbnQuc3RhdHVzID09PSBcIlBBVVNFRFwiKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB0b25lOiBcImlkbGVcIixcbiAgICAgICAgbGFiZWw6IFwiUGF1c2VkIGJ5IG9wZXJhdG9yXCIsXG4gICAgICAgIGRldGFpbDogYCR7ZnJlc2hlc3RBZ2VudC5uYW1lfSBpcyBzdGFuZGluZyBieSB1bnRpbCB3b3JrIHJlc3VtZXMuYCxcbiAgICAgICAgbGFzdFNlZW5MYWJlbCxcbiAgICAgICAgYWdlbnRJZDogZnJlc2hlc3RBZ2VudC5faWQsXG4gICAgICAgIHRhc2tJZDogZnJlc2hlc3RBZ2VudC5jdXJyZW50VGFza0lkID8/IG51bGwsXG4gICAgICB9O1xuICAgIH1cblxuICAgIGlmIChmcmVzaGVzdEFnZW50LnN0YXR1cyA9PT0gXCJRVUFSQU5USU5FRFwiIHx8IGZyZXNoZXN0QWdlbnQuc3RhdHVzID09PSBcIkRSQUlORURcIikge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdG9uZTogXCJ0aGlua2luZ1wiLFxuICAgICAgICBsYWJlbDogXCJOZWVkcyBvcGVyYXRvciByZXZpZXdcIixcbiAgICAgICAgZGV0YWlsOiBgJHtmcmVzaGVzdEFnZW50Lm5hbWV9IGlzICR7ZnJlc2hlc3RBZ2VudC5zdGF0dXMudG9Mb3dlckNhc2UoKX0gYW5kIG1heSBuZWVkIGludGVydmVudGlvbi5gLFxuICAgICAgICBsYXN0U2VlbkxhYmVsLFxuICAgICAgICBhZ2VudElkOiBmcmVzaGVzdEFnZW50Ll9pZCxcbiAgICAgICAgdGFza0lkOiBmcmVzaGVzdEFnZW50LmN1cnJlbnRUYXNrSWQgPz8gbnVsbCxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgaWYgKGFnZU1zIDw9IDQ1XzAwMCkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdG9uZTogXCJhY3RpdmVcIixcbiAgICAgICAgbGFiZWw6IHRhc2tUaXRsZSA/IFwiV29ya2luZyBub3dcIiA6IFwiTGl2ZSBhbmQgcmVzcG9uZGluZ1wiLFxuICAgICAgICBkZXRhaWw6IHRhc2tUaXRsZVxuICAgICAgICAgID8gYCR7ZnJlc2hlc3RBZ2VudC5uYW1lfSBpcyB3b3JraW5nIG9uICR7dGFza1RpdGxlfS5gXG4gICAgICAgICAgOiBgJHtmcmVzaGVzdEFnZW50Lm5hbWV9IGlzIGFjdGl2ZWx5IHJlcG9ydGluZyBoZWFydGJlYXQgdHJhZmZpYy5gLFxuICAgICAgICBsYXN0U2VlbkxhYmVsLFxuICAgICAgICBhZ2VudElkOiBmcmVzaGVzdEFnZW50Ll9pZCxcbiAgICAgICAgdGFza0lkOiBmcmVzaGVzdEFnZW50LmN1cnJlbnRUYXNrSWQgPz8gbnVsbCxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgaWYgKGFnZU1zIDw9IDE4MF8wMDApIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHRvbmU6IFwidGhpbmtpbmdcIixcbiAgICAgICAgbGFiZWw6IHRhc2tUaXRsZSA/IFwiVGhpbmtpbmcgdGhyb3VnaCBleGVjdXRpb25cIiA6IFwiVGhpbmtpbmdcIixcbiAgICAgICAgZGV0YWlsOiB0YXNrVGl0bGVcbiAgICAgICAgICA/IGAke2ZyZXNoZXN0QWdlbnQubmFtZX0gbGFzdCByZXBvcnRlZCB3aGlsZSB3b3JraW5nIG9uICR7dGFza1RpdGxlfS5gXG4gICAgICAgICAgOiBgJHtmcmVzaGVzdEFnZW50Lm5hbWV9IGlzIGJldHdlZW4gdXBkYXRlcyBidXQgc3RpbGwgd2FybS5gLFxuICAgICAgICBsYXN0U2VlbkxhYmVsLFxuICAgICAgICBhZ2VudElkOiBmcmVzaGVzdEFnZW50Ll9pZCxcbiAgICAgICAgdGFza0lkOiBmcmVzaGVzdEFnZW50LmN1cnJlbnRUYXNrSWQgPz8gbnVsbCxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgaWYgKGFnZU1zID4gMjFfNjAwXzAwMCkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdG9uZTogXCJvZmZsaW5lXCIsXG4gICAgICAgIGxhYmVsOiBcIlN0YWxlIHNpZ25hbFwiLFxuICAgICAgICBkZXRhaWw6IGAke2ZyZXNoZXN0QWdlbnQubmFtZX0gaGFzIG5vdCByZXBvcnRlZCBhIHRydXN0d29ydGh5IGhlYXJ0YmVhdCByZWNlbnRseS4gSW5zcGVjdCB0aGUgZmxlZXQgYmVmb3JlIHJlbHlpbmcgb24gdGhpcyBzdGF0ZS5gLFxuICAgICAgICBsYXN0U2VlbkxhYmVsLFxuICAgICAgICBhZ2VudElkOiBmcmVzaGVzdEFnZW50Ll9pZCxcbiAgICAgICAgdGFza0lkOiBmcmVzaGVzdEFnZW50LmN1cnJlbnRUYXNrSWQgPz8gbnVsbCxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIHRvbmU6IFwiaWRsZVwiLFxuICAgICAgbGFiZWw6IFwiUmVhZHkgZm9yIG5leHQgYXNzaWdubWVudFwiLFxuICAgICAgZGV0YWlsOiBgJHtmcmVzaGVzdEFnZW50Lm5hbWV9IGlzIG9ubGluZSBidXQgaGFzbuKAmXQgcmVwb3J0ZWQgYWN0aXZpdHkgcmVjZW50bHkuYCxcbiAgICAgIGxhc3RTZWVuTGFiZWwsXG4gICAgICBhZ2VudElkOiBmcmVzaGVzdEFnZW50Ll9pZCxcbiAgICAgIHRhc2tJZDogZnJlc2hlc3RBZ2VudC5jdXJyZW50VGFza0lkID8/IG51bGwsXG4gICAgfTtcbiAgfSwgW2FnZW50cywgc3RhdHVzVGljaywgdGFza3NdKTtcblxuICByZXR1cm4geyBhY3RpdmVDb3VudCwgdGFza0NvdW50LCBhaVN0YXR1cyB9O1xufVxuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBQQUdFIFRSQU5TSVRJT05cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuZnVuY3Rpb24gUGFnZVRyYW5zaXRpb24oeyBjaGlsZHJlbiwgdmlld0tleSB9OiB7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7IHZpZXdLZXk6IHN0cmluZyB9KSB7XG4gIHJldHVybiAoXG4gICAgPEFuaW1hdGVQcmVzZW5jZSBtb2RlPVwid2FpdFwiPlxuICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAga2V5PXt2aWV3S2V5fVxuICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDYgfX1cbiAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwIH19XG4gICAgICAgIGV4aXQ9e3sgb3BhY2l0eTogMCwgeTogLTYgfX1cbiAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC4yLCBlYXNlOiBcImVhc2VPdXRcIiB9fVxuICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGZsZXgtMSBvdmVyZmxvdy1oaWRkZW5cIlxuICAgICAgPlxuICAgICAgICB7Y2hpbGRyZW59XG4gICAgICA8L21vdGlvbi5kaXY+XG4gICAgPC9BbmltYXRlUHJlc2VuY2U+XG4gICk7XG59XG5cbmZ1bmN0aW9uIFNlY3Rpb25Mb2FkaW5nU3RhdGUoKSB7XG4gIHJldHVybiAoXG4gICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleCBmbGV4LTEgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC0xIGZsZXgtY29sIGdhcC00IHAtNlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMTYgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWxpbmUgYW5pbWF0ZS1wdWxzZSBiZy1zdXJmYWNlLTJcIiAvPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZmxleC0xIGdhcC00IGxnOmdyaWQtY29scy0zXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlciBib3JkZXItbGluZSBhbmltYXRlLXB1bHNlIGJnLXN1cmZhY2UtMlwiIC8+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlciBib3JkZXItbGluZSBhbmltYXRlLXB1bHNlIGJnLXN1cmZhY2UtMiBsZzpjb2wtc3Bhbi0yXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L21haW4+XG4gICk7XG59XG5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbi8vIEFQUFxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoKSB7XG4gIGNvbnN0IFtzZWFyY2hQYXJhbXMsIHNldFNlYXJjaFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcbiAgLy8g4pSA4pSAIE5hdmlnYXRpb24gJiBzZWxlY3Rpb24gKHBlcnNpc3QgbGFzdCB2aWV3IHNvIFVJIHJlb3BlbnMgd2hlcmUgb3BlcmF0b3IgbGVmdCBvZmYpIOKUgFxuICBjb25zdCBbY3VycmVudFZpZXcsIHNldEN1cnJlbnRWaWV3XSA9IHVzZVN0YXRlPE1haW5WaWV3PigoKSA9PiByZWFkUGVyc2lzdGVkVmlldygpID8/IFwiaG9tZVwiKTtcbiAgLy8gVHJlYXQgYSBVUkwvbG9jYWwtc3RvcmFnZSB3b3Jrc3BhY2UgdmFsdWUgYXMgdW50cnVzdGVkIHVudGlsIGl0IGlzIGZvdW5kXG4gIC8vIGluIHRoZSBwcm9qZWN0IGxpc3QuIEEgZm9yZWlnbiBDb252ZXggSUQgb3RoZXJ3aXNlIGNyYXNoZXMgdi5pZChcInByb2plY3RzXCIpXG4gIC8vIHZhbGlkYXRpb24gYmVmb3JlIHRoZSBub3JtYWwgd29ya3NwYWNlIGZhbGxiYWNrIGNhbiBydW4uXG4gIGNvbnN0IFtyZXF1ZXN0ZWRQcm9qZWN0SWRdID0gdXNlU3RhdGUocmVhZFJlcXVlc3RlZFByb2plY3RJZCk7XG4gIGNvbnN0IFtwcm9qZWN0SWQsIHNldFByb2plY3RJZF0gPSB1c2VTdGF0ZTxJZDxcInByb2plY3RzXCI+IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtzZWxlY3RlZFRhc2tJZCwgc2V0U2VsZWN0ZWRUYXNrSWRdID0gdXNlU3RhdGU8SWQ8XCJ0YXNrc1wiPiB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbc2VsZWN0ZWRRY1J1bklkLCBzZXRTZWxlY3RlZFFjUnVuSWRdID0gdXNlU3RhdGU8SWQ8XCJxY1J1bnNcIj4gfCBudWxsPihudWxsKTtcblxuICAvLyDilIDilIAgU2lkZWJhciAvIG9wcy1zZWN0aW9uIHN0YXRlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICBjb25zdCBbc2lkZWJhclNlbGVjdGVkQWdlbnRJZCwgc2V0U2lkZWJhclNlbGVjdGVkQWdlbnRJZF0gPSB1c2VTdGF0ZTxJZDxcImFnZW50c1wiPiB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbc2lkZWJhcldpZHRoLCBzZXRTaWRlYmFyV2lkdGhdID0gdXNlU3RhdGUoU0lERUJBUl9XSURUSCk7XG4gIGNvbnN0IFtsaXZlRmVlZEV4cGFuZGVkLCBzZXRMaXZlRmVlZEV4cGFuZGVkXSA9IHVzZVN0YXRlKCgpID0+IHtcbiAgICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIGZhbHNlO1xuICAgIHJldHVybiB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJtYy5saXZlX2ZlZWRfZXhwYW5kZWRcIikgPT09IFwiMVwiO1xuICB9KTtcbiAgY29uc3QgW2thbmJhbkZpbHRlcnMsIHNldEthbmJhbkZpbHRlcnNdID0gdXNlU3RhdGU8e1xuICAgIGFnZW50czogc3RyaW5nW107XG4gICAgcHJpb3JpdGllczogbnVtYmVyW107XG4gICAgdHlwZXM6IHN0cmluZ1tdO1xuICB9Pih7IGFnZW50czogW10sIHByaW9yaXRpZXM6IFtdLCB0eXBlczogW10gfSk7XG5cbiAgLy8g4pSA4pSAIE1vZGFsIHN0YXRlICgxOSBib29sZWFucyBleHRyYWN0ZWQgdG8gaG9vaykg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIGNvbnN0IHsgbW9kYWxzLCBvcGVuLCBjbG9zZSwgY2xvc2VBbGwgfSA9IHVzZU1vZGFsU3RhdGUoKTtcblxuICAvLyDilIDilIAgRGVyaXZlZCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgY29uc3QgYWN0aXZlU2VjdGlvbiA9IHVzZU1lbW8oKCkgPT4gdmlld1RvU2VjdGlvbihjdXJyZW50VmlldyksIFtjdXJyZW50Vmlld10pO1xuICBjb25zdCBzZWN0aW9uVGFicyA9IFNFQ1RJT05fVEFCU1thY3RpdmVTZWN0aW9uXTtcblxuICAvLyDilIDilIAgRGF0YSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgY29uc3QgcHJvamVjdCA9IHVzZVF1ZXJ5KGFwaS5wcm9qZWN0cy5nZXQsIHByb2plY3RJZCA/IHsgcHJvamVjdElkIH0gOiBcInNraXBcIik7XG4gIGNvbnN0IHByb2plY3RzID0gdXNlUXVlcnkoYXBpLnByb2plY3RzLmxpc3QpO1xuICBjb25zdCBhdmFpbGFibGVQcm9qZWN0cyA9IHVzZU1lbW8oXG4gICAgKCkgPT4gcHJvamVjdHM/LmZpbHRlcigoaXRlbSkgPT4gaXRlbS5zdGF0dXMgIT09IFwiQVJDSElWRURcIiksXG4gICAgW3Byb2plY3RzXVxuICApO1xuICBjb25zdCBwZW5kaW5nQXBwcm92YWxzID0gdXNlUXVlcnkoXG4gICAgYXBpLmFwcHJvdmFscy5saXN0UGVuZGluZyxcbiAgICBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCwgbGltaXQ6IDEwIH0gOiBcInNraXBcIlxuICApO1xuXG4gIC8vIOKUgOKUgCBFZmZlY3RzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChcbiAgICAgIHByb2plY3RzICYmXG4gICAgICBhdmFpbGFibGVQcm9qZWN0cyAmJlxuICAgICAgYXZhaWxhYmxlUHJvamVjdHMubGVuZ3RoID4gMCAmJlxuICAgICAgKCFwcm9qZWN0SWQgfHwgIWF2YWlsYWJsZVByb2plY3RzLnNvbWUoKGl0ZW0pID0+IGl0ZW0uX2lkID09PSBwcm9qZWN0SWQpKVxuICAgICkge1xuICAgICAgY29uc3QgcHJlZmVycmVkID1cbiAgICAgICAgYXZhaWxhYmxlUHJvamVjdHMuZmluZCgocCkgPT4gcC5faWQgPT09IHByb2plY3RJZCkgPz9cbiAgICAgICAgYXZhaWxhYmxlUHJvamVjdHMuZmluZCgocCkgPT4gcC5faWQgPT09IHJlcXVlc3RlZFByb2plY3RJZCkgPz9cbiAgICAgICAgYXZhaWxhYmxlUHJvamVjdHMuZmluZCgocCkgPT4gcC5uYW1lLnRyaW0oKS50b0xvd2VyQ2FzZSgpID09PSBcIm1pc3Npb24gY29udHJvbFwiKSA/P1xuICAgICAgICBhdmFpbGFibGVQcm9qZWN0cy5maW5kKChwKSA9PiBwLm5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhcIm1pc3Npb24gY29udHJvbFwiKSkgPz9cbiAgICAgICAgYXZhaWxhYmxlUHJvamVjdHNbMF07XG4gICAgICBzZXRQcm9qZWN0SWQocHJlZmVycmVkLl9pZCk7XG4gICAgfSBlbHNlIGlmIChhdmFpbGFibGVQcm9qZWN0cyAmJiBhdmFpbGFibGVQcm9qZWN0cy5sZW5ndGggPT09IDAgJiYgcHJvamVjdElkKSB7XG4gICAgICBzZXRQcm9qZWN0SWQobnVsbCk7XG4gICAgfVxuICB9LCBbYXZhaWxhYmxlUHJvamVjdHMsIHByb2plY3RJZCwgcmVxdWVzdGVkUHJvamVjdElkXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXByb2plY3RJZCB8fCB0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm47XG4gICAgdHJ5IHtcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShTVE9SQUdFX0tFWV9QUk9KRUNULCBwcm9qZWN0SWQpO1xuICAgICAgaWYgKHNlYXJjaFBhcmFtcy5nZXQoXCJ3b3Jrc3BhY2VcIikgIT09IHByb2plY3RJZCkge1xuICAgICAgICBzZXRTZWFyY2hQYXJhbXMoKGN1cnJlbnQpID0+IHtcbiAgICAgICAgICBjb25zdCBuZXh0ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhjdXJyZW50KTtcbiAgICAgICAgICBuZXh0LnNldChcIndvcmtzcGFjZVwiLCBwcm9qZWN0SWQpO1xuICAgICAgICAgIHJldHVybiBuZXh0O1xuICAgICAgICB9LCB7IHJlcGxhY2U6IHRydWUgfSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBpZ25vcmVcbiAgICB9XG4gIH0sIFtwcm9qZWN0SWQsIHNlYXJjaFBhcmFtcywgc2V0U2VhcmNoUGFyYW1zXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXRTZWxlY3RlZFRhc2tJZChudWxsKTtcbiAgICBzZXRTZWxlY3RlZFFjUnVuSWQobnVsbCk7XG4gICAgc2V0U2lkZWJhclNlbGVjdGVkQWdlbnRJZChudWxsKTtcbiAgICBzZXRLYW5iYW5GaWx0ZXJzKHsgYWdlbnRzOiBbXSwgcHJpb3JpdGllczogW10sIHR5cGVzOiBbXSB9KTtcbiAgICBjbG9zZUFsbCgpO1xuICB9LCBbcHJvamVjdElkLCBjbG9zZUFsbF0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcIm1jLmxpdmVfZmVlZF9leHBhbmRlZFwiLCBsaXZlRmVlZEV4cGFuZGVkID8gXCIxXCIgOiBcIjBcIik7XG4gICAgfVxuICB9LCBbbGl2ZUZlZWRFeHBhbmRlZF0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShTVE9SQUdFX0tFWV9WSUVXLCBjdXJyZW50Vmlldyk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gaWdub3JlXG4gICAgICB9XG4gICAgfVxuICB9LCBbY3VycmVudFZpZXddKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChjdXJyZW50VmlldyAhPT0gXCJ0YXNrc1wiKSBzZXRTaWRlYmFyU2VsZWN0ZWRBZ2VudElkKG51bGwpO1xuICB9LCBbY3VycmVudFZpZXddKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghbW9kYWxzLnBhdXNlQ29uZmlybSkgcmV0dXJuO1xuICAgIGNvbnN0IGhhbmRsZXIgPSAoZTogS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgICAgaWYgKGUua2V5ID09PSBcIkVzY2FwZVwiKSBjbG9zZShcInBhdXNlQ29uZmlybVwiKTtcbiAgICB9O1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBoYW5kbGVyKTtcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGhhbmRsZXIpO1xuICB9LCBbbW9kYWxzLnBhdXNlQ29uZmlybSwgY2xvc2VdKTtcblxuICAvLyDilIDilIAgTXV0YXRpb25zIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICBjb25zdCBwYXVzZUFsbCA9IHVzZU11dGF0aW9uKGFwaS5hZ2VudHMucGF1c2VBbGwpO1xuICBjb25zdCByZXN1bWVBbGwgPSB1c2VNdXRhdGlvbihhcGkuYWdlbnRzLnJlc3VtZUFsbCk7XG4gIGNvbnN0IHsgdG9hc3QgfSA9IHVzZVRvYXN0KCk7XG5cbiAgLy8g4pSA4pSAIEtleWJvYXJkIHNob3J0Y3V0cyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgdXNlS2V5Ym9hcmRTaG9ydGN1dHMoe1xuICAgIG9uTmV3VGFzazogKCkgPT4gb3BlbihcImNyZWF0ZVRhc2tcIiksXG4gICAgb25TZWFyY2g6ICgpID0+IG9wZW4oXCJjb21tYW5kUGFsZXR0ZVwiKSxcbiAgICBvbkFwcHJvdmFsczogKCkgPT4gb3BlbihcImFwcHJvdmFsc1wiKSxcbiAgICBvbkFnZW50czogKCkgPT4geyBzZXRTaWRlYmFyU2VsZWN0ZWRBZ2VudElkKG51bGwpOyBvcGVuKFwiYWdlbnRzRmx5b3V0XCIpOyB9LFxuICAgIG9uQ29zdEFuYWx5dGljczogKCkgPT4gb3BlbihcImNvc3RBbmFseXRpY3NcIiksXG4gICAgb25Hb1RvQm9hcmQ6ICgpID0+IHNldEN1cnJlbnRWaWV3KFwidGFza3NcIiksXG4gICAgb25TaG93SGVscDogKCkgPT4gb3BlbihcImtleWJvYXJkSGVscFwiKSxcbiAgICBvbk1pc3Npb246ICgpID0+IG9wZW4oXCJtaXNzaW9uTW9kYWxcIiksXG4gIH0pO1xuXG4gIC8vIOKUgOKUgCBDYWxsYmFja3Mg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIGNvbnN0IGhhbmRsZUNvbmZpcm1QYXVzZVNxdWFkID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIGNsb3NlKFwicGF1c2VDb25maXJtXCIpO1xuICAgIGlmICghcHJvamVjdElkKSB7XG4gICAgICB0b2FzdChcIlNlbGVjdCBhIHdvcmtzcGFjZSBiZWZvcmUgcGF1c2luZyBhZ2VudHMuXCIsIHRydWUpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcGF1c2VBbGwoe1xuICAgICAgICBwcm9qZWN0SWQsXG4gICAgICAgIHJlYXNvbjogXCJQYXVzZSBzcXVhZCBmcm9tIE1pc3Npb24gQ29udHJvbFwiLFxuICAgICAgICB1c2VySWQ6IFwib3BlcmF0b3JcIixcbiAgICAgIH0pO1xuICAgICAgdG9hc3QoYFBhdXNlZCAkeyhyZXN1bHQgYXMgeyBwYXVzZWQ6IG51bWJlciB9KS5wYXVzZWR9IGFnZW50KHMpYCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgdG9hc3QoZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogXCJQYXVzZSBmYWlsZWRcIiwgdHJ1ZSk7XG4gICAgfVxuICB9LCBbcGF1c2VBbGwsIHByb2plY3RJZCwgdG9hc3QsIGNsb3NlXSk7XG5cbiAgY29uc3QgaGFuZGxlUmVzdW1lU3F1YWQgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFwcm9qZWN0SWQpIHtcbiAgICAgIHRvYXN0KFwiU2VsZWN0IGEgd29ya3NwYWNlIGJlZm9yZSByZXN1bWluZyBhZ2VudHMuXCIsIHRydWUpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmVzdW1lQWxsKHtcbiAgICAgICAgcHJvamVjdElkLFxuICAgICAgICByZWFzb246IFwiUmVzdW1lIHNxdWFkIGZyb20gTWlzc2lvbiBDb250cm9sXCIsXG4gICAgICAgIHVzZXJJZDogXCJvcGVyYXRvclwiLFxuICAgICAgfSk7XG4gICAgICB0b2FzdChgUmVzdW1lZCAkeyhyZXN1bHQgYXMgeyByZXN1bWVkOiBudW1iZXIgfSkucmVzdW1lZH0gYWdlbnQocylgKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICB0b2FzdChlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiBcIlJlc3VtZSBmYWlsZWRcIiwgdHJ1ZSk7XG4gICAgfVxuICB9LCBbcmVzdW1lQWxsLCBwcm9qZWN0SWQsIHRvYXN0XSk7XG5cbiAgY29uc3QgaGFuZGxlU2VjdGlvbkNoYW5nZSA9IHVzZUNhbGxiYWNrKChzZWN0aW9uOiBDb21tYW5kU2VjdGlvbikgPT4ge1xuICAgIGNsb3NlKFwiYWdlbnRzRmx5b3V0XCIpO1xuICAgIHNldFNpZGViYXJTZWxlY3RlZEFnZW50SWQobnVsbCk7XG4gICAgc2V0Q3VycmVudFZpZXcoU0VDVElPTl9ERUZBVUxUX1ZJRVdbc2VjdGlvbl0pO1xuICB9LCBbY2xvc2VdKTtcblxuICBjb25zdCBoYW5kbGVUYWJDaGFuZ2UgPSB1c2VDYWxsYmFjaygodGFiSWQ6IHN0cmluZykgPT4ge1xuICAgIGNsb3NlKFwiYWdlbnRzRmx5b3V0XCIpO1xuICAgIHNldFNpZGViYXJTZWxlY3RlZEFnZW50SWQobnVsbCk7XG4gICAgc2V0Q3VycmVudFZpZXcodGFiSWQgYXMgTWFpblZpZXcpO1xuICB9LCBbY2xvc2VdKTtcblxuICAvLyDilIDilIAgSGVhZGVyIGRhdGEg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XG4gIGNvbnN0IHRpbWVTdHIgPSBub3cudG9Mb2NhbGVUaW1lU3RyaW5nKFwiZW4tVVNcIiwgeyBob3VyOiBcIjItZGlnaXRcIiwgbWludXRlOiBcIjItZGlnaXRcIiwgc2Vjb25kOiBcIjItZGlnaXRcIiB9KTtcbiAgY29uc3QgZGF0ZVN0ciA9IG5vdy50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1VU1wiLCB7IHdlZWtkYXk6IFwic2hvcnRcIiwgbW9udGg6IFwic2hvcnRcIiwgZGF5OiBcIm51bWVyaWNcIiB9KS50b1VwcGVyQ2FzZSgpO1xuICBjb25zdCB7IGFjdGl2ZUNvdW50LCB0YXNrQ291bnQsIGFpU3RhdHVzIH0gPSB1c2VIZWFkZXJNZXRyaWNzKHByb2plY3RJZCk7XG5cbiAgLy8g4pSA4pSAIFNlY3Rpb24gcmVuZGVyZXIg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIGZ1bmN0aW9uIHJlbmRlclNlY3Rpb24oKSB7XG4gICAgaWYgKGN1cnJlbnRWaWV3ICE9PSBcInByb2plY3RzXCIpIHtcbiAgICAgIGlmICghcHJvamVjdHMgfHwgKHByb2plY3RJZCAmJiBwcm9qZWN0ID09PSB1bmRlZmluZWQpKSB7XG4gICAgICAgIHJldHVybiA8U2VjdGlvbkxvYWRpbmdTdGF0ZSAvPjtcbiAgICAgIH1cbiAgICAgIGlmIChhdmFpbGFibGVQcm9qZWN0cy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtMSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYXBwIHAtNlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy1tZCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgcC02IHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj5DcmVhdGUgYSB3b3Jrc3BhY2U8L2gxPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1pbmstc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgV29yayBPcmRlcnMsIGFnZW50cywgcnVucywgYW5kIGV2aWRlbmNlIHJlcXVpcmUgYW4gZXhwbGljaXQgd29ya3NwYWNlIGJvdW5kYXJ5LlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDdXJyZW50VmlldyhcInByb2plY3RzXCIpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTQgaC05IHJvdW5kZWQtbGcgYmctYWN0IHB4LTMgdGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdGV4dC1hY3QtaW5rXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIE9wZW4gd29ya3NwYWNlIHNldHRpbmdzXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9tYWluPlxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgaWYgKCFwcm9qZWN0SWQgfHwgIXByb2plY3QpIHtcbiAgICAgICAgcmV0dXJuIDxTZWN0aW9uTG9hZGluZ1N0YXRlIC8+O1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChcbiAgICAgIFtcbiAgICAgICAgXCJoYXJuZXNzLWhlYWx0aFwiLFxuICAgICAgICBcImhhcm5lc3MtbG9vcHNcIixcbiAgICAgICAgXCJoYXJuZXNzLWNvbnRyb2wtcGxhbmVcIixcbiAgICAgICAgXCJoYXJuZXNzLXdvcmstbGVkZ2VyXCIsXG4gICAgICAgIFwiaGFybmVzcy12ZXJpZmllcnNcIixcbiAgICAgICAgXCJoYXJuZXNzLWNoYW5nZS1yZXZpZXdcIixcbiAgICAgICAgXCJoYXJuZXNzLWNoYW5nZS1yaXNrXCIsXG4gICAgICAgIFwiaGFybmVzcy1sYXVuY2hcIixcbiAgICAgICAgXCJoYXJuZXNzLW1ldGEtbG9vcFwiLFxuICAgICAgICBcImhhcm5lc3MtdGVhbS1wdWxzZVwiLFxuICAgICAgICBcImhhcm5lc3MtYnVpbGRlclwiLFxuICAgICAgICBcImhhcm5lc3MtbWFpbnRlbmFuY2VcIixcbiAgICAgICAgXCJoYXJuZXNzLWNvZGUtcmV2aWV3LXdpemFyZFwiLFxuICAgICAgICBcImhhcm5lc3Mtd29ya3Nob3BcIixcbiAgICAgICAgXCJoYXJuZXNzLWF1dG9tYXRpb25zXCIsXG4gICAgICAgIFwiaGFybmVzcy1hZ2VudC1mbGVldFwiLFxuICAgICAgICBcImhhcm5lc3Mtc29mdHdhcmUtZmFjdG9yeVwiLFxuICAgICAgICBcImhhcm5lc3MtYXJjaGl0ZWN0XCIsXG4gICAgICBcImhhcm5lc3MtcGF0dGVybnNcIixcbiAgICAgIF0uaW5jbHVkZXMoY3VycmVudFZpZXcpXG4gICAgKSB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8SGFybmVzc1NlY3Rpb25cbiAgICAgICAgICBjdXJyZW50Vmlldz17Y3VycmVudFZpZXd9XG4gICAgICAgICAgcHJvamVjdElkPXtwcm9qZWN0SWR9XG4gICAgICAgICAgb25OYXZpZ2F0ZT17c2V0Q3VycmVudFZpZXd9XG4gICAgICAgIC8+XG4gICAgICApO1xuICAgIH1cblxuICAgIHN3aXRjaCAoYWN0aXZlU2VjdGlvbikge1xuICAgICAgY2FzZSBcImhvbWVcIjpcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8RGFzaGJvYXJkT3ZlcnZpZXdcbiAgICAgICAgICAgIHByb2plY3RJZD17cHJvamVjdElkfVxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT4ge319XG4gICAgICAgICAgICBvbk9wZW5NaXNzaW9uTW9kYWw9eygpID0+IG9wZW4oXCJtaXNzaW9uTW9kYWxcIil9XG4gICAgICAgICAgICBvbk9wZW5TdWdnZXN0aW9uc0RyYXdlcj17KCkgPT4gb3BlbihcInN1Z2dlc3Rpb25zRHJhd2VyXCIpfVxuICAgICAgICAgICAgb25OYXZpZ2F0ZT17c2V0Q3VycmVudFZpZXd9XG4gICAgICAgICAgICBvbk9wZW5BcHByb3ZhbHM9eygpID0+IG9wZW4oXCJhcHByb3ZhbHNcIil9XG4gICAgICAgICAgICBvbk9wZW5Db3N0QW5hbHl0aWNzPXsoKSA9PiBvcGVuKFwiY29zdEFuYWx5dGljc1wiKX1cbiAgICAgICAgICAgIG9uT3BlbkFsZXJ0UnVsZXM9eygpID0+IG9wZW4oXCJhbGVydFJ1bGVzXCIpfVxuICAgICAgICAgICAgb25UYXNrU2VsZWN0PXtzZXRTZWxlY3RlZFRhc2tJZH1cbiAgICAgICAgICAgIG9uTmF2aWdhdGVUb0dhdGV3YXk9eygpID0+IHtcbiAgICAgICAgICAgICAgaGFuZGxlU2VjdGlvbkNoYW5nZShcImFnZW50c1wiKTtcbiAgICAgICAgICAgICAgaGFuZGxlVGFiQ2hhbmdlKFwiZ2F0ZXdheVwiKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBvbk9wZW5DcmVhdGVUYXNrPXsoKSA9PiBvcGVuKFwiY3JlYXRlVGFza1wiKX1cbiAgICAgICAgICAgIG9uU2VsZWN0QWdlbnQ9eyhpZCkgPT4ge1xuICAgICAgICAgICAgICBzZXRTaWRlYmFyU2VsZWN0ZWRBZ2VudElkKGlkKTtcbiAgICAgICAgICAgICAgb3BlbihcImFnZW50c0ZseW91dFwiKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgLz5cbiAgICAgICAgKTtcbiAgICAgIGNhc2UgXCJjb250cm9sXCI6XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPENvbnRyb2xTZWN0aW9uXG4gICAgICAgICAgICBjdXJyZW50Vmlldz17Y3VycmVudFZpZXd9XG4gICAgICAgICAgICBwcm9qZWN0SWQ9e3Byb2plY3RJZH1cbiAgICAgICAgICAgIG9uTmF2aWdhdGU9e3NldEN1cnJlbnRWaWV3fVxuICAgICAgICAgIC8+XG4gICAgICAgICk7XG4gICAgICBjYXNlIFwib3BzXCI6XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPE9wc1NlY3Rpb25cbiAgICAgICAgICAgIGN1cnJlbnRWaWV3PXtjdXJyZW50Vmlld31cbiAgICAgICAgICAgIHByb2plY3RJZD17cHJvamVjdElkfVxuICAgICAgICAgICAgdGFza0NvdW50PXt0YXNrQ291bnR9XG4gICAgICAgICAgICBvblRhc2tTZWxlY3Q9e3NldFNlbGVjdGVkVGFza0lkfVxuICAgICAgICAgICAgbGl2ZUZlZWRFeHBhbmRlZD17bGl2ZUZlZWRFeHBhbmRlZH1cbiAgICAgICAgICAgIG9uVG9nZ2xlTGl2ZUZlZWQ9eygpID0+IHNldExpdmVGZWVkRXhwYW5kZWQoKHYpID0+ICF2KX1cbiAgICAgICAgICAgIGthbmJhbkZpbHRlcnM9e2thbmJhbkZpbHRlcnN9XG4gICAgICAgICAgICBvbkZpbHRlcnNDaGFuZ2U9e3NldEthbmJhbkZpbHRlcnN9XG4gICAgICAgICAgICBzaWRlYmFyU2VsZWN0ZWRBZ2VudElkPXtzaWRlYmFyU2VsZWN0ZWRBZ2VudElkfVxuICAgICAgICAgICAgb25BZ2VudFNlbGVjdD17c2V0U2lkZWJhclNlbGVjdGVkQWdlbnRJZH1cbiAgICAgICAgICAgIG9uU2lkZWJhcldpZHRoQ2hhbmdlPXtzZXRTaWRlYmFyV2lkdGh9XG4gICAgICAgICAgICBvbk9wZW5BcHByb3ZhbHM9eygpID0+IG9wZW4oXCJhcHByb3ZhbHNcIil9XG4gICAgICAgICAgICBvbk9wZW5Qb2xpY3k9eygpID0+IG9wZW4oXCJwb2xpY3lcIil9XG4gICAgICAgICAgICBvbk9wZW5PcGVyYXRvckNvbnRyb2xzPXsoKSA9PiBvcGVuKFwib3BlcmF0b3JDb250cm9sc1wiKX1cbiAgICAgICAgICAgIG9uT3Blbk5vdGlmaWNhdGlvbnM9eygpID0+IG9wZW4oXCJub3RpZmljYXRpb25zXCIpfVxuICAgICAgICAgICAgb25PcGVuU3RhbmR1cD17KCkgPT4gb3BlbihcInN0YW5kdXBcIil9XG4gICAgICAgICAgICBvblBhdXNlU3F1YWQ9eygpID0+IG9wZW4oXCJwYXVzZUNvbmZpcm1cIil9XG4gICAgICAgICAgICBvblJlc3VtZVNxdWFkPXtoYW5kbGVSZXN1bWVTcXVhZH1cbiAgICAgICAgICAgIG9uT3BlbkltcG9ydFByZD17KCkgPT4gb3BlbihcImltcG9ydFByZFwiKX1cbiAgICAgICAgICAgIG9uTmF2aWdhdGU9e3NldEN1cnJlbnRWaWV3fVxuICAgICAgICAgICAgb25OZXdUYXNrPXsoKSA9PiBvcGVuKFwiY3JlYXRlVGFza1wiKX1cbiAgICAgICAgICAvPlxuICAgICAgICApO1xuICAgICAgY2FzZSBcImFnZW50c1wiOlxuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIDxBZ2VudHNTZWN0aW9uXG4gICAgICAgICAgICBjdXJyZW50Vmlldz17Y3VycmVudFZpZXd9XG4gICAgICAgICAgICBwcm9qZWN0SWQ9e3Byb2plY3RJZH1cbiAgICAgICAgICAgIG9uTmF2aWdhdGVUb0lkZW50aXR5PXsoKSA9PiBzZXRDdXJyZW50VmlldyhcImlkZW50aXR5XCIpfVxuICAgICAgICAgICAgb25OYXZpZ2F0ZVRvVGFzaz17KHRhc2tJZCkgPT4ge1xuICAgICAgICAgICAgICBzZXRTZWxlY3RlZFRhc2tJZCh0YXNrSWQpO1xuICAgICAgICAgICAgICBzZXRDdXJyZW50VmlldyhcInRhc2tzXCIpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIG9uTmF2aWdhdGVUb1Rhc2tzPXsoKSA9PiBzZXRDdXJyZW50VmlldyhcInRhc2tzXCIpfVxuICAgICAgICAgICAgb25OYXZpZ2F0ZVRvQWdlbnQ9eyhhZ2VudElkKSA9PiB7XG4gICAgICAgICAgICAgIHNldFNpZGViYXJTZWxlY3RlZEFnZW50SWQoYWdlbnRJZCk7XG4gICAgICAgICAgICAgIHNldEN1cnJlbnRWaWV3KFwiYWdlbnRzXCIpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIG9uT3BlbkNyZWF0ZUFnZW50PXsoKSA9PiBvcGVuKFwiY3JlYXRlQWdlbnRcIil9XG4gICAgICAgICAgLz5cbiAgICAgICAgKTtcbiAgICAgIGNhc2UgXCJjaGF0XCI6XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPENoYXRTZWN0aW9uXG4gICAgICAgICAgICBjdXJyZW50Vmlldz17Y3VycmVudFZpZXd9XG4gICAgICAgICAgICBwcm9qZWN0SWQ9e3Byb2plY3RJZH1cbiAgICAgICAgICAgIG9uT3BlblN1Z2dlc3Rpb25zRHJhd2VyPXsoKSA9PiBvcGVuKFwic3VnZ2VzdGlvbnNEcmF3ZXJcIil9XG4gICAgICAgICAgLz5cbiAgICAgICAgKTtcbiAgICAgIGNhc2UgXCJjb250ZW50XCI6XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPENvbnRlbnRTZWN0aW9uXG4gICAgICAgICAgICBjdXJyZW50Vmlldz17Y3VycmVudFZpZXd9XG4gICAgICAgICAgICBwcm9qZWN0SWQ9e3Byb2plY3RJZH1cbiAgICAgICAgICAgIG9uUHJvamVjdFNlbGVjdD17c2V0UHJvamVjdElkfVxuICAgICAgICAgIC8+XG4gICAgICAgICk7XG4gICAgICBjYXNlIFwiY29tbXNcIjpcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8Q29tbXNTZWN0aW9uXG4gICAgICAgICAgICBjdXJyZW50Vmlldz17Y3VycmVudFZpZXd9XG4gICAgICAgICAgICBwcm9qZWN0SWQ9e3Byb2plY3RJZH1cbiAgICAgICAgICAgIG9uTmF2aWdhdGU9e3NldEN1cnJlbnRWaWV3fVxuICAgICAgICAgIC8+XG4gICAgICAgICk7XG4gICAgICBjYXNlIFwia25vd2xlZGdlXCI6XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPEtub3dsZWRnZVNlY3Rpb25cbiAgICAgICAgICAgIGN1cnJlbnRWaWV3PXtjdXJyZW50Vmlld31cbiAgICAgICAgICAgIHByb2plY3RJZD17cHJvamVjdElkfVxuICAgICAgICAgICAgb25OYXZpZ2F0ZT17c2V0Q3VycmVudFZpZXd9XG4gICAgICAgICAgICBvblRhc2tTZWxlY3Q9eyh0YXNrSWQpID0+IHtcbiAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRUYXNrSWQodGFza0lkIGFzIElkPFwidGFza3NcIj4pO1xuICAgICAgICAgICAgICBzZXRDdXJyZW50VmlldyhcInRhc2tzXCIpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICApO1xuICAgICAgY2FzZSBcImNvZGVcIjpcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8Q29kZVNlY3Rpb25cbiAgICAgICAgICAgIGN1cnJlbnRWaWV3PXtjdXJyZW50Vmlld31cbiAgICAgICAgICAgIHByb2plY3RJZD17cHJvamVjdElkfVxuICAgICAgICAgICAgb25UYXNrU2VsZWN0PXsodGFza0lkKSA9PiB7XG4gICAgICAgICAgICAgIHNldFNlbGVjdGVkVGFza0lkKHRhc2tJZCk7XG4gICAgICAgICAgICAgIHNldEN1cnJlbnRWaWV3KFwidGFza3NcIik7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgIC8+XG4gICAgICAgICk7XG4gICAgICBjYXNlIFwicXVhbGl0eVwiOlxuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIDxRdWFsaXR5U2VjdGlvblxuICAgICAgICAgICAgY3VycmVudFZpZXc9e2N1cnJlbnRWaWV3fVxuICAgICAgICAgICAgcHJvamVjdElkPXtwcm9qZWN0SWR9XG4gICAgICAgICAgICBzZWxlY3RlZFFjUnVuSWQ9e3NlbGVjdGVkUWNSdW5JZH1cbiAgICAgICAgICAgIHNldFNlbGVjdGVkUWNSdW5JZD17c2V0U2VsZWN0ZWRRY1J1bklkfVxuICAgICAgICAgICAgb25OYXZpZ2F0ZT17c2V0Q3VycmVudFZpZXd9XG4gICAgICAgICAgICBvbk9wZW5TdGFydFFjUnVuPXsoKSA9PiBvcGVuKFwic3RhcnRRY1J1blwiKX1cbiAgICAgICAgICAvPlxuICAgICAgICApO1xuICAgICAgY2FzZSBcInBsYXRmb3JtXCI6XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPFBsYXRmb3JtU2VjdGlvblxuICAgICAgICAgICAgY3VycmVudFZpZXc9e2N1cnJlbnRWaWV3fVxuICAgICAgICAgICAgcHJvamVjdElkPXtwcm9qZWN0SWR9XG4gICAgICAgICAgICBvbk5hdmlnYXRlPXtzZXRDdXJyZW50Vmlld31cbiAgICAgICAgICAgIG9uT3BlbkhlYWx0aERhc2hib2FyZD17KCkgPT4gb3BlbihcImhlYWx0aERhc2hib2FyZFwiKX1cbiAgICAgICAgICAgIG9uT3Blbk1vbml0b3JpbmdEYXNoYm9hcmQ9eygpID0+IG9wZW4oXCJtb25pdG9yaW5nRGFzaGJvYXJkXCIpfVxuICAgICAgICAgICAgb25UYXNrU2VsZWN0PXsodGFza0lkKSA9PiB7XG4gICAgICAgICAgICAgIHNldFNlbGVjdGVkVGFza0lkKHRhc2tJZCk7XG4gICAgICAgICAgICAgIHNldEN1cnJlbnRWaWV3KFwidGFza3NcIik7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgIC8+XG4gICAgICAgICk7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gIH1cblxuICAvLyDilIDilIAgUmVuZGVyIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBUaGUgU29mdHdhcmUgRmFjdG9yeSB2MiBzaGVsbCBpcyBub3cgdGhlIGRlZmF1bHQgVUkuIFNldCB0aGUgYHVpLnNoZWxsLnYxYFxuICAvLyBmbGFnIChvciBWSVRFX0ZMQUdfVUlfU0hFTExfVjE9dHJ1ZSkgdG8gZmFsbCBiYWNrIHRvIHRoZSBsZWdhY3kgc2hlbGwuXG4gIGNvbnN0IGxlZ2FjeVNoZWxsID0gdXNlRmxhZyhcInVpLnNoZWxsLnYxXCIpO1xuXG4gIGlmICghbGVnYWN5U2hlbGwpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPFdvcmtzcGFjZVNjb3BlUHJvdmlkZXIgdmFsdWU9e3sgcHJvamVjdElkLCBzZXRQcm9qZWN0SWQsIHByb2plY3QgfX0+XG4gICAgICAgIDxQcml2YWN5UHJvdmlkZXI+XG4gICAgICAgICAgPEFwcFNoZWxsVjJcbiAgICAgICAgICAgIGFjdGl2ZVZpZXc9e2N1cnJlbnRWaWV3fVxuICAgICAgICAgICAgb25OYXZpZ2F0ZT17c2V0Q3VycmVudFZpZXd9XG4gICAgICAgICAgICB3b3Jrc3BhY2VTd2l0Y2hlcj17XG4gICAgICAgICAgICAgIDxQcm9qZWN0U3dpdGNoZXJcbiAgICAgICAgICAgICAgICBzaG93RGV0YWlsc1xuICAgICAgICAgICAgICAgIG9uTWFuYWdlPXsoKSA9PiBzZXRDdXJyZW50VmlldyhcInByb2plY3RzXCIpfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgb25PcGVuU2VhcmNoPXsoKSA9PiBvcGVuKFwiY29tbWFuZFBhbGV0dGVcIil9XG4gICAgICAgICAgICBwZW5kaW5nQXBwcm92YWxzPXtwZW5kaW5nQXBwcm92YWxzPy5sZW5ndGggPz8gMH1cbiAgICAgICAgICAgIG9uT3BlbkFwcHJvdmFscz17KCkgPT4gb3BlbihcImFwcHJvdmFsc1wiKX1cbiAgICAgICAgICAgIHByb2plY3RJZD17cHJvamVjdElkfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxTdXNwZW5zZSBmYWxsYmFjaz17PFNlY3Rpb25Mb2FkaW5nU3RhdGUgLz59PntyZW5kZXJTZWN0aW9uKCl9PC9TdXNwZW5zZT5cbiAgICAgICAgICA8L0FwcFNoZWxsVjI+XG4gICAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXtudWxsfT5cbiAgICAgICAgICAgIDxUYXNrRHJhd2VyVGFicyB0YXNrSWQ9e3NlbGVjdGVkVGFza0lkfSBvbkNsb3NlPXsoKSA9PiBzZXRTZWxlY3RlZFRhc2tJZChudWxsKX0gLz5cbiAgICAgICAgICA8L1N1c3BlbnNlPlxuICAgICAgICAgIDxTdXNwZW5zZSBmYWxsYmFjaz17bnVsbH0+XG4gICAgICAgICAgICA8TW9kYWxMYXllclxuICAgICAgICAgICAgICBwcm9qZWN0SWQ9e3Byb2plY3RJZH1cbiAgICAgICAgICAgICAgbW9kYWxzPXttb2RhbHN9XG4gICAgICAgICAgICAgIG9wZW49e29wZW59XG4gICAgICAgICAgICAgIGNsb3NlPXtjbG9zZX1cbiAgICAgICAgICAgICAgc2VsZWN0ZWRUYXNrSWQ9e3NlbGVjdGVkVGFza0lkfVxuICAgICAgICAgICAgICBzZXRTZWxlY3RlZFRhc2tJZD17c2V0U2VsZWN0ZWRUYXNrSWR9XG4gICAgICAgICAgICAgIHNpZGViYXJTZWxlY3RlZEFnZW50SWQ9e3NpZGViYXJTZWxlY3RlZEFnZW50SWR9XG4gICAgICAgICAgICAgIHNldFNpZGViYXJTZWxlY3RlZEFnZW50SWQ9e3NldFNpZGViYXJTZWxlY3RlZEFnZW50SWR9XG4gICAgICAgICAgICAgIHNpZGViYXJXaWR0aD17c2lkZWJhcldpZHRofVxuICAgICAgICAgICAgICBvbk5hdmlnYXRlPXtzZXRDdXJyZW50Vmlld31cbiAgICAgICAgICAgICAgb25Db25maXJtUGF1c2VTcXVhZD17aGFuZGxlQ29uZmlybVBhdXNlU3F1YWR9XG4gICAgICAgICAgICAgIG9uUmVzdW1lU3F1YWQ9e2hhbmRsZVJlc3VtZVNxdWFkfVxuICAgICAgICAgICAgICBvblRvYXN0PXt0b2FzdH1cbiAgICAgICAgICAgICAgb25OYXZpZ2F0ZVRvR2F0ZXdheT17KCkgPT4ge1xuICAgICAgICAgICAgICAgIGhhbmRsZVNlY3Rpb25DaGFuZ2UoXCJhZ2VudHNcIik7XG4gICAgICAgICAgICAgICAgaGFuZGxlVGFiQ2hhbmdlKFwiZ2F0ZXdheVwiKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9TdXNwZW5zZT5cbiAgICAgICAgPC9Qcml2YWN5UHJvdmlkZXI+XG4gICAgICA8L1dvcmtzcGFjZVNjb3BlUHJvdmlkZXI+XG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPFdvcmtzcGFjZVNjb3BlUHJvdmlkZXIgdmFsdWU9e3sgcHJvamVjdElkLCBzZXRQcm9qZWN0SWQsIHByb2plY3QgfX0+XG4gICAgICA8UHJpdmFjeVByb3ZpZGVyPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtc2NyZWVuIGZsZXgtY29sIGJnLWJhY2tncm91bmQgdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgIDxBcHBUb3BCYXJcbiAgICAgICAgICBwcm9qZWN0U3dpdGNoZXI9ezxQcm9qZWN0U3dpdGNoZXIgLz59XG4gICAgICAgICAgc2VhcmNoQmFyPXtcbiAgICAgICAgICAgIDxTZWFyY2hCYXJcbiAgICAgICAgICAgICAgcHJvamVjdElkPXtwcm9qZWN0SWQgPz8gdW5kZWZpbmVkfVxuICAgICAgICAgICAgICBvblJlc3VsdENsaWNrPXsodGFza0lkKSA9PiBzZXRTZWxlY3RlZFRhc2tJZCh0YXNrSWQgYXMgSWQ8XCJ0YXNrc1wiPil9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIH1cbiAgICAgICAgICBhY3RpdmVDb3VudD17YWN0aXZlQ291bnR9XG4gICAgICAgICAgdGFza0NvdW50PXt0YXNrQ291bnR9XG4gICAgICAgICAgYWlTdGF0dXM9e2FpU3RhdHVzfVxuICAgICAgICAgIHRpbWVTdHI9e3RpbWVTdHJ9XG4gICAgICAgICAgZGF0ZVN0cj17ZGF0ZVN0cn1cbiAgICAgICAgICBwZW5kaW5nQXBwcm92YWxzPXtwZW5kaW5nQXBwcm92YWxzPy5sZW5ndGggPz8gMH1cbiAgICAgICAgICBwcm9qZWN0SWQ9e3Byb2plY3RJZH1cbiAgICAgICAgICBvbk5ld1Rhc2s9eygpID0+IG9wZW4oXCJjcmVhdGVUYXNrXCIpfVxuICAgICAgICAgIG9uT3BlbkNvbnRyb2xzPXsoKSA9PiBvcGVuKFwib3BlcmF0b3JDb250cm9sc1wiKX1cbiAgICAgICAgICBvbk9wZW5Db21tYW5kUGFsZXR0ZT17KCkgPT4gb3BlbihcImNvbW1hbmRQYWxldHRlXCIpfVxuICAgICAgICAgIG9uT3BlbkNvc3RBbmFseXRpY3M9eygpID0+IG9wZW4oXCJjb3N0QW5hbHl0aWNzXCIpfVxuICAgICAgICAgIG9uT3BlbkJ1ZGdldEJ1cm5Eb3duPXsoKSA9PiBvcGVuKFwiYnVkZ2V0QnVybkRvd25cIil9XG4gICAgICAgICAgb25PcGVuQWR2YW5jZWRBbmFseXRpY3M9eygpID0+IG9wZW4oXCJhZHZhbmNlZEFuYWx5dGljc1wiKX1cbiAgICAgICAgICBvbk9wZW5IZWFsdGhEYXNoYm9hcmQ9eygpID0+IG9wZW4oXCJoZWFsdGhEYXNoYm9hcmRcIil9XG4gICAgICAgICAgb25PcGVuTW9uaXRvcmluZ0Rhc2hib2FyZD17KCkgPT4gb3BlbihcIm1vbml0b3JpbmdEYXNoYm9hcmRcIil9XG4gICAgICAgICAgb25PcGVuRGFzaGJvYXJkT3ZlcnZpZXc9eygpID0+IGhhbmRsZVNlY3Rpb25DaGFuZ2UoXCJob21lXCIpfVxuICAgICAgICAgIG9uT3BlbkFjdGl2aXR5RmVlZD17KCkgPT4gb3BlbihcImFjdGl2aXR5RmVlZFwiKX1cbiAgICAgICAgICBvbk9wZW5LZXlib2FyZEhlbHA9eygpID0+IG9wZW4oXCJrZXlib2FyZEhlbHBcIil9XG4gICAgICAgICAgb25PcGVuQXBwcm92YWxzPXsoKSA9PiBvcGVuKFwiYXBwcm92YWxzXCIpfVxuICAgICAgICAgIG9uT3Blbk5vdGlmaWNhdGlvbnM9eygpID0+IG9wZW4oXCJub3RpZmljYXRpb25zXCIpfVxuICAgICAgICAgIG9uT3BlbkFnZW50c0ZseW91dD17KCkgPT4geyBzZXRTaWRlYmFyU2VsZWN0ZWRBZ2VudElkKG51bGwpOyBvcGVuKFwiYWdlbnRzRmx5b3V0XCIpOyB9fVxuICAgICAgICAgIG9uT3BlbkFpU3RhdHVzPXsoKSA9PiB7XG4gICAgICAgICAgICBpZiAoYWlTdGF0dXMudGFza0lkKSB7XG4gICAgICAgICAgICAgIHNldFNlbGVjdGVkVGFza0lkKGFpU3RhdHVzLnRhc2tJZCk7XG4gICAgICAgICAgICAgIHNldEN1cnJlbnRWaWV3KFwidGFza3NcIik7XG4gICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHNldEN1cnJlbnRWaWV3KFwiYWdlbnRzXCIpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgb25PcGVuTWlzc2lvbk1vZGFsPXsoKSA9PiBvcGVuKFwibWlzc2lvbk1vZGFsXCIpfVxuICAgICAgICAgIG9uT3BlblN1Z2dlc3Rpb25zRHJhd2VyPXsoKSA9PiBvcGVuKFwic3VnZ2VzdGlvbnNEcmF3ZXJcIil9XG4gICAgICAgIC8+XG5cbiAgICAgICAgPENvbW1hbmROYXYgYWN0aXZlU2VjdGlvbj17YWN0aXZlU2VjdGlvbn0gb25TZWN0aW9uQ2hhbmdlPXtoYW5kbGVTZWN0aW9uQ2hhbmdlfSAvPlxuXG4gICAgICAgIHtzZWN0aW9uVGFicyAmJiAoXG4gICAgICAgICAgPFRhYkJhciB0YWJzPXtzZWN0aW9uVGFic30gYWN0aXZlVGFiPXtjdXJyZW50Vmlld30gb25UYWJDaGFuZ2U9e2hhbmRsZVRhYkNoYW5nZX0gLz5cbiAgICAgICAgKX1cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC0xIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgIDxQYWdlVHJhbnNpdGlvbiB2aWV3S2V5PXtjdXJyZW50Vmlld30+XG4gICAgICAgICAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxTZWN0aW9uTG9hZGluZ1N0YXRlIC8+fT5cbiAgICAgICAgICAgICAge3JlbmRlclNlY3Rpb24oKX1cbiAgICAgICAgICAgIDwvU3VzcGVuc2U+XG4gICAgICAgICAgPC9QYWdlVHJhbnNpdGlvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXtudWxsfT5cbiAgICAgICAgICA8VGFza0RyYXdlclRhYnMgdGFza0lkPXtzZWxlY3RlZFRhc2tJZH0gb25DbG9zZT17KCkgPT4gc2V0U2VsZWN0ZWRUYXNrSWQobnVsbCl9IC8+XG4gICAgICAgIDwvU3VzcGVuc2U+XG5cbiAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXtudWxsfT5cbiAgICAgICAgICA8TW9kYWxMYXllclxuICAgICAgICAgICAgcHJvamVjdElkPXtwcm9qZWN0SWR9XG4gICAgICAgICAgICBtb2RhbHM9e21vZGFsc31cbiAgICAgICAgICAgIG9wZW49e29wZW59XG4gICAgICAgICAgICBjbG9zZT17Y2xvc2V9XG4gICAgICAgICAgICBzZWxlY3RlZFRhc2tJZD17c2VsZWN0ZWRUYXNrSWR9XG4gICAgICAgICAgICBzZXRTZWxlY3RlZFRhc2tJZD17c2V0U2VsZWN0ZWRUYXNrSWR9XG4gICAgICAgICAgICBzaWRlYmFyU2VsZWN0ZWRBZ2VudElkPXtzaWRlYmFyU2VsZWN0ZWRBZ2VudElkfVxuICAgICAgICAgICAgc2V0U2lkZWJhclNlbGVjdGVkQWdlbnRJZD17c2V0U2lkZWJhclNlbGVjdGVkQWdlbnRJZH1cbiAgICAgICAgICAgIHNpZGViYXJXaWR0aD17c2lkZWJhcldpZHRofVxuICAgICAgICAgICAgb25OYXZpZ2F0ZT17c2V0Q3VycmVudFZpZXd9XG4gICAgICAgICAgICBvbkNvbmZpcm1QYXVzZVNxdWFkPXtoYW5kbGVDb25maXJtUGF1c2VTcXVhZH1cbiAgICAgICAgICAgIG9uUmVzdW1lU3F1YWQ9e2hhbmRsZVJlc3VtZVNxdWFkfVxuICAgICAgICAgICAgb25Ub2FzdD17dG9hc3R9XG4gICAgICAgICAgICBvbk5hdmlnYXRlVG9HYXRld2F5PXsoKSA9PiB7XG4gICAgICAgICAgICAgIGhhbmRsZVNlY3Rpb25DaGFuZ2UoXCJhZ2VudHNcIik7XG4gICAgICAgICAgICAgIGhhbmRsZVRhYkNoYW5nZShcImdhdGV3YXlcIik7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvU3VzcGVuc2U+XG4gICAgICA8L2Rpdj5cbiAgICAgIDwvUHJpdmFjeVByb3ZpZGVyPlxuICAgIDwvV29ya3NwYWNlU2NvcGVQcm92aWRlcj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL0FwcC50c3gifQ==