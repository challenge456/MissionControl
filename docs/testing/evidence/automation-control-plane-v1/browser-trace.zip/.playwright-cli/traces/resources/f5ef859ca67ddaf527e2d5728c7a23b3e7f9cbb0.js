import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/AgentDashboard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { cn } from "/src/lib/utils.ts";
import { StatusBadge } from "/src/components/factory/badges.tsx";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger
} from "/src/components/ui/tooltip.tsx";
const STATUS_TONE = {
  ACTIVE: "success",
  PAUSED: "warning",
  OFFLINE: "neutral",
  DRAINED: "neutral",
  QUARANTINED: "error"
};
export function AgentDashboard({ projectId, onClose, onSelectAgent }) {
  _s();
  const agents = useQuery(
    api.agents.listAll,
    projectId ? { projectId } : {}
  );
  const tasks = useQuery(
    api.tasks.listAll,
    projectId ? { projectId } : {}
  );
  const runs = useQuery(
    api.runs.listRecent,
    projectId ? { projectId, limit: 1e3 } : { limit: 1e3 }
  );
  if (!agents || !tasks || !runs) {
    return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-surface-1 border border-line rounded-xl p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-full border-2 border-line border-t-ink animate-spin" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
      lineNumber: 66,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
      lineNumber: 65,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
      lineNumber: 64,
      columnNumber: 7
    }, this);
  }
  const agentMetrics = agents.map((agent) => {
    const agentTasks = tasks.filter((t) => t.assigneeIds.includes(agent._id));
    const agentRuns = runs.filter((r) => r.agentId === agent._id);
    const completedTasks = agentTasks.filter((t) => t.status === "DONE").length;
    const inProgressTasks = agentTasks.filter((t) => t.status === "IN_PROGRESS").length;
    const totalCost = agentRuns.reduce((sum, r) => sum + r.costUsd, 0);
    const avgCostPerRun = agentRuns.length > 0 ? totalCost / agentRuns.length : 0;
    const successRate = agentRuns.length > 0 ? agentRuns.filter((r) => r.status === "COMPLETED").length / agentRuns.length * 100 : 0;
    return {
      agent,
      completedTasks,
      inProgressTasks,
      totalTasks: agentTasks.length,
      totalRuns: agentRuns.length,
      totalCost,
      avgCostPerRun,
      successRate,
      spendToday: agent.spendToday,
      budgetDaily: agent.budgetDaily,
      budgetRemaining: agent.budgetDaily - agent.spendToday,
      utilization: agent.budgetDaily > 0 ? agent.spendToday / agent.budgetDaily * 100 : 0
    };
  });
  agentMetrics.sort((a, b) => b.totalCost - a.totalCost);
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-surface-1 border border-line rounded-xl max-w-[80rem] w-full max-h-[90vh] overflow-hidden flex flex-col", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "p-6 border-b border-line", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[19px] font-semibold text-ink m-0", children: "Agent Performance Dashboard" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
          lineNumber: 109,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[13.5px] text-ink-secondary mt-1 mb-0", children: [
          agents.length,
          " agents · ",
          runs.length,
          " runs · $",
          agentMetrics.reduce((sum, m) => sum + m.totalCost, 0).toFixed(2),
          " total cost"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
          lineNumber: 110,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
        lineNumber: 108,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: onClose, className: "bg-transparent border-none text-ink-muted hover:text-ink transition-colors duration-150 cursor-pointer p-1", "aria-label": "Close agent dashboard", children: /* @__PURE__ */ jsxDEV("svg", { width: "24", height: "24", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", "aria-hidden": "true", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M6 18L18 6M6 6l12 12" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
        lineNumber: 116,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
        lineNumber: 115,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
        lineNumber: 114,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
      lineNumber: 107,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
      lineNumber: 106,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-y-auto p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-[repeat(auto-fill,minmax(340px,1fr))] gap-4", children: agentMetrics.map(
      ({ agent, ...metrics }) => /* @__PURE__ */ jsxDEV(TooltipProvider, { children: /* @__PURE__ */ jsxDEV(Tooltip, { children: [
        /* @__PURE__ */ jsxDEV(TooltipTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(
          "div",
          {
            role: onSelectAgent ? "button" : void 0,
            tabIndex: onSelectAgent ? 0 : void 0,
            onClick: onSelectAgent ? () => onSelectAgent(agent._id) : void 0,
            onKeyDown: onSelectAgent ? (e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                onSelectAgent(agent._id);
              }
            } : void 0,
            className: cn(
              "bg-surface-2 rounded-xl p-4 border border-line",
              onSelectAgent && "cursor-pointer hover:border-line-strong transition-colors duration-150"
            ),
            "aria-label": onSelectAgent ? `Agent ${agent.name}. Click to open details.` : void 0,
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between mb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-line bg-surface-1 text-lg", children: agent.emoji || agent.name.charAt(0).toUpperCase() }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                  lineNumber: 151,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-ink m-0 text-[15px]", title: agent._id, children: agent.name }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 155,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mt-1", children: [
                    /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", children: agent.role }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                      lineNumber: 159,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(StatusBadge, { tone: STATUS_TONE[agent.status] ?? "neutral", children: agent.status }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                      lineNumber: 160,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 158,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                  lineNumber: 154,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                lineNumber: 150,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                lineNumber: 149,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3 mb-4", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] text-ink-muted mb-0.5", children: "Tasks" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 171,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[17px] font-semibold font-mono text-ink", children: [
                    metrics.completedTasks,
                    "/",
                    metrics.totalTasks
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 172,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] text-ink-muted", children: [
                    metrics.inProgressTasks,
                    " in progress"
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 175,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                  lineNumber: 170,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] text-ink-muted mb-0.5", children: "Runs" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 180,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[17px] font-semibold font-mono text-ink", children: metrics.totalRuns }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 181,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] text-ink-muted", children: [
                    metrics.successRate != null && !Number.isNaN(metrics.successRate) ? metrics.successRate.toFixed(0) : "—",
                    "% success"
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 182,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                  lineNumber: 179,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] text-ink-muted mb-0.5", children: "Total Cost" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 189,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[17px] font-semibold font-mono text-ink", children: [
                    "$",
                    metrics.totalCost.toFixed(2)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 190,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] text-ink-muted", children: [
                    "$",
                    metrics.avgCostPerRun.toFixed(3),
                    "/run"
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 193,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                  lineNumber: 188,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] text-ink-muted mb-0.5", children: "Today's Spend" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 198,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[17px] font-semibold font-mono text-ink", children: [
                    "$",
                    metrics.spendToday.toFixed(2)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 199,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] text-ink-muted", children: [
                    "$",
                    metrics.budgetRemaining.toFixed(2),
                    " left"
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 202,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                  lineNumber: 197,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                lineNumber: 169,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between text-[12.5px] text-ink-muted mb-1", children: [
                  /* @__PURE__ */ jsxDEV("span", { children: "Budget Utilization" }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 211,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "font-mono", children: [
                    metrics.utilization != null && !Number.isNaN(metrics.utilization) ? metrics.utilization.toFixed(0) : "—",
                    "%"
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 212,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                  lineNumber: 210,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-full bg-surface-1 border border-line rounded-full h-2 overflow-hidden", children: /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: cn(
                      "h-full rounded-full transition-[width] duration-300",
                      (metrics.utilization ?? 0) >= 90 ? "bg-err" : (metrics.utilization ?? 0) >= 70 ? "bg-warn" : "bg-ok"
                    ),
                    style: { width: `${Math.min(metrics.utilization ?? 0, 100)}%` }
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 219,
                    columnNumber: 21
                  },
                  this
                ) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                  lineNumber: 218,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between text-[12.5px] font-mono text-ink-muted mt-1", children: [
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    "$",
                    metrics.spendToday.toFixed(2)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 232,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    "$",
                    metrics.budgetDaily.toFixed(2)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 233,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                  lineNumber: 231,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                lineNumber: 209,
                columnNumber: 17
              }, this),
              agent.allowedTaskTypes && agent.allowedTaskTypes.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-4 border-t border-line", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] text-ink-muted mb-0.5", children: "Allowed Task Types" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                  lineNumber: 240,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1 mt-1.5", children: agent.allowedTaskTypes.map(
                  (type) => /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", children: type }, type, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                    lineNumber: 243,
                    columnNumber: 25
                  }, this)
                ) }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                  lineNumber: 241,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
                lineNumber: 239,
                columnNumber: 21
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
            lineNumber: 129,
            columnNumber: 21
          },
          this
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
          lineNumber: 128,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV(TooltipContent, { side: "top", className: "max-w-[280px]", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "font-medium", children: agent.name }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
            lineNumber: 253,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-[11.5px] font-mono text-ink-muted break-all", children: agent._id }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
            lineNumber: 254,
            columnNumber: 21
          }, this),
          onSelectAgent && /* @__PURE__ */ jsxDEV("div", { className: "text-[11.5px] mt-0.5", children: "Click to open agent details" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
            lineNumber: 255,
            columnNumber: 39
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
          lineNumber: 252,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
        lineNumber: 127,
        columnNumber: 17
      }, this) }, agent._id, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
        lineNumber: 126,
        columnNumber: 13
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
      lineNumber: 124,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
      lineNumber: 123,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
    lineNumber: 104,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx",
    lineNumber: 103,
    columnNumber: 5
  }, this);
}
_s(AgentDashboard, "eJqkSkN7gwNTWEkD8QcsUW9VToo=", false, function() {
  return [useQuery, useQuery, useQuery];
});
_c = AgentDashboard;
var _c;
$RefreshReg$(_c, "AgentDashboard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/AgentDashboard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOENVOzs7Ozs7Ozs7Ozs7Ozs7OztBQTlDVixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsV0FBVztBQUVwQixTQUFTQyxVQUFVO0FBQ25CLFNBQVNDLG1CQUEwQztBQUNuRDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFRUCxNQUFNQyxjQUF3RDtBQUFBLEVBQzVEQyxRQUFRO0FBQUEsRUFDUkMsUUFBUTtBQUFBLEVBQ1JDLFNBQVM7QUFBQSxFQUNUQyxTQUFTO0FBQUEsRUFDVEMsYUFBYTtBQUNmO0FBRU8sZ0JBQVNDLGVBQWUsRUFBRUMsV0FBV0MsU0FBU0MsY0FBbUMsR0FBRztBQUFBQyxLQUFBO0FBQ3pGLFFBQU1DLFNBQVNuQjtBQUFBQSxJQUNiQyxJQUFJa0IsT0FBT0M7QUFBQUEsSUFDWEwsWUFBWSxFQUFFQSxVQUFVLElBQUksQ0FBQztBQUFBLEVBQy9CO0FBRUEsUUFBTU0sUUFBUXJCO0FBQUFBLElBQ1pDLElBQUlvQixNQUFNRDtBQUFBQSxJQUNWTCxZQUFZLEVBQUVBLFVBQVUsSUFBSSxDQUFDO0FBQUEsRUFDL0I7QUFFQSxRQUFNTyxPQUFPdEI7QUFBQUEsSUFDWEMsSUFBSXFCLEtBQUtDO0FBQUFBLElBQ1RSLFlBQVksRUFBRUEsV0FBV1MsT0FBTyxJQUFLLElBQUksRUFBRUEsT0FBTyxJQUFLO0FBQUEsRUFDekQ7QUFFQSxNQUFJLENBQUNMLFVBQVUsQ0FBQ0UsU0FBUyxDQUFDQyxNQUFNO0FBQzlCLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLDJFQUNiLGlDQUFDLFNBQUksV0FBVSxrREFDYixpQ0FBQyxTQUFJLFdBQVUseUVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRixLQUR0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxFQUVKO0FBRUEsUUFBTUcsZUFBZU4sT0FBT08sSUFBSSxDQUFDQyxVQUFVO0FBQ3pDLFVBQU1DLGFBQWFQLE1BQU1RLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRUMsWUFBWUMsU0FBU0wsTUFBTU0sR0FBRyxDQUFDO0FBQ3hFLFVBQU1DLFlBQVlaLEtBQUtPLE9BQU8sQ0FBQ00sTUFBTUEsRUFBRUMsWUFBWVQsTUFBTU0sR0FBRztBQUU1RCxVQUFNSSxpQkFBaUJULFdBQVdDLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRVEsV0FBVyxNQUFNLEVBQUVDO0FBQ3JFLFVBQU1DLGtCQUFrQlosV0FBV0MsT0FBTyxDQUFDQyxNQUFNQSxFQUFFUSxXQUFXLGFBQWEsRUFBRUM7QUFDN0UsVUFBTUUsWUFBWVAsVUFBVVEsT0FBTyxDQUFDQyxLQUFLUixNQUFNUSxNQUFNUixFQUFFUyxTQUFTLENBQUM7QUFDakUsVUFBTUMsZ0JBQWdCWCxVQUFVSyxTQUFTLElBQUlFLFlBQVlQLFVBQVVLLFNBQVM7QUFDNUUsVUFBTU8sY0FBY1osVUFBVUssU0FBUyxJQUNsQ0wsVUFBVUwsT0FBTyxDQUFDTSxNQUFNQSxFQUFFRyxXQUFXLFdBQVcsRUFBRUMsU0FBU0wsVUFBVUssU0FBVSxNQUNoRjtBQUVKLFdBQU87QUFBQSxNQUNMWjtBQUFBQSxNQUNBVTtBQUFBQSxNQUNBRztBQUFBQSxNQUNBTyxZQUFZbkIsV0FBV1c7QUFBQUEsTUFDdkJTLFdBQVdkLFVBQVVLO0FBQUFBLE1BQ3JCRTtBQUFBQSxNQUNBSTtBQUFBQSxNQUNBQztBQUFBQSxNQUNBRyxZQUFZdEIsTUFBTXNCO0FBQUFBLE1BQ2xCQyxhQUFhdkIsTUFBTXVCO0FBQUFBLE1BQ25CQyxpQkFBaUJ4QixNQUFNdUIsY0FBY3ZCLE1BQU1zQjtBQUFBQSxNQUMzQ0csYUFBYXpCLE1BQU11QixjQUFjLElBQUt2QixNQUFNc0IsYUFBYXRCLE1BQU11QixjQUFlLE1BQU07QUFBQSxJQUN0RjtBQUFBLEVBQ0YsQ0FBQztBQUVEekIsZUFBYTRCLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTUEsRUFBRWQsWUFBWWEsRUFBRWIsU0FBUztBQUVyRCxTQUNFLHVCQUFDLFNBQUksV0FBVSwyRUFDYixpQ0FBQyxTQUFJLFdBQVUsOEdBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsNEJBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSwwQ0FBeUMsMkNBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Y7QUFBQSxRQUNsRix1QkFBQyxPQUFFLFdBQVUsOENBQ1Z0QjtBQUFBQSxpQkFBT29CO0FBQUFBLFVBQU87QUFBQSxVQUFXakIsS0FBS2lCO0FBQUFBLFVBQU87QUFBQSxVQUFVZCxhQUFhaUIsT0FBTyxDQUFDQyxLQUFLYSxNQUFNYixNQUFNYSxFQUFFZixXQUFXLENBQUMsRUFBRWdCLFFBQVEsQ0FBQztBQUFBLFVBQUU7QUFBQSxhQURuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxTQUFTekMsU0FBUyxXQUFVLDhHQUE2RyxjQUFXLHlCQUMxSixpQ0FBQyxTQUFJLE9BQU0sTUFBSyxRQUFPLE1BQUssTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUFZLGVBQVksUUFDNUYsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFhLEdBQUcsR0FBRSwwQkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRixLQUQ3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDhCQUNiLGlDQUFDLFNBQUksV0FBVSw4REFDWlMsdUJBQWFDO0FBQUFBLE1BQUksQ0FBQyxFQUFFQyxPQUFPLEdBQUcrQixRQUFRLE1BQ3JDLHVCQUFDLG1CQUNDLGlDQUFDLFdBQ0M7QUFBQSwrQkFBQyxrQkFBZSxTQUFPLE1BQ3JCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNekMsZ0JBQWdCLFdBQVcwQztBQUFBQSxZQUNqQyxVQUFVMUMsZ0JBQWdCLElBQUkwQztBQUFBQSxZQUM5QixTQUFTMUMsZ0JBQWdCLE1BQU1BLGNBQWNVLE1BQU1NLEdBQUcsSUFBSTBCO0FBQUFBLFlBQzFELFdBQ0UxQyxnQkFDSSxDQUFDMkMsTUFBTTtBQUNMLGtCQUFJQSxFQUFFQyxRQUFRLFdBQVdELEVBQUVDLFFBQVEsS0FBSztBQUN0Q0Qsa0JBQUVFLGVBQWU7QUFDakI3Qyw4QkFBY1UsTUFBTU0sR0FBRztBQUFBLGNBQ3pCO0FBQUEsWUFDRixJQUNBMEI7QUFBQUEsWUFDTixXQUFXekQ7QUFBQUEsY0FDVDtBQUFBLGNBQ0FlLGlCQUFpQjtBQUFBLFlBQ25CO0FBQUEsWUFDQSxjQUFZQSxnQkFBZ0IsU0FBU1UsTUFBTW9DLElBQUksNkJBQTZCSjtBQUFBQSxZQUc1RTtBQUFBLHFDQUFDLFNBQUksV0FBVSx5Q0FDYixpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsd0dBQ2JoQyxnQkFBTXFDLFNBQVNyQyxNQUFNb0MsS0FBS0UsT0FBTyxDQUFDLEVBQUVDLFlBQVksS0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsMENBQXlDLE9BQU92QyxNQUFNTSxLQUNqRU4sZ0JBQU1vQyxRQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDTix1QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSwyQ0FBQyxlQUFZLE1BQUssV0FBV3BDLGdCQUFNd0MsUUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd0M7QUFBQSxvQkFDeEMsdUJBQUMsZUFBWSxNQUFNM0QsWUFBWW1CLE1BQU1XLE1BQU0sS0FBSyxXQUM3Q1gsZ0JBQU1XLFVBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxxQkFUSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVOO0FBQUEsbUJBZEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlTixLQWhCSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlCTjtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsdUNBQUMsU0FDQztBQUFBLHlDQUFDLFNBQUksV0FBVSx1Q0FBc0MscUJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBEO0FBQUEsa0JBQzFELHVCQUFDLFNBQUksV0FBVSxnREFDWm9CO0FBQUFBLDRCQUFRckI7QUFBQUEsb0JBQWU7QUFBQSxvQkFBRXFCLFFBQVFYO0FBQUFBLHVCQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGdDQUNaVztBQUFBQSw0QkFBUWxCO0FBQUFBLG9CQUFnQjtBQUFBLHVCQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsdUNBQXNDLG9CQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RDtBQUFBLGtCQUN6RCx1QkFBQyxTQUFJLFdBQVUsZ0RBQWdEa0Isa0JBQVFWLGFBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlGO0FBQUEsa0JBQ2pGLHVCQUFDLFNBQUksV0FBVSxnQ0FDWFU7QUFBQUEsNEJBQVFaLGVBQWUsUUFBUSxDQUFDc0IsT0FBT0MsTUFBTVgsUUFBUVosV0FBVyxJQUM5RFksUUFBUVosWUFBWVcsUUFBUSxDQUFDLElBQzdCO0FBQUEsb0JBQUs7QUFBQSx1QkFIWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBO0FBQUEscUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsdUNBQXNDLDBCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErRDtBQUFBLGtCQUMvRCx1QkFBQyxTQUFJLFdBQVUsZ0RBQThDO0FBQUE7QUFBQSxvQkFDekRDLFFBQVFqQixVQUFVZ0IsUUFBUSxDQUFDO0FBQUEsdUJBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQThCO0FBQUE7QUFBQSxvQkFDekNDLFFBQVFiLGNBQWNZLFFBQVEsQ0FBQztBQUFBLG9CQUFFO0FBQUEsdUJBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVFBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFNBQUksV0FBVSx1Q0FBc0MsNkJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVFO0FBQUEsa0JBQ3ZFLHVCQUFDLFNBQUksV0FBVSxnREFBOEM7QUFBQTtBQUFBLG9CQUN6REMsUUFBUVQsV0FBV1EsUUFBUSxDQUFDO0FBQUEsdUJBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQThCO0FBQUE7QUFBQSxvQkFDekNDLFFBQVFQLGdCQUFnQk0sUUFBUSxDQUFDO0FBQUEsb0JBQUU7QUFBQSx1QkFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUUE7QUFBQSxtQkFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxQ0E7QUFBQSxjQUdBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsdUVBQ2I7QUFBQSx5Q0FBQyxVQUFLLGtDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdCO0FBQUEsa0JBQ3hCLHVCQUFDLFVBQUssV0FBVSxhQUNaQztBQUFBQSw0QkFBUU4sZUFBZSxRQUFRLENBQUNnQixPQUFPQyxNQUFNWCxRQUFRTixXQUFXLElBQzlETSxRQUFRTixZQUFZSyxRQUFRLENBQUMsSUFDN0I7QUFBQSxvQkFBSztBQUFBLHVCQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxxQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJFQUNiO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVd2RDtBQUFBQSxzQkFDVDtBQUFBLHVCQUNDd0QsUUFBUU4sZUFBZSxNQUFNLEtBQzFCLFlBQ0NNLFFBQVFOLGVBQWUsTUFBTSxLQUM1QixZQUNBO0FBQUEsb0JBQ1I7QUFBQSxvQkFDQSxPQUFPLEVBQUVrQixPQUFPLEdBQUdDLEtBQUtDLElBQUlkLFFBQVFOLGVBQWUsR0FBRyxHQUFHLENBQUMsSUFBSTtBQUFBO0FBQUEsa0JBVGhFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFTa0UsS0FWcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFZQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxpRkFDYjtBQUFBLHlDQUFDLFVBQUs7QUFBQTtBQUFBLG9CQUFFTSxRQUFRVCxXQUFXUSxRQUFRLENBQUM7QUFBQSx1QkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0M7QUFBQSxrQkFDdEMsdUJBQUMsVUFBSztBQUFBO0FBQUEsb0JBQUVDLFFBQVFSLFlBQVlPLFFBQVEsQ0FBQztBQUFBLHVCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1QztBQUFBLHFCQUZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsbUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMEJBO0FBQUEsY0FHQzlCLE1BQU04QyxvQkFBb0I5QyxNQUFNOEMsaUJBQWlCbEMsU0FBUyxLQUN6RCx1QkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsdUNBQXNDLGtDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RTtBQUFBLGdCQUN2RSx1QkFBQyxTQUFJLFdBQVUsK0JBQ1paLGdCQUFNOEMsaUJBQWlCL0M7QUFBQUEsa0JBQUksQ0FBQ2dELFNBQzNCLHVCQUFDLGVBQXVCLE1BQUssV0FDMUJBLGtCQURlQSxNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU1BO0FBQUEsbUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBO0FBQUE7QUFBQSxVQXZIRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUF5SEEsS0ExSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJIQTtBQUFBLFFBQ0EsdUJBQUMsa0JBQWUsTUFBSyxPQUFNLFdBQVUsaUJBQ25DO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGVBQWUvQyxnQkFBTW9DLFFBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlDO0FBQUEsVUFDekMsdUJBQUMsU0FBSSxXQUFVLG9EQUFvRHBDLGdCQUFNTSxPQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RTtBQUFBLFVBQzVFaEIsaUJBQWlCLHVCQUFDLFNBQUksV0FBVSx3QkFBdUIsMkNBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlFO0FBQUEsYUFIckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsV0FqSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtJQSxLQW5Jb0JVLE1BQU1NLEtBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvSUE7QUFBQSxJQUNELEtBdklIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3SUEsS0F6SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBJQTtBQUFBLE9BN0pGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4SkEsS0EvSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdLQTtBQUVKO0FBQUNmLEdBM05lSixnQkFBYztBQUFBLFVBQ2JkLFVBS0RBLFVBS0RBLFFBQVE7QUFBQTtBQUFBLEtBWFBjO0FBQWMsSUFBQTZEO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVF1ZXJ5IiwiYXBpIiwiY24iLCJTdGF0dXNCYWRnZSIsIlRvb2x0aXAiLCJUb29sdGlwQ29udGVudCIsIlRvb2x0aXBQcm92aWRlciIsIlRvb2x0aXBUcmlnZ2VyIiwiU1RBVFVTX1RPTkUiLCJBQ1RJVkUiLCJQQVVTRUQiLCJPRkZMSU5FIiwiRFJBSU5FRCIsIlFVQVJBTlRJTkVEIiwiQWdlbnREYXNoYm9hcmQiLCJwcm9qZWN0SWQiLCJvbkNsb3NlIiwib25TZWxlY3RBZ2VudCIsIl9zIiwiYWdlbnRzIiwibGlzdEFsbCIsInRhc2tzIiwicnVucyIsImxpc3RSZWNlbnQiLCJsaW1pdCIsImFnZW50TWV0cmljcyIsIm1hcCIsImFnZW50IiwiYWdlbnRUYXNrcyIsImZpbHRlciIsInQiLCJhc3NpZ25lZUlkcyIsImluY2x1ZGVzIiwiX2lkIiwiYWdlbnRSdW5zIiwiciIsImFnZW50SWQiLCJjb21wbGV0ZWRUYXNrcyIsInN0YXR1cyIsImxlbmd0aCIsImluUHJvZ3Jlc3NUYXNrcyIsInRvdGFsQ29zdCIsInJlZHVjZSIsInN1bSIsImNvc3RVc2QiLCJhdmdDb3N0UGVyUnVuIiwic3VjY2Vzc1JhdGUiLCJ0b3RhbFRhc2tzIiwidG90YWxSdW5zIiwic3BlbmRUb2RheSIsImJ1ZGdldERhaWx5IiwiYnVkZ2V0UmVtYWluaW5nIiwidXRpbGl6YXRpb24iLCJzb3J0IiwiYSIsImIiLCJtIiwidG9GaXhlZCIsIm1ldHJpY3MiLCJ1bmRlZmluZWQiLCJlIiwia2V5IiwicHJldmVudERlZmF1bHQiLCJuYW1lIiwiZW1vamkiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsInJvbGUiLCJOdW1iZXIiLCJpc05hTiIsIndpZHRoIiwiTWF0aCIsIm1pbiIsImFsbG93ZWRUYXNrVHlwZXMiLCJ0eXBlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQWdlbnREYXNoYm9hcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVF1ZXJ5IH0gZnJvbSBcImNvbnZleC9yZWFjdFwiO1xuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2FwaVwiO1xuaW1wb3J0IHR5cGUgeyBJZCB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9kYXRhTW9kZWxcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5pbXBvcnQgeyBTdGF0dXNCYWRnZSwgdHlwZSBTdGF0dXNCYWRnZVByb3BzIH0gZnJvbSBcIi4vY29tcG9uZW50cy9mYWN0b3J5L2JhZGdlc1wiO1xuaW1wb3J0IHtcbiAgVG9vbHRpcCxcbiAgVG9vbHRpcENvbnRlbnQsXG4gIFRvb2x0aXBQcm92aWRlcixcbiAgVG9vbHRpcFRyaWdnZXIsXG59IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvdG9vbHRpcFwiO1xuXG5pbnRlcmZhY2UgQWdlbnREYXNoYm9hcmRQcm9wcyB7XG4gIHByb2plY3RJZDogSWQ8XCJwcm9qZWN0c1wiPiB8IG51bGw7XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gIG9uU2VsZWN0QWdlbnQ/OiAoYWdlbnRJZDogSWQ8XCJhZ2VudHNcIj4pID0+IHZvaWQ7XG59XG5cbmNvbnN0IFNUQVRVU19UT05FOiBSZWNvcmQ8c3RyaW5nLCBTdGF0dXNCYWRnZVByb3BzW1widG9uZVwiXT4gPSB7XG4gIEFDVElWRTogXCJzdWNjZXNzXCIsXG4gIFBBVVNFRDogXCJ3YXJuaW5nXCIsXG4gIE9GRkxJTkU6IFwibmV1dHJhbFwiLFxuICBEUkFJTkVEOiBcIm5ldXRyYWxcIixcbiAgUVVBUkFOVElORUQ6IFwiZXJyb3JcIixcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBBZ2VudERhc2hib2FyZCh7IHByb2plY3RJZCwgb25DbG9zZSwgb25TZWxlY3RBZ2VudCB9OiBBZ2VudERhc2hib2FyZFByb3BzKSB7XG4gIGNvbnN0IGFnZW50cyA9IHVzZVF1ZXJ5KFxuICAgIGFwaS5hZ2VudHMubGlzdEFsbCxcbiAgICBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCB9IDoge31cbiAgKTtcblxuICBjb25zdCB0YXNrcyA9IHVzZVF1ZXJ5KFxuICAgIGFwaS50YXNrcy5saXN0QWxsLFxuICAgIHByb2plY3RJZCA/IHsgcHJvamVjdElkIH0gOiB7fVxuICApO1xuXG4gIGNvbnN0IHJ1bnMgPSB1c2VRdWVyeShcbiAgICBhcGkucnVucy5saXN0UmVjZW50LFxuICAgIHByb2plY3RJZCA/IHsgcHJvamVjdElkLCBsaW1pdDogMTAwMCB9IDogeyBsaW1pdDogMTAwMCB9XG4gICk7XG5cbiAgaWYgKCFhZ2VudHMgfHwgIXRhc2tzIHx8ICFydW5zKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjay81MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB6LVs5OTk5XSBwLTRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zdXJmYWNlLTEgYm9yZGVyIGJvcmRlci1saW5lIHJvdW5kZWQteGwgcC02XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBib3JkZXItMiBib3JkZXItbGluZSBib3JkZXItdC1pbmsgYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgY29uc3QgYWdlbnRNZXRyaWNzID0gYWdlbnRzLm1hcCgoYWdlbnQpID0+IHtcbiAgICBjb25zdCBhZ2VudFRhc2tzID0gdGFza3MuZmlsdGVyKCh0KSA9PiB0LmFzc2lnbmVlSWRzLmluY2x1ZGVzKGFnZW50Ll9pZCkpO1xuICAgIGNvbnN0IGFnZW50UnVucyA9IHJ1bnMuZmlsdGVyKChyKSA9PiByLmFnZW50SWQgPT09IGFnZW50Ll9pZCk7XG5cbiAgICBjb25zdCBjb21wbGV0ZWRUYXNrcyA9IGFnZW50VGFza3MuZmlsdGVyKCh0KSA9PiB0LnN0YXR1cyA9PT0gXCJET05FXCIpLmxlbmd0aDtcbiAgICBjb25zdCBpblByb2dyZXNzVGFza3MgPSBhZ2VudFRhc2tzLmZpbHRlcigodCkgPT4gdC5zdGF0dXMgPT09IFwiSU5fUFJPR1JFU1NcIikubGVuZ3RoO1xuICAgIGNvbnN0IHRvdGFsQ29zdCA9IGFnZW50UnVucy5yZWR1Y2UoKHN1bSwgcikgPT4gc3VtICsgci5jb3N0VXNkLCAwKTtcbiAgICBjb25zdCBhdmdDb3N0UGVyUnVuID0gYWdlbnRSdW5zLmxlbmd0aCA+IDAgPyB0b3RhbENvc3QgLyBhZ2VudFJ1bnMubGVuZ3RoIDogMDtcbiAgICBjb25zdCBzdWNjZXNzUmF0ZSA9IGFnZW50UnVucy5sZW5ndGggPiAwXG4gICAgICA/IChhZ2VudFJ1bnMuZmlsdGVyKChyKSA9PiByLnN0YXR1cyA9PT0gXCJDT01QTEVURURcIikubGVuZ3RoIC8gYWdlbnRSdW5zLmxlbmd0aCkgKiAxMDBcbiAgICAgIDogMDtcblxuICAgIHJldHVybiB7XG4gICAgICBhZ2VudCxcbiAgICAgIGNvbXBsZXRlZFRhc2tzLFxuICAgICAgaW5Qcm9ncmVzc1Rhc2tzLFxuICAgICAgdG90YWxUYXNrczogYWdlbnRUYXNrcy5sZW5ndGgsXG4gICAgICB0b3RhbFJ1bnM6IGFnZW50UnVucy5sZW5ndGgsXG4gICAgICB0b3RhbENvc3QsXG4gICAgICBhdmdDb3N0UGVyUnVuLFxuICAgICAgc3VjY2Vzc1JhdGUsXG4gICAgICBzcGVuZFRvZGF5OiBhZ2VudC5zcGVuZFRvZGF5LFxuICAgICAgYnVkZ2V0RGFpbHk6IGFnZW50LmJ1ZGdldERhaWx5LFxuICAgICAgYnVkZ2V0UmVtYWluaW5nOiBhZ2VudC5idWRnZXREYWlseSAtIGFnZW50LnNwZW5kVG9kYXksXG4gICAgICB1dGlsaXphdGlvbjogYWdlbnQuYnVkZ2V0RGFpbHkgPiAwID8gKGFnZW50LnNwZW5kVG9kYXkgLyBhZ2VudC5idWRnZXREYWlseSkgKiAxMDAgOiAwLFxuICAgIH07XG4gIH0pO1xuXG4gIGFnZW50TWV0cmljcy5zb3J0KChhLCBiKSA9PiBiLnRvdGFsQ29zdCAtIGEudG90YWxDb3N0KTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjay81MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB6LVs5OTk5XSBwLTRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc3VyZmFjZS0xIGJvcmRlciBib3JkZXItbGluZSByb3VuZGVkLXhsIG1heC13LVs4MHJlbV0gdy1mdWxsIG1heC1oLVs5MHZoXSBvdmVyZmxvdy1oaWRkZW4gZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBib3JkZXItYiBib3JkZXItbGluZVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMTlweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWluayBtLTBcIj5BZ2VudCBQZXJmb3JtYW5jZSBEYXNoYm9hcmQ8L2gyPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMy41cHhdIHRleHQtaW5rLXNlY29uZGFyeSBtdC0xIG1iLTBcIj5cbiAgICAgICAgICAgICAgICB7YWdlbnRzLmxlbmd0aH0gYWdlbnRzIMK3IHtydW5zLmxlbmd0aH0gcnVucyDCtyAke2FnZW50TWV0cmljcy5yZWR1Y2UoKHN1bSwgbSkgPT4gc3VtICsgbS50b3RhbENvc3QsIDApLnRvRml4ZWQoMil9IHRvdGFsIGNvc3RcbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xvc2V9IGNsYXNzTmFtZT1cImJnLXRyYW5zcGFyZW50IGJvcmRlci1ub25lIHRleHQtaW5rLW11dGVkIGhvdmVyOnRleHQtaW5rIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBjdXJzb3ItcG9pbnRlciBwLTFcIiBhcmlhLWxhYmVsPVwiQ2xvc2UgYWdlbnQgZGFzaGJvYXJkXCI+XG4gICAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIyNFwiIGhlaWdodD1cIjI0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XG4gICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPXsyfSBkPVwiTTYgMThMMTggNk02IDZsMTIgMTJcIiAvPlxuICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQ29udGVudCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHAtNlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtW3JlcGVhdChhdXRvLWZpbGwsbWlubWF4KDM0MHB4LDFmcikpXSBnYXAtNFwiPlxuICAgICAgICAgICAge2FnZW50TWV0cmljcy5tYXAoKHsgYWdlbnQsIC4uLm1ldHJpY3MgfSkgPT4gKFxuICAgICAgICAgICAgICA8VG9vbHRpcFByb3ZpZGVyIGtleT17YWdlbnQuX2lkfT5cbiAgICAgICAgICAgICAgICA8VG9vbHRpcD5cbiAgICAgICAgICAgICAgICAgIDxUb29sdGlwVHJpZ2dlciBhc0NoaWxkPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgcm9sZT17b25TZWxlY3RBZ2VudCA/IFwiYnV0dG9uXCIgOiB1bmRlZmluZWR9XG4gICAgICAgICAgICAgICAgICAgICAgdGFiSW5kZXg9e29uU2VsZWN0QWdlbnQgPyAwIDogdW5kZWZpbmVkfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uU2VsZWN0QWdlbnQgPyAoKSA9PiBvblNlbGVjdEFnZW50KGFnZW50Ll9pZCkgOiB1bmRlZmluZWR9XG4gICAgICAgICAgICAgICAgICAgICAgb25LZXlEb3duPXtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VsZWN0QWdlbnRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGUua2V5ID09PSBcIkVudGVyXCIgfHwgZS5rZXkgPT09IFwiIFwiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWxlY3RBZ2VudChhZ2VudC5faWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiB1bmRlZmluZWR9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiYmctc3VyZmFjZS0yIHJvdW5kZWQteGwgcC00IGJvcmRlciBib3JkZXItbGluZVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgb25TZWxlY3RBZ2VudCAmJiBcImN1cnNvci1wb2ludGVyIGhvdmVyOmJvcmRlci1saW5lLXN0cm9uZyB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17b25TZWxlY3RBZ2VudCA/IGBBZ2VudCAke2FnZW50Lm5hbWV9LiBDbGljayB0byBvcGVuIGRldGFpbHMuYCA6IHVuZGVmaW5lZH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBBZ2VudCBIZWFkZXIgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaC05IHctOSBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xIHRleHQtbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWdlbnQuZW1vamkgfHwgYWdlbnQubmFtZS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtaW5rIG0tMCB0ZXh0LVsxNXB4XVwiIHRpdGxlPXthZ2VudC5faWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FnZW50Lm5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdGF0dXNCYWRnZSB0b25lPVwibmV1dHJhbFwiPnthZ2VudC5yb2xlfTwvU3RhdHVzQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U3RhdHVzQmFkZ2UgdG9uZT17U1RBVFVTX1RPTkVbYWdlbnQuc3RhdHVzXSA/PyBcIm5ldXRyYWxcIn0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHthZ2VudC5zdGF0dXN9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L1N0YXR1c0JhZGdlPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIE1ldHJpY3MgR3JpZCAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTMgbWItNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMi41cHhdIHRleHQtaW5rLW11dGVkIG1iLTAuNVwiPlRhc2tzPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTdweF0gZm9udC1zZW1pYm9sZCBmb250LW1vbm8gdGV4dC1pbmtcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7bWV0cmljcy5jb21wbGV0ZWRUYXNrc30ve21ldHJpY3MudG90YWxUYXNrc31cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHttZXRyaWNzLmluUHJvZ3Jlc3NUYXNrc30gaW4gcHJvZ3Jlc3NcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZCBtYi0wLjVcIj5SdW5zPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTdweF0gZm9udC1zZW1pYm9sZCBmb250LW1vbm8gdGV4dC1pbmtcIj57bWV0cmljcy50b3RhbFJ1bnN9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHsobWV0cmljcy5zdWNjZXNzUmF0ZSAhPSBudWxsICYmICFOdW1iZXIuaXNOYU4obWV0cmljcy5zdWNjZXNzUmF0ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgID8gbWV0cmljcy5zdWNjZXNzUmF0ZS50b0ZpeGVkKDApXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwi4oCUXCIpfSUgc3VjY2Vzc1xuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMi41cHhdIHRleHQtaW5rLW11dGVkIG1iLTAuNVwiPlRvdGFsIENvc3Q8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxN3B4XSBmb250LXNlbWlib2xkIGZvbnQtbW9ubyB0ZXh0LWlua1wiPlxuICAgICAgICAgICAgICAgICAgICAgICR7bWV0cmljcy50b3RhbENvc3QudG9GaXhlZCgyKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICR7bWV0cmljcy5hdmdDb3N0UGVyUnVuLnRvRml4ZWQoMyl9L3J1blxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMi41cHhdIHRleHQtaW5rLW11dGVkIG1iLTAuNVwiPlRvZGF5JmFwb3M7cyBTcGVuZDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzE3cHhdIGZvbnQtc2VtaWJvbGQgZm9udC1tb25vIHRleHQtaW5rXCI+XG4gICAgICAgICAgICAgICAgICAgICAgJHttZXRyaWNzLnNwZW5kVG9kYXkudG9GaXhlZCgyKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICR7bWV0cmljcy5idWRnZXRSZW1haW5pbmcudG9GaXhlZCgyKX0gbGVmdFxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEJ1ZGdldCBCYXIgKi99XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtWzEyLjVweF0gdGV4dC1pbmstbXV0ZWQgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5CdWRnZXQgVXRpbGl6YXRpb248L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHsobWV0cmljcy51dGlsaXphdGlvbiAhPSBudWxsICYmICFOdW1iZXIuaXNOYU4obWV0cmljcy51dGlsaXphdGlvbilcbiAgICAgICAgICAgICAgICAgICAgICAgID8gbWV0cmljcy51dGlsaXphdGlvbi50b0ZpeGVkKDApXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwi4oCUXCIpfSVcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBiZy1zdXJmYWNlLTEgYm9yZGVyIGJvcmRlci1saW5lIHJvdW5kZWQtZnVsbCBoLTIgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJoLWZ1bGwgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tW3dpZHRoXSBkdXJhdGlvbi0zMDBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIChtZXRyaWNzLnV0aWxpemF0aW9uID8/IDApID49IDkwXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1lcnJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IChtZXRyaWNzLnV0aWxpemF0aW9uID8/IDApID49IDcwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXdhcm5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1va1wiXG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7TWF0aC5taW4obWV0cmljcy51dGlsaXphdGlvbiA/PyAwLCAxMDApfSVgIH19XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtWzEyLjVweF0gZm9udC1tb25vIHRleHQtaW5rLW11dGVkIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+JHttZXRyaWNzLnNwZW5kVG9kYXkudG9GaXhlZCgyKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPiR7bWV0cmljcy5idWRnZXREYWlseS50b0ZpeGVkKDIpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIFRhc2sgVHlwZXMgKi99XG4gICAgICAgICAgICAgICAge2FnZW50LmFsbG93ZWRUYXNrVHlwZXMgJiYgYWdlbnQuYWxsb3dlZFRhc2tUeXBlcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBwdC00IGJvcmRlci10IGJvcmRlci1saW5lXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZCBtYi0wLjVcIj5BbGxvd2VkIFRhc2sgVHlwZXM8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMSBtdC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7YWdlbnQuYWxsb3dlZFRhc2tUeXBlcy5tYXAoKHR5cGUpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdGF0dXNCYWRnZSBrZXk9e3R5cGV9IHRvbmU9XCJuZXV0cmFsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt0eXBlfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TdGF0dXNCYWRnZT5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvVG9vbHRpcFRyaWdnZXI+XG4gICAgICAgICAgICAgICAgICA8VG9vbHRpcENvbnRlbnQgc2lkZT1cInRvcFwiIGNsYXNzTmFtZT1cIm1heC13LVsyODBweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPnthZ2VudC5uYW1lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExLjVweF0gZm9udC1tb25vIHRleHQtaW5rLW11dGVkIGJyZWFrLWFsbFwiPnthZ2VudC5faWR9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIHtvblNlbGVjdEFnZW50ICYmIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSBtdC0wLjVcIj5DbGljayB0byBvcGVuIGFnZW50IGRldGFpbHM8L2Rpdj59XG4gICAgICAgICAgICAgICAgICA8L1Rvb2x0aXBDb250ZW50PlxuICAgICAgICAgICAgICAgIDwvVG9vbHRpcD5cbiAgICAgICAgICAgICAgPC9Ub29sdGlwUHJvdmlkZXI+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL0FnZW50RGFzaGJvYXJkLnRzeCJ9