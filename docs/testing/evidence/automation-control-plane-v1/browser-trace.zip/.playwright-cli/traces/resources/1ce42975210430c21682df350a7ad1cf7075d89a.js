export function navCountForView(view, stats, taskCount, approvalCount) {
  switch (view) {
    case "tasks":
      return taskCount > 0 ? taskCount : void 0;
    case "trace-inspector":
    case "execution":
      return stats.turns != null && stats.turns > 0 ? stats.turns : void 0;
    case "skills":
      return stats.skillCount != null && stats.skillCount > 0 ? stats.skillCount : void 0;
    case "memory":
      return stats.facts != null && stats.facts > 0 ? stats.facts : void 0;
    case "telemetry":
      return stats.alertCount != null && stats.alertCount > 0 ? stats.alertCount : void 0;
    case "gateway":
      return stats.events != null && stats.events > 0 ? stats.events : void 0;
    case "audit":
    case "control-approvals":
      return approvalCount > 0 ? approvalCount : void 0;
    case "qc-dashboard":
    case "qc-runs":
      return stats.traceFiles != null && stats.traceFiles > 0 ? stats.traceFiles : void 0;
    default:
      return void 0;
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5hdkNvdW50cy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgdHlwZSBOYXZDb3VudFN0YXRzID0ge1xuICB0YXNrQ291bnQ/OiBudW1iZXI7XG4gIHR1cm5zPzogbnVtYmVyO1xuICBza2lsbENvdW50PzogbnVtYmVyO1xuICBmYWN0cz86IG51bWJlcjtcbiAgYWxlcnRDb3VudD86IG51bWJlcjtcbiAgZXZlbnRzPzogbnVtYmVyO1xuICB0cmFjZUZpbGVzPzogbnVtYmVyO1xufTtcblxuLyoqIFB1cmUgbmF2IGJhZGdlIHJlc29sdmVyIOKAlCB0ZXN0ZWQgd2l0aG91dCBSZWFjdC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBuYXZDb3VudEZvclZpZXcoXG4gIHZpZXc6IHN0cmluZyxcbiAgc3RhdHM6IE5hdkNvdW50U3RhdHMsXG4gIHRhc2tDb3VudDogbnVtYmVyLFxuICBhcHByb3ZhbENvdW50OiBudW1iZXJcbik6IG51bWJlciB8IHVuZGVmaW5lZCB7XG4gIHN3aXRjaCAodmlldykge1xuICAgIGNhc2UgXCJ0YXNrc1wiOlxuICAgICAgcmV0dXJuIHRhc2tDb3VudCA+IDAgPyB0YXNrQ291bnQgOiB1bmRlZmluZWQ7XG4gICAgY2FzZSBcInRyYWNlLWluc3BlY3RvclwiOlxuICAgIGNhc2UgXCJleGVjdXRpb25cIjpcbiAgICAgIHJldHVybiBzdGF0cy50dXJucyAhPSBudWxsICYmIHN0YXRzLnR1cm5zID4gMCA/IHN0YXRzLnR1cm5zIDogdW5kZWZpbmVkO1xuICAgIGNhc2UgXCJza2lsbHNcIjpcbiAgICAgIHJldHVybiBzdGF0cy5za2lsbENvdW50ICE9IG51bGwgJiYgc3RhdHMuc2tpbGxDb3VudCA+IDAgPyBzdGF0cy5za2lsbENvdW50IDogdW5kZWZpbmVkO1xuICAgIGNhc2UgXCJtZW1vcnlcIjpcbiAgICAgIHJldHVybiBzdGF0cy5mYWN0cyAhPSBudWxsICYmIHN0YXRzLmZhY3RzID4gMCA/IHN0YXRzLmZhY3RzIDogdW5kZWZpbmVkO1xuICAgIGNhc2UgXCJ0ZWxlbWV0cnlcIjpcbiAgICAgIHJldHVybiBzdGF0cy5hbGVydENvdW50ICE9IG51bGwgJiYgc3RhdHMuYWxlcnRDb3VudCA+IDAgPyBzdGF0cy5hbGVydENvdW50IDogdW5kZWZpbmVkO1xuICAgIGNhc2UgXCJnYXRld2F5XCI6XG4gICAgICByZXR1cm4gc3RhdHMuZXZlbnRzICE9IG51bGwgJiYgc3RhdHMuZXZlbnRzID4gMCA/IHN0YXRzLmV2ZW50cyA6IHVuZGVmaW5lZDtcbiAgICBjYXNlIFwiYXVkaXRcIjpcbiAgICBjYXNlIFwiY29udHJvbC1hcHByb3ZhbHNcIjpcbiAgICAgIHJldHVybiBhcHByb3ZhbENvdW50ID4gMCA/IGFwcHJvdmFsQ291bnQgOiB1bmRlZmluZWQ7XG4gICAgY2FzZSBcInFjLWRhc2hib2FyZFwiOlxuICAgIGNhc2UgXCJxYy1ydW5zXCI6XG4gICAgICByZXR1cm4gc3RhdHMudHJhY2VGaWxlcyAhPSBudWxsICYmIHN0YXRzLnRyYWNlRmlsZXMgPiAwID8gc3RhdHMudHJhY2VGaWxlcyA6IHVuZGVmaW5lZDtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiQUFXTyxnQkFBUyxnQkFDZCxNQUNBLE9BQ0EsV0FDQSxlQUNvQjtBQUNwQixVQUFRLE1BQU07QUFBQSxJQUNaLEtBQUs7QUFDSCxhQUFPLFlBQVksSUFBSSxZQUFZO0FBQUEsSUFDckMsS0FBSztBQUFBLElBQ0wsS0FBSztBQUNILGFBQU8sTUFBTSxTQUFTLFFBQVEsTUFBTSxRQUFRLElBQUksTUFBTSxRQUFRO0FBQUEsSUFDaEUsS0FBSztBQUNILGFBQU8sTUFBTSxjQUFjLFFBQVEsTUFBTSxhQUFhLElBQUksTUFBTSxhQUFhO0FBQUEsSUFDL0UsS0FBSztBQUNILGFBQU8sTUFBTSxTQUFTLFFBQVEsTUFBTSxRQUFRLElBQUksTUFBTSxRQUFRO0FBQUEsSUFDaEUsS0FBSztBQUNILGFBQU8sTUFBTSxjQUFjLFFBQVEsTUFBTSxhQUFhLElBQUksTUFBTSxhQUFhO0FBQUEsSUFDL0UsS0FBSztBQUNILGFBQU8sTUFBTSxVQUFVLFFBQVEsTUFBTSxTQUFTLElBQUksTUFBTSxTQUFTO0FBQUEsSUFDbkUsS0FBSztBQUFBLElBQ0wsS0FBSztBQUNILGFBQU8sZ0JBQWdCLElBQUksZ0JBQWdCO0FBQUEsSUFDN0MsS0FBSztBQUFBLElBQ0wsS0FBSztBQUNILGFBQU8sTUFBTSxjQUFjLFFBQVEsTUFBTSxhQUFhLElBQUksTUFBTSxhQUFhO0FBQUEsSUFDL0U7QUFDRSxhQUFPO0FBQUEsRUFDWDtBQUNGOyIsIm5hbWVzIjpbXX0=