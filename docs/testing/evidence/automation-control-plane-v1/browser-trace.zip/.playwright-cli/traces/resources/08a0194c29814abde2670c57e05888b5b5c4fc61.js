// ../../../../../../../../node_modules/.pnpm/@radix-ui+number@1.1.1/node_modules/@radix-ui/number/dist/index.mjs
function clamp(value, [min, max]) {
  return Math.min(max, Math.max(min, value));
}

export {
  clamp
};
//# sourceMappingURL=chunk-622LR6H7.js.map
