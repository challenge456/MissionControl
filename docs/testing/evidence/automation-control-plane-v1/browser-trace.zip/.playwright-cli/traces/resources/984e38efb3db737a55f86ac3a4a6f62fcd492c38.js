import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/SearchBar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { Search, Bot } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { cn } from "/src/lib/utils.ts";
import { Input } from "/src/components/ui/input.tsx";
import { ScrollArea } from "/src/components/ui/scroll-area.tsx";
export function SearchBar({ projectId, onResultClick }) {
  _s();
  const [query, setQuery] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [nonActionableFeedback, setNonActionableFeedback] = useState(false);
  const results = useQuery(
    api.search.searchAll,
    query.length >= 2 && projectId ? { projectId, query, limit: 10 } : "skip"
  );
  const taskResults = results?.tasks ?? [];
  const approvalResults = results?.approvals ?? [];
  const agentResults = results?.agents ?? [];
  const messageResults = results?.messages ?? [];
  const flatResults = useMemo(() => {
    const taskHits = taskResults.map((task) => ({
      type: "task",
      id: `task-${task._id}`,
      title: task.title,
      subtitle: `${task.status} · ${task.type} · P${task.priority}`,
      taskId: task._id
    }));
    const approvalHits = approvalResults.map((approval) => ({
      type: "approval",
      id: `approval-${approval._id}`,
      title: approval.actionSummary,
      subtitle: `${approval.status} · ${approval.riskLevel} · ${approval.actionType}`,
      taskId: approval.taskId ?? void 0
    }));
    return [...taskHits, ...approvalHits];
  }, [taskResults, approvalResults]);
  useEffect(() => {
    const hasAny = taskResults.length > 0 || approvalResults.length > 0 || agentResults.length > 0 || messageResults.length > 0;
    setIsOpen(query.length >= 2 && hasAny);
    setSelectedIndex(0);
  }, [query, taskResults.length, approvalResults.length, agentResults.length, messageResults.length]);
  function handleKeyDown(event) {
    if (!flatResults.length) return;
    if (event.key === "ArrowDown") {
      event.preventDefault();
      setSelectedIndex((prev) => Math.min(prev + 1, flatResults.length - 1));
      return;
    }
    if (event.key === "ArrowUp") {
      event.preventDefault();
      setSelectedIndex((prev) => Math.max(prev - 1, 0));
      return;
    }
    if (event.key === "Enter") {
      event.preventDefault();
      const selected = flatResults[selectedIndex];
      if (!selected) return;
      if (selected.type === "task") {
        onResultClick(selected.taskId);
        setQuery("");
        setIsOpen(false);
      } else if (selected.type === "approval") {
        if (selected.taskId) {
          onResultClick(selected.taskId);
          setQuery("");
          setIsOpen(false);
        } else {
          setNonActionableFeedback(true);
          setTimeout(() => setNonActionableFeedback(false), 1200);
        }
      }
      return;
    }
    if (event.key === "Escape") {
      setIsOpen(false);
    }
  }
  const noResults = query.length >= 2 && !!results && !results.totalResults;
  return /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-[460px]", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
      /* @__PURE__ */ jsxDEV(Search, { size: 15, strokeWidth: 1.7, className: "pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-muted", "aria-hidden": true }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
        lineNumber: 130,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Input,
        {
          type: "text",
          value: query,
          onChange: (event) => setQuery(event.target.value),
          onKeyDown: handleKeyDown,
          onFocus: () => query.length >= 2 && setIsOpen(true),
          placeholder: "Search tasks, approvals, agents...",
          className: "h-9 rounded-lg border-line bg-surface-1 pl-9 text-[13.5px] placeholder:text-ink-muted",
          "aria-label": "Search tasks, approvals, and agents"
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
          lineNumber: 131,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
      lineNumber: 129,
      columnNumber: 7
    }, this),
    isOpen && /* @__PURE__ */ jsxDEV("div", { className: "absolute z-[1000] mt-2 w-full overflow-hidden rounded-xl border border-line bg-surface-3 shadow-[var(--shadow-elevation-2)]", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "border-b border-line px-4 py-3 text-[11.5px] font-medium text-ink-muted", children: nonActionableFeedback ? /* @__PURE__ */ jsxDEV("span", { className: "text-warn", children: "This item has no linked task" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
        lineNumber: 147,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        results?.totalResults ?? 0,
        " result(s)"
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
        lineNumber: 149,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
        lineNumber: 145,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(ScrollArea, { className: "max-h-[420px]", children: [
        /* @__PURE__ */ jsxDEV(
          SearchSection,
          {
            title: "Tasks",
            rows: taskResults.map((task) => ({
              key: `task-${task._id}`,
              title: task.title,
              subtitle: `${task.status} · ${task.type} · P${task.priority}`,
              onClick: () => {
                onResultClick(task._id);
                setQuery("");
                setIsOpen(false);
              },
              isSelected: flatResults[selectedIndex]?.id === `task-${task._id}`
            }))
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
            lineNumber: 153,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          SearchSection,
          {
            title: "Approvals",
            rows: approvalResults.map((approval) => ({
              key: `approval-${approval._id}`,
              title: approval.actionSummary,
              subtitle: `${approval.status} · ${approval.riskLevel} · ${approval.actionType}`,
              onClick: approval.taskId ? () => {
                onResultClick(approval.taskId);
                setQuery("");
                setIsOpen(false);
              } : void 0,
              isSelected: flatResults[selectedIndex]?.id === `approval-${approval._id}`
            }))
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
            lineNumber: 168,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          SearchSection,
          {
            title: "Agents",
            rows: agentResults.map((agent) => ({
              key: `agent-${agent._id}`,
              title: agent.name,
              subtitle: `${agent.role} · ${agent.status}`,
              onClick: void 0,
              isSelected: false
            }))
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
            lineNumber: 185,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          SearchSection,
          {
            title: "Messages",
            rows: messageResults.slice(0, 4).map((message) => ({
              key: `message-${message._id}`,
              title: message.content.slice(0, 80),
              subtitle: message.type,
              onClick: message.taskId ? () => {
                onResultClick(message.taskId);
                setQuery("");
                setIsOpen(false);
              } : void 0,
              isSelected: false
            }))
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
            lineNumber: 196,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
        lineNumber: 152,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
      lineNumber: 144,
      columnNumber: 7
    }, this),
    noResults && /* @__PURE__ */ jsxDEV("div", { className: "absolute z-[1000] mt-2 w-full rounded-xl border border-line bg-surface-3 px-4 py-3 text-center text-[13.5px] text-ink-muted shadow-[var(--shadow-elevation-2)]", children: [
      'No results for "',
      query,
      '"'
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
      lineNumber: 217,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
    lineNumber: 128,
    columnNumber: 5
  }, this);
}
_s(SearchBar, "J5DRt4/XAiDr0diiz2gEo9huC4M=", false, function() {
  return [useQuery];
});
_c = SearchBar;
function SearchSection({
  title,
  rows
}) {
  if (!rows.length) return null;
  return /* @__PURE__ */ jsxDEV("div", { className: "border-b border-line p-2 last:border-b-0", children: [
    /* @__PURE__ */ jsxDEV("p", { className: "mb-1 px-2 text-[11.5px] font-medium uppercase tracking-[0.06em] text-ink-muted", children: title }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
      lineNumber: 242,
      columnNumber: 7
    }, this),
    rows.map(
      (row) => /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: row.onClick,
          disabled: !row.onClick,
          className: cn(
            "w-full rounded-lg px-3 py-2.5 text-left transition-colors duration-150",
            row.isSelected && "bg-surface-2",
            row.onClick ? "cursor-pointer text-ink hover:bg-surface-2" : "cursor-default text-ink-secondary"
          ),
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2 truncate text-[13.5px] font-medium", children: [
              title === "Agents" && /* @__PURE__ */ jsxDEV(Bot, { size: 14, strokeWidth: 1.7, "aria-hidden": true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
                lineNumber: 260,
                columnNumber: 36
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "truncate", children: row.title }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
                lineNumber: 261,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
              lineNumber: 259,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "block truncate text-[12.5px] text-ink-muted", children: row.subtitle }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
              lineNumber: 263,
              columnNumber: 11
            }, this)
          ]
        },
        row.key,
        true,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
          lineNumber: 246,
          columnNumber: 7
        },
        this
      )
    )
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx",
    lineNumber: 241,
    columnNumber: 5
  }, this);
}
_c2 = SearchSection;
var _c, _c2;
$RefreshReg$(_c, "SearchBar");
$RefreshReg$(_c2, "SearchSection");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/SearchBar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEdRLFNBbUJNLFVBbkJOOzs7Ozs7Ozs7Ozs7Ozs7OztBQTlHUixTQUFTQSxXQUFXQyxTQUFTQyxnQkFBb0M7QUFDakUsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFdBQVc7QUFDcEIsU0FBU0MsUUFBUUMsV0FBVztBQUM1QixTQUFTQyxVQUFVO0FBQ25CLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0Msa0JBQWtCO0FBV3BCLGdCQUFTQyxVQUFVLEVBQUVDLFdBQVdDLGNBQThCLEdBQUc7QUFBQUMsS0FBQTtBQUN0RSxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSWIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ2MsUUFBUUMsU0FBUyxJQUFJZixTQUFTLEtBQUs7QUFDMUMsUUFBTSxDQUFDZ0IsZUFBZUMsZ0JBQWdCLElBQUlqQixTQUFTLENBQUM7QUFDcEQsUUFBTSxDQUFDa0IsdUJBQXVCQyx3QkFBd0IsSUFBSW5CLFNBQVMsS0FBSztBQUV4RSxRQUFNb0IsVUFBVW5CO0FBQUFBLElBQ2RDLElBQUltQixPQUFPQztBQUFBQSxJQUNYVixNQUFNVyxVQUFVLEtBQUtkLFlBQ2pCLEVBQUVBLFdBQTZCRyxPQUFPWSxPQUFPLEdBQUcsSUFDaEQ7QUFBQSxFQUNOO0FBRUEsUUFBTUMsY0FBY0wsU0FBU00sU0FBUztBQUN0QyxRQUFNQyxrQkFBa0JQLFNBQVNRLGFBQWE7QUFDOUMsUUFBTUMsZUFBZVQsU0FBU1UsVUFBVTtBQUN4QyxRQUFNQyxpQkFBaUJYLFNBQVNZLFlBQVk7QUFFNUMsUUFBTUMsY0FBY2xDLFFBQXFCLE1BQU07QUFDN0MsVUFBTW1DLFdBQXdCVCxZQUFZVSxJQUFJLENBQUNDLFVBQVU7QUFBQSxNQUN2REMsTUFBTTtBQUFBLE1BQ05DLElBQUksUUFBUUYsS0FBS0csR0FBRztBQUFBLE1BQ3BCQyxPQUFPSixLQUFLSTtBQUFBQSxNQUNaQyxVQUFVLEdBQUdMLEtBQUtNLE1BQU0sTUFBTU4sS0FBS0MsSUFBSSxPQUFPRCxLQUFLTyxRQUFRO0FBQUEsTUFDM0RDLFFBQVFSLEtBQUtHO0FBQUFBLElBQ2YsRUFBRTtBQUNGLFVBQU1NLGVBQTRCbEIsZ0JBQWdCUSxJQUFJLENBQUNXLGNBQWM7QUFBQSxNQUNuRVQsTUFBTTtBQUFBLE1BQ05DLElBQUksWUFBWVEsU0FBU1AsR0FBRztBQUFBLE1BQzVCQyxPQUFPTSxTQUFTQztBQUFBQSxNQUNoQk4sVUFBVSxHQUFHSyxTQUFTSixNQUFNLE1BQU1JLFNBQVNFLFNBQVMsTUFBTUYsU0FBU0csVUFBVTtBQUFBLE1BQzdFTCxRQUFRRSxTQUFTRixVQUFVTTtBQUFBQSxJQUM3QixFQUFFO0FBQ0YsV0FBTyxDQUFDLEdBQUdoQixVQUFVLEdBQUdXLFlBQVk7QUFBQSxFQUN0QyxHQUFHLENBQUNwQixhQUFhRSxlQUFlLENBQUM7QUFFakM3QixZQUFVLE1BQU07QUFDZCxVQUFNcUQsU0FDSjFCLFlBQVlGLFNBQVMsS0FDckJJLGdCQUFnQkosU0FBUyxLQUN6Qk0sYUFBYU4sU0FBUyxLQUN0QlEsZUFBZVIsU0FBUztBQUMxQlIsY0FBVUgsTUFBTVcsVUFBVSxLQUFLNEIsTUFBTTtBQUNyQ2xDLHFCQUFpQixDQUFDO0FBQUEsRUFDcEIsR0FBRyxDQUFDTCxPQUFPYSxZQUFZRixRQUFRSSxnQkFBZ0JKLFFBQVFNLGFBQWFOLFFBQVFRLGVBQWVSLE1BQU0sQ0FBQztBQUVsRyxXQUFTNkIsY0FBY0MsT0FBd0M7QUFDN0QsUUFBSSxDQUFDcEIsWUFBWVYsT0FBUTtBQUV6QixRQUFJOEIsTUFBTUMsUUFBUSxhQUFhO0FBQzdCRCxZQUFNRSxlQUFlO0FBQ3JCdEMsdUJBQWlCLENBQUN1QyxTQUFTQyxLQUFLQyxJQUFJRixPQUFPLEdBQUd2QixZQUFZVixTQUFTLENBQUMsQ0FBQztBQUNyRTtBQUFBLElBQ0Y7QUFFQSxRQUFJOEIsTUFBTUMsUUFBUSxXQUFXO0FBQzNCRCxZQUFNRSxlQUFlO0FBQ3JCdEMsdUJBQWlCLENBQUN1QyxTQUFTQyxLQUFLRSxJQUFJSCxPQUFPLEdBQUcsQ0FBQyxDQUFDO0FBQ2hEO0FBQUEsSUFDRjtBQUVBLFFBQUlILE1BQU1DLFFBQVEsU0FBUztBQUN6QkQsWUFBTUUsZUFBZTtBQUNyQixZQUFNSyxXQUFXM0IsWUFBWWpCLGFBQWE7QUFDMUMsVUFBSSxDQUFDNEMsU0FBVTtBQUVmLFVBQUlBLFNBQVN2QixTQUFTLFFBQVE7QUFDNUIzQixzQkFBY2tELFNBQVNoQixNQUFNO0FBQzdCL0IsaUJBQVMsRUFBRTtBQUNYRSxrQkFBVSxLQUFLO0FBQUEsTUFDakIsV0FBVzZDLFNBQVN2QixTQUFTLFlBQVk7QUFDdkMsWUFBSXVCLFNBQVNoQixRQUFRO0FBQ25CbEMsd0JBQWNrRCxTQUFTaEIsTUFBTTtBQUM3Qi9CLG1CQUFTLEVBQUU7QUFDWEUsb0JBQVUsS0FBSztBQUFBLFFBQ2pCLE9BQU87QUFDTEksbUNBQXlCLElBQUk7QUFDN0IwQyxxQkFBVyxNQUFNMUMseUJBQXlCLEtBQUssR0FBRyxJQUFJO0FBQUEsUUFDeEQ7QUFBQSxNQUNGO0FBQ0E7QUFBQSxJQUNGO0FBRUEsUUFBSWtDLE1BQU1DLFFBQVEsVUFBVTtBQUMxQnZDLGdCQUFVLEtBQUs7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNK0MsWUFBWWxELE1BQU1XLFVBQVUsS0FBSyxDQUFDLENBQUNILFdBQVcsQ0FBQ0EsUUFBUTJDO0FBRTdELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGlDQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSw2QkFBQyxVQUFPLE1BQU0sSUFBSSxhQUFhLEtBQUssV0FBVSxpRkFBZ0YsZUFBVyxRQUF6STtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlJO0FBQUEsTUFDekk7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLE9BQU9uRDtBQUFBQSxVQUNQLFVBQVUsQ0FBQ3lDLFVBQVV4QyxTQUFTd0MsTUFBTVcsT0FBT0MsS0FBSztBQUFBLFVBQ2hELFdBQVdiO0FBQUFBLFVBQ1gsU0FBUyxNQUFNeEMsTUFBTVcsVUFBVSxLQUFLUixVQUFVLElBQUk7QUFBQSxVQUNsRCxhQUFZO0FBQUEsVUFDWixXQUFVO0FBQUEsVUFDVixjQUFXO0FBQUE7QUFBQSxRQVJiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFrRDtBQUFBLFNBVnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBRUNELFVBQ0MsdUJBQUMsU0FBSSxXQUFVLCtIQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDJFQUNaSSxrQ0FDQyx1QkFBQyxVQUFLLFdBQVUsYUFBWSw0Q0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RCxJQUV4RCxtQ0FBR0U7QUFBQUEsaUJBQVMyQyxnQkFBZ0I7QUFBQSxRQUFFO0FBQUEsV0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QyxLQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxNQUNBLHVCQUFDLGNBQVcsV0FBVSxpQkFDcEI7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sTUFBTXRDLFlBQVlVLElBQUksQ0FBQ0MsVUFBVTtBQUFBLGNBQy9Ca0IsS0FBSyxRQUFRbEIsS0FBS0csR0FBRztBQUFBLGNBQ3JCQyxPQUFPSixLQUFLSTtBQUFBQSxjQUNaQyxVQUFVLEdBQUdMLEtBQUtNLE1BQU0sTUFBTU4sS0FBS0MsSUFBSSxPQUFPRCxLQUFLTyxRQUFRO0FBQUEsY0FDM0R1QixTQUFTQSxNQUFNO0FBQ2J4RCw4QkFBYzBCLEtBQUtHLEdBQUc7QUFDdEIxQix5QkFBUyxFQUFFO0FBQ1hFLDBCQUFVLEtBQUs7QUFBQSxjQUNqQjtBQUFBLGNBQ0FvRCxZQUFZbEMsWUFBWWpCLGFBQWEsR0FBR3NCLE9BQU8sUUFBUUYsS0FBS0csR0FBRztBQUFBLFlBQ2pFLEVBQUU7QUFBQTtBQUFBLFVBWko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWU07QUFBQSxRQUdOO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixNQUFNWixnQkFBZ0JRLElBQUksQ0FBQ1csY0FBYztBQUFBLGNBQ3ZDUSxLQUFLLFlBQVlSLFNBQVNQLEdBQUc7QUFBQSxjQUM3QkMsT0FBT00sU0FBU0M7QUFBQUEsY0FDaEJOLFVBQVUsR0FBR0ssU0FBU0osTUFBTSxNQUFNSSxTQUFTRSxTQUFTLE1BQU1GLFNBQVNHLFVBQVU7QUFBQSxjQUM3RWlCLFNBQVNwQixTQUFTRixTQUNkLE1BQU07QUFDSmxDLDhCQUFjb0MsU0FBU0YsTUFBZ0I7QUFDdkMvQix5QkFBUyxFQUFFO0FBQ1hFLDBCQUFVLEtBQUs7QUFBQSxjQUNqQixJQUNBbUM7QUFBQUEsY0FDSmlCLFlBQVlsQyxZQUFZakIsYUFBYSxHQUFHc0IsT0FBTyxZQUFZUSxTQUFTUCxHQUFHO0FBQUEsWUFDekUsRUFBRTtBQUFBO0FBQUEsVUFkSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFjTTtBQUFBLFFBR047QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE1BQU1WLGFBQWFNLElBQUksQ0FBQ2lDLFdBQVc7QUFBQSxjQUNqQ2QsS0FBSyxTQUFTYyxNQUFNN0IsR0FBRztBQUFBLGNBQ3ZCQyxPQUFPNEIsTUFBTUM7QUFBQUEsY0FDYjVCLFVBQVUsR0FBRzJCLE1BQU1FLElBQUksTUFBTUYsTUFBTTFCLE1BQU07QUFBQSxjQUN6Q3dCLFNBQVNoQjtBQUFBQSxjQUNUaUIsWUFBWTtBQUFBLFlBQ2QsRUFBRTtBQUFBO0FBQUEsVUFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRTTtBQUFBLFFBR047QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE1BQU1wQyxlQUFld0MsTUFBTSxHQUFHLENBQUMsRUFBRXBDLElBQUksQ0FBQ3FDLGFBQWE7QUFBQSxjQUNqRGxCLEtBQUssV0FBV2tCLFFBQVFqQyxHQUFHO0FBQUEsY0FDM0JDLE9BQU9nQyxRQUFRQyxRQUFRRixNQUFNLEdBQUcsRUFBRTtBQUFBLGNBQ2xDOUIsVUFBVStCLFFBQVFuQztBQUFBQSxjQUNsQjZCLFNBQVNNLFFBQVE1QixTQUNiLE1BQU07QUFDSmxDLDhCQUFjOEQsUUFBUTVCLE1BQWdCO0FBQ3RDL0IseUJBQVMsRUFBRTtBQUNYRSwwQkFBVSxLQUFLO0FBQUEsY0FDakIsSUFDQW1DO0FBQUFBLGNBQ0ppQixZQUFZO0FBQUEsWUFDZCxFQUFFO0FBQUE7QUFBQSxVQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWNNO0FBQUEsV0ExRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTREQTtBQUFBLFNBcEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxRUE7QUFBQSxJQUdETCxhQUNDLHVCQUFDLFNBQUksV0FBVSxrS0FBZ0s7QUFBQTtBQUFBLE1BQzVKbEQ7QUFBQUEsTUFBTTtBQUFBLFNBRHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BM0ZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2RkE7QUFFSjtBQUFDRCxHQTFMZUgsV0FBUztBQUFBLFVBTVBQLFFBQVE7QUFBQTtBQUFBLEtBTlZPO0FBNExoQixTQUFTa0UsY0FBYztBQUFBLEVBQ3JCbEM7QUFBQUEsRUFDQW1DO0FBVUYsR0FBRztBQUNELE1BQUksQ0FBQ0EsS0FBS3BELE9BQVEsUUFBTztBQUV6QixTQUNFLHVCQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLDJCQUFDLE9BQUUsV0FBVSxrRkFDVmlCLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0NtQyxLQUFLeEM7QUFBQUEsTUFBSSxDQUFDeUMsUUFDVDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUMsTUFBSztBQUFBLFVBQ0wsU0FBU0EsSUFBSVY7QUFBQUEsVUFDYixVQUFVLENBQUNVLElBQUlWO0FBQUFBLFVBQ2YsV0FBVzdEO0FBQUFBLFlBQ1Q7QUFBQSxZQUNBdUUsSUFBSVQsY0FBYztBQUFBLFlBQ2xCUyxJQUFJVixVQUNBLCtDQUNBO0FBQUEsVUFDTjtBQUFBLFVBRUE7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsOERBQ2IxQjtBQUFBQSx3QkFBVSxZQUFZLHVCQUFDLE9BQUksTUFBTSxJQUFJLGFBQWEsS0FBSyxlQUFXLFFBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRDO0FBQUEsY0FDbkUsdUJBQUMsVUFBSyxXQUFVLFlBQVlvQyxjQUFJcEMsU0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0M7QUFBQSxpQkFGeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsVUFBSyxXQUFVLCtDQUErQ29DLGNBQUluQyxZQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RTtBQUFBO0FBQUE7QUFBQSxRQWhCdkVtQyxJQUFJdEI7QUFBQUEsUUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Ba0JBO0FBQUEsSUFDRDtBQUFBLE9BeEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5QkE7QUFFSjtBQUFDdUIsTUEzQ1FIO0FBQWEsSUFBQUksSUFBQUQ7QUFBQSxhQUFBQyxJQUFBO0FBQUEsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsInVzZVF1ZXJ5IiwiYXBpIiwiU2VhcmNoIiwiQm90IiwiY24iLCJJbnB1dCIsIlNjcm9sbEFyZWEiLCJTZWFyY2hCYXIiLCJwcm9qZWN0SWQiLCJvblJlc3VsdENsaWNrIiwiX3MiLCJxdWVyeSIsInNldFF1ZXJ5IiwiaXNPcGVuIiwic2V0SXNPcGVuIiwic2VsZWN0ZWRJbmRleCIsInNldFNlbGVjdGVkSW5kZXgiLCJub25BY3Rpb25hYmxlRmVlZGJhY2siLCJzZXROb25BY3Rpb25hYmxlRmVlZGJhY2siLCJyZXN1bHRzIiwic2VhcmNoIiwic2VhcmNoQWxsIiwibGVuZ3RoIiwibGltaXQiLCJ0YXNrUmVzdWx0cyIsInRhc2tzIiwiYXBwcm92YWxSZXN1bHRzIiwiYXBwcm92YWxzIiwiYWdlbnRSZXN1bHRzIiwiYWdlbnRzIiwibWVzc2FnZVJlc3VsdHMiLCJtZXNzYWdlcyIsImZsYXRSZXN1bHRzIiwidGFza0hpdHMiLCJtYXAiLCJ0YXNrIiwidHlwZSIsImlkIiwiX2lkIiwidGl0bGUiLCJzdWJ0aXRsZSIsInN0YXR1cyIsInByaW9yaXR5IiwidGFza0lkIiwiYXBwcm92YWxIaXRzIiwiYXBwcm92YWwiLCJhY3Rpb25TdW1tYXJ5Iiwicmlza0xldmVsIiwiYWN0aW9uVHlwZSIsInVuZGVmaW5lZCIsImhhc0FueSIsImhhbmRsZUtleURvd24iLCJldmVudCIsImtleSIsInByZXZlbnREZWZhdWx0IiwicHJldiIsIk1hdGgiLCJtaW4iLCJtYXgiLCJzZWxlY3RlZCIsInNldFRpbWVvdXQiLCJub1Jlc3VsdHMiLCJ0b3RhbFJlc3VsdHMiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm9uQ2xpY2siLCJpc1NlbGVjdGVkIiwiYWdlbnQiLCJuYW1lIiwicm9sZSIsInNsaWNlIiwibWVzc2FnZSIsImNvbnRlbnQiLCJTZWFyY2hTZWN0aW9uIiwicm93cyIsInJvdyIsIl9jMiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNlYXJjaEJhci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VTdGF0ZSwgdHlwZSBLZXlib2FyZEV2ZW50IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB7IFNlYXJjaCwgQm90IH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcbmltcG9ydCB7IElucHV0IH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9pbnB1dFwiO1xuaW1wb3J0IHsgU2Nyb2xsQXJlYSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvc2Nyb2xsLWFyZWFcIjtcblxuaW50ZXJmYWNlIFNlYXJjaEJhclByb3BzIHtcbiAgcHJvamVjdElkOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gIG9uUmVzdWx0Q2xpY2s6ICh0YXNrSWQ6IHN0cmluZykgPT4gdm9pZDtcbn1cblxudHlwZSBTZWFyY2hIaXQgPVxuICB8IHsgdHlwZTogXCJ0YXNrXCI7IGlkOiBzdHJpbmc7IHRpdGxlOiBzdHJpbmc7IHN1YnRpdGxlOiBzdHJpbmc7IHRhc2tJZDogc3RyaW5nIH1cbiAgfCB7IHR5cGU6IFwiYXBwcm92YWxcIjsgaWQ6IHN0cmluZzsgdGl0bGU6IHN0cmluZzsgc3VidGl0bGU6IHN0cmluZzsgdGFza0lkPzogc3RyaW5nIH07XG5cbmV4cG9ydCBmdW5jdGlvbiBTZWFyY2hCYXIoeyBwcm9qZWN0SWQsIG9uUmVzdWx0Q2xpY2sgfTogU2VhcmNoQmFyUHJvcHMpIHtcbiAgY29uc3QgW3F1ZXJ5LCBzZXRRdWVyeV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2lzT3Blbiwgc2V0SXNPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3NlbGVjdGVkSW5kZXgsIHNldFNlbGVjdGVkSW5kZXhdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtub25BY3Rpb25hYmxlRmVlZGJhY2ssIHNldE5vbkFjdGlvbmFibGVGZWVkYmFja10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgY29uc3QgcmVzdWx0cyA9IHVzZVF1ZXJ5KFxuICAgIGFwaS5zZWFyY2guc2VhcmNoQWxsLFxuICAgIHF1ZXJ5Lmxlbmd0aCA+PSAyICYmIHByb2plY3RJZFxuICAgICAgPyB7IHByb2plY3RJZDogcHJvamVjdElkIGFzIGFueSwgcXVlcnksIGxpbWl0OiAxMCB9XG4gICAgICA6IFwic2tpcFwiXG4gICk7XG5cbiAgY29uc3QgdGFza1Jlc3VsdHMgPSByZXN1bHRzPy50YXNrcyA/PyBbXTtcbiAgY29uc3QgYXBwcm92YWxSZXN1bHRzID0gcmVzdWx0cz8uYXBwcm92YWxzID8/IFtdO1xuICBjb25zdCBhZ2VudFJlc3VsdHMgPSByZXN1bHRzPy5hZ2VudHMgPz8gW107XG4gIGNvbnN0IG1lc3NhZ2VSZXN1bHRzID0gcmVzdWx0cz8ubWVzc2FnZXMgPz8gW107XG5cbiAgY29uc3QgZmxhdFJlc3VsdHMgPSB1c2VNZW1vPFNlYXJjaEhpdFtdPigoKSA9PiB7XG4gICAgY29uc3QgdGFza0hpdHM6IFNlYXJjaEhpdFtdID0gdGFza1Jlc3VsdHMubWFwKCh0YXNrKSA9PiAoe1xuICAgICAgdHlwZTogXCJ0YXNrXCIsXG4gICAgICBpZDogYHRhc2stJHt0YXNrLl9pZH1gLFxuICAgICAgdGl0bGU6IHRhc2sudGl0bGUsXG4gICAgICBzdWJ0aXRsZTogYCR7dGFzay5zdGF0dXN9IMK3ICR7dGFzay50eXBlfSDCtyBQJHt0YXNrLnByaW9yaXR5fWAsXG4gICAgICB0YXNrSWQ6IHRhc2suX2lkLFxuICAgIH0pKTtcbiAgICBjb25zdCBhcHByb3ZhbEhpdHM6IFNlYXJjaEhpdFtdID0gYXBwcm92YWxSZXN1bHRzLm1hcCgoYXBwcm92YWwpID0+ICh7XG4gICAgICB0eXBlOiBcImFwcHJvdmFsXCIsXG4gICAgICBpZDogYGFwcHJvdmFsLSR7YXBwcm92YWwuX2lkfWAsXG4gICAgICB0aXRsZTogYXBwcm92YWwuYWN0aW9uU3VtbWFyeSxcbiAgICAgIHN1YnRpdGxlOiBgJHthcHByb3ZhbC5zdGF0dXN9IMK3ICR7YXBwcm92YWwucmlza0xldmVsfSDCtyAke2FwcHJvdmFsLmFjdGlvblR5cGV9YCxcbiAgICAgIHRhc2tJZDogYXBwcm92YWwudGFza0lkID8/IHVuZGVmaW5lZCxcbiAgICB9KSk7XG4gICAgcmV0dXJuIFsuLi50YXNrSGl0cywgLi4uYXBwcm92YWxIaXRzXTtcbiAgfSwgW3Rhc2tSZXN1bHRzLCBhcHByb3ZhbFJlc3VsdHNdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGhhc0FueSA9XG4gICAgICB0YXNrUmVzdWx0cy5sZW5ndGggPiAwIHx8XG4gICAgICBhcHByb3ZhbFJlc3VsdHMubGVuZ3RoID4gMCB8fFxuICAgICAgYWdlbnRSZXN1bHRzLmxlbmd0aCA+IDAgfHxcbiAgICAgIG1lc3NhZ2VSZXN1bHRzLmxlbmd0aCA+IDA7XG4gICAgc2V0SXNPcGVuKHF1ZXJ5Lmxlbmd0aCA+PSAyICYmIGhhc0FueSk7XG4gICAgc2V0U2VsZWN0ZWRJbmRleCgwKTtcbiAgfSwgW3F1ZXJ5LCB0YXNrUmVzdWx0cy5sZW5ndGgsIGFwcHJvdmFsUmVzdWx0cy5sZW5ndGgsIGFnZW50UmVzdWx0cy5sZW5ndGgsIG1lc3NhZ2VSZXN1bHRzLmxlbmd0aF0pO1xuXG4gIGZ1bmN0aW9uIGhhbmRsZUtleURvd24oZXZlbnQ6IEtleWJvYXJkRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pIHtcbiAgICBpZiAoIWZsYXRSZXN1bHRzLmxlbmd0aCkgcmV0dXJuO1xuXG4gICAgaWYgKGV2ZW50LmtleSA9PT0gXCJBcnJvd0Rvd25cIikge1xuICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgIHNldFNlbGVjdGVkSW5kZXgoKHByZXYpID0+IE1hdGgubWluKHByZXYgKyAxLCBmbGF0UmVzdWx0cy5sZW5ndGggLSAxKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKGV2ZW50LmtleSA9PT0gXCJBcnJvd1VwXCIpIHtcbiAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICBzZXRTZWxlY3RlZEluZGV4KChwcmV2KSA9PiBNYXRoLm1heChwcmV2IC0gMSwgMCkpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChldmVudC5rZXkgPT09IFwiRW50ZXJcIikge1xuICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgIGNvbnN0IHNlbGVjdGVkID0gZmxhdFJlc3VsdHNbc2VsZWN0ZWRJbmRleF07XG4gICAgICBpZiAoIXNlbGVjdGVkKSByZXR1cm47XG5cbiAgICAgIGlmIChzZWxlY3RlZC50eXBlID09PSBcInRhc2tcIikge1xuICAgICAgICBvblJlc3VsdENsaWNrKHNlbGVjdGVkLnRhc2tJZCk7XG4gICAgICAgIHNldFF1ZXJ5KFwiXCIpO1xuICAgICAgICBzZXRJc09wZW4oZmFsc2UpO1xuICAgICAgfSBlbHNlIGlmIChzZWxlY3RlZC50eXBlID09PSBcImFwcHJvdmFsXCIpIHtcbiAgICAgICAgaWYgKHNlbGVjdGVkLnRhc2tJZCkge1xuICAgICAgICAgIG9uUmVzdWx0Q2xpY2soc2VsZWN0ZWQudGFza0lkKTtcbiAgICAgICAgICBzZXRRdWVyeShcIlwiKTtcbiAgICAgICAgICBzZXRJc09wZW4oZmFsc2UpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNldE5vbkFjdGlvbmFibGVGZWVkYmFjayh0cnVlKTtcbiAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNldE5vbkFjdGlvbmFibGVGZWVkYmFjayhmYWxzZSksIDEyMDApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKGV2ZW50LmtleSA9PT0gXCJFc2NhcGVcIikge1xuICAgICAgc2V0SXNPcGVuKGZhbHNlKTtcbiAgICB9XG4gIH1cblxuICBjb25zdCBub1Jlc3VsdHMgPSBxdWVyeS5sZW5ndGggPj0gMiAmJiAhIXJlc3VsdHMgJiYgIXJlc3VsdHMudG90YWxSZXN1bHRzO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctWzQ2MHB4XVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICA8U2VhcmNoIHNpemU9ezE1fSBzdHJva2VXaWR0aD17MS43fSBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIGxlZnQtMi41IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LWluay1tdXRlZFwiIGFyaWEtaGlkZGVuIC8+XG4gICAgICAgIDxJbnB1dFxuICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICB2YWx1ZT17cXVlcnl9XG4gICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0UXVlcnkoZXZlbnQudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICBvbktleURvd249e2hhbmRsZUtleURvd259XG4gICAgICAgICAgb25Gb2N1cz17KCkgPT4gcXVlcnkubGVuZ3RoID49IDIgJiYgc2V0SXNPcGVuKHRydWUpfVxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIHRhc2tzLCBhcHByb3ZhbHMsIGFnZW50cy4uLlwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiaC05IHJvdW5kZWQtbGcgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xIHBsLTkgdGV4dC1bMTMuNXB4XSBwbGFjZWhvbGRlcjp0ZXh0LWluay1tdXRlZFwiXG4gICAgICAgICAgYXJpYS1sYWJlbD1cIlNlYXJjaCB0YXNrcywgYXBwcm92YWxzLCBhbmQgYWdlbnRzXCJcbiAgICAgICAgLz5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7aXNPcGVuICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB6LVsxMDAwXSBtdC0yIHctZnVsbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0zIHNoYWRvdy1bdmFyKC0tc2hhZG93LWVsZXZhdGlvbi0yKV1cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1saW5lIHB4LTQgcHktMyB0ZXh0LVsxMS41cHhdIGZvbnQtbWVkaXVtIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAgICB7bm9uQWN0aW9uYWJsZUZlZWRiYWNrID8gKFxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXdhcm5cIj5UaGlzIGl0ZW0gaGFzIG5vIGxpbmtlZCB0YXNrPC9zcGFuPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPD57cmVzdWx0cz8udG90YWxSZXN1bHRzID8/IDB9IHJlc3VsdChzKTwvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8U2Nyb2xsQXJlYSBjbGFzc05hbWU9XCJtYXgtaC1bNDIwcHhdXCI+XG4gICAgICAgICAgICA8U2VhcmNoU2VjdGlvblxuICAgICAgICAgICAgICB0aXRsZT1cIlRhc2tzXCJcbiAgICAgICAgICAgICAgcm93cz17dGFza1Jlc3VsdHMubWFwKCh0YXNrKSA9PiAoe1xuICAgICAgICAgICAgICAgIGtleTogYHRhc2stJHt0YXNrLl9pZH1gLFxuICAgICAgICAgICAgICAgIHRpdGxlOiB0YXNrLnRpdGxlLFxuICAgICAgICAgICAgICAgIHN1YnRpdGxlOiBgJHt0YXNrLnN0YXR1c30gwrcgJHt0YXNrLnR5cGV9IMK3IFAke3Rhc2sucHJpb3JpdHl9YCxcbiAgICAgICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBvblJlc3VsdENsaWNrKHRhc2suX2lkKTtcbiAgICAgICAgICAgICAgICAgIHNldFF1ZXJ5KFwiXCIpO1xuICAgICAgICAgICAgICAgICAgc2V0SXNPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGlzU2VsZWN0ZWQ6IGZsYXRSZXN1bHRzW3NlbGVjdGVkSW5kZXhdPy5pZCA9PT0gYHRhc2stJHt0YXNrLl9pZH1gLFxuICAgICAgICAgICAgICB9KSl9XG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICA8U2VhcmNoU2VjdGlvblxuICAgICAgICAgICAgICB0aXRsZT1cIkFwcHJvdmFsc1wiXG4gICAgICAgICAgICAgIHJvd3M9e2FwcHJvdmFsUmVzdWx0cy5tYXAoKGFwcHJvdmFsKSA9PiAoe1xuICAgICAgICAgICAgICAgIGtleTogYGFwcHJvdmFsLSR7YXBwcm92YWwuX2lkfWAsXG4gICAgICAgICAgICAgICAgdGl0bGU6IGFwcHJvdmFsLmFjdGlvblN1bW1hcnksXG4gICAgICAgICAgICAgICAgc3VidGl0bGU6IGAke2FwcHJvdmFsLnN0YXR1c30gwrcgJHthcHByb3ZhbC5yaXNrTGV2ZWx9IMK3ICR7YXBwcm92YWwuYWN0aW9uVHlwZX1gLFxuICAgICAgICAgICAgICAgIG9uQ2xpY2s6IGFwcHJvdmFsLnRhc2tJZFxuICAgICAgICAgICAgICAgICAgPyAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgb25SZXN1bHRDbGljayhhcHByb3ZhbC50YXNrSWQgYXMgc3RyaW5nKTtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRRdWVyeShcIlwiKTtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRJc09wZW4oZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICBpc1NlbGVjdGVkOiBmbGF0UmVzdWx0c1tzZWxlY3RlZEluZGV4XT8uaWQgPT09IGBhcHByb3ZhbC0ke2FwcHJvdmFsLl9pZH1gLFxuICAgICAgICAgICAgICB9KSl9XG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICA8U2VhcmNoU2VjdGlvblxuICAgICAgICAgICAgICB0aXRsZT1cIkFnZW50c1wiXG4gICAgICAgICAgICAgIHJvd3M9e2FnZW50UmVzdWx0cy5tYXAoKGFnZW50KSA9PiAoe1xuICAgICAgICAgICAgICAgIGtleTogYGFnZW50LSR7YWdlbnQuX2lkfWAsXG4gICAgICAgICAgICAgICAgdGl0bGU6IGFnZW50Lm5hbWUsXG4gICAgICAgICAgICAgICAgc3VidGl0bGU6IGAke2FnZW50LnJvbGV9IMK3ICR7YWdlbnQuc3RhdHVzfWAsXG4gICAgICAgICAgICAgICAgb25DbGljazogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIGlzU2VsZWN0ZWQ6IGZhbHNlLFxuICAgICAgICAgICAgICB9KSl9XG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICA8U2VhcmNoU2VjdGlvblxuICAgICAgICAgICAgICB0aXRsZT1cIk1lc3NhZ2VzXCJcbiAgICAgICAgICAgICAgcm93cz17bWVzc2FnZVJlc3VsdHMuc2xpY2UoMCwgNCkubWFwKChtZXNzYWdlKSA9PiAoe1xuICAgICAgICAgICAgICAgIGtleTogYG1lc3NhZ2UtJHttZXNzYWdlLl9pZH1gLFxuICAgICAgICAgICAgICAgIHRpdGxlOiBtZXNzYWdlLmNvbnRlbnQuc2xpY2UoMCwgODApLFxuICAgICAgICAgICAgICAgIHN1YnRpdGxlOiBtZXNzYWdlLnR5cGUsXG4gICAgICAgICAgICAgICAgb25DbGljazogbWVzc2FnZS50YXNrSWRcbiAgICAgICAgICAgICAgICAgID8gKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIG9uUmVzdWx0Q2xpY2sobWVzc2FnZS50YXNrSWQgYXMgc3RyaW5nKTtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRRdWVyeShcIlwiKTtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRJc09wZW4oZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICBpc1NlbGVjdGVkOiBmYWxzZSxcbiAgICAgICAgICAgICAgfSkpfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L1Njcm9sbEFyZWE+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAge25vUmVzdWx0cyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgei1bMTAwMF0gbXQtMiB3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0zIHB4LTQgcHktMyB0ZXh0LWNlbnRlciB0ZXh0LVsxMy41cHhdIHRleHQtaW5rLW11dGVkIHNoYWRvdy1bdmFyKC0tc2hhZG93LWVsZXZhdGlvbi0yKV1cIj5cbiAgICAgICAgICBObyByZXN1bHRzIGZvciBcIntxdWVyeX1cIlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmZ1bmN0aW9uIFNlYXJjaFNlY3Rpb24oe1xuICB0aXRsZSxcbiAgcm93cyxcbn06IHtcbiAgdGl0bGU6IHN0cmluZztcbiAgcm93czogQXJyYXk8e1xuICAgIGtleTogc3RyaW5nO1xuICAgIHRpdGxlOiBzdHJpbmc7XG4gICAgc3VidGl0bGU6IHN0cmluZztcbiAgICBvbkNsaWNrPzogKCkgPT4gdm9pZDtcbiAgICBpc1NlbGVjdGVkOiBib29sZWFuO1xuICB9Pjtcbn0pIHtcbiAgaWYgKCFyb3dzLmxlbmd0aCkgcmV0dXJuIG51bGw7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1saW5lIHAtMiBsYXN0OmJvcmRlci1iLTBcIj5cbiAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTEgcHgtMiB0ZXh0LVsxMS41cHhdIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy1bMC4wNmVtXSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICB7dGl0bGV9XG4gICAgICA8L3A+XG4gICAgICB7cm93cy5tYXAoKHJvdykgPT4gKFxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAga2V5PXtyb3cua2V5fVxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIG9uQ2xpY2s9e3Jvdy5vbkNsaWNrfVxuICAgICAgICAgIGRpc2FibGVkPXshcm93Lm9uQ2xpY2t9XG4gICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgIFwidy1mdWxsIHJvdW5kZWQtbGcgcHgtMyBweS0yLjUgdGV4dC1sZWZ0IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiLFxuICAgICAgICAgICAgcm93LmlzU2VsZWN0ZWQgJiYgXCJiZy1zdXJmYWNlLTJcIixcbiAgICAgICAgICAgIHJvdy5vbkNsaWNrXG4gICAgICAgICAgICAgID8gXCJjdXJzb3ItcG9pbnRlciB0ZXh0LWluayBob3ZlcjpiZy1zdXJmYWNlLTJcIlxuICAgICAgICAgICAgICA6IFwiY3Vyc29yLWRlZmF1bHQgdGV4dC1pbmstc2Vjb25kYXJ5XCJcbiAgICAgICAgICApfVxuICAgICAgICA+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdHJ1bmNhdGUgdGV4dC1bMTMuNXB4XSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAge3RpdGxlID09PSBcIkFnZW50c1wiICYmIDxCb3Qgc2l6ZT17MTR9IHN0cm9rZVdpZHRoPXsxLjd9IGFyaWEtaGlkZGVuIC8+fVxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj57cm93LnRpdGxlfTwvc3Bhbj5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgdHJ1bmNhdGUgdGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZFwiPntyb3cuc3VidGl0bGV9PC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICkpfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvU2VhcmNoQmFyLnRzeCJ9