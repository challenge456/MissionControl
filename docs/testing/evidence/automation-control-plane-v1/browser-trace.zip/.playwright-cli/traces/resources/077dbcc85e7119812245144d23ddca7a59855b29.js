import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/dashboard/UsageTrendCharts.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { cn } from "/src/lib/utils.ts";
import {
  CHART_CONTAINER_CLASS,
  CHART_GRID_COLOR,
  CHART_SERIES,
  CHART_STROKE_WIDTH,
  CHART_TICK_STYLE,
  CHART_TOOLTIP_CONTENT_STYLE
} from "/src/components/factory/chartTheme.ts";
import {
  Area,
  AreaChart,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip as RechartsTooltip,
  XAxis,
  YAxis
} from "/node_modules/.vite/deps/recharts.js?v=6daa7d05";
function formatPeriodTick(value, windowHours) {
  if (windowHours === 24) {
    const hour = value.slice(11, 13);
    return hour ? `${hour}h` : value;
  }
  if (windowHours === 168) return value.slice(5, 10);
  return value.slice(0, 10);
}
function ChartEmptyState({ message }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-[200px] items-center justify-center rounded-lg border border-dashed border-line bg-surface-2/50", children: /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-ink-muted", children: message }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
    lineNumber: 61,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
    lineNumber: 60,
    columnNumber: 5
  }, this);
}
_c = ChartEmptyState;
export function UsageTrendCharts({
  series,
  windowHours,
  onWindowChange,
  onOpenCostAnalytics,
  secondaryButtonClass
}) {
  const data = series.map((d) => ({ ...d, totalTokens: d.inputTokens + d.outputTokens }));
  const hasUsage = data.some((d) => d.totalTokens > 0 || d.costUsd > 0);
  const windows = [
    { value: 24, label: "24h" },
    { value: 168, label: "7d" },
    { value: 720, label: "30d" }
  ];
  const btnClass = secondaryButtonClass ?? "rounded-md border border-line px-2.5 py-1 text-[12px] font-medium text-ink-secondary transition-colors duration-150 hover:bg-surface-2 hover:text-ink";
  return /* @__PURE__ */ jsxDEV("section", { className: "flex flex-col gap-3", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-[13px] font-medium uppercase tracking-[0.06em] text-ink-muted", children: "Usage" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
        lineNumber: 93,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center rounded-lg border border-line p-0.5", children: windows.map(
          (w) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => onWindowChange(w.value),
              className: cn(
                "rounded-md px-2.5 py-1 text-[12px] font-medium transition-colors duration-150",
                windowHours === w.value ? "bg-surface-2 text-ink" : "text-ink-muted hover:text-ink-secondary"
              ),
              children: w.label
            },
            w.value,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
              lineNumber: 97,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
          lineNumber: 95,
          columnNumber: 11
        }, this),
        onOpenCostAnalytics && /* @__PURE__ */ jsxDEV("button", { type: "button", className: btnClass, onClick: onOpenCostAnalytics, children: "Cost analytics" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
          lineNumber: 113,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
        lineNumber: 94,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
      lineNumber: 92,
      columnNumber: 7
    }, this),
    !hasUsage ? /* @__PURE__ */ jsxDEV(ChartEmptyState, { message: "No usage in this window." }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
      lineNumber: 120,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-4 lg:grid-cols-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: CHART_CONTAINER_CLASS, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-3 text-[12.5px] font-medium text-ink-secondary", children: "Token usage" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
          lineNumber: 124,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "h-[200px] w-full", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(AreaChart, { data, margin: { top: 4, right: 8, left: 0, bottom: 0 }, children: [
          /* @__PURE__ */ jsxDEV(
            XAxis,
            {
              dataKey: "period",
              tick: CHART_TICK_STYLE,
              tickLine: { stroke: CHART_GRID_COLOR },
              axisLine: { stroke: CHART_GRID_COLOR },
              tickFormatter: (v) => formatPeriodTick(v, windowHours)
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
              lineNumber: 128,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            YAxis,
            {
              tick: CHART_TICK_STYLE,
              tickLine: { stroke: CHART_GRID_COLOR },
              axisLine: { stroke: CHART_GRID_COLOR },
              tickFormatter: (v) => v >= 1e3 ? `${(v / 1e3).toFixed(0)}k` : String(v)
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
              lineNumber: 135,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            RechartsTooltip,
            {
              contentStyle: CHART_TOOLTIP_CONTENT_STYLE,
              formatter: (value) => [
                value >= 1e3 ? `${(value / 1e3).toFixed(1)}k` : value,
                "Tokens"
              ],
              labelFormatter: (l) => typeof l === "string" ? l : ""
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
              lineNumber: 143,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Area,
            {
              type: "monotone",
              dataKey: "totalTokens",
              stroke: CHART_SERIES[1],
              fill: CHART_SERIES[1],
              fillOpacity: 0.12,
              strokeWidth: CHART_STROKE_WIDTH,
              dot: false,
              activeDot: { r: 3 }
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
              lineNumber: 151,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
          lineNumber: 127,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
          lineNumber: 126,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
          lineNumber: 125,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
        lineNumber: 123,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: CHART_CONTAINER_CLASS, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-3 text-[12.5px] font-medium text-ink-secondary", children: "Cost trend" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
          lineNumber: 166,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "h-[200px] w-full", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(LineChart, { data, margin: { top: 4, right: 8, left: 0, bottom: 0 }, children: [
          /* @__PURE__ */ jsxDEV(
            XAxis,
            {
              dataKey: "period",
              tick: CHART_TICK_STYLE,
              tickLine: { stroke: CHART_GRID_COLOR },
              axisLine: { stroke: CHART_GRID_COLOR },
              tickFormatter: (v) => formatPeriodTick(v, windowHours)
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
              lineNumber: 170,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            YAxis,
            {
              tick: CHART_TICK_STYLE,
              tickLine: { stroke: CHART_GRID_COLOR },
              axisLine: { stroke: CHART_GRID_COLOR },
              tickFormatter: (v) => `$${Number(v).toFixed(2)}`
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
              lineNumber: 177,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            RechartsTooltip,
            {
              contentStyle: CHART_TOOLTIP_CONTENT_STYLE,
              formatter: (value) => [`$${Number(value).toFixed(2)}`, "Cost"],
              labelFormatter: (l) => typeof l === "string" ? l : ""
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
              lineNumber: 183,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Line,
            {
              type: "monotone",
              dataKey: "costUsd",
              stroke: CHART_SERIES[0],
              strokeWidth: CHART_STROKE_WIDTH,
              dot: false,
              activeDot: { r: 3 }
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
              lineNumber: 188,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
          lineNumber: 169,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
          lineNumber: 168,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
          lineNumber: 167,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
        lineNumber: 165,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
      lineNumber: 122,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx",
    lineNumber: 91,
    columnNumber: 5
  }, this);
}
_c2 = UsageTrendCharts;
var _c, _c2;
$RefreshReg$(_c, "ChartEmptyState");
$RefreshReg$(_c2, "UsageTrendCharts");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/dashboard/UsageTrendCharts.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUNNOzs7Ozs7Ozs7Ozs7Ozs7O0FBekNOLFNBQVNBLFVBQVU7QUFDbkI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1A7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxXQUFXQztBQUFBQSxFQUNYQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBV1AsU0FBU0MsaUJBQWlCQyxPQUFlQyxhQUFrQztBQUN6RSxNQUFJQSxnQkFBZ0IsSUFBSTtBQUN0QixVQUFNQyxPQUFPRixNQUFNRyxNQUFNLElBQUksRUFBRTtBQUMvQixXQUFPRCxPQUFPLEdBQUdBLElBQUksTUFBTUY7QUFBQUEsRUFDN0I7QUFDQSxNQUFJQyxnQkFBZ0IsSUFBSyxRQUFPRCxNQUFNRyxNQUFNLEdBQUcsRUFBRTtBQUNqRCxTQUFPSCxNQUFNRyxNQUFNLEdBQUcsRUFBRTtBQUMxQjtBQUVBLFNBQVNDLGdCQUFnQixFQUFFQyxRQUE2QixHQUFHO0FBQ3pELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDBHQUNiLGlDQUFDLE9BQUUsV0FBVSw4QkFBOEJBLHFCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW1ELEtBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUNDLEtBTlFGO0FBUUYsZ0JBQVNHLGlCQUFpQjtBQUFBLEVBQy9CQztBQUFBQSxFQUNBUDtBQUFBQSxFQUNBUTtBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQU9GLEdBQWdCO0FBQ2QsUUFBTUMsT0FBT0osT0FBT0ssSUFBSSxDQUFDQyxPQUFPLEVBQUUsR0FBR0EsR0FBR0MsYUFBYUQsRUFBRUUsY0FBY0YsRUFBRUcsYUFBYSxFQUFFO0FBQ3RGLFFBQU1DLFdBQVdOLEtBQUtPLEtBQUssQ0FBQ0wsTUFBTUEsRUFBRUMsY0FBYyxLQUFLRCxFQUFFTSxVQUFVLENBQUM7QUFDcEUsUUFBTUMsVUFBbUQ7QUFBQSxJQUN2RCxFQUFFckIsT0FBTyxJQUFJc0IsT0FBTyxNQUFNO0FBQUEsSUFDMUIsRUFBRXRCLE9BQU8sS0FBS3NCLE9BQU8sS0FBSztBQUFBLElBQzFCLEVBQUV0QixPQUFPLEtBQUtzQixPQUFPLE1BQU07QUFBQSxFQUFDO0FBRTlCLFFBQU1DLFdBQ0paLHdCQUNBO0FBRUYsU0FDRSx1QkFBQyxhQUFRLFdBQVUsdUJBQ2pCO0FBQUEsMkJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHNFQUFxRSxxQkFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RjtBQUFBLE1BQ3hGLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx5REFDWlUsa0JBQVFSO0FBQUFBLFVBQUksQ0FBQ1csTUFDWjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNZixlQUFlZSxFQUFFeEIsS0FBSztBQUFBLGNBQ3JDLFdBQVdqQjtBQUFBQSxnQkFDVDtBQUFBLGdCQUNBa0IsZ0JBQWdCdUIsRUFBRXhCLFFBQ2QsMEJBQ0E7QUFBQSxjQUNOO0FBQUEsY0FFQ3dCLFlBQUVGO0FBQUFBO0FBQUFBLFlBVkVFLEVBQUV4QjtBQUFBQSxZQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFZQTtBQUFBLFFBQ0QsS0FmSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsUUFDQ1UsdUJBQ0MsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBV2EsVUFBVSxTQUFTYixxQkFBb0IsOEJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1QkE7QUFBQSxTQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEJBO0FBQUEsSUFDQyxDQUFDUSxXQUNBLHVCQUFDLG1CQUFnQixTQUFRLDhCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1ELElBRW5ELHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBV2xDLHVCQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFEQUFvRCwyQkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RTtBQUFBLFFBQzlFLHVCQUFDLFNBQUksV0FBVSxvQkFDYixpQ0FBQyx1QkFBb0IsT0FBTSxRQUFPLFFBQU8sUUFDdkMsaUNBQUMsYUFBVSxNQUFZLFFBQVEsRUFBRXlDLEtBQUssR0FBR0MsT0FBTyxHQUFHQyxNQUFNLEdBQUdDLFFBQVEsRUFBRSxHQUNwRTtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFRO0FBQUEsY0FDUixNQUFNeEM7QUFBQUEsY0FDTixVQUFVLEVBQUV5QyxRQUFRNUMsaUJBQWlCO0FBQUEsY0FDckMsVUFBVSxFQUFFNEMsUUFBUTVDLGlCQUFpQjtBQUFBLGNBQ3JDLGVBQWUsQ0FBQzZDLE1BQWMvQixpQkFBaUIrQixHQUFHN0IsV0FBVztBQUFBO0FBQUEsWUFML0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS2lFO0FBQUEsVUFFakU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU1iO0FBQUFBLGNBQ04sVUFBVSxFQUFFeUMsUUFBUTVDLGlCQUFpQjtBQUFBLGNBQ3JDLFVBQVUsRUFBRTRDLFFBQVE1QyxpQkFBaUI7QUFBQSxjQUNyQyxlQUFlLENBQUM2QyxNQUNkQSxLQUFLLE1BQU8sSUFBSUEsSUFBSSxLQUFNQyxRQUFRLENBQUMsQ0FBQyxNQUFNQyxPQUFPRixDQUFDO0FBQUE7QUFBQSxZQUx0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNRztBQUFBLFVBRUg7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLGNBQWN6QztBQUFBQSxjQUNkLFdBQVcsQ0FBQ1csVUFBa0I7QUFBQSxnQkFDNUJBLFNBQVMsTUFBTyxJQUFJQSxRQUFRLEtBQU0rQixRQUFRLENBQUMsQ0FBQyxNQUFNL0I7QUFBQUEsZ0JBQ2xEO0FBQUEsY0FBUTtBQUFBLGNBRVYsZ0JBQWdCLENBQUNpQyxNQUFPLE9BQU9BLE1BQU0sV0FBV0EsSUFBSTtBQUFBO0FBQUEsWUFOdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTTBEO0FBQUEsVUFFMUQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVE7QUFBQSxjQUNSLFFBQVEvQyxhQUFhLENBQUM7QUFBQSxjQUN0QixNQUFNQSxhQUFhLENBQUM7QUFBQSxjQUNwQixhQUFhO0FBQUEsY0FDYixhQUFhQztBQUFBQSxjQUNiLEtBQUs7QUFBQSxjQUNMLFdBQVcsRUFBRStDLEdBQUcsRUFBRTtBQUFBO0FBQUEsWUFScEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUXNCO0FBQUEsYUFoQ3hCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQ0EsS0FuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9DQSxLQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0NBO0FBQUEsV0F4Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlDQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFXbEQsdUJBQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUscURBQW9ELDBCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZFO0FBQUEsUUFDN0UsdUJBQUMsU0FBSSxXQUFVLG9CQUNiLGlDQUFDLHVCQUFvQixPQUFNLFFBQU8sUUFBTyxRQUN2QyxpQ0FBQyxhQUFVLE1BQVksUUFBUSxFQUFFeUMsS0FBSyxHQUFHQyxPQUFPLEdBQUdDLE1BQU0sR0FBR0MsUUFBUSxFQUFFLEdBQ3BFO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVE7QUFBQSxjQUNSLE1BQU14QztBQUFBQSxjQUNOLFVBQVUsRUFBRXlDLFFBQVE1QyxpQkFBaUI7QUFBQSxjQUNyQyxVQUFVLEVBQUU0QyxRQUFRNUMsaUJBQWlCO0FBQUEsY0FDckMsZUFBZSxDQUFDNkMsTUFBYy9CLGlCQUFpQitCLEdBQUc3QixXQUFXO0FBQUE7QUFBQSxZQUwvRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLaUU7QUFBQSxVQUVqRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTWI7QUFBQUEsY0FDTixVQUFVLEVBQUV5QyxRQUFRNUMsaUJBQWlCO0FBQUEsY0FDckMsVUFBVSxFQUFFNEMsUUFBUTVDLGlCQUFpQjtBQUFBLGNBQ3JDLGVBQWUsQ0FBQzZDLE1BQWMsSUFBSUssT0FBT0wsQ0FBQyxFQUFFQyxRQUFRLENBQUMsQ0FBQztBQUFBO0FBQUEsWUFKeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSTJEO0FBQUEsVUFFM0Q7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLGNBQWMxQztBQUFBQSxjQUNkLFdBQVcsQ0FBQ1csVUFBa0IsQ0FBQyxJQUFJbUMsT0FBT25DLEtBQUssRUFBRStCLFFBQVEsQ0FBQyxDQUFDLElBQUksTUFBTTtBQUFBLGNBQ3JFLGdCQUFnQixDQUFDRSxNQUFPLE9BQU9BLE1BQU0sV0FBV0EsSUFBSTtBQUFBO0FBQUEsWUFIdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRzBEO0FBQUEsVUFFMUQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVE7QUFBQSxjQUNSLFFBQVEvQyxhQUFhLENBQUM7QUFBQSxjQUN0QixhQUFhQztBQUFBQSxjQUNiLEtBQUs7QUFBQSxjQUNMLFdBQVcsRUFBRStDLEdBQUcsRUFBRTtBQUFBO0FBQUEsWUFOcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTXNCO0FBQUEsYUF6QnhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyQkEsS0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZCQSxLQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBO0FBQUEsV0FqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtDQTtBQUFBLFNBN0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4RUE7QUFBQSxPQTdHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0dBO0FBRUo7QUFBQ0UsTUExSWU3QjtBQUFnQixJQUFBRCxJQUFBOEI7QUFBQSxhQUFBOUIsSUFBQTtBQUFBLGFBQUE4QixLQUFBIiwibmFtZXMiOlsiY24iLCJDSEFSVF9DT05UQUlORVJfQ0xBU1MiLCJDSEFSVF9HUklEX0NPTE9SIiwiQ0hBUlRfU0VSSUVTIiwiQ0hBUlRfU1RST0tFX1dJRFRIIiwiQ0hBUlRfVElDS19TVFlMRSIsIkNIQVJUX1RPT0xUSVBfQ09OVEVOVF9TVFlMRSIsIkFyZWEiLCJBcmVhQ2hhcnQiLCJMaW5lIiwiTGluZUNoYXJ0IiwiUmVzcG9uc2l2ZUNvbnRhaW5lciIsIlRvb2x0aXAiLCJSZWNoYXJ0c1Rvb2x0aXAiLCJYQXhpcyIsIllBeGlzIiwiZm9ybWF0UGVyaW9kVGljayIsInZhbHVlIiwid2luZG93SG91cnMiLCJob3VyIiwic2xpY2UiLCJDaGFydEVtcHR5U3RhdGUiLCJtZXNzYWdlIiwiX2MiLCJVc2FnZVRyZW5kQ2hhcnRzIiwic2VyaWVzIiwib25XaW5kb3dDaGFuZ2UiLCJvbk9wZW5Db3N0QW5hbHl0aWNzIiwic2Vjb25kYXJ5QnV0dG9uQ2xhc3MiLCJkYXRhIiwibWFwIiwiZCIsInRvdGFsVG9rZW5zIiwiaW5wdXRUb2tlbnMiLCJvdXRwdXRUb2tlbnMiLCJoYXNVc2FnZSIsInNvbWUiLCJjb3N0VXNkIiwid2luZG93cyIsImxhYmVsIiwiYnRuQ2xhc3MiLCJ3IiwidG9wIiwicmlnaHQiLCJsZWZ0IiwiYm90dG9tIiwic3Ryb2tlIiwidiIsInRvRml4ZWQiLCJTdHJpbmciLCJsIiwiciIsIk51bWJlciIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJVc2FnZVRyZW5kQ2hhcnRzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiO1xuaW1wb3J0IHtcbiAgQ0hBUlRfQ09OVEFJTkVSX0NMQVNTLFxuICBDSEFSVF9HUklEX0NPTE9SLFxuICBDSEFSVF9TRVJJRVMsXG4gIENIQVJUX1NUUk9LRV9XSURUSCxcbiAgQ0hBUlRfVElDS19TVFlMRSxcbiAgQ0hBUlRfVE9PTFRJUF9DT05URU5UX1NUWUxFLFxufSBmcm9tIFwiQC9jb21wb25lbnRzL2ZhY3RvcnkvY2hhcnRUaGVtZVwiO1xuaW1wb3J0IHtcbiAgQXJlYSxcbiAgQXJlYUNoYXJ0LFxuICBMaW5lLFxuICBMaW5lQ2hhcnQsXG4gIFJlc3BvbnNpdmVDb250YWluZXIsXG4gIFRvb2x0aXAgYXMgUmVjaGFydHNUb29sdGlwLFxuICBYQXhpcyxcbiAgWUF4aXMsXG59IGZyb20gXCJyZWNoYXJ0c1wiO1xuXG5leHBvcnQgdHlwZSBDaGFydFdpbmRvdyA9IDI0IHwgMTY4IHwgNzIwO1xuXG5leHBvcnQgaW50ZXJmYWNlIFVzYWdlUG9pbnQge1xuICBwZXJpb2Q6IHN0cmluZztcbiAgaW5wdXRUb2tlbnM6IG51bWJlcjtcbiAgb3V0cHV0VG9rZW5zOiBudW1iZXI7XG4gIGNvc3RVc2Q6IG51bWJlcjtcbn1cblxuZnVuY3Rpb24gZm9ybWF0UGVyaW9kVGljayh2YWx1ZTogc3RyaW5nLCB3aW5kb3dIb3VyczogQ2hhcnRXaW5kb3cpOiBzdHJpbmcge1xuICBpZiAod2luZG93SG91cnMgPT09IDI0KSB7XG4gICAgY29uc3QgaG91ciA9IHZhbHVlLnNsaWNlKDExLCAxMyk7XG4gICAgcmV0dXJuIGhvdXIgPyBgJHtob3VyfWhgIDogdmFsdWU7XG4gIH1cbiAgaWYgKHdpbmRvd0hvdXJzID09PSAxNjgpIHJldHVybiB2YWx1ZS5zbGljZSg1LCAxMCk7XG4gIHJldHVybiB2YWx1ZS5zbGljZSgwLCAxMCk7XG59XG5cbmZ1bmN0aW9uIENoYXJ0RW1wdHlTdGF0ZSh7IG1lc3NhZ2UgfTogeyBtZXNzYWdlOiBzdHJpbmcgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLVsyMDBweF0gaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1kYXNoZWQgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yLzUwXCI+XG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSB0ZXh0LWluay1tdXRlZFwiPnttZXNzYWdlfTwvcD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFVzYWdlVHJlbmRDaGFydHMoe1xuICBzZXJpZXMsXG4gIHdpbmRvd0hvdXJzLFxuICBvbldpbmRvd0NoYW5nZSxcbiAgb25PcGVuQ29zdEFuYWx5dGljcyxcbiAgc2Vjb25kYXJ5QnV0dG9uQ2xhc3MsXG59OiB7XG4gIHNlcmllczogVXNhZ2VQb2ludFtdO1xuICB3aW5kb3dIb3VyczogQ2hhcnRXaW5kb3c7XG4gIG9uV2luZG93Q2hhbmdlOiAodzogQ2hhcnRXaW5kb3cpID0+IHZvaWQ7XG4gIG9uT3BlbkNvc3RBbmFseXRpY3M/OiAoKSA9PiB2b2lkO1xuICBzZWNvbmRhcnlCdXR0b25DbGFzcz86IHN0cmluZztcbn0pOiBKU1guRWxlbWVudCB7XG4gIGNvbnN0IGRhdGEgPSBzZXJpZXMubWFwKChkKSA9PiAoeyAuLi5kLCB0b3RhbFRva2VuczogZC5pbnB1dFRva2VucyArIGQub3V0cHV0VG9rZW5zIH0pKTtcbiAgY29uc3QgaGFzVXNhZ2UgPSBkYXRhLnNvbWUoKGQpID0+IGQudG90YWxUb2tlbnMgPiAwIHx8IGQuY29zdFVzZCA+IDApO1xuICBjb25zdCB3aW5kb3dzOiB7IHZhbHVlOiBDaGFydFdpbmRvdzsgbGFiZWw6IHN0cmluZyB9W10gPSBbXG4gICAgeyB2YWx1ZTogMjQsIGxhYmVsOiBcIjI0aFwiIH0sXG4gICAgeyB2YWx1ZTogMTY4LCBsYWJlbDogXCI3ZFwiIH0sXG4gICAgeyB2YWx1ZTogNzIwLCBsYWJlbDogXCIzMGRcIiB9LFxuICBdO1xuICBjb25zdCBidG5DbGFzcyA9XG4gICAgc2Vjb25kYXJ5QnV0dG9uQ2xhc3MgPz9cbiAgICBcInJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIHB4LTIuNSBweS0xIHRleHQtWzEycHhdIGZvbnQtbWVkaXVtIHRleHQtaW5rLXNlY29uZGFyeSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgaG92ZXI6Ymctc3VyZmFjZS0yIGhvdmVyOnRleHQtaW5rXCI7XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0zXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMTNweF0gZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLVswLjA2ZW1dIHRleHQtaW5rLW11dGVkXCI+VXNhZ2U8L2gyPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBwLTAuNVwiPlxuICAgICAgICAgICAge3dpbmRvd3MubWFwKCh3KSA9PiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBrZXk9e3cudmFsdWV9XG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25XaW5kb3dDaGFuZ2Uody52YWx1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgIFwicm91bmRlZC1tZCBweC0yLjUgcHktMSB0ZXh0LVsxMnB4XSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTBcIixcbiAgICAgICAgICAgICAgICAgIHdpbmRvd0hvdXJzID09PSB3LnZhbHVlXG4gICAgICAgICAgICAgICAgICAgID8gXCJiZy1zdXJmYWNlLTIgdGV4dC1pbmtcIlxuICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1pbmstbXV0ZWQgaG92ZXI6dGV4dC1pbmstc2Vjb25kYXJ5XCIsXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHt3LmxhYmVsfVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHtvbk9wZW5Db3N0QW5hbHl0aWNzICYmIChcbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT17YnRuQ2xhc3N9IG9uQ2xpY2s9e29uT3BlbkNvc3RBbmFseXRpY3N9PlxuICAgICAgICAgICAgICBDb3N0IGFuYWx5dGljc1xuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIHshaGFzVXNhZ2UgPyAoXG4gICAgICAgIDxDaGFydEVtcHR5U3RhdGUgbWVzc2FnZT1cIk5vIHVzYWdlIGluIHRoaXMgd2luZG93LlwiIC8+XG4gICAgICApIDogKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTQgbGc6Z3JpZC1jb2xzLTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17Q0hBUlRfQ09OVEFJTkVSX0NMQVNTfT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyB0ZXh0LVsxMi41cHhdIGZvbnQtbWVkaXVtIHRleHQtaW5rLXNlY29uZGFyeVwiPlRva2VuIHVzYWdlPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtWzIwMHB4XSB3LWZ1bGxcIj5cbiAgICAgICAgICAgICAgPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PVwiMTAwJVwiPlxuICAgICAgICAgICAgICAgIDxBcmVhQ2hhcnQgZGF0YT17ZGF0YX0gbWFyZ2luPXt7IHRvcDogNCwgcmlnaHQ6IDgsIGxlZnQ6IDAsIGJvdHRvbTogMCB9fT5cbiAgICAgICAgICAgICAgICAgIDxYQXhpc1xuICAgICAgICAgICAgICAgICAgICBkYXRhS2V5PVwicGVyaW9kXCJcbiAgICAgICAgICAgICAgICAgICAgdGljaz17Q0hBUlRfVElDS19TVFlMRX1cbiAgICAgICAgICAgICAgICAgICAgdGlja0xpbmU9e3sgc3Ryb2tlOiBDSEFSVF9HUklEX0NPTE9SIH19XG4gICAgICAgICAgICAgICAgICAgIGF4aXNMaW5lPXt7IHN0cm9rZTogQ0hBUlRfR1JJRF9DT0xPUiB9fVxuICAgICAgICAgICAgICAgICAgICB0aWNrRm9ybWF0dGVyPXsodjogc3RyaW5nKSA9PiBmb3JtYXRQZXJpb2RUaWNrKHYsIHdpbmRvd0hvdXJzKX1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8WUF4aXNcbiAgICAgICAgICAgICAgICAgICAgdGljaz17Q0hBUlRfVElDS19TVFlMRX1cbiAgICAgICAgICAgICAgICAgICAgdGlja0xpbmU9e3sgc3Ryb2tlOiBDSEFSVF9HUklEX0NPTE9SIH19XG4gICAgICAgICAgICAgICAgICAgIGF4aXNMaW5lPXt7IHN0cm9rZTogQ0hBUlRfR1JJRF9DT0xPUiB9fVxuICAgICAgICAgICAgICAgICAgICB0aWNrRm9ybWF0dGVyPXsodjogbnVtYmVyKSA9PlxuICAgICAgICAgICAgICAgICAgICAgIHYgPj0gMTAwMCA/IGAkeyh2IC8gMTAwMCkudG9GaXhlZCgwKX1rYCA6IFN0cmluZyh2KVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPFJlY2hhcnRzVG9vbHRpcFxuICAgICAgICAgICAgICAgICAgICBjb250ZW50U3R5bGU9e0NIQVJUX1RPT0xUSVBfQ09OVEVOVF9TVFlMRX1cbiAgICAgICAgICAgICAgICAgICAgZm9ybWF0dGVyPXsodmFsdWU6IG51bWJlcikgPT4gW1xuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlID49IDEwMDAgPyBgJHsodmFsdWUgLyAxMDAwKS50b0ZpeGVkKDEpfWtgIDogdmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgXCJUb2tlbnNcIixcbiAgICAgICAgICAgICAgICAgICAgXX1cbiAgICAgICAgICAgICAgICAgICAgbGFiZWxGb3JtYXR0ZXI9eyhsKSA9PiAodHlwZW9mIGwgPT09IFwic3RyaW5nXCIgPyBsIDogXCJcIil9XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPEFyZWFcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm1vbm90b25lXCJcbiAgICAgICAgICAgICAgICAgICAgZGF0YUtleT1cInRvdGFsVG9rZW5zXCJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPXtDSEFSVF9TRVJJRVNbMV19XG4gICAgICAgICAgICAgICAgICAgIGZpbGw9e0NIQVJUX1NFUklFU1sxXX1cbiAgICAgICAgICAgICAgICAgICAgZmlsbE9wYWNpdHk9ezAuMTJ9XG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXtDSEFSVF9TVFJPS0VfV0lEVEh9XG4gICAgICAgICAgICAgICAgICAgIGRvdD17ZmFsc2V9XG4gICAgICAgICAgICAgICAgICAgIGFjdGl2ZURvdD17eyByOiAzIH19XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvQXJlYUNoYXJ0PlxuICAgICAgICAgICAgICA8L1Jlc3BvbnNpdmVDb250YWluZXI+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17Q0hBUlRfQ09OVEFJTkVSX0NMQVNTfT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyB0ZXh0LVsxMi41cHhdIGZvbnQtbWVkaXVtIHRleHQtaW5rLXNlY29uZGFyeVwiPkNvc3QgdHJlbmQ8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1bMjAwcHhdIHctZnVsbFwiPlxuICAgICAgICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCI+XG4gICAgICAgICAgICAgICAgPExpbmVDaGFydCBkYXRhPXtkYXRhfSBtYXJnaW49e3sgdG9wOiA0LCByaWdodDogOCwgbGVmdDogMCwgYm90dG9tOiAwIH19PlxuICAgICAgICAgICAgICAgICAgPFhBeGlzXG4gICAgICAgICAgICAgICAgICAgIGRhdGFLZXk9XCJwZXJpb2RcIlxuICAgICAgICAgICAgICAgICAgICB0aWNrPXtDSEFSVF9USUNLX1NUWUxFfVxuICAgICAgICAgICAgICAgICAgICB0aWNrTGluZT17eyBzdHJva2U6IENIQVJUX0dSSURfQ09MT1IgfX1cbiAgICAgICAgICAgICAgICAgICAgYXhpc0xpbmU9e3sgc3Ryb2tlOiBDSEFSVF9HUklEX0NPTE9SIH19XG4gICAgICAgICAgICAgICAgICAgIHRpY2tGb3JtYXR0ZXI9eyh2OiBzdHJpbmcpID0+IGZvcm1hdFBlcmlvZFRpY2sodiwgd2luZG93SG91cnMpfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxZQXhpc1xuICAgICAgICAgICAgICAgICAgICB0aWNrPXtDSEFSVF9USUNLX1NUWUxFfVxuICAgICAgICAgICAgICAgICAgICB0aWNrTGluZT17eyBzdHJva2U6IENIQVJUX0dSSURfQ09MT1IgfX1cbiAgICAgICAgICAgICAgICAgICAgYXhpc0xpbmU9e3sgc3Ryb2tlOiBDSEFSVF9HUklEX0NPTE9SIH19XG4gICAgICAgICAgICAgICAgICAgIHRpY2tGb3JtYXR0ZXI9eyh2OiBudW1iZXIpID0+IGAkJHtOdW1iZXIodikudG9GaXhlZCgyKX1gfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxSZWNoYXJ0c1Rvb2x0aXBcbiAgICAgICAgICAgICAgICAgICAgY29udGVudFN0eWxlPXtDSEFSVF9UT09MVElQX0NPTlRFTlRfU1RZTEV9XG4gICAgICAgICAgICAgICAgICAgIGZvcm1hdHRlcj17KHZhbHVlOiBudW1iZXIpID0+IFtgJCR7TnVtYmVyKHZhbHVlKS50b0ZpeGVkKDIpfWAsIFwiQ29zdFwiXX1cbiAgICAgICAgICAgICAgICAgICAgbGFiZWxGb3JtYXR0ZXI9eyhsKSA9PiAodHlwZW9mIGwgPT09IFwic3RyaW5nXCIgPyBsIDogXCJcIil9XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPExpbmVcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm1vbm90b25lXCJcbiAgICAgICAgICAgICAgICAgICAgZGF0YUtleT1cImNvc3RVc2RcIlxuICAgICAgICAgICAgICAgICAgICBzdHJva2U9e0NIQVJUX1NFUklFU1swXX1cbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9e0NIQVJUX1NUUk9LRV9XSURUSH1cbiAgICAgICAgICAgICAgICAgICAgZG90PXtmYWxzZX1cbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlRG90PXt7IHI6IDMgfX1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9MaW5lQ2hhcnQ+XG4gICAgICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9zZWN0aW9uPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvY29tcG9uZW50cy9kYXNoYm9hcmQvVXNhZ2VUcmVuZENoYXJ0cy50c3gifQ==