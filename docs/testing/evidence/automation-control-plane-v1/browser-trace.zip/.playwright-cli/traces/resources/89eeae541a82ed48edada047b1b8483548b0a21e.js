import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Toast.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Toast.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const createContext = __vite__cjsImport3_react["createContext"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Toaster, toast as sonnerToast } from "/node_modules/.vite/deps/sonner.js?v=9e9e4f14";
const ToastContext = createContext({ toast: () => {
} });
export function ToastProvider({ children }) {
  _s();
  const [theme, setTheme] = useState(() => {
    if (typeof document === "undefined") return "dark";
    return document.documentElement.getAttribute("data-theme") === "light" ? "light" : "dark";
  });
  useEffect(() => {
    if (typeof document === "undefined") return;
    const observer = new MutationObserver(() => {
      const isLight = document.documentElement.getAttribute("data-theme") === "light";
      setTheme(isLight ? "light" : "dark");
    });
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["data-theme"]
    });
    return () => observer.disconnect();
  }, []);
  const toast = useCallback((text, error) => {
    if (error) {
      sonnerToast.error(text, { duration: 4500 });
      return;
    }
    sonnerToast.message(text, { duration: 3200 });
  }, []);
  return /* @__PURE__ */ jsxDEV(ToastContext.Provider, { value: { toast }, children: [
    children,
    /* @__PURE__ */ jsxDEV(
      Toaster,
      {
        theme,
        position: "top-center",
        closeButton: true,
        toastOptions: {
          classNames: {
            toast: "border border-border bg-card text-card-foreground shadow-lg",
            title: "text-sm font-medium",
            closeButton: "bg-secondary text-secondary-foreground border-border"
          }
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Toast.tsx",
        lineNumber: 57,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Toast.tsx",
    lineNumber: 55,
    columnNumber: 5
  }, this);
}
_s(ToastProvider, "NzLkRrJtLzegukjX1iKqOdzANtQ=");
_c = ToastProvider;
export function useToast() {
  _s2();
  return useContext(ToastContext);
}
_s2(useToast, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
$RefreshReg$(_c, "ToastProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Toast.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Toast.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJDTixTQUFTQSxlQUFlQyxhQUFhQyxZQUFZQyxXQUFXQyxnQkFBZ0M7QUFDNUYsU0FBU0MsU0FBU0MsU0FBU0MsbUJBQW1CO0FBRTlDLE1BQU1DLGVBQWVSLGNBRWxCLEVBQUVNLE9BQU9BLE1BQU07QUFBQyxFQUFFLENBQUM7QUFFZixnQkFBU0csY0FBYyxFQUFFQyxTQUFrQyxHQUFHO0FBQUFDLEtBQUE7QUFDbkUsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlULFNBQTJCLE1BQU07QUFDekQsUUFBSSxPQUFPVSxhQUFhLFlBQWEsUUFBTztBQUM1QyxXQUFPQSxTQUFTQyxnQkFBZ0JDLGFBQWEsWUFBWSxNQUFNLFVBQVUsVUFBVTtBQUFBLEVBQ3JGLENBQUM7QUFFRGIsWUFBVSxNQUFNO0FBQ2QsUUFBSSxPQUFPVyxhQUFhLFlBQWE7QUFDckMsVUFBTUcsV0FBVyxJQUFJQyxpQkFBaUIsTUFBTTtBQUMxQyxZQUFNQyxVQUFVTCxTQUFTQyxnQkFBZ0JDLGFBQWEsWUFBWSxNQUFNO0FBQ3hFSCxlQUFTTSxVQUFVLFVBQVUsTUFBTTtBQUFBLElBQ3JDLENBQUM7QUFDREYsYUFBU0csUUFBUU4sU0FBU0MsaUJBQWlCO0FBQUEsTUFDekNNLFlBQVk7QUFBQSxNQUNaQyxpQkFBaUIsQ0FBQyxZQUFZO0FBQUEsSUFDaEMsQ0FBQztBQUNELFdBQU8sTUFBTUwsU0FBU00sV0FBVztBQUFBLEVBQ25DLEdBQUcsRUFBRTtBQUVMLFFBQU1qQixRQUFRTCxZQUFZLENBQUN1QixNQUFjQyxVQUFvQjtBQUMzRCxRQUFJQSxPQUFPO0FBQ1RsQixrQkFBWWtCLE1BQU1ELE1BQU0sRUFBRUUsVUFBVSxLQUFLLENBQUM7QUFDMUM7QUFBQSxJQUNGO0FBQ0FuQixnQkFBWW9CLFFBQVFILE1BQU0sRUFBRUUsVUFBVSxLQUFLLENBQUM7QUFBQSxFQUM5QyxHQUFHLEVBQUU7QUFFTCxTQUNFLHVCQUFDLGFBQWEsVUFBYixFQUFzQixPQUFPLEVBQUVwQixNQUFNLEdBQ25DSTtBQUFBQTtBQUFBQSxJQUNEO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsVUFBUztBQUFBLFFBQ1Q7QUFBQSxRQUNBLGNBQWM7QUFBQSxVQUNaa0IsWUFBWTtBQUFBLFlBQ1Z0QixPQUFPO0FBQUEsWUFDUHVCLE9BQU87QUFBQSxZQUNQQyxhQUFhO0FBQUEsVUFDZjtBQUFBLFFBQ0Y7QUFBQTtBQUFBLE1BVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBVUk7QUFBQSxPQVpOO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FjQTtBQUVKO0FBQUNuQixHQTVDZUYsZUFBYTtBQUFBLEtBQWJBO0FBOENULGdCQUFTc0IsV0FBVztBQUFBQyxNQUFBO0FBQ3pCLFNBQU85QixXQUFXTSxZQUFZO0FBQ2hDO0FBQUN3QixJQUZlRCxVQUFRO0FBQUEsSUFBQUU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiY3JlYXRlQ29udGV4dCIsInVzZUNhbGxiYWNrIiwidXNlQ29udGV4dCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiVG9hc3RlciIsInRvYXN0Iiwic29ubmVyVG9hc3QiLCJUb2FzdENvbnRleHQiLCJUb2FzdFByb3ZpZGVyIiwiY2hpbGRyZW4iLCJfcyIsInRoZW1lIiwic2V0VGhlbWUiLCJkb2N1bWVudCIsImRvY3VtZW50RWxlbWVudCIsImdldEF0dHJpYnV0ZSIsIm9ic2VydmVyIiwiTXV0YXRpb25PYnNlcnZlciIsImlzTGlnaHQiLCJvYnNlcnZlIiwiYXR0cmlidXRlcyIsImF0dHJpYnV0ZUZpbHRlciIsImRpc2Nvbm5lY3QiLCJ0ZXh0IiwiZXJyb3IiLCJkdXJhdGlvbiIsIm1lc3NhZ2UiLCJjbGFzc05hbWVzIiwidGl0bGUiLCJjbG9zZUJ1dHRvbiIsInVzZVRvYXN0IiwiX3MyIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVG9hc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIHVzZUNhbGxiYWNrLCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZVN0YXRlLCB0eXBlIFJlYWN0Tm9kZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgVG9hc3RlciwgdG9hc3QgYXMgc29ubmVyVG9hc3QgfSBmcm9tIFwic29ubmVyXCI7XG5cbmNvbnN0IFRvYXN0Q29udGV4dCA9IGNyZWF0ZUNvbnRleHQ8e1xuICB0b2FzdDogKHRleHQ6IHN0cmluZywgZXJyb3I/OiBib29sZWFuKSA9PiB2b2lkO1xufT4oeyB0b2FzdDogKCkgPT4ge30gfSk7XG5cbmV4cG9ydCBmdW5jdGlvbiBUb2FzdFByb3ZpZGVyKHsgY2hpbGRyZW4gfTogeyBjaGlsZHJlbjogUmVhY3ROb2RlIH0pIHtcbiAgY29uc3QgW3RoZW1lLCBzZXRUaGVtZV0gPSB1c2VTdGF0ZTxcImRhcmtcIiB8IFwibGlnaHRcIj4oKCkgPT4ge1xuICAgIGlmICh0eXBlb2YgZG9jdW1lbnQgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBcImRhcmtcIjtcbiAgICByZXR1cm4gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmdldEF0dHJpYnV0ZShcImRhdGEtdGhlbWVcIikgPT09IFwibGlnaHRcIiA/IFwibGlnaHRcIiA6IFwiZGFya1wiO1xuICB9KTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICh0eXBlb2YgZG9jdW1lbnQgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybjtcbiAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKCgpID0+IHtcbiAgICAgIGNvbnN0IGlzTGlnaHQgPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuZ2V0QXR0cmlidXRlKFwiZGF0YS10aGVtZVwiKSA9PT0gXCJsaWdodFwiO1xuICAgICAgc2V0VGhlbWUoaXNMaWdodCA/IFwibGlnaHRcIiA6IFwiZGFya1wiKTtcbiAgICB9KTtcbiAgICBvYnNlcnZlci5vYnNlcnZlKGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCwge1xuICAgICAgYXR0cmlidXRlczogdHJ1ZSxcbiAgICAgIGF0dHJpYnV0ZUZpbHRlcjogW1wiZGF0YS10aGVtZVwiXSxcbiAgICB9KTtcbiAgICByZXR1cm4gKCkgPT4gb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICB9LCBbXSk7XG5cbiAgY29uc3QgdG9hc3QgPSB1c2VDYWxsYmFjaygodGV4dDogc3RyaW5nLCBlcnJvcj86IGJvb2xlYW4pID0+IHtcbiAgICBpZiAoZXJyb3IpIHtcbiAgICAgIHNvbm5lclRvYXN0LmVycm9yKHRleHQsIHsgZHVyYXRpb246IDQ1MDAgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNvbm5lclRvYXN0Lm1lc3NhZ2UodGV4dCwgeyBkdXJhdGlvbjogMzIwMCB9KTtcbiAgfSwgW10pO1xuXG4gIHJldHVybiAoXG4gICAgPFRvYXN0Q29udGV4dC5Qcm92aWRlciB2YWx1ZT17eyB0b2FzdCB9fT5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICAgIDxUb2FzdGVyXG4gICAgICAgIHRoZW1lPXt0aGVtZX1cbiAgICAgICAgcG9zaXRpb249XCJ0b3AtY2VudGVyXCJcbiAgICAgICAgY2xvc2VCdXR0b25cbiAgICAgICAgdG9hc3RPcHRpb25zPXt7XG4gICAgICAgICAgY2xhc3NOYW1lczoge1xuICAgICAgICAgICAgdG9hc3Q6IFwiYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctY2FyZCB0ZXh0LWNhcmQtZm9yZWdyb3VuZCBzaGFkb3ctbGdcIixcbiAgICAgICAgICAgIHRpdGxlOiBcInRleHQtc20gZm9udC1tZWRpdW1cIixcbiAgICAgICAgICAgIGNsb3NlQnV0dG9uOiBcImJnLXNlY29uZGFyeSB0ZXh0LXNlY29uZGFyeS1mb3JlZ3JvdW5kIGJvcmRlci1ib3JkZXJcIixcbiAgICAgICAgICB9LFxuICAgICAgICB9fVxuICAgICAgLz5cbiAgICA8L1RvYXN0Q29udGV4dC5Qcm92aWRlcj5cbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZVRvYXN0KCkge1xuICByZXR1cm4gdXNlQ29udGV4dChUb2FzdENvbnRleHQpO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvVG9hc3QudHN4In0=