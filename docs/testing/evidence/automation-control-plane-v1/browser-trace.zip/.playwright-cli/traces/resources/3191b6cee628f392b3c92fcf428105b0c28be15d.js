import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/PlanningModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useAction, useMutation, useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { Button } from "/src/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "/src/components/ui/dialog.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { Loader2, Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
export function PlanningModal({
  taskId,
  onClose,
  onSuccess
}) {
  _s();
  const [step, setStep] = useState("questions");
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [plan, setPlan] = useState(null);
  const [questionsLoading, setQuestionsLoading] = useState(false);
  const [planLoading, setPlanLoading] = useState(false);
  const [submitLoading, setSubmitLoading] = useState(false);
  const [error, setError] = useState(null);
  const task = useQuery(
    api.planning.getTaskForPlanning,
    taskId ? { taskId } : "skip"
  );
  const generateQuestions = useAction(api.planning.generateQuestions);
  const generatePlanFromAnswers = useAction(api.planning.generatePlanFromAnswers);
  const submitPlan = useMutation(api.planning.submitPlan);
  useEffect(() => {
    setStep("questions");
    setQuestions([]);
    setAnswers({});
    setPlan(null);
    setError(null);
    setQuestionsLoading(false);
    setPlanLoading(false);
    setSubmitLoading(false);
  }, [taskId]);
  useEffect(() => {
    if (!taskId || !task) return;
    if (step !== "questions" || questions.length > 0) return;
    setQuestionsLoading(true);
    setError(null);
    generateQuestions({
      title: task.title,
      description: task.description ?? void 0,
      type: task.type
    }).then((res) => {
      setQuestions(res.questions);
    }).catch((e) => {
      setError(e instanceof Error ? e.message : "Failed to generate questions");
    }).finally(() => {
      setQuestionsLoading(false);
    });
  }, [taskId, task, step, questions.length, generateQuestions]);
  const handleNextToPlan = async () => {
    if (!task) return;
    const qa = questions.map((q, i) => ({ question: q, answer: answers[i] ?? "" }));
    if (qa.some((a) => !a.answer.trim())) {
      setError("Please answer all questions.");
      return;
    }
    setPlanLoading(true);
    setError(null);
    try {
      const res = await generatePlanFromAnswers({
        title: task.title,
        description: task.description ?? void 0,
        type: task.type,
        answers: qa
      });
      setPlan(res);
      setStep("plan");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to generate plan");
    } finally {
      setPlanLoading(false);
    }
  };
  const handleSubmit = async () => {
    if (!taskId || !plan) return;
    const qa = questions.map((q, i) => ({ question: q, answer: answers[i] ?? "" }));
    setSubmitLoading(true);
    setError(null);
    try {
      await submitPlan({
        taskId,
        workPlan: {
          bullets: plan.bullets,
          estimatedCost: plan.estimatedCost,
          estimatedDuration: plan.estimatedDuration
        },
        planningQa: qa,
        idempotencyKey: `plan:${taskId}:${Date.now()}`
      });
      setStep("done");
      onSuccess?.();
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to submit plan");
    } finally {
      setSubmitLoading(false);
    }
  };
  const open = !!taskId;
  const canNext = questions.length > 0 && questions.every((_, i) => (answers[i] ?? "").trim().length > 0);
  return /* @__PURE__ */ jsxDEV(Dialog, { open, onOpenChange: (o) => {
    if (!o) onClose();
  }, children: /* @__PURE__ */ jsxDEV(DialogContent, { className: "max-w-lg max-h-[85vh] overflow-y-auto", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(Sparkles, { className: "h-5 w-5 text-primary" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
          lineNumber: 160,
          columnNumber: 13
        }, this),
        "Plan with AI"
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
        lineNumber: 159,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: task ? `Clarify and plan: ${task.title.slice(0, 50)}${task.title.length > 50 ? "…" : ""}` : "Loading task…" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
        lineNumber: 163,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
      lineNumber: 158,
      columnNumber: 9
    }, this),
    task && /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 py-2", children: [
      step === "questions" && /* @__PURE__ */ jsxDEV(Fragment, { children: questionsLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-muted-foreground py-6", children: [
        /* @__PURE__ */ jsxDEV(Loader2, { className: "h-4 w-4 animate-spin" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
          lineNumber: 176,
          columnNumber: 21
        }, this),
        "Generating questions…"
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
        lineNumber: 175,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "Answer these so we can build a precise work plan." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
          lineNumber: 181,
          columnNumber: 21
        }, this),
        questions.map(
          (q, i) => /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV(Label, { className: "text-sm font-medium", children: q }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
              lineNumber: 186,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                value: answers[i] ?? "",
                onChange: (e) => setAnswers((prev) => ({ ...prev, [i]: e.target.value })),
                placeholder: "Your answer…",
                className: "bg-background"
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
                lineNumber: 187,
                columnNumber: 25
              },
              this
            )
          ] }, i, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
            lineNumber: 185,
            columnNumber: 15
          }, this)
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
        lineNumber: 180,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
        lineNumber: 173,
        columnNumber: 11
      }, this),
      step === "plan" && plan && /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "Review the work plan, then submit to assign." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
          lineNumber: 204,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("ul", { className: "list-disc pl-5 text-sm text-foreground/90 space-y-1", children: plan.bullets.map(
          (b, i) => /* @__PURE__ */ jsxDEV("li", { children: b }, i, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
            lineNumber: 207,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
          lineNumber: 205,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 text-xs text-muted-foreground", children: [
          plan.estimatedCost != null && /* @__PURE__ */ jsxDEV("span", { children: [
            "Est. cost: $",
            plan.estimatedCost.toFixed(2)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
            lineNumber: 212,
            columnNumber: 15
          }, this),
          plan.estimatedDuration && /* @__PURE__ */ jsxDEV("span", { children: [
            "Est. duration: ",
            plan.estimatedDuration
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
            lineNumber: 215,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
          lineNumber: 210,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
        lineNumber: 203,
        columnNumber: 11
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-destructive bg-destructive/10 px-3 py-2 rounded", children: error }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
        lineNumber: 222,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
      lineNumber: 171,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
      step === "questions" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "outline", onClick: onClose, children: "Cancel" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
          lineNumber: 232,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: handleNextToPlan,
            disabled: questionsLoading || planLoading || !canNext,
            children: planLoading ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Loader2, { className: "h-4 w-4 animate-spin mr-2" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
                lineNumber: 241,
                columnNumber: 21
              }, this),
              "Generating plan…"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
              lineNumber: 240,
              columnNumber: 15
            }, this) : "Generate plan"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
            lineNumber: 235,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
        lineNumber: 231,
        columnNumber: 11
      }, this),
      step === "plan" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "outline", onClick: () => setStep("questions"), children: "Back" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
          lineNumber: 252,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { onClick: handleSubmit, disabled: submitLoading, children: submitLoading ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(Loader2, { className: "h-4 w-4 animate-spin mr-2" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
            lineNumber: 258,
            columnNumber: 21
          }, this),
          "Submitting…"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
          lineNumber: 257,
          columnNumber: 15
        }, this) : "Submit plan & assign" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
          lineNumber: 255,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
        lineNumber: 251,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
      lineNumber: 229,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
    lineNumber: 157,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx",
    lineNumber: 156,
    columnNumber: 5
  }, this);
}
_s(PlanningModal, "ut6AOedU4GtXpB7d+7YgbOCgL9Q=", false, function() {
  return [useQuery, useAction, useAction, useMutation];
});
_c = PlanningModal;
var _c;
$RefreshReg$(_c, "PlanningModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/PlanningModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNElZLFNBYUUsVUFiRjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE1SVosU0FBU0EsVUFBVUMsaUJBQWlCO0FBQ3BDLFNBQVNDLFdBQVdDLGFBQWFDLGdCQUFnQjtBQUNqRCxTQUFTQyxXQUFXO0FBRXBCLFNBQVNDLGNBQWM7QUFDdkI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLFNBQVNDLGdCQUFnQjtBQUkzQixnQkFBU0MsY0FBYztBQUFBLEVBQzVCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUtGLEdBQUc7QUFBQUMsS0FBQTtBQUNELFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJdkIsU0FBZSxXQUFXO0FBQ2xELFFBQU0sQ0FBQ3dCLFdBQVdDLFlBQVksSUFBSXpCLFNBQW1CLEVBQUU7QUFDdkQsUUFBTSxDQUFDMEIsU0FBU0MsVUFBVSxJQUFJM0IsU0FBaUMsQ0FBQyxDQUFDO0FBQ2pFLFFBQU0sQ0FBQzRCLE1BQU1DLE9BQU8sSUFBSTdCLFNBSWQsSUFBSTtBQUNkLFFBQU0sQ0FBQzhCLGtCQUFrQkMsbUJBQW1CLElBQUkvQixTQUFTLEtBQUs7QUFDOUQsUUFBTSxDQUFDZ0MsYUFBYUMsY0FBYyxJQUFJakMsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQ2tDLGVBQWVDLGdCQUFnQixJQUFJbkMsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ29DLE9BQU9DLFFBQVEsSUFBSXJDLFNBQXdCLElBQUk7QUFFdEQsUUFBTXNDLE9BQU9sQztBQUFBQSxJQUNYQyxJQUFJa0MsU0FBU0M7QUFBQUEsSUFDYnRCLFNBQVMsRUFBRUEsT0FBTyxJQUFJO0FBQUEsRUFDeEI7QUFDQSxRQUFNdUIsb0JBQW9CdkMsVUFBVUcsSUFBSWtDLFNBQVNFLGlCQUFpQjtBQUNsRSxRQUFNQywwQkFBMEJ4QyxVQUFVRyxJQUFJa0MsU0FBU0csdUJBQXVCO0FBQzlFLFFBQU1DLGFBQWF4QyxZQUFZRSxJQUFJa0MsU0FBU0ksVUFBVTtBQUV0RDFDLFlBQVUsTUFBTTtBQUNkc0IsWUFBUSxXQUFXO0FBQ25CRSxpQkFBYSxFQUFFO0FBQ2ZFLGVBQVcsQ0FBQyxDQUFDO0FBQ2JFLFlBQVEsSUFBSTtBQUNaUSxhQUFTLElBQUk7QUFDYk4sd0JBQW9CLEtBQUs7QUFDekJFLG1CQUFlLEtBQUs7QUFDcEJFLHFCQUFpQixLQUFLO0FBQUEsRUFDeEIsR0FBRyxDQUFDakIsTUFBTSxDQUFDO0FBRVhqQixZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNpQixVQUFVLENBQUNvQixLQUFNO0FBQ3RCLFFBQUloQixTQUFTLGVBQWVFLFVBQVVvQixTQUFTLEVBQUc7QUFDbERiLHdCQUFvQixJQUFJO0FBQ3hCTSxhQUFTLElBQUk7QUFDYkksc0JBQWtCO0FBQUEsTUFDaEJJLE9BQU9QLEtBQUtPO0FBQUFBLE1BQ1pDLGFBQWFSLEtBQUtRLGVBQWVDO0FBQUFBLE1BQ2pDQyxNQUFNVixLQUFLVTtBQUFBQSxJQUNiLENBQUMsRUFDRUMsS0FBSyxDQUFDQyxRQUFRO0FBQ2J6QixtQkFBYXlCLElBQUkxQixTQUFTO0FBQUEsSUFDNUIsQ0FBQyxFQUNBMkIsTUFBTSxDQUFDQyxNQUFNO0FBQ1pmLGVBQVNlLGFBQWFDLFFBQVFELEVBQUVFLFVBQVUsOEJBQThCO0FBQUEsSUFDMUUsQ0FBQyxFQUNBQyxRQUFRLE1BQU07QUFDYnhCLDBCQUFvQixLQUFLO0FBQUEsSUFDM0IsQ0FBQztBQUFBLEVBQ0wsR0FBRyxDQUFDYixRQUFRb0IsTUFBTWhCLE1BQU1FLFVBQVVvQixRQUFRSCxpQkFBaUIsQ0FBQztBQUU1RCxRQUFNZSxtQkFBbUIsWUFBWTtBQUNuQyxRQUFJLENBQUNsQixLQUFNO0FBQ1gsVUFBTW1CLEtBQUtqQyxVQUFVa0MsSUFBSSxDQUFDQyxHQUFHQyxPQUFPLEVBQUVDLFVBQVVGLEdBQUdHLFFBQVFwQyxRQUFRa0MsQ0FBQyxLQUFLLEdBQUcsRUFBRTtBQUM5RSxRQUFJSCxHQUFHTSxLQUFLLENBQUNDLE1BQU0sQ0FBQ0EsRUFBRUYsT0FBT0csS0FBSyxDQUFDLEdBQUc7QUFDcEM1QixlQUFTLDhCQUE4QjtBQUN2QztBQUFBLElBQ0Y7QUFDQUosbUJBQWUsSUFBSTtBQUNuQkksYUFBUyxJQUFJO0FBQ2IsUUFBSTtBQUNGLFlBQU1hLE1BQU0sTUFBTVIsd0JBQXdCO0FBQUEsUUFDeENHLE9BQU9QLEtBQUtPO0FBQUFBLFFBQ1pDLGFBQWFSLEtBQUtRLGVBQWVDO0FBQUFBLFFBQ2pDQyxNQUFNVixLQUFLVTtBQUFBQSxRQUNYdEIsU0FBUytCO0FBQUFBLE1BQ1gsQ0FBQztBQUNENUIsY0FBUXFCLEdBQUc7QUFDWDNCLGNBQVEsTUFBTTtBQUFBLElBQ2hCLFNBQVM2QixHQUFHO0FBQ1ZmLGVBQVNlLGFBQWFDLFFBQVFELEVBQUVFLFVBQVUseUJBQXlCO0FBQUEsSUFDckUsVUFBQztBQUNDckIscUJBQWUsS0FBSztBQUFBLElBQ3RCO0FBQUEsRUFDRjtBQUVBLFFBQU1pQyxlQUFlLFlBQVk7QUFDL0IsUUFBSSxDQUFDaEQsVUFBVSxDQUFDVSxLQUFNO0FBQ3RCLFVBQU02QixLQUFLakMsVUFBVWtDLElBQUksQ0FBQ0MsR0FBR0MsT0FBTyxFQUFFQyxVQUFVRixHQUFHRyxRQUFRcEMsUUFBUWtDLENBQUMsS0FBSyxHQUFHLEVBQUU7QUFDOUV6QixxQkFBaUIsSUFBSTtBQUNyQkUsYUFBUyxJQUFJO0FBQ2IsUUFBSTtBQUNGLFlBQU1NLFdBQVc7QUFBQSxRQUNmekI7QUFBQUEsUUFDQWlELFVBQVU7QUFBQSxVQUNSQyxTQUFTeEMsS0FBS3dDO0FBQUFBLFVBQ2RDLGVBQWV6QyxLQUFLeUM7QUFBQUEsVUFDcEJDLG1CQUFtQjFDLEtBQUswQztBQUFBQSxRQUMxQjtBQUFBLFFBQ0FDLFlBQVlkO0FBQUFBLFFBQ1plLGdCQUFnQixRQUFRdEQsTUFBTSxJQUFJdUQsS0FBS0MsSUFBSSxDQUFDO0FBQUEsTUFDOUMsQ0FBQztBQUNEbkQsY0FBUSxNQUFNO0FBQ2RILGtCQUFZO0FBQ1pELGNBQVE7QUFBQSxJQUNWLFNBQVNpQyxHQUFHO0FBQ1ZmLGVBQVNlLGFBQWFDLFFBQVFELEVBQUVFLFVBQVUsdUJBQXVCO0FBQUEsSUFDbkUsVUFBQztBQUNDbkIsdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNd0MsT0FBTyxDQUFDLENBQUN6RDtBQUNmLFFBQU0wRCxVQUFVcEQsVUFBVW9CLFNBQVMsS0FBS3BCLFVBQVVxRCxNQUFNLENBQUNDLEdBQUdsQixPQUFPbEMsUUFBUWtDLENBQUMsS0FBSyxJQUFJSyxLQUFLLEVBQUVyQixTQUFTLENBQUM7QUFFdEcsU0FDRSx1QkFBQyxVQUFPLE1BQVksY0FBYyxDQUFDbUMsTUFBTTtBQUFFLFFBQUksQ0FBQ0EsRUFBRzVELFNBQVE7QUFBQSxFQUFHLEdBQzVELGlDQUFDLGlCQUFjLFdBQVUseUNBQ3ZCO0FBQUEsMkJBQUMsZ0JBQ0M7QUFBQSw2QkFBQyxlQUFZLFdBQVUsMkJBQ3JCO0FBQUEsK0JBQUMsWUFBUyxXQUFVLDBCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBDO0FBQUE7QUFBQSxXQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLHFCQUNFbUIsaUJBQ0cscUJBQXFCQSxLQUFLTyxNQUFNbUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxHQUFHMUMsS0FBS08sTUFBTUQsU0FBUyxLQUFLLE1BQU0sRUFBRSxLQUNoRixtQkFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBRUNOLFFBQ0MsdUJBQUMsU0FBSSxXQUFVLGtCQUNaaEI7QUFBQUEsZUFBUyxlQUNSLG1DQUNHUSw2QkFDQyx1QkFBQyxTQUFJLFdBQVUsc0RBQ2I7QUFBQSwrQkFBQyxXQUFRLFdBQVUsMEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUM7QUFBQTtBQUFBLFdBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsT0FBRSxXQUFVLGlDQUErQixpRUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQ04sVUFBVWtDO0FBQUFBLFVBQUksQ0FBQ0MsR0FBR0MsTUFDakIsdUJBQUMsU0FBWSxXQUFVLGFBQ3JCO0FBQUEsbUNBQUMsU0FBTSxXQUFVLHVCQUF1QkQsZUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEM7QUFBQSxZQUMxQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU9qQyxRQUFRa0MsQ0FBQyxLQUFLO0FBQUEsZ0JBQ3JCLFVBQVUsQ0FBQ1IsTUFDVHpCLFdBQVcsQ0FBQ3NELFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUNyQixDQUFDLEdBQUdSLEVBQUU4QixPQUFPQyxNQUFNLEVBQUU7QUFBQSxnQkFFekQsYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQTtBQUFBLGNBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTTJCO0FBQUEsZUFSbkJ2QixHQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxRQUNEO0FBQUEsV0FoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlCQSxLQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEJBO0FBQUEsTUFHRHRDLFNBQVMsVUFBVU0sUUFDbEIsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxPQUFFLFdBQVUsaUNBQWdDLDREQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlGO0FBQUEsUUFDekYsdUJBQUMsUUFBRyxXQUFVLHVEQUNYQSxlQUFLd0MsUUFBUVY7QUFBQUEsVUFBSSxDQUFDMEIsR0FBR3hCLE1BQ3BCLHVCQUFDLFFBQVl3QixlQUFKeEIsR0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlO0FBQUEsUUFDaEIsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSw0Q0FDWmhDO0FBQUFBLGVBQUt5QyxpQkFBaUIsUUFDckIsdUJBQUMsVUFBSztBQUFBO0FBQUEsWUFBYXpDLEtBQUt5QyxjQUFjZ0IsUUFBUSxDQUFDO0FBQUEsZUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxVQUVsRHpELEtBQUswQyxxQkFDSix1QkFBQyxVQUFLO0FBQUE7QUFBQSxZQUFnQjFDLEtBQUswQztBQUFBQSxlQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QztBQUFBLGFBTGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsTUFHRGxDLFNBQ0MsdUJBQUMsT0FBRSxXQUFVLGdFQUNWQSxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQXJESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdURBO0FBQUEsSUFHRix1QkFBQyxnQkFDRWQ7QUFBQUEsZUFBUyxlQUNSLG1DQUNFO0FBQUEsK0JBQUMsVUFBTyxTQUFRLFdBQVUsU0FBU0gsU0FBUSxzQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBU3FDO0FBQUFBLFlBQ1QsVUFBVTFCLG9CQUFvQkUsZUFBZSxDQUFDNEM7QUFBQUEsWUFFN0M1Qyx3QkFDQyxtQ0FDRTtBQUFBLHFDQUFDLFdBQVEsV0FBVSwrQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEM7QUFBQTtBQUFBLGlCQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBLElBRUE7QUFBQTtBQUFBLFVBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWUE7QUFBQSxXQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBO0FBQUEsTUFFRFYsU0FBUyxVQUNSLG1DQUNFO0FBQUEsK0JBQUMsVUFBTyxTQUFRLFdBQVUsU0FBUyxNQUFNQyxRQUFRLFdBQVcsR0FBRSxvQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFPLFNBQVMyQyxjQUFjLFVBQVVoQyxlQUN0Q0EsMEJBQ0MsbUNBQ0U7QUFBQSxpQ0FBQyxXQUFRLFdBQVUsK0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThDO0FBQUE7QUFBQSxhQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0EsSUFFQSwwQkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLFNBcENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQ0E7QUFBQSxPQTlHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0dBLEtBaEhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpSEE7QUFFSjtBQUFDYixHQXhPZUosZUFBYTtBQUFBLFVBc0JkYixVQUlhRixXQUNNQSxXQUNiQyxXQUFXO0FBQUE7QUFBQSxLQTVCaEJjO0FBQWEsSUFBQXFFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlQWN0aW9uIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsImFwaSIsIkJ1dHRvbiIsIkRpYWxvZyIsIkRpYWxvZ0NvbnRlbnQiLCJEaWFsb2dEZXNjcmlwdGlvbiIsIkRpYWxvZ0Zvb3RlciIsIkRpYWxvZ0hlYWRlciIsIkRpYWxvZ1RpdGxlIiwiSW5wdXQiLCJMYWJlbCIsIkxvYWRlcjIiLCJTcGFya2xlcyIsIlBsYW5uaW5nTW9kYWwiLCJ0YXNrSWQiLCJvbkNsb3NlIiwib25TdWNjZXNzIiwiX3MiLCJzdGVwIiwic2V0U3RlcCIsInF1ZXN0aW9ucyIsInNldFF1ZXN0aW9ucyIsImFuc3dlcnMiLCJzZXRBbnN3ZXJzIiwicGxhbiIsInNldFBsYW4iLCJxdWVzdGlvbnNMb2FkaW5nIiwic2V0UXVlc3Rpb25zTG9hZGluZyIsInBsYW5Mb2FkaW5nIiwic2V0UGxhbkxvYWRpbmciLCJzdWJtaXRMb2FkaW5nIiwic2V0U3VibWl0TG9hZGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJ0YXNrIiwicGxhbm5pbmciLCJnZXRUYXNrRm9yUGxhbm5pbmciLCJnZW5lcmF0ZVF1ZXN0aW9ucyIsImdlbmVyYXRlUGxhbkZyb21BbnN3ZXJzIiwic3VibWl0UGxhbiIsImxlbmd0aCIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJ1bmRlZmluZWQiLCJ0eXBlIiwidGhlbiIsInJlcyIsImNhdGNoIiwiZSIsIkVycm9yIiwibWVzc2FnZSIsImZpbmFsbHkiLCJoYW5kbGVOZXh0VG9QbGFuIiwicWEiLCJtYXAiLCJxIiwiaSIsInF1ZXN0aW9uIiwiYW5zd2VyIiwic29tZSIsImEiLCJ0cmltIiwiaGFuZGxlU3VibWl0Iiwid29ya1BsYW4iLCJidWxsZXRzIiwiZXN0aW1hdGVkQ29zdCIsImVzdGltYXRlZER1cmF0aW9uIiwicGxhbm5pbmdRYSIsImlkZW1wb3RlbmN5S2V5IiwiRGF0ZSIsIm5vdyIsIm9wZW4iLCJjYW5OZXh0IiwiZXZlcnkiLCJfIiwibyIsInNsaWNlIiwicHJldiIsInRhcmdldCIsInZhbHVlIiwiYiIsInRvRml4ZWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQbGFubmluZ01vZGFsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VBY3Rpb24sIHVzZU11dGF0aW9uLCB1c2VRdWVyeSB9IGZyb20gXCJjb252ZXgvcmVhY3RcIjtcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi8uLi8uLi9jb252ZXgvX2dlbmVyYXRlZC9hcGlcIjtcbmltcG9ydCB0eXBlIHsgSWQgfSBmcm9tIFwiLi4vLi4vLi4vY29udmV4L19nZW5lcmF0ZWQvZGF0YU1vZGVsXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuaW1wb3J0IHtcbiAgRGlhbG9nLFxuICBEaWFsb2dDb250ZW50LFxuICBEaWFsb2dEZXNjcmlwdGlvbixcbiAgRGlhbG9nRm9vdGVyLFxuICBEaWFsb2dIZWFkZXIsXG4gIERpYWxvZ1RpdGxlLFxufSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2RpYWxvZ1wiO1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2lucHV0XCI7XG5pbXBvcnQgeyBMYWJlbCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvbGFiZWxcIjtcbmltcG9ydCB7IExvYWRlcjIsIFNwYXJrbGVzIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuXG50eXBlIFN0ZXAgPSBcInF1ZXN0aW9uc1wiIHwgXCJwbGFuXCIgfCBcImRvbmVcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIFBsYW5uaW5nTW9kYWwoe1xuICB0YXNrSWQsXG4gIG9uQ2xvc2UsXG4gIG9uU3VjY2Vzcyxcbn06IHtcbiAgdGFza0lkOiBJZDxcInRhc2tzXCI+IHwgbnVsbDtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbiAgb25TdWNjZXNzPzogKCkgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgW3N0ZXAsIHNldFN0ZXBdID0gdXNlU3RhdGU8U3RlcD4oXCJxdWVzdGlvbnNcIik7XG4gIGNvbnN0IFtxdWVzdGlvbnMsIHNldFF1ZXN0aW9uc10gPSB1c2VTdGF0ZTxzdHJpbmdbXT4oW10pO1xuICBjb25zdCBbYW5zd2Vycywgc2V0QW5zd2Vyc10gPSB1c2VTdGF0ZTxSZWNvcmQ8bnVtYmVyLCBzdHJpbmc+Pih7fSk7XG4gIGNvbnN0IFtwbGFuLCBzZXRQbGFuXSA9IHVzZVN0YXRlPHtcbiAgICBidWxsZXRzOiBzdHJpbmdbXTtcbiAgICBlc3RpbWF0ZWRDb3N0PzogbnVtYmVyO1xuICAgIGVzdGltYXRlZER1cmF0aW9uPzogc3RyaW5nO1xuICB9IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtxdWVzdGlvbnNMb2FkaW5nLCBzZXRRdWVzdGlvbnNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3BsYW5Mb2FkaW5nLCBzZXRQbGFuTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzdWJtaXRMb2FkaW5nLCBzZXRTdWJtaXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCB0YXNrID0gdXNlUXVlcnkoXG4gICAgYXBpLnBsYW5uaW5nLmdldFRhc2tGb3JQbGFubmluZyxcbiAgICB0YXNrSWQgPyB7IHRhc2tJZCB9IDogXCJza2lwXCJcbiAgKTtcbiAgY29uc3QgZ2VuZXJhdGVRdWVzdGlvbnMgPSB1c2VBY3Rpb24oYXBpLnBsYW5uaW5nLmdlbmVyYXRlUXVlc3Rpb25zKTtcbiAgY29uc3QgZ2VuZXJhdGVQbGFuRnJvbUFuc3dlcnMgPSB1c2VBY3Rpb24oYXBpLnBsYW5uaW5nLmdlbmVyYXRlUGxhbkZyb21BbnN3ZXJzKTtcbiAgY29uc3Qgc3VibWl0UGxhbiA9IHVzZU11dGF0aW9uKGFwaS5wbGFubmluZy5zdWJtaXRQbGFuKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNldFN0ZXAoXCJxdWVzdGlvbnNcIik7XG4gICAgc2V0UXVlc3Rpb25zKFtdKTtcbiAgICBzZXRBbnN3ZXJzKHt9KTtcbiAgICBzZXRQbGFuKG51bGwpO1xuICAgIHNldEVycm9yKG51bGwpO1xuICAgIHNldFF1ZXN0aW9uc0xvYWRpbmcoZmFsc2UpO1xuICAgIHNldFBsYW5Mb2FkaW5nKGZhbHNlKTtcbiAgICBzZXRTdWJtaXRMb2FkaW5nKGZhbHNlKTtcbiAgfSwgW3Rhc2tJZF0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCF0YXNrSWQgfHwgIXRhc2spIHJldHVybjtcbiAgICBpZiAoc3RlcCAhPT0gXCJxdWVzdGlvbnNcIiB8fCBxdWVzdGlvbnMubGVuZ3RoID4gMCkgcmV0dXJuO1xuICAgIHNldFF1ZXN0aW9uc0xvYWRpbmcodHJ1ZSk7XG4gICAgc2V0RXJyb3IobnVsbCk7XG4gICAgZ2VuZXJhdGVRdWVzdGlvbnMoe1xuICAgICAgdGl0bGU6IHRhc2sudGl0bGUsXG4gICAgICBkZXNjcmlwdGlvbjogdGFzay5kZXNjcmlwdGlvbiA/PyB1bmRlZmluZWQsXG4gICAgICB0eXBlOiB0YXNrLnR5cGUsXG4gICAgfSlcbiAgICAgIC50aGVuKChyZXMpID0+IHtcbiAgICAgICAgc2V0UXVlc3Rpb25zKHJlcy5xdWVzdGlvbnMpO1xuICAgICAgfSlcbiAgICAgIC5jYXRjaCgoZSkgPT4ge1xuICAgICAgICBzZXRFcnJvcihlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiBcIkZhaWxlZCB0byBnZW5lcmF0ZSBxdWVzdGlvbnNcIik7XG4gICAgICB9KVxuICAgICAgLmZpbmFsbHkoKCkgPT4ge1xuICAgICAgICBzZXRRdWVzdGlvbnNMb2FkaW5nKGZhbHNlKTtcbiAgICAgIH0pO1xuICB9LCBbdGFza0lkLCB0YXNrLCBzdGVwLCBxdWVzdGlvbnMubGVuZ3RoLCBnZW5lcmF0ZVF1ZXN0aW9uc10pO1xuXG4gIGNvbnN0IGhhbmRsZU5leHRUb1BsYW4gPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCF0YXNrKSByZXR1cm47XG4gICAgY29uc3QgcWEgPSBxdWVzdGlvbnMubWFwKChxLCBpKSA9PiAoeyBxdWVzdGlvbjogcSwgYW5zd2VyOiBhbnN3ZXJzW2ldID8/IFwiXCIgfSkpO1xuICAgIGlmIChxYS5zb21lKChhKSA9PiAhYS5hbnN3ZXIudHJpbSgpKSkge1xuICAgICAgc2V0RXJyb3IoXCJQbGVhc2UgYW5zd2VyIGFsbCBxdWVzdGlvbnMuXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzZXRQbGFuTG9hZGluZyh0cnVlKTtcbiAgICBzZXRFcnJvcihudWxsKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgZ2VuZXJhdGVQbGFuRnJvbUFuc3dlcnMoe1xuICAgICAgICB0aXRsZTogdGFzay50aXRsZSxcbiAgICAgICAgZGVzY3JpcHRpb246IHRhc2suZGVzY3JpcHRpb24gPz8gdW5kZWZpbmVkLFxuICAgICAgICB0eXBlOiB0YXNrLnR5cGUsXG4gICAgICAgIGFuc3dlcnM6IHFhLFxuICAgICAgfSk7XG4gICAgICBzZXRQbGFuKHJlcyk7XG4gICAgICBzZXRTdGVwKFwicGxhblwiKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBzZXRFcnJvcihlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiBcIkZhaWxlZCB0byBnZW5lcmF0ZSBwbGFuXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRQbGFuTG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXRhc2tJZCB8fCAhcGxhbikgcmV0dXJuO1xuICAgIGNvbnN0IHFhID0gcXVlc3Rpb25zLm1hcCgocSwgaSkgPT4gKHsgcXVlc3Rpb246IHEsIGFuc3dlcjogYW5zd2Vyc1tpXSA/PyBcIlwiIH0pKTtcbiAgICBzZXRTdWJtaXRMb2FkaW5nKHRydWUpO1xuICAgIHNldEVycm9yKG51bGwpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBzdWJtaXRQbGFuKHtcbiAgICAgICAgdGFza0lkLFxuICAgICAgICB3b3JrUGxhbjoge1xuICAgICAgICAgIGJ1bGxldHM6IHBsYW4uYnVsbGV0cyxcbiAgICAgICAgICBlc3RpbWF0ZWRDb3N0OiBwbGFuLmVzdGltYXRlZENvc3QsXG4gICAgICAgICAgZXN0aW1hdGVkRHVyYXRpb246IHBsYW4uZXN0aW1hdGVkRHVyYXRpb24sXG4gICAgICAgIH0sXG4gICAgICAgIHBsYW5uaW5nUWE6IHFhLFxuICAgICAgICBpZGVtcG90ZW5jeUtleTogYHBsYW46JHt0YXNrSWR9OiR7RGF0ZS5ub3coKX1gLFxuICAgICAgfSk7XG4gICAgICBzZXRTdGVwKFwiZG9uZVwiKTtcbiAgICAgIG9uU3VjY2Vzcz8uKCk7XG4gICAgICBvbkNsb3NlKCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgc2V0RXJyb3IoZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogXCJGYWlsZWQgdG8gc3VibWl0IHBsYW5cIik7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFN1Ym1pdExvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBvcGVuID0gISF0YXNrSWQ7XG4gIGNvbnN0IGNhbk5leHQgPSBxdWVzdGlvbnMubGVuZ3RoID4gMCAmJiBxdWVzdGlvbnMuZXZlcnkoKF8sIGkpID0+IChhbnN3ZXJzW2ldID8/IFwiXCIpLnRyaW0oKS5sZW5ndGggPiAwKTtcblxuICByZXR1cm4gKFxuICAgIDxEaWFsb2cgb3Blbj17b3Blbn0gb25PcGVuQ2hhbmdlPXsobykgPT4geyBpZiAoIW8pIG9uQ2xvc2UoKTsgfX0+XG4gICAgICA8RGlhbG9nQ29udGVudCBjbGFzc05hbWU9XCJtYXgtdy1sZyBtYXgtaC1bODV2aF0gb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgIDxEaWFsb2dIZWFkZXI+XG4gICAgICAgICAgPERpYWxvZ1RpdGxlIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LXByaW1hcnlcIiAvPlxuICAgICAgICAgICAgUGxhbiB3aXRoIEFJXG4gICAgICAgICAgPC9EaWFsb2dUaXRsZT5cbiAgICAgICAgICA8RGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgICAgICB7dGFza1xuICAgICAgICAgICAgICA/IGBDbGFyaWZ5IGFuZCBwbGFuOiAke3Rhc2sudGl0bGUuc2xpY2UoMCwgNTApfSR7dGFzay50aXRsZS5sZW5ndGggPiA1MCA/IFwi4oCmXCIgOiBcIlwifWBcbiAgICAgICAgICAgICAgOiBcIkxvYWRpbmcgdGFza+KAplwifVxuICAgICAgICAgIDwvRGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgIDwvRGlhbG9nSGVhZGVyPlxuXG4gICAgICAgIHt0YXNrICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCBweS0yXCI+XG4gICAgICAgICAgICB7c3RlcCA9PT0gXCJxdWVzdGlvbnNcIiAmJiAoXG4gICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAge3F1ZXN0aW9uc0xvYWRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBweS02XCI+XG4gICAgICAgICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cImgtNCB3LTQgYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgR2VuZXJhdGluZyBxdWVzdGlvbnPigKZcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIEFuc3dlciB0aGVzZSBzbyB3ZSBjYW4gYnVpbGQgYSBwcmVjaXNlIHdvcmsgcGxhbi5cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICB7cXVlc3Rpb25zLm1hcCgocSwgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxMYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+e3F9PC9MYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YW5zd2Vyc1tpXSA/PyBcIlwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QW5zd2VycygocHJldikgPT4gKHsgLi4ucHJldiwgW2ldOiBlLnRhcmdldC52YWx1ZSB9KSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIllvdXIgYW5zd2Vy4oCmXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYmFja2dyb3VuZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAge3N0ZXAgPT09IFwicGxhblwiICYmIHBsYW4gJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+UmV2aWV3IHRoZSB3b3JrIHBsYW4sIHRoZW4gc3VibWl0IHRvIGFzc2lnbi48L3A+XG4gICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImxpc3QtZGlzYyBwbC01IHRleHQtc20gdGV4dC1mb3JlZ3JvdW5kLzkwIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAge3BsYW4uYnVsbGV0cy5tYXAoKGIsIGkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17aX0+e2J9PC9saT5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00IHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICB7cGxhbi5lc3RpbWF0ZWRDb3N0ICE9IG51bGwgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Fc3QuIGNvc3Q6ICR7cGxhbi5lc3RpbWF0ZWRDb3N0LnRvRml4ZWQoMil9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIHtwbGFuLmVzdGltYXRlZER1cmF0aW9uICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+RXN0LiBkdXJhdGlvbjoge3BsYW4uZXN0aW1hdGVkRHVyYXRpb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZGVzdHJ1Y3RpdmUgYmctZGVzdHJ1Y3RpdmUvMTAgcHgtMyBweS0yIHJvdW5kZWRcIj5cbiAgICAgICAgICAgICAgICB7ZXJyb3J9XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgPERpYWxvZ0Zvb3Rlcj5cbiAgICAgICAgICB7c3RlcCA9PT0gXCJxdWVzdGlvbnNcIiAmJiAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17b25DbG9zZX0+XG4gICAgICAgICAgICAgICAgQ2FuY2VsXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlTmV4dFRvUGxhbn1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17cXVlc3Rpb25zTG9hZGluZyB8fCBwbGFuTG9hZGluZyB8fCAhY2FuTmV4dH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtwbGFuTG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cImgtNCB3LTQgYW5pbWF0ZS1zcGluIG1yLTJcIiAvPlxuICAgICAgICAgICAgICAgICAgICBHZW5lcmF0aW5nIHBsYW7igKZcbiAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICBcIkdlbmVyYXRlIHBsYW5cIlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC8+XG4gICAgICAgICAgKX1cbiAgICAgICAgICB7c3RlcCA9PT0gXCJwbGFuXCIgJiYgKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9eygpID0+IHNldFN0ZXAoXCJxdWVzdGlvbnNcIil9PlxuICAgICAgICAgICAgICAgIEJhY2tcbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDxCdXR0b24gb25DbGljaz17aGFuZGxlU3VibWl0fSBkaXNhYmxlZD17c3VibWl0TG9hZGluZ30+XG4gICAgICAgICAgICAgICAge3N1Ym1pdExvYWRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJoLTQgdy00IGFuaW1hdGUtc3BpbiBtci0yXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgU3VibWl0dGluZ+KAplxuICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIFwiU3VibWl0IHBsYW4gJiBhc3NpZ25cIlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC8+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9EaWFsb2dGb290ZXI+XG4gICAgICA8L0RpYWxvZ0NvbnRlbnQ+XG4gICAgPC9EaWFsb2c+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9QbGFubmluZ01vZGFsLnRzeCJ9