import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/LiveFeed.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { cn } from "/src/lib/utils.ts";
import { Button } from "/src/components/ui/button.tsx";
import { Badge } from "/src/components/ui/badge.tsx";
import { ScrollArea } from "/src/components/ui/scroll-area.tsx";
import { CheckCircle2, X } from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
const FEED_PAGE_SIZE = 10;
export function LiveFeed({
  projectId,
  expanded,
  onToggle,
  onTaskSelect,
  onExecutionSelect
}) {
  _s();
  const [filter, setFilter] = useState("all");
  const [visibleCount, setVisibleCount] = useState(FEED_PAGE_SIZE);
  const activities = useQuery(api.activities.listRecent, projectId ? { projectId, limit: 80 } : { limit: 80 });
  const messages = useQuery(api.messages.listRecent, projectId ? { projectId, limit: 50 } : { limit: 50 });
  const agents = useQuery(api.agents.listAll, projectId ? { projectId } : {});
  const tasks = useQuery(api.tasks.listAll, projectId ? { projectId } : {});
  const totalCount = (activities?.length ?? 0) + (messages?.length ?? 0);
  useEffect(() => {
    setVisibleCount(FEED_PAGE_SIZE);
  }, [filter, projectId]);
  if (!expanded) {
    return /* @__PURE__ */ jsxDEV("aside", { className: "flex flex-col items-center py-3 border-l border-border bg-card w-12 shrink-0", children: /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: onToggle,
        className: "[writing-mode:vertical-lr] text-xs font-medium text-muted-foreground hover:text-foreground transition-colors cursor-pointer bg-transparent border-0 flex items-center gap-2",
        "aria-label": "Expand live activity feed",
        title: "Open live activity",
        children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Feed" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
            lineNumber: 70,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", className: "text-[10px] px-1 py-0", children: totalCount }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
            lineNumber: 71,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
        lineNumber: 63,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
      lineNumber: 62,
      columnNumber: 7
    }, this);
  }
  const agentMap = agents ? new Map(agents.map((a) => [a._id, a])) : /* @__PURE__ */ new Map();
  const taskMap = tasks ? new Map(tasks.map((t) => [t._id, t])) : /* @__PURE__ */ new Map();
  if (activities === void 0 || messages === void 0) {
    return /* @__PURE__ */ jsxDEV("aside", { className: "w-72 border-l border-border bg-card flex flex-col shrink-0", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 border-b border-border text-xs font-semibold uppercase tracking-wider text-foreground", children: "Live Feed" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
        lineNumber: 83,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 text-muted-foreground text-sm", children: "Loading..." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
        lineNumber: 86,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
      lineNumber: 82,
      columnNumber: 7
    }, this);
  }
  const taskActions = /* @__PURE__ */ new Set(["TASK_CREATED", "TASK_TRANSITION", "TASK_UPDATED"]);
  const statusActions = /* @__PURE__ */ new Set(["TASK_TRANSITION", "AGENT_PAUSED", "AGENT_STATUS_CHANGED"]);
  const decisionActions = /* @__PURE__ */ new Set(["APPROVAL_REQUESTED", "APPROVAL_APPROVED", "APPROVAL_DENIED"]);
  const isAgentExecutionAction = (action) => action.startsWith("WORKFLOW_") || action.startsWith("WORK_ORDER_DISPATCH") || action.startsWith("AGENT_EXECUTION") || action === "RUN_STARTED" || action === "RUN_COMPLETED" || action === "RUN_FAILED";
  const canonicalActivities = activities.filter((activity) => activity.action !== "MESSAGE_POSTED");
  const commentMessages = messages.filter((message) => message.type === "COMMENT");
  const countAll = canonicalActivities.length + commentMessages.length;
  const countTasks = canonicalActivities.filter((a) => taskActions.has(a.action)).length;
  const countComments = commentMessages.length;
  const countDecisions = canonicalActivities.filter((a) => decisionActions.has(a.action)).length;
  const countAgents = canonicalActivities.filter((a) => isAgentExecutionAction(a.action)).length;
  const countStatus = canonicalActivities.filter((a) => statusActions.has(a.action)).length;
  const filters = [
    { key: "all", label: "All", count: countAll },
    { key: "tasks", label: "Tasks", count: countTasks },
    { key: "comments", label: "Comments", count: countComments },
    { key: "decisions", label: "Decisions", count: countDecisions },
    { key: "agents", label: "Executions", count: countAgents },
    { key: "status", label: "Status", count: countStatus }
  ];
  const feedItems = [];
  for (const a of canonicalActivities) {
    const taskTitle = a.taskId ? taskMap.get(a.taskId)?.title : void 0;
    const author = a.actorType === "HUMAN" ? a.actorId ?? "Operator" : a.agentId ? agentMap.get(a.agentId)?.name ?? "Agent" : "System";
    const passes = filter === "all" || filter === "tasks" && taskActions.has(a.action) || filter === "status" && statusActions.has(a.action) || filter === "decisions" && decisionActions.has(a.action) || filter === "agents" && isAgentExecutionAction(a.action);
    if (passes) {
      const desc = (a.description || "").toLowerCase();
      const isCompleted = a.action === "TASK_TRANSITION" && (desc.includes("done") || a.afterState?.toStatus === "DONE");
      feedItems.push({
        type: "activity",
        id: a._id,
        ts: a._creationTime,
        author,
        text: isCompleted && taskTitle ? `Completed: ${taskTitle}` : a.description,
        taskId: a.taskId,
        taskTitle,
        action: a.action,
        targetType: a.targetType,
        isCompleted
      });
    }
  }
  for (const m of commentMessages) {
    const taskTitle = taskMap.get(m.taskId)?.title;
    const author = m.authorUserId ?? (m.authorAgentId ? agentMap.get(m.authorAgentId)?.name : null) ?? "Unknown";
    const passes = filter === "all" || filter === "comments";
    if (passes) {
      feedItems.push({
        type: "message",
        id: m._id,
        ts: m._creationTime,
        author,
        text: m.type === "COMMENT" ? m.content : `[${m.type}] ${m.content.slice(0, 80)}${m.content.length > 80 ? "..." : ""}`,
        taskId: m.taskId,
        taskTitle
      });
    }
  }
  feedItems.sort((a, b) => b.ts - a.ts);
  const displayed = feedItems.slice(0, visibleCount);
  const hiddenCount = Math.max(feedItems.length - displayed.length, 0);
  const hasMore = hiddenCount > 0;
  return /* @__PURE__ */ jsxDEV("aside", { className: "w-72 border-l border-border bg-card flex flex-col shrink-0", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between px-4 py-3 border-b border-border", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold uppercase tracking-wider text-foreground", children: "Live Activity" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
        lineNumber: 192,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: onToggle,
          className: "p-1 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors",
          "aria-label": "Collapse live activity feed",
          title: "Collapse live activity",
          children: /* @__PURE__ */ jsxDEV(X, { className: "h-4 w-4" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
            lineNumber: 200,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
          lineNumber: 193,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
      lineNumber: 191,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex shrink-0 gap-1 overflow-x-auto flex-nowrap px-3 py-2 border-b border-border", children: filters.map(
      (f) => /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setFilter(f.key),
          className: cn(
            "px-2 py-1 rounded-md text-xs transition-colors cursor-pointer border-0",
            filter === f.key ? "bg-primary text-primary-foreground" : "bg-transparent text-muted-foreground hover:bg-muted hover:text-foreground"
          ),
          children: [
            f.label,
            " ",
            f.count
          ]
        },
        f.key,
        true,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
          lineNumber: 207,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
      lineNumber: 205,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex shrink-0 gap-1 overflow-x-auto flex-nowrap px-3 py-2 border-b border-border", children: [
      /* @__PURE__ */ jsxDEV(Badge, { variant: "default", className: "text-xs cursor-pointer", children: "All Agents" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
        lineNumber: 225,
        columnNumber: 9
      }, this),
      agents && agents.slice(0, 8).map(
        (a) => /* @__PURE__ */ jsxDEV(Badge, { variant: "outline", className: "text-xs", children: [
          a.name,
          " ",
          activities.filter((ac) => ac.agentId === a._id).length
        ] }, a._id, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
          lineNumber: 227,
          columnNumber: 9
        }, this)
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
      lineNumber: 224,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(ScrollArea, { className: "flex-1 min-h-0", children: /* @__PURE__ */ jsxDEV("div", { className: "px-3 py-2", children: displayed.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "py-4 text-muted-foreground text-sm text-center", children: "No activity yet" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
      lineNumber: 237,
      columnNumber: 11
    }, this) : displayed.map((item) => {
      const hasExecutionTarget = item.targetType === "WORK_ORDER" || item.targetType === "WORKFLOW_RUN";
      return /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          disabled: (!item.taskId || !onTaskSelect) && (!hasExecutionTarget || !onExecutionSelect),
          onClick: () => {
            if (item.taskId) {
              onTaskSelect?.(item.taskId);
              return;
            }
            if (hasExecutionTarget) {
              onExecutionSelect?.();
            }
          },
          className: "block w-full border-0 border-b border-border bg-transparent py-2 text-left last:border-0 enabled:cursor-pointer enabled:hover:bg-muted/40 disabled:cursor-default",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-1.5 text-xs text-foreground", children: [
              item.isCompleted && /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-3.5 w-3.5 shrink-0 mt-0.5 text-emerald-500", "aria-hidden": true }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
                lineNumber: 263,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
                /* @__PURE__ */ jsxDEV("strong", { children: item.author }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
                  lineNumber: 266,
                  columnNumber: 21
                }, this),
                item.type === "message" ? " commented" : " · ",
                item.taskTitle && !item.isCompleted && /* @__PURE__ */ jsxDEV("span", { className: "text-muted-foreground", children: [
                  " on '",
                  item.taskTitle,
                  "'"
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
                  lineNumber: 269,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
                lineNumber: 265,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
              lineNumber: 261,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-muted-foreground mt-0.5 line-clamp-2", children: item.text }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
              lineNumber: 273,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-muted-foreground/60 mt-1", children: formatTime(item.ts) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
              lineNumber: 274,
              columnNumber: 17
            }, this)
          ]
        },
        `${item.type}:${item.id}`,
        true,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
          lineNumber: 243,
          columnNumber: 15
        },
        this
      );
    }) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
      lineNumber: 235,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
      lineNumber: 234,
      columnNumber: 7
    }, this),
    feedItems.length > FEED_PAGE_SIZE && /* @__PURE__ */ jsxDEV("div", { className: "px-3 py-2 border-t border-border shrink-0", children: hasMore ? /* @__PURE__ */ jsxDEV(
      Button,
      {
        variant: "ghost",
        size: "sm",
        className: "w-full text-xs",
        onClick: () => setVisibleCount((current) => Math.min(current + FEED_PAGE_SIZE, feedItems.length)),
        children: [
          "Load ",
          Math.min(FEED_PAGE_SIZE, hiddenCount),
          " more (",
          hiddenCount,
          " remaining)"
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
        lineNumber: 286,
        columnNumber: 9
      },
      this
    ) : /* @__PURE__ */ jsxDEV(
      Button,
      {
        variant: "ghost",
        size: "sm",
        className: "w-full text-xs",
        onClick: () => setVisibleCount(FEED_PAGE_SIZE),
        children: [
          "Show first ",
          FEED_PAGE_SIZE
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
        lineNumber: 295,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
      lineNumber: 284,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx",
    lineNumber: 189,
    columnNumber: 5
  }, this);
}
_s(LiveFeed, "WH3gXv5kfllG2/CA/uiEtyU7goo=", false, function() {
  return [useQuery, useQuery, useQuery, useQuery];
});
_c = LiveFeed;
function formatTime(ts) {
  const now = Date.now();
  const diff = now - ts;
  if (diff < 6e4) return "just now";
  if (diff < 36e5) return `${Math.floor(diff / 6e4)} min ago`;
  if (diff < 864e5) return `${Math.floor(diff / 36e5)} hours ago`;
  if (diff < 864e5 * 2) return "1 day ago";
  return new Date(ts).toLocaleDateString();
}
var _c;
$RefreshReg$(_c, "LiveFeed");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/LiveFeed.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0RVOzs7Ozs7Ozs7Ozs7Ozs7OztBQWxEVixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFdBQVc7QUFFcEIsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGNBQWNDLFNBQVM7QUFHaEMsTUFBTUMsaUJBQWlCO0FBVWhCLGdCQUFTQyxTQUFTO0FBQUEsRUFDdkJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ2EsR0FBRztBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJbEIsU0FBcUIsS0FBSztBQUN0RCxRQUFNLENBQUNtQixjQUFjQyxlQUFlLElBQUlwQixTQUFTUyxjQUFjO0FBQy9ELFFBQU1ZLGFBQWFwQixTQUFTQyxJQUFJbUIsV0FBV0MsWUFBWVgsWUFBWSxFQUFFQSxXQUFXWSxPQUFPLEdBQUcsSUFBSSxFQUFFQSxPQUFPLEdBQUcsQ0FBQztBQUMzRyxRQUFNQyxXQUFXdkIsU0FBU0MsSUFBSXNCLFNBQVNGLFlBQVlYLFlBQVksRUFBRUEsV0FBV1ksT0FBTyxHQUFHLElBQUksRUFBRUEsT0FBTyxHQUFHLENBQUM7QUFDdkcsUUFBTUUsU0FBU3hCLFNBQVNDLElBQUl1QixPQUFPQyxTQUFTZixZQUFZLEVBQUVBLFVBQVUsSUFBSSxDQUFDLENBQUM7QUFDMUUsUUFBTWdCLFFBQVExQixTQUFTQyxJQUFJeUIsTUFBTUQsU0FBU2YsWUFBWSxFQUFFQSxVQUFVLElBQUksQ0FBQyxDQUFDO0FBQ3hFLFFBQU1pQixjQUFjUCxZQUFZUSxVQUFVLE1BQU1MLFVBQVVLLFVBQVU7QUFFcEU5QixZQUFVLE1BQU07QUFDZHFCLG9CQUFnQlgsY0FBYztBQUFBLEVBQ2hDLEdBQUcsQ0FBQ1EsUUFBUU4sU0FBUyxDQUFDO0FBRXRCLE1BQUksQ0FBQ0MsVUFBVTtBQUNiLFdBQ0UsdUJBQUMsV0FBTSxXQUFVLGdGQUNmO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxTQUFTQztBQUFBQSxRQUNULFdBQVU7QUFBQSxRQUNWLGNBQVc7QUFBQSxRQUNYLE9BQU07QUFBQSxRQUVOO0FBQUEsaUNBQUMsVUFBSyxvQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFVO0FBQUEsVUFDVix1QkFBQyxTQUFNLFNBQVEsV0FBVSxXQUFVLHlCQUF5QmUsd0JBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVFO0FBQUE7QUFBQTtBQUFBLE1BUnpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsRUFFSjtBQUVBLFFBQU1FLFdBQVdMLFNBQVMsSUFBSU0sSUFBSU4sT0FBT08sSUFBSSxDQUFDQyxNQUFxQixDQUFDQSxFQUFFQyxLQUFLRCxDQUFDLENBQUMsQ0FBQyxJQUFJLG9CQUFJRixJQUFJO0FBQzFGLFFBQU1JLFVBQVVSLFFBQVEsSUFBSUksSUFBSUosTUFBTUssSUFBSSxDQUFDSSxNQUFvQixDQUFDQSxFQUFFRixLQUFLRSxDQUFDLENBQUMsQ0FBQyxJQUFJLG9CQUFJTCxJQUFJO0FBRXRGLE1BQUlWLGVBQWVnQixVQUFhYixhQUFhYSxRQUFXO0FBQ3RELFdBQ0UsdUJBQUMsV0FBTSxXQUFVLDhEQUNmO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG1HQUFpRyx5QkFBaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQW9DLDBCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZEO0FBQUEsU0FKL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsRUFFSjtBQUVBLFFBQU1DLGNBQWMsb0JBQUlDLElBQUksQ0FBQyxnQkFBZ0IsbUJBQW1CLGNBQWMsQ0FBQztBQUMvRSxRQUFNQyxnQkFBZ0Isb0JBQUlELElBQUksQ0FBQyxtQkFBbUIsZ0JBQWdCLHNCQUFzQixDQUFDO0FBQ3pGLFFBQU1FLGtCQUFrQixvQkFBSUYsSUFBSSxDQUFDLHNCQUFzQixxQkFBcUIsaUJBQWlCLENBQUM7QUFDOUYsUUFBTUcseUJBQXlCQSxDQUFDQyxXQUM5QkEsT0FBT0MsV0FBVyxXQUFXLEtBQzdCRCxPQUFPQyxXQUFXLHFCQUFxQixLQUN2Q0QsT0FBT0MsV0FBVyxpQkFBaUIsS0FDbkNELFdBQVcsaUJBQ1hBLFdBQVcsbUJBQ1hBLFdBQVc7QUFFYixRQUFNRSxzQkFBc0J4QixXQUFXSixPQUFPLENBQUM2QixhQUFhQSxTQUFTSCxXQUFXLGdCQUFnQjtBQUNoRyxRQUFNSSxrQkFBa0J2QixTQUFTUCxPQUFPLENBQUMrQixZQUFZQSxRQUFRQyxTQUFTLFNBQVM7QUFDL0UsUUFBTUMsV0FBV0wsb0JBQW9CaEIsU0FBU2tCLGdCQUFnQmxCO0FBQzlELFFBQU1zQixhQUFhTixvQkFBb0I1QixPQUFPLENBQUNnQixNQUFNSyxZQUFZYyxJQUFJbkIsRUFBRVUsTUFBTSxDQUFDLEVBQUVkO0FBQ2hGLFFBQU13QixnQkFBZ0JOLGdCQUFnQmxCO0FBQ3RDLFFBQU15QixpQkFBaUJULG9CQUFvQjVCLE9BQU8sQ0FBQ2dCLE1BQU1RLGdCQUFnQlcsSUFBSW5CLEVBQUVVLE1BQU0sQ0FBQyxFQUFFZDtBQUN4RixRQUFNMEIsY0FBY1Ysb0JBQW9CNUIsT0FBTyxDQUFDZ0IsTUFBTVMsdUJBQXVCVCxFQUFFVSxNQUFNLENBQUMsRUFBRWQ7QUFDeEYsUUFBTTJCLGNBQWNYLG9CQUFvQjVCLE9BQU8sQ0FBQ2dCLE1BQU1PLGNBQWNZLElBQUluQixFQUFFVSxNQUFNLENBQUMsRUFBRWQ7QUFFbkYsUUFBTTRCLFVBQStEO0FBQUEsSUFDbkUsRUFBRUMsS0FBSyxPQUFPQyxPQUFPLE9BQU9DLE9BQU9WLFNBQVM7QUFBQSxJQUM1QyxFQUFFUSxLQUFLLFNBQVNDLE9BQU8sU0FBU0MsT0FBT1QsV0FBVztBQUFBLElBQ2xELEVBQUVPLEtBQUssWUFBWUMsT0FBTyxZQUFZQyxPQUFPUCxjQUFjO0FBQUEsSUFDM0QsRUFBRUssS0FBSyxhQUFhQyxPQUFPLGFBQWFDLE9BQU9OLGVBQWU7QUFBQSxJQUM5RCxFQUFFSSxLQUFLLFVBQVVDLE9BQU8sY0FBY0MsT0FBT0wsWUFBWTtBQUFBLElBQ3pELEVBQUVHLEtBQUssVUFBVUMsT0FBTyxVQUFVQyxPQUFPSixZQUFZO0FBQUEsRUFBQztBQUd4RCxRQUFNSyxZQVdEO0FBRUwsYUFBVzVCLEtBQUtZLHFCQUFxQjtBQUNuQyxVQUFNaUIsWUFBWTdCLEVBQUU4QixTQUFTNUIsUUFBUTZCLElBQUkvQixFQUFFOEIsTUFBTSxHQUFHRSxRQUFRNUI7QUFDNUQsVUFBTTZCLFNBQ0pqQyxFQUFFa0MsY0FBYyxVQUNYbEMsRUFBRW1DLFdBQVcsYUFDZG5DLEVBQUVvQyxVQUNBdkMsU0FBU2tDLElBQUkvQixFQUFFb0MsT0FBTyxHQUFHQyxRQUFRLFVBQ2pDO0FBQ1IsVUFBTUMsU0FDSnRELFdBQVcsU0FDVkEsV0FBVyxXQUFXcUIsWUFBWWMsSUFBSW5CLEVBQUVVLE1BQU0sS0FDOUMxQixXQUFXLFlBQVl1QixjQUFjWSxJQUFJbkIsRUFBRVUsTUFBTSxLQUNqRDFCLFdBQVcsZUFBZXdCLGdCQUFnQlcsSUFBSW5CLEVBQUVVLE1BQU0sS0FDdEQxQixXQUFXLFlBQVl5Qix1QkFBdUJULEVBQUVVLE1BQU07QUFDekQsUUFBSTRCLFFBQVE7QUFDVixZQUFNQyxRQUFRdkMsRUFBRXdDLGVBQWUsSUFBSUMsWUFBWTtBQUMvQyxZQUFNQyxjQUNKMUMsRUFBRVUsV0FBVyxzQkFDWjZCLEtBQUtJLFNBQVMsTUFBTSxLQUFNM0MsRUFBNkM0QyxZQUFZQyxhQUFhO0FBQ25HakIsZ0JBQVVrQixLQUFLO0FBQUEsUUFDYjlCLE1BQU07QUFBQSxRQUNOK0IsSUFBSS9DLEVBQUVDO0FBQUFBLFFBQ04rQyxJQUFLaEQsRUFBZ0NpRDtBQUFBQSxRQUNyQ2hCO0FBQUFBLFFBQ0FpQixNQUFNUixlQUFlYixZQUFZLGNBQWNBLFNBQVMsS0FBSzdCLEVBQUV3QztBQUFBQSxRQUMvRFYsUUFBUTlCLEVBQUU4QjtBQUFBQSxRQUNWRDtBQUFBQSxRQUNBbkIsUUFBUVYsRUFBRVU7QUFBQUEsUUFDVnlDLFlBQVluRCxFQUFFbUQ7QUFBQUEsUUFDZFQ7QUFBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFDQSxhQUFXVSxLQUFLdEMsaUJBQWlCO0FBQy9CLFVBQU1lLFlBQVkzQixRQUFRNkIsSUFBSXFCLEVBQUV0QixNQUFNLEdBQUdFO0FBQ3pDLFVBQU1DLFNBQ0ptQixFQUFFQyxpQkFBaUJELEVBQUVFLGdCQUFnQnpELFNBQVNrQyxJQUFJcUIsRUFBRUUsYUFBYSxHQUFHakIsT0FBTyxTQUFTO0FBQ3RGLFVBQU1DLFNBQVN0RCxXQUFXLFNBQVNBLFdBQVc7QUFDOUMsUUFBSXNELFFBQVE7QUFDVlYsZ0JBQVVrQixLQUFLO0FBQUEsUUFDYjlCLE1BQU07QUFBQSxRQUNOK0IsSUFBSUssRUFBRW5EO0FBQUFBLFFBQ04rQyxJQUFLSSxFQUFnQ0g7QUFBQUEsUUFDckNoQjtBQUFBQSxRQUNBaUIsTUFBTUUsRUFBRXBDLFNBQVMsWUFBWW9DLEVBQUVHLFVBQVUsSUFBSUgsRUFBRXBDLElBQUksS0FBS29DLEVBQUVHLFFBQVFDLE1BQU0sR0FBRyxFQUFFLENBQUMsR0FBR0osRUFBRUcsUUFBUTNELFNBQVMsS0FBSyxRQUFRLEVBQUU7QUFBQSxRQUNuSGtDLFFBQVFzQixFQUFFdEI7QUFBQUEsUUFDVkQ7QUFBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFDQUQsWUFBVTZCLEtBQUssQ0FBQ3pELEdBQUcwRCxNQUFNQSxFQUFFVixLQUFLaEQsRUFBRWdELEVBQUU7QUFDcEMsUUFBTVcsWUFBWS9CLFVBQVU0QixNQUFNLEdBQUd0RSxZQUFZO0FBQ2pELFFBQU0wRSxjQUFjQyxLQUFLQyxJQUFJbEMsVUFBVWhDLFNBQVMrRCxVQUFVL0QsUUFBUSxDQUFDO0FBQ25FLFFBQU1tRSxVQUFVSCxjQUFjO0FBRTlCLFNBQ0UsdUJBQUMsV0FBTSxXQUFVLDhEQUVmO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHNFQUNiO0FBQUEsNkJBQUMsVUFBSyxXQUFVLGtFQUFpRSw2QkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RjtBQUFBLE1BQzlGO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUFTaEY7QUFBQUEsVUFDVCxXQUFVO0FBQUEsVUFDVixjQUFXO0FBQUEsVUFDWCxPQUFNO0FBQUEsVUFFTixpQ0FBQyxLQUFFLFdBQVUsYUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQjtBQUFBO0FBQUEsUUFQeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUE7QUFBQSxTQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLG9GQUNaNEMsa0JBQVF6QjtBQUFBQSxNQUFJLENBQUNpRSxNQUNaO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxNQUFLO0FBQUEsVUFDTCxTQUFTLE1BQU0vRSxVQUFVK0UsRUFBRXZDLEdBQUc7QUFBQSxVQUM5QixXQUFXdkQ7QUFBQUEsWUFDVDtBQUFBLFlBQ0FjLFdBQVdnRixFQUFFdkMsTUFDVCx1Q0FDQTtBQUFBLFVBQ047QUFBQSxVQUVDdUM7QUFBQUEsY0FBRXRDO0FBQUFBLFlBQU07QUFBQSxZQUFFc0MsRUFBRXJDO0FBQUFBO0FBQUFBO0FBQUFBLFFBVlJxQyxFQUFFdkM7QUFBQUEsUUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BWUE7QUFBQSxJQUNELEtBZkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLG9GQUNiO0FBQUEsNkJBQUMsU0FBTSxTQUFRLFdBQVUsV0FBVSwwQkFBeUIsMEJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0U7QUFBQSxNQUNyRWpDLFVBQVdBLE9BQTJCZ0UsTUFBTSxHQUFHLENBQUMsRUFBRXpEO0FBQUFBLFFBQUksQ0FBQ0MsTUFDdEQsdUJBQUMsU0FBa0IsU0FBUSxXQUFVLFdBQVUsV0FDNUNBO0FBQUFBLFlBQUVxQztBQUFBQSxVQUFLO0FBQUEsVUFBRWpELFdBQVdKLE9BQU8sQ0FBQ2lGLE9BQXNEQSxHQUFHN0IsWUFBWXBDLEVBQUVDLEdBQUcsRUFBRUw7QUFBQUEsYUFEL0ZJLEVBQUVDLEtBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsTUFDRDtBQUFBLFNBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFHQSx1QkFBQyxjQUFXLFdBQVUsa0JBQ3BCLGlDQUFDLFNBQUksV0FBVSxhQUNaMEQsb0JBQVUvRCxXQUFXLElBQ3BCLHVCQUFDLFNBQUksV0FBVSxrREFBaUQsK0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0UsSUFFL0UrRCxVQUFVNUQsSUFBSSxDQUFDbUUsU0FBUztBQUN0QixZQUFNQyxxQkFDSkQsS0FBS2YsZUFBZSxnQkFBZ0JlLEtBQUtmLGVBQWU7QUFDMUQsYUFDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUMsTUFBSztBQUFBLFVBQ0wsV0FDRyxDQUFDZSxLQUFLcEMsVUFBVSxDQUFDakQsa0JBQ2pCLENBQUNzRixzQkFBc0IsQ0FBQ3JGO0FBQUFBLFVBRTNCLFNBQVMsTUFBTTtBQUNiLGdCQUFJb0YsS0FBS3BDLFFBQVE7QUFDZmpELDZCQUFlcUYsS0FBS3BDLE1BQU07QUFDMUI7QUFBQSxZQUNGO0FBQ0EsZ0JBQUlxQyxvQkFBb0I7QUFDdEJyRixrQ0FBb0I7QUFBQSxZQUN0QjtBQUFBLFVBQ0Y7QUFBQSxVQUNBLFdBQVU7QUFBQSxVQUVaO0FBQUEsbUNBQUMsU0FBSSxXQUFVLG9EQUNab0Y7QUFBQUEsbUJBQUt4QixlQUNKLHVCQUFDLGdCQUFhLFdBQVUsZ0RBQStDLGVBQVcsUUFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0Y7QUFBQSxjQUVwRix1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSx1Q0FBQyxZQUFRd0IsZUFBS2pDLFVBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUI7QUFBQSxnQkFDcEJpQyxLQUFLbEQsU0FBUyxZQUFZLGVBQWU7QUFBQSxnQkFDekNrRCxLQUFLckMsYUFBYSxDQUFDcUMsS0FBS3hCLGVBQ3ZCLHVCQUFDLFVBQUssV0FBVSx5QkFBd0I7QUFBQTtBQUFBLGtCQUFXd0IsS0FBS3JDO0FBQUFBLGtCQUFVO0FBQUEscUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdFO0FBQUEsbUJBSjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUE7QUFBQSxpQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscURBQXFEcUMsZUFBS2hCLFFBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThFO0FBQUEsWUFDOUUsdUJBQUMsU0FBSSxXQUFVLDZDQUE2Q2tCLHFCQUFXRixLQUFLbEIsRUFBRSxLQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRjtBQUFBO0FBQUE7QUFBQSxRQTlCekUsR0FBR2tCLEtBQUtsRCxJQUFJLElBQUlrRCxLQUFLbkIsRUFBRTtBQUFBLFFBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFnQ0E7QUFBQSxJQUVKLENBQUMsS0ExQ0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRDQSxLQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOENBO0FBQUEsSUFHQ25CLFVBQVVoQyxTQUFTcEIsa0JBQ2xCLHVCQUFDLFNBQUksV0FBVSw2Q0FDWnVGLG9CQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFRO0FBQUEsUUFDUixNQUFLO0FBQUEsUUFDTCxXQUFVO0FBQUEsUUFDVixTQUFTLE1BQU01RSxnQkFBZ0IsQ0FBQ2tGLFlBQVlSLEtBQUtTLElBQUlELFVBQVU3RixnQkFBZ0JvRCxVQUFVaEMsTUFBTSxDQUFDO0FBQUEsUUFBRTtBQUFBO0FBQUEsVUFFNUZpRSxLQUFLUyxJQUFJOUYsZ0JBQWdCb0YsV0FBVztBQUFBLFVBQUU7QUFBQSxVQUFRQTtBQUFBQSxVQUFZO0FBQUE7QUFBQTtBQUFBLE1BTmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9BLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVE7QUFBQSxRQUNSLE1BQUs7QUFBQSxRQUNMLFdBQVU7QUFBQSxRQUNWLFNBQVMsTUFBTXpFLGdCQUFnQlgsY0FBYztBQUFBLFFBQUU7QUFBQTtBQUFBLFVBRW5DQTtBQUFBQTtBQUFBQTtBQUFBQSxNQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9BLEtBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxPQW5ISjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUhBO0FBRUo7QUFBQ08sR0EzUWVOLFVBQVE7QUFBQSxVQVNIVCxVQUNGQSxVQUNGQSxVQUNEQSxRQUFRO0FBQUE7QUFBQSxLQVpSUztBQTZRaEIsU0FBUzJGLFdBQVdwQixJQUFvQjtBQUN0QyxRQUFNdUIsTUFBTUMsS0FBS0QsSUFBSTtBQUNyQixRQUFNRSxPQUFPRixNQUFNdkI7QUFDbkIsTUFBSXlCLE9BQU8sSUFBUSxRQUFPO0FBQzFCLE1BQUlBLE9BQU8sS0FBVSxRQUFPLEdBQUdaLEtBQUthLE1BQU1ELE9BQU8sR0FBTSxDQUFDO0FBQ3hELE1BQUlBLE9BQU8sTUFBVyxRQUFPLEdBQUdaLEtBQUthLE1BQU1ELE9BQU8sSUFBUSxDQUFDO0FBQzNELE1BQUlBLE9BQU8sUUFBWSxFQUFHLFFBQU87QUFDakMsU0FBTyxJQUFJRCxLQUFLeEIsRUFBRSxFQUFFMkIsbUJBQW1CO0FBQ3pDO0FBQUMsSUFBQUM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VRdWVyeSIsImFwaSIsImNuIiwiQnV0dG9uIiwiQmFkZ2UiLCJTY3JvbGxBcmVhIiwiQ2hlY2tDaXJjbGUyIiwiWCIsIkZFRURfUEFHRV9TSVpFIiwiTGl2ZUZlZWQiLCJwcm9qZWN0SWQiLCJleHBhbmRlZCIsIm9uVG9nZ2xlIiwib25UYXNrU2VsZWN0Iiwib25FeGVjdXRpb25TZWxlY3QiLCJfcyIsImZpbHRlciIsInNldEZpbHRlciIsInZpc2libGVDb3VudCIsInNldFZpc2libGVDb3VudCIsImFjdGl2aXRpZXMiLCJsaXN0UmVjZW50IiwibGltaXQiLCJtZXNzYWdlcyIsImFnZW50cyIsImxpc3RBbGwiLCJ0YXNrcyIsInRvdGFsQ291bnQiLCJsZW5ndGgiLCJhZ2VudE1hcCIsIk1hcCIsIm1hcCIsImEiLCJfaWQiLCJ0YXNrTWFwIiwidCIsInVuZGVmaW5lZCIsInRhc2tBY3Rpb25zIiwiU2V0Iiwic3RhdHVzQWN0aW9ucyIsImRlY2lzaW9uQWN0aW9ucyIsImlzQWdlbnRFeGVjdXRpb25BY3Rpb24iLCJhY3Rpb24iLCJzdGFydHNXaXRoIiwiY2Fub25pY2FsQWN0aXZpdGllcyIsImFjdGl2aXR5IiwiY29tbWVudE1lc3NhZ2VzIiwibWVzc2FnZSIsInR5cGUiLCJjb3VudEFsbCIsImNvdW50VGFza3MiLCJoYXMiLCJjb3VudENvbW1lbnRzIiwiY291bnREZWNpc2lvbnMiLCJjb3VudEFnZW50cyIsImNvdW50U3RhdHVzIiwiZmlsdGVycyIsImtleSIsImxhYmVsIiwiY291bnQiLCJmZWVkSXRlbXMiLCJ0YXNrVGl0bGUiLCJ0YXNrSWQiLCJnZXQiLCJ0aXRsZSIsImF1dGhvciIsImFjdG9yVHlwZSIsImFjdG9ySWQiLCJhZ2VudElkIiwibmFtZSIsInBhc3NlcyIsImRlc2MiLCJkZXNjcmlwdGlvbiIsInRvTG93ZXJDYXNlIiwiaXNDb21wbGV0ZWQiLCJpbmNsdWRlcyIsImFmdGVyU3RhdGUiLCJ0b1N0YXR1cyIsInB1c2giLCJpZCIsInRzIiwiX2NyZWF0aW9uVGltZSIsInRleHQiLCJ0YXJnZXRUeXBlIiwibSIsImF1dGhvclVzZXJJZCIsImF1dGhvckFnZW50SWQiLCJjb250ZW50Iiwic2xpY2UiLCJzb3J0IiwiYiIsImRpc3BsYXllZCIsImhpZGRlbkNvdW50IiwiTWF0aCIsIm1heCIsImhhc01vcmUiLCJmIiwiYWMiLCJpdGVtIiwiaGFzRXhlY3V0aW9uVGFyZ2V0IiwiZm9ybWF0VGltZSIsImN1cnJlbnQiLCJtaW4iLCJub3ciLCJEYXRlIiwiZGlmZiIsImZsb29yIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTGl2ZUZlZWQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5IH0gZnJvbSBcImNvbnZleC9yZWFjdFwiO1xuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2FwaVwiO1xuaW1wb3J0IHR5cGUgeyBEb2MsIElkIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQgeyBCYWRnZSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYmFkZ2VcIjtcbmltcG9ydCB7IFNjcm9sbEFyZWEgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL3Njcm9sbC1hcmVhXCI7XG5pbXBvcnQgeyBDaGVja0NpcmNsZTIsIFggfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5cbnR5cGUgRmVlZEZpbHRlciA9IFwiYWxsXCIgfCBcInRhc2tzXCIgfCBcImNvbW1lbnRzXCIgfCBcImRlY2lzaW9uc1wiIHwgXCJhZ2VudHNcIiB8IFwic3RhdHVzXCI7XG5jb25zdCBGRUVEX1BBR0VfU0laRSA9IDEwO1xuXG5pbnRlcmZhY2UgTGl2ZUZlZWRQcm9wcyB7XG4gIHByb2plY3RJZDogSWQ8XCJwcm9qZWN0c1wiPiB8IG51bGw7XG4gIGV4cGFuZGVkOiBib29sZWFuO1xuICBvblRvZ2dsZTogKCkgPT4gdm9pZDtcbiAgb25UYXNrU2VsZWN0PzogKHRhc2tJZDogSWQ8XCJ0YXNrc1wiPikgPT4gdm9pZDtcbiAgb25FeGVjdXRpb25TZWxlY3Q/OiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gTGl2ZUZlZWQoe1xuICBwcm9qZWN0SWQsXG4gIGV4cGFuZGVkLFxuICBvblRvZ2dsZSxcbiAgb25UYXNrU2VsZWN0LFxuICBvbkV4ZWN1dGlvblNlbGVjdCxcbn06IExpdmVGZWVkUHJvcHMpIHtcbiAgY29uc3QgW2ZpbHRlciwgc2V0RmlsdGVyXSA9IHVzZVN0YXRlPEZlZWRGaWx0ZXI+KFwiYWxsXCIpO1xuICBjb25zdCBbdmlzaWJsZUNvdW50LCBzZXRWaXNpYmxlQ291bnRdID0gdXNlU3RhdGUoRkVFRF9QQUdFX1NJWkUpO1xuICBjb25zdCBhY3Rpdml0aWVzID0gdXNlUXVlcnkoYXBpLmFjdGl2aXRpZXMubGlzdFJlY2VudCwgcHJvamVjdElkID8geyBwcm9qZWN0SWQsIGxpbWl0OiA4MCB9IDogeyBsaW1pdDogODAgfSk7XG4gIGNvbnN0IG1lc3NhZ2VzID0gdXNlUXVlcnkoYXBpLm1lc3NhZ2VzLmxpc3RSZWNlbnQsIHByb2plY3RJZCA/IHsgcHJvamVjdElkLCBsaW1pdDogNTAgfSA6IHsgbGltaXQ6IDUwIH0pO1xuICBjb25zdCBhZ2VudHMgPSB1c2VRdWVyeShhcGkuYWdlbnRzLmxpc3RBbGwsIHByb2plY3RJZCA/IHsgcHJvamVjdElkIH0gOiB7fSk7XG4gIGNvbnN0IHRhc2tzID0gdXNlUXVlcnkoYXBpLnRhc2tzLmxpc3RBbGwsIHByb2plY3RJZCA/IHsgcHJvamVjdElkIH0gOiB7fSk7XG4gIGNvbnN0IHRvdGFsQ291bnQgPSAoYWN0aXZpdGllcz8ubGVuZ3RoID8/IDApICsgKG1lc3NhZ2VzPy5sZW5ndGggPz8gMCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXRWaXNpYmxlQ291bnQoRkVFRF9QQUdFX1NJWkUpO1xuICB9LCBbZmlsdGVyLCBwcm9qZWN0SWRdKTtcblxuICBpZiAoIWV4cGFuZGVkKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBweS0zIGJvcmRlci1sIGJvcmRlci1ib3JkZXIgYmctY2FyZCB3LTEyIHNocmluay0wXCI+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBvbkNsaWNrPXtvblRvZ2dsZX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJbd3JpdGluZy1tb2RlOnZlcnRpY2FsLWxyXSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBob3Zlcjp0ZXh0LWZvcmVncm91bmQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgYmctdHJhbnNwYXJlbnQgYm9yZGVyLTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIlxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJFeHBhbmQgbGl2ZSBhY3Rpdml0eSBmZWVkXCJcbiAgICAgICAgICB0aXRsZT1cIk9wZW4gbGl2ZSBhY3Rpdml0eVwiXG4gICAgICAgID5cbiAgICAgICAgICA8c3Bhbj5GZWVkPC9zcGFuPlxuICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwib3V0bGluZVwiIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHB4LTEgcHktMFwiPnt0b3RhbENvdW50fTwvQmFkZ2U+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9hc2lkZT5cbiAgICApO1xuICB9XG5cbiAgY29uc3QgYWdlbnRNYXAgPSBhZ2VudHMgPyBuZXcgTWFwKGFnZW50cy5tYXAoKGE6IERvYzxcImFnZW50c1wiPikgPT4gW2EuX2lkLCBhXSkpIDogbmV3IE1hcCgpO1xuICBjb25zdCB0YXNrTWFwID0gdGFza3MgPyBuZXcgTWFwKHRhc2tzLm1hcCgodDogRG9jPFwidGFza3NcIj4pID0+IFt0Ll9pZCwgdF0pKSA6IG5ldyBNYXAoKTtcblxuICBpZiAoYWN0aXZpdGllcyA9PT0gdW5kZWZpbmVkIHx8IG1lc3NhZ2VzID09PSB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cInctNzIgYm9yZGVyLWwgYm9yZGVyLWJvcmRlciBiZy1jYXJkIGZsZXggZmxleC1jb2wgc2hyaW5rLTBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC00IHB5LTMgYm9yZGVyLWIgYm9yZGVyLWJvcmRlciB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgIExpdmUgRmVlZFxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIHRleHQtc21cIj5Mb2FkaW5nLi4uPC9kaXY+XG4gICAgICA8L2FzaWRlPlxuICAgICk7XG4gIH1cblxuICBjb25zdCB0YXNrQWN0aW9ucyA9IG5ldyBTZXQoW1wiVEFTS19DUkVBVEVEXCIsIFwiVEFTS19UUkFOU0lUSU9OXCIsIFwiVEFTS19VUERBVEVEXCJdKTtcbiAgY29uc3Qgc3RhdHVzQWN0aW9ucyA9IG5ldyBTZXQoW1wiVEFTS19UUkFOU0lUSU9OXCIsIFwiQUdFTlRfUEFVU0VEXCIsIFwiQUdFTlRfU1RBVFVTX0NIQU5HRURcIl0pO1xuICBjb25zdCBkZWNpc2lvbkFjdGlvbnMgPSBuZXcgU2V0KFtcIkFQUFJPVkFMX1JFUVVFU1RFRFwiLCBcIkFQUFJPVkFMX0FQUFJPVkVEXCIsIFwiQVBQUk9WQUxfREVOSUVEXCJdKTtcbiAgY29uc3QgaXNBZ2VudEV4ZWN1dGlvbkFjdGlvbiA9IChhY3Rpb246IHN0cmluZykgPT5cbiAgICBhY3Rpb24uc3RhcnRzV2l0aChcIldPUktGTE9XX1wiKSB8fFxuICAgIGFjdGlvbi5zdGFydHNXaXRoKFwiV09SS19PUkRFUl9ESVNQQVRDSFwiKSB8fFxuICAgIGFjdGlvbi5zdGFydHNXaXRoKFwiQUdFTlRfRVhFQ1VUSU9OXCIpIHx8XG4gICAgYWN0aW9uID09PSBcIlJVTl9TVEFSVEVEXCIgfHxcbiAgICBhY3Rpb24gPT09IFwiUlVOX0NPTVBMRVRFRFwiIHx8XG4gICAgYWN0aW9uID09PSBcIlJVTl9GQUlMRURcIjtcblxuICBjb25zdCBjYW5vbmljYWxBY3Rpdml0aWVzID0gYWN0aXZpdGllcy5maWx0ZXIoKGFjdGl2aXR5KSA9PiBhY3Rpdml0eS5hY3Rpb24gIT09IFwiTUVTU0FHRV9QT1NURURcIik7XG4gIGNvbnN0IGNvbW1lbnRNZXNzYWdlcyA9IG1lc3NhZ2VzLmZpbHRlcigobWVzc2FnZSkgPT4gbWVzc2FnZS50eXBlID09PSBcIkNPTU1FTlRcIik7XG4gIGNvbnN0IGNvdW50QWxsID0gY2Fub25pY2FsQWN0aXZpdGllcy5sZW5ndGggKyBjb21tZW50TWVzc2FnZXMubGVuZ3RoO1xuICBjb25zdCBjb3VudFRhc2tzID0gY2Fub25pY2FsQWN0aXZpdGllcy5maWx0ZXIoKGEpID0+IHRhc2tBY3Rpb25zLmhhcyhhLmFjdGlvbikpLmxlbmd0aDtcbiAgY29uc3QgY291bnRDb21tZW50cyA9IGNvbW1lbnRNZXNzYWdlcy5sZW5ndGg7XG4gIGNvbnN0IGNvdW50RGVjaXNpb25zID0gY2Fub25pY2FsQWN0aXZpdGllcy5maWx0ZXIoKGEpID0+IGRlY2lzaW9uQWN0aW9ucy5oYXMoYS5hY3Rpb24pKS5sZW5ndGg7XG4gIGNvbnN0IGNvdW50QWdlbnRzID0gY2Fub25pY2FsQWN0aXZpdGllcy5maWx0ZXIoKGEpID0+IGlzQWdlbnRFeGVjdXRpb25BY3Rpb24oYS5hY3Rpb24pKS5sZW5ndGg7XG4gIGNvbnN0IGNvdW50U3RhdHVzID0gY2Fub25pY2FsQWN0aXZpdGllcy5maWx0ZXIoKGEpID0+IHN0YXR1c0FjdGlvbnMuaGFzKGEuYWN0aW9uKSkubGVuZ3RoO1xuXG4gIGNvbnN0IGZpbHRlcnM6IHsga2V5OiBGZWVkRmlsdGVyOyBsYWJlbDogc3RyaW5nOyBjb3VudDogbnVtYmVyIH1bXSA9IFtcbiAgICB7IGtleTogXCJhbGxcIiwgbGFiZWw6IFwiQWxsXCIsIGNvdW50OiBjb3VudEFsbCB9LFxuICAgIHsga2V5OiBcInRhc2tzXCIsIGxhYmVsOiBcIlRhc2tzXCIsIGNvdW50OiBjb3VudFRhc2tzIH0sXG4gICAgeyBrZXk6IFwiY29tbWVudHNcIiwgbGFiZWw6IFwiQ29tbWVudHNcIiwgY291bnQ6IGNvdW50Q29tbWVudHMgfSxcbiAgICB7IGtleTogXCJkZWNpc2lvbnNcIiwgbGFiZWw6IFwiRGVjaXNpb25zXCIsIGNvdW50OiBjb3VudERlY2lzaW9ucyB9LFxuICAgIHsga2V5OiBcImFnZW50c1wiLCBsYWJlbDogXCJFeGVjdXRpb25zXCIsIGNvdW50OiBjb3VudEFnZW50cyB9LFxuICAgIHsga2V5OiBcInN0YXR1c1wiLCBsYWJlbDogXCJTdGF0dXNcIiwgY291bnQ6IGNvdW50U3RhdHVzIH0sXG4gIF07XG5cbiAgY29uc3QgZmVlZEl0ZW1zOiBBcnJheTx7XG4gICAgdHlwZTogXCJhY3Rpdml0eVwiIHwgXCJtZXNzYWdlXCI7XG4gICAgaWQ6IHN0cmluZztcbiAgICB0czogbnVtYmVyO1xuICAgIGF1dGhvcjogc3RyaW5nO1xuICAgIHRleHQ6IHN0cmluZztcbiAgICB0YXNrSWQ/OiBJZDxcInRhc2tzXCI+O1xuICAgIHRhc2tUaXRsZT86IHN0cmluZztcbiAgICBhY3Rpb24/OiBzdHJpbmc7XG4gICAgdGFyZ2V0VHlwZT86IHN0cmluZztcbiAgICBpc0NvbXBsZXRlZD86IGJvb2xlYW47XG4gIH0+ID0gW107XG5cbiAgZm9yIChjb25zdCBhIG9mIGNhbm9uaWNhbEFjdGl2aXRpZXMpIHtcbiAgICBjb25zdCB0YXNrVGl0bGUgPSBhLnRhc2tJZCA/IHRhc2tNYXAuZ2V0KGEudGFza0lkKT8udGl0bGUgOiB1bmRlZmluZWQ7XG4gICAgY29uc3QgYXV0aG9yID1cbiAgICAgIGEuYWN0b3JUeXBlID09PSBcIkhVTUFOXCJcbiAgICAgICAgPyAoYS5hY3RvcklkID8/IFwiT3BlcmF0b3JcIilcbiAgICAgICAgOiBhLmFnZW50SWRcbiAgICAgICAgICA/IGFnZW50TWFwLmdldChhLmFnZW50SWQpPy5uYW1lID8/IFwiQWdlbnRcIlxuICAgICAgICAgIDogXCJTeXN0ZW1cIjtcbiAgICBjb25zdCBwYXNzZXMgPVxuICAgICAgZmlsdGVyID09PSBcImFsbFwiIHx8XG4gICAgICAoZmlsdGVyID09PSBcInRhc2tzXCIgJiYgdGFza0FjdGlvbnMuaGFzKGEuYWN0aW9uKSkgfHxcbiAgICAgIChmaWx0ZXIgPT09IFwic3RhdHVzXCIgJiYgc3RhdHVzQWN0aW9ucy5oYXMoYS5hY3Rpb24pKSB8fFxuICAgICAgKGZpbHRlciA9PT0gXCJkZWNpc2lvbnNcIiAmJiBkZWNpc2lvbkFjdGlvbnMuaGFzKGEuYWN0aW9uKSkgfHxcbiAgICAgIChmaWx0ZXIgPT09IFwiYWdlbnRzXCIgJiYgaXNBZ2VudEV4ZWN1dGlvbkFjdGlvbihhLmFjdGlvbikpO1xuICAgIGlmIChwYXNzZXMpIHtcbiAgICAgIGNvbnN0IGRlc2MgPSAoYS5kZXNjcmlwdGlvbiB8fCBcIlwiKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgY29uc3QgaXNDb21wbGV0ZWQgPVxuICAgICAgICBhLmFjdGlvbiA9PT0gXCJUQVNLX1RSQU5TSVRJT05cIiAmJlxuICAgICAgICAoZGVzYy5pbmNsdWRlcyhcImRvbmVcIikgfHwgKGEgYXMgeyBhZnRlclN0YXRlPzogeyB0b1N0YXR1cz86IHN0cmluZyB9IH0pLmFmdGVyU3RhdGU/LnRvU3RhdHVzID09PSBcIkRPTkVcIik7XG4gICAgICBmZWVkSXRlbXMucHVzaCh7XG4gICAgICAgIHR5cGU6IFwiYWN0aXZpdHlcIixcbiAgICAgICAgaWQ6IGEuX2lkLFxuICAgICAgICB0czogKGEgYXMgeyBfY3JlYXRpb25UaW1lOiBudW1iZXIgfSkuX2NyZWF0aW9uVGltZSxcbiAgICAgICAgYXV0aG9yLFxuICAgICAgICB0ZXh0OiBpc0NvbXBsZXRlZCAmJiB0YXNrVGl0bGUgPyBgQ29tcGxldGVkOiAke3Rhc2tUaXRsZX1gIDogYS5kZXNjcmlwdGlvbixcbiAgICAgICAgdGFza0lkOiBhLnRhc2tJZCxcbiAgICAgICAgdGFza1RpdGxlLFxuICAgICAgICBhY3Rpb246IGEuYWN0aW9uLFxuICAgICAgICB0YXJnZXRUeXBlOiBhLnRhcmdldFR5cGUsXG4gICAgICAgIGlzQ29tcGxldGVkLFxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIGZvciAoY29uc3QgbSBvZiBjb21tZW50TWVzc2FnZXMpIHtcbiAgICBjb25zdCB0YXNrVGl0bGUgPSB0YXNrTWFwLmdldChtLnRhc2tJZCk/LnRpdGxlO1xuICAgIGNvbnN0IGF1dGhvciA9XG4gICAgICBtLmF1dGhvclVzZXJJZCA/PyAobS5hdXRob3JBZ2VudElkID8gYWdlbnRNYXAuZ2V0KG0uYXV0aG9yQWdlbnRJZCk/Lm5hbWUgOiBudWxsKSA/PyBcIlVua25vd25cIjtcbiAgICBjb25zdCBwYXNzZXMgPSBmaWx0ZXIgPT09IFwiYWxsXCIgfHwgZmlsdGVyID09PSBcImNvbW1lbnRzXCI7XG4gICAgaWYgKHBhc3Nlcykge1xuICAgICAgZmVlZEl0ZW1zLnB1c2goe1xuICAgICAgICB0eXBlOiBcIm1lc3NhZ2VcIixcbiAgICAgICAgaWQ6IG0uX2lkLFxuICAgICAgICB0czogKG0gYXMgeyBfY3JlYXRpb25UaW1lOiBudW1iZXIgfSkuX2NyZWF0aW9uVGltZSxcbiAgICAgICAgYXV0aG9yLFxuICAgICAgICB0ZXh0OiBtLnR5cGUgPT09IFwiQ09NTUVOVFwiID8gbS5jb250ZW50IDogYFske20udHlwZX1dICR7bS5jb250ZW50LnNsaWNlKDAsIDgwKX0ke20uY29udGVudC5sZW5ndGggPiA4MCA/IFwiLi4uXCIgOiBcIlwifWAsXG4gICAgICAgIHRhc2tJZDogbS50YXNrSWQsXG4gICAgICAgIHRhc2tUaXRsZSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBmZWVkSXRlbXMuc29ydCgoYSwgYikgPT4gYi50cyAtIGEudHMpO1xuICBjb25zdCBkaXNwbGF5ZWQgPSBmZWVkSXRlbXMuc2xpY2UoMCwgdmlzaWJsZUNvdW50KTtcbiAgY29uc3QgaGlkZGVuQ291bnQgPSBNYXRoLm1heChmZWVkSXRlbXMubGVuZ3RoIC0gZGlzcGxheWVkLmxlbmd0aCwgMCk7XG4gIGNvbnN0IGhhc01vcmUgPSBoaWRkZW5Db3VudCA+IDA7XG5cbiAgcmV0dXJuIChcbiAgICA8YXNpZGUgY2xhc3NOYW1lPVwidy03MiBib3JkZXItbCBib3JkZXItYm9yZGVyIGJnLWNhcmQgZmxleCBmbGV4LWNvbCBzaHJpbmstMFwiPlxuICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTQgcHktMyBib3JkZXItYiBib3JkZXItYm9yZGVyXCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1mb3JlZ3JvdW5kXCI+TGl2ZSBBY3Rpdml0eTwvc3Bhbj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIG9uQ2xpY2s9e29uVG9nZ2xlfVxuICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSByb3VuZGVkLW1kIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBob3Zlcjp0ZXh0LWZvcmVncm91bmQgaG92ZXI6YmctbXV0ZWQgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJDb2xsYXBzZSBsaXZlIGFjdGl2aXR5IGZlZWRcIlxuICAgICAgICAgIHRpdGxlPVwiQ29sbGFwc2UgbGl2ZSBhY3Rpdml0eVwiXG4gICAgICAgID5cbiAgICAgICAgICA8WCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEZpbHRlcnMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggc2hyaW5rLTAgZ2FwLTEgb3ZlcmZsb3cteC1hdXRvIGZsZXgtbm93cmFwIHB4LTMgcHktMiBib3JkZXItYiBib3JkZXItYm9yZGVyXCI+XG4gICAgICAgIHtmaWx0ZXJzLm1hcCgoZikgPT4gKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIGtleT17Zi5rZXl9XG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZpbHRlcihmLmtleSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICBcInB4LTIgcHktMSByb3VuZGVkLW1kIHRleHQteHMgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgYm9yZGVyLTBcIixcbiAgICAgICAgICAgICAgZmlsdGVyID09PSBmLmtleVxuICAgICAgICAgICAgICAgID8gXCJiZy1wcmltYXJ5IHRleHQtcHJpbWFyeS1mb3JlZ3JvdW5kXCJcbiAgICAgICAgICAgICAgICA6IFwiYmctdHJhbnNwYXJlbnQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGhvdmVyOmJnLW11dGVkIGhvdmVyOnRleHQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICApfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtmLmxhYmVsfSB7Zi5jb3VudH1cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEFnZW50IGNoaXBzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNocmluay0wIGdhcC0xIG92ZXJmbG93LXgtYXV0byBmbGV4LW5vd3JhcCBweC0zIHB5LTIgYm9yZGVyLWIgYm9yZGVyLWJvcmRlclwiPlxuICAgICAgICA8QmFkZ2UgdmFyaWFudD1cImRlZmF1bHRcIiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGN1cnNvci1wb2ludGVyXCI+QWxsIEFnZW50czwvQmFkZ2U+XG4gICAgICAgIHthZ2VudHMgJiYgKGFnZW50cyBhcyBEb2M8XCJhZ2VudHNcIj5bXSkuc2xpY2UoMCwgOCkubWFwKChhKSA9PiAoXG4gICAgICAgICAgPEJhZGdlIGtleT17YS5faWR9IHZhcmlhbnQ9XCJvdXRsaW5lXCIgY2xhc3NOYW1lPVwidGV4dC14c1wiPlxuICAgICAgICAgICAge2EubmFtZX0ge2FjdGl2aXRpZXMuZmlsdGVyKChhYzogRG9jPFwiYWN0aXZpdGllc1wiPiAmIHsgX2NyZWF0aW9uVGltZTogbnVtYmVyIH0pID0+IGFjLmFnZW50SWQgPT09IGEuX2lkKS5sZW5ndGh9XG4gICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEZlZWQgaXRlbXMgKi99XG4gICAgICA8U2Nyb2xsQXJlYSBjbGFzc05hbWU9XCJmbGV4LTEgbWluLWgtMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTMgcHktMlwiPlxuICAgICAgICAgIHtkaXNwbGF5ZWQubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS00IHRleHQtbXV0ZWQtZm9yZWdyb3VuZCB0ZXh0LXNtIHRleHQtY2VudGVyXCI+Tm8gYWN0aXZpdHkgeWV0PC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIGRpc3BsYXllZC5tYXAoKGl0ZW0pID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgaGFzRXhlY3V0aW9uVGFyZ2V0ID1cbiAgICAgICAgICAgICAgICBpdGVtLnRhcmdldFR5cGUgPT09IFwiV09SS19PUkRFUlwiIHx8IGl0ZW0udGFyZ2V0VHlwZSA9PT0gXCJXT1JLRkxPV19SVU5cIjtcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e2Ake2l0ZW0udHlwZX06JHtpdGVtLmlkfWB9XG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtcbiAgICAgICAgICAgICAgICAgICAgKCFpdGVtLnRhc2tJZCB8fCAhb25UYXNrU2VsZWN0KSAmJlxuICAgICAgICAgICAgICAgICAgICAoIWhhc0V4ZWN1dGlvblRhcmdldCB8fCAhb25FeGVjdXRpb25TZWxlY3QpXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpdGVtLnRhc2tJZCkge1xuICAgICAgICAgICAgICAgICAgICAgIG9uVGFza1NlbGVjdD8uKGl0ZW0udGFza0lkKTtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKGhhc0V4ZWN1dGlvblRhcmdldCkge1xuICAgICAgICAgICAgICAgICAgICAgIG9uRXhlY3V0aW9uU2VsZWN0Py4oKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCBib3JkZXItMCBib3JkZXItYiBib3JkZXItYm9yZGVyIGJnLXRyYW5zcGFyZW50IHB5LTIgdGV4dC1sZWZ0IGxhc3Q6Ym9yZGVyLTAgZW5hYmxlZDpjdXJzb3ItcG9pbnRlciBlbmFibGVkOmhvdmVyOmJnLW11dGVkLzQwIGRpc2FibGVkOmN1cnNvci1kZWZhdWx0XCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0xLjUgdGV4dC14cyB0ZXh0LWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgIHtpdGVtLmlzQ29tcGxldGVkICYmIChcbiAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSBzaHJpbmstMCBtdC0wLjUgdGV4dC1lbWVyYWxkLTUwMFwiIGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPntpdGVtLmF1dGhvcn08L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAge2l0ZW0udHlwZSA9PT0gXCJtZXNzYWdlXCIgPyBcIiBjb21tZW50ZWRcIiA6IFwiIMK3IFwifVxuICAgICAgICAgICAgICAgICAgICB7aXRlbS50YXNrVGl0bGUgJiYgIWl0ZW0uaXNDb21wbGV0ZWQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPiBvbiAmYXBvczt7aXRlbS50YXNrVGl0bGV9JmFwb3M7PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtdC0wLjUgbGluZS1jbGFtcC0yXCI+e2l0ZW0udGV4dH08L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtbXV0ZWQtZm9yZWdyb3VuZC82MCBtdC0xXCI+e2Zvcm1hdFRpbWUoaXRlbS50cyl9PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9TY3JvbGxBcmVhPlxuXG4gICAgICB7LyogUGFnaW5hdGlvbiAqL31cbiAgICAgIHtmZWVkSXRlbXMubGVuZ3RoID4gRkVFRF9QQUdFX1NJWkUgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTMgcHktMiBib3JkZXItdCBib3JkZXItYm9yZGVyIHNocmluay0wXCI+XG4gICAgICAgICAge2hhc01vcmUgPyAoXG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VmlzaWJsZUNvdW50KChjdXJyZW50KSA9PiBNYXRoLm1pbihjdXJyZW50ICsgRkVFRF9QQUdFX1NJWkUsIGZlZWRJdGVtcy5sZW5ndGgpKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgTG9hZCB7TWF0aC5taW4oRkVFRF9QQUdFX1NJWkUsIGhpZGRlbkNvdW50KX0gbW9yZSAoe2hpZGRlbkNvdW50fSByZW1haW5pbmcpXG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC14c1wiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpc2libGVDb3VudChGRUVEX1BBR0VfU0laRSl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIFNob3cgZmlyc3Qge0ZFRURfUEFHRV9TSVpFfVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvYXNpZGU+XG4gICk7XG59XG5cbmZ1bmN0aW9uIGZvcm1hdFRpbWUodHM6IG51bWJlcik6IHN0cmluZyB7XG4gIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gIGNvbnN0IGRpZmYgPSBub3cgLSB0cztcbiAgaWYgKGRpZmYgPCA2MF8wMDApIHJldHVybiBcImp1c3Qgbm93XCI7XG4gIGlmIChkaWZmIDwgMzYwMF8wMDApIHJldHVybiBgJHtNYXRoLmZsb29yKGRpZmYgLyA2MF8wMDApfSBtaW4gYWdvYDtcbiAgaWYgKGRpZmYgPCA4NjQwMF8wMDApIHJldHVybiBgJHtNYXRoLmZsb29yKGRpZmYgLyAzNjAwXzAwMCl9IGhvdXJzIGFnb2A7XG4gIGlmIChkaWZmIDwgODY0MDBfMDAwICogMikgcmV0dXJuIFwiMSBkYXkgYWdvXCI7XG4gIHJldHVybiBuZXcgRGF0ZSh0cykudG9Mb2NhbGVEYXRlU3RyaW5nKCk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9MaXZlRmVlZC50c3gifQ==