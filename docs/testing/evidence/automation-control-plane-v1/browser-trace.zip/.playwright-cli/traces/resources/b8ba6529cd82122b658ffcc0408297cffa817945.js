import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/TaskDrawerTabs.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$();
import { useMutation, useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useEffect = __vite__cjsImport5_react["useEffect"]; const useState = __vite__cjsImport5_react["useState"];
import { cn } from "/src/lib/utils.ts";
import { Button } from "/src/components/ui/button.tsx";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "/src/components/ui/dropdown-menu.tsx";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle
} from "/src/components/ui/sheet.tsx";
import { PeerReviewPanel } from "/src/PeerReviewPanel.tsx";
import { ExportReportButton } from "/src/ExportReportButton.tsx";
import { TaskEditMode } from "/src/TaskEditMode.tsx";
import { RiskBadge, StatusBadge } from "/src/components/factory/badges.tsx";
import { VerificationTracePanel } from "/src/components/tasks/VerificationTracePanel.tsx";
import { buildVerificationTrace } from "/src/lib/verificationTrace.ts";
function taskStatusTone(status) {
  switch (status) {
    case "DONE":
      return "success";
    case "IN_PROGRESS":
    case "REVIEW":
      return "info";
    case "NEEDS_APPROVAL":
    case "BLOCKED":
      return "warning";
    case "FAILED":
      return "error";
    default:
      return "neutral";
  }
}
function approvalStatusTone(status) {
  switch (status) {
    case "APPROVED":
      return "success";
    case "DENIED":
    case "EXPIRED":
      return "error";
    case "PENDING":
    case "ESCALATED":
      return "warning";
    default:
      return "neutral";
  }
}
function formatStatusLabel(status) {
  return status.replace(/_/g, " ");
}
export function TaskDrawerTabs({
  taskId,
  onClose
}) {
  _s();
  const [activeTab, setActiveTab] = useState("overview");
  const [isEditMode, setIsEditMode] = useState(false);
  const [comment, setComment] = useState("");
  const [loading, setLoading] = useState(false);
  const data = useQuery(api.tasks.getWithTimeline, taskId ? { taskId } : "skip");
  const agents = useQuery(
    api.agents.listAll,
    data?.task.projectId ? { projectId: data.task.projectId } : {}
  );
  const watchSubscriptions = useQuery(
    api.watchSubscriptions.listByUser,
    taskId ? { userId: "operator", entityType: "TASK" } : "skip"
  );
  const postMessage = useMutation(api.messages.post);
  const transitionTask = useMutation(api.tasks.transition);
  const updateTask = useMutation(api.tasks.update);
  const toggleWatch = useMutation(api.watchSubscriptions.toggle);
  const requestApproval = useMutation(api.approvals.request);
  if (!taskId) return null;
  const isLoading = data === void 0 || agents === void 0;
  return /* @__PURE__ */ jsxDEV(Sheet, { open: !!taskId, onOpenChange: (open) => {
    if (!open) onClose();
  }, children: /* @__PURE__ */ jsxDEV(SheetContent, { side: "right", className: "w-[600px] max-w-[90vw] p-0 flex flex-col bg-surface-1 border-l border-line", children: [
    /* @__PURE__ */ jsxDEV(SheetHeader, { className: "sr-only", children: [
      /* @__PURE__ */ jsxDEV(SheetTitle, { children: data?.task.title ?? "Task details" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 130,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(SheetDescription, { children: "Review task status, evidence, approvals, activity, and available actions." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 131,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 129,
      columnNumber: 9
    }, this),
    isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "p-6 text-sm text-ink-muted", children: "Loading..." }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 136,
      columnNumber: 9
    }, this) : !data ? /* @__PURE__ */ jsxDEV("div", { className: "p-6 text-sm text-ink-muted", children: "Task not found" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 138,
      columnNumber: 9
    }, this) : (() => {
      const { task, transitions, messages, runs, toolCalls, approvals, activities, taskEvents } = data;
      const agentMap = new Map(
        agents.map((a) => [a._id, a])
      );
      const isWatchingTask = !!watchSubscriptions?.some((subscription) => subscription.entityId === taskId);
      const handlePostComment = async () => {
        if (!comment.trim()) return;
        setLoading(true);
        try {
          await postMessage({
            taskId,
            authorType: "HUMAN",
            authorUserId: "operator",
            type: "COMMENT",
            content: comment,
            idempotencyKey: `comment:${taskId}:${Date.now()}`
          });
          setComment("");
        } catch (e) {
          console.error(e);
        }
        setLoading(false);
      };
      const handleTransition = async (toStatus) => {
        setLoading(true);
        try {
          const result = await transitionTask({
            taskId,
            toStatus,
            actorType: "HUMAN",
            actorUserId: "operator",
            idempotencyKey: `transition:${taskId}:${toStatus}:${Date.now()}`,
            reason: "Manual transition from UI"
          });
          if (!result.success && result.errors) {
            alert(result.errors.map((e) => e.message).join("\n"));
          }
        } catch (e) {
          console.error(e);
        }
        setLoading(false);
      };
      return /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-4 border-b border-line", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-0", children: [
              task.identifier && /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-mono text-ink-muted mb-0.5 block", children: task.identifier }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
                lineNumber: 193,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "h2",
                {
                  "aria-hidden": "true",
                  className: "text-base font-semibold leading-snug",
                  children: task.title
                },
                void 0,
                false,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
                  lineNumber: 195,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 191,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 mt-2 flex-wrap items-center", children: [
              /* @__PURE__ */ jsxDEV(StatusBadge, { tone: taskStatusTone(task.status), children: formatStatusLabel(task.status) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
                lineNumber: 203,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", children: [
                "P",
                task.priority
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
                lineNumber: 206,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", children: task.type }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
                lineNumber: 207,
                columnNumber: 23
              }, this),
              task.source && (() => {
                const src = SOURCE_CONFIG[task.source] || SOURCE_CONFIG.UNKNOWN;
                return /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    className: "text-[11.5px] text-ink-muted",
                    title: task.sourceRef ? `${src.label}: ${task.sourceRef}` : src.label,
                    children: src.label
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
                    lineNumber: 211,
                    columnNumber: 27
                  },
                  this
                );
              })()
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 202,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 190,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 items-center shrink-0", children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                variant: isWatchingTask ? "default" : "outline",
                size: "sm",
                onClick: async () => {
                  await toggleWatch({
                    userId: "operator",
                    projectId: task.projectId ?? void 0,
                    entityType: "TASK",
                    entityId: taskId
                  });
                },
                children: isWatchingTask ? "Watching" : "Watch"
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
                lineNumber: 222,
                columnNumber: 21
              },
              this
            ),
            !isEditMode && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Button, { size: "sm", onClick: () => setIsEditMode(true), children: "Edit" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
                lineNumber: 238,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(ExportReportButton, { taskId }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
                lineNumber: 241,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 237,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 221,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 189,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 188,
          columnNumber: 15
        }, this),
        isEditMode ? /* @__PURE__ */ jsxDEV(
          TaskEditMode,
          {
            task,
            onSave: () => setIsEditMode(false),
            onCancel: () => setIsEditMode(false)
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 249,
            columnNumber: 15
          },
          this
        ) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex border-b border-line px-5", role: "tablist", children: ["overview", "timeline", "artifacts", "approvals", "cost", "reviews", "why"].map(
            (tab) => /* @__PURE__ */ jsxDEV(
              TabButton,
              {
                active: activeTab === tab,
                onClick: () => setActiveTab(tab),
                children: tab === "approvals" && approvals.length > 0 ? `Approvals (${approvals.length})` : tab === "why" ? "Why?" : tab.charAt(0).toUpperCase() + tab.slice(1)
              },
              tab,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
                lineNumber: 259,
                columnNumber: 19
              },
              this
            )
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 257,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-auto p-5", children: [
            activeTab === "overview" && /* @__PURE__ */ jsxDEV(
              OverviewTab,
              {
                taskId,
                task,
                runs,
                approvals,
                agents,
                agentMap,
                onTransition: handleTransition,
                loading,
                postMessage,
                updateTask,
                requestApproval,
                setLoading
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
                lineNumber: 276,
                columnNumber: 19
              },
              this
            ),
            activeTab === "timeline" && /* @__PURE__ */ jsxDEV(
              TimelineTab,
              {
                taskEvents,
                transitions,
                messages,
                runs,
                toolCalls,
                approvals,
                activities,
                agentMap
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
                lineNumber: 292,
                columnNumber: 19
              },
              this
            ),
            activeTab === "artifacts" && /* @__PURE__ */ jsxDEV(ArtifactsTab, { task, messages }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 304,
              columnNumber: 19
            }, this),
            activeTab === "reviews" && /* @__PURE__ */ jsxDEV(PeerReviewPanel, { taskId, projectId: task.projectId }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 307,
              columnNumber: 19
            }, this),
            activeTab === "approvals" && /* @__PURE__ */ jsxDEV(ApprovalsTab, { approvals, agentMap }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 310,
              columnNumber: 19
            }, this),
            activeTab === "cost" && /* @__PURE__ */ jsxDEV(CostTab, { task, runs }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 313,
              columnNumber: 19
            }, this),
            activeTab === "why" && /* @__PURE__ */ jsxDEV(WhyTab, { task, agentMap, transitions }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 316,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 274,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-5 border-t border-line", children: [
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                value: comment,
                onChange: (e) => setComment(e.target.value),
                placeholder: "Add a comment...",
                rows: 3,
                className: "w-full p-3 bg-surface-1 border border-line rounded-md text-sm text-ink placeholder:text-ink-muted resize-y focus:outline-none focus:ring-2 focus:ring-ring"
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
                lineNumber: 322,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "sm",
                onClick: handlePostComment,
                disabled: loading || !comment.trim(),
                className: "mt-2",
                children: loading ? "Posting..." : "Post comment"
              },
              void 0,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
                lineNumber: 329,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 321,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 255,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 186,
        columnNumber: 13
      }, this);
    })()
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
    lineNumber: 128,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
    lineNumber: 127,
    columnNumber: 5
  }, this);
}
_s(TaskDrawerTabs, "7MfJZfh+04mIFVigRumjyr3Pn1Q=", false, function() {
  return [useQuery, useQuery, useQuery, useMutation, useMutation, useMutation, useMutation, useMutation];
});
_c = TaskDrawerTabs;
function OverviewTab({
  taskId,
  task,
  runs,
  approvals,
  agents,
  agentMap,
  onTransition,
  loading,
  postMessage,
  updateTask,
  requestApproval,
  setLoading
}) {
  const verificationTrace = buildVerificationTrace(task, runs, approvals);
  const approved = approvals.some((approval) => approval.status === "APPROVED");
  const pendingApproval = approvals.some(
    (approval) => ["PENDING", "ESCALATED"].includes(approval.status)
  );
  const handleRequestApproval = async () => {
    const requestorAgentId = task.assigneeIds[0];
    if (!requestorAgentId) {
      window.alert("Assign an agent before requesting approval.");
      return;
    }
    setLoading(true);
    try {
      await requestApproval({
        projectId: task.projectId,
        taskId,
        requestorAgentId,
        actionType: "TASK_COMPLETION",
        actionSummary: `Approve completion of ${task.identifier ?? task.title}`,
        riskLevel: "YELLOW",
        justification: task.deliverable?.summary ?? "Task deliverable is ready for an explicit operator decision.",
        expiresInMinutes: 120,
        idempotencyKey: `task-review:${taskId}:${task.reviewCycles}`
      });
    } catch (error) {
      window.alert(error instanceof Error ? error.message : "Unable to request approval.");
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV(VerificationTracePanel, { trace: verificationTrace }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 432,
      columnNumber: 7
    }, this),
    task.description && /* @__PURE__ */ jsxDEV(Section, { title: "Description", children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-ink-secondary leading-relaxed", children: task.description }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 436,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 435,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Assignees", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 flex-wrap items-center", children: [
      task.assigneeIds.length > 0 ? task.assigneeIds.map((id) => {
        const agent = agentMap.get(id);
        return agent ? /* @__PURE__ */ jsxDEV(AgentChip, { agent }, id, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 446,
          columnNumber: 13
        }, this) : null;
      }) : /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-ink-muted", children: "Unassigned" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 450,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        ReassignDropdown,
        {
          taskId,
          currentAssigneeIds: task.assigneeIds,
          agents,
          updateTask,
          setLoading
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 452,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 441,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 440,
      columnNumber: 7
    }, this),
    task.dueAt != null && /* @__PURE__ */ jsxDEV(Section, { title: "Due Date", children: /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center gap-2 rounded-md border border-line bg-surface-2 px-3 py-2 text-sm", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-ink", children: new Date(task.dueAt).toLocaleDateString(void 0, {
        weekday: "short",
        month: "short",
        day: "numeric",
        year: "numeric"
      }) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 465,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(
        "span",
        {
          className: cn(
            "text-xs",
            task.dueAt < Date.now() ? "text-err" : task.dueAt < Date.now() + 864e5 * 2 ? "text-warn" : "text-ink-muted"
          ),
          children: task.dueAt < Date.now() ? "Overdue" : task.dueAt < Date.now() + 864e5 * 2 ? "Due soon" : "Scheduled"
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 473,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 464,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 463,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Source", children: /* @__PURE__ */ jsxDEV(SourceBadge, { source: task.source, sourceRef: task.sourceRef, createdBy: task.createdBy }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 494,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 493,
      columnNumber: 7
    }, this),
    task.planningQa && task.planningQa.length > 0 && /* @__PURE__ */ jsxDEV(Section, { title: "Planning Q&A", children: /* @__PURE__ */ jsxDEV("dl", { className: "space-y-2 text-sm", children: task.planningQa.map(
      (qa, i) => /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("dt", { className: "font-medium text-ink", children: qa.question }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 502,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "text-ink-secondary pl-2 mt-0.5", children: qa.answer }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 503,
          columnNumber: 17
        }, this)
      ] }, i, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 501,
        columnNumber: 11
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 499,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 498,
      columnNumber: 7
    }, this),
    task.workPlan && /* @__PURE__ */ jsxDEV(Section, { title: "Work Plan", children: [
      /* @__PURE__ */ jsxDEV("ul", { className: "list-disc pl-5 text-sm text-ink-secondary space-y-1.5", children: task.workPlan.bullets.map(
        (bullet, i) => /* @__PURE__ */ jsxDEV("li", { children: bullet }, i, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 514,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 512,
        columnNumber: 11
      }, this),
      task.workPlan.estimatedCost && /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-xs text-ink-muted", children: [
        "Estimated: $",
        task.workPlan.estimatedCost.toFixed(2)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 518,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 511,
      columnNumber: 7
    }, this),
    task.deliverable && /* @__PURE__ */ jsxDEV(Section, { title: "Deliverable", children: [
      task.deliverable.summary && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-ink-secondary mb-2", children: task.deliverable.summary }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 528,
        columnNumber: 9
      }, this),
      task.deliverable.artifactIds && task.deliverable.artifactIds.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1.5 flex-wrap", children: task.deliverable.artifactIds.map(
        (id) => /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", className: "font-mono", children: id }, id, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 533,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 531,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 526,
      columnNumber: 7
    }, this),
    task.blockedReason && /* @__PURE__ */ jsxDEV(Section, { title: "Blocked Reason", children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-err", children: task.blockedReason }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 542,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 541,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Redirect", children: /* @__PURE__ */ jsxDEV(
      RedirectForm,
      {
        taskId,
        postMessage,
        loading,
        setLoading
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 547,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 546,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Quick Actions", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 flex-wrap", children: [
      task.status === "INBOX" && /* @__PURE__ */ jsxDEV(Button, { size: "sm", onClick: () => onTransition("ASSIGNED"), disabled: loading, children: "Assign" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 558,
        columnNumber: 11
      }, this),
      task.status === "REVIEW" && approved && /* @__PURE__ */ jsxDEV(Button, { size: "sm", onClick: () => onTransition("DONE"), disabled: loading, children: "Accept and mark done" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 563,
        columnNumber: 11
      }, this),
      task.status === "REVIEW" && !approved && !pendingApproval && /* @__PURE__ */ jsxDEV(Button, { size: "sm", onClick: handleRequestApproval, disabled: loading, children: "Request approval" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 568,
        columnNumber: 11
      }, this),
      task.status === "REVIEW" && pendingApproval && /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "outline", disabled: true, children: "Awaiting approval" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 573,
        columnNumber: 11
      }, this),
      task.status === "BLOCKED" && /* @__PURE__ */ jsxDEV(Button, { size: "sm", onClick: () => onTransition("IN_PROGRESS"), disabled: loading, children: "Unblock" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 578,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 556,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 555,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
    lineNumber: 431,
    columnNumber: 5
  }, this);
}
_c2 = OverviewTab;
function ReassignDropdown({
  taskId,
  currentAssigneeIds,
  agents,
  updateTask,
  setLoading
}) {
  _s2();
  const [selectedIds, setSelectedIds] = useState(currentAssigneeIds);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    setSelectedIds(currentAssigneeIds);
  }, [currentAssigneeIds]);
  const handleReassign = async (nextIds) => {
    setSelectedIds(nextIds);
    setLoading(true);
    try {
      await updateTask({ taskId, assigneeIds: nextIds });
      setOpen(false);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(DropdownMenu, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsxDEV(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(Button, { variant: "outline", size: "sm", children: "Reassign..." }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 624,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 623,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(DropdownMenuContent, { align: "start", className: "w-56 max-h-[280px] overflow-y-auto", children: [
      /* @__PURE__ */ jsxDEV(DropdownMenuLabel, { children: "Assign to" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 629,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DropdownMenuSeparator, {}, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 630,
        columnNumber: 9
      }, this),
      agents.map(
        (agent) => /* @__PURE__ */ jsxDEV(
          DropdownMenuCheckboxItem,
          {
            checked: selectedIds.includes(agent._id),
            onCheckedChange: () => {
              const nextIds = selectedIds.includes(agent._id) ? selectedIds.filter((candidate) => candidate !== agent._id) : [...selectedIds, agent._id];
              void handleReassign(nextIds);
            },
            children: /* @__PURE__ */ jsxDEV("span", { children: agent.name }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 642,
              columnNumber: 13
            }, this)
          },
          agent._id,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 632,
            columnNumber: 9
          },
          this
        )
      ),
      /* @__PURE__ */ jsxDEV(DropdownMenuSeparator, {}, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 645,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        DropdownMenuItem,
        {
          onSelect: () => void handleReassign([]),
          children: "Clear assignees"
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 646,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 628,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
    lineNumber: 622,
    columnNumber: 5
  }, this);
}
_s2(ReassignDropdown, "n1NY4uQtu4v9e9feGF+MTC/0TY0=");
_c3 = ReassignDropdown;
function RedirectForm({
  taskId,
  postMessage,
  loading,
  setLoading
}) {
  _s3();
  const [redirectText, setRedirectText] = useState("");
  const handleRedirect = async () => {
    if (!redirectText.trim()) return;
    setLoading(true);
    try {
      await postMessage({
        taskId,
        authorType: "HUMAN",
        authorUserId: "operator",
        type: "COMMENT",
        content: `Redirect: ${redirectText.trim()}`,
        idempotencyKey: `redirect:${taskId}:${Date.now()}`
      });
      setRedirectText("");
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        type: "text",
        value: redirectText,
        onChange: (event) => setRedirectText(event.target.value),
        placeholder: "Instruction for the agent...",
        className: "flex-1 min-w-0 px-3 py-2 rounded-md border border-line bg-surface-1 text-sm text-ink placeholder:text-ink-muted focus:outline-none focus:ring-2 focus:ring-ring"
      },
      void 0,
      false,
      {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 698,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Button, { size: "sm", onClick: handleRedirect, disabled: loading || !redirectText.trim(), children: "Send redirect" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 705,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
    lineNumber: 697,
    columnNumber: 5
  }, this);
}
_s3(RedirectForm, "8NV3PonWsgwXfO414z/TGYGEri8=");
_c4 = RedirectForm;
function AgentChip({ agent }) {
  return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-2.5 py-1 bg-surface-2 rounded-md text-xs text-ink", children: [
    /* @__PURE__ */ jsxDEV("span", { children: agent.name }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 715,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("span", { className: "text-ink-muted", children: agent.role }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 716,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
    lineNumber: 714,
    columnNumber: 5
  }, this);
}
_c5 = AgentChip;
const TIMELINE_ENTRY_CLASS = "relative border-b border-line pb-3 pl-4 last:border-b-0 before:absolute before:left-0 before:top-[7px] before:h-1.5 before:w-1.5 before:rounded-full before:bg-ink-muted";
function TimelineTab({
  taskEvents,
  transitions,
  messages,
  runs,
  toolCalls,
  approvals,
  activities,
  agentMap
}) {
  const items = [];
  if (taskEvents.length > 0) {
    for (const event of taskEvents) {
      items.push({ type: "taskEvent", ts: event.timestamp, data: event });
    }
  } else {
    for (const t of transitions) items.push({ type: "transition", ts: t._creationTime, data: t });
    for (const m of messages) items.push({ type: "message", ts: m._creationTime, data: m });
    for (const r of runs) items.push({ type: "run", ts: r.startedAt, data: r });
    for (const tc of toolCalls) items.push({ type: "toolCall", ts: tc.startedAt, data: tc });
    for (const a of approvals) items.push({ type: "approval", ts: a._creationTime, data: a });
    for (const activity of activities) items.push({ type: "activity", ts: activity._creationTime, data: activity });
  }
  items.sort((a, b) => a.ts - b.ts);
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: items.map(
    (item, i) => /* @__PURE__ */ jsxDEV(TimelineItem, { item, agentMap }, i, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 772,
      columnNumber: 7
    }, this)
  ) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
    lineNumber: 770,
    columnNumber: 5
  }, this);
}
_c6 = TimelineTab;
function TimelineItem({
  item,
  agentMap
}) {
  const time = new Date(item.ts).toLocaleTimeString();
  const formatActorName = (actorType, actorId) => {
    if (actorType === "AGENT" && actorId) {
      const maybeAgent = agentMap.get(actorId);
      if (maybeAgent) return maybeAgent.name;
    }
    if (actorType === "HUMAN") return actorId || "Human";
    if (actorType === "SYSTEM") return "System";
    return actorId || "Unknown";
  };
  switch (item.type) {
    case "taskEvent": {
      const event = item.data;
      const actor = formatActorName(event.actorType, event.actorId);
      return /* @__PURE__ */ jsxDEV("div", { className: TIMELINE_ENTRY_CLASS, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted", children: time }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 803,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-sm text-ink", children: formatStatusLabel(event.eventType) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 804,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted mt-0.5", children: [
          "Actor: ",
          actor
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 807,
          columnNumber: 11
        }, this),
        event.beforeState && event.afterState && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-secondary mt-1", children: [
          JSON.stringify(event.beforeState),
          " → ",
          JSON.stringify(event.afterState)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 809,
          columnNumber: 13
        }, this),
        event.metadata && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted mt-1", children: JSON.stringify(event.metadata) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 814,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 802,
        columnNumber: 11
      }, this);
    }
    case "transition": {
      const t = item.data;
      const actor = formatActorName(t.actorType, t.actorUserId || t.actorAgentId);
      return /* @__PURE__ */ jsxDEV("div", { className: TIMELINE_ENTRY_CLASS, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted", children: time }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 827,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-ink", children: [
          t.fromStatus,
          " → ",
          t.toStatus,
          " · ",
          actor
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 828,
          columnNumber: 11
        }, this),
        t.reason && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted mt-0.5", children: t.reason }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 831,
          columnNumber: 24
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 826,
        columnNumber: 11
      }, this);
    }
    case "message": {
      const m = item.data;
      const author = m.authorUserId || (m.authorAgentId ? agentMap.get(m.authorAgentId)?.name : null) || "Unknown";
      return /* @__PURE__ */ jsxDEV("div", { className: TIMELINE_ENTRY_CLASS, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted", children: time }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 841,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-ink", children: [
          author,
          " · ",
          m.type
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 842,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-secondary whitespace-pre-wrap mt-0.5", children: [
          m.content.slice(0, 200),
          m.content.length > 200 ? "..." : ""
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 843,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 840,
        columnNumber: 11
      }, this);
    }
    case "run": {
      const r = item.data;
      const agent = agentMap.get(r.agentId);
      const duration = r.durationMs ? `${(r.durationMs / 1e3).toFixed(1)}s` : "running";
      return /* @__PURE__ */ jsxDEV("div", { className: TIMELINE_ENTRY_CLASS, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted", children: time }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 856,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-ink", children: [
          "Run by ",
          agent?.name || "Agent",
          " · ",
          r.status
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 857,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted mt-0.5", children: [
          r.model,
          " · ",
          duration,
          " · Δ $",
          r.costUsd.toFixed(3)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 860,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 855,
        columnNumber: 11
      }, this);
    }
    case "toolCall": {
      const tc = item.data;
      const agent = agentMap.get(tc.agentId);
      return /* @__PURE__ */ jsxDEV("div", { className: TIMELINE_ENTRY_CLASS, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted", children: time }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 872,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-ink", children: [
          agent?.name || "Agent",
          " · ",
          tc.toolName
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 873,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted mt-0.5", children: [
          /* @__PURE__ */ jsxDEV(RiskBadge, { level: tc.riskLevel }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 877,
            columnNumber: 13
          }, this),
          " · ",
          tc.status,
          tc.inputPreview && ` · ${tc.inputPreview.slice(0, 50)}...`
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 876,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 871,
        columnNumber: 11
      }, this);
    }
    case "approval": {
      const a = item.data;
      const agent = agentMap.get(a.requestorAgentId);
      return /* @__PURE__ */ jsxDEV("div", { className: TIMELINE_ENTRY_CLASS, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted", children: time }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 889,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-ink", children: [
          "Approval · ",
          /* @__PURE__ */ jsxDEV(StatusBadge, { tone: approvalStatusTone(a.status), children: formatStatusLabel(a.status) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 891,
            columnNumber: 24
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 890,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted mt-0.5", children: [
          a.actionSummary,
          " · ",
          agent?.name || "Agent"
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 893,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 888,
        columnNumber: 11
      }, this);
    }
    case "activity": {
      const activity = item.data;
      const actor = formatActorName(activity.actorType, activity.actorId);
      return /* @__PURE__ */ jsxDEV("div", { className: TIMELINE_ENTRY_CLASS, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted", children: time }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 905,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-ink", children: [
          "Audit · ",
          activity.action,
          " · ",
          actor
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 906,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted whitespace-pre-wrap mt-0.5", children: activity.description }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 909,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 904,
        columnNumber: 11
      }, this);
    }
    default:
      return null;
  }
}
_c7 = TimelineItem;
function ArtifactsTab({
  task,
  messages
}) {
  const artifactMessages = messages.filter((m) => m.type === "ARTIFACT" || m.artifacts);
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
    task.deliverable && /* @__PURE__ */ jsxDEV(Section, { title: "Deliverable", children: [
      task.deliverable.summary && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-ink-secondary mb-3", children: task.deliverable.summary }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 939,
        columnNumber: 9
      }, this),
      task.deliverable.artifactIds && task.deliverable.artifactIds.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 flex-wrap", children: task.deliverable.artifactIds.map(
        (id) => /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", className: "font-mono", children: id }, id, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 944,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 942,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 937,
      columnNumber: 7
    }, this),
    artifactMessages.length > 0 && /* @__PURE__ */ jsxDEV(Section, { title: "Artifact Messages", children: artifactMessages.map(
      (m) => /* @__PURE__ */ jsxDEV("div", { className: "mb-4 p-3 bg-surface-2 border border-line rounded-md", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted mb-1.5", children: new Date(m._creationTime).toLocaleString() }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 955,
          columnNumber: 15
        }, this),
        m.artifacts && m.artifacts.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1.5 flex-wrap mt-2", children: m.artifacts.map(
          (a, i) => /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", children: a.name }, i, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 961,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 959,
          columnNumber: 11
        }, this)
      ] }, m._id, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 954,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 952,
      columnNumber: 7
    }, this),
    !task.deliverable && artifactMessages.length === 0 && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-ink-muted", children: "No artifacts yet" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 971,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
    lineNumber: 935,
    columnNumber: 5
  }, this);
}
_c8 = ArtifactsTab;
function ApprovalsTab({
  approvals,
  agentMap
}) {
  _s4();
  const approve = useMutation(api.approvals.approve);
  const deny = useMutation(api.approvals.deny);
  const [decisionReasons, setDecisionReasons] = useState({});
  const [busyApprovalId, setBusyApprovalId] = useState(null);
  if (approvals.length === 0) {
    return /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-ink-muted", children: "No approvals for this task" }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 994,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: approvals.map((a) => {
    const agent = agentMap.get(a.requestorAgentId);
    return /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-surface-2 border border-line rounded-md", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between mb-2", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-ink-muted", children: [
          agent?.name || "Agent",
          " · ",
          a.actionType,
          " · ",
          /* @__PURE__ */ jsxDEV(RiskBadge, { level: a.riskLevel }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 1005,
            columnNumber: 61
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1004,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(StatusBadge, { tone: approvalStatusTone(a.status), children: formatStatusLabel(a.status) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1007,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1003,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-ink mb-1.5", children: a.actionSummary }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1009,
        columnNumber: 13
      }, this),
      a.justification && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted mb-2", children: a.justification }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1011,
        columnNumber: 13
      }, this),
      a.decisionReason && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-secondary pt-2 border-t border-line", children: [
        /* @__PURE__ */ jsxDEV("strong", { children: "Decision:" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1015,
          columnNumber: 17
        }, this),
        " ",
        a.decisionReason
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1014,
        columnNumber: 13
      }, this),
      ["PENDING", "ESCALATED"].includes(a.status) && /* @__PURE__ */ jsxDEV("div", { className: "mt-3 space-y-2 border-t border-line pt-3", children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            value: decisionReasons[a._id] ?? "",
            onChange: (event) => setDecisionReasons((current) => ({
              ...current,
              [a._id]: event.target.value
            })),
            placeholder: "Decision reason (required)",
            "aria-label": `Decision reason for ${a.actionSummary}`,
            className: "h-9 w-full rounded-md border border-line bg-surface-1 px-3 text-sm text-ink placeholder:text-ink-muted focus:outline-none focus:ring-2 focus:ring-ring"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 1020,
            columnNumber: 17
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "sm",
              disabled: busyApprovalId === a._id || !(decisionReasons[a._id] ?? "").trim(),
              onClick: async () => {
                setBusyApprovalId(a._id);
                try {
                  const result = await approve({
                    approvalId: a._id,
                    decidedByUserId: "operator",
                    reason: decisionReasons[a._id].trim()
                  });
                  if (!result.success) window.alert(result.error ?? "Approval failed.");
                } finally {
                  setBusyApprovalId(null);
                }
              },
              children: "Approve"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 1033,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              size: "sm",
              variant: "outline",
              disabled: busyApprovalId === a._id || !(decisionReasons[a._id] ?? "").trim(),
              onClick: async () => {
                setBusyApprovalId(a._id);
                try {
                  const result = await deny({
                    approvalId: a._id,
                    decidedByUserId: "operator",
                    reason: decisionReasons[a._id].trim()
                  });
                  if (!result.success) window.alert(result.error ?? "Rejection failed.");
                } finally {
                  setBusyApprovalId(null);
                }
              },
              children: "Reject"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 1054,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1032,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1019,
        columnNumber: 13
      }, this)
    ] }, a._id, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 1002,
      columnNumber: 11
    }, this);
  }) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
    lineNumber: 998,
    columnNumber: 5
  }, this);
}
_s4(ApprovalsTab, "23BqfXoiLePO1EedMh/8JslDCG4=", false, function() {
  return [useMutation, useMutation];
});
_c9 = ApprovalsTab;
function CostTab({
  task,
  runs
}) {
  const totalRunCost = runs.reduce((sum, r) => sum + r.costUsd, 0);
  const completedRuns = runs.filter((r) => r.status === "COMPLETED");
  const failedRuns = runs.filter((r) => r.status === "FAILED");
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV(Section, { title: "Budget", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 flex-wrap", children: [
      task.budgetAllocated && /* @__PURE__ */ jsxDEV(Stat, { label: "Allocated", value: `$${task.budgetAllocated.toFixed(2)}` }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1106,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Stat, { label: "Actual Cost", value: `$${task.actualCost.toFixed(2)}` }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1108,
        columnNumber: 11
      }, this),
      task.budgetRemaining !== void 0 && /* @__PURE__ */ jsxDEV(
        Stat,
        {
          label: "Remaining",
          value: `$${task.budgetRemaining.toFixed(2)}`,
          negative: task.budgetRemaining < 0
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1110,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 1104,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 1103,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Section, { title: "Runs", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 flex-wrap mb-4", children: [
        /* @__PURE__ */ jsxDEV(Stat, { label: "Total Runs", value: runs.length.toString() }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1121,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { label: "Completed", value: completedRuns.length.toString() }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1122,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { label: "Failed", value: failedRuns.length.toString() }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1123,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { label: "Run Cost", value: `$${totalRunCost.toFixed(3)}` }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1124,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1120,
        columnNumber: 9
      }, this),
      runs.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: runs.slice(-10).reverse().map(
        (r) => /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-surface-2 border border-line rounded-md text-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between mb-1", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-ink-muted", children: r.model }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 1132,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-ink font-medium", children: [
              "$",
              r.costUsd.toFixed(3)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 1133,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 1131,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted", children: [
            r.inputTokens.toLocaleString(),
            " in · ",
            r.outputTokens.toLocaleString(),
            " out",
            r.durationMs && ` · ${(r.durationMs / 1e3).toFixed(1)}s`
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 1135,
            columnNumber: 17
          }, this)
        ] }, r._id, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1130,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1128,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 1119,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
    lineNumber: 1102,
    columnNumber: 5
  }, this);
}
_c0 = CostTab;
function WhyTab({
  task,
  agentMap,
  transitions
}) {
  _s5();
  const assignees = task.assigneeIds.map((id) => agentMap.get(id)).filter((agent) => !!agent);
  const allowedTransitions = useQuery(api.tasks.getAllowedTransitionsForHuman);
  const [simulateToStatus, setSimulateToStatus] = useState("");
  const transitionChoices = allowedTransitions?.[task.status] ?? [];
  useEffect(() => {
    if (!simulateToStatus && transitionChoices.length > 0) {
      setSimulateToStatus(transitionChoices[0]);
    }
  }, [simulateToStatus, transitionChoices]);
  const transitionSimulation = useQuery(
    api.tasks.simulateTransition,
    simulateToStatus ? {
      taskId: task._id,
      toStatus: simulateToStatus,
      actorType: "HUMAN",
      hasWorkPlan: !!task.workPlan,
      hasDeliverable: !!task.deliverable,
      hasChecklist: !!task.reviewChecklist
    } : "skip"
  );
  const policyDecision = useQuery(api.policy.explainTaskPolicy, {
    taskId: task._id,
    plannedTransitionTo: simulateToStatus || void 0,
    estimatedCost: task.estimatedCost
  });
  const riskLevel = policyDecision?.riskLevel ?? "GREEN";
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV("section", { children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-semibold text-ink mb-3", children: "Policy Decision Viewer" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1199,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-surface-2 border border-line rounded-md", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 flex-wrap", children: [
          /* @__PURE__ */ jsxDEV(RiskBadge, { level: riskLevel }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 1202,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            StatusBadge,
            {
              tone: policyDecision?.decision === "ALLOW" ? "success" : policyDecision?.decision === "DENY" ? "error" : "neutral",
              children: policyDecision?.decision ?? "Analyzing..."
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 1203,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1201,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-ink-secondary", children: policyDecision?.reason ?? "Calculating policy outcome..." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1209,
          columnNumber: 11
        }, this),
        policyDecision?.triggeredRules && policyDecision.triggeredRules.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted mb-1.5", children: "Triggered rules" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 1214,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1.5 flex-wrap", children: policyDecision.triggeredRules.map(
            (rule) => /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", className: "font-mono", children: rule }, rule, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 1217,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 1215,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1213,
          columnNumber: 11
        }, this),
        policyDecision?.requiredApprovals?.length ? /* @__PURE__ */ jsxDEV("div", { className: "mt-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted mb-1.5", children: "Required approvals" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 1224,
            columnNumber: 15
          }, this),
          policyDecision.requiredApprovals.map(
            (approval, index) => /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-secondary mb-1", children: [
              "• ",
              approval.type,
              ": ",
              approval.reason
            ] }, `${approval.type}-${index}`, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 1226,
              columnNumber: 13
            }, this)
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1223,
          columnNumber: 11
        }, this) : null,
        policyDecision?.remediationHints?.length ? /* @__PURE__ */ jsxDEV("div", { className: "mt-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted mb-1.5", children: "Remediation hints" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 1234,
            columnNumber: 15
          }, this),
          policyDecision.remediationHints.map(
            (hint, index) => /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-secondary mb-1", children: [
              "• ",
              hint
            ] }, `${hint}-${index}`, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 1236,
              columnNumber: 13
            }, this)
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1233,
          columnNumber: 11
        }, this) : null
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1200,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 1198,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-semibold text-ink mb-3", children: "Dry Run Simulation" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1246,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-surface-2 border border-line rounded-md", children: transitionChoices.length > 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-3", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-ink-muted", children: "Simulate transition" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 1251,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              value: simulateToStatus,
              onChange: (event) => setSimulateToStatus(event.target.value),
              className: "px-2 py-1 bg-surface-1 border border-line rounded-md text-sm text-ink",
              children: transitionChoices.map(
                (choice) => /* @__PURE__ */ jsxDEV("option", { value: choice, children: [
                  task.status,
                  " → ",
                  choice
                ] }, choice, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
                  lineNumber: 1258,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 1252,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1250,
          columnNumber: 15
        }, this),
        transitionSimulation ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(
            ExplainRow,
            {
              label: "Result",
              value: transitionSimulation.valid ? "VALID" : "INVALID",
              detail: transitionSimulation.valid ? "No blocking transition rule" : "One or more checks failed"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 1267,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            ExplainRow,
            {
              label: "Actor",
              value: transitionSimulation.actorType,
              detail: "Dry-run evaluates HUMAN actions by default"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 1272,
              columnNumber: 19
            },
            this
          ),
          transitionSimulation.requirements && /* @__PURE__ */ jsxDEV(
            ExplainRow,
            {
              label: "Requirements",
              value: [
                transitionSimulation.requirements.requiresWorkPlan ? "work plan" : null,
                transitionSimulation.requirements.requiresDeliverable ? "deliverable" : null,
                transitionSimulation.requirements.requiresChecklist ? "checklist" : null,
                transitionSimulation.requirements.humanOnly ? "human-only" : null
              ].filter(Boolean).join(", ") || "none"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 1278,
              columnNumber: 15
            },
            this
          ),
          transitionSimulation.errors?.length ? /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: transitionSimulation.errors.map(
            (error) => /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-err mb-1", children: [
              "• ",
              error.field,
              ": ",
              error.message
            ] }, `${error.field}-${error.message}`, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 1293,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 1291,
            columnNumber: 15
          }, this) : null
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1266,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted", children: "Running simulation..." }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1301,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1249,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted", children: [
        "No human transitions available from ",
        task.status,
        "."
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1305,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1247,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 1245,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-semibold text-ink mb-3", children: "Assignment Context" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1313,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-surface-2 border border-line rounded-md", children: assignees.length ? assignees.map(
        (agent) => /* @__PURE__ */ jsxDEV("div", { className: "mb-2.5", children: [
          /* @__PURE__ */ jsxDEV(ExplainRow, { label: "Agent", value: agent.name }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 1318,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(ExplainRow, { label: "Role", value: agent.role }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 1319,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(ExplainRow, { label: "Status", value: agent.status }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 1320,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            ExplainRow,
            {
              label: "Capabilities",
              value: agent.allowedTaskTypes.length ? agent.allowedTaskTypes.join(", ") : "All types",
              detail: agent.allowedTaskTypes.includes(task.type) ? "Matches task type" : "No direct type match"
            },
            void 0,
            false,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
              lineNumber: 1321,
              columnNumber: 17
            },
            this
          )
        ] }, agent._id, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1317,
          columnNumber: 11
        }, this)
      ) : /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-ink-muted", children: "No assignee yet. Assigning an active agent improves policy confidence and simulation accuracy." }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1329,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1314,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 1312,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-semibold text-ink mb-3", children: "Task Properties" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1337,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-surface-2 border border-line rounded-md space-y-1.5", children: [
        /* @__PURE__ */ jsxDEV(ExplainRow, { label: "Type", value: task.type, detail: "Determines decomposition strategy and agent matching" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1339,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(ExplainRow, { label: "Priority", value: `P${task.priority}`, detail: "Higher priority = higher score for agent selection" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1340,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          ExplainRow,
          {
            label: "Source",
            value: (SOURCE_CONFIG[task.source ?? ""] || SOURCE_CONFIG.UNKNOWN).label,
            detail: task.sourceRef ? `Ref: ${task.sourceRef}` : task.createdBy ? `Created by: ${CREATED_BY_LABELS[task.createdBy] || task.createdBy}` : "How the task entered the system"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 1341,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          ExplainRow,
          {
            label: "Created",
            value: new Date(task._creationTime).toLocaleDateString(),
            detail: new Date(task._creationTime).toLocaleString()
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 1346,
            columnNumber: 11
          },
          this
        ),
        task.parentTaskId && /* @__PURE__ */ jsxDEV(ExplainRow, { label: "Parent Task", value: String(task.parentTaskId), detail: "This is a subtask of a decomposed mission" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1352,
          columnNumber: 11
        }, this),
        task.labels && task.labels.length > 0 && /* @__PURE__ */ jsxDEV(ExplainRow, { label: "Labels", value: task.labels.join(", ") }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
          lineNumber: 1355,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          ExplainRow,
          {
            label: "Recent transitions",
            value: String(transitions.length),
            detail: transitions.length ? "Included in task audit trail" : "No transitions yet"
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
            lineNumber: 1357,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1338,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 1336,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
    lineNumber: 1197,
    columnNumber: 5
  }, this);
}
_s5(WhyTab, "qquQ4et6U3mQ96JrxPB8F9FIixw=", false, function() {
  return [useQuery, useQuery, useQuery];
});
_c1 = WhyTab;
function TabButton({
  active,
  onClick,
  children
}) {
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      role: "tab",
      "aria-selected": active,
      onClick,
      className: cn(
        "-mb-px flex items-center gap-1.5 border-b-2 px-3 py-2.5 text-[13px] transition-colors duration-150",
        active ? "border-ink text-ink" : "border-transparent text-ink-muted hover:text-ink-secondary"
      ),
      children
    },
    void 0,
    false,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 1382,
      columnNumber: 5
    },
    this
  );
}
_c10 = TabButton;
function Section({ title, children }) {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h3", { className: "text-xs font-semibold text-ink-muted uppercase tracking-wider mb-3", children: title }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 1401,
      columnNumber: 7
    }, this),
    children
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
    lineNumber: 1400,
    columnNumber: 5
  }, this);
}
_c11 = Section;
function ExplainRow({
  label,
  value,
  detail
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 items-baseline", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-ink-muted w-[100px] shrink-0", children: label }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 1420,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-ink font-medium", children: value }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 1421,
      columnNumber: 7
    }, this),
    detail && /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-ink-muted italic", children: [
      "— ",
      detail
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 1423,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
    lineNumber: 1419,
    columnNumber: 5
  }, this);
}
_c12 = ExplainRow;
function Stat({
  label,
  value,
  negative
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-surface-2 border border-line rounded-md", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-ink-muted block", children: label }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 1440,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("span", { className: cn("text-lg font-semibold", negative ? "text-err" : "text-ink"), children: value }, void 0, false, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 1441,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
    lineNumber: 1439,
    columnNumber: 5
  }, this);
}
_c13 = Stat;
const SOURCE_CONFIG = {
  DASHBOARD: { label: "Dashboard" },
  TELEGRAM: { label: "Telegram" },
  GITHUB: { label: "GitHub" },
  AGENT: { label: "Agent" },
  API: { label: "API" },
  TRELLO: { label: "Trello" },
  SEED: { label: "Seed Data" },
  MISSION_PROMPT: { label: "Mission" },
  PRD_IMPORT: { label: "Imported PRD" },
  UNKNOWN: { label: "Unknown" }
};
const CREATED_BY_LABELS = {
  HUMAN: "Human",
  AGENT: "AI Agent",
  SYSTEM: "System"
};
function SourceBadge({
  source,
  sourceRef,
  createdBy
}) {
  const src = SOURCE_CONFIG[source ?? ""] || SOURCE_CONFIG.UNKNOWN;
  const creatorLabel = CREATED_BY_LABELS[createdBy ?? ""] || null;
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", children: src.label }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1486,
        columnNumber: 9
      }, this),
      creatorLabel && /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-ink-muted", children: [
        "by ",
        creatorLabel
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1488,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 1485,
      columnNumber: 7
    }, this),
    sourceRef && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-ink-muted", children: [
      "Ref: ",
      /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-ink-secondary", children: sourceRef }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
        lineNumber: 1493,
        columnNumber: 16
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
      lineNumber: 1492,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx",
    lineNumber: 1484,
    columnNumber: 5
  }, this);
}
_c14 = SourceBadge;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0, _c1, _c10, _c11, _c12, _c13, _c14;
$RefreshReg$(_c, "TaskDrawerTabs");
$RefreshReg$(_c2, "OverviewTab");
$RefreshReg$(_c3, "ReassignDropdown");
$RefreshReg$(_c4, "RedirectForm");
$RefreshReg$(_c5, "AgentChip");
$RefreshReg$(_c6, "TimelineTab");
$RefreshReg$(_c7, "TimelineItem");
$RefreshReg$(_c8, "ArtifactsTab");
$RefreshReg$(_c9, "ApprovalsTab");
$RefreshReg$(_c0, "CostTab");
$RefreshReg$(_c1, "WhyTab");
$RefreshReg$(_c10, "TabButton");
$RefreshReg$(_c11, "Section");
$RefreshReg$(_c12, "ExplainRow");
$RefreshReg$(_c13, "Stat");
$RefreshReg$(_c14, "SourceBadge");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/TaskDrawerTabs.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEdVLFNBMkdZLFVBM0daOzs7Ozs7Ozs7Ozs7Ozs7OztBQXhHVixTQUFTQSxhQUFhQyxnQkFBZ0I7QUFDdEMsU0FBU0MsV0FBVztBQUVwQixTQUFTQyxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxjQUFjO0FBQ3ZCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQywwQkFBMEI7QUFDbkMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLFdBQVdDLG1CQUEwQztBQUM5RCxTQUFTQyw4QkFBOEI7QUFDdkMsU0FBU0MsOEJBQThCO0FBTXZDLFNBQVNDLGVBQWVDLFFBQTBDO0FBQ2hFLFVBQVFBLFFBQU07QUFBQSxJQUNaLEtBQUs7QUFDSCxhQUFPO0FBQUEsSUFDVCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQ0gsYUFBTztBQUFBLElBQ1QsS0FBSztBQUFBLElBQ0wsS0FBSztBQUNILGFBQU87QUFBQSxJQUNULEtBQUs7QUFDSCxhQUFPO0FBQUEsSUFDVDtBQUNFLGFBQU87QUFBQSxFQUNYO0FBQ0Y7QUFFQSxTQUFTQyxtQkFBbUJELFFBQTBDO0FBQ3BFLFVBQVFBLFFBQU07QUFBQSxJQUNaLEtBQUs7QUFDSCxhQUFPO0FBQUEsSUFDVCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQ0gsYUFBTztBQUFBLElBQ1QsS0FBSztBQUFBLElBQ0wsS0FBSztBQUNILGFBQU87QUFBQSxJQUNUO0FBQ0UsYUFBTztBQUFBLEVBQ1g7QUFDRjtBQUVBLFNBQVNFLGtCQUFrQkYsUUFBd0I7QUFDakQsU0FBT0EsT0FBT0csUUFBUSxNQUFNLEdBQUc7QUFDakM7QUFFTyxnQkFBU0MsZUFBZTtBQUFBLEVBQzdCQztBQUFBQSxFQUNBQztBQUlGLEdBQUc7QUFBQUMsS0FBQTtBQUNELFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJaEMsU0FBYyxVQUFVO0FBQzFELFFBQU0sQ0FBQ2lDLFlBQVlDLGFBQWEsSUFBSWxDLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUNtQyxTQUFTQyxVQUFVLElBQUlwQyxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDcUMsU0FBU0MsVUFBVSxJQUFJdEMsU0FBUyxLQUFLO0FBRTVDLFFBQU11QyxPQUFPMUMsU0FBU0MsSUFBSTBDLE1BQU1DLGlCQUFpQmIsU0FBUyxFQUFFQSxPQUFPLElBQUksTUFBTTtBQUM3RSxRQUFNYyxTQUFTN0M7QUFBQUEsSUFDYkMsSUFBSTRDLE9BQU9DO0FBQUFBLElBQ1hKLE1BQU1LLEtBQUtDLFlBQVksRUFBRUEsV0FBV04sS0FBS0ssS0FBS0MsVUFBVSxJQUFJLENBQUM7QUFBQSxFQUMvRDtBQUNBLFFBQU1DLHFCQUFxQmpEO0FBQUFBLElBQ3pCQyxJQUFJZ0QsbUJBQW1CQztBQUFBQSxJQUN2Qm5CLFNBQVMsRUFBRW9CLFFBQVEsWUFBWUMsWUFBWSxPQUFPLElBQUk7QUFBQSxFQUN4RDtBQUNBLFFBQU1DLGNBQWN0RCxZQUFZRSxJQUFJcUQsU0FBU0MsSUFBSTtBQUNqRCxRQUFNQyxpQkFBaUJ6RCxZQUFZRSxJQUFJMEMsTUFBTWMsVUFBVTtBQUN2RCxRQUFNQyxhQUFhM0QsWUFBWUUsSUFBSTBDLE1BQU1nQixNQUFNO0FBQy9DLFFBQU1DLGNBQWM3RCxZQUFZRSxJQUFJZ0QsbUJBQW1CWSxNQUFNO0FBQzdELFFBQU1DLGtCQUFrQi9ELFlBQVlFLElBQUk4RCxVQUFVQyxPQUFPO0FBRXpELE1BQUksQ0FBQ2pDLE9BQVEsUUFBTztBQUVwQixRQUFNa0MsWUFBWXZCLFNBQVN3QixVQUFhckIsV0FBV3FCO0FBRW5ELFNBQ0UsdUJBQUMsU0FBTSxNQUFNLENBQUMsQ0FBQ25DLFFBQVEsY0FBYyxDQUFDb0MsU0FBUztBQUFFLFFBQUksQ0FBQ0EsS0FBTW5DLFNBQVE7QUFBQSxFQUFHLEdBQ3JFLGlDQUFDLGdCQUFhLE1BQUssU0FBUSxXQUFVLDhFQUNuQztBQUFBLDJCQUFDLGVBQVksV0FBVSxXQUNyQjtBQUFBLDZCQUFDLGNBQVlVLGdCQUFNSyxLQUFLcUIsU0FBUyxrQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRDtBQUFBLE1BQ2hELHVCQUFDLG9CQUFnQix5RkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUNDSCxZQUNDLHVCQUFDLFNBQUksV0FBVSw4QkFBNkIsMEJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0QsSUFDcEQsQ0FBQ3ZCLE9BQ0gsdUJBQUMsU0FBSSxXQUFVLDhCQUE2Qiw4QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRCxLQUN2RCxNQUFNO0FBQ1QsWUFBTSxFQUFFSyxNQUFNc0IsYUFBYWYsVUFBVWdCLE1BQU1DLFdBQVdSLFdBQVdTLFlBQVlDLFdBQVcsSUFBSS9CO0FBQzVGLFlBQU1nQyxXQUFXLElBQUlDO0FBQUFBLFFBQ2xCOUIsT0FBMkIrQixJQUFJLENBQUNDLE1BQXFCLENBQUNBLEVBQUVDLEtBQUtELENBQUMsQ0FBQztBQUFBLE1BQ2xFO0FBQ0EsWUFBTUUsaUJBQWlCLENBQUMsQ0FBQzlCLG9CQUFvQitCLEtBQUssQ0FBQ0MsaUJBQWlCQSxhQUFhQyxhQUFhbkQsTUFBTTtBQUVwRyxZQUFNb0Qsb0JBQW9CLFlBQVk7QUFDcEMsWUFBSSxDQUFDN0MsUUFBUThDLEtBQUssRUFBRztBQUNyQjNDLG1CQUFXLElBQUk7QUFDZixZQUFJO0FBQ0YsZ0JBQU1ZLFlBQVk7QUFBQSxZQUNoQnRCO0FBQUFBLFlBQ0FzRCxZQUFZO0FBQUEsWUFDWkMsY0FBYztBQUFBLFlBQ2RDLE1BQU07QUFBQSxZQUNOQyxTQUFTbEQ7QUFBQUEsWUFDVG1ELGdCQUFnQixXQUFXMUQsTUFBTSxJQUFJMkQsS0FBS0MsSUFBSSxDQUFDO0FBQUEsVUFDakQsQ0FBQztBQUNEcEQscUJBQVcsRUFBRTtBQUFBLFFBQ2YsU0FBU3FELEdBQUc7QUFDVkMsa0JBQVFDLE1BQU1GLENBQUM7QUFBQSxRQUNqQjtBQUNBbkQsbUJBQVcsS0FBSztBQUFBLE1BQ2xCO0FBRUEsWUFBTXNELG1CQUFtQixPQUFPQyxhQUF5QjtBQUN2RHZELG1CQUFXLElBQUk7QUFDZixZQUFJO0FBQ0YsZ0JBQU13RCxTQUFTLE1BQU16QyxlQUFlO0FBQUEsWUFDbEN6QjtBQUFBQSxZQUNBaUU7QUFBQUEsWUFDQUUsV0FBVztBQUFBLFlBQ1hDLGFBQWE7QUFBQSxZQUNiVixnQkFBZ0IsY0FBYzFELE1BQU0sSUFBSWlFLFFBQVEsSUFBSU4sS0FBS0MsSUFBSSxDQUFDO0FBQUEsWUFDOURTLFFBQVE7QUFBQSxVQUNWLENBQUM7QUFDRCxjQUFJLENBQUNILE9BQU9JLFdBQVdKLE9BQU9LLFFBQVE7QUFDcENDLGtCQUFNTixPQUFPSyxPQUFPMUIsSUFBSSxDQUFDZ0IsTUFBV0EsRUFBRVksT0FBTyxFQUFFQyxLQUFLLElBQUksQ0FBQztBQUFBLFVBQzNEO0FBQUEsUUFDRixTQUFTYixHQUFHO0FBQ1ZDLGtCQUFRQyxNQUFNRixDQUFDO0FBQUEsUUFDakI7QUFDQW5ELG1CQUFXLEtBQUs7QUFBQSxNQUNsQjtBQUVBLGFBQ0UsbUNBRUU7QUFBQSwrQkFBQyxTQUFJLFdBQVUsa0NBQ2IsaUNBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsYUFDWk07QUFBQUEsbUJBQUsyRCxjQUNKLHVCQUFDLFVBQUssV0FBVSxxREFBcUQzRCxlQUFLMkQsY0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUY7QUFBQSxjQUV2RjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxlQUFZO0FBQUEsa0JBQ1osV0FBVTtBQUFBLGtCQUVUM0QsZUFBS3FCO0FBQUFBO0FBQUFBLGdCQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsaUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsZUFBWSxNQUFNM0MsZUFBZXNCLEtBQUtyQixNQUFNLEdBQzFDRSw0QkFBa0JtQixLQUFLckIsTUFBTSxLQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxlQUFZLE1BQUssV0FBVTtBQUFBO0FBQUEsZ0JBQUVxQixLQUFLNEQ7QUFBQUEsbUJBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRDO0FBQUEsY0FDNUMsdUJBQUMsZUFBWSxNQUFLLFdBQVc1RCxlQUFLd0MsUUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUM7QUFBQSxjQUN0Q3hDLEtBQUs2RCxXQUFXLE1BQU07QUFDckIsc0JBQU1DLE1BQU1DLGNBQWMvRCxLQUFLNkQsTUFBTSxLQUFLRSxjQUFjQztBQUN4RCx1QkFDRTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsT0FBT2hFLEtBQUtpRSxZQUFZLEdBQUdILElBQUlJLEtBQUssS0FBS2xFLEtBQUtpRSxTQUFTLEtBQUtILElBQUlJO0FBQUFBLG9CQUUvREosY0FBSUk7QUFBQUE7QUFBQUEsa0JBSlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsY0FFSixHQUFHO0FBQUEsaUJBaEJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsZUE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4QkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBU2xDLGlCQUFpQixZQUFZO0FBQUEsZ0JBQ3RDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLFlBQVk7QUFDbkIsd0JBQU1uQixZQUFZO0FBQUEsb0JBQ2hCVCxRQUFRO0FBQUEsb0JBQ1JILFdBQVdELEtBQUtDLGFBQWFrQjtBQUFBQSxvQkFDN0JkLFlBQVk7QUFBQSxvQkFDWjhCLFVBQVVuRDtBQUFBQSxrQkFDWixDQUFDO0FBQUEsZ0JBQ0g7QUFBQSxnQkFFQ2dELDJCQUFpQixhQUFhO0FBQUE7QUFBQSxjQVpqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFhQTtBQUFBLFlBQ0MsQ0FBQzNDLGNBQ0EsbUNBQ0U7QUFBQSxxQ0FBQyxVQUFPLE1BQUssTUFBSyxTQUFTLE1BQU1DLGNBQWMsSUFBSSxHQUFFLG9CQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxzQkFBbUIsVUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUM7QUFBQSxpQkFKckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLGVBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUJBO0FBQUEsYUF2REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdEQSxLQXpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMERBO0FBQUEsUUFFQ0QsYUFDQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBLFFBQVEsTUFBTUMsY0FBYyxLQUFLO0FBQUEsWUFDakMsVUFBVSxNQUFNQSxjQUFjLEtBQUs7QUFBQTtBQUFBLFVBSHJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUd1QyxJQUd2QyxtQ0FFRTtBQUFBLGlDQUFDLFNBQUksV0FBVSxrQ0FBaUMsTUFBSyxXQUNqRCxXQUFDLFlBQVksWUFBWSxhQUFhLGFBQWEsUUFBUSxXQUFXLEtBQUssRUFBWXVDO0FBQUFBLFlBQUksQ0FBQ3NDLFFBQzVGO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsUUFBUWhGLGNBQWNnRjtBQUFBQSxnQkFDdEIsU0FBUyxNQUFNL0UsYUFBYStFLEdBQUc7QUFBQSxnQkFFOUJBLGtCQUFRLGVBQWVuRCxVQUFVb0QsU0FBUyxJQUN2QyxjQUFjcEQsVUFBVW9ELE1BQU0sTUFDOUJELFFBQVEsUUFDTixTQUNBQSxJQUFJRSxPQUFPLENBQUMsRUFBRUMsWUFBWSxJQUFJSCxJQUFJSSxNQUFNLENBQUM7QUFBQTtBQUFBLGNBUjFDSjtBQUFBQSxjQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLFVBQ0QsS0FiSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsNEJBQ1poRjtBQUFBQSwwQkFBYyxjQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQTtBQUFBLGdCQUNBO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQTtBQUFBLGdCQUNBO0FBQUEsZ0JBQ0EsY0FBYzZEO0FBQUFBLGdCQUNkO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQTtBQUFBLGdCQUNBO0FBQUEsZ0JBQ0E7QUFBQTtBQUFBLGNBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWXlCO0FBQUEsWUFHMUI3RCxjQUFjLGNBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQTtBQUFBLGdCQUNBO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQTtBQUFBLGdCQUNBO0FBQUE7QUFBQSxjQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFxQjtBQUFBLFlBR3RCQSxjQUFjLGVBQ2IsdUJBQUMsZ0JBQWEsTUFBWSxZQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QztBQUFBLFlBRTlDQSxjQUFjLGFBQ2IsdUJBQUMsbUJBQWdCLFFBQWdCLFdBQVdhLEtBQUtDLGFBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTREO0FBQUEsWUFFN0RkLGNBQWMsZUFDYix1QkFBQyxnQkFBYSxXQUFzQixZQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RDtBQUFBLFlBRXhEQSxjQUFjLFVBQ2IsdUJBQUMsV0FBUSxNQUFZLFFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDO0FBQUEsWUFFakNBLGNBQWMsU0FDYix1QkFBQyxVQUFPLE1BQVksVUFBb0IsZUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUU7QUFBQSxlQTFDckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0Q0E7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT0k7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDc0QsTUFBTXJELFdBQVdxRCxFQUFFMkIsT0FBT0MsS0FBSztBQUFBLGdCQUMxQyxhQUFZO0FBQUEsZ0JBQ1osTUFBTTtBQUFBLGdCQUNOLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS3dLO0FBQUEsWUFFeEs7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU3JDO0FBQUFBLGdCQUNULFVBQVUzQyxXQUFXLENBQUNGLFFBQVE4QyxLQUFLO0FBQUEsZ0JBQ25DLFdBQVU7QUFBQSxnQkFFVDVDLG9CQUFVLGVBQWU7QUFBQTtBQUFBLGNBTjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsZUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLGFBbEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtRkE7QUFBQSxXQXhKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEpBO0FBQUEsSUFFSixHQUFHO0FBQUEsT0F0Tkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVOQSxLQXhORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeU5BO0FBRUo7QUFJQVAsR0EvUGdCSCxnQkFBYztBQUFBLFVBWWY5QixVQUNFQSxVQUlZQSxVQUlQRCxhQUNHQSxhQUNKQSxhQUNDQSxhQUNJQSxXQUFXO0FBQUE7QUFBQSxLQXpCckIrQjtBQWlRaEIsU0FBUzJGLFlBQVk7QUFBQSxFQUNuQjFGO0FBQUFBLEVBQ0FnQjtBQUFBQSxFQUNBdUI7QUFBQUEsRUFDQVA7QUFBQUEsRUFDQWxCO0FBQUFBLEVBQ0E2QjtBQUFBQSxFQUNBZ0Q7QUFBQUEsRUFDQWxGO0FBQUFBLEVBQ0FhO0FBQUFBLEVBQ0FLO0FBQUFBLEVBQ0FJO0FBQUFBLEVBQ0FyQjtBQStCRixHQUFHO0FBQ0QsUUFBTWtGLG9CQUFvQm5HLHVCQUF1QnVCLE1BQU11QixNQUFNUCxTQUFTO0FBQ3RFLFFBQU02RCxXQUFXN0QsVUFBVWlCLEtBQUssQ0FBQzZDLGFBQWFBLFNBQVNuRyxXQUFXLFVBQVU7QUFDNUUsUUFBTW9HLGtCQUFrQi9ELFVBQVVpQjtBQUFBQSxJQUFLLENBQUM2QyxhQUN0QyxDQUFDLFdBQVcsV0FBVyxFQUFFRSxTQUFTRixTQUFTbkcsTUFBTTtBQUFBLEVBQ25EO0FBRUEsUUFBTXNHLHdCQUF3QixZQUFZO0FBQ3hDLFVBQU1DLG1CQUFtQmxGLEtBQUttRixZQUFZLENBQUM7QUFDM0MsUUFBSSxDQUFDRCxrQkFBa0I7QUFDckJFLGFBQU81QixNQUFNLDZDQUE2QztBQUMxRDtBQUFBLElBQ0Y7QUFDQTlELGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixZQUFNcUIsZ0JBQWdCO0FBQUEsUUFDcEJkLFdBQVdELEtBQUtDO0FBQUFBLFFBQ2hCakI7QUFBQUEsUUFDQWtHO0FBQUFBLFFBQ0FHLFlBQVk7QUFBQSxRQUNaQyxlQUFlLHlCQUF5QnRGLEtBQUsyRCxjQUFjM0QsS0FBS3FCLEtBQUs7QUFBQSxRQUNyRWtFLFdBQVc7QUFBQSxRQUNYQyxlQUNFeEYsS0FBS3lGLGFBQWFDLFdBQ2xCO0FBQUEsUUFDRkMsa0JBQWtCO0FBQUEsUUFDbEJqRCxnQkFBZ0IsZUFBZTFELE1BQU0sSUFBSWdCLEtBQUs0RixZQUFZO0FBQUEsTUFDNUQsQ0FBQztBQUFBLElBQ0gsU0FBUzdDLE9BQU87QUFDZHFDLGFBQU81QixNQUFNVCxpQkFBaUI4QyxRQUFROUMsTUFBTVUsVUFBVSw2QkFBNkI7QUFBQSxJQUNyRixVQUFDO0FBQ0MvRCxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDJCQUFDLDBCQUF1QixPQUFPa0YscUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUQ7QUFBQSxJQUVoRDVFLEtBQUs4RixlQUNKLHVCQUFDLFdBQVEsT0FBTSxlQUNiLGlDQUFDLE9BQUUsV0FBVSw4Q0FBOEM5RixlQUFLOEYsZUFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0RSxLQUQ5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUdGLHVCQUFDLFdBQVEsT0FBTSxhQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDWjlGO0FBQUFBLFdBQUttRixZQUFZZixTQUFTLElBQ3pCcEUsS0FBS21GLFlBQVl0RCxJQUFJLENBQUNrRSxPQUFxQjtBQUN6QyxjQUFNQyxRQUFRckUsU0FBU3NFLElBQUlGLEVBQUU7QUFDN0IsZUFBT0MsUUFDTCx1QkFBQyxhQUFtQixTQUFKRCxJQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlDLElBQy9CO0FBQUEsTUFDTixDQUFDLElBRUQsdUJBQUMsVUFBSyxXQUFVLDBCQUF5QiwwQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRDtBQUFBLE1BRXJEO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0Esb0JBQW9CL0YsS0FBS21GO0FBQUFBLFVBQ3pCO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQTtBQUFBLFFBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS3lCO0FBQUEsU0FoQjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQkEsS0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CQTtBQUFBLElBRUNuRixLQUFLa0csU0FBUyxRQUNiLHVCQUFDLFdBQVEsT0FBTSxZQUNiLGlDQUFDLFNBQUksV0FBVSwrRkFDYjtBQUFBLDZCQUFDLFVBQUssV0FBVSxZQUNiLGNBQUl2RCxLQUFLM0MsS0FBS2tHLEtBQUssRUFBRUMsbUJBQW1CaEYsUUFBVztBQUFBLFFBQ2xEaUYsU0FBUztBQUFBLFFBQ1RDLE9BQU87QUFBQSxRQUNQQyxLQUFLO0FBQUEsUUFDTEMsTUFBTTtBQUFBLE1BQ1IsQ0FBQyxLQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVdsSjtBQUFBQSxZQUNUO0FBQUEsWUFDQTJDLEtBQUtrRyxRQUFRdkQsS0FBS0MsSUFBSSxJQUNsQixhQUNBNUMsS0FBS2tHLFFBQVF2RCxLQUFLQyxJQUFJLElBQUksUUFBVyxJQUNuQyxjQUNBO0FBQUEsVUFDUjtBQUFBLFVBRUM1QyxlQUFLa0csUUFBUXZELEtBQUtDLElBQUksSUFDbkIsWUFDQTVDLEtBQUtrRyxRQUFRdkQsS0FBS0MsSUFBSSxJQUFJLFFBQVcsSUFDbkMsYUFDQTtBQUFBO0FBQUEsUUFkUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFlQTtBQUFBLFNBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkEsS0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJCQTtBQUFBLElBR0YsdUJBQUMsV0FBUSxPQUFNLFVBQ2IsaUNBQUMsZUFBWSxRQUFRNUMsS0FBSzZELFFBQVEsV0FBVzdELEtBQUtpRSxXQUFXLFdBQVdqRSxLQUFLd0csYUFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1RixLQUR6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVDeEcsS0FBS3lHLGNBQWN6RyxLQUFLeUcsV0FBV3JDLFNBQVMsS0FDM0MsdUJBQUMsV0FBUSxPQUFNLGdCQUNiLGlDQUFDLFFBQUcsV0FBVSxxQkFDWHBFLGVBQUt5RyxXQUFXNUU7QUFBQUEsTUFBSSxDQUFDNkUsSUFBMENDLE1BQzlELHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsd0JBQXdCRCxhQUFHRSxZQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUEsUUFDbEQsdUJBQUMsUUFBRyxXQUFVLGtDQUFrQ0YsYUFBR0csVUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRDtBQUFBLFdBRmxERixHQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLElBQ0QsS0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUdEM0csS0FBSzhHLFlBQ0osdUJBQUMsV0FBUSxPQUFNLGFBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUseURBQ1g5RyxlQUFLOEcsU0FBU0MsUUFBUWxGO0FBQUFBLFFBQUksQ0FBQ21GLFFBQWdCTCxNQUMxQyx1QkFBQyxRQUFZSyxvQkFBSkwsR0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9CO0FBQUEsTUFDckIsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUNDM0csS0FBSzhHLFNBQVNHLGlCQUNiLHVCQUFDLE9BQUUsV0FBVSwrQkFBNkI7QUFBQTtBQUFBLFFBQzNCakgsS0FBSzhHLFNBQVNHLGNBQWNDLFFBQVEsQ0FBQztBQUFBLFdBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsSUFHRGxILEtBQUt5RixlQUNKLHVCQUFDLFdBQVEsT0FBTSxlQUNaekY7QUFBQUEsV0FBS3lGLFlBQVlDLFdBQ2hCLHVCQUFDLE9BQUUsV0FBVSxtQ0FBbUMxRixlQUFLeUYsWUFBWUMsV0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RTtBQUFBLE1BRTFFMUYsS0FBS3lGLFlBQVkwQixlQUFlbkgsS0FBS3lGLFlBQVkwQixZQUFZL0MsU0FBUyxLQUNyRSx1QkFBQyxTQUFJLFdBQVUsMEJBQ1pwRSxlQUFLeUYsWUFBWTBCLFlBQVl0RjtBQUFBQSxRQUFJLENBQUNrRSxPQUNqQyx1QkFBQyxlQUFxQixNQUFLLFdBQVUsV0FBVSxhQUFhQSxnQkFBMUNBLElBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0Q7QUFBQSxNQUNoRSxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLFNBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsSUFHRC9GLEtBQUtvSCxpQkFDSix1QkFBQyxXQUFRLE9BQU0sa0JBQ2IsaUNBQUMsT0FBRSxXQUFVLG9CQUFvQnBILGVBQUtvSCxpQkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRCxLQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUdGLHVCQUFDLFdBQVEsT0FBTSxZQUNiO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBO0FBQUEsTUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJeUIsS0FMM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFFQSx1QkFBQyxXQUFRLE9BQU0saUJBQ2IsaUNBQUMsU0FBSSxXQUFVLHdCQUNacEg7QUFBQUEsV0FBS3JCLFdBQVcsV0FDZix1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFTLE1BQU1nRyxhQUFhLFVBQVUsR0FBRyxVQUFVbEYsU0FBUSxzQkFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFRE8sS0FBS3JCLFdBQVcsWUFBWWtHLFlBQzNCLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVMsTUFBTUYsYUFBYSxNQUFNLEdBQUcsVUFBVWxGLFNBQVEsb0NBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRURPLEtBQUtyQixXQUFXLFlBQVksQ0FBQ2tHLFlBQVksQ0FBQ0UsbUJBQ3pDLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVNFLHVCQUF1QixVQUFVeEYsU0FBUSxnQ0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFRE8sS0FBS3JCLFdBQVcsWUFBWW9HLG1CQUMzQix1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFRLFdBQVUsVUFBUSx1Q0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFRC9FLEtBQUtyQixXQUFXLGFBQ2YsdUJBQUMsVUFBTyxNQUFLLE1BQUssU0FBUyxNQUFNZ0csYUFBYSxhQUFhLEdBQUcsVUFBVWxGLFNBQVEsdUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBeEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQkEsS0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRCQTtBQUFBLE9BeEpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5SkE7QUFFSjtBQUFDNEgsTUExT1EzQztBQTRPVCxTQUFTNEMsaUJBQWlCO0FBQUEsRUFDeEJ0STtBQUFBQSxFQUNBdUk7QUFBQUEsRUFDQXpIO0FBQUFBLEVBQ0FhO0FBQUFBLEVBQ0FqQjtBQU9GLEdBQUc7QUFBQThILE1BQUE7QUFDRCxRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSXRLLFNBQXlCbUssa0JBQWtCO0FBQ2pGLFFBQU0sQ0FBQ25HLE1BQU11RyxPQUFPLElBQUl2SyxTQUFTLEtBQUs7QUFFdENELFlBQVUsTUFBTTtBQUNkdUssbUJBQWVILGtCQUFrQjtBQUFBLEVBQ25DLEdBQUcsQ0FBQ0Esa0JBQWtCLENBQUM7QUFFdkIsUUFBTUssaUJBQWlCLE9BQU9DLFlBQTRCO0FBQ3hESCxtQkFBZUcsT0FBTztBQUN0Qm5JLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixZQUFNaUIsV0FBVyxFQUFFM0IsUUFBUW1HLGFBQWEwQyxRQUFRLENBQUM7QUFDakRGLGNBQVEsS0FBSztBQUFBLElBQ2YsU0FBUzVFLE9BQU87QUFDZEQsY0FBUUMsTUFBTUEsS0FBSztBQUFBLElBQ3JCLFVBQUM7QUFDQ3JELGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLGdCQUFhLE1BQVksY0FBY2lJLFNBQ3RDO0FBQUEsMkJBQUMsdUJBQW9CLFNBQU8sTUFDMUIsaUNBQUMsVUFBTyxTQUFRLFdBQVUsTUFBSyxNQUFJLDJCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxJQUNBLHVCQUFDLHVCQUFvQixPQUFNLFNBQVEsV0FBVSxzQ0FDM0M7QUFBQSw2QkFBQyxxQkFBa0IseUJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEI7QUFBQSxNQUM1Qix1QkFBQywyQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNCO0FBQUEsTUFDckI3SCxPQUFPK0I7QUFBQUEsUUFBSSxDQUFDbUUsVUFDWDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsU0FBU3lCLFlBQVl6QyxTQUFTZ0IsTUFBTWpFLEdBQUc7QUFBQSxZQUN2QyxpQkFBaUIsTUFBTTtBQUNyQixvQkFBTThGLFVBQVVKLFlBQVl6QyxTQUFTZ0IsTUFBTWpFLEdBQUcsSUFDMUMwRixZQUFZSyxPQUFPLENBQUNDLGNBQWNBLGNBQWMvQixNQUFNakUsR0FBRyxJQUN6RCxDQUFDLEdBQUcwRixhQUFhekIsTUFBTWpFLEdBQUc7QUFDOUIsbUJBQUs2RixlQUFlQyxPQUFPO0FBQUEsWUFDN0I7QUFBQSxZQUVBLGlDQUFDLFVBQU03QixnQkFBTWdDLFFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0I7QUFBQTtBQUFBLFVBVGJoQyxNQUFNakU7QUFBQUEsVUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBV0E7QUFBQSxNQUNEO0FBQUEsTUFDRCx1QkFBQywyQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNCO0FBQUEsTUFDdEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFVBQVUsTUFBTSxLQUFLNkYsZUFBZSxFQUFFO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSUE7QUFBQSxTQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsT0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThCQTtBQUVKO0FBQUNKLElBbEVRRixrQkFBZ0I7QUFBQSxNQUFoQkE7QUFvRVQsU0FBU1csYUFBYTtBQUFBLEVBQ3BCako7QUFBQUEsRUFDQXNCO0FBQUFBLEVBQ0FiO0FBQUFBLEVBQ0FDO0FBYUYsR0FBRztBQUFBd0ksTUFBQTtBQUNELFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJaEwsU0FBUyxFQUFFO0FBRW5ELFFBQU1pTCxpQkFBaUIsWUFBWTtBQUNqQyxRQUFJLENBQUNGLGFBQWE5RixLQUFLLEVBQUc7QUFDMUIzQyxlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0YsWUFBTVksWUFBWTtBQUFBLFFBQ2hCdEI7QUFBQUEsUUFDQXNELFlBQVk7QUFBQSxRQUNaQyxjQUFjO0FBQUEsUUFDZEMsTUFBTTtBQUFBLFFBQ05DLFNBQVMsYUFBYTBGLGFBQWE5RixLQUFLLENBQUM7QUFBQSxRQUN6Q0ssZ0JBQWdCLFlBQVkxRCxNQUFNLElBQUkyRCxLQUFLQyxJQUFJLENBQUM7QUFBQSxNQUNsRCxDQUFDO0FBQ0R3RixzQkFBZ0IsRUFBRTtBQUFBLElBQ3BCLFNBQVNyRixPQUFPO0FBQ2RELGNBQVFDLE1BQU1BLEtBQUs7QUFBQSxJQUNyQixVQUFDO0FBQ0NyRCxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxPQUFPeUk7QUFBQUEsUUFDUCxVQUFVLENBQUNHLFVBQVVGLGdCQUFnQkUsTUFBTTlELE9BQU9DLEtBQUs7QUFBQSxRQUN2RCxhQUFZO0FBQUEsUUFDWixXQUFVO0FBQUE7QUFBQSxNQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUs2SztBQUFBLElBRTdLLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVM0RCxnQkFBZ0IsVUFBVTVJLFdBQVcsQ0FBQzBJLGFBQWE5RixLQUFLLEdBQUUsNkJBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdBO0FBRUo7QUFBQzZGLElBdERRRCxjQUFZO0FBQUEsTUFBWkE7QUF3RFQsU0FBU00sVUFBVSxFQUFFdkMsTUFBZ0MsR0FBRztBQUN0RCxTQUNFLHVCQUFDLFVBQUssV0FBVSx5RkFDZDtBQUFBLDJCQUFDLFVBQU1BLGdCQUFNZ0MsUUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtCO0FBQUEsSUFDbEIsdUJBQUMsVUFBSyxXQUFVLGtCQUFrQmhDLGdCQUFNd0MsUUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QztBQUFBLE9BRi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQTtBQUVKO0FBTUFDLE1BYlNGO0FBY1QsTUFBTUcsdUJBQ0o7QUFFRixTQUFTQyxZQUFZO0FBQUEsRUFDbkJqSDtBQUFBQSxFQUNBSjtBQUFBQSxFQUNBZjtBQUFBQSxFQUNBZ0I7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQVI7QUFBQUEsRUFDQVM7QUFBQUEsRUFDQUU7QUFVRixHQUFHO0FBQ0QsUUFBTWlILFFBSUQ7QUFFTCxNQUFJbEgsV0FBVzBDLFNBQVMsR0FBRztBQUN6QixlQUFXa0UsU0FBUzVHLFlBQVk7QUFDOUJrSCxZQUFNQyxLQUFLLEVBQUVyRyxNQUFNLGFBQWFzRyxJQUFJUixNQUFNUyxXQUFXcEosTUFBTTJJLE1BQU0sQ0FBQztBQUFBLElBQ3BFO0FBQUEsRUFDRixPQUFPO0FBQ0wsZUFBV1UsS0FBSzFILFlBQWFzSCxPQUFNQyxLQUFLLEVBQUVyRyxNQUFNLGNBQWNzRyxJQUFLRSxFQUFVQyxlQUFldEosTUFBTXFKLEVBQUUsQ0FBQztBQUNyRyxlQUFXRSxLQUFLM0ksU0FBVXFJLE9BQU1DLEtBQUssRUFBRXJHLE1BQU0sV0FBV3NHLElBQUtJLEVBQVVELGVBQWV0SixNQUFNdUosRUFBRSxDQUFDO0FBQy9GLGVBQVdDLEtBQUs1SCxLQUFNcUgsT0FBTUMsS0FBSyxFQUFFckcsTUFBTSxPQUFPc0csSUFBSUssRUFBRUMsV0FBV3pKLE1BQU13SixFQUFFLENBQUM7QUFDMUUsZUFBV0UsTUFBTTdILFVBQVdvSCxPQUFNQyxLQUFLLEVBQUVyRyxNQUFNLFlBQVlzRyxJQUFJTyxHQUFHRCxXQUFXekosTUFBTTBKLEdBQUcsQ0FBQztBQUN2RixlQUFXdkgsS0FBS2QsVUFBVzRILE9BQU1DLEtBQUssRUFBRXJHLE1BQU0sWUFBWXNHLElBQUtoSCxFQUFVbUgsZUFBZXRKLE1BQU1tQyxFQUFFLENBQUM7QUFDakcsZUFBV3dILFlBQVk3SCxXQUFZbUgsT0FBTUMsS0FBSyxFQUFFckcsTUFBTSxZQUFZc0csSUFBS1EsU0FBaUJMLGVBQWV0SixNQUFNMkosU0FBUyxDQUFDO0FBQUEsRUFDekg7QUFFQVYsUUFBTVcsS0FBSyxDQUFDekgsR0FBRzBILE1BQU0xSCxFQUFFZ0gsS0FBS1UsRUFBRVYsRUFBRTtBQUVoQyxTQUNFLHVCQUFDLFNBQUksV0FBVSxhQUNaRixnQkFBTS9HO0FBQUFBLElBQUksQ0FBQzRILE1BQU05QyxNQUNoQix1QkFBQyxnQkFBcUIsTUFBWSxZQUFmQSxHQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFEO0FBQUEsRUFDdEQsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUE7QUFFSjtBQUFDK0MsTUEvQ1FmO0FBaURULFNBQVNnQixhQUFhO0FBQUEsRUFDcEJGO0FBQUFBLEVBQ0E5SDtBQUlGLEdBQUc7QUFDRCxRQUFNaUksT0FBTyxJQUFJakgsS0FBSzhHLEtBQUtYLEVBQUUsRUFBRWUsbUJBQW1CO0FBRWxELFFBQU1DLGtCQUFrQkEsQ0FBQzNHLFdBQW9CNEcsWUFBcUI7QUFDaEUsUUFBSTVHLGNBQWMsV0FBVzRHLFNBQVM7QUFDcEMsWUFBTUMsYUFBYXJJLFNBQVNzRSxJQUFJOEQsT0FBdUI7QUFDdkQsVUFBSUMsV0FBWSxRQUFPQSxXQUFXaEM7QUFBQUEsSUFDcEM7QUFDQSxRQUFJN0UsY0FBYyxRQUFTLFFBQU80RyxXQUFXO0FBQzdDLFFBQUk1RyxjQUFjLFNBQVUsUUFBTztBQUNuQyxXQUFPNEcsV0FBVztBQUFBLEVBQ3BCO0FBRUEsVUFBUU4sS0FBS2pILE1BQUk7QUFBQSxJQUNmLEtBQUssYUFBYTtBQUNoQixZQUFNOEYsUUFBUW1CLEtBQUs5SjtBQUNuQixZQUFNc0ssUUFBUUgsZ0JBQWdCeEIsTUFBTW5GLFdBQVdtRixNQUFNeUIsT0FBTztBQUM1RCxhQUNFLHVCQUFDLFNBQUksV0FBV3JCLHNCQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBCQUEwQmtCLGtCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsUUFDOUMsdUJBQUMsU0FBSSxXQUFVLGdDQUNaL0ssNEJBQWtCeUosTUFBTTRCLFNBQVMsS0FEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsaUNBQWdDO0FBQUE7QUFBQSxVQUFRRDtBQUFBQSxhQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZEO0FBQUEsUUFDNUQzQixNQUFNNkIsZUFBZTdCLE1BQU04QixjQUMxQix1QkFBQyxTQUFJLFdBQVUsbUNBQ1pDO0FBQUFBLGVBQUtDLFVBQVVoQyxNQUFNNkIsV0FBVztBQUFBLFVBQUU7QUFBQSxVQUFJRSxLQUFLQyxVQUFVaEMsTUFBTThCLFVBQVU7QUFBQSxhQUR4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVEOUIsTUFBTWlDLFlBQ0wsdUJBQUMsU0FBSSxXQUFVLCtCQUNaRixlQUFLQyxVQUFVaEMsTUFBTWlDLFFBQVEsS0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FkSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsSUFFSjtBQUFBLElBRUEsS0FBSyxjQUFjO0FBQ2pCLFlBQU12QixJQUFJUyxLQUFLOUo7QUFDZixZQUFNc0ssUUFBUUgsZ0JBQWdCZCxFQUFFN0YsV0FBVzZGLEVBQUU1RixlQUFnQjRGLEVBQUV3QixZQUFrQztBQUNqRyxhQUNFLHVCQUFDLFNBQUksV0FBVzlCLHNCQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBCQUEwQmtCLGtCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsUUFDOUMsdUJBQUMsU0FBSSxXQUFVLGdDQUNaWjtBQUFBQSxZQUFFeUI7QUFBQUEsVUFBVztBQUFBLFVBQUl6QixFQUFFL0Y7QUFBQUEsVUFBUztBQUFBLFVBQUlnSDtBQUFBQSxhQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNDakIsRUFBRTNGLFVBQVUsdUJBQUMsU0FBSSxXQUFVLGlDQUFpQzJGLFlBQUUzRixVQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlEO0FBQUEsV0FMeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsSUFFSjtBQUFBLElBRUEsS0FBSyxXQUFXO0FBQ2QsWUFBTTZGLElBQUlPLEtBQUs5SjtBQUNmLFlBQU0rSyxTQUFTeEIsRUFBRTNHLGlCQUFpQjJHLEVBQUV5QixnQkFBZ0JoSixTQUFTc0UsSUFBSWlELEVBQUV5QixhQUFhLEdBQUczQyxPQUFPLFNBQVM7QUFDbkcsYUFDRSx1QkFBQyxTQUFJLFdBQVdVLHNCQUNkO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBCQUEwQmtCLGtCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsUUFDOUMsdUJBQUMsU0FBSSxXQUFVLGdDQUFnQ2M7QUFBQUE7QUFBQUEsVUFBTztBQUFBLFVBQUl4QixFQUFFMUc7QUFBQUEsYUFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRTtBQUFBLFFBQ2pFLHVCQUFDLFNBQUksV0FBVSx5REFDWjBHO0FBQUFBLFlBQUV6RyxRQUFROEIsTUFBTSxHQUFHLEdBQUc7QUFBQSxVQUFHMkUsRUFBRXpHLFFBQVEyQixTQUFTLE1BQU0sUUFBUTtBQUFBLGFBRDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsSUFFSjtBQUFBLElBRUEsS0FBSyxPQUFPO0FBQ1YsWUFBTStFLElBQUlNLEtBQUs5SjtBQUNmLFlBQU1xRyxRQUFRckUsU0FBU3NFLElBQUlrRCxFQUFFeUIsT0FBTztBQUNwQyxZQUFNQyxXQUFXMUIsRUFBRTJCLGFBQWEsSUFBSTNCLEVBQUUyQixhQUFhLEtBQU01RCxRQUFRLENBQUMsQ0FBQyxNQUFNO0FBQ3pFLGFBQ0UsdUJBQUMsU0FBSSxXQUFXd0Isc0JBQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMEJBQTBCa0Isa0JBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUM5Qyx1QkFBQyxTQUFJLFdBQVUsZ0NBQThCO0FBQUE7QUFBQSxVQUNuQzVELE9BQU9nQyxRQUFRO0FBQUEsVUFBUTtBQUFBLFVBQUltQixFQUFFeEs7QUFBQUEsYUFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsaUNBQ1p3SztBQUFBQSxZQUFFNEI7QUFBQUEsVUFBTTtBQUFBLFVBQUlGO0FBQUFBLFVBQVM7QUFBQSxVQUFPMUIsRUFBRTZCLFFBQVE5RCxRQUFRLENBQUM7QUFBQSxhQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLElBRUo7QUFBQSxJQUVBLEtBQUssWUFBWTtBQUNmLFlBQU1tQyxLQUFLSSxLQUFLOUo7QUFDaEIsWUFBTXFHLFFBQVFyRSxTQUFTc0UsSUFBSW9ELEdBQUd1QixPQUFPO0FBQ3JDLGFBQ0UsdUJBQUMsU0FBSSxXQUFXbEMsc0JBQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMEJBQTBCa0Isa0JBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUM5Qyx1QkFBQyxTQUFJLFdBQVUsZ0NBQ1o1RDtBQUFBQSxpQkFBT2dDLFFBQVE7QUFBQSxVQUFRO0FBQUEsVUFBSXFCLEdBQUc0QjtBQUFBQSxhQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLGlDQUFDLGFBQVUsT0FBTzVCLEdBQUc5RCxhQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQjtBQUFBLFVBQUc7QUFBQSxVQUFJOEQsR0FBRzFLO0FBQUFBLFVBQ3hDMEssR0FBRzZCLGdCQUFnQixNQUFNN0IsR0FBRzZCLGFBQWEzRyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsYUFGeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxJQUVKO0FBQUEsSUFFQSxLQUFLLFlBQVk7QUFDZixZQUFNekMsSUFBSTJILEtBQUs5SjtBQUNmLFlBQU1xRyxRQUFRckUsU0FBU3NFLElBQUluRSxFQUFFb0QsZ0JBQWdCO0FBQzdDLGFBQ0UsdUJBQUMsU0FBSSxXQUFXd0Qsc0JBQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMEJBQTBCa0Isa0JBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUM5Qyx1QkFBQyxTQUFJLFdBQVUsZ0NBQThCO0FBQUE7QUFBQSxVQUNoQyx1QkFBQyxlQUFZLE1BQU1oTCxtQkFBbUJrRCxFQUFFbkQsTUFBTSxHQUFJRSw0QkFBa0JpRCxFQUFFbkQsTUFBTSxLQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RTtBQUFBLGFBRDNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGlDQUNabUQ7QUFBQUEsWUFBRXdEO0FBQUFBLFVBQWM7QUFBQSxVQUFJVSxPQUFPZ0MsUUFBUTtBQUFBLGFBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsSUFFSjtBQUFBLElBRUEsS0FBSyxZQUFZO0FBQ2YsWUFBTXNCLFdBQVdHLEtBQUs5SjtBQUN0QixZQUFNc0ssUUFBUUgsZ0JBQWdCUixTQUFTbkcsV0FBV21HLFNBQVNTLE9BQU87QUFDbEUsYUFDRSx1QkFBQyxTQUFJLFdBQVdyQixzQkFDZDtBQUFBLCtCQUFDLFNBQUksV0FBVSwwQkFBMEJrQixrQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QztBQUFBLFFBQzlDLHVCQUFDLFNBQUksV0FBVSxnQ0FBOEI7QUFBQTtBQUFBLFVBQ2xDTixTQUFTNkI7QUFBQUEsVUFBTztBQUFBLFVBQUlsQjtBQUFBQSxhQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxxREFDWlgsbUJBQVN4RCxlQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsSUFFSjtBQUFBLElBRUE7QUFDRSxhQUFPO0FBQUEsRUFDWDtBQUNGO0FBSUFzRixNQWpKU3pCO0FBbUpULFNBQVMwQixhQUFhO0FBQUEsRUFDcEJyTDtBQUFBQSxFQUNBTztBQUlGLEdBQUc7QUFDRCxRQUFNK0ssbUJBQW1CL0ssU0FBU3VILE9BQU8sQ0FBQW9CLE1BQUtBLEVBQUUxRyxTQUFTLGNBQWMwRyxFQUFFcUMsU0FBUztBQUVsRixTQUNFLHVCQUFDLFNBQUksV0FBVSxhQUNadkw7QUFBQUEsU0FBS3lGLGVBQ0osdUJBQUMsV0FBUSxPQUFNLGVBQ1p6RjtBQUFBQSxXQUFLeUYsWUFBWUMsV0FDaEIsdUJBQUMsT0FBRSxXQUFVLG1DQUFtQzFGLGVBQUt5RixZQUFZQyxXQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlFO0FBQUEsTUFFMUUxRixLQUFLeUYsWUFBWTBCLGVBQWVuSCxLQUFLeUYsWUFBWTBCLFlBQVkvQyxTQUFTLEtBQ3JFLHVCQUFDLFNBQUksV0FBVSx3QkFDWnBFLGVBQUt5RixZQUFZMEIsWUFBWXRGO0FBQUFBLFFBQUksQ0FBQ2tFLE9BQ2pDLHVCQUFDLGVBQXFCLE1BQUssV0FBVSxXQUFVLGFBQWFBLGdCQUExQ0EsSUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRDtBQUFBLE1BQ2hFLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsU0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUdEdUYsaUJBQWlCbEgsU0FBUyxLQUN6Qix1QkFBQyxXQUFRLE9BQU0scUJBQ1prSCwyQkFBaUJ6SjtBQUFBQSxNQUFJLENBQUNxSCxNQUNyQix1QkFBQyxTQUFnQixXQUFVLHVEQUN6QjtBQUFBLCtCQUFDLFNBQUksV0FBVSxpQ0FDWixjQUFJdkcsS0FBTXVHLEVBQVVELGFBQWEsRUFBRXVDLGVBQWUsS0FEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQ3RDLEVBQUVxQyxhQUFhckMsRUFBRXFDLFVBQVVuSCxTQUFTLEtBQ25DLHVCQUFDLFNBQUksV0FBVSwrQkFDWjhFLFlBQUVxQyxVQUFVMUo7QUFBQUEsVUFBSSxDQUFDQyxHQUFRNkUsTUFDeEIsdUJBQUMsZUFBb0IsTUFBSyxXQUFXN0UsWUFBRWtHLFFBQXJCckIsR0FBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEM7QUFBQSxRQUM3QyxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBVE11QyxFQUFFbkgsS0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxJQUNELEtBZEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsSUFHRCxDQUFDL0IsS0FBS3lGLGVBQWU2RixpQkFBaUJsSCxXQUFXLEtBQ2hELHVCQUFDLE9BQUUsV0FBVSwwQkFBeUIsZ0NBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0Q7QUFBQSxPQXBDMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNDQTtBQUVKO0FBSUFxSCxNQXREU0o7QUF3RFQsU0FBU0ssYUFBYTtBQUFBLEVBQ3BCMUs7QUFBQUEsRUFDQVc7QUFJRixHQUFHO0FBQUFnSyxNQUFBO0FBQ0QsUUFBTUMsVUFBVTVPLFlBQVlFLElBQUk4RCxVQUFVNEssT0FBTztBQUNqRCxRQUFNQyxPQUFPN08sWUFBWUUsSUFBSThELFVBQVU2SyxJQUFJO0FBQzNDLFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSTNPLFNBQWlDLENBQUMsQ0FBQztBQUNqRixRQUFNLENBQUM0TyxnQkFBZ0JDLGlCQUFpQixJQUFJN08sU0FBd0IsSUFBSTtBQUV4RSxNQUFJNEQsVUFBVW9ELFdBQVcsR0FBRztBQUMxQixXQUFPLHVCQUFDLE9BQUUsV0FBVSwwQkFBeUIsMENBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0U7QUFBQSxFQUN6RTtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGFBQ1pwRCxvQkFBVWEsSUFBSSxDQUFDQyxNQUFNO0FBQ3BCLFVBQU1rRSxRQUFRckUsU0FBU3NFLElBQUluRSxFQUFFb0QsZ0JBQWdCO0FBQzdDLFdBQ0UsdUJBQUMsU0FBZ0IsV0FBVSxrREFDekI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSwrQkFBQyxVQUFLLFdBQVUsMEJBQ2JjO0FBQUFBLGlCQUFPZ0MsUUFBUTtBQUFBLFVBQVE7QUFBQSxVQUFJbEcsRUFBRXVEO0FBQUFBLFVBQVc7QUFBQSxVQUFHLHVCQUFDLGFBQVUsT0FBT3ZELEVBQUV5RCxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QjtBQUFBLGFBRDVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsZUFBWSxNQUFNM0csbUJBQW1Ca0QsRUFBRW5ELE1BQU0sR0FBSUUsNEJBQWtCaUQsRUFBRW5ELE1BQU0sS0FBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RTtBQUFBLFdBSmhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUF1Q21ELFlBQUV3RCxpQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRTtBQUFBLE1BQ3JFeEQsRUFBRTBELGlCQUNELHVCQUFDLFNBQUksV0FBVSwrQkFBK0IxRCxZQUFFMEQsaUJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEQ7QUFBQSxNQUUvRDFELEVBQUVvSyxrQkFDRCx1QkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSwrQkFBQyxZQUFPLHlCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUI7QUFBQSxRQUFTO0FBQUEsUUFBRXBLLEVBQUVvSztBQUFBQSxXQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVELENBQUMsV0FBVyxXQUFXLEVBQUVsSCxTQUFTbEQsRUFBRW5ELE1BQU0sS0FDekMsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU9tTixnQkFBZ0JoSyxFQUFFQyxHQUFHLEtBQUs7QUFBQSxZQUNqQyxVQUFVLENBQUN1RyxVQUNUeUQsbUJBQW1CLENBQUNJLGFBQWE7QUFBQSxjQUMvQixHQUFHQTtBQUFBQSxjQUNILENBQUNySyxFQUFFQyxHQUFHLEdBQUd1RyxNQUFNOUQsT0FBT0M7QUFBQUEsWUFDeEIsRUFBRTtBQUFBLFlBRUosYUFBWTtBQUFBLFlBQ1osY0FBWSx1QkFBdUIzQyxFQUFFd0QsYUFBYTtBQUFBLFlBQ2xELFdBQVU7QUFBQTtBQUFBLFVBVlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVW9LO0FBQUEsUUFFcEssdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsVUFDRTBHLG1CQUFtQmxLLEVBQUVDLE9BQU8sRUFBRStKLGdCQUFnQmhLLEVBQUVDLEdBQUcsS0FBSyxJQUFJTSxLQUFLO0FBQUEsY0FFbkUsU0FBUyxZQUFZO0FBQ25CNEosa0NBQWtCbkssRUFBRUMsR0FBRztBQUN2QixvQkFBSTtBQUNGLHdCQUFNbUIsU0FBUyxNQUFNMEksUUFBUTtBQUFBLG9CQUMzQlEsWUFBWXRLLEVBQUVDO0FBQUFBLG9CQUNkc0ssaUJBQWlCO0FBQUEsb0JBQ2pCaEosUUFBUXlJLGdCQUFnQmhLLEVBQUVDLEdBQUcsRUFBRU0sS0FBSztBQUFBLGtCQUN0QyxDQUFDO0FBQ0Qsc0JBQUksQ0FBQ2EsT0FBT0ksUUFBUzhCLFFBQU81QixNQUFNTixPQUFPSCxTQUFTLGtCQUFrQjtBQUFBLGdCQUN0RSxVQUFDO0FBQ0NrSixvQ0FBa0IsSUFBSTtBQUFBLGdCQUN4QjtBQUFBLGNBQ0Y7QUFBQSxjQUFFO0FBQUE7QUFBQSxZQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFvQkE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFRO0FBQUEsY0FDUixVQUNFRCxtQkFBbUJsSyxFQUFFQyxPQUFPLEVBQUUrSixnQkFBZ0JoSyxFQUFFQyxHQUFHLEtBQUssSUFBSU0sS0FBSztBQUFBLGNBRW5FLFNBQVMsWUFBWTtBQUNuQjRKLGtDQUFrQm5LLEVBQUVDLEdBQUc7QUFDdkIsb0JBQUk7QUFDRix3QkFBTW1CLFNBQVMsTUFBTTJJLEtBQUs7QUFBQSxvQkFDeEJPLFlBQVl0SyxFQUFFQztBQUFBQSxvQkFDZHNLLGlCQUFpQjtBQUFBLG9CQUNqQmhKLFFBQVF5SSxnQkFBZ0JoSyxFQUFFQyxHQUFHLEVBQUVNLEtBQUs7QUFBQSxrQkFDdEMsQ0FBQztBQUNELHNCQUFJLENBQUNhLE9BQU9JLFFBQVM4QixRQUFPNUIsTUFBTU4sT0FBT0gsU0FBUyxtQkFBbUI7QUFBQSxnQkFDdkUsVUFBQztBQUNDa0osb0NBQWtCLElBQUk7QUFBQSxnQkFDeEI7QUFBQSxjQUNGO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFsQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBcUJBO0FBQUEsYUEzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRDQTtBQUFBLFdBekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwREE7QUFBQSxTQTNFTW5LLEVBQUVDLEtBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZFQTtBQUFBLEVBRUosQ0FBQyxLQW5GSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0ZBO0FBRUo7QUFJQTRKLElBM0dTRCxjQUFZO0FBQUEsVUFPSDFPLGFBQ0hBLFdBQVc7QUFBQTtBQUFBLE1BUmpCME87QUE2R1QsU0FBU1ksUUFBUTtBQUFBLEVBQ2Z0TTtBQUFBQSxFQUNBdUI7QUFJRixHQUFHO0FBQ0QsUUFBTWdMLGVBQWVoTCxLQUFLaUwsT0FBTyxDQUFDQyxLQUFLdEQsTUFBTXNELE1BQU10RCxFQUFFNkIsU0FBUyxDQUFDO0FBQy9ELFFBQU0wQixnQkFBZ0JuTCxLQUFLdUcsT0FBTyxDQUFBcUIsTUFBS0EsRUFBRXhLLFdBQVcsV0FBVztBQUMvRCxRQUFNZ08sYUFBYXBMLEtBQUt1RyxPQUFPLENBQUFxQixNQUFLQSxFQUFFeEssV0FBVyxRQUFRO0FBRXpELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwyQkFBQyxXQUFRLE9BQU0sVUFDYixpQ0FBQyxTQUFJLFdBQVUsd0JBQ1pxQjtBQUFBQSxXQUFLNE0sbUJBQ0osdUJBQUMsUUFBSyxPQUFNLGFBQVksT0FBTyxJQUFJNU0sS0FBSzRNLGdCQUFnQjFGLFFBQVEsQ0FBQyxDQUFDLE1BQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUU7QUFBQSxNQUV2RSx1QkFBQyxRQUFLLE9BQU0sZUFBYyxPQUFPLElBQUlsSCxLQUFLNk0sV0FBVzNGLFFBQVEsQ0FBQyxDQUFDLE1BQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0U7QUFBQSxNQUNqRWxILEtBQUs4TSxvQkFBb0IzTCxVQUN4QjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTTtBQUFBLFVBQ04sT0FBTyxJQUFJbkIsS0FBSzhNLGdCQUFnQjVGLFFBQVEsQ0FBQyxDQUFDO0FBQUEsVUFDMUMsVUFBVWxILEtBQUs4TSxrQkFBa0I7QUFBQTtBQUFBLFFBSG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdxQztBQUFBLFNBVHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLElBRUEsdUJBQUMsV0FBUSxPQUFNLFFBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSwrQkFBQyxRQUFLLE9BQU0sY0FBYSxPQUFPdkwsS0FBSzZDLE9BQU8ySSxTQUFTLEtBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUQ7QUFBQSxRQUN2RCx1QkFBQyxRQUFLLE9BQU0sYUFBWSxPQUFPTCxjQUFjdEksT0FBTzJJLFNBQVMsS0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRDtBQUFBLFFBQy9ELHVCQUFDLFFBQUssT0FBTSxVQUFTLE9BQU9KLFdBQVd2SSxPQUFPMkksU0FBUyxLQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlEO0FBQUEsUUFDekQsdUJBQUMsUUFBSyxPQUFNLFlBQVcsT0FBTyxJQUFJUixhQUFhckYsUUFBUSxDQUFDLENBQUMsTUFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RDtBQUFBLFdBSjlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BRUMzRixLQUFLNkMsU0FBUyxLQUNiLHVCQUFDLFNBQUksV0FBVSxhQUNaN0MsZUFBS2dELE1BQU0sR0FBRyxFQUFFeUksUUFBUSxFQUFFbkw7QUFBQUEsUUFBSSxDQUFDc0gsTUFDOUIsdUJBQUMsU0FBZ0IsV0FBVSwwREFDekI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsa0JBQWtCQSxZQUFFNEIsU0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEM7QUFBQSxZQUMxQyx1QkFBQyxVQUFLLFdBQVUsd0JBQXVCO0FBQUE7QUFBQSxjQUFFNUIsRUFBRTZCLFFBQVE5RCxRQUFRLENBQUM7QUFBQSxpQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEQ7QUFBQSxlQUZoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ1ppQztBQUFBQSxjQUFFOEQsWUFBWXpCLGVBQWU7QUFBQSxZQUFFO0FBQUEsWUFBT3JDLEVBQUUrRCxhQUFhMUIsZUFBZTtBQUFBLFlBQUU7QUFBQSxZQUN0RXJDLEVBQUUyQixjQUFjLE9BQU8zQixFQUFFMkIsYUFBYSxLQUFNNUQsUUFBUSxDQUFDLENBQUM7QUFBQSxlQUZ6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFSUWlDLEVBQUVwSCxLQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLE1BQ0QsS0FaSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxTQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0JBO0FBQUEsT0F6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBDQTtBQUVKO0FBSUFvTCxNQTVEU2I7QUE4RFQsU0FBU2MsT0FBTztBQUFBLEVBQ2RwTjtBQUFBQSxFQUNBMkI7QUFBQUEsRUFDQUw7QUFLRixHQUFHO0FBQUErTCxNQUFBO0FBQ0QsUUFBTUMsWUFBWXROLEtBQUttRixZQUNwQnRELElBQUksQ0FBQ2tFLE9BQXFCcEUsU0FBU3NFLElBQUlGLEVBQUUsQ0FBQyxFQUMxQytCLE9BQU8sQ0FBQzlCLFVBQWtDLENBQUMsQ0FBQ0EsS0FBSztBQUNwRCxRQUFNdUgscUJBQXFCdFEsU0FBU0MsSUFBSTBDLE1BQU00Tiw2QkFBNkI7QUFDM0UsUUFBTSxDQUFDQyxrQkFBa0JDLG1CQUFtQixJQUFJdFEsU0FBMEIsRUFBRTtBQUU1RSxRQUFNdVEsb0JBQXFCSixxQkFBcUJ2TixLQUFLckIsTUFBTSxLQUFrQztBQUM3RnhCLFlBQVUsTUFBTTtBQUNkLFFBQUksQ0FBQ3NRLG9CQUFvQkUsa0JBQWtCdkosU0FBUyxHQUFHO0FBQ3JEc0osMEJBQW9CQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQUEsSUFDMUM7QUFBQSxFQUNGLEdBQUcsQ0FBQ0Ysa0JBQWtCRSxpQkFBaUIsQ0FBQztBQUV4QyxRQUFNQyx1QkFBdUIzUTtBQUFBQSxJQUMzQkMsSUFBSTBDLE1BQU1pTztBQUFBQSxJQUNWSixtQkFDSTtBQUFBLE1BQ0V6TyxRQUFRZ0IsS0FBSytCO0FBQUFBLE1BQ2JrQixVQUFVd0s7QUFBQUEsTUFDVnRLLFdBQVc7QUFBQSxNQUNYMkssYUFBYSxDQUFDLENBQUM5TixLQUFLOEc7QUFBQUEsTUFDcEJpSCxnQkFBZ0IsQ0FBQyxDQUFDL04sS0FBS3lGO0FBQUFBLE1BQ3ZCdUksY0FBYyxDQUFDLENBQUNoTyxLQUFLaU87QUFBQUEsSUFDdkIsSUFDQTtBQUFBLEVBQ047QUFFQSxRQUFNQyxpQkFBaUJqUixTQUFTQyxJQUFJaVIsT0FBT0MsbUJBQW1CO0FBQUEsSUFDNURwUCxRQUFRZ0IsS0FBSytCO0FBQUFBLElBQ2JzTSxxQkFBcUJaLG9CQUFvQnRNO0FBQUFBLElBQ3pDOEYsZUFBZWpILEtBQUtpSDtBQUFBQSxFQUN0QixDQUFDO0FBRUQsUUFBTTFCLFlBQVkySSxnQkFBZ0IzSSxhQUFhO0FBRS9DLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwyQkFBQyxhQUNDO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHVDQUFzQyxzQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRTtBQUFBLE1BQzFFLHVCQUFDLFNBQUksV0FBVSxrREFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLGlDQUFDLGFBQVUsT0FBT0EsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEI7QUFBQSxVQUM1QjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTTJJLGdCQUFnQkksYUFBYSxVQUFVLFlBQVlKLGdCQUFnQkksYUFBYSxTQUFTLFVBQVU7QUFBQSxjQUV4R0osMEJBQWdCSSxZQUFZO0FBQUE7QUFBQSxZQUgvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsbUNBQ1ZKLDBCQUFnQjdLLFVBQVUsbUNBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0M2SyxnQkFBZ0JLLGtCQUFrQkwsZUFBZUssZUFBZW5LLFNBQVMsS0FDeEUsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsaUNBQWdDLCtCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RDtBQUFBLFVBQzlELHVCQUFDLFNBQUksV0FBVSwwQkFDWjhKLHlCQUFlSyxlQUFlMU07QUFBQUEsWUFBSSxDQUFDMk0sU0FDbEMsdUJBQUMsZUFBdUIsTUFBSyxXQUFVLFdBQVUsYUFBYUEsa0JBQTVDQSxNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRTtBQUFBLFVBQ3BFLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFFRE4sZ0JBQWdCTyxtQkFBbUJySyxTQUNsQyx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxpQ0FBZ0Msa0NBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlFO0FBQUEsVUFDaEU4SixlQUFlTyxrQkFBa0I1TTtBQUFBQSxZQUFJLENBQUNpRCxVQUE0QzRKLFVBQ2pGLHVCQUFDLFNBQXNDLFdBQVUsbUNBQWlDO0FBQUE7QUFBQSxjQUM3RTVKLFNBQVN0QztBQUFBQSxjQUFLO0FBQUEsY0FBR3NDLFNBQVN6QjtBQUFBQSxpQkFEckIsR0FBR3lCLFNBQVN0QyxJQUFJLElBQUlrTSxLQUFLLElBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxVQUNEO0FBQUEsYUFOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0EsSUFDRTtBQUFBLFFBQ0hSLGdCQUFnQlMsa0JBQWtCdkssU0FDakMsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsaUNBQWdDLGlDQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRTtBQUFBLFVBQy9EOEosZUFBZVMsaUJBQWlCOU07QUFBQUEsWUFBSSxDQUFDK00sTUFBY0YsVUFDbEQsdUJBQUMsU0FBNkIsV0FBVSxtQ0FBaUM7QUFBQTtBQUFBLGNBQ3BFRTtBQUFBQSxpQkFESyxHQUFHQSxJQUFJLElBQUlGLEtBQUssSUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFVBQ0Q7QUFBQSxhQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQSxJQUNFO0FBQUEsV0F6Q047QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBDQTtBQUFBLFNBNUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2Q0E7QUFBQSxJQUVBLHVCQUFDLGFBQ0M7QUFBQSw2QkFBQyxRQUFHLFdBQVUsdUNBQXNDLGtDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNFO0FBQUEsTUFDdEUsdUJBQUMsU0FBSSxXQUFVLGtEQUNaZiw0QkFBa0J2SixTQUFTLElBQzFCLG1DQUNFO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLDBCQUF5QixtQ0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEQ7QUFBQSxVQUM1RDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT3FKO0FBQUFBLGNBQ1AsVUFBVSxDQUFDbkYsVUFBVW9GLG9CQUFvQnBGLE1BQU05RCxPQUFPQyxLQUFtQjtBQUFBLGNBQ3pFLFdBQVU7QUFBQSxjQUVUa0osNEJBQWtCOUw7QUFBQUEsZ0JBQUksQ0FBQ2dOLFdBQ3RCLHVCQUFDLFlBQW9CLE9BQU9BLFFBQ3pCN087QUFBQUEsdUJBQUtyQjtBQUFBQSxrQkFBTztBQUFBLGtCQUFJa1E7QUFBQUEscUJBRE5BLFFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGNBQ0Q7QUFBQTtBQUFBLFlBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxhQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBRUNqQix1QkFDQyxtQ0FDRTtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixPQUFPQSxxQkFBcUJrQixRQUFRLFVBQVU7QUFBQSxjQUM5QyxRQUFRbEIscUJBQXFCa0IsUUFBUSxnQ0FBZ0M7QUFBQTtBQUFBLFlBSHZFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUdtRztBQUFBLFVBRW5HO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixPQUFPbEIscUJBQXFCeks7QUFBQUEsY0FDNUIsUUFBTztBQUFBO0FBQUEsWUFIVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFHcUQ7QUFBQSxVQUVwRHlLLHFCQUFxQm1CLGdCQUNwQjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sT0FBTztBQUFBLGdCQUNMbkIscUJBQXFCbUIsYUFBYUMsbUJBQW1CLGNBQWM7QUFBQSxnQkFDbkVwQixxQkFBcUJtQixhQUFhRSxzQkFBc0IsZ0JBQWdCO0FBQUEsZ0JBQ3hFckIscUJBQXFCbUIsYUFBYUcsb0JBQW9CLGNBQWM7QUFBQSxnQkFDcEV0QixxQkFBcUJtQixhQUFhSSxZQUFZLGVBQWU7QUFBQSxjQUFJLEVBRWhFckgsT0FBT3NILE9BQU8sRUFDZDFMLEtBQUssSUFBSSxLQUFLO0FBQUE7QUFBQSxZQVRuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTMEI7QUFBQSxVQUczQmtLLHFCQUFxQnJLLFFBQVFhLFNBQzVCLHVCQUFDLFNBQUksV0FBVSxRQUNad0osK0JBQXFCckssT0FBTzFCO0FBQUFBLFlBQUksQ0FBQ2tCLFVBQ2hDLHVCQUFDLFNBQTRDLFdBQVUseUJBQXVCO0FBQUE7QUFBQSxjQUN6RUEsTUFBTXNNO0FBQUFBLGNBQU07QUFBQSxjQUFHdE0sTUFBTVU7QUFBQUEsaUJBRGhCLEdBQUdWLE1BQU1zTSxLQUFLLElBQUl0TSxNQUFNVSxPQUFPLElBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxVQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQSxJQUNFO0FBQUEsYUFoQ047QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlDQSxJQUVBLHVCQUFDLFNBQUksV0FBVSwwQkFBeUIscUNBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkQ7QUFBQSxXQXBEakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNEQSxJQUVBLHVCQUFDLFNBQUksV0FBVSwwQkFBd0I7QUFBQTtBQUFBLFFBQ0F6RCxLQUFLckI7QUFBQUEsUUFBTztBQUFBLFdBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxLQTVESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOERBO0FBQUEsU0FoRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlFQTtBQUFBLElBRUEsdUJBQUMsYUFDQztBQUFBLDZCQUFDLFFBQUcsV0FBVSx1Q0FBc0Msa0NBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0U7QUFBQSxNQUN0RSx1QkFBQyxTQUFJLFdBQVUsa0RBQ1oyTyxvQkFBVWxKLFNBQ1RrSixVQUFVekw7QUFBQUEsUUFBSSxDQUFDbUUsVUFDYix1QkFBQyxTQUFvQixXQUFVLFVBQzdCO0FBQUEsaUNBQUMsY0FBVyxPQUFNLFNBQVEsT0FBT0EsTUFBTWdDLFFBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRDO0FBQUEsVUFDNUMsdUJBQUMsY0FBVyxPQUFNLFFBQU8sT0FBT2hDLE1BQU13QyxRQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQztBQUFBLFVBQzNDLHVCQUFDLGNBQVcsT0FBTSxVQUFTLE9BQU94QyxNQUFNckgsVUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0M7QUFBQSxVQUMvQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sT0FBT3FILE1BQU1zSixpQkFBaUJsTCxTQUFTNEIsTUFBTXNKLGlCQUFpQjVMLEtBQUssSUFBSSxJQUFJO0FBQUEsY0FDM0UsUUFBUXNDLE1BQU1zSixpQkFBaUJ0SyxTQUFTaEYsS0FBS3dDLElBQUksSUFBSSxzQkFBc0I7QUFBQTtBQUFBLFlBSDdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUdvRztBQUFBLGFBUDVGd0QsTUFBTWpFLEtBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLE1BQ0QsSUFFRCx1QkFBQyxPQUFFLFdBQVUsMEJBQXdCLDhHQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQTtBQUFBLFNBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQkE7QUFBQSxJQUVBLHVCQUFDLGFBQ0M7QUFBQSw2QkFBQyxRQUFHLFdBQVUsdUNBQXNDLCtCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1FO0FBQUEsTUFDbkUsdUJBQUMsU0FBSSxXQUFVLDhEQUNiO0FBQUEsK0JBQUMsY0FBVyxPQUFNLFFBQU8sT0FBTy9CLEtBQUt3QyxNQUFNLFFBQU8sMERBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0c7QUFBQSxRQUN4Ryx1QkFBQyxjQUFXLE9BQU0sWUFBVyxPQUFPLElBQUl4QyxLQUFLNEQsUUFBUSxJQUFJLFFBQU8sd0RBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0g7QUFBQSxRQUNwSDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sUUFBUUcsY0FBYy9ELEtBQUs2RCxVQUFVLEVBQUUsS0FBS0UsY0FBY0MsU0FBU0U7QUFBQUEsWUFDbkUsUUFBUWxFLEtBQUtpRSxZQUFZLFFBQVFqRSxLQUFLaUUsU0FBUyxLQUFNakUsS0FBS3dHLFlBQVksZUFBZStJLGtCQUFrQnZQLEtBQUt3RyxTQUFTLEtBQUt4RyxLQUFLd0csU0FBUyxLQUFLO0FBQUE7QUFBQSxVQUgvSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHa0w7QUFBQSxRQUVsTDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sT0FBTyxJQUFJN0QsS0FBSzNDLEtBQUtpSixhQUFhLEVBQUU5QyxtQkFBbUI7QUFBQSxZQUN2RCxRQUFRLElBQUl4RCxLQUFLM0MsS0FBS2lKLGFBQWEsRUFBRXVDLGVBQWU7QUFBQTtBQUFBLFVBSHREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUd3RDtBQUFBLFFBRXZEeEwsS0FBS3dQLGdCQUNKLHVCQUFDLGNBQVcsT0FBTSxlQUFjLE9BQU9DLE9BQU96UCxLQUFLd1AsWUFBWSxHQUFHLFFBQU8sK0NBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0g7QUFBQSxRQUVySHhQLEtBQUswUCxVQUFVMVAsS0FBSzBQLE9BQU90TCxTQUFTLEtBQ25DLHVCQUFDLGNBQVcsT0FBTSxVQUFTLE9BQU9wRSxLQUFLMFAsT0FBT2hNLEtBQUssSUFBSSxLQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlEO0FBQUEsUUFFM0Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE9BQU8rTCxPQUFPbk8sWUFBWThDLE1BQU07QUFBQSxZQUNoQyxRQUFROUMsWUFBWThDLFNBQVMsaUNBQWlDO0FBQUE7QUFBQSxVQUhoRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHcUY7QUFBQSxXQXRCdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdCQTtBQUFBLFNBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQkE7QUFBQSxPQXRLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUtBO0FBRUo7QUFJQWlKLElBMU5TRCxRQUFNO0FBQUEsVUFZY25RLFVBVUVBLFVBY05BLFFBQVE7QUFBQTtBQUFBLE1BcEN4Qm1RO0FBNE5ULFNBQVN1QyxVQUFVO0FBQUEsRUFDakJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBS0YsR0FBRztBQUNELFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE1BQUs7QUFBQSxNQUNMLGlCQUFlRjtBQUFBQSxNQUNmO0FBQUEsTUFDQSxXQUFXdlM7QUFBQUEsUUFDVDtBQUFBLFFBQ0F1UyxTQUNJLHdCQUNBO0FBQUEsTUFDTjtBQUFBLE1BRUNFO0FBQUFBO0FBQUFBLElBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBWUE7QUFFSjtBQUFDQyxPQXhCUUo7QUEwQlQsU0FBU0ssUUFBUSxFQUFFM08sT0FBT3lPLFNBQXVELEdBQUc7QUFDbEYsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxXQUFVLHNFQUNYek8sbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQ3lPO0FBQUFBLE9BSkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtBO0FBRUo7QUFBQ0csT0FUUUQ7QUFXVCxTQUFTRSxXQUFXO0FBQUEsRUFDbEJoTTtBQUFBQSxFQUNBTztBQUFBQSxFQUNBMEw7QUFLRixHQUFHO0FBQ0QsU0FDRSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSwyQkFBQyxVQUFLLFdBQVUsNkNBQTZDak0sbUJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUU7QUFBQSxJQUNuRSx1QkFBQyxVQUFLLFdBQVUsZ0NBQWdDTyxtQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRDtBQUFBLElBQ3JEMEwsVUFDQyx1QkFBQyxVQUFLLFdBQVUsaUNBQWdDO0FBQUE7QUFBQSxNQUFHQTtBQUFBQSxTQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBEO0FBQUEsT0FKOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BO0FBRUo7QUFBQ0MsT0FsQlFGO0FBb0JULFNBQVNHLEtBQUs7QUFBQSxFQUNabk07QUFBQUEsRUFDQU87QUFBQUEsRUFDQTZMO0FBS0YsR0FBRztBQUNELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGtEQUNiO0FBQUEsMkJBQUMsVUFBSyxXQUFVLGdDQUFnQ3BNLG1CQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNEO0FBQUEsSUFDdEQsdUJBQUMsVUFBSyxXQUFXN0csR0FBRyx5QkFBeUJpVCxXQUFXLGFBQWEsVUFBVSxHQUM1RTdMLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtBO0FBRUo7QUFJQThMLE9BckJTRjtBQXVCVCxNQUFNdE0sZ0JBQW1EO0FBQUEsRUFDdkR5TSxXQUFXLEVBQUV0TSxPQUFPLFlBQVk7QUFBQSxFQUNoQ3VNLFVBQVUsRUFBRXZNLE9BQU8sV0FBVztBQUFBLEVBQzlCd00sUUFBUSxFQUFFeE0sT0FBTyxTQUFTO0FBQUEsRUFDMUJ5TSxPQUFPLEVBQUV6TSxPQUFPLFFBQVE7QUFBQSxFQUN4QjBNLEtBQUssRUFBRTFNLE9BQU8sTUFBTTtBQUFBLEVBQ3BCMk0sUUFBUSxFQUFFM00sT0FBTyxTQUFTO0FBQUEsRUFDMUI0TSxNQUFNLEVBQUU1TSxPQUFPLFlBQVk7QUFBQSxFQUMzQjZNLGdCQUFnQixFQUFFN00sT0FBTyxVQUFVO0FBQUEsRUFDbkM4TSxZQUFZLEVBQUU5TSxPQUFPLGVBQWU7QUFBQSxFQUNwQ0YsU0FBUyxFQUFFRSxPQUFPLFVBQVU7QUFDOUI7QUFFQSxNQUFNcUwsb0JBQTRDO0FBQUEsRUFDaEQwQixPQUFPO0FBQUEsRUFDUE4sT0FBTztBQUFBLEVBQ1BPLFFBQVE7QUFDVjtBQUVBLFNBQVNDLFlBQVk7QUFBQSxFQUNuQnROO0FBQUFBLEVBQ0FJO0FBQUFBLEVBQ0F1QztBQUtGLEdBQUc7QUFDRCxRQUFNMUMsTUFBTUMsY0FBY0YsVUFBVSxFQUFFLEtBQUtFLGNBQWNDO0FBQ3pELFFBQU1vTixlQUFlN0Isa0JBQWtCL0ksYUFBYSxFQUFFLEtBQUs7QUFFM0QsU0FDRSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDZCQUFDLGVBQVksTUFBSyxXQUFXMUMsY0FBSUksU0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QztBQUFBLE1BQ3RDa04sZ0JBQ0MsdUJBQUMsVUFBSyxXQUFVLDBCQUF5QjtBQUFBO0FBQUEsUUFBSUE7QUFBQUEsV0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRDtBQUFBLFNBSDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0NuTixhQUNDLHVCQUFDLFNBQUksV0FBVSwwQkFBd0I7QUFBQTtBQUFBLE1BQ2hDLHVCQUFDLFVBQUssV0FBVSxnQ0FBZ0NBLHVCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBEO0FBQUEsU0FEakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBWUE7QUFFSjtBQUFDb04sT0EzQlFGO0FBQVcsSUFBQUcsSUFBQWpLLEtBQUFrSyxLQUFBQyxLQUFBL0ksS0FBQWlCLEtBQUEwQixLQUFBSyxLQUFBZ0csS0FBQXRFLEtBQUF1RSxLQUFBM0IsTUFBQUUsTUFBQUcsTUFBQUcsTUFBQWM7QUFBQSxhQUFBQyxJQUFBO0FBQUEsYUFBQWpLLEtBQUE7QUFBQSxhQUFBa0ssS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBL0ksS0FBQTtBQUFBLGFBQUFpQixLQUFBO0FBQUEsYUFBQTBCLEtBQUE7QUFBQSxhQUFBSyxLQUFBO0FBQUEsYUFBQWdHLEtBQUE7QUFBQSxhQUFBdEUsS0FBQTtBQUFBLGFBQUF1RSxLQUFBO0FBQUEsYUFBQTNCLE1BQUE7QUFBQSxhQUFBRSxNQUFBO0FBQUEsYUFBQUcsTUFBQTtBQUFBLGFBQUFHLE1BQUE7QUFBQSxhQUFBYyxNQUFBIiwibmFtZXMiOlsidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsImFwaSIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiY24iLCJCdXR0b24iLCJEcm9wZG93bk1lbnUiLCJEcm9wZG93bk1lbnVDaGVja2JveEl0ZW0iLCJEcm9wZG93bk1lbnVDb250ZW50IiwiRHJvcGRvd25NZW51SXRlbSIsIkRyb3Bkb3duTWVudUxhYmVsIiwiRHJvcGRvd25NZW51U2VwYXJhdG9yIiwiRHJvcGRvd25NZW51VHJpZ2dlciIsIlNoZWV0IiwiU2hlZXRDb250ZW50IiwiU2hlZXREZXNjcmlwdGlvbiIsIlNoZWV0SGVhZGVyIiwiU2hlZXRUaXRsZSIsIlBlZXJSZXZpZXdQYW5lbCIsIkV4cG9ydFJlcG9ydEJ1dHRvbiIsIlRhc2tFZGl0TW9kZSIsIlJpc2tCYWRnZSIsIlN0YXR1c0JhZGdlIiwiVmVyaWZpY2F0aW9uVHJhY2VQYW5lbCIsImJ1aWxkVmVyaWZpY2F0aW9uVHJhY2UiLCJ0YXNrU3RhdHVzVG9uZSIsInN0YXR1cyIsImFwcHJvdmFsU3RhdHVzVG9uZSIsImZvcm1hdFN0YXR1c0xhYmVsIiwicmVwbGFjZSIsIlRhc2tEcmF3ZXJUYWJzIiwidGFza0lkIiwib25DbG9zZSIsIl9zIiwiYWN0aXZlVGFiIiwic2V0QWN0aXZlVGFiIiwiaXNFZGl0TW9kZSIsInNldElzRWRpdE1vZGUiLCJjb21tZW50Iiwic2V0Q29tbWVudCIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZGF0YSIsInRhc2tzIiwiZ2V0V2l0aFRpbWVsaW5lIiwiYWdlbnRzIiwibGlzdEFsbCIsInRhc2siLCJwcm9qZWN0SWQiLCJ3YXRjaFN1YnNjcmlwdGlvbnMiLCJsaXN0QnlVc2VyIiwidXNlcklkIiwiZW50aXR5VHlwZSIsInBvc3RNZXNzYWdlIiwibWVzc2FnZXMiLCJwb3N0IiwidHJhbnNpdGlvblRhc2siLCJ0cmFuc2l0aW9uIiwidXBkYXRlVGFzayIsInVwZGF0ZSIsInRvZ2dsZVdhdGNoIiwidG9nZ2xlIiwicmVxdWVzdEFwcHJvdmFsIiwiYXBwcm92YWxzIiwicmVxdWVzdCIsImlzTG9hZGluZyIsInVuZGVmaW5lZCIsIm9wZW4iLCJ0aXRsZSIsInRyYW5zaXRpb25zIiwicnVucyIsInRvb2xDYWxscyIsImFjdGl2aXRpZXMiLCJ0YXNrRXZlbnRzIiwiYWdlbnRNYXAiLCJNYXAiLCJtYXAiLCJhIiwiX2lkIiwiaXNXYXRjaGluZ1Rhc2siLCJzb21lIiwic3Vic2NyaXB0aW9uIiwiZW50aXR5SWQiLCJoYW5kbGVQb3N0Q29tbWVudCIsInRyaW0iLCJhdXRob3JUeXBlIiwiYXV0aG9yVXNlcklkIiwidHlwZSIsImNvbnRlbnQiLCJpZGVtcG90ZW5jeUtleSIsIkRhdGUiLCJub3ciLCJlIiwiY29uc29sZSIsImVycm9yIiwiaGFuZGxlVHJhbnNpdGlvbiIsInRvU3RhdHVzIiwicmVzdWx0IiwiYWN0b3JUeXBlIiwiYWN0b3JVc2VySWQiLCJyZWFzb24iLCJzdWNjZXNzIiwiZXJyb3JzIiwiYWxlcnQiLCJtZXNzYWdlIiwiam9pbiIsImlkZW50aWZpZXIiLCJwcmlvcml0eSIsInNvdXJjZSIsInNyYyIsIlNPVVJDRV9DT05GSUciLCJVTktOT1dOIiwic291cmNlUmVmIiwibGFiZWwiLCJ0YWIiLCJsZW5ndGgiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsInNsaWNlIiwidGFyZ2V0IiwidmFsdWUiLCJPdmVydmlld1RhYiIsIm9uVHJhbnNpdGlvbiIsInZlcmlmaWNhdGlvblRyYWNlIiwiYXBwcm92ZWQiLCJhcHByb3ZhbCIsInBlbmRpbmdBcHByb3ZhbCIsImluY2x1ZGVzIiwiaGFuZGxlUmVxdWVzdEFwcHJvdmFsIiwicmVxdWVzdG9yQWdlbnRJZCIsImFzc2lnbmVlSWRzIiwid2luZG93IiwiYWN0aW9uVHlwZSIsImFjdGlvblN1bW1hcnkiLCJyaXNrTGV2ZWwiLCJqdXN0aWZpY2F0aW9uIiwiZGVsaXZlcmFibGUiLCJzdW1tYXJ5IiwiZXhwaXJlc0luTWludXRlcyIsInJldmlld0N5Y2xlcyIsIkVycm9yIiwiZGVzY3JpcHRpb24iLCJpZCIsImFnZW50IiwiZ2V0IiwiZHVlQXQiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJ3ZWVrZGF5IiwibW9udGgiLCJkYXkiLCJ5ZWFyIiwiY3JlYXRlZEJ5IiwicGxhbm5pbmdRYSIsInFhIiwiaSIsInF1ZXN0aW9uIiwiYW5zd2VyIiwid29ya1BsYW4iLCJidWxsZXRzIiwiYnVsbGV0IiwiZXN0aW1hdGVkQ29zdCIsInRvRml4ZWQiLCJhcnRpZmFjdElkcyIsImJsb2NrZWRSZWFzb24iLCJfYzIiLCJSZWFzc2lnbkRyb3Bkb3duIiwiY3VycmVudEFzc2lnbmVlSWRzIiwiX3MyIiwic2VsZWN0ZWRJZHMiLCJzZXRTZWxlY3RlZElkcyIsInNldE9wZW4iLCJoYW5kbGVSZWFzc2lnbiIsIm5leHRJZHMiLCJmaWx0ZXIiLCJjYW5kaWRhdGUiLCJuYW1lIiwiUmVkaXJlY3RGb3JtIiwiX3MzIiwicmVkaXJlY3RUZXh0Iiwic2V0UmVkaXJlY3RUZXh0IiwiaGFuZGxlUmVkaXJlY3QiLCJldmVudCIsIkFnZW50Q2hpcCIsInJvbGUiLCJfYzUiLCJUSU1FTElORV9FTlRSWV9DTEFTUyIsIlRpbWVsaW5lVGFiIiwiaXRlbXMiLCJwdXNoIiwidHMiLCJ0aW1lc3RhbXAiLCJ0IiwiX2NyZWF0aW9uVGltZSIsIm0iLCJyIiwic3RhcnRlZEF0IiwidGMiLCJhY3Rpdml0eSIsInNvcnQiLCJiIiwiaXRlbSIsIl9jNiIsIlRpbWVsaW5lSXRlbSIsInRpbWUiLCJ0b0xvY2FsZVRpbWVTdHJpbmciLCJmb3JtYXRBY3Rvck5hbWUiLCJhY3RvcklkIiwibWF5YmVBZ2VudCIsImFjdG9yIiwiZXZlbnRUeXBlIiwiYmVmb3JlU3RhdGUiLCJhZnRlclN0YXRlIiwiSlNPTiIsInN0cmluZ2lmeSIsIm1ldGFkYXRhIiwiYWN0b3JBZ2VudElkIiwiZnJvbVN0YXR1cyIsImF1dGhvciIsImF1dGhvckFnZW50SWQiLCJhZ2VudElkIiwiZHVyYXRpb24iLCJkdXJhdGlvbk1zIiwibW9kZWwiLCJjb3N0VXNkIiwidG9vbE5hbWUiLCJpbnB1dFByZXZpZXciLCJhY3Rpb24iLCJfYzciLCJBcnRpZmFjdHNUYWIiLCJhcnRpZmFjdE1lc3NhZ2VzIiwiYXJ0aWZhY3RzIiwidG9Mb2NhbGVTdHJpbmciLCJfYzgiLCJBcHByb3ZhbHNUYWIiLCJfczQiLCJhcHByb3ZlIiwiZGVueSIsImRlY2lzaW9uUmVhc29ucyIsInNldERlY2lzaW9uUmVhc29ucyIsImJ1c3lBcHByb3ZhbElkIiwic2V0QnVzeUFwcHJvdmFsSWQiLCJkZWNpc2lvblJlYXNvbiIsImN1cnJlbnQiLCJhcHByb3ZhbElkIiwiZGVjaWRlZEJ5VXNlcklkIiwiQ29zdFRhYiIsInRvdGFsUnVuQ29zdCIsInJlZHVjZSIsInN1bSIsImNvbXBsZXRlZFJ1bnMiLCJmYWlsZWRSdW5zIiwiYnVkZ2V0QWxsb2NhdGVkIiwiYWN0dWFsQ29zdCIsImJ1ZGdldFJlbWFpbmluZyIsInRvU3RyaW5nIiwicmV2ZXJzZSIsImlucHV0VG9rZW5zIiwib3V0cHV0VG9rZW5zIiwiX2MwIiwiV2h5VGFiIiwiX3M1IiwiYXNzaWduZWVzIiwiYWxsb3dlZFRyYW5zaXRpb25zIiwiZ2V0QWxsb3dlZFRyYW5zaXRpb25zRm9ySHVtYW4iLCJzaW11bGF0ZVRvU3RhdHVzIiwic2V0U2ltdWxhdGVUb1N0YXR1cyIsInRyYW5zaXRpb25DaG9pY2VzIiwidHJhbnNpdGlvblNpbXVsYXRpb24iLCJzaW11bGF0ZVRyYW5zaXRpb24iLCJoYXNXb3JrUGxhbiIsImhhc0RlbGl2ZXJhYmxlIiwiaGFzQ2hlY2tsaXN0IiwicmV2aWV3Q2hlY2tsaXN0IiwicG9saWN5RGVjaXNpb24iLCJwb2xpY3kiLCJleHBsYWluVGFza1BvbGljeSIsInBsYW5uZWRUcmFuc2l0aW9uVG8iLCJkZWNpc2lvbiIsInRyaWdnZXJlZFJ1bGVzIiwicnVsZSIsInJlcXVpcmVkQXBwcm92YWxzIiwiaW5kZXgiLCJyZW1lZGlhdGlvbkhpbnRzIiwiaGludCIsImNob2ljZSIsInZhbGlkIiwicmVxdWlyZW1lbnRzIiwicmVxdWlyZXNXb3JrUGxhbiIsInJlcXVpcmVzRGVsaXZlcmFibGUiLCJyZXF1aXJlc0NoZWNrbGlzdCIsImh1bWFuT25seSIsIkJvb2xlYW4iLCJmaWVsZCIsImFsbG93ZWRUYXNrVHlwZXMiLCJDUkVBVEVEX0JZX0xBQkVMUyIsInBhcmVudFRhc2tJZCIsIlN0cmluZyIsImxhYmVscyIsIlRhYkJ1dHRvbiIsImFjdGl2ZSIsIm9uQ2xpY2siLCJjaGlsZHJlbiIsIl9jMTAiLCJTZWN0aW9uIiwiX2MxMSIsIkV4cGxhaW5Sb3ciLCJkZXRhaWwiLCJfYzEyIiwiU3RhdCIsIm5lZ2F0aXZlIiwiX2MxMyIsIkRBU0hCT0FSRCIsIlRFTEVHUkFNIiwiR0lUSFVCIiwiQUdFTlQiLCJBUEkiLCJUUkVMTE8iLCJTRUVEIiwiTUlTU0lPTl9QUk9NUFQiLCJQUkRfSU1QT1JUIiwiSFVNQU4iLCJTWVNURU0iLCJTb3VyY2VCYWRnZSIsImNyZWF0b3JMYWJlbCIsIl9jMTQiLCJfYyIsIl9jMyIsIl9jNCIsIl9jOSIsIl9jMSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUYXNrRHJhd2VyVGFicy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBUYXNrRHJhd2VyIHdpdGggVGFic1xuICpcbiAqIEVuaGFuY2VkIHRhc2sgZGV0YWlsIHZpZXcgd2l0aCBPdmVydmlldywgVGltZWxpbmUsIEFydGlmYWN0cywgQXBwcm92YWxzLCBDb3N0IHRhYnMuXG4gKi9cblxuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5IH0gZnJvbSBcImNvbnZleC9yZWFjdFwiO1xuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2FwaVwiO1xuaW1wb3J0IHR5cGUgeyBJZCwgRG9jIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQge1xuICBEcm9wZG93bk1lbnUsXG4gIERyb3Bkb3duTWVudUNoZWNrYm94SXRlbSxcbiAgRHJvcGRvd25NZW51Q29udGVudCxcbiAgRHJvcGRvd25NZW51SXRlbSxcbiAgRHJvcGRvd25NZW51TGFiZWwsXG4gIERyb3Bkb3duTWVudVNlcGFyYXRvcixcbiAgRHJvcGRvd25NZW51VHJpZ2dlcixcbn0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9kcm9wZG93bi1tZW51XCI7XG5pbXBvcnQge1xuICBTaGVldCxcbiAgU2hlZXRDb250ZW50LFxuICBTaGVldERlc2NyaXB0aW9uLFxuICBTaGVldEhlYWRlcixcbiAgU2hlZXRUaXRsZSxcbn0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9zaGVldFwiO1xuaW1wb3J0IHsgUGVlclJldmlld1BhbmVsIH0gZnJvbSBcIi4vUGVlclJldmlld1BhbmVsXCI7XG5pbXBvcnQgeyBFeHBvcnRSZXBvcnRCdXR0b24gfSBmcm9tIFwiLi9FeHBvcnRSZXBvcnRCdXR0b25cIjtcbmltcG9ydCB7IFRhc2tFZGl0TW9kZSB9IGZyb20gXCIuL1Rhc2tFZGl0TW9kZVwiO1xuaW1wb3J0IHsgUmlza0JhZGdlLCBTdGF0dXNCYWRnZSwgdHlwZSBTdGF0dXNCYWRnZVByb3BzIH0gZnJvbSBcIi4vY29tcG9uZW50cy9mYWN0b3J5L2JhZGdlc1wiO1xuaW1wb3J0IHsgVmVyaWZpY2F0aW9uVHJhY2VQYW5lbCB9IGZyb20gXCIuL2NvbXBvbmVudHMvdGFza3MvVmVyaWZpY2F0aW9uVHJhY2VQYW5lbFwiO1xuaW1wb3J0IHsgYnVpbGRWZXJpZmljYXRpb25UcmFjZSB9IGZyb20gXCJAL2xpYi92ZXJpZmljYXRpb25UcmFjZVwiO1xuXG50eXBlIFRhYiA9IFwib3ZlcnZpZXdcIiB8IFwidGltZWxpbmVcIiB8IFwiYXJ0aWZhY3RzXCIgfCBcImFwcHJvdmFsc1wiIHwgXCJjb3N0XCIgfCBcInJldmlld3NcIiB8IFwid2h5XCI7XG50eXBlIFRhc2tTdGF0dXMgPSBEb2M8XCJ0YXNrc1wiPltcInN0YXR1c1wiXTtcblxuLyoqIFVJX1NUWUxFX0dVSURFIHRhc2stc3RhdGUg4oaSIGJhZGdlIHRvbmUgbWFwcGluZy4gKi9cbmZ1bmN0aW9uIHRhc2tTdGF0dXNUb25lKHN0YXR1czogc3RyaW5nKTogU3RhdHVzQmFkZ2VQcm9wc1tcInRvbmVcIl0ge1xuICBzd2l0Y2ggKHN0YXR1cykge1xuICAgIGNhc2UgXCJET05FXCI6XG4gICAgICByZXR1cm4gXCJzdWNjZXNzXCI7XG4gICAgY2FzZSBcIklOX1BST0dSRVNTXCI6XG4gICAgY2FzZSBcIlJFVklFV1wiOlxuICAgICAgcmV0dXJuIFwiaW5mb1wiO1xuICAgIGNhc2UgXCJORUVEU19BUFBST1ZBTFwiOlxuICAgIGNhc2UgXCJCTE9DS0VEXCI6XG4gICAgICByZXR1cm4gXCJ3YXJuaW5nXCI7XG4gICAgY2FzZSBcIkZBSUxFRFwiOlxuICAgICAgcmV0dXJuIFwiZXJyb3JcIjtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIFwibmV1dHJhbFwiO1xuICB9XG59XG5cbmZ1bmN0aW9uIGFwcHJvdmFsU3RhdHVzVG9uZShzdGF0dXM6IHN0cmluZyk6IFN0YXR1c0JhZGdlUHJvcHNbXCJ0b25lXCJdIHtcbiAgc3dpdGNoIChzdGF0dXMpIHtcbiAgICBjYXNlIFwiQVBQUk9WRURcIjpcbiAgICAgIHJldHVybiBcInN1Y2Nlc3NcIjtcbiAgICBjYXNlIFwiREVOSUVEXCI6XG4gICAgY2FzZSBcIkVYUElSRURcIjpcbiAgICAgIHJldHVybiBcImVycm9yXCI7XG4gICAgY2FzZSBcIlBFTkRJTkdcIjpcbiAgICBjYXNlIFwiRVNDQUxBVEVEXCI6XG4gICAgICByZXR1cm4gXCJ3YXJuaW5nXCI7XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiBcIm5ldXRyYWxcIjtcbiAgfVxufVxuXG5mdW5jdGlvbiBmb3JtYXRTdGF0dXNMYWJlbChzdGF0dXM6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBzdGF0dXMucmVwbGFjZSgvXy9nLCBcIiBcIik7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBUYXNrRHJhd2VyVGFicyh7XG4gIHRhc2tJZCxcbiAgb25DbG9zZSxcbn06IHtcbiAgdGFza0lkOiBJZDxcInRhc2tzXCI+IHwgbnVsbDtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlPFRhYj4oXCJvdmVydmlld1wiKTtcbiAgY29uc3QgW2lzRWRpdE1vZGUsIHNldElzRWRpdE1vZGVdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbY29tbWVudCwgc2V0Q29tbWVudF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IGRhdGEgPSB1c2VRdWVyeShhcGkudGFza3MuZ2V0V2l0aFRpbWVsaW5lLCB0YXNrSWQgPyB7IHRhc2tJZCB9IDogXCJza2lwXCIpO1xuICBjb25zdCBhZ2VudHMgPSB1c2VRdWVyeShcbiAgICBhcGkuYWdlbnRzLmxpc3RBbGwsXG4gICAgZGF0YT8udGFzay5wcm9qZWN0SWQgPyB7IHByb2plY3RJZDogZGF0YS50YXNrLnByb2plY3RJZCB9IDoge31cbiAgKTtcbiAgY29uc3Qgd2F0Y2hTdWJzY3JpcHRpb25zID0gdXNlUXVlcnkoXG4gICAgYXBpLndhdGNoU3Vic2NyaXB0aW9ucy5saXN0QnlVc2VyLFxuICAgIHRhc2tJZCA/IHsgdXNlcklkOiBcIm9wZXJhdG9yXCIsIGVudGl0eVR5cGU6IFwiVEFTS1wiIH0gOiBcInNraXBcIlxuICApO1xuICBjb25zdCBwb3N0TWVzc2FnZSA9IHVzZU11dGF0aW9uKGFwaS5tZXNzYWdlcy5wb3N0KTtcbiAgY29uc3QgdHJhbnNpdGlvblRhc2sgPSB1c2VNdXRhdGlvbihhcGkudGFza3MudHJhbnNpdGlvbik7XG4gIGNvbnN0IHVwZGF0ZVRhc2sgPSB1c2VNdXRhdGlvbihhcGkudGFza3MudXBkYXRlKTtcbiAgY29uc3QgdG9nZ2xlV2F0Y2ggPSB1c2VNdXRhdGlvbihhcGkud2F0Y2hTdWJzY3JpcHRpb25zLnRvZ2dsZSk7XG4gIGNvbnN0IHJlcXVlc3RBcHByb3ZhbCA9IHVzZU11dGF0aW9uKGFwaS5hcHByb3ZhbHMucmVxdWVzdCk7XG5cbiAgaWYgKCF0YXNrSWQpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IGlzTG9hZGluZyA9IGRhdGEgPT09IHVuZGVmaW5lZCB8fCBhZ2VudHMgPT09IHVuZGVmaW5lZDtcblxuICByZXR1cm4gKFxuICAgIDxTaGVldCBvcGVuPXshIXRhc2tJZH0gb25PcGVuQ2hhbmdlPXsob3BlbikgPT4geyBpZiAoIW9wZW4pIG9uQ2xvc2UoKTsgfX0+XG4gICAgICA8U2hlZXRDb250ZW50IHNpZGU9XCJyaWdodFwiIGNsYXNzTmFtZT1cInctWzYwMHB4XSBtYXgtdy1bOTB2d10gcC0wIGZsZXggZmxleC1jb2wgYmctc3VyZmFjZS0xIGJvcmRlci1sIGJvcmRlci1saW5lXCI+XG4gICAgICAgIDxTaGVldEhlYWRlciBjbGFzc05hbWU9XCJzci1vbmx5XCI+XG4gICAgICAgICAgPFNoZWV0VGl0bGU+e2RhdGE/LnRhc2sudGl0bGUgPz8gXCJUYXNrIGRldGFpbHNcIn08L1NoZWV0VGl0bGU+XG4gICAgICAgICAgPFNoZWV0RGVzY3JpcHRpb24+XG4gICAgICAgICAgICBSZXZpZXcgdGFzayBzdGF0dXMsIGV2aWRlbmNlLCBhcHByb3ZhbHMsIGFjdGl2aXR5LCBhbmQgYXZhaWxhYmxlIGFjdGlvbnMuXG4gICAgICAgICAgPC9TaGVldERlc2NyaXB0aW9uPlxuICAgICAgICA8L1NoZWV0SGVhZGVyPlxuICAgICAgICB7aXNMb2FkaW5nID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IHRleHQtc20gdGV4dC1pbmstbXV0ZWRcIj5Mb2FkaW5nLi4uPC9kaXY+XG4gICAgICAgICkgOiAhZGF0YSA/IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiB0ZXh0LXNtIHRleHQtaW5rLW11dGVkXCI+VGFzayBub3QgZm91bmQ8L2Rpdj5cbiAgICAgICAgKSA6ICgoKSA9PiB7XG4gICAgICAgICAgY29uc3QgeyB0YXNrLCB0cmFuc2l0aW9ucywgbWVzc2FnZXMsIHJ1bnMsIHRvb2xDYWxscywgYXBwcm92YWxzLCBhY3Rpdml0aWVzLCB0YXNrRXZlbnRzIH0gPSBkYXRhO1xuICAgICAgICAgIGNvbnN0IGFnZW50TWFwID0gbmV3IE1hcDxJZDxcImFnZW50c1wiPiwgRG9jPFwiYWdlbnRzXCI+PihcbiAgICAgICAgICAgIChhZ2VudHMgYXMgRG9jPFwiYWdlbnRzXCI+W10pLm1hcCgoYTogRG9jPFwiYWdlbnRzXCI+KSA9PiBbYS5faWQsIGFdKVxuICAgICAgICAgICk7XG4gICAgICAgICAgY29uc3QgaXNXYXRjaGluZ1Rhc2sgPSAhIXdhdGNoU3Vic2NyaXB0aW9ucz8uc29tZSgoc3Vic2NyaXB0aW9uKSA9PiBzdWJzY3JpcHRpb24uZW50aXR5SWQgPT09IHRhc2tJZCk7XG5cbiAgICAgICAgICBjb25zdCBoYW5kbGVQb3N0Q29tbWVudCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIGlmICghY29tbWVudC50cmltKCkpIHJldHVybjtcbiAgICAgICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICBhd2FpdCBwb3N0TWVzc2FnZSh7XG4gICAgICAgICAgICAgICAgdGFza0lkLFxuICAgICAgICAgICAgICAgIGF1dGhvclR5cGU6IFwiSFVNQU5cIixcbiAgICAgICAgICAgICAgICBhdXRob3JVc2VySWQ6IFwib3BlcmF0b3JcIixcbiAgICAgICAgICAgICAgICB0eXBlOiBcIkNPTU1FTlRcIixcbiAgICAgICAgICAgICAgICBjb250ZW50OiBjb21tZW50LFxuICAgICAgICAgICAgICAgIGlkZW1wb3RlbmN5S2V5OiBgY29tbWVudDoke3Rhc2tJZH06JHtEYXRlLm5vdygpfWAsXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICBzZXRDb21tZW50KFwiXCIpO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIGNvbnN0IGhhbmRsZVRyYW5zaXRpb24gPSBhc3luYyAodG9TdGF0dXM6IFRhc2tTdGF0dXMpID0+IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0cmFuc2l0aW9uVGFzayh7XG4gICAgICAgICAgICAgICAgdGFza0lkLFxuICAgICAgICAgICAgICAgIHRvU3RhdHVzLFxuICAgICAgICAgICAgICAgIGFjdG9yVHlwZTogXCJIVU1BTlwiLFxuICAgICAgICAgICAgICAgIGFjdG9yVXNlcklkOiBcIm9wZXJhdG9yXCIsXG4gICAgICAgICAgICAgICAgaWRlbXBvdGVuY3lLZXk6IGB0cmFuc2l0aW9uOiR7dGFza0lkfToke3RvU3RhdHVzfToke0RhdGUubm93KCl9YCxcbiAgICAgICAgICAgICAgICByZWFzb246IFwiTWFudWFsIHRyYW5zaXRpb24gZnJvbSBVSVwiLFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgaWYgKCFyZXN1bHQuc3VjY2VzcyAmJiByZXN1bHQuZXJyb3JzKSB7XG4gICAgICAgICAgICAgICAgYWxlcnQocmVzdWx0LmVycm9ycy5tYXAoKGU6IGFueSkgPT4gZS5tZXNzYWdlKS5qb2luKFwiXFxuXCIpKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTUgcHktNCBib3JkZXItYiBib3JkZXItbGluZVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3Rhc2suaWRlbnRpZmllciAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8gdGV4dC1pbmstbXV0ZWQgbWItMC41IGJsb2NrXCI+e3Rhc2suaWRlbnRpZmllcn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICA8aDJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCBsZWFkaW5nLXNudWdcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHt0YXNrLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTIgbXQtMiBmbGV4LXdyYXAgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPFN0YXR1c0JhZGdlIHRvbmU9e3Rhc2tTdGF0dXNUb25lKHRhc2suc3RhdHVzKX0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0U3RhdHVzTGFiZWwodGFzay5zdGF0dXMpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvU3RhdHVzQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgICAgPFN0YXR1c0JhZGdlIHRvbmU9XCJuZXV0cmFsXCI+UHt0YXNrLnByaW9yaXR5fTwvU3RhdHVzQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgICAgPFN0YXR1c0JhZGdlIHRvbmU9XCJuZXV0cmFsXCI+e3Rhc2sudHlwZX08L1N0YXR1c0JhZGdlPlxuICAgICAgICAgICAgICAgICAgICAgIHt0YXNrLnNvdXJjZSAmJiAoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3JjID0gU09VUkNFX0NPTkZJR1t0YXNrLnNvdXJjZV0gfHwgU09VUkNFX0NPTkZJRy5VTktOT1dOO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsxMS41cHhdIHRleHQtaW5rLW11dGVkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17dGFzay5zb3VyY2VSZWYgPyBgJHtzcmMubGFiZWx9OiAke3Rhc2suc291cmNlUmVmfWAgOiBzcmMubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3JjLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgIH0pKCl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTIgaXRlbXMtY2VudGVyIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PXtpc1dhdGNoaW5nVGFzayA/IFwiZGVmYXVsdFwiIDogXCJvdXRsaW5lXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXthc3luYyAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhd2FpdCB0b2dnbGVXYXRjaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJJZDogXCJvcGVyYXRvclwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9qZWN0SWQ6IHRhc2sucHJvamVjdElkID8/IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZW50aXR5VHlwZTogXCJUQVNLXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGVudGl0eUlkOiB0YXNrSWQsXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge2lzV2F0Y2hpbmdUYXNrID8gXCJXYXRjaGluZ1wiIDogXCJXYXRjaFwifVxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgeyFpc0VkaXRNb2RlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiBvbkNsaWNrPXsoKSA9PiBzZXRJc0VkaXRNb2RlKHRydWUpfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgRWRpdFxuICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RXhwb3J0UmVwb3J0QnV0dG9uIHRhc2tJZD17dGFza0lkfSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHtpc0VkaXRNb2RlID8gKFxuICAgICAgICAgICAgICAgIDxUYXNrRWRpdE1vZGVcbiAgICAgICAgICAgICAgICAgIHRhc2s9e3Rhc2t9XG4gICAgICAgICAgICAgICAgICBvblNhdmU9eygpID0+IHNldElzRWRpdE1vZGUoZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgb25DYW5jZWw9eygpID0+IHNldElzRWRpdE1vZGUoZmFsc2UpfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgIHsvKiBUYWJzICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGJvcmRlci1iIGJvcmRlci1saW5lIHB4LTVcIiByb2xlPVwidGFibGlzdFwiPlxuICAgICAgICAgICAgICAgICAgICB7KFtcIm92ZXJ2aWV3XCIsIFwidGltZWxpbmVcIiwgXCJhcnRpZmFjdHNcIiwgXCJhcHByb3ZhbHNcIiwgXCJjb3N0XCIsIFwicmV2aWV3c1wiLCBcIndoeVwiXSBhcyBUYWJbXSkubWFwKCh0YWIpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8VGFiQnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3RhYn1cbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZT17YWN0aXZlVGFiID09PSB0YWJ9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIodGFiKX1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dGFiID09PSBcImFwcHJvdmFsc1wiICYmIGFwcHJvdmFscy5sZW5ndGggPiAwXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gYEFwcHJvdmFscyAoJHthcHByb3ZhbHMubGVuZ3RofSlgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogdGFiID09PSBcIndoeVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIldoeT9cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogdGFiLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgdGFiLnNsaWNlKDEpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvVGFiQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7LyogVGFiIENvbnRlbnQgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy1hdXRvIHAtNVwiPlxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSBcIm92ZXJ2aWV3XCIgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxPdmVydmlld1RhYlxuICAgICAgICAgICAgICAgICAgICAgICAgdGFza0lkPXt0YXNrSWR9XG4gICAgICAgICAgICAgICAgICAgICAgICB0YXNrPXt0YXNrfVxuICAgICAgICAgICAgICAgICAgICAgICAgcnVucz17cnVuc31cbiAgICAgICAgICAgICAgICAgICAgICAgIGFwcHJvdmFscz17YXBwcm92YWxzfVxuICAgICAgICAgICAgICAgICAgICAgICAgYWdlbnRzPXthZ2VudHMgYXMgRG9jPFwiYWdlbnRzXCI+W119XG4gICAgICAgICAgICAgICAgICAgICAgICBhZ2VudE1hcD17YWdlbnRNYXB9XG4gICAgICAgICAgICAgICAgICAgICAgICBvblRyYW5zaXRpb249e2hhbmRsZVRyYW5zaXRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgcG9zdE1lc3NhZ2U9e3Bvc3RNZXNzYWdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlVGFzaz17dXBkYXRlVGFza31cbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVlc3RBcHByb3ZhbD17cmVxdWVzdEFwcHJvdmFsfVxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0TG9hZGluZz17c2V0TG9hZGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSBcInRpbWVsaW5lXCIgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxUaW1lbGluZVRhYlxuICAgICAgICAgICAgICAgICAgICAgICAgdGFza0V2ZW50cz17dGFza0V2ZW50c31cbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb25zPXt0cmFuc2l0aW9uc31cbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2VzPXttZXNzYWdlc31cbiAgICAgICAgICAgICAgICAgICAgICAgIHJ1bnM9e3J1bnN9XG4gICAgICAgICAgICAgICAgICAgICAgICB0b29sQ2FsbHM9e3Rvb2xDYWxsc31cbiAgICAgICAgICAgICAgICAgICAgICAgIGFwcHJvdmFscz17YXBwcm92YWxzfVxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aXZpdGllcz17YWN0aXZpdGllc31cbiAgICAgICAgICAgICAgICAgICAgICAgIGFnZW50TWFwPXthZ2VudE1hcH1cbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSBcImFydGlmYWN0c1wiICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8QXJ0aWZhY3RzVGFiIHRhc2s9e3Rhc2t9IG1lc3NhZ2VzPXttZXNzYWdlc30gLz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVRhYiA9PT0gXCJyZXZpZXdzXCIgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxQZWVyUmV2aWV3UGFuZWwgdGFza0lkPXt0YXNrSWR9IHByb2plY3RJZD17dGFzay5wcm9qZWN0SWQhfSAvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSBcImFwcHJvdmFsc1wiICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8QXBwcm92YWxzVGFiIGFwcHJvdmFscz17YXBwcm92YWxzfSBhZ2VudE1hcD17YWdlbnRNYXB9IC8+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwiY29zdFwiICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8Q29zdFRhYiB0YXNrPXt0YXNrfSBydW5zPXtydW5zfSAvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSBcIndoeVwiICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8V2h5VGFiIHRhc2s9e3Rhc2t9IGFnZW50TWFwPXthZ2VudE1hcH0gdHJhbnNpdGlvbnM9e3RyYW5zaXRpb25zfSAvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBDb21tZW50IEJveCAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IGJvcmRlci10IGJvcmRlci1saW5lXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb21tZW50fVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q29tbWVudChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBZGQgYSBjb21tZW50Li4uXCJcbiAgICAgICAgICAgICAgICAgICAgICByb3dzPXszfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTMgYmctc3VyZmFjZS0xIGJvcmRlciBib3JkZXItbGluZSByb3VuZGVkLW1kIHRleHQtc20gdGV4dC1pbmsgcGxhY2Vob2xkZXI6dGV4dC1pbmstbXV0ZWQgcmVzaXplLXkgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXJpbmdcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVQb3N0Q29tbWVudH1cbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZyB8fCAhY29tbWVudC50cmltKCl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMlwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7bG9hZGluZyA/IFwiUG9zdGluZy4uLlwiIDogXCJQb3N0IGNvbW1lbnRcIn1cbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICk7XG4gICAgICAgIH0pKCl9XG4gICAgICA8L1NoZWV0Q29udGVudD5cbiAgICA8L1NoZWV0PlxuICApO1xufVxuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBPVkVSVklFVyBUQUJcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuZnVuY3Rpb24gT3ZlcnZpZXdUYWIoe1xuICB0YXNrSWQsXG4gIHRhc2ssXG4gIHJ1bnMsXG4gIGFwcHJvdmFscyxcbiAgYWdlbnRzLFxuICBhZ2VudE1hcCxcbiAgb25UcmFuc2l0aW9uLFxuICBsb2FkaW5nLFxuICBwb3N0TWVzc2FnZSxcbiAgdXBkYXRlVGFzayxcbiAgcmVxdWVzdEFwcHJvdmFsLFxuICBzZXRMb2FkaW5nLFxufToge1xuICB0YXNrSWQ6IElkPFwidGFza3NcIj47XG4gIHRhc2s6IERvYzxcInRhc2tzXCI+O1xuICBydW5zOiBEb2M8XCJydW5zXCI+W107XG4gIGFwcHJvdmFsczogRG9jPFwiYXBwcm92YWxzXCI+W107XG4gIGFnZW50czogRG9jPFwiYWdlbnRzXCI+W107XG4gIGFnZW50TWFwOiBNYXA8SWQ8XCJhZ2VudHNcIj4sIERvYzxcImFnZW50c1wiPj47XG4gIG9uVHJhbnNpdGlvbjogKHN0YXR1czogVGFza1N0YXR1cykgPT4gdm9pZDtcbiAgbG9hZGluZzogYm9vbGVhbjtcbiAgcG9zdE1lc3NhZ2U6IChhcmdzOiB7XG4gICAgdGFza0lkOiBJZDxcInRhc2tzXCI+O1xuICAgIGF1dGhvclR5cGU6IFwiSFVNQU5cIjtcbiAgICBhdXRob3JVc2VySWQ6IHN0cmluZztcbiAgICB0eXBlOiBcIkNPTU1FTlRcIjtcbiAgICBjb250ZW50OiBzdHJpbmc7XG4gICAgaWRlbXBvdGVuY3lLZXk6IHN0cmluZztcbiAgfSkgPT4gUHJvbWlzZTx1bmtub3duPjtcbiAgdXBkYXRlVGFzazogKGFyZ3M6IHsgdGFza0lkOiBJZDxcInRhc2tzXCI+OyBhc3NpZ25lZUlkczogSWQ8XCJhZ2VudHNcIj5bXSB9KSA9PiBQcm9taXNlPHVua25vd24+O1xuICByZXF1ZXN0QXBwcm92YWw6IChhcmdzOiB7XG4gICAgcHJvamVjdElkPzogSWQ8XCJwcm9qZWN0c1wiPjtcbiAgICB0YXNrSWQ6IElkPFwidGFza3NcIj47XG4gICAgcmVxdWVzdG9yQWdlbnRJZDogSWQ8XCJhZ2VudHNcIj47XG4gICAgYWN0aW9uVHlwZTogc3RyaW5nO1xuICAgIGFjdGlvblN1bW1hcnk6IHN0cmluZztcbiAgICByaXNrTGV2ZWw6IHN0cmluZztcbiAgICBqdXN0aWZpY2F0aW9uOiBzdHJpbmc7XG4gICAgZXhwaXJlc0luTWludXRlcz86IG51bWJlcjtcbiAgICBpZGVtcG90ZW5jeUtleT86IHN0cmluZztcbiAgfSkgPT4gUHJvbWlzZTx1bmtub3duPjtcbiAgc2V0TG9hZGluZzogKHZhbHVlOiBib29sZWFuKSA9PiB2b2lkO1xufSkge1xuICBjb25zdCB2ZXJpZmljYXRpb25UcmFjZSA9IGJ1aWxkVmVyaWZpY2F0aW9uVHJhY2UodGFzaywgcnVucywgYXBwcm92YWxzKTtcbiAgY29uc3QgYXBwcm92ZWQgPSBhcHByb3ZhbHMuc29tZSgoYXBwcm92YWwpID0+IGFwcHJvdmFsLnN0YXR1cyA9PT0gXCJBUFBST1ZFRFwiKTtcbiAgY29uc3QgcGVuZGluZ0FwcHJvdmFsID0gYXBwcm92YWxzLnNvbWUoKGFwcHJvdmFsKSA9PlxuICAgIFtcIlBFTkRJTkdcIiwgXCJFU0NBTEFURURcIl0uaW5jbHVkZXMoYXBwcm92YWwuc3RhdHVzKVxuICApO1xuXG4gIGNvbnN0IGhhbmRsZVJlcXVlc3RBcHByb3ZhbCA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCByZXF1ZXN0b3JBZ2VudElkID0gdGFzay5hc3NpZ25lZUlkc1swXTtcbiAgICBpZiAoIXJlcXVlc3RvckFnZW50SWQpIHtcbiAgICAgIHdpbmRvdy5hbGVydChcIkFzc2lnbiBhbiBhZ2VudCBiZWZvcmUgcmVxdWVzdGluZyBhcHByb3ZhbC5cIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHJlcXVlc3RBcHByb3ZhbCh7XG4gICAgICAgIHByb2plY3RJZDogdGFzay5wcm9qZWN0SWQsXG4gICAgICAgIHRhc2tJZCxcbiAgICAgICAgcmVxdWVzdG9yQWdlbnRJZCxcbiAgICAgICAgYWN0aW9uVHlwZTogXCJUQVNLX0NPTVBMRVRJT05cIixcbiAgICAgICAgYWN0aW9uU3VtbWFyeTogYEFwcHJvdmUgY29tcGxldGlvbiBvZiAke3Rhc2suaWRlbnRpZmllciA/PyB0YXNrLnRpdGxlfWAsXG4gICAgICAgIHJpc2tMZXZlbDogXCJZRUxMT1dcIixcbiAgICAgICAganVzdGlmaWNhdGlvbjpcbiAgICAgICAgICB0YXNrLmRlbGl2ZXJhYmxlPy5zdW1tYXJ5ID8/XG4gICAgICAgICAgXCJUYXNrIGRlbGl2ZXJhYmxlIGlzIHJlYWR5IGZvciBhbiBleHBsaWNpdCBvcGVyYXRvciBkZWNpc2lvbi5cIixcbiAgICAgICAgZXhwaXJlc0luTWludXRlczogMTIwLFxuICAgICAgICBpZGVtcG90ZW5jeUtleTogYHRhc2stcmV2aWV3OiR7dGFza0lkfToke3Rhc2sucmV2aWV3Q3ljbGVzfWAsXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgd2luZG93LmFsZXJ0KGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJVbmFibGUgdG8gcmVxdWVzdCBhcHByb3ZhbC5cIik7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICA8VmVyaWZpY2F0aW9uVHJhY2VQYW5lbCB0cmFjZT17dmVyaWZpY2F0aW9uVHJhY2V9IC8+XG5cbiAgICAgIHt0YXNrLmRlc2NyaXB0aW9uICYmIChcbiAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJEZXNjcmlwdGlvblwiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1pbmstc2Vjb25kYXJ5IGxlYWRpbmctcmVsYXhlZFwiPnt0YXNrLmRlc2NyaXB0aW9ufTwvcD5cbiAgICAgICAgPC9TZWN0aW9uPlxuICAgICAgKX1cblxuICAgICAgPFNlY3Rpb24gdGl0bGU9XCJBc3NpZ25lZXNcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yIGZsZXgtd3JhcCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICB7dGFzay5hc3NpZ25lZUlkcy5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgdGFzay5hc3NpZ25lZUlkcy5tYXAoKGlkOiBJZDxcImFnZW50c1wiPikgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBhZ2VudCA9IGFnZW50TWFwLmdldChpZCk7XG4gICAgICAgICAgICAgIHJldHVybiBhZ2VudCA/IChcbiAgICAgICAgICAgICAgICA8QWdlbnRDaGlwIGtleT17aWR9IGFnZW50PXthZ2VudH0gLz5cbiAgICAgICAgICAgICAgKSA6IG51bGw7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtaW5rLW11dGVkXCI+VW5hc3NpZ25lZDwvc3Bhbj5cbiAgICAgICAgICApfVxuICAgICAgICAgIDxSZWFzc2lnbkRyb3Bkb3duXG4gICAgICAgICAgICB0YXNrSWQ9e3Rhc2tJZH1cbiAgICAgICAgICAgIGN1cnJlbnRBc3NpZ25lZUlkcz17dGFzay5hc3NpZ25lZUlkc31cbiAgICAgICAgICAgIGFnZW50cz17YWdlbnRzfVxuICAgICAgICAgICAgdXBkYXRlVGFzaz17dXBkYXRlVGFza31cbiAgICAgICAgICAgIHNldExvYWRpbmc9e3NldExvYWRpbmd9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L1NlY3Rpb24+XG5cbiAgICAgIHt0YXNrLmR1ZUF0ICE9IG51bGwgJiYgKFxuICAgICAgICA8U2VjdGlvbiB0aXRsZT1cIkR1ZSBEYXRlXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yIHB4LTMgcHktMiB0ZXh0LXNtXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWlua1wiPlxuICAgICAgICAgICAgICB7bmV3IERhdGUodGFzay5kdWVBdCkudG9Mb2NhbGVEYXRlU3RyaW5nKHVuZGVmaW5lZCwge1xuICAgICAgICAgICAgICAgIHdlZWtkYXk6IFwic2hvcnRcIixcbiAgICAgICAgICAgICAgICBtb250aDogXCJzaG9ydFwiLFxuICAgICAgICAgICAgICAgIGRheTogXCJudW1lcmljXCIsXG4gICAgICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXG4gICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICBcInRleHQteHNcIixcbiAgICAgICAgICAgICAgICB0YXNrLmR1ZUF0IDwgRGF0ZS5ub3coKVxuICAgICAgICAgICAgICAgICAgPyBcInRleHQtZXJyXCJcbiAgICAgICAgICAgICAgICAgIDogdGFzay5kdWVBdCA8IERhdGUubm93KCkgKyA4NjQwMDAwMCAqIDJcbiAgICAgICAgICAgICAgICAgICAgPyBcInRleHQtd2FyblwiXG4gICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWluay1tdXRlZFwiXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHt0YXNrLmR1ZUF0IDwgRGF0ZS5ub3coKVxuICAgICAgICAgICAgICAgID8gXCJPdmVyZHVlXCJcbiAgICAgICAgICAgICAgICA6IHRhc2suZHVlQXQgPCBEYXRlLm5vdygpICsgODY0MDAwMDAgKiAyXG4gICAgICAgICAgICAgICAgICA/IFwiRHVlIHNvb25cIlxuICAgICAgICAgICAgICAgICAgOiBcIlNjaGVkdWxlZFwifVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L1NlY3Rpb24+XG4gICAgICApfVxuXG4gICAgICA8U2VjdGlvbiB0aXRsZT1cIlNvdXJjZVwiPlxuICAgICAgICA8U291cmNlQmFkZ2Ugc291cmNlPXt0YXNrLnNvdXJjZX0gc291cmNlUmVmPXt0YXNrLnNvdXJjZVJlZn0gY3JlYXRlZEJ5PXt0YXNrLmNyZWF0ZWRCeX0gLz5cbiAgICAgIDwvU2VjdGlvbj5cblxuICAgICAge3Rhc2sucGxhbm5pbmdRYSAmJiB0YXNrLnBsYW5uaW5nUWEubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgIDxTZWN0aW9uIHRpdGxlPVwiUGxhbm5pbmcgUSZBXCI+XG4gICAgICAgICAgPGRsIGNsYXNzTmFtZT1cInNwYWNlLXktMiB0ZXh0LXNtXCI+XG4gICAgICAgICAgICB7dGFzay5wbGFubmluZ1FhLm1hcCgocWE6IHsgcXVlc3Rpb246IHN0cmluZzsgYW5zd2VyOiBzdHJpbmcgfSwgaTogbnVtYmVyKSA9PiAoXG4gICAgICAgICAgICAgIDxkaXYga2V5PXtpfT5cbiAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1pbmtcIj57cWEucXVlc3Rpb259PC9kdD5cbiAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwidGV4dC1pbmstc2Vjb25kYXJ5IHBsLTIgbXQtMC41XCI+e3FhLmFuc3dlcn08L2RkPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGw+XG4gICAgICAgIDwvU2VjdGlvbj5cbiAgICAgICl9XG5cbiAgICAgIHt0YXNrLndvcmtQbGFuICYmIChcbiAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJXb3JrIFBsYW5cIj5cbiAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwibGlzdC1kaXNjIHBsLTUgdGV4dC1zbSB0ZXh0LWluay1zZWNvbmRhcnkgc3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgIHt0YXNrLndvcmtQbGFuLmJ1bGxldHMubWFwKChidWxsZXQ6IHN0cmluZywgaTogbnVtYmVyKSA9PiAoXG4gICAgICAgICAgICAgIDxsaSBrZXk9e2l9PntidWxsZXR9PC9saT5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvdWw+XG4gICAgICAgICAge3Rhc2sud29ya1BsYW4uZXN0aW1hdGVkQ29zdCAmJiAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQteHMgdGV4dC1pbmstbXV0ZWRcIj5cbiAgICAgICAgICAgICAgRXN0aW1hdGVkOiAke3Rhc2sud29ya1BsYW4uZXN0aW1hdGVkQ29zdC50b0ZpeGVkKDIpfVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvU2VjdGlvbj5cbiAgICAgICl9XG5cbiAgICAgIHt0YXNrLmRlbGl2ZXJhYmxlICYmIChcbiAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJEZWxpdmVyYWJsZVwiPlxuICAgICAgICAgIHt0YXNrLmRlbGl2ZXJhYmxlLnN1bW1hcnkgJiYgKFxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWluay1zZWNvbmRhcnkgbWItMlwiPnt0YXNrLmRlbGl2ZXJhYmxlLnN1bW1hcnl9PC9wPlxuICAgICAgICAgICl9XG4gICAgICAgICAge3Rhc2suZGVsaXZlcmFibGUuYXJ0aWZhY3RJZHMgJiYgdGFzay5kZWxpdmVyYWJsZS5hcnRpZmFjdElkcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMS41IGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgICB7dGFzay5kZWxpdmVyYWJsZS5hcnRpZmFjdElkcy5tYXAoKGlkOiBzdHJpbmcpID0+IChcbiAgICAgICAgICAgICAgICA8U3RhdHVzQmFkZ2Uga2V5PXtpZH0gdG9uZT1cIm5ldXRyYWxcIiBjbGFzc05hbWU9XCJmb250LW1vbm9cIj57aWR9PC9TdGF0dXNCYWRnZT5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L1NlY3Rpb24+XG4gICAgICApfVxuXG4gICAgICB7dGFzay5ibG9ja2VkUmVhc29uICYmIChcbiAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJCbG9ja2VkIFJlYXNvblwiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1lcnJcIj57dGFzay5ibG9ja2VkUmVhc29ufTwvcD5cbiAgICAgICAgPC9TZWN0aW9uPlxuICAgICAgKX1cblxuICAgICAgPFNlY3Rpb24gdGl0bGU9XCJSZWRpcmVjdFwiPlxuICAgICAgICA8UmVkaXJlY3RGb3JtXG4gICAgICAgICAgdGFza0lkPXt0YXNrSWR9XG4gICAgICAgICAgcG9zdE1lc3NhZ2U9e3Bvc3RNZXNzYWdlfVxuICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgICAgc2V0TG9hZGluZz17c2V0TG9hZGluZ31cbiAgICAgICAgLz5cbiAgICAgIDwvU2VjdGlvbj5cblxuICAgICAgPFNlY3Rpb24gdGl0bGU9XCJRdWljayBBY3Rpb25zXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMiBmbGV4LXdyYXBcIj5cbiAgICAgICAgICB7dGFzay5zdGF0dXMgPT09IFwiSU5CT1hcIiAmJiAoXG4gICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIG9uQ2xpY2s9eygpID0+IG9uVHJhbnNpdGlvbihcIkFTU0lHTkVEXCIpfSBkaXNhYmxlZD17bG9hZGluZ30+XG4gICAgICAgICAgICAgIEFzc2lnblxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgICB7dGFzay5zdGF0dXMgPT09IFwiUkVWSUVXXCIgJiYgYXBwcm92ZWQgJiYgKFxuICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiBvbkNsaWNrPXsoKSA9PiBvblRyYW5zaXRpb24oXCJET05FXCIpfSBkaXNhYmxlZD17bG9hZGluZ30+XG4gICAgICAgICAgICAgIEFjY2VwdCBhbmQgbWFyayBkb25lXG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICAgIHt0YXNrLnN0YXR1cyA9PT0gXCJSRVZJRVdcIiAmJiAhYXBwcm92ZWQgJiYgIXBlbmRpbmdBcHByb3ZhbCAmJiAoXG4gICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIG9uQ2xpY2s9e2hhbmRsZVJlcXVlc3RBcHByb3ZhbH0gZGlzYWJsZWQ9e2xvYWRpbmd9PlxuICAgICAgICAgICAgICBSZXF1ZXN0IGFwcHJvdmFsXG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICAgIHt0YXNrLnN0YXR1cyA9PT0gXCJSRVZJRVdcIiAmJiBwZW5kaW5nQXBwcm92YWwgJiYgKFxuICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwib3V0bGluZVwiIGRpc2FibGVkPlxuICAgICAgICAgICAgICBBd2FpdGluZyBhcHByb3ZhbFxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgICB7dGFzay5zdGF0dXMgPT09IFwiQkxPQ0tFRFwiICYmIChcbiAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4gb25UcmFuc2l0aW9uKFwiSU5fUFJPR1JFU1NcIil9IGRpc2FibGVkPXtsb2FkaW5nfT5cbiAgICAgICAgICAgICAgVW5ibG9ja1xuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L1NlY3Rpb24+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmZ1bmN0aW9uIFJlYXNzaWduRHJvcGRvd24oe1xuICB0YXNrSWQsXG4gIGN1cnJlbnRBc3NpZ25lZUlkcyxcbiAgYWdlbnRzLFxuICB1cGRhdGVUYXNrLFxuICBzZXRMb2FkaW5nLFxufToge1xuICB0YXNrSWQ6IElkPFwidGFza3NcIj47XG4gIGN1cnJlbnRBc3NpZ25lZUlkczogSWQ8XCJhZ2VudHNcIj5bXTtcbiAgYWdlbnRzOiBEb2M8XCJhZ2VudHNcIj5bXTtcbiAgdXBkYXRlVGFzazogKGFyZ3M6IHsgdGFza0lkOiBJZDxcInRhc2tzXCI+OyBhc3NpZ25lZUlkczogSWQ8XCJhZ2VudHNcIj5bXSB9KSA9PiBQcm9taXNlPHVua25vd24+O1xuICBzZXRMb2FkaW5nOiAodmFsdWU6IGJvb2xlYW4pID0+IHZvaWQ7XG59KSB7XG4gIGNvbnN0IFtzZWxlY3RlZElkcywgc2V0U2VsZWN0ZWRJZHNdID0gdXNlU3RhdGU8SWQ8XCJhZ2VudHNcIj5bXT4oY3VycmVudEFzc2lnbmVlSWRzKTtcbiAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2V0U2VsZWN0ZWRJZHMoY3VycmVudEFzc2lnbmVlSWRzKTtcbiAgfSwgW2N1cnJlbnRBc3NpZ25lZUlkc10pO1xuXG4gIGNvbnN0IGhhbmRsZVJlYXNzaWduID0gYXN5bmMgKG5leHRJZHM6IElkPFwiYWdlbnRzXCI+W10pID0+IHtcbiAgICBzZXRTZWxlY3RlZElkcyhuZXh0SWRzKTtcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCB1cGRhdGVUYXNrKHsgdGFza0lkLCBhc3NpZ25lZUlkczogbmV4dElkcyB9KTtcbiAgICAgIHNldE9wZW4oZmFsc2UpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPERyb3Bkb3duTWVudSBvcGVuPXtvcGVufSBvbk9wZW5DaGFuZ2U9e3NldE9wZW59PlxuICAgICAgPERyb3Bkb3duTWVudVRyaWdnZXIgYXNDaGlsZD5cbiAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIHNpemU9XCJzbVwiPlxuICAgICAgICAgIFJlYXNzaWduLi4uXG4gICAgICAgIDwvQnV0dG9uPlxuICAgICAgPC9Ecm9wZG93bk1lbnVUcmlnZ2VyPlxuICAgICAgPERyb3Bkb3duTWVudUNvbnRlbnQgYWxpZ249XCJzdGFydFwiIGNsYXNzTmFtZT1cInctNTYgbWF4LWgtWzI4MHB4XSBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgPERyb3Bkb3duTWVudUxhYmVsPkFzc2lnbiB0bzwvRHJvcGRvd25NZW51TGFiZWw+XG4gICAgICAgIDxEcm9wZG93bk1lbnVTZXBhcmF0b3IgLz5cbiAgICAgICAge2FnZW50cy5tYXAoKGFnZW50KSA9PiAoXG4gICAgICAgICAgPERyb3Bkb3duTWVudUNoZWNrYm94SXRlbVxuICAgICAgICAgICAga2V5PXthZ2VudC5faWR9XG4gICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RlZElkcy5pbmNsdWRlcyhhZ2VudC5faWQpfVxuICAgICAgICAgICAgb25DaGVja2VkQ2hhbmdlPXsoKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IG5leHRJZHMgPSBzZWxlY3RlZElkcy5pbmNsdWRlcyhhZ2VudC5faWQpXG4gICAgICAgICAgICAgICAgPyBzZWxlY3RlZElkcy5maWx0ZXIoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlICE9PSBhZ2VudC5faWQpXG4gICAgICAgICAgICAgICAgOiBbLi4uc2VsZWN0ZWRJZHMsIGFnZW50Ll9pZF07XG4gICAgICAgICAgICAgIHZvaWQgaGFuZGxlUmVhc3NpZ24obmV4dElkcyk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxzcGFuPnthZ2VudC5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICA8L0Ryb3Bkb3duTWVudUNoZWNrYm94SXRlbT5cbiAgICAgICAgKSl9XG4gICAgICAgIDxEcm9wZG93bk1lbnVTZXBhcmF0b3IgLz5cbiAgICAgICAgPERyb3Bkb3duTWVudUl0ZW1cbiAgICAgICAgICBvblNlbGVjdD17KCkgPT4gdm9pZCBoYW5kbGVSZWFzc2lnbihbXSl9XG4gICAgICAgID5cbiAgICAgICAgICBDbGVhciBhc3NpZ25lZXNcbiAgICAgICAgPC9Ecm9wZG93bk1lbnVJdGVtPlxuICAgICAgPC9Ecm9wZG93bk1lbnVDb250ZW50PlxuICAgIDwvRHJvcGRvd25NZW51PlxuICApO1xufVxuXG5mdW5jdGlvbiBSZWRpcmVjdEZvcm0oe1xuICB0YXNrSWQsXG4gIHBvc3RNZXNzYWdlLFxuICBsb2FkaW5nLFxuICBzZXRMb2FkaW5nLFxufToge1xuICB0YXNrSWQ6IElkPFwidGFza3NcIj47XG4gIHBvc3RNZXNzYWdlOiAoYXJnczoge1xuICAgIHRhc2tJZDogSWQ8XCJ0YXNrc1wiPjtcbiAgICBhdXRob3JUeXBlOiBcIkhVTUFOXCI7XG4gICAgYXV0aG9yVXNlcklkOiBzdHJpbmc7XG4gICAgdHlwZTogXCJDT01NRU5UXCI7XG4gICAgY29udGVudDogc3RyaW5nO1xuICAgIGlkZW1wb3RlbmN5S2V5OiBzdHJpbmc7XG4gIH0pID0+IFByb21pc2U8dW5rbm93bj47XG4gIGxvYWRpbmc6IGJvb2xlYW47XG4gIHNldExvYWRpbmc6ICh2YWx1ZTogYm9vbGVhbikgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgW3JlZGlyZWN0VGV4dCwgc2V0UmVkaXJlY3RUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xuXG4gIGNvbnN0IGhhbmRsZVJlZGlyZWN0ID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghcmVkaXJlY3RUZXh0LnRyaW0oKSkgcmV0dXJuO1xuICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHBvc3RNZXNzYWdlKHtcbiAgICAgICAgdGFza0lkLFxuICAgICAgICBhdXRob3JUeXBlOiBcIkhVTUFOXCIsXG4gICAgICAgIGF1dGhvclVzZXJJZDogXCJvcGVyYXRvclwiLFxuICAgICAgICB0eXBlOiBcIkNPTU1FTlRcIixcbiAgICAgICAgY29udGVudDogYFJlZGlyZWN0OiAke3JlZGlyZWN0VGV4dC50cmltKCl9YCxcbiAgICAgICAgaWRlbXBvdGVuY3lLZXk6IGByZWRpcmVjdDoke3Rhc2tJZH06JHtEYXRlLm5vdygpfWAsXG4gICAgICB9KTtcbiAgICAgIHNldFJlZGlyZWN0VGV4dChcIlwiKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgPGlucHV0XG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgdmFsdWU9e3JlZGlyZWN0VGV4dH1cbiAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0UmVkaXJlY3RUZXh0KGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgIHBsYWNlaG9sZGVyPVwiSW5zdHJ1Y3Rpb24gZm9yIHRoZSBhZ2VudC4uLlwiXG4gICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wIHB4LTMgcHktMiByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgdGV4dC1zbSB0ZXh0LWluayBwbGFjZWhvbGRlcjp0ZXh0LWluay1tdXRlZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcmluZ1wiXG4gICAgICAvPlxuICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiBvbkNsaWNrPXtoYW5kbGVSZWRpcmVjdH0gZGlzYWJsZWQ9e2xvYWRpbmcgfHwgIXJlZGlyZWN0VGV4dC50cmltKCl9PlxuICAgICAgICBTZW5kIHJlZGlyZWN0XG4gICAgICA8L0J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gQWdlbnRDaGlwKHsgYWdlbnQgfTogeyBhZ2VudDogRG9jPFwiYWdlbnRzXCI+IH0pIHtcbiAgcmV0dXJuIChcbiAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yLjUgcHktMSBiZy1zdXJmYWNlLTIgcm91bmRlZC1tZCB0ZXh0LXhzIHRleHQtaW5rXCI+XG4gICAgICA8c3Bhbj57YWdlbnQubmFtZX08L3NwYW4+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWluay1tdXRlZFwiPnthZ2VudC5yb2xlfTwvc3Bhbj5cbiAgICA8L3NwYW4+XG4gICk7XG59XG5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbi8vIFRJTUVMSU5FIFRBQlxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuXG4vKiogRmxhdCB0aW1lbGluZSBlbnRyeTogaGFpcmxpbmUgc2VwYXJhdG9yICsgZmxhdCBkb3QgbWFya2VyIChubyBib3hlZCBjYXJkcykuICovXG5jb25zdCBUSU1FTElORV9FTlRSWV9DTEFTUyA9XG4gIFwicmVsYXRpdmUgYm9yZGVyLWIgYm9yZGVyLWxpbmUgcGItMyBwbC00IGxhc3Q6Ym9yZGVyLWItMCBiZWZvcmU6YWJzb2x1dGUgYmVmb3JlOmxlZnQtMCBiZWZvcmU6dG9wLVs3cHhdIGJlZm9yZTpoLTEuNSBiZWZvcmU6dy0xLjUgYmVmb3JlOnJvdW5kZWQtZnVsbCBiZWZvcmU6YmctaW5rLW11dGVkXCI7XG5cbmZ1bmN0aW9uIFRpbWVsaW5lVGFiKHtcbiAgdGFza0V2ZW50cyxcbiAgdHJhbnNpdGlvbnMsXG4gIG1lc3NhZ2VzLFxuICBydW5zLFxuICB0b29sQ2FsbHMsXG4gIGFwcHJvdmFscyxcbiAgYWN0aXZpdGllcyxcbiAgYWdlbnRNYXAsXG59OiB7XG4gIHRhc2tFdmVudHM6IERvYzxcInRhc2tFdmVudHNcIj5bXTtcbiAgdHJhbnNpdGlvbnM6IERvYzxcInRhc2tUcmFuc2l0aW9uc1wiPltdO1xuICBtZXNzYWdlczogRG9jPFwibWVzc2FnZXNcIj5bXTtcbiAgcnVuczogRG9jPFwicnVuc1wiPltdO1xuICB0b29sQ2FsbHM6IERvYzxcInRvb2xDYWxsc1wiPltdO1xuICBhcHByb3ZhbHM6IERvYzxcImFwcHJvdmFsc1wiPltdO1xuICBhY3Rpdml0aWVzOiBEb2M8XCJhY3Rpdml0aWVzXCI+W107XG4gIGFnZW50TWFwOiBNYXA8SWQ8XCJhZ2VudHNcIj4sIERvYzxcImFnZW50c1wiPj47XG59KSB7XG4gIGNvbnN0IGl0ZW1zOiBBcnJheTx7XG4gICAgdHlwZTogXCJ0YXNrRXZlbnRcIiB8IFwidHJhbnNpdGlvblwiIHwgXCJtZXNzYWdlXCIgfCBcInJ1blwiIHwgXCJ0b29sQ2FsbFwiIHwgXCJhcHByb3ZhbFwiIHwgXCJhY3Rpdml0eVwiO1xuICAgIHRzOiBudW1iZXI7XG4gICAgZGF0YTogYW55O1xuICB9PiA9IFtdO1xuXG4gIGlmICh0YXNrRXZlbnRzLmxlbmd0aCA+IDApIHtcbiAgICBmb3IgKGNvbnN0IGV2ZW50IG9mIHRhc2tFdmVudHMpIHtcbiAgICAgIGl0ZW1zLnB1c2goeyB0eXBlOiBcInRhc2tFdmVudFwiLCB0czogZXZlbnQudGltZXN0YW1wLCBkYXRhOiBldmVudCB9KTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgZm9yIChjb25zdCB0IG9mIHRyYW5zaXRpb25zKSBpdGVtcy5wdXNoKHsgdHlwZTogXCJ0cmFuc2l0aW9uXCIsIHRzOiAodCBhcyBhbnkpLl9jcmVhdGlvblRpbWUsIGRhdGE6IHQgfSk7XG4gICAgZm9yIChjb25zdCBtIG9mIG1lc3NhZ2VzKSBpdGVtcy5wdXNoKHsgdHlwZTogXCJtZXNzYWdlXCIsIHRzOiAobSBhcyBhbnkpLl9jcmVhdGlvblRpbWUsIGRhdGE6IG0gfSk7XG4gICAgZm9yIChjb25zdCByIG9mIHJ1bnMpIGl0ZW1zLnB1c2goeyB0eXBlOiBcInJ1blwiLCB0czogci5zdGFydGVkQXQsIGRhdGE6IHIgfSk7XG4gICAgZm9yIChjb25zdCB0YyBvZiB0b29sQ2FsbHMpIGl0ZW1zLnB1c2goeyB0eXBlOiBcInRvb2xDYWxsXCIsIHRzOiB0Yy5zdGFydGVkQXQsIGRhdGE6IHRjIH0pO1xuICAgIGZvciAoY29uc3QgYSBvZiBhcHByb3ZhbHMpIGl0ZW1zLnB1c2goeyB0eXBlOiBcImFwcHJvdmFsXCIsIHRzOiAoYSBhcyBhbnkpLl9jcmVhdGlvblRpbWUsIGRhdGE6IGEgfSk7XG4gICAgZm9yIChjb25zdCBhY3Rpdml0eSBvZiBhY3Rpdml0aWVzKSBpdGVtcy5wdXNoKHsgdHlwZTogXCJhY3Rpdml0eVwiLCB0czogKGFjdGl2aXR5IGFzIGFueSkuX2NyZWF0aW9uVGltZSwgZGF0YTogYWN0aXZpdHkgfSk7XG4gIH1cblxuICBpdGVtcy5zb3J0KChhLCBiKSA9PiBhLnRzIC0gYi50cyk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAge2l0ZW1zLm1hcCgoaXRlbSwgaSkgPT4gKFxuICAgICAgICA8VGltZWxpbmVJdGVtIGtleT17aX0gaXRlbT17aXRlbX0gYWdlbnRNYXA9e2FnZW50TWFwfSAvPlxuICAgICAgKSl9XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmZ1bmN0aW9uIFRpbWVsaW5lSXRlbSh7XG4gIGl0ZW0sXG4gIGFnZW50TWFwLFxufToge1xuICBpdGVtOiB7IHR5cGU6IHN0cmluZzsgdHM6IG51bWJlcjsgZGF0YTogYW55IH07XG4gIGFnZW50TWFwOiBNYXA8SWQ8XCJhZ2VudHNcIj4sIERvYzxcImFnZW50c1wiPj47XG59KSB7XG4gIGNvbnN0IHRpbWUgPSBuZXcgRGF0ZShpdGVtLnRzKS50b0xvY2FsZVRpbWVTdHJpbmcoKTtcblxuICBjb25zdCBmb3JtYXRBY3Rvck5hbWUgPSAoYWN0b3JUeXBlPzogc3RyaW5nLCBhY3RvcklkPzogc3RyaW5nKSA9PiB7XG4gICAgaWYgKGFjdG9yVHlwZSA9PT0gXCJBR0VOVFwiICYmIGFjdG9ySWQpIHtcbiAgICAgIGNvbnN0IG1heWJlQWdlbnQgPSBhZ2VudE1hcC5nZXQoYWN0b3JJZCBhcyBJZDxcImFnZW50c1wiPik7XG4gICAgICBpZiAobWF5YmVBZ2VudCkgcmV0dXJuIG1heWJlQWdlbnQubmFtZTtcbiAgICB9XG4gICAgaWYgKGFjdG9yVHlwZSA9PT0gXCJIVU1BTlwiKSByZXR1cm4gYWN0b3JJZCB8fCBcIkh1bWFuXCI7XG4gICAgaWYgKGFjdG9yVHlwZSA9PT0gXCJTWVNURU1cIikgcmV0dXJuIFwiU3lzdGVtXCI7XG4gICAgcmV0dXJuIGFjdG9ySWQgfHwgXCJVbmtub3duXCI7XG4gIH07XG5cbiAgc3dpdGNoIChpdGVtLnR5cGUpIHtcbiAgICBjYXNlIFwidGFza0V2ZW50XCI6IHtcbiAgICAgIGNvbnN0IGV2ZW50ID0gaXRlbS5kYXRhIGFzIERvYzxcInRhc2tFdmVudHNcIj47XG4gICAgICBjb25zdCBhY3RvciA9IGZvcm1hdEFjdG9yTmFtZShldmVudC5hY3RvclR5cGUsIGV2ZW50LmFjdG9ySWQpO1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e1RJTUVMSU5FX0VOVFJZX0NMQVNTfT5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1pbmstbXV0ZWRcIj57dGltZX08L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtc20gdGV4dC1pbmtcIj5cbiAgICAgICAgICAgIHtmb3JtYXRTdGF0dXNMYWJlbChldmVudC5ldmVudFR5cGUpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWluay1tdXRlZCBtdC0wLjVcIj5BY3Rvcjoge2FjdG9yfTwvZGl2PlxuICAgICAgICAgIHtldmVudC5iZWZvcmVTdGF0ZSAmJiBldmVudC5hZnRlclN0YXRlICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWluay1zZWNvbmRhcnkgbXQtMVwiPlxuICAgICAgICAgICAgICB7SlNPTi5zdHJpbmdpZnkoZXZlbnQuYmVmb3JlU3RhdGUpfSDihpIge0pTT04uc3RyaW5naWZ5KGV2ZW50LmFmdGVyU3RhdGUpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgICB7ZXZlbnQubWV0YWRhdGEgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtaW5rLW11dGVkIG10LTFcIj5cbiAgICAgICAgICAgICAge0pTT04uc3RyaW5naWZ5KGV2ZW50Lm1ldGFkYXRhKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjYXNlIFwidHJhbnNpdGlvblwiOiB7XG4gICAgICBjb25zdCB0ID0gaXRlbS5kYXRhIGFzIERvYzxcInRhc2tUcmFuc2l0aW9uc1wiPjtcbiAgICAgIGNvbnN0IGFjdG9yID0gZm9ybWF0QWN0b3JOYW1lKHQuYWN0b3JUeXBlLCB0LmFjdG9yVXNlcklkIHx8ICh0LmFjdG9yQWdlbnRJZCBhcyB1bmtub3duIGFzIHN0cmluZykpO1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e1RJTUVMSU5FX0VOVFJZX0NMQVNTfT5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1pbmstbXV0ZWRcIj57dGltZX08L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1pbmtcIj5cbiAgICAgICAgICAgIHt0LmZyb21TdGF0dXN9IOKGkiB7dC50b1N0YXR1c30gwrcge2FjdG9yfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHt0LnJlYXNvbiAmJiA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1pbmstbXV0ZWQgbXQtMC41XCI+e3QucmVhc29ufTwvZGl2Pn1cbiAgICAgICAgPC9kaXY+XG4gICAgICApO1xuICAgIH1cblxuICAgIGNhc2UgXCJtZXNzYWdlXCI6IHtcbiAgICAgIGNvbnN0IG0gPSBpdGVtLmRhdGEgYXMgRG9jPFwibWVzc2FnZXNcIj47XG4gICAgICBjb25zdCBhdXRob3IgPSBtLmF1dGhvclVzZXJJZCB8fCAobS5hdXRob3JBZ2VudElkID8gYWdlbnRNYXAuZ2V0KG0uYXV0aG9yQWdlbnRJZCk/Lm5hbWUgOiBudWxsKSB8fCBcIlVua25vd25cIjtcbiAgICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtUSU1FTElORV9FTlRSWV9DTEFTU30+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtaW5rLW11dGVkXCI+e3RpbWV9PC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5rXCI+e2F1dGhvcn0gwrcge20udHlwZX08L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1pbmstc2Vjb25kYXJ5IHdoaXRlc3BhY2UtcHJlLXdyYXAgbXQtMC41XCI+XG4gICAgICAgICAgICB7bS5jb250ZW50LnNsaWNlKDAsIDIwMCl9e20uY29udGVudC5sZW5ndGggPiAyMDAgPyBcIi4uLlwiIDogXCJcIn1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApO1xuICAgIH1cblxuICAgIGNhc2UgXCJydW5cIjoge1xuICAgICAgY29uc3QgciA9IGl0ZW0uZGF0YSBhcyBEb2M8XCJydW5zXCI+O1xuICAgICAgY29uc3QgYWdlbnQgPSBhZ2VudE1hcC5nZXQoci5hZ2VudElkKTtcbiAgICAgIGNvbnN0IGR1cmF0aW9uID0gci5kdXJhdGlvbk1zID8gYCR7KHIuZHVyYXRpb25NcyAvIDEwMDApLnRvRml4ZWQoMSl9c2AgOiBcInJ1bm5pbmdcIjtcbiAgICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtUSU1FTElORV9FTlRSWV9DTEFTU30+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtaW5rLW11dGVkXCI+e3RpbWV9PC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5rXCI+XG4gICAgICAgICAgICBSdW4gYnkge2FnZW50Py5uYW1lIHx8IFwiQWdlbnRcIn0gwrcge3Iuc3RhdHVzfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWluay1tdXRlZCBtdC0wLjVcIj5cbiAgICAgICAgICAgIHtyLm1vZGVsfSDCtyB7ZHVyYXRpb259IMK3IM6UICR7ci5jb3N0VXNkLnRvRml4ZWQoMyl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjYXNlIFwidG9vbENhbGxcIjoge1xuICAgICAgY29uc3QgdGMgPSBpdGVtLmRhdGEgYXMgRG9jPFwidG9vbENhbGxzXCI+O1xuICAgICAgY29uc3QgYWdlbnQgPSBhZ2VudE1hcC5nZXQodGMuYWdlbnRJZCk7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17VElNRUxJTkVfRU5UUllfQ0xBU1N9PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWluay1tdXRlZFwiPnt0aW1lfTwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWlua1wiPlxuICAgICAgICAgICAge2FnZW50Py5uYW1lIHx8IFwiQWdlbnRcIn0gwrcge3RjLnRvb2xOYW1lfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWluay1tdXRlZCBtdC0wLjVcIj5cbiAgICAgICAgICAgIDxSaXNrQmFkZ2UgbGV2ZWw9e3RjLnJpc2tMZXZlbH0gLz4gwrcge3RjLnN0YXR1c31cbiAgICAgICAgICAgIHt0Yy5pbnB1dFByZXZpZXcgJiYgYCDCtyAke3RjLmlucHV0UHJldmlldy5zbGljZSgwLCA1MCl9Li4uYH1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApO1xuICAgIH1cblxuICAgIGNhc2UgXCJhcHByb3ZhbFwiOiB7XG4gICAgICBjb25zdCBhID0gaXRlbS5kYXRhIGFzIERvYzxcImFwcHJvdmFsc1wiPjtcbiAgICAgIGNvbnN0IGFnZW50ID0gYWdlbnRNYXAuZ2V0KGEucmVxdWVzdG9yQWdlbnRJZCk7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17VElNRUxJTkVfRU5UUllfQ0xBU1N9PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWluay1tdXRlZFwiPnt0aW1lfTwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWlua1wiPlxuICAgICAgICAgICAgQXBwcm92YWwgwrcgPFN0YXR1c0JhZGdlIHRvbmU9e2FwcHJvdmFsU3RhdHVzVG9uZShhLnN0YXR1cyl9Pntmb3JtYXRTdGF0dXNMYWJlbChhLnN0YXR1cyl9PC9TdGF0dXNCYWRnZT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1pbmstbXV0ZWQgbXQtMC41XCI+XG4gICAgICAgICAgICB7YS5hY3Rpb25TdW1tYXJ5fSDCtyB7YWdlbnQ/Lm5hbWUgfHwgXCJBZ2VudFwifVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICk7XG4gICAgfVxuXG4gICAgY2FzZSBcImFjdGl2aXR5XCI6IHtcbiAgICAgIGNvbnN0IGFjdGl2aXR5ID0gaXRlbS5kYXRhIGFzIERvYzxcImFjdGl2aXRpZXNcIj47XG4gICAgICBjb25zdCBhY3RvciA9IGZvcm1hdEFjdG9yTmFtZShhY3Rpdml0eS5hY3RvclR5cGUsIGFjdGl2aXR5LmFjdG9ySWQpO1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e1RJTUVMSU5FX0VOVFJZX0NMQVNTfT5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1pbmstbXV0ZWRcIj57dGltZX08L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1pbmtcIj5cbiAgICAgICAgICAgIEF1ZGl0IMK3IHthY3Rpdml0eS5hY3Rpb259IMK3IHthY3Rvcn1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1pbmstbXV0ZWQgd2hpdGVzcGFjZS1wcmUtd3JhcCBtdC0wLjVcIj5cbiAgICAgICAgICAgIHthY3Rpdml0eS5kZXNjcmlwdGlvbn1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApO1xuICAgIH1cblxuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBBUlRJRkFDVFMgVEFCXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbmZ1bmN0aW9uIEFydGlmYWN0c1RhYih7XG4gIHRhc2ssXG4gIG1lc3NhZ2VzLFxufToge1xuICB0YXNrOiBEb2M8XCJ0YXNrc1wiPjtcbiAgbWVzc2FnZXM6IERvYzxcIm1lc3NhZ2VzXCI+W107XG59KSB7XG4gIGNvbnN0IGFydGlmYWN0TWVzc2FnZXMgPSBtZXNzYWdlcy5maWx0ZXIobSA9PiBtLnR5cGUgPT09IFwiQVJUSUZBQ1RcIiB8fCBtLmFydGlmYWN0cyk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAge3Rhc2suZGVsaXZlcmFibGUgJiYgKFxuICAgICAgICA8U2VjdGlvbiB0aXRsZT1cIkRlbGl2ZXJhYmxlXCI+XG4gICAgICAgICAge3Rhc2suZGVsaXZlcmFibGUuc3VtbWFyeSAmJiAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtaW5rLXNlY29uZGFyeSBtYi0zXCI+e3Rhc2suZGVsaXZlcmFibGUuc3VtbWFyeX08L3A+XG4gICAgICAgICAgKX1cbiAgICAgICAgICB7dGFzay5kZWxpdmVyYWJsZS5hcnRpZmFjdElkcyAmJiB0YXNrLmRlbGl2ZXJhYmxlLmFydGlmYWN0SWRzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yIGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgICB7dGFzay5kZWxpdmVyYWJsZS5hcnRpZmFjdElkcy5tYXAoKGlkOiBzdHJpbmcpID0+IChcbiAgICAgICAgICAgICAgICA8U3RhdHVzQmFkZ2Uga2V5PXtpZH0gdG9uZT1cIm5ldXRyYWxcIiBjbGFzc05hbWU9XCJmb250LW1vbm9cIj57aWR9PC9TdGF0dXNCYWRnZT5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L1NlY3Rpb24+XG4gICAgICApfVxuXG4gICAgICB7YXJ0aWZhY3RNZXNzYWdlcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJBcnRpZmFjdCBNZXNzYWdlc1wiPlxuICAgICAgICAgIHthcnRpZmFjdE1lc3NhZ2VzLm1hcCgobSkgPT4gKFxuICAgICAgICAgICAgPGRpdiBrZXk9e20uX2lkfSBjbGFzc05hbWU9XCJtYi00IHAtMyBiZy1zdXJmYWNlLTIgYm9yZGVyIGJvcmRlci1saW5lIHJvdW5kZWQtbWRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtaW5rLW11dGVkIG1iLTEuNVwiPlxuICAgICAgICAgICAgICAgIHtuZXcgRGF0ZSgobSBhcyBhbnkpLl9jcmVhdGlvblRpbWUpLnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICB7bS5hcnRpZmFjdHMgJiYgbS5hcnRpZmFjdHMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0xLjUgZmxleC13cmFwIG10LTJcIj5cbiAgICAgICAgICAgICAgICAgIHttLmFydGlmYWN0cy5tYXAoKGE6IGFueSwgaTogbnVtYmVyKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxTdGF0dXNCYWRnZSBrZXk9e2l9IHRvbmU9XCJuZXV0cmFsXCI+e2EubmFtZX08L1N0YXR1c0JhZGdlPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9TZWN0aW9uPlxuICAgICAgKX1cblxuICAgICAgeyF0YXNrLmRlbGl2ZXJhYmxlICYmIGFydGlmYWN0TWVzc2FnZXMubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWluay1tdXRlZFwiPk5vIGFydGlmYWN0cyB5ZXQ8L3A+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufVxuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBBUFBST1ZBTFMgVEFCXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbmZ1bmN0aW9uIEFwcHJvdmFsc1RhYih7XG4gIGFwcHJvdmFscyxcbiAgYWdlbnRNYXAsXG59OiB7XG4gIGFwcHJvdmFsczogRG9jPFwiYXBwcm92YWxzXCI+W107XG4gIGFnZW50TWFwOiBNYXA8SWQ8XCJhZ2VudHNcIj4sIERvYzxcImFnZW50c1wiPj47XG59KSB7XG4gIGNvbnN0IGFwcHJvdmUgPSB1c2VNdXRhdGlvbihhcGkuYXBwcm92YWxzLmFwcHJvdmUpO1xuICBjb25zdCBkZW55ID0gdXNlTXV0YXRpb24oYXBpLmFwcHJvdmFscy5kZW55KTtcbiAgY29uc3QgW2RlY2lzaW9uUmVhc29ucywgc2V0RGVjaXNpb25SZWFzb25zXSA9IHVzZVN0YXRlPFJlY29yZDxzdHJpbmcsIHN0cmluZz4+KHt9KTtcbiAgY29uc3QgW2J1c3lBcHByb3ZhbElkLCBzZXRCdXN5QXBwcm92YWxJZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBpZiAoYXBwcm92YWxzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtaW5rLW11dGVkXCI+Tm8gYXBwcm92YWxzIGZvciB0aGlzIHRhc2s8L3A+O1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAge2FwcHJvdmFscy5tYXAoKGEpID0+IHtcbiAgICAgICAgY29uc3QgYWdlbnQgPSBhZ2VudE1hcC5nZXQoYS5yZXF1ZXN0b3JBZ2VudElkKTtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8ZGl2IGtleT17YS5faWR9IGNsYXNzTmFtZT1cInAtMyBiZy1zdXJmYWNlLTIgYm9yZGVyIGJvcmRlci1saW5lIHJvdW5kZWQtbWRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAgICAgICAge2FnZW50Py5uYW1lIHx8IFwiQWdlbnRcIn0gwrcge2EuYWN0aW9uVHlwZX0gwrcgPFJpc2tCYWRnZSBsZXZlbD17YS5yaXNrTGV2ZWx9IC8+XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPFN0YXR1c0JhZGdlIHRvbmU9e2FwcHJvdmFsU3RhdHVzVG9uZShhLnN0YXR1cyl9Pntmb3JtYXRTdGF0dXNMYWJlbChhLnN0YXR1cyl9PC9TdGF0dXNCYWRnZT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5rIG1iLTEuNVwiPnthLmFjdGlvblN1bW1hcnl9PC9kaXY+XG4gICAgICAgICAgICB7YS5qdXN0aWZpY2F0aW9uICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtaW5rLW11dGVkIG1iLTJcIj57YS5qdXN0aWZpY2F0aW9ufTwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHthLmRlY2lzaW9uUmVhc29uICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtaW5rLXNlY29uZGFyeSBwdC0yIGJvcmRlci10IGJvcmRlci1saW5lXCI+XG4gICAgICAgICAgICAgICAgPHN0cm9uZz5EZWNpc2lvbjo8L3N0cm9uZz4ge2EuZGVjaXNpb25SZWFzb259XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHtbXCJQRU5ESU5HXCIsIFwiRVNDQUxBVEVEXCJdLmluY2x1ZGVzKGEuc3RhdHVzKSAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBzcGFjZS15LTIgYm9yZGVyLXQgYm9yZGVyLWxpbmUgcHQtM1wiPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2RlY2lzaW9uUmVhc29uc1thLl9pZF0gPz8gXCJcIn1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+XG4gICAgICAgICAgICAgICAgICAgIHNldERlY2lzaW9uUmVhc29ucygoY3VycmVudCkgPT4gKHtcbiAgICAgICAgICAgICAgICAgICAgICAuLi5jdXJyZW50LFxuICAgICAgICAgICAgICAgICAgICAgIFthLl9pZF06IGV2ZW50LnRhcmdldC52YWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRlY2lzaW9uIHJlYXNvbiAocmVxdWlyZWQpXCJcbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BEZWNpc2lvbiByZWFzb24gZm9yICR7YS5hY3Rpb25TdW1tYXJ5fWB9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTkgdy1mdWxsIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMSBweC0zIHRleHQtc20gdGV4dC1pbmsgcGxhY2Vob2xkZXI6dGV4dC1pbmstbXV0ZWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXJpbmdcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtcbiAgICAgICAgICAgICAgICAgICAgICBidXN5QXBwcm92YWxJZCA9PT0gYS5faWQgfHwgIShkZWNpc2lvblJlYXNvbnNbYS5faWRdID8/IFwiXCIpLnRyaW0oKVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRCdXN5QXBwcm92YWxJZChhLl9pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGFwcHJvdmUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICBhcHByb3ZhbElkOiBhLl9pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGVjaWRlZEJ5VXNlcklkOiBcIm9wZXJhdG9yXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlYXNvbjogZGVjaXNpb25SZWFzb25zW2EuX2lkXS50cmltKCksXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghcmVzdWx0LnN1Y2Nlc3MpIHdpbmRvdy5hbGVydChyZXN1bHQuZXJyb3IgPz8gXCJBcHByb3ZhbCBmYWlsZWQuXCIpO1xuICAgICAgICAgICAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRCdXN5QXBwcm92YWxJZChudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIEFwcHJvdmVcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtcbiAgICAgICAgICAgICAgICAgICAgICBidXN5QXBwcm92YWxJZCA9PT0gYS5faWQgfHwgIShkZWNpc2lvblJlYXNvbnNbYS5faWRdID8/IFwiXCIpLnRyaW0oKVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRCdXN5QXBwcm92YWxJZChhLl9pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGRlbnkoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICBhcHByb3ZhbElkOiBhLl9pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGVjaWRlZEJ5VXNlcklkOiBcIm9wZXJhdG9yXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlYXNvbjogZGVjaXNpb25SZWFzb25zW2EuX2lkXS50cmltKCksXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghcmVzdWx0LnN1Y2Nlc3MpIHdpbmRvdy5hbGVydChyZXN1bHQuZXJyb3IgPz8gXCJSZWplY3Rpb24gZmFpbGVkLlwiKTtcbiAgICAgICAgICAgICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0QnVzeUFwcHJvdmFsSWQobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBSZWplY3RcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICk7XG4gICAgICB9KX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gQ09TVCBUQUJcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuZnVuY3Rpb24gQ29zdFRhYih7XG4gIHRhc2ssXG4gIHJ1bnMsXG59OiB7XG4gIHRhc2s6IERvYzxcInRhc2tzXCI+O1xuICBydW5zOiBEb2M8XCJydW5zXCI+W107XG59KSB7XG4gIGNvbnN0IHRvdGFsUnVuQ29zdCA9IHJ1bnMucmVkdWNlKChzdW0sIHIpID0+IHN1bSArIHIuY29zdFVzZCwgMCk7XG4gIGNvbnN0IGNvbXBsZXRlZFJ1bnMgPSBydW5zLmZpbHRlcihyID0+IHIuc3RhdHVzID09PSBcIkNPTVBMRVRFRFwiKTtcbiAgY29uc3QgZmFpbGVkUnVucyA9IHJ1bnMuZmlsdGVyKHIgPT4gci5zdGF0dXMgPT09IFwiRkFJTEVEXCIpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgIDxTZWN0aW9uIHRpdGxlPVwiQnVkZ2V0XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNCBmbGV4LXdyYXBcIj5cbiAgICAgICAgICB7dGFzay5idWRnZXRBbGxvY2F0ZWQgJiYgKFxuICAgICAgICAgICAgPFN0YXQgbGFiZWw9XCJBbGxvY2F0ZWRcIiB2YWx1ZT17YCQke3Rhc2suYnVkZ2V0QWxsb2NhdGVkLnRvRml4ZWQoMil9YH0gLz5cbiAgICAgICAgICApfVxuICAgICAgICAgIDxTdGF0IGxhYmVsPVwiQWN0dWFsIENvc3RcIiB2YWx1ZT17YCQke3Rhc2suYWN0dWFsQ29zdC50b0ZpeGVkKDIpfWB9IC8+XG4gICAgICAgICAge3Rhc2suYnVkZ2V0UmVtYWluaW5nICE9PSB1bmRlZmluZWQgJiYgKFxuICAgICAgICAgICAgPFN0YXRcbiAgICAgICAgICAgICAgbGFiZWw9XCJSZW1haW5pbmdcIlxuICAgICAgICAgICAgICB2YWx1ZT17YCQke3Rhc2suYnVkZ2V0UmVtYWluaW5nLnRvRml4ZWQoMil9YH1cbiAgICAgICAgICAgICAgbmVnYXRpdmU9e3Rhc2suYnVkZ2V0UmVtYWluaW5nIDwgMH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L1NlY3Rpb24+XG5cbiAgICAgIDxTZWN0aW9uIHRpdGxlPVwiUnVuc1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTQgZmxleC13cmFwIG1iLTRcIj5cbiAgICAgICAgICA8U3RhdCBsYWJlbD1cIlRvdGFsIFJ1bnNcIiB2YWx1ZT17cnVucy5sZW5ndGgudG9TdHJpbmcoKX0gLz5cbiAgICAgICAgICA8U3RhdCBsYWJlbD1cIkNvbXBsZXRlZFwiIHZhbHVlPXtjb21wbGV0ZWRSdW5zLmxlbmd0aC50b1N0cmluZygpfSAvPlxuICAgICAgICAgIDxTdGF0IGxhYmVsPVwiRmFpbGVkXCIgdmFsdWU9e2ZhaWxlZFJ1bnMubGVuZ3RoLnRvU3RyaW5nKCl9IC8+XG4gICAgICAgICAgPFN0YXQgbGFiZWw9XCJSdW4gQ29zdFwiIHZhbHVlPXtgJCR7dG90YWxSdW5Db3N0LnRvRml4ZWQoMyl9YH0gLz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAge3J1bnMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgIHtydW5zLnNsaWNlKC0xMCkucmV2ZXJzZSgpLm1hcCgocikgPT4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17ci5faWR9IGNsYXNzTmFtZT1cInAtMyBiZy1zdXJmYWNlLTIgYm9yZGVyIGJvcmRlci1saW5lIHJvdW5kZWQtbWQgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gbWItMVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1pbmstbXV0ZWRcIj57ci5tb2RlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWluayBmb250LW1lZGl1bVwiPiR7ci5jb3N0VXNkLnRvRml4ZWQoMyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAge3IuaW5wdXRUb2tlbnMudG9Mb2NhbGVTdHJpbmcoKX0gaW4gwrcge3Iub3V0cHV0VG9rZW5zLnRvTG9jYWxlU3RyaW5nKCl9IG91dFxuICAgICAgICAgICAgICAgICAge3IuZHVyYXRpb25NcyAmJiBgIMK3ICR7KHIuZHVyYXRpb25NcyAvIDEwMDApLnRvRml4ZWQoMSl9c2B9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L1NlY3Rpb24+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbi8vIFdIWSBUQUIgKEV4cGxhaW5hYmlsaXR5IFBhbmVsKVxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuXG5mdW5jdGlvbiBXaHlUYWIoe1xuICB0YXNrLFxuICBhZ2VudE1hcCxcbiAgdHJhbnNpdGlvbnMsXG59OiB7XG4gIHRhc2s6IERvYzxcInRhc2tzXCI+O1xuICBhZ2VudE1hcDogTWFwPElkPFwiYWdlbnRzXCI+LCBEb2M8XCJhZ2VudHNcIj4+O1xuICB0cmFuc2l0aW9uczogYW55W107XG59KSB7XG4gIGNvbnN0IGFzc2lnbmVlcyA9IHRhc2suYXNzaWduZWVJZHNcbiAgICAubWFwKChpZDogSWQ8XCJhZ2VudHNcIj4pID0+IGFnZW50TWFwLmdldChpZCkpXG4gICAgLmZpbHRlcigoYWdlbnQpOiBhZ2VudCBpcyBEb2M8XCJhZ2VudHNcIj4gPT4gISFhZ2VudCk7XG4gIGNvbnN0IGFsbG93ZWRUcmFuc2l0aW9ucyA9IHVzZVF1ZXJ5KGFwaS50YXNrcy5nZXRBbGxvd2VkVHJhbnNpdGlvbnNGb3JIdW1hbik7XG4gIGNvbnN0IFtzaW11bGF0ZVRvU3RhdHVzLCBzZXRTaW11bGF0ZVRvU3RhdHVzXSA9IHVzZVN0YXRlPFRhc2tTdGF0dXMgfCBcIlwiPihcIlwiKTtcblxuICBjb25zdCB0cmFuc2l0aW9uQ2hvaWNlcyA9IChhbGxvd2VkVHJhbnNpdGlvbnM/Llt0YXNrLnN0YXR1c10gYXMgVGFza1N0YXR1c1tdIHwgdW5kZWZpbmVkKSA/PyBbXTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXNpbXVsYXRlVG9TdGF0dXMgJiYgdHJhbnNpdGlvbkNob2ljZXMubGVuZ3RoID4gMCkge1xuICAgICAgc2V0U2ltdWxhdGVUb1N0YXR1cyh0cmFuc2l0aW9uQ2hvaWNlc1swXSk7XG4gICAgfVxuICB9LCBbc2ltdWxhdGVUb1N0YXR1cywgdHJhbnNpdGlvbkNob2ljZXNdKTtcblxuICBjb25zdCB0cmFuc2l0aW9uU2ltdWxhdGlvbiA9IHVzZVF1ZXJ5KFxuICAgIGFwaS50YXNrcy5zaW11bGF0ZVRyYW5zaXRpb24sXG4gICAgc2ltdWxhdGVUb1N0YXR1c1xuICAgICAgPyB7XG4gICAgICAgICAgdGFza0lkOiB0YXNrLl9pZCxcbiAgICAgICAgICB0b1N0YXR1czogc2ltdWxhdGVUb1N0YXR1cyxcbiAgICAgICAgICBhY3RvclR5cGU6IFwiSFVNQU5cIixcbiAgICAgICAgICBoYXNXb3JrUGxhbjogISF0YXNrLndvcmtQbGFuLFxuICAgICAgICAgIGhhc0RlbGl2ZXJhYmxlOiAhIXRhc2suZGVsaXZlcmFibGUsXG4gICAgICAgICAgaGFzQ2hlY2tsaXN0OiAhIXRhc2sucmV2aWV3Q2hlY2tsaXN0LFxuICAgICAgICB9XG4gICAgICA6IFwic2tpcFwiXG4gICk7XG5cbiAgY29uc3QgcG9saWN5RGVjaXNpb24gPSB1c2VRdWVyeShhcGkucG9saWN5LmV4cGxhaW5UYXNrUG9saWN5LCB7XG4gICAgdGFza0lkOiB0YXNrLl9pZCxcbiAgICBwbGFubmVkVHJhbnNpdGlvblRvOiBzaW11bGF0ZVRvU3RhdHVzIHx8IHVuZGVmaW5lZCxcbiAgICBlc3RpbWF0ZWRDb3N0OiB0YXNrLmVzdGltYXRlZENvc3QsXG4gIH0pO1xuXG4gIGNvbnN0IHJpc2tMZXZlbCA9IHBvbGljeURlY2lzaW9uPy5yaXNrTGV2ZWwgPz8gXCJHUkVFTlwiO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgIDxzZWN0aW9uPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtaW5rIG1iLTNcIj5Qb2xpY3kgRGVjaXNpb24gVmlld2VyPC9oMz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctc3VyZmFjZS0yIGJvcmRlciBib3JkZXItbGluZSByb3VuZGVkLW1kXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgIDxSaXNrQmFkZ2UgbGV2ZWw9e3Jpc2tMZXZlbH0gLz5cbiAgICAgICAgICAgIDxTdGF0dXNCYWRnZVxuICAgICAgICAgICAgICB0b25lPXtwb2xpY3lEZWNpc2lvbj8uZGVjaXNpb24gPT09IFwiQUxMT1dcIiA/IFwic3VjY2Vzc1wiIDogcG9saWN5RGVjaXNpb24/LmRlY2lzaW9uID09PSBcIkRFTllcIiA/IFwiZXJyb3JcIiA6IFwibmV1dHJhbFwifVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7cG9saWN5RGVjaXNpb24/LmRlY2lzaW9uID8/IFwiQW5hbHl6aW5nLi4uXCJ9XG4gICAgICAgICAgICA8L1N0YXR1c0JhZGdlPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LWluay1zZWNvbmRhcnlcIj5cbiAgICAgICAgICAgIHtwb2xpY3lEZWNpc2lvbj8ucmVhc29uID8/IFwiQ2FsY3VsYXRpbmcgcG9saWN5IG91dGNvbWUuLi5cIn1cbiAgICAgICAgICA8L3A+XG4gICAgICAgICAge3BvbGljeURlY2lzaW9uPy50cmlnZ2VyZWRSdWxlcyAmJiBwb2xpY3lEZWNpc2lvbi50cmlnZ2VyZWRSdWxlcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtM1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1pbmstbXV0ZWQgbWItMS41XCI+VHJpZ2dlcmVkIHJ1bGVzPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMS41IGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgICAgIHtwb2xpY3lEZWNpc2lvbi50cmlnZ2VyZWRSdWxlcy5tYXAoKHJ1bGU6IHN0cmluZykgPT4gKFxuICAgICAgICAgICAgICAgICAgPFN0YXR1c0JhZGdlIGtleT17cnVsZX0gdG9uZT1cIm5ldXRyYWxcIiBjbGFzc05hbWU9XCJmb250LW1vbm9cIj57cnVsZX08L1N0YXR1c0JhZGdlPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgICAge3BvbGljeURlY2lzaW9uPy5yZXF1aXJlZEFwcHJvdmFscz8ubGVuZ3RoID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWluay1tdXRlZCBtYi0xLjVcIj5SZXF1aXJlZCBhcHByb3ZhbHM8L2Rpdj5cbiAgICAgICAgICAgICAge3BvbGljeURlY2lzaW9uLnJlcXVpcmVkQXBwcm92YWxzLm1hcCgoYXBwcm92YWw6IHsgdHlwZTogc3RyaW5nOyByZWFzb246IHN0cmluZyB9LCBpbmRleDogbnVtYmVyKSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2Ake2FwcHJvdmFsLnR5cGV9LSR7aW5kZXh9YH0gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWluay1zZWNvbmRhcnkgbWItMVwiPlxuICAgICAgICAgICAgICAgICAg4oCiIHthcHByb3ZhbC50eXBlfToge2FwcHJvdmFsLnJlYXNvbn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICB7cG9saWN5RGVjaXNpb24/LnJlbWVkaWF0aW9uSGludHM/Lmxlbmd0aCA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtM1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1pbmstbXV0ZWQgbWItMS41XCI+UmVtZWRpYXRpb24gaGludHM8L2Rpdj5cbiAgICAgICAgICAgICAge3BvbGljeURlY2lzaW9uLnJlbWVkaWF0aW9uSGludHMubWFwKChoaW50OiBzdHJpbmcsIGluZGV4OiBudW1iZXIpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17YCR7aGludH0tJHtpbmRleH1gfSBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtaW5rLXNlY29uZGFyeSBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICDigKIge2hpbnR9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICA8c2VjdGlvbj5cbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWluayBtYi0zXCI+RHJ5IFJ1biBTaW11bGF0aW9uPC9oMz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctc3VyZmFjZS0yIGJvcmRlciBib3JkZXItbGluZSByb3VuZGVkLW1kXCI+XG4gICAgICAgICAge3RyYW5zaXRpb25DaG9pY2VzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTNcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtaW5rLW11dGVkXCI+U2ltdWxhdGUgdHJhbnNpdGlvbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2ltdWxhdGVUb1N0YXR1c31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFNpbXVsYXRlVG9TdGF0dXMoZXZlbnQudGFyZ2V0LnZhbHVlIGFzIFRhc2tTdGF0dXMpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMiBweS0xIGJnLXN1cmZhY2UtMSBib3JkZXIgYm9yZGVyLWxpbmUgcm91bmRlZC1tZCB0ZXh0LXNtIHRleHQtaW5rXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7dHJhbnNpdGlvbkNob2ljZXMubWFwKChjaG9pY2U6IFRhc2tTdGF0dXMpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2Nob2ljZX0gdmFsdWU9e2Nob2ljZX0+XG4gICAgICAgICAgICAgICAgICAgICAge3Rhc2suc3RhdHVzfSDihpIge2Nob2ljZX1cbiAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAge3RyYW5zaXRpb25TaW11bGF0aW9uID8gKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8RXhwbGFpblJvd1xuICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlJlc3VsdFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0cmFuc2l0aW9uU2ltdWxhdGlvbi52YWxpZCA/IFwiVkFMSURcIiA6IFwiSU5WQUxJRFwifVxuICAgICAgICAgICAgICAgICAgICBkZXRhaWw9e3RyYW5zaXRpb25TaW11bGF0aW9uLnZhbGlkID8gXCJObyBibG9ja2luZyB0cmFuc2l0aW9uIHJ1bGVcIiA6IFwiT25lIG9yIG1vcmUgY2hlY2tzIGZhaWxlZFwifVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxFeHBsYWluUm93XG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQWN0b3JcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dHJhbnNpdGlvblNpbXVsYXRpb24uYWN0b3JUeXBlfVxuICAgICAgICAgICAgICAgICAgICBkZXRhaWw9XCJEcnktcnVuIGV2YWx1YXRlcyBIVU1BTiBhY3Rpb25zIGJ5IGRlZmF1bHRcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIHt0cmFuc2l0aW9uU2ltdWxhdGlvbi5yZXF1aXJlbWVudHMgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8RXhwbGFpblJvd1xuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiUmVxdWlyZW1lbnRzXCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17W1xuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvblNpbXVsYXRpb24ucmVxdWlyZW1lbnRzLnJlcXVpcmVzV29ya1BsYW4gPyBcIndvcmsgcGxhblwiIDogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb25TaW11bGF0aW9uLnJlcXVpcmVtZW50cy5yZXF1aXJlc0RlbGl2ZXJhYmxlID8gXCJkZWxpdmVyYWJsZVwiIDogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb25TaW11bGF0aW9uLnJlcXVpcmVtZW50cy5yZXF1aXJlc0NoZWNrbGlzdCA/IFwiY2hlY2tsaXN0XCIgOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvblNpbXVsYXRpb24ucmVxdWlyZW1lbnRzLmh1bWFuT25seSA/IFwiaHVtYW4tb25seVwiIDogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKEJvb2xlYW4pXG4gICAgICAgICAgICAgICAgICAgICAgICAuam9pbihcIiwgXCIpIHx8IFwibm9uZVwifVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIHt0cmFuc2l0aW9uU2ltdWxhdGlvbi5lcnJvcnM/Lmxlbmd0aCA/IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3RyYW5zaXRpb25TaW11bGF0aW9uLmVycm9ycy5tYXAoKGVycm9yOiB7IGZpZWxkOiBzdHJpbmc7IG1lc3NhZ2U6IHN0cmluZyB9KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17YCR7ZXJyb3IuZmllbGR9LSR7ZXJyb3IubWVzc2FnZX1gfSBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZXJyIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAg4oCiIHtlcnJvci5maWVsZH06IHtlcnJvci5tZXNzYWdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtaW5rLW11dGVkXCI+UnVubmluZyBzaW11bGF0aW9uLi4uPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAgICAgIE5vIGh1bWFuIHRyYW5zaXRpb25zIGF2YWlsYWJsZSBmcm9tIHt0YXNrLnN0YXR1c30uXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgPHNlY3Rpb24+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmsgbWItM1wiPkFzc2lnbm1lbnQgQ29udGV4dDwvaDM+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXN1cmZhY2UtMiBib3JkZXIgYm9yZGVyLWxpbmUgcm91bmRlZC1tZFwiPlxuICAgICAgICAgIHthc3NpZ25lZXMubGVuZ3RoID8gKFxuICAgICAgICAgICAgYXNzaWduZWVzLm1hcCgoYWdlbnQ6IERvYzxcImFnZW50c1wiPikgPT4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17YWdlbnQuX2lkfSBjbGFzc05hbWU9XCJtYi0yLjVcIj5cbiAgICAgICAgICAgICAgICA8RXhwbGFpblJvdyBsYWJlbD1cIkFnZW50XCIgdmFsdWU9e2FnZW50Lm5hbWV9IC8+XG4gICAgICAgICAgICAgICAgPEV4cGxhaW5Sb3cgbGFiZWw9XCJSb2xlXCIgdmFsdWU9e2FnZW50LnJvbGV9IC8+XG4gICAgICAgICAgICAgICAgPEV4cGxhaW5Sb3cgbGFiZWw9XCJTdGF0dXNcIiB2YWx1ZT17YWdlbnQuc3RhdHVzfSAvPlxuICAgICAgICAgICAgICAgIDxFeHBsYWluUm93XG4gICAgICAgICAgICAgICAgICBsYWJlbD1cIkNhcGFiaWxpdGllc1wiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17YWdlbnQuYWxsb3dlZFRhc2tUeXBlcy5sZW5ndGggPyBhZ2VudC5hbGxvd2VkVGFza1R5cGVzLmpvaW4oXCIsIFwiKSA6IFwiQWxsIHR5cGVzXCJ9XG4gICAgICAgICAgICAgICAgICBkZXRhaWw9e2FnZW50LmFsbG93ZWRUYXNrVHlwZXMuaW5jbHVkZXModGFzay50eXBlKSA/IFwiTWF0Y2hlcyB0YXNrIHR5cGVcIiA6IFwiTm8gZGlyZWN0IHR5cGUgbWF0Y2hcIn1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkpXG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1pbmstbXV0ZWRcIj5cbiAgICAgICAgICAgICAgTm8gYXNzaWduZWUgeWV0LiBBc3NpZ25pbmcgYW4gYWN0aXZlIGFnZW50IGltcHJvdmVzIHBvbGljeSBjb25maWRlbmNlIGFuZCBzaW11bGF0aW9uIGFjY3VyYWN5LlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICA8c2VjdGlvbj5cbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWluayBtYi0zXCI+VGFzayBQcm9wZXJ0aWVzPC9oMz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctc3VyZmFjZS0yIGJvcmRlciBib3JkZXItbGluZSByb3VuZGVkLW1kIHNwYWNlLXktMS41XCI+XG4gICAgICAgICAgPEV4cGxhaW5Sb3cgbGFiZWw9XCJUeXBlXCIgdmFsdWU9e3Rhc2sudHlwZX0gZGV0YWlsPVwiRGV0ZXJtaW5lcyBkZWNvbXBvc2l0aW9uIHN0cmF0ZWd5IGFuZCBhZ2VudCBtYXRjaGluZ1wiIC8+XG4gICAgICAgICAgPEV4cGxhaW5Sb3cgbGFiZWw9XCJQcmlvcml0eVwiIHZhbHVlPXtgUCR7dGFzay5wcmlvcml0eX1gfSBkZXRhaWw9XCJIaWdoZXIgcHJpb3JpdHkgPSBoaWdoZXIgc2NvcmUgZm9yIGFnZW50IHNlbGVjdGlvblwiIC8+XG4gICAgICAgICAgPEV4cGxhaW5Sb3dcbiAgICAgICAgICAgIGxhYmVsPVwiU291cmNlXCJcbiAgICAgICAgICAgIHZhbHVlPXsoU09VUkNFX0NPTkZJR1t0YXNrLnNvdXJjZSA/PyBcIlwiXSB8fCBTT1VSQ0VfQ09ORklHLlVOS05PV04pLmxhYmVsfVxuICAgICAgICAgICAgZGV0YWlsPXt0YXNrLnNvdXJjZVJlZiA/IGBSZWY6ICR7dGFzay5zb3VyY2VSZWZ9YCA6ICh0YXNrLmNyZWF0ZWRCeSA/IGBDcmVhdGVkIGJ5OiAke0NSRUFURURfQllfTEFCRUxTW3Rhc2suY3JlYXRlZEJ5XSB8fCB0YXNrLmNyZWF0ZWRCeX1gIDogXCJIb3cgdGhlIHRhc2sgZW50ZXJlZCB0aGUgc3lzdGVtXCIpfVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPEV4cGxhaW5Sb3dcbiAgICAgICAgICAgIGxhYmVsPVwiQ3JlYXRlZFwiXG4gICAgICAgICAgICB2YWx1ZT17bmV3IERhdGUodGFzay5fY3JlYXRpb25UaW1lKS50b0xvY2FsZURhdGVTdHJpbmcoKX1cbiAgICAgICAgICAgIGRldGFpbD17bmV3IERhdGUodGFzay5fY3JlYXRpb25UaW1lKS50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgIC8+XG4gICAgICAgICAge3Rhc2sucGFyZW50VGFza0lkICYmIChcbiAgICAgICAgICAgIDxFeHBsYWluUm93IGxhYmVsPVwiUGFyZW50IFRhc2tcIiB2YWx1ZT17U3RyaW5nKHRhc2sucGFyZW50VGFza0lkKX0gZGV0YWlsPVwiVGhpcyBpcyBhIHN1YnRhc2sgb2YgYSBkZWNvbXBvc2VkIG1pc3Npb25cIiAvPlxuICAgICAgICAgICl9XG4gICAgICAgICAge3Rhc2subGFiZWxzICYmIHRhc2subGFiZWxzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPEV4cGxhaW5Sb3cgbGFiZWw9XCJMYWJlbHNcIiB2YWx1ZT17dGFzay5sYWJlbHMuam9pbihcIiwgXCIpfSAvPlxuICAgICAgICAgICl9XG4gICAgICAgICAgPEV4cGxhaW5Sb3dcbiAgICAgICAgICAgIGxhYmVsPVwiUmVjZW50IHRyYW5zaXRpb25zXCJcbiAgICAgICAgICAgIHZhbHVlPXtTdHJpbmcodHJhbnNpdGlvbnMubGVuZ3RoKX1cbiAgICAgICAgICAgIGRldGFpbD17dHJhbnNpdGlvbnMubGVuZ3RoID8gXCJJbmNsdWRlZCBpbiB0YXNrIGF1ZGl0IHRyYWlsXCIgOiBcIk5vIHRyYW5zaXRpb25zIHlldFwifVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4vLyBIRUxQRVIgQ09NUE9ORU5UU1xuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuXG5mdW5jdGlvbiBUYWJCdXR0b24oe1xuICBhY3RpdmUsXG4gIG9uQ2xpY2ssXG4gIGNoaWxkcmVuLFxufToge1xuICBhY3RpdmU6IGJvb2xlYW47XG4gIG9uQ2xpY2s6ICgpID0+IHZvaWQ7XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG59KSB7XG4gIHJldHVybiAoXG4gICAgPGJ1dHRvblxuICAgICAgcm9sZT1cInRhYlwiXG4gICAgICBhcmlhLXNlbGVjdGVkPXthY3RpdmV9XG4gICAgICBvbkNsaWNrPXtvbkNsaWNrfVxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCItbWItcHggZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBib3JkZXItYi0yIHB4LTMgcHktMi41IHRleHQtWzEzcHhdIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiLFxuICAgICAgICBhY3RpdmVcbiAgICAgICAgICA/IFwiYm9yZGVyLWluayB0ZXh0LWlua1wiXG4gICAgICAgICAgOiBcImJvcmRlci10cmFuc3BhcmVudCB0ZXh0LWluay1tdXRlZCBob3Zlcjp0ZXh0LWluay1zZWNvbmRhcnlcIlxuICAgICAgKX1cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9idXR0b24+XG4gICk7XG59XG5cbmZ1bmN0aW9uIFNlY3Rpb24oeyB0aXRsZSwgY2hpbGRyZW4gfTogeyB0aXRsZTogc3RyaW5nOyBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWluay1tdXRlZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItM1wiPlxuICAgICAgICB7dGl0bGV9XG4gICAgICA8L2gzPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvZGl2PlxuICApO1xufVxuXG5mdW5jdGlvbiBFeHBsYWluUm93KHtcbiAgbGFiZWwsXG4gIHZhbHVlLFxuICBkZXRhaWwsXG59OiB7XG4gIGxhYmVsOiBzdHJpbmc7XG4gIHZhbHVlOiBzdHJpbmc7XG4gIGRldGFpbD86IHN0cmluZztcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTIgaXRlbXMtYmFzZWxpbmVcIj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1pbmstbXV0ZWQgdy1bMTAwcHhdIHNocmluay0wXCI+e2xhYmVsfTwvc3Bhbj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1pbmsgZm9udC1tZWRpdW1cIj57dmFsdWV9PC9zcGFuPlxuICAgICAge2RldGFpbCAmJiAoXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1pbmstbXV0ZWQgaXRhbGljXCI+4oCUIHtkZXRhaWx9PC9zcGFuPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gU3RhdCh7XG4gIGxhYmVsLFxuICB2YWx1ZSxcbiAgbmVnYXRpdmUsXG59OiB7XG4gIGxhYmVsOiBzdHJpbmc7XG4gIHZhbHVlOiBzdHJpbmc7XG4gIG5lZ2F0aXZlPzogYm9vbGVhbjtcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1zdXJmYWNlLTIgYm9yZGVyIGJvcmRlci1saW5lIHJvdW5kZWQtbWRcIj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1pbmstbXV0ZWQgYmxvY2tcIj57bGFiZWx9PC9zcGFuPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPXtjbihcInRleHQtbGcgZm9udC1zZW1pYm9sZFwiLCBuZWdhdGl2ZSA/IFwidGV4dC1lcnJcIiA6IFwidGV4dC1pbmtcIil9PlxuICAgICAgICB7dmFsdWV9XG4gICAgICA8L3NwYW4+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbi8vIFNPVVJDRSBCQURHRVxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuXG5jb25zdCBTT1VSQ0VfQ09ORklHOiBSZWNvcmQ8c3RyaW5nLCB7IGxhYmVsOiBzdHJpbmcgfT4gPSB7XG4gIERBU0hCT0FSRDogeyBsYWJlbDogXCJEYXNoYm9hcmRcIiB9LFxuICBURUxFR1JBTTogeyBsYWJlbDogXCJUZWxlZ3JhbVwiIH0sXG4gIEdJVEhVQjogeyBsYWJlbDogXCJHaXRIdWJcIiB9LFxuICBBR0VOVDogeyBsYWJlbDogXCJBZ2VudFwiIH0sXG4gIEFQSTogeyBsYWJlbDogXCJBUElcIiB9LFxuICBUUkVMTE86IHsgbGFiZWw6IFwiVHJlbGxvXCIgfSxcbiAgU0VFRDogeyBsYWJlbDogXCJTZWVkIERhdGFcIiB9LFxuICBNSVNTSU9OX1BST01QVDogeyBsYWJlbDogXCJNaXNzaW9uXCIgfSxcbiAgUFJEX0lNUE9SVDogeyBsYWJlbDogXCJJbXBvcnRlZCBQUkRcIiB9LFxuICBVTktOT1dOOiB7IGxhYmVsOiBcIlVua25vd25cIiB9LFxufTtcblxuY29uc3QgQ1JFQVRFRF9CWV9MQUJFTFM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gIEhVTUFOOiBcIkh1bWFuXCIsXG4gIEFHRU5UOiBcIkFJIEFnZW50XCIsXG4gIFNZU1RFTTogXCJTeXN0ZW1cIixcbn07XG5cbmZ1bmN0aW9uIFNvdXJjZUJhZGdlKHtcbiAgc291cmNlLFxuICBzb3VyY2VSZWYsXG4gIGNyZWF0ZWRCeSxcbn06IHtcbiAgc291cmNlPzogc3RyaW5nO1xuICBzb3VyY2VSZWY/OiBzdHJpbmc7XG4gIGNyZWF0ZWRCeT86IHN0cmluZztcbn0pIHtcbiAgY29uc3Qgc3JjID0gU09VUkNFX0NPTkZJR1tzb3VyY2UgPz8gXCJcIl0gfHwgU09VUkNFX0NPTkZJRy5VTktOT1dOO1xuICBjb25zdCBjcmVhdG9yTGFiZWwgPSBDUkVBVEVEX0JZX0xBQkVMU1tjcmVhdGVkQnkgPz8gXCJcIl0gfHwgbnVsbDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgPFN0YXR1c0JhZGdlIHRvbmU9XCJuZXV0cmFsXCI+e3NyYy5sYWJlbH08L1N0YXR1c0JhZGdlPlxuICAgICAgICB7Y3JlYXRvckxhYmVsICYmIChcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtaW5rLW11dGVkXCI+Ynkge2NyZWF0b3JMYWJlbH08L3NwYW4+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICAgIHtzb3VyY2VSZWYgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1pbmstbXV0ZWRcIj5cbiAgICAgICAgICBSZWY6IDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LWluay1zZWNvbmRhcnlcIj57c291cmNlUmVmfTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvamF5d2VzdC9NaXNzaW9uQ29udHJvbC8ud29ya3RyZWVzL2NvZGV4L3NvZnR3YXJlLWZhY3RvcnktZW5oYW5jZW1lbnQtcGxhbi8ud29ya3RyZWVzL2NvZGV4L2F1dG9tYXRpb24tY29udHJvbC1wbGFuZS12MS9hcHBzL21pc3Npb24tY29udHJvbC11aS9zcmMvVGFza0RyYXdlclRhYnMudHN4In0=