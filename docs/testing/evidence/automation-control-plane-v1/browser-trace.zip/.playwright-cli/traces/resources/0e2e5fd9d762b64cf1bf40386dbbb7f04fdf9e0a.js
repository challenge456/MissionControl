import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Kanban.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport3_react["useState"];
import { useMutation, useQuery } from "/node_modules/.vite/deps/convex_react.js?v=d5011b43";
import { api } from "/@fs/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/convex/_generated/api.js";
import { useToast } from "/src/Toast.tsx";
import { cn } from "/src/lib/utils.ts";
import { StatusBadge } from "/src/components/factory/badges.tsx";
import { PriorityChip } from "/src/components/PriorityChip.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { ScrollArea } from "/src/components/ui/scroll-area.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "/src/components/ui/dropdown-menu.tsx";
import {
  DndContext,
  DragOverlay,
  closestCorners,
  PointerSensor,
  TouchSensor,
  useSensor,
  useSensors,
  useDroppable,
  useDraggable
} from "/node_modules/.vite/deps/@dnd-kit_core.js?v=1eb95e36";
import {
  Inbox,
  UserCheck,
  Play,
  Eye,
  ShieldAlert,
  Ban,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  ArrowRight,
  Undo2,
  DollarSign,
  GripVertical,
  ExternalLink,
  Sparkles
} from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import { PlanningModal } from "/src/PlanningModal.tsx";
const COLUMNS = [
  { status: "INBOX", label: "Inbox", color: "text-ink-muted", icon: Inbox },
  { status: "ASSIGNED", label: "Assigned", color: "text-ink-muted", icon: UserCheck },
  { status: "IN_PROGRESS", label: "In Progress", color: "text-ink-muted", icon: Play },
  { status: "REVIEW", label: "Review", color: "text-ink-muted", icon: Eye },
  { status: "NEEDS_APPROVAL", label: "Needs Approval", color: "text-ink-muted", icon: ShieldAlert },
  { status: "BLOCKED", label: "Blocked", color: "text-ink-muted", icon: Ban },
  { status: "FAILED", label: "Failed", color: "text-ink-muted", icon: AlertTriangle },
  { status: "DONE", label: "Done", color: "text-ink-muted", icon: CheckCircle2 },
  { status: "CANCELED", label: "Canceled", color: "text-ink-muted", icon: XCircle }
];
const COLUMN_DOT = {
  INBOX: "bg-ink-muted",
  ASSIGNED: "bg-ink-muted",
  IN_PROGRESS: "bg-info-accent",
  REVIEW: "bg-info-accent",
  NEEDS_APPROVAL: "bg-warn",
  BLOCKED: "bg-warn",
  FAILED: "bg-err",
  DONE: "bg-ok",
  CANCELED: "bg-ink-muted"
};
const SOURCE_CONFIG = {
  DASHBOARD: { label: "Dashboard" },
  TELEGRAM: { label: "Telegram" },
  GITHUB: { label: "GitHub" },
  AGENT: { label: "Agent" },
  API: { label: "API" },
  TRELLO: { label: "Trello" },
  SEED: { label: "Seed" },
  MISSION_PROMPT: { label: "Mission", isSpecial: true },
  PRD_IMPORT: { label: "Imported PRD", isSpecial: true },
  UNKNOWN: { label: "Unknown" }
};
const STATUS_LABELS = {
  INBOX: "Inbox",
  ASSIGNED: "Assigned",
  IN_PROGRESS: "In Progress",
  REVIEW: "Review",
  NEEDS_APPROVAL: "Needs Approval",
  BLOCKED: "Blocked",
  FAILED: "Failed",
  DONE: "Done",
  CANCELED: "Canceled"
};
export function Kanban({
  projectId,
  onSelectTask,
  filters
}) {
  _s();
  const [activeTask, setActiveTask] = useState(null);
  const [planningTaskId, setPlanningTaskId] = useState(null);
  const [lastMove, setLastMove] = useState(null);
  const tasks = useQuery(api.tasks.listAll, projectId ? { projectId } : {});
  const agents = useQuery(api.agents.listAll, projectId ? { projectId } : {});
  const allowedMap = useQuery(api.tasks.getAllowedTransitionsForHuman);
  const transitionTask = useMutation(api.tasks.transition);
  const { toast } = useToast();
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: { distance: 8 }
    }),
    useSensor(TouchSensor, {
      activationConstraint: { delay: 250, tolerance: 5 }
    })
  );
  if (tasks === void 0 || agents === void 0) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-3 p-6", "aria-label": "Loading tasks", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "h-4 w-48 animate-pulse rounded bg-surface-2" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
        lineNumber: 185,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "h-4 w-72 animate-pulse rounded bg-surface-2" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
        lineNumber: 186,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "h-4 w-56 animate-pulse rounded bg-surface-2" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
        lineNumber: 187,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
      lineNumber: 184,
      columnNumber: 7
    }, this);
  }
  const filteredTasks = tasks.filter((task) => {
    if (!filters) return true;
    if (filters.agents.length > 0) {
      const hasMatchingAgent = task.assigneeIds.some(
        (id) => filters.agents.includes(id)
      );
      if (!hasMatchingAgent && task.assigneeIds.length > 0) return false;
    }
    if (filters.priorities.length > 0) {
      if (!filters.priorities.includes(task.priority)) return false;
    }
    if (filters.types.length > 0) {
      if (!filters.types.includes(task.type)) return false;
    }
    return true;
  });
  const agentMap = new Map(
    agents.map((a) => [a._id, a])
  );
  const byStatus = (status) => filteredTasks.filter((t) => t.status === status);
  const handleMoveTo = async (taskId, fromStatus, toStatus) => {
    try {
      const result = await transitionTask({
        taskId,
        toStatus,
        actorType: "HUMAN",
        actorUserId: "operator",
        idempotencyKey: `ui-${taskId}-${toStatus}-${Date.now()}`
      });
      if (result && typeof result === "object" && "success" in result && !result.success) {
        const err = result.errors?.[0]?.message ?? "Transition failed";
        toast(err, true);
      } else {
        setLastMove({ taskId, fromStatus, toStatus });
        toast(`Moved to ${STATUS_LABELS[toStatus]}`);
      }
    } catch (e) {
      toast(e instanceof Error ? e.message : "Transition failed", true);
    }
  };
  const handleUndo = async () => {
    if (!lastMove) return;
    try {
      await transitionTask({
        taskId: lastMove.taskId,
        toStatus: lastMove.fromStatus,
        actorType: "HUMAN",
        actorUserId: "operator",
        idempotencyKey: `undo-${lastMove.taskId}-${Date.now()}`
      });
      toast("Undone");
      setLastMove(null);
    } catch (e) {
      toast(e instanceof Error ? e.message : "Undo failed", true);
    }
  };
  const handleDragStart = (event) => {
    const task = filteredTasks.find((t) => t._id === event.active.id);
    if (task) setActiveTask(task);
  };
  const handleDragEnd = (event) => {
    setActiveTask(null);
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const task = filteredTasks.find((t) => t._id === active.id);
    const toStatus = over.id;
    if (!task) return;
    const allowed = allowedMap?.[task.status] ?? [];
    if (!allowed.includes(toStatus)) {
      toast("Transition not allowed", true);
      return;
    }
    handleMoveTo(task._id, task.status, toStatus);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-0 flex-1 flex-col", children: /* @__PURE__ */ jsxDEV(
    DndContext,
    {
      sensors,
      collisionDetection: closestCorners,
      onDragStart: handleDragStart,
      onDragEnd: handleDragEnd,
      children: [
        /* @__PURE__ */ jsxDEV("div", { className: "relative flex min-h-0 flex-1 flex-col", children: [
          lastMove && /* @__PURE__ */ jsxDEV("div", { className: "fixed bottom-6 right-6 z-50", children: /* @__PURE__ */ jsxDEV(Button, { onClick: handleUndo, className: "shadow-[var(--shadow-elevation-2)] gap-2", children: [
            /* @__PURE__ */ jsxDEV(Undo2, { className: "h-4 w-4" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
              lineNumber: 286,
              columnNumber: 15
            }, this),
            "Undo"
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
            lineNumber: 285,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
            lineNumber: 284,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-0 flex-1 items-stretch gap-3 overflow-x-auto p-4", children: COLUMNS.map(
            (col) => /* @__PURE__ */ jsxDEV(
              Column,
              {
                label: col.label,
                icon: col.icon,
                colorClass: col.color,
                status: col.status,
                tasks: byStatus(col.status),
                agentMap,
                allowedMap: allowedMap ?? {},
                onSelectTask,
                onMoveTo: handleMoveTo,
                onPlanTask: col.status === "INBOX" ? setPlanningTaskId : void 0
              },
              col.status,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                lineNumber: 294,
                columnNumber: 13
              },
              this
            )
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
            lineNumber: 292,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
          lineNumber: 281,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(DragOverlay, { children: activeTask ? /* @__PURE__ */ jsxDEV("div", { className: "min-w-[240px] rounded-xl border border-line-strong bg-surface-3 p-3 shadow-[var(--shadow-elevation-2)] opacity-95", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-[13.5px] text-ink mb-1 line-clamp-2", children: activeTask.title }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
            lineNumber: 315,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] text-ink-muted", children: [
            activeTask.type,
            " · P",
            activeTask.priority
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
            lineNumber: 318,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
          lineNumber: 314,
          columnNumber: 11
        }, this) : null }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
          lineNumber: 312,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          PlanningModal,
          {
            taskId: planningTaskId,
            onClose: () => setPlanningTaskId(null),
            onSuccess: () => setPlanningTaskId(null)
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
            lineNumber: 324,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
      lineNumber: 275,
      columnNumber: 5
    },
    this
  ) }, void 0, false, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
    lineNumber: 274,
    columnNumber: 5
  }, this);
}
_s(Kanban, "zCHOxFgxwiM7f8N0uU1wleY8Oto=", false, function() {
  return [useQuery, useQuery, useQuery, useMutation, useToast, useSensors, useSensor, useSensor];
});
_c = Kanban;
function Column({
  label,
  icon: Icon,
  colorClass,
  status,
  tasks,
  agentMap,
  allowedMap,
  onSelectTask,
  onMoveTo,
  onPlanTask
}) {
  _s2();
  const { setNodeRef, isOver } = useDroppable({ id: status });
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      ref: setNodeRef,
      className: cn(
        "flex h-full min-h-0 min-w-[264px] max-w-[264px] flex-col rounded-xl border bg-surface-1 transition-colors duration-150 overflow-hidden",
        isOver ? "border-line-strong bg-surface-2" : "border-line"
      ),
      children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 px-3 py-2 border-b border-line", children: [
          /* @__PURE__ */ jsxDEV(Icon, { size: 14, strokeWidth: 1.6, className: cn("shrink-0", colorClass) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
            lineNumber: 369,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[12.5px] font-medium text-ink-secondary", children: label }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
            lineNumber: 370,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", className: "ml-auto", children: tasks.length }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
            lineNumber: 371,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
          lineNumber: 368,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(ScrollArea, { className: "min-h-0 flex-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2 p-2", children: [
          tasks.map(
            (t) => /* @__PURE__ */ jsxDEV(
              Card,
              {
                task: t,
                agentMap,
                allowedToStatuses: allowedMap[t.status] ?? [],
                onSelect: () => onSelectTask(t._id),
                onMoveTo: (toStatus) => onMoveTo(t._id, t.status, toStatus),
                onPlanTask
              },
              t._id,
              false,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                lineNumber: 380,
                columnNumber: 11
              },
              this
            )
          ),
          tasks.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center py-8 text-ink-muted", children: /* @__PURE__ */ jsxDEV("span", { className: "text-[12.5px]", children: status === "BLOCKED" ? "No blocked tasks" : status === "DONE" ? "Nothing completed yet" : "Drop tasks here" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
            lineNumber: 392,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
            lineNumber: 391,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
          lineNumber: 378,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
          lineNumber: 377,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
      lineNumber: 360,
      columnNumber: 5
    },
    this
  );
}
_s2(Column, "DmJTTt6A5xWIX/faBiFge3FOLrw=", false, function() {
  return [useDroppable];
});
_c2 = Column;
function Card({
  task,
  agentMap,
  allowedToStatuses,
  onSelect,
  onMoveTo,
  onPlanTask
}) {
  _s3();
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: task._id,
    disabled: allowedToStatuses.length === 0
  });
  const assignees = task.assigneeIds.map((id) => agentMap.get(id)).filter(Boolean);
  const src = task.source ? SOURCE_CONFIG[task.source] || SOURCE_CONFIG.UNKNOWN : null;
  const workflowAttempt = task.metadata?.workflowAttempt;
  const style = transform ? {
    transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`
  } : void 0;
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      ref: setNodeRef,
      style,
      className: cn(
        "group relative rounded-xl border bg-surface-1 p-3 transition-colors duration-150",
        isDragging ? "opacity-50 border-line-strong" : "border-line hover:border-line-strong hover:bg-surface-2",
        "cursor-pointer"
      ),
      children: [
        allowedToStatuses.length > 0 ? /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            ...attributes,
            ...listeners,
            className: "absolute right-2 top-2 z-10 rounded p-1 text-ink-muted opacity-0 transition-opacity hover:bg-surface-3 hover:text-ink-secondary focus-visible:opacity-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring group-hover:opacity-100",
            "aria-label": `Drag ${task.title}`,
            children: /* @__PURE__ */ jsxDEV(GripVertical, { className: "h-3.5 w-3.5", "aria-hidden": true }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
              lineNumber: 457,
              columnNumber: 11
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
            lineNumber: 450,
            columnNumber: 7
          },
          this
        ) : null,
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            role: "button",
            tabIndex: 0,
            "aria-label": `Open task ${task.title}`,
            onClick: onSelect,
            onKeyDown: (e) => e.key === "Enter" && onSelect(),
            className: "outline-none focus-visible:ring-2 focus-visible:ring-ring",
            children: [
              task.identifier && /* @__PURE__ */ jsxDEV("div", { className: "text-[11.5px] font-mono text-ink-muted mb-1", children: task.identifier }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                lineNumber: 470,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mb-2 line-clamp-2 pr-5 text-[13.5px] font-medium leading-snug text-ink", children: task.title }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                lineNumber: 472,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1 mb-2", children: [
                /* @__PURE__ */ jsxDEV(StatusBadge, { tone: "neutral", children: task.type }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                  lineNumber: 478,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV(PriorityChip, { priority: task.priority }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                  lineNumber: 479,
                  columnNumber: 11
                }, this),
                src && /* @__PURE__ */ jsxDEV(StatusBadge, { tone: src.isSpecial ? "info" : "neutral", children: [
                  src.isSpecial && /* @__PURE__ */ jsxDEV(Sparkles, { size: 11, strokeWidth: 1.75, "aria-hidden": true }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                    lineNumber: 482,
                    columnNumber: 33
                  }, this),
                  src.label
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                  lineNumber: 481,
                  columnNumber: 11
                }, this),
                task.metadata?.workflowRunId && workflowAttempt?.attemptNumber ? /* @__PURE__ */ jsxDEV(StatusBadge, { tone: workflowAttempt.supersededAt ? "warning" : "info", children: [
                  "Attempt ",
                  workflowAttempt.attemptNumber,
                  workflowAttempt.retryNumber ? ` · Retry ${workflowAttempt.retryNumber}` : ""
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                  lineNumber: 487,
                  columnNumber: 11
                }, this) : null
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                lineNumber: 477,
                columnNumber: 9
              }, this),
              task.labels && task.labels.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1 mb-2", children: [
                task.labels.slice(0, 3).map(
                  (label) => /* @__PURE__ */ jsxDEV(
                    "span",
                    {
                      className: "text-[11.5px] px-1.5 py-0.5 bg-surface-2 text-ink-secondary rounded-md",
                      children: label
                    },
                    label,
                    false,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                      lineNumber: 498,
                      columnNumber: 11
                    },
                    this
                  )
                ),
                task.labels.length > 3 && /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] text-ink-muted", children: [
                  "+",
                  task.labels.length - 3
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                  lineNumber: 506,
                  columnNumber: 11
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                lineNumber: 496,
                columnNumber: 9
              }, this),
              task.blockedReason && /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] px-2 py-1.5 bg-err-soft text-err rounded-md mb-2 flex items-start gap-1.5", children: [
                /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "h-3 w-3 mt-0.5 shrink-0", strokeWidth: 1.75 }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                  lineNumber: 516,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "line-clamp-2", children: task.blockedReason }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                  lineNumber: 517,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                lineNumber: 515,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between text-[12.5px] text-ink-muted", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxDEV(DollarSign, { className: "h-3 w-3", strokeWidth: 1.75 }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                    lineNumber: 524,
                    columnNumber: 13
                  }, this),
                  task.actualCost.toFixed(2),
                  task.estimatedCost != null && /* @__PURE__ */ jsxDEV("span", { className: "text-ink-muted/60", children: [
                    " / $",
                    task.estimatedCost.toFixed(2)
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                    lineNumber: 527,
                    columnNumber: 13
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                  lineNumber: 523,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex -space-x-1.5", children: [
                  assignees.slice(0, 3).map(
                    (agent, i) => /* @__PURE__ */ jsxDEV(
                      "span",
                      {
                        title: agent.name,
                        className: "flex h-5 w-5 items-center justify-center rounded-full bg-surface-2 text-[11px] text-ink-secondary border border-line",
                        children: agent.emoji || agent.name.charAt(0)
                      },
                      i,
                      false,
                      {
                        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                        lineNumber: 532,
                        columnNumber: 13
                      },
                      this
                    )
                  ),
                  assignees.length > 3 && /* @__PURE__ */ jsxDEV("span", { className: "flex h-5 w-5 items-center justify-center rounded-full bg-surface-2 text-[11px] text-ink-secondary border border-line", children: [
                    "+",
                    assignees.length - 3
                  ] }, void 0, true, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                    lineNumber: 541,
                    columnNumber: 13
                  }, this)
                ] }, void 0, true, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                  lineNumber: 530,
                  columnNumber: 11
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                lineNumber: 522,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
            lineNumber: 460,
            columnNumber: 7
          },
          this
        ),
        (allowedToStatuses.length > 0 || onPlanTask) && /* @__PURE__ */ jsxDEV("div", { className: "mt-2 flex items-center gap-1 border-t border-line pt-2", children: [
          onPlanTask && /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "ghost",
              size: "sm",
              className: "h-6 text-[11px] px-2",
              onClick: (e) => {
                e.stopPropagation();
                onPlanTask(task._id);
              },
              children: [
                /* @__PURE__ */ jsxDEV(Sparkles, { className: "h-3 w-3 mr-1", strokeWidth: 1.75 }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                  lineNumber: 559,
                  columnNumber: 15
                }, this),
                "Plan with AI"
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
              lineNumber: 553,
              columnNumber: 9
            },
            this
          ),
          allowedToStatuses.length > 0 && /* @__PURE__ */ jsxDEV(DropdownMenu, { children: [
            /* @__PURE__ */ jsxDEV(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "sm", className: "h-6 text-[11px] px-2", children: [
              /* @__PURE__ */ jsxDEV(ArrowRight, { className: "h-3 w-3 mr-1", strokeWidth: 1.75 }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                lineNumber: 567,
                columnNumber: 19
              }, this),
              "Move"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
              lineNumber: 566,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
              lineNumber: 565,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(DropdownMenuContent, { align: "start", className: "w-44", children: allowedToStatuses.map(
              (s) => /* @__PURE__ */ jsxDEV(
                DropdownMenuItem,
                {
                  onClick: (e) => {
                    e.stopPropagation();
                    onMoveTo(s);
                  },
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: cn("h-1.5 w-1.5 rounded-full mr-2", COLUMN_DOT[s]) }, void 0, false, {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                      lineNumber: 577,
                      columnNumber: 21
                    }, this),
                    STATUS_LABELS[s]
                  ]
                },
                s,
                true,
                {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                  lineNumber: 573,
                  columnNumber: 13
                },
                this
              )
            ) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
              lineNumber: 571,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
            lineNumber: 564,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "ghost",
              size: "sm",
              className: "h-6 text-[11px] px-2 ml-auto",
              onClick: onSelect,
              children: [
                /* @__PURE__ */ jsxDEV(ExternalLink, { className: "h-3 w-3 mr-1" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
                  lineNumber: 590,
                  columnNumber: 13
                }, this),
                "Open"
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
              lineNumber: 584,
              columnNumber: 11
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
          lineNumber: 551,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx",
      lineNumber: 440,
      columnNumber: 5
    },
    this
  );
}
_s3(Card, "uZNJ3/8UzXAvFYh/tqZxqBQOH0I=", false, function() {
  return [useDraggable];
});
_c3 = Card;
var _c, _c2, _c3;
$RefreshReg$(_c, "Kanban");
$RefreshReg$(_c2, "Column");
$RefreshReg$(_c3, "Card");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/Kanban.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUtROzs7Ozs7Ozs7Ozs7Ozs7OztBQXJLUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLFdBQVc7QUFFcEIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFVBQVU7QUFDbkIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGtCQUFrQjtBQUMzQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BR0s7QUFDUDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBRUFDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BRUs7QUFDUCxTQUFTQyxxQkFBcUI7QUFJOUIsTUFBTUMsVUFBb0Y7QUFBQSxFQUN4RixFQUFFQyxRQUFRLFNBQVNDLE9BQU8sU0FBU0MsT0FBTyxrQkFBa0JDLE1BQU1wQixNQUFNO0FBQUEsRUFDeEUsRUFBRWlCLFFBQVEsWUFBWUMsT0FBTyxZQUFZQyxPQUFPLGtCQUFrQkMsTUFBTW5CLFVBQVU7QUFBQSxFQUNsRixFQUFFZ0IsUUFBUSxlQUFlQyxPQUFPLGVBQWVDLE9BQU8sa0JBQWtCQyxNQUFNbEIsS0FBSztBQUFBLEVBQ25GLEVBQUVlLFFBQVEsVUFBVUMsT0FBTyxVQUFVQyxPQUFPLGtCQUFrQkMsTUFBTWpCLElBQUk7QUFBQSxFQUN4RSxFQUFFYyxRQUFRLGtCQUFrQkMsT0FBTyxrQkFBa0JDLE9BQU8sa0JBQWtCQyxNQUFNaEIsWUFBWTtBQUFBLEVBQ2hHLEVBQUVhLFFBQVEsV0FBV0MsT0FBTyxXQUFXQyxPQUFPLGtCQUFrQkMsTUFBTWYsSUFBSTtBQUFBLEVBQzFFLEVBQUVZLFFBQVEsVUFBVUMsT0FBTyxVQUFVQyxPQUFPLGtCQUFrQkMsTUFBTWQsY0FBYztBQUFBLEVBQ2xGLEVBQUVXLFFBQVEsUUFBUUMsT0FBTyxRQUFRQyxPQUFPLGtCQUFrQkMsTUFBTWIsYUFBYTtBQUFBLEVBQzdFLEVBQUVVLFFBQVEsWUFBWUMsT0FBTyxZQUFZQyxPQUFPLGtCQUFrQkMsTUFBTVosUUFBUTtBQUFDO0FBSW5GLE1BQU1hLGFBQXFDO0FBQUEsRUFDekNDLE9BQU87QUFBQSxFQUNQQyxVQUFVO0FBQUEsRUFDVkMsYUFBYTtBQUFBLEVBQ2JDLFFBQVE7QUFBQSxFQUNSQyxnQkFBZ0I7QUFBQSxFQUNoQkMsU0FBUztBQUFBLEVBQ1RDLFFBQVE7QUFBQSxFQUNSQyxNQUFNO0FBQUEsRUFDTkMsVUFBVTtBQUNaO0FBMEJBLE1BQU1DLGdCQUF3RTtBQUFBLEVBQzVFQyxXQUFXLEVBQUVkLE9BQU8sWUFBWTtBQUFBLEVBQ2hDZSxVQUFXLEVBQUVmLE9BQU8sV0FBVztBQUFBLEVBQy9CZ0IsUUFBVyxFQUFFaEIsT0FBTyxTQUFTO0FBQUEsRUFDN0JpQixPQUFXLEVBQUVqQixPQUFPLFFBQVE7QUFBQSxFQUM1QmtCLEtBQVcsRUFBRWxCLE9BQU8sTUFBTTtBQUFBLEVBQzFCbUIsUUFBVyxFQUFFbkIsT0FBTyxTQUFTO0FBQUEsRUFDN0JvQixNQUFXLEVBQUVwQixPQUFPLE9BQU87QUFBQSxFQUMzQnFCLGdCQUFnQixFQUFFckIsT0FBTyxXQUFXc0IsV0FBVyxLQUFLO0FBQUEsRUFDcERDLFlBQVksRUFBRXZCLE9BQU8sZ0JBQWdCc0IsV0FBVyxLQUFLO0FBQUEsRUFDckRFLFNBQVcsRUFBRXhCLE9BQU8sVUFBVTtBQUNoQztBQUVBLE1BQU15QixnQkFBNEM7QUFBQSxFQUNoRHJCLE9BQU87QUFBQSxFQUNQQyxVQUFVO0FBQUEsRUFDVkMsYUFBYTtBQUFBLEVBQ2JDLFFBQVE7QUFBQSxFQUNSQyxnQkFBZ0I7QUFBQSxFQUNoQkMsU0FBUztBQUFBLEVBQ1RDLFFBQVE7QUFBQSxFQUNSQyxNQUFNO0FBQUEsRUFDTkMsVUFBVTtBQUNaO0FBRU8sZ0JBQVNjLE9BQU87QUFBQSxFQUNyQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFTRixHQUFHO0FBQUFDLEtBQUE7QUFDRCxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSXpFLFNBQXNCLElBQUk7QUFDOUQsUUFBTSxDQUFDMEUsZ0JBQWdCQyxpQkFBaUIsSUFBSTNFLFNBQTZCLElBQUk7QUFDN0UsUUFBTSxDQUFDNEUsVUFBVUMsV0FBVyxJQUFJN0UsU0FJdEIsSUFBSTtBQUVkLFFBQU04RSxRQUFRNUUsU0FBU0MsSUFBSTJFLE1BQU1DLFNBQVNYLFlBQVksRUFBRUEsVUFBVSxJQUFJLENBQUMsQ0FBQztBQUN4RSxRQUFNWSxTQUFTOUUsU0FBU0MsSUFBSTZFLE9BQU9ELFNBQVNYLFlBQVksRUFBRUEsVUFBVSxJQUFJLENBQUMsQ0FBQztBQUMxRSxRQUFNYSxhQUFhL0UsU0FBU0MsSUFBSTJFLE1BQU1JLDZCQUE2QjtBQUNuRSxRQUFNQyxpQkFBaUJsRixZQUFZRSxJQUFJMkUsTUFBTU0sVUFBVTtBQUN2RCxRQUFNLEVBQUVDLE1BQU0sSUFBSWpGLFNBQVM7QUFFM0IsUUFBTWtGLFVBQVVsRTtBQUFBQSxJQUNkRCxVQUFVRixlQUFlO0FBQUEsTUFDdkJzRSxzQkFBc0IsRUFBRUMsVUFBVSxFQUFFO0FBQUEsSUFDdEMsQ0FBQztBQUFBLElBQ0RyRSxVQUFVRCxhQUFhO0FBQUEsTUFDckJxRSxzQkFBc0IsRUFBRUUsT0FBTyxLQUFLQyxXQUFXLEVBQUU7QUFBQSxJQUNuRCxDQUFDO0FBQUEsRUFDSDtBQUVBLE1BQUlaLFVBQVVhLFVBQWFYLFdBQVdXLFFBQVc7QUFDL0MsV0FDRSx1QkFBQyxTQUFJLFdBQVUsMkJBQTBCLGNBQVcsaUJBQ2xEO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlEQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEQ7QUFBQSxNQUM1RCx1QkFBQyxTQUFJLFdBQVUsaURBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RDtBQUFBLE1BQzVELHVCQUFDLFNBQUksV0FBVSxpREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTREO0FBQUEsU0FIOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsRUFFSjtBQUVBLFFBQU1DLGdCQUFnQmQsTUFBTWUsT0FBTyxDQUFDQyxTQUFTO0FBQzNDLFFBQUksQ0FBQ3hCLFFBQVMsUUFBTztBQUNyQixRQUFJQSxRQUFRVSxPQUFPZSxTQUFTLEdBQUc7QUFDN0IsWUFBTUMsbUJBQW1CRixLQUFLRyxZQUFZQztBQUFBQSxRQUFLLENBQUNDLE9BQzlDN0IsUUFBUVUsT0FBT29CLFNBQVNELEVBQUU7QUFBQSxNQUM1QjtBQUNBLFVBQUksQ0FBQ0gsb0JBQW9CRixLQUFLRyxZQUFZRixTQUFTLEVBQUcsUUFBTztBQUFBLElBQy9EO0FBQ0EsUUFBSXpCLFFBQVErQixXQUFXTixTQUFTLEdBQUc7QUFDakMsVUFBSSxDQUFDekIsUUFBUStCLFdBQVdELFNBQVNOLEtBQUtRLFFBQVEsRUFBRyxRQUFPO0FBQUEsSUFDMUQ7QUFDQSxRQUFJaEMsUUFBUWlDLE1BQU1SLFNBQVMsR0FBRztBQUM1QixVQUFJLENBQUN6QixRQUFRaUMsTUFBTUgsU0FBU04sS0FBS1UsSUFBSSxFQUFHLFFBQU87QUFBQSxJQUNqRDtBQUNBLFdBQU87QUFBQSxFQUNULENBQUM7QUFFRCxRQUFNQyxXQUFXLElBQUlDO0FBQUFBLElBQ2xCMUIsT0FBMkIyQixJQUFJLENBQUNDLE1BQXFCLENBQUNBLEVBQUVDLEtBQUtELENBQUMsQ0FBQztBQUFBLEVBQ2xFO0FBQ0EsUUFBTUUsV0FBV0EsQ0FBQ3RFLFdBQ2hCb0QsY0FBY0MsT0FBTyxDQUFDa0IsTUFBb0JBLEVBQUV2RSxXQUFXQSxNQUFNO0FBRS9ELFFBQU13RSxlQUFlLE9BQU9DLFFBQXFCQyxZQUF3QkMsYUFBeUI7QUFDaEcsUUFBSTtBQUNGLFlBQU1DLFNBQVMsTUFBTWpDLGVBQWU7QUFBQSxRQUNsQzhCO0FBQUFBLFFBQ0FFO0FBQUFBLFFBQ0FFLFdBQVc7QUFBQSxRQUNYQyxhQUFhO0FBQUEsUUFDYkMsZ0JBQWdCLE1BQU1OLE1BQU0sSUFBSUUsUUFBUSxJQUFJSyxLQUFLQyxJQUFJLENBQUM7QUFBQSxNQUN4RCxDQUFDO0FBQ0QsVUFBSUwsVUFBVSxPQUFPQSxXQUFXLFlBQVksYUFBYUEsVUFBVSxDQUFDQSxPQUFPTSxTQUFTO0FBQ2xGLGNBQU1DLE1BQU9QLE9BQThDUSxTQUFTLENBQUMsR0FBR0MsV0FBVztBQUNuRnhDLGNBQU1zQyxLQUFLLElBQUk7QUFBQSxNQUNqQixPQUFPO0FBQ0w5QyxvQkFBWSxFQUFFb0MsUUFBUUMsWUFBWUMsU0FBUyxDQUFDO0FBQzVDOUIsY0FBTSxZQUFZbkIsY0FBY2lELFFBQVEsQ0FBQyxFQUFFO0FBQUEsTUFDN0M7QUFBQSxJQUNGLFNBQVNXLEdBQUc7QUFDVnpDLFlBQU15QyxhQUFhQyxRQUFRRCxFQUFFRCxVQUFVLHFCQUFxQixJQUFJO0FBQUEsSUFDbEU7QUFBQSxFQUNGO0FBRUEsUUFBTUcsYUFBYSxZQUFZO0FBQzdCLFFBQUksQ0FBQ3BELFNBQVU7QUFDZixRQUFJO0FBQ0YsWUFBTU8sZUFBZTtBQUFBLFFBQ25COEIsUUFBUXJDLFNBQVNxQztBQUFBQSxRQUNqQkUsVUFBVXZDLFNBQVNzQztBQUFBQSxRQUNuQkcsV0FBVztBQUFBLFFBQ1hDLGFBQWE7QUFBQSxRQUNiQyxnQkFBZ0IsUUFBUTNDLFNBQVNxQyxNQUFNLElBQUlPLEtBQUtDLElBQUksQ0FBQztBQUFBLE1BQ3ZELENBQUM7QUFDRHBDLFlBQU0sUUFBUTtBQUNkUixrQkFBWSxJQUFJO0FBQUEsSUFDbEIsU0FBU2lELEdBQUc7QUFDVnpDLFlBQU15QyxhQUFhQyxRQUFRRCxFQUFFRCxVQUFVLGVBQWUsSUFBSTtBQUFBLElBQzVEO0FBQUEsRUFDRjtBQUVBLFFBQU1JLGtCQUFrQkEsQ0FBQ0MsVUFBMEI7QUFDakQsVUFBTXBDLE9BQU9GLGNBQWN1QyxLQUFLLENBQUNwQixNQUFNQSxFQUFFRixRQUFRcUIsTUFBTUUsT0FBT2pDLEVBQUU7QUFDaEUsUUFBSUwsS0FBTXJCLGVBQWNxQixJQUFZO0FBQUEsRUFDdEM7QUFFQSxRQUFNdUMsZ0JBQWdCQSxDQUFDSCxVQUF3QjtBQUM3Q3pELGtCQUFjLElBQUk7QUFDbEIsVUFBTSxFQUFFMkQsUUFBUUUsS0FBSyxJQUFJSjtBQUN6QixRQUFJLENBQUNJLFFBQVFGLE9BQU9qQyxPQUFPbUMsS0FBS25DLEdBQUk7QUFDcEMsVUFBTUwsT0FBT0YsY0FBY3VDLEtBQUssQ0FBQ3BCLE1BQU1BLEVBQUVGLFFBQVF1QixPQUFPakMsRUFBRTtBQUMxRCxVQUFNZ0IsV0FBV21CLEtBQUtuQztBQUN0QixRQUFJLENBQUNMLEtBQU07QUFDWCxVQUFNeUMsVUFBVXRELGFBQWFhLEtBQUt0RCxNQUFNLEtBQUs7QUFDN0MsUUFBSSxDQUFDK0YsUUFBUW5DLFNBQVNlLFFBQVEsR0FBRztBQUMvQjlCLFlBQU0sMEJBQTBCLElBQUk7QUFDcEM7QUFBQSxJQUNGO0FBQ0EyQixpQkFBYWxCLEtBQUtlLEtBQUtmLEtBQUt0RCxRQUFRMkUsUUFBUTtBQUFBLEVBQzlDO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ2Y7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQSxvQkFBb0JuRztBQUFBQSxNQUNwQixhQUFhaUg7QUFBQUEsTUFDYixXQUFXSTtBQUFBQSxNQUVYO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHlDQUVaekQ7QUFBQUEsc0JBQ0MsdUJBQUMsU0FBSSxXQUFVLCtCQUNiLGlDQUFDLFVBQU8sU0FBU29ELFlBQVksV0FBVSw0Q0FDckM7QUFBQSxtQ0FBQyxTQUFNLFdBQVUsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEI7QUFBQTtBQUFBLGVBRDVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFHRix1QkFBQyxTQUFJLFdBQVUsK0RBQ1p6RixrQkFBUW9FO0FBQUFBLFlBQUksQ0FBQzZCLFFBQ1o7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxPQUFPQSxJQUFJL0Y7QUFBQUEsZ0JBQ1gsTUFBTStGLElBQUk3RjtBQUFBQSxnQkFDVixZQUFZNkYsSUFBSTlGO0FBQUFBLGdCQUNoQixRQUFROEYsSUFBSWhHO0FBQUFBLGdCQUNaLE9BQU9zRSxTQUFTMEIsSUFBSWhHLE1BQU07QUFBQSxnQkFDMUI7QUFBQSxnQkFDQSxZQUFZeUMsY0FBYyxDQUFDO0FBQUEsZ0JBQzNCO0FBQUEsZ0JBQ0EsVUFBVStCO0FBQUFBLGdCQUNWLFlBQVl3QixJQUFJaEcsV0FBVyxVQUFVbUMsb0JBQW9CZ0I7QUFBQUE7QUFBQUEsY0FWcEQ2QyxJQUFJaEc7QUFBQUEsY0FEWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV3FFO0FBQUEsVUFFdEUsS0FmSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLGFBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0QkE7QUFBQSxRQUdBLHVCQUFDLGVBQ0VnQyx1QkFDQyx1QkFBQyxTQUFJLFdBQVUscUhBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsd0RBQ1pBLHFCQUFXaUUsU0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ1pqRTtBQUFBQSx1QkFBV2dDO0FBQUFBLFlBQUs7QUFBQSxZQUFLaEMsV0FBVzhCO0FBQUFBLGVBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQSxJQUNFLFFBVk47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsUUFBUTVCO0FBQUFBLFlBQ1IsU0FBUyxNQUFNQyxrQkFBa0IsSUFBSTtBQUFBLFlBQ3JDLFdBQVcsTUFBTUEsa0JBQWtCLElBQUk7QUFBQTtBQUFBLFVBSHpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUcyQztBQUFBO0FBQUE7QUFBQSxJQXBEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBc0RBLEtBdkRBO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3REE7QUFFSjtBQUFDSixHQTFMZUosUUFBTTtBQUFBLFVBcUJOakUsVUFDQ0EsVUFDSUEsVUFDSUQsYUFDTEcsVUFFRmdCLFlBQ2RELFdBR0FBLFNBQVM7QUFBQTtBQUFBLEtBL0JHZ0Q7QUE0TGhCLFNBQVN1RSxPQUFPO0FBQUEsRUFDZGpHO0FBQUFBLEVBQ0FFLE1BQU1nRztBQUFBQSxFQUNOQztBQUFBQSxFQUNBcEc7QUFBQUEsRUFDQXNDO0FBQUFBLEVBQ0EyQjtBQUFBQSxFQUNBeEI7QUFBQUEsRUFDQVo7QUFBQUEsRUFDQXdFO0FBQUFBLEVBQ0FDO0FBWUYsR0FBRztBQUFBQyxNQUFBO0FBQ0QsUUFBTSxFQUFFQyxZQUFZQyxPQUFPLElBQUk1SCxhQUFhLEVBQUU4RSxJQUFJM0QsT0FBTyxDQUFDO0FBRTFELFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLEtBQUt3RztBQUFBQSxNQUNMLFdBQVczSTtBQUFBQSxRQUNUO0FBQUEsUUFDQTRJLFNBQVMsb0NBQW9DO0FBQUEsTUFDL0M7QUFBQSxNQUdBO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBEQUNiO0FBQUEsaUNBQUMsUUFBSyxNQUFNLElBQUksYUFBYSxLQUFLLFdBQVc1SSxHQUFHLFlBQVl1SSxVQUFVLEtBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdFO0FBQUEsVUFDeEUsdUJBQUMsVUFBSyxXQUFVLGdEQUFnRG5HLG1CQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRTtBQUFBLFVBQ3RFLHVCQUFDLGVBQVksTUFBSyxXQUFVLFdBQVUsV0FDbkNxQyxnQkFBTWlCLFVBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFHQSx1QkFBQyxjQUFXLFdBQVUsa0JBQ3BCLGlDQUFDLFNBQUksV0FBVSwyQkFDWmpCO0FBQUFBLGdCQUFNNkI7QUFBQUEsWUFBSSxDQUFDSSxNQUNWO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsTUFBTUE7QUFBQUEsZ0JBQ047QUFBQSxnQkFDQSxtQkFBb0I5QixXQUFXOEIsRUFBRXZFLE1BQU0sS0FBa0M7QUFBQSxnQkFDekUsVUFBVSxNQUFNNkIsYUFBYTBDLEVBQUVGLEdBQUc7QUFBQSxnQkFDbEMsVUFBVSxDQUFDTSxhQUFhMEIsU0FBUzlCLEVBQUVGLEtBQUtFLEVBQUV2RSxRQUFRMkUsUUFBUTtBQUFBLGdCQUMxRDtBQUFBO0FBQUEsY0FOS0osRUFBRUY7QUFBQUEsY0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT3lCO0FBQUEsVUFFMUI7QUFBQSxVQUNBL0IsTUFBTWlCLFdBQVcsS0FDaEIsdUJBQUMsU0FBSSxXQUFVLGlFQUNiLGlDQUFDLFVBQUssV0FBVSxpQkFDYnZELHFCQUFXLFlBQ1IscUJBQ0FBLFdBQVcsU0FDVCwwQkFDQSxxQkFMUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLGFBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1QkEsS0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlCQTtBQUFBO0FBQUE7QUFBQSxJQTFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUEyQ0E7QUFFSjtBQUFDdUcsSUF2RVFMLFFBQU07QUFBQSxVQXVCa0JySCxZQUFZO0FBQUE7QUFBQSxNQXZCcENxSDtBQTBFVCxTQUFTUSxLQUFLO0FBQUEsRUFDWnBEO0FBQUFBLEVBQ0FXO0FBQUFBLEVBQ0EwQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBUDtBQUFBQSxFQUNBQztBQVFGLEdBQUc7QUFBQU8sTUFBQTtBQUNELFFBQU0sRUFBRUMsWUFBWUMsV0FBV1AsWUFBWVEsV0FBV0MsV0FBVyxJQUFJbkksYUFBYTtBQUFBLElBQ2hGNkUsSUFBSUwsS0FBS2U7QUFBQUEsSUFDVDZDLFVBQVVQLGtCQUFrQnBELFdBQVc7QUFBQSxFQUN6QyxDQUFDO0FBRUQsUUFBTTRELFlBQVk3RCxLQUFLRyxZQUNwQlUsSUFBSSxDQUFDUixPQUFPTSxTQUFTbUQsSUFBSXpELEVBQUUsQ0FBQyxFQUM1Qk4sT0FBT2dFLE9BQU87QUFFakIsUUFBTUMsTUFBTWhFLEtBQUtpRSxTQUFVekcsY0FBY3dDLEtBQUtpRSxNQUFNLEtBQUt6RyxjQUFjVyxVQUFXO0FBQ2xGLFFBQU0rRixrQkFBa0JsRSxLQUFLbUUsVUFBVUQ7QUFFdkMsUUFBTUUsUUFBUVYsWUFBWTtBQUFBLElBQ3hCQSxXQUFXLGVBQWVBLFVBQVVXLENBQUMsT0FBT1gsVUFBVVksQ0FBQztBQUFBLEVBQ3pELElBQUl6RTtBQUVKLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLEtBQUtxRDtBQUFBQSxNQUNMO0FBQUEsTUFDQSxXQUFXM0k7QUFBQUEsUUFDVDtBQUFBLFFBQ0FvSixhQUFhLGtDQUFrQztBQUFBLFFBQy9DO0FBQUEsTUFDRjtBQUFBLE1BRUNOO0FBQUFBLDBCQUFrQnBELFNBQVMsSUFDMUI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLEdBQUl1RDtBQUFBQSxZQUNKLEdBQUlDO0FBQUFBLFlBQ0osV0FBVTtBQUFBLFlBQ1YsY0FBWSxRQUFRekQsS0FBSzJDLEtBQUs7QUFBQSxZQUU5QixpQ0FBQyxnQkFBYSxXQUFVLGVBQWMsZUFBVyxRQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRDtBQUFBO0FBQUEsVUFQbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUEsSUFDRTtBQUFBLFFBQ0o7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFVBQVU7QUFBQSxZQUNWLGNBQVksYUFBYTNDLEtBQUsyQyxLQUFLO0FBQUEsWUFDbkMsU0FBU1c7QUFBQUEsWUFDVCxXQUFXLENBQUN0QixNQUFNQSxFQUFFdUMsUUFBUSxXQUFXakIsU0FBUztBQUFBLFlBQ2hELFdBQVU7QUFBQSxZQUdUdEQ7QUFBQUEsbUJBQUt3RSxjQUNKLHVCQUFDLFNBQUksV0FBVSwrQ0FBK0N4RSxlQUFLd0UsY0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEU7QUFBQSxjQUVoRix1QkFBQyxTQUFJLFdBQVUsMEVBQ1p4RSxlQUFLMkMsU0FEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSx1Q0FBQyxlQUFZLE1BQUssV0FBVzNDLGVBQUtVLFFBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVDO0FBQUEsZ0JBQ3ZDLHVCQUFDLGdCQUFhLFVBQVVWLEtBQUtRLFlBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNDO0FBQUEsZ0JBQ3JDd0QsT0FDQyx1QkFBQyxlQUFZLE1BQU1BLElBQUkvRixZQUFZLFNBQVMsV0FDekMrRjtBQUFBQSxzQkFBSS9GLGFBQWEsdUJBQUMsWUFBUyxNQUFNLElBQUksYUFBYSxNQUFNLGVBQVcsUUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0Q7QUFBQSxrQkFDbkUrRixJQUFJckg7QUFBQUEscUJBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUVEcUQsS0FBS21FLFVBQVVNLGlCQUFpQlAsaUJBQWlCUSxnQkFDaEQsdUJBQUMsZUFBWSxNQUFNUixnQkFBZ0JTLGVBQWUsWUFBWSxRQUFPO0FBQUE7QUFBQSxrQkFDMURULGdCQUFnQlE7QUFBQUEsa0JBQ3hCUixnQkFBZ0JVLGNBQWMsWUFBWVYsZ0JBQWdCVSxXQUFXLEtBQUs7QUFBQSxxQkFGN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQSxJQUNFO0FBQUEsbUJBZE47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGNBR0M1RSxLQUFLNkUsVUFBVTdFLEtBQUs2RSxPQUFPNUUsU0FBUyxLQUNuQyx1QkFBQyxTQUFJLFdBQVUsNkJBQ1pEO0FBQUFBLHFCQUFLNkUsT0FBT0MsTUFBTSxHQUFHLENBQUMsRUFBRWpFO0FBQUFBLGtCQUFJLENBQUNsRSxVQUM1QjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFFQyxXQUFVO0FBQUEsc0JBRVRBO0FBQUFBO0FBQUFBLG9CQUhJQTtBQUFBQSxvQkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsZ0JBQ0Q7QUFBQSxnQkFDQXFELEtBQUs2RSxPQUFPNUUsU0FBUyxLQUNwQix1QkFBQyxVQUFLLFdBQVUsZ0NBQThCO0FBQUE7QUFBQSxrQkFDMUNELEtBQUs2RSxPQUFPNUUsU0FBUztBQUFBLHFCQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFjQTtBQUFBLGNBSURELEtBQUsrRSxpQkFDSix1QkFBQyxTQUFJLFdBQVUsMkZBQ2I7QUFBQSx1Q0FBQyxpQkFBYyxXQUFVLDJCQUEwQixhQUFhLFFBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFFO0FBQUEsZ0JBQ3JFLHVCQUFDLFVBQUssV0FBVSxnQkFBZ0IvRSxlQUFLK0UsaUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1EO0FBQUEsbUJBRnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUlGLHVCQUFDLFNBQUksV0FBVSxrRUFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSwyQkFDZDtBQUFBLHlDQUFDLGNBQVcsV0FBVSxXQUFVLGFBQWEsUUFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0Q7QUFBQSxrQkFDakQvRSxLQUFLZ0YsV0FBV0MsUUFBUSxDQUFDO0FBQUEsa0JBQ3pCakYsS0FBS2tGLGlCQUFpQixRQUNyQix1QkFBQyxVQUFLLFdBQVUscUJBQW9CO0FBQUE7QUFBQSxvQkFBS2xGLEtBQUtrRixjQUFjRCxRQUFRLENBQUM7QUFBQSx1QkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUU7QUFBQSxxQkFKM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDWnBCO0FBQUFBLDRCQUFVaUIsTUFBTSxHQUFHLENBQUMsRUFBRWpFO0FBQUFBLG9CQUFJLENBQUNzRSxPQUFPQyxNQUNqQztBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFFQyxPQUFPRCxNQUFPRTtBQUFBQSx3QkFDZCxXQUFVO0FBQUEsd0JBRVRGLGdCQUFPRyxTQUFTSCxNQUFPRSxLQUFLRSxPQUFPLENBQUM7QUFBQTtBQUFBLHNCQUpoQ0g7QUFBQUEsc0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNQTtBQUFBLGtCQUNEO0FBQUEsa0JBQ0F2QixVQUFVNUQsU0FBUyxLQUNsQix1QkFBQyxVQUFLLFdBQVUsd0hBQXNIO0FBQUE7QUFBQSxvQkFDbEk0RCxVQUFVNUQsU0FBUztBQUFBLHVCQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFlQTtBQUFBLG1CQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXdCQTtBQUFBO0FBQUE7QUFBQSxVQXRGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUF1RkE7QUFBQSxTQUdFb0Qsa0JBQWtCcEQsU0FBUyxLQUFLK0MsZUFDaEMsdUJBQUMsU0FBSSxXQUFVLDBEQUNaQTtBQUFBQSx3QkFDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUTtBQUFBLGNBQ1IsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsU0FBUyxDQUFDaEIsTUFBTTtBQUFFQSxrQkFBRXdELGdCQUFnQjtBQUFHeEMsMkJBQVdoRCxLQUFLZSxHQUFHO0FBQUEsY0FBRztBQUFBLGNBRTdEO0FBQUEsdUNBQUMsWUFBUyxXQUFVLGdCQUFlLGFBQWEsUUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU52RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLFVBRURzQyxrQkFBa0JwRCxTQUFTLEtBQzFCLHVCQUFDLGdCQUNDO0FBQUEsbUNBQUMsdUJBQW9CLFNBQU8sTUFDMUIsaUNBQUMsVUFBTyxTQUFRLFNBQVEsTUFBSyxNQUFLLFdBQVUsd0JBQzFDO0FBQUEscUNBQUMsY0FBVyxXQUFVLGdCQUFlLGFBQWEsUUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUQ7QUFBQTtBQUFBLGlCQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsdUJBQW9CLE9BQU0sU0FBUSxXQUFVLFFBQzFDb0QsNEJBQWtCeEM7QUFBQUEsY0FBSSxDQUFDNEUsTUFDdEI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUMsU0FBUyxDQUFDekQsTUFBTTtBQUFFQSxzQkFBRXdELGdCQUFnQjtBQUFHekMsNkJBQVMwQyxDQUFDO0FBQUEsa0JBQUc7QUFBQSxrQkFFcEQ7QUFBQSwyQ0FBQyxVQUFLLFdBQVdsTCxHQUFHLGlDQUFpQ3VDLFdBQVcySSxDQUFDLENBQUMsS0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0U7QUFBQSxvQkFDbkVySCxjQUFjcUgsQ0FBQztBQUFBO0FBQUE7QUFBQSxnQkFKWEE7QUFBQUEsZ0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsWUFDRCxLQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxlQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLFVBRUY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVE7QUFBQSxjQUNSLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLFNBQVNuQztBQUFBQSxjQUVUO0FBQUEsdUNBQUMsZ0JBQWEsV0FBVSxrQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU54QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLGFBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQ0E7QUFBQTtBQUFBO0FBQUEsSUF6Sko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBMkpBO0FBRUo7QUFBQ0MsSUE3TFFILE1BQUk7QUFBQSxVQWUwRDVILFlBQVk7QUFBQTtBQUFBLE1BZjFFNEg7QUFBSSxJQUFBc0MsSUFBQUMsS0FBQUM7QUFBQSxhQUFBRixJQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJhcGkiLCJ1c2VUb2FzdCIsImNuIiwiU3RhdHVzQmFkZ2UiLCJQcmlvcml0eUNoaXAiLCJCdXR0b24iLCJTY3JvbGxBcmVhIiwiRHJvcGRvd25NZW51IiwiRHJvcGRvd25NZW51Q29udGVudCIsIkRyb3Bkb3duTWVudUl0ZW0iLCJEcm9wZG93bk1lbnVUcmlnZ2VyIiwiRG5kQ29udGV4dCIsIkRyYWdPdmVybGF5IiwiY2xvc2VzdENvcm5lcnMiLCJQb2ludGVyU2Vuc29yIiwiVG91Y2hTZW5zb3IiLCJ1c2VTZW5zb3IiLCJ1c2VTZW5zb3JzIiwidXNlRHJvcHBhYmxlIiwidXNlRHJhZ2dhYmxlIiwiSW5ib3giLCJVc2VyQ2hlY2siLCJQbGF5IiwiRXllIiwiU2hpZWxkQWxlcnQiLCJCYW4iLCJBbGVydFRyaWFuZ2xlIiwiQ2hlY2tDaXJjbGUyIiwiWENpcmNsZSIsIkFycm93UmlnaHQiLCJVbmRvMiIsIkRvbGxhclNpZ24iLCJHcmlwVmVydGljYWwiLCJFeHRlcm5hbExpbmsiLCJTcGFya2xlcyIsIlBsYW5uaW5nTW9kYWwiLCJDT0xVTU5TIiwic3RhdHVzIiwibGFiZWwiLCJjb2xvciIsImljb24iLCJDT0xVTU5fRE9UIiwiSU5CT1giLCJBU1NJR05FRCIsIklOX1BST0dSRVNTIiwiUkVWSUVXIiwiTkVFRFNfQVBQUk9WQUwiLCJCTE9DS0VEIiwiRkFJTEVEIiwiRE9ORSIsIkNBTkNFTEVEIiwiU09VUkNFX0NPTkZJRyIsIkRBU0hCT0FSRCIsIlRFTEVHUkFNIiwiR0lUSFVCIiwiQUdFTlQiLCJBUEkiLCJUUkVMTE8iLCJTRUVEIiwiTUlTU0lPTl9QUk9NUFQiLCJpc1NwZWNpYWwiLCJQUkRfSU1QT1JUIiwiVU5LTk9XTiIsIlNUQVRVU19MQUJFTFMiLCJLYW5iYW4iLCJwcm9qZWN0SWQiLCJvblNlbGVjdFRhc2siLCJmaWx0ZXJzIiwiX3MiLCJhY3RpdmVUYXNrIiwic2V0QWN0aXZlVGFzayIsInBsYW5uaW5nVGFza0lkIiwic2V0UGxhbm5pbmdUYXNrSWQiLCJsYXN0TW92ZSIsInNldExhc3RNb3ZlIiwidGFza3MiLCJsaXN0QWxsIiwiYWdlbnRzIiwiYWxsb3dlZE1hcCIsImdldEFsbG93ZWRUcmFuc2l0aW9uc0Zvckh1bWFuIiwidHJhbnNpdGlvblRhc2siLCJ0cmFuc2l0aW9uIiwidG9hc3QiLCJzZW5zb3JzIiwiYWN0aXZhdGlvbkNvbnN0cmFpbnQiLCJkaXN0YW5jZSIsImRlbGF5IiwidG9sZXJhbmNlIiwidW5kZWZpbmVkIiwiZmlsdGVyZWRUYXNrcyIsImZpbHRlciIsInRhc2siLCJsZW5ndGgiLCJoYXNNYXRjaGluZ0FnZW50IiwiYXNzaWduZWVJZHMiLCJzb21lIiwiaWQiLCJpbmNsdWRlcyIsInByaW9yaXRpZXMiLCJwcmlvcml0eSIsInR5cGVzIiwidHlwZSIsImFnZW50TWFwIiwiTWFwIiwibWFwIiwiYSIsIl9pZCIsImJ5U3RhdHVzIiwidCIsImhhbmRsZU1vdmVUbyIsInRhc2tJZCIsImZyb21TdGF0dXMiLCJ0b1N0YXR1cyIsInJlc3VsdCIsImFjdG9yVHlwZSIsImFjdG9yVXNlcklkIiwiaWRlbXBvdGVuY3lLZXkiLCJEYXRlIiwibm93Iiwic3VjY2VzcyIsImVyciIsImVycm9ycyIsIm1lc3NhZ2UiLCJlIiwiRXJyb3IiLCJoYW5kbGVVbmRvIiwiaGFuZGxlRHJhZ1N0YXJ0IiwiZXZlbnQiLCJmaW5kIiwiYWN0aXZlIiwiaGFuZGxlRHJhZ0VuZCIsIm92ZXIiLCJhbGxvd2VkIiwiY29sIiwidGl0bGUiLCJDb2x1bW4iLCJJY29uIiwiY29sb3JDbGFzcyIsIm9uTW92ZVRvIiwib25QbGFuVGFzayIsIl9zMiIsInNldE5vZGVSZWYiLCJpc092ZXIiLCJDYXJkIiwiYWxsb3dlZFRvU3RhdHVzZXMiLCJvblNlbGVjdCIsIl9zMyIsImF0dHJpYnV0ZXMiLCJsaXN0ZW5lcnMiLCJ0cmFuc2Zvcm0iLCJpc0RyYWdnaW5nIiwiZGlzYWJsZWQiLCJhc3NpZ25lZXMiLCJnZXQiLCJCb29sZWFuIiwic3JjIiwic291cmNlIiwid29ya2Zsb3dBdHRlbXB0IiwibWV0YWRhdGEiLCJzdHlsZSIsIngiLCJ5Iiwia2V5IiwiaWRlbnRpZmllciIsIndvcmtmbG93UnVuSWQiLCJhdHRlbXB0TnVtYmVyIiwic3VwZXJzZWRlZEF0IiwicmV0cnlOdW1iZXIiLCJsYWJlbHMiLCJzbGljZSIsImJsb2NrZWRSZWFzb24iLCJhY3R1YWxDb3N0IiwidG9GaXhlZCIsImVzdGltYXRlZENvc3QiLCJhZ2VudCIsImkiLCJuYW1lIiwiZW1vamkiLCJjaGFyQXQiLCJzdG9wUHJvcGFnYXRpb24iLCJzIiwiX2MiLCJfYzIiLCJfYzMiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiS2FuYmFuLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5IH0gZnJvbSBcImNvbnZleC9yZWFjdFwiO1xuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2FwaVwiO1xuaW1wb3J0IHR5cGUgeyBJZCwgRG9jIH0gZnJvbSBcIi4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuaW1wb3J0IHsgdXNlVG9hc3QgfSBmcm9tIFwiLi9Ub2FzdFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcbmltcG9ydCB7IFN0YXR1c0JhZGdlIH0gZnJvbSBcIkAvY29tcG9uZW50cy9mYWN0b3J5L2JhZGdlc1wiO1xuaW1wb3J0IHsgUHJpb3JpdHlDaGlwIH0gZnJvbSBcIkAvY29tcG9uZW50cy9Qcmlvcml0eUNoaXBcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQgeyBTY3JvbGxBcmVhIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9zY3JvbGwtYXJlYVwiO1xuaW1wb3J0IHtcbiAgRHJvcGRvd25NZW51LFxuICBEcm9wZG93bk1lbnVDb250ZW50LFxuICBEcm9wZG93bk1lbnVJdGVtLFxuICBEcm9wZG93bk1lbnVUcmlnZ2VyLFxufSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2Ryb3Bkb3duLW1lbnVcIjtcbmltcG9ydCB7XG4gIERuZENvbnRleHQsXG4gIERyYWdPdmVybGF5LFxuICBjbG9zZXN0Q29ybmVycyxcbiAgUG9pbnRlclNlbnNvcixcbiAgVG91Y2hTZW5zb3IsXG4gIHVzZVNlbnNvcixcbiAgdXNlU2Vuc29ycyxcbiAgdXNlRHJvcHBhYmxlLFxuICB1c2VEcmFnZ2FibGUsXG4gIHR5cGUgRHJhZ0VuZEV2ZW50LFxuICB0eXBlIERyYWdTdGFydEV2ZW50LFxufSBmcm9tIFwiQGRuZC1raXQvY29yZVwiO1xuaW1wb3J0IHtcbiAgSW5ib3gsXG4gIFVzZXJDaGVjayxcbiAgUGxheSxcbiAgRXllLFxuICBTaGllbGRBbGVydCxcbiAgQmFuLFxuICBBbGVydFRyaWFuZ2xlLFxuICBDaGVja0NpcmNsZTIsXG4gIFhDaXJjbGUsXG4gIEFycm93UmlnaHQsXG4gIFVuZG8yLFxuICBEb2xsYXJTaWduLFxuICBHcmlwVmVydGljYWwsXG4gIE1vcmVIb3Jpem9udGFsLFxuICBFeHRlcm5hbExpbmssXG4gIFNwYXJrbGVzLFxuICB0eXBlIEx1Y2lkZUljb24sXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IFBsYW5uaW5nTW9kYWwgfSBmcm9tIFwiLi9QbGFubmluZ01vZGFsXCI7XG5cbnR5cGUgVGFza1N0YXR1cyA9IERvYzxcInRhc2tzXCI+W1wic3RhdHVzXCJdO1xuXG5jb25zdCBDT0xVTU5TOiB7IHN0YXR1czogVGFza1N0YXR1czsgbGFiZWw6IHN0cmluZzsgY29sb3I6IHN0cmluZzsgaWNvbjogTHVjaWRlSWNvbiB9W10gPSBbXG4gIHsgc3RhdHVzOiBcIklOQk9YXCIsIGxhYmVsOiBcIkluYm94XCIsIGNvbG9yOiBcInRleHQtaW5rLW11dGVkXCIsIGljb246IEluYm94IH0sXG4gIHsgc3RhdHVzOiBcIkFTU0lHTkVEXCIsIGxhYmVsOiBcIkFzc2lnbmVkXCIsIGNvbG9yOiBcInRleHQtaW5rLW11dGVkXCIsIGljb246IFVzZXJDaGVjayB9LFxuICB7IHN0YXR1czogXCJJTl9QUk9HUkVTU1wiLCBsYWJlbDogXCJJbiBQcm9ncmVzc1wiLCBjb2xvcjogXCJ0ZXh0LWluay1tdXRlZFwiLCBpY29uOiBQbGF5IH0sXG4gIHsgc3RhdHVzOiBcIlJFVklFV1wiLCBsYWJlbDogXCJSZXZpZXdcIiwgY29sb3I6IFwidGV4dC1pbmstbXV0ZWRcIiwgaWNvbjogRXllIH0sXG4gIHsgc3RhdHVzOiBcIk5FRURTX0FQUFJPVkFMXCIsIGxhYmVsOiBcIk5lZWRzIEFwcHJvdmFsXCIsIGNvbG9yOiBcInRleHQtaW5rLW11dGVkXCIsIGljb246IFNoaWVsZEFsZXJ0IH0sXG4gIHsgc3RhdHVzOiBcIkJMT0NLRURcIiwgbGFiZWw6IFwiQmxvY2tlZFwiLCBjb2xvcjogXCJ0ZXh0LWluay1tdXRlZFwiLCBpY29uOiBCYW4gfSxcbiAgeyBzdGF0dXM6IFwiRkFJTEVEXCIsIGxhYmVsOiBcIkZhaWxlZFwiLCBjb2xvcjogXCJ0ZXh0LWluay1tdXRlZFwiLCBpY29uOiBBbGVydFRyaWFuZ2xlIH0sXG4gIHsgc3RhdHVzOiBcIkRPTkVcIiwgbGFiZWw6IFwiRG9uZVwiLCBjb2xvcjogXCJ0ZXh0LWluay1tdXRlZFwiLCBpY29uOiBDaGVja0NpcmNsZTIgfSxcbiAgeyBzdGF0dXM6IFwiQ0FOQ0VMRURcIiwgbGFiZWw6IFwiQ2FuY2VsZWRcIiwgY29sb3I6IFwidGV4dC1pbmstbXV0ZWRcIiwgaWNvbjogWENpcmNsZSB9LFxuXTtcblxuLyoqIEZsYXQgc3RhdHVzLWRvdCBjb2xvcnMgcGVyIFVJX1NUWUxFX0dVSURFIHRhc2stc3RhdGUgbWFwcGluZy4gKi9cbmNvbnN0IENPTFVNTl9ET1Q6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gIElOQk9YOiBcImJnLWluay1tdXRlZFwiLFxuICBBU1NJR05FRDogXCJiZy1pbmstbXV0ZWRcIixcbiAgSU5fUFJPR1JFU1M6IFwiYmctaW5mby1hY2NlbnRcIixcbiAgUkVWSUVXOiBcImJnLWluZm8tYWNjZW50XCIsXG4gIE5FRURTX0FQUFJPVkFMOiBcImJnLXdhcm5cIixcbiAgQkxPQ0tFRDogXCJiZy13YXJuXCIsXG4gIEZBSUxFRDogXCJiZy1lcnJcIixcbiAgRE9ORTogXCJiZy1va1wiLFxuICBDQU5DRUxFRDogXCJiZy1pbmstbXV0ZWRcIixcbn07XG5cbnR5cGUgVGFzayA9IHtcbiAgX2lkOiBJZDxcInRhc2tzXCI+O1xuICB0aXRsZTogc3RyaW5nO1xuICB0eXBlOiBzdHJpbmc7XG4gIHN0YXR1czogVGFza1N0YXR1cztcbiAgcHJpb3JpdHk6IG51bWJlcjtcbiAgYWN0dWFsQ29zdDogbnVtYmVyO1xuICBlc3RpbWF0ZWRDb3N0PzogbnVtYmVyO1xuICBhc3NpZ25lZUlkczogSWQ8XCJhZ2VudHNcIj5bXTtcbiAgbGFiZWxzPzogc3RyaW5nW107XG4gIGJsb2NrZWRSZWFzb24/OiBzdHJpbmc7XG4gIHNvdXJjZT86IHN0cmluZztcbiAgc291cmNlUmVmPzogc3RyaW5nO1xuICBpZGVudGlmaWVyPzogc3RyaW5nO1xuICBtZXRhZGF0YT86IHtcbiAgICB3b3JrZmxvd1J1bklkPzogc3RyaW5nO1xuICAgIHdvcmtmbG93QXR0ZW1wdD86IHtcbiAgICAgIGF0dGVtcHROdW1iZXI/OiBudW1iZXI7XG4gICAgICByZXRyeU51bWJlcj86IG51bWJlcjtcbiAgICAgIHN1cGVyc2VkZWRBdD86IG51bWJlcjtcbiAgICB9O1xuICB9O1xufTtcblxuY29uc3QgU09VUkNFX0NPTkZJRzogUmVjb3JkPHN0cmluZywgeyBsYWJlbDogc3RyaW5nOyBpc1NwZWNpYWw/OiBib29sZWFuIH0+ID0ge1xuICBEQVNIQk9BUkQ6IHsgbGFiZWw6IFwiRGFzaGJvYXJkXCIgfSxcbiAgVEVMRUdSQU06ICB7IGxhYmVsOiBcIlRlbGVncmFtXCIgfSxcbiAgR0lUSFVCOiAgICB7IGxhYmVsOiBcIkdpdEh1YlwiIH0sXG4gIEFHRU5UOiAgICAgeyBsYWJlbDogXCJBZ2VudFwiIH0sXG4gIEFQSTogICAgICAgeyBsYWJlbDogXCJBUElcIiB9LFxuICBUUkVMTE86ICAgIHsgbGFiZWw6IFwiVHJlbGxvXCIgfSxcbiAgU0VFRDogICAgICB7IGxhYmVsOiBcIlNlZWRcIiB9LFxuICBNSVNTSU9OX1BST01QVDogeyBsYWJlbDogXCJNaXNzaW9uXCIsIGlzU3BlY2lhbDogdHJ1ZSB9LFxuICBQUkRfSU1QT1JUOiB7IGxhYmVsOiBcIkltcG9ydGVkIFBSRFwiLCBpc1NwZWNpYWw6IHRydWUgfSxcbiAgVU5LTk9XTjogICB7IGxhYmVsOiBcIlVua25vd25cIiB9LFxufTtcblxuY29uc3QgU1RBVFVTX0xBQkVMUzogUmVjb3JkPFRhc2tTdGF0dXMsIHN0cmluZz4gPSB7XG4gIElOQk9YOiBcIkluYm94XCIsXG4gIEFTU0lHTkVEOiBcIkFzc2lnbmVkXCIsXG4gIElOX1BST0dSRVNTOiBcIkluIFByb2dyZXNzXCIsXG4gIFJFVklFVzogXCJSZXZpZXdcIixcbiAgTkVFRFNfQVBQUk9WQUw6IFwiTmVlZHMgQXBwcm92YWxcIixcbiAgQkxPQ0tFRDogXCJCbG9ja2VkXCIsXG4gIEZBSUxFRDogXCJGYWlsZWRcIixcbiAgRE9ORTogXCJEb25lXCIsXG4gIENBTkNFTEVEOiBcIkNhbmNlbGVkXCIsXG59O1xuXG5leHBvcnQgZnVuY3Rpb24gS2FuYmFuKHsgXG4gIHByb2plY3RJZCxcbiAgb25TZWxlY3RUYXNrLFxuICBmaWx0ZXJzLFxufTogeyBcbiAgcHJvamVjdElkOiBJZDxcInByb2plY3RzXCI+IHwgbnVsbDtcbiAgb25TZWxlY3RUYXNrOiAoaWQ6IElkPFwidGFza3NcIj4pID0+IHZvaWQ7XG4gIGZpbHRlcnM/OiB7XG4gICAgYWdlbnRzOiBzdHJpbmdbXTtcbiAgICBwcmlvcml0aWVzOiBudW1iZXJbXTtcbiAgICB0eXBlczogc3RyaW5nW107XG4gIH07XG59KSB7XG4gIGNvbnN0IFthY3RpdmVUYXNrLCBzZXRBY3RpdmVUYXNrXSA9IHVzZVN0YXRlPFRhc2sgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3BsYW5uaW5nVGFza0lkLCBzZXRQbGFubmluZ1Rhc2tJZF0gPSB1c2VTdGF0ZTxJZDxcInRhc2tzXCI+IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtsYXN0TW92ZSwgc2V0TGFzdE1vdmVdID0gdXNlU3RhdGU8e1xuICAgIHRhc2tJZDogSWQ8XCJ0YXNrc1wiPjtcbiAgICBmcm9tU3RhdHVzOiBUYXNrU3RhdHVzO1xuICAgIHRvU3RhdHVzOiBUYXNrU3RhdHVzO1xuICB9IHwgbnVsbD4obnVsbCk7XG4gIFxuICBjb25zdCB0YXNrcyA9IHVzZVF1ZXJ5KGFwaS50YXNrcy5saXN0QWxsLCBwcm9qZWN0SWQgPyB7IHByb2plY3RJZCB9IDoge30pO1xuICBjb25zdCBhZ2VudHMgPSB1c2VRdWVyeShhcGkuYWdlbnRzLmxpc3RBbGwsIHByb2plY3RJZCA/IHsgcHJvamVjdElkIH0gOiB7fSk7XG4gIGNvbnN0IGFsbG93ZWRNYXAgPSB1c2VRdWVyeShhcGkudGFza3MuZ2V0QWxsb3dlZFRyYW5zaXRpb25zRm9ySHVtYW4pO1xuICBjb25zdCB0cmFuc2l0aW9uVGFzayA9IHVzZU11dGF0aW9uKGFwaS50YXNrcy50cmFuc2l0aW9uKTtcbiAgY29uc3QgeyB0b2FzdCB9ID0gdXNlVG9hc3QoKTtcbiAgXG4gIGNvbnN0IHNlbnNvcnMgPSB1c2VTZW5zb3JzKFxuICAgIHVzZVNlbnNvcihQb2ludGVyU2Vuc29yLCB7XG4gICAgICBhY3RpdmF0aW9uQ29uc3RyYWludDogeyBkaXN0YW5jZTogOCB9LFxuICAgIH0pLFxuICAgIHVzZVNlbnNvcihUb3VjaFNlbnNvciwge1xuICAgICAgYWN0aXZhdGlvbkNvbnN0cmFpbnQ6IHsgZGVsYXk6IDI1MCwgdG9sZXJhbmNlOiA1IH0sXG4gICAgfSlcbiAgKTtcblxuICBpZiAodGFza3MgPT09IHVuZGVmaW5lZCB8fCBhZ2VudHMgPT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTMgcC02XCIgYXJpYS1sYWJlbD1cIkxvYWRpbmcgdGFza3NcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTQgdy00OCBhbmltYXRlLXB1bHNlIHJvdW5kZWQgYmctc3VyZmFjZS0yXCIgLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTQgdy03MiBhbmltYXRlLXB1bHNlIHJvdW5kZWQgYmctc3VyZmFjZS0yXCIgLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTQgdy01NiBhbmltYXRlLXB1bHNlIHJvdW5kZWQgYmctc3VyZmFjZS0yXCIgLz5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICBjb25zdCBmaWx0ZXJlZFRhc2tzID0gdGFza3MuZmlsdGVyKCh0YXNrKSA9PiB7XG4gICAgaWYgKCFmaWx0ZXJzKSByZXR1cm4gdHJ1ZTtcbiAgICBpZiAoZmlsdGVycy5hZ2VudHMubGVuZ3RoID4gMCkge1xuICAgICAgY29uc3QgaGFzTWF0Y2hpbmdBZ2VudCA9IHRhc2suYXNzaWduZWVJZHMuc29tZSgoaWQpID0+XG4gICAgICAgIGZpbHRlcnMuYWdlbnRzLmluY2x1ZGVzKGlkKVxuICAgICAgKTtcbiAgICAgIGlmICghaGFzTWF0Y2hpbmdBZ2VudCAmJiB0YXNrLmFzc2lnbmVlSWRzLmxlbmd0aCA+IDApIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKGZpbHRlcnMucHJpb3JpdGllcy5sZW5ndGggPiAwKSB7XG4gICAgICBpZiAoIWZpbHRlcnMucHJpb3JpdGllcy5pbmNsdWRlcyh0YXNrLnByaW9yaXR5KSkgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpZiAoZmlsdGVycy50eXBlcy5sZW5ndGggPiAwKSB7XG4gICAgICBpZiAoIWZpbHRlcnMudHlwZXMuaW5jbHVkZXModGFzay50eXBlKSkgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSk7XG5cbiAgY29uc3QgYWdlbnRNYXAgPSBuZXcgTWFwPElkPFwiYWdlbnRzXCI+LCBEb2M8XCJhZ2VudHNcIj4+KFxuICAgIChhZ2VudHMgYXMgRG9jPFwiYWdlbnRzXCI+W10pLm1hcCgoYTogRG9jPFwiYWdlbnRzXCI+KSA9PiBbYS5faWQsIGFdKVxuICApO1xuICBjb25zdCBieVN0YXR1cyA9IChzdGF0dXM6IFRhc2tTdGF0dXMpID0+XG4gICAgZmlsdGVyZWRUYXNrcy5maWx0ZXIoKHQ6IERvYzxcInRhc2tzXCI+KSA9PiB0LnN0YXR1cyA9PT0gc3RhdHVzKTtcblxuICBjb25zdCBoYW5kbGVNb3ZlVG8gPSBhc3luYyAodGFza0lkOiBJZDxcInRhc2tzXCI+LCBmcm9tU3RhdHVzOiBUYXNrU3RhdHVzLCB0b1N0YXR1czogVGFza1N0YXR1cykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0cmFuc2l0aW9uVGFzayh7XG4gICAgICAgIHRhc2tJZCxcbiAgICAgICAgdG9TdGF0dXMsXG4gICAgICAgIGFjdG9yVHlwZTogXCJIVU1BTlwiLFxuICAgICAgICBhY3RvclVzZXJJZDogXCJvcGVyYXRvclwiLFxuICAgICAgICBpZGVtcG90ZW5jeUtleTogYHVpLSR7dGFza0lkfS0ke3RvU3RhdHVzfS0ke0RhdGUubm93KCl9YCxcbiAgICAgIH0pO1xuICAgICAgaWYgKHJlc3VsdCAmJiB0eXBlb2YgcmVzdWx0ID09PSBcIm9iamVjdFwiICYmIFwic3VjY2Vzc1wiIGluIHJlc3VsdCAmJiAhcmVzdWx0LnN1Y2Nlc3MpIHtcbiAgICAgICAgY29uc3QgZXJyID0gKHJlc3VsdCBhcyB7IGVycm9ycz86IHsgbWVzc2FnZTogc3RyaW5nIH1bXSB9KS5lcnJvcnM/LlswXT8ubWVzc2FnZSA/PyBcIlRyYW5zaXRpb24gZmFpbGVkXCI7XG4gICAgICAgIHRvYXN0KGVyciwgdHJ1ZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRMYXN0TW92ZSh7IHRhc2tJZCwgZnJvbVN0YXR1cywgdG9TdGF0dXMgfSk7XG4gICAgICAgIHRvYXN0KGBNb3ZlZCB0byAke1NUQVRVU19MQUJFTFNbdG9TdGF0dXNdfWApO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHRvYXN0KGUgaW5zdGFuY2VvZiBFcnJvciA/IGUubWVzc2FnZSA6IFwiVHJhbnNpdGlvbiBmYWlsZWRcIiwgdHJ1ZSk7XG4gICAgfVxuICB9O1xuICBcbiAgY29uc3QgaGFuZGxlVW5kbyA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIWxhc3RNb3ZlKSByZXR1cm47XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRyYW5zaXRpb25UYXNrKHtcbiAgICAgICAgdGFza0lkOiBsYXN0TW92ZS50YXNrSWQsXG4gICAgICAgIHRvU3RhdHVzOiBsYXN0TW92ZS5mcm9tU3RhdHVzLFxuICAgICAgICBhY3RvclR5cGU6IFwiSFVNQU5cIixcbiAgICAgICAgYWN0b3JVc2VySWQ6IFwib3BlcmF0b3JcIixcbiAgICAgICAgaWRlbXBvdGVuY3lLZXk6IGB1bmRvLSR7bGFzdE1vdmUudGFza0lkfS0ke0RhdGUubm93KCl9YCxcbiAgICAgIH0pO1xuICAgICAgdG9hc3QoXCJVbmRvbmVcIik7XG4gICAgICBzZXRMYXN0TW92ZShudWxsKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICB0b2FzdChlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiBcIlVuZG8gZmFpbGVkXCIsIHRydWUpO1xuICAgIH1cbiAgfTtcbiAgXG4gIGNvbnN0IGhhbmRsZURyYWdTdGFydCA9IChldmVudDogRHJhZ1N0YXJ0RXZlbnQpID0+IHtcbiAgICBjb25zdCB0YXNrID0gZmlsdGVyZWRUYXNrcy5maW5kKCh0KSA9PiB0Ll9pZCA9PT0gZXZlbnQuYWN0aXZlLmlkKTtcbiAgICBpZiAodGFzaykgc2V0QWN0aXZlVGFzayh0YXNrIGFzIFRhc2spO1xuICB9O1xuICBcbiAgY29uc3QgaGFuZGxlRHJhZ0VuZCA9IChldmVudDogRHJhZ0VuZEV2ZW50KSA9PiB7XG4gICAgc2V0QWN0aXZlVGFzayhudWxsKTtcbiAgICBjb25zdCB7IGFjdGl2ZSwgb3ZlciB9ID0gZXZlbnQ7XG4gICAgaWYgKCFvdmVyIHx8IGFjdGl2ZS5pZCA9PT0gb3Zlci5pZCkgcmV0dXJuO1xuICAgIGNvbnN0IHRhc2sgPSBmaWx0ZXJlZFRhc2tzLmZpbmQoKHQpID0+IHQuX2lkID09PSBhY3RpdmUuaWQpO1xuICAgIGNvbnN0IHRvU3RhdHVzID0gb3Zlci5pZCBhcyBUYXNrU3RhdHVzO1xuICAgIGlmICghdGFzaykgcmV0dXJuO1xuICAgIGNvbnN0IGFsbG93ZWQgPSBhbGxvd2VkTWFwPy5bdGFzay5zdGF0dXNdID8/IFtdO1xuICAgIGlmICghYWxsb3dlZC5pbmNsdWRlcyh0b1N0YXR1cykpIHtcbiAgICAgIHRvYXN0KFwiVHJhbnNpdGlvbiBub3QgYWxsb3dlZFwiLCB0cnVlKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaGFuZGxlTW92ZVRvKHRhc2suX2lkLCB0YXNrLnN0YXR1cywgdG9TdGF0dXMpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLTAgZmxleC0xIGZsZXgtY29sXCI+XG4gICAgPERuZENvbnRleHRcbiAgICAgIHNlbnNvcnM9e3NlbnNvcnN9XG4gICAgICBjb2xsaXNpb25EZXRlY3Rpb249e2Nsb3Nlc3RDb3JuZXJzfVxuICAgICAgb25EcmFnU3RhcnQ9e2hhbmRsZURyYWdTdGFydH1cbiAgICAgIG9uRHJhZ0VuZD17aGFuZGxlRHJhZ0VuZH1cbiAgICA+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggbWluLWgtMCBmbGV4LTEgZmxleC1jb2xcIj5cbiAgICAgICAgey8qIFVuZG8gdG9hc3QgKi99XG4gICAgICAgIHtsYXN0TW92ZSAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBib3R0b20tNiByaWdodC02IHotNTBcIj5cbiAgICAgICAgICAgIDxCdXR0b24gb25DbGljaz17aGFuZGxlVW5kb30gY2xhc3NOYW1lPVwic2hhZG93LVt2YXIoLS1zaGFkb3ctZWxldmF0aW9uLTIpXSBnYXAtMlwiPlxuICAgICAgICAgICAgICA8VW5kbzIgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgIFVuZG9cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgICBcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLTAgZmxleC0xIGl0ZW1zLXN0cmV0Y2ggZ2FwLTMgb3ZlcmZsb3cteC1hdXRvIHAtNFwiPlxuICAgICAgICAgIHtDT0xVTU5TLm1hcCgoY29sKSA9PiAoXG4gICAgICAgICAgICA8Q29sdW1uXG4gICAgICAgICAgICAgIGtleT17Y29sLnN0YXR1c31cbiAgICAgICAgICAgICAgbGFiZWw9e2NvbC5sYWJlbH1cbiAgICAgICAgICAgICAgaWNvbj17Y29sLmljb259XG4gICAgICAgICAgICAgIGNvbG9yQ2xhc3M9e2NvbC5jb2xvcn1cbiAgICAgICAgICAgICAgc3RhdHVzPXtjb2wuc3RhdHVzfVxuICAgICAgICAgICAgICB0YXNrcz17YnlTdGF0dXMoY29sLnN0YXR1cykgYXMgVGFza1tdfVxuICAgICAgICAgICAgICBhZ2VudE1hcD17YWdlbnRNYXB9XG4gICAgICAgICAgICAgIGFsbG93ZWRNYXA9e2FsbG93ZWRNYXAgPz8ge319XG4gICAgICAgICAgICAgIG9uU2VsZWN0VGFzaz17b25TZWxlY3RUYXNrfVxuICAgICAgICAgICAgICBvbk1vdmVUbz17aGFuZGxlTW92ZVRvfVxuICAgICAgICAgICAgICBvblBsYW5UYXNrPXtjb2wuc3RhdHVzID09PSBcIklOQk9YXCIgPyBzZXRQbGFubmluZ1Rhc2tJZCA6IHVuZGVmaW5lZH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICBcbiAgICAgIHsvKiBEcmFnIG92ZXJsYXkgKi99XG4gICAgICA8RHJhZ092ZXJsYXk+XG4gICAgICAgIHthY3RpdmVUYXNrID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctWzI0MHB4XSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItbGluZS1zdHJvbmcgYmctc3VyZmFjZS0zIHAtMyBzaGFkb3ctW3ZhcigtLXNoYWRvdy1lbGV2YXRpb24tMildIG9wYWNpdHktOTVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1bMTMuNXB4XSB0ZXh0LWluayBtYi0xIGxpbmUtY2xhbXAtMlwiPlxuICAgICAgICAgICAgICB7YWN0aXZlVGFzay50aXRsZX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMi41cHhdIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAgICAgIHthY3RpdmVUYXNrLnR5cGV9IMK3IFB7YWN0aXZlVGFzay5wcmlvcml0eX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogbnVsbH1cbiAgICAgIDwvRHJhZ092ZXJsYXk+XG4gICAgICA8UGxhbm5pbmdNb2RhbFxuICAgICAgICB0YXNrSWQ9e3BsYW5uaW5nVGFza0lkfVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRQbGFubmluZ1Rhc2tJZChudWxsKX1cbiAgICAgICAgb25TdWNjZXNzPXsoKSA9PiBzZXRQbGFubmluZ1Rhc2tJZChudWxsKX1cbiAgICAgIC8+XG4gICAgPC9EbmRDb250ZXh0PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5mdW5jdGlvbiBDb2x1bW4oe1xuICBsYWJlbCxcbiAgaWNvbjogSWNvbixcbiAgY29sb3JDbGFzcyxcbiAgc3RhdHVzLFxuICB0YXNrcyxcbiAgYWdlbnRNYXAsXG4gIGFsbG93ZWRNYXAsXG4gIG9uU2VsZWN0VGFzayxcbiAgb25Nb3ZlVG8sXG4gIG9uUGxhblRhc2ssXG59OiB7XG4gIGxhYmVsOiBzdHJpbmc7XG4gIGljb246IEx1Y2lkZUljb247XG4gIGNvbG9yQ2xhc3M6IHN0cmluZztcbiAgc3RhdHVzOiBUYXNrU3RhdHVzO1xuICB0YXNrczogVGFza1tdO1xuICBhZ2VudE1hcDogTWFwPElkPFwiYWdlbnRzXCI+LCB7IG5hbWU6IHN0cmluZzsgZW1vamk/OiBzdHJpbmcgfT47XG4gIGFsbG93ZWRNYXA6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPjtcbiAgb25TZWxlY3RUYXNrOiAoaWQ6IElkPFwidGFza3NcIj4pID0+IHZvaWQ7XG4gIG9uTW92ZVRvOiAodGFza0lkOiBJZDxcInRhc2tzXCI+LCBmcm9tU3RhdHVzOiBUYXNrU3RhdHVzLCB0b1N0YXR1czogVGFza1N0YXR1cykgPT4gdm9pZDtcbiAgb25QbGFuVGFzaz86ICh0YXNrSWQ6IElkPFwidGFza3NcIj4pID0+IHZvaWQ7XG59KSB7XG4gIGNvbnN0IHsgc2V0Tm9kZVJlZiwgaXNPdmVyIH0gPSB1c2VEcm9wcGFibGUoeyBpZDogc3RhdHVzIH0pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgcmVmPXtzZXROb2RlUmVmfVxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJmbGV4IGgtZnVsbCBtaW4taC0wIG1pbi13LVsyNjRweF0gbWF4LXctWzI2NHB4XSBmbGV4LWNvbCByb3VuZGVkLXhsIGJvcmRlciBiZy1zdXJmYWNlLTEgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIG92ZXJmbG93LWhpZGRlblwiLFxuICAgICAgICBpc092ZXIgPyBcImJvcmRlci1saW5lLXN0cm9uZyBiZy1zdXJmYWNlLTJcIiA6IFwiYm9yZGVyLWxpbmVcIlxuICAgICAgKX1cbiAgICA+XG4gICAgICB7LyogTGFuZSBoZWFkZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMgcHktMiBib3JkZXItYiBib3JkZXItbGluZVwiPlxuICAgICAgICA8SWNvbiBzaXplPXsxNH0gc3Ryb2tlV2lkdGg9ezEuNn0gY2xhc3NOYW1lPXtjbihcInNocmluay0wXCIsIGNvbG9yQ2xhc3MpfSAvPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMi41cHhdIGZvbnQtbWVkaXVtIHRleHQtaW5rLXNlY29uZGFyeVwiPntsYWJlbH08L3NwYW4+XG4gICAgICAgIDxTdGF0dXNCYWRnZSB0b25lPVwibmV1dHJhbFwiIGNsYXNzTmFtZT1cIm1sLWF1dG9cIj5cbiAgICAgICAgICB7dGFza3MubGVuZ3RofVxuICAgICAgICA8L1N0YXR1c0JhZGdlPlxuICAgICAgPC9kaXY+XG4gICAgICBcbiAgICAgIHsvKiBDYXJkcyAqL31cbiAgICAgIDxTY3JvbGxBcmVhIGNsYXNzTmFtZT1cIm1pbi1oLTAgZmxleC0xXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMiBwLTJcIj5cbiAgICAgICAgICB7dGFza3MubWFwKCh0KSA9PiAoXG4gICAgICAgICAgICA8Q2FyZFxuICAgICAgICAgICAgICBrZXk9e3QuX2lkfVxuICAgICAgICAgICAgICB0YXNrPXt0fVxuICAgICAgICAgICAgICBhZ2VudE1hcD17YWdlbnRNYXB9XG4gICAgICAgICAgICAgIGFsbG93ZWRUb1N0YXR1c2VzPXsoYWxsb3dlZE1hcFt0LnN0YXR1c10gYXMgVGFza1N0YXR1c1tdIHwgdW5kZWZpbmVkKSA/PyBbXX1cbiAgICAgICAgICAgICAgb25TZWxlY3Q9eygpID0+IG9uU2VsZWN0VGFzayh0Ll9pZCl9XG4gICAgICAgICAgICAgIG9uTW92ZVRvPXsodG9TdGF0dXMpID0+IG9uTW92ZVRvKHQuX2lkLCB0LnN0YXR1cywgdG9TdGF0dXMpfVxuICAgICAgICAgICAgICBvblBsYW5UYXNrPXtvblBsYW5UYXNrfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApKX1cbiAgICAgICAgICB7dGFza3MubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktOCB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMi41cHhdXCI+XG4gICAgICAgICAgICAgICAge3N0YXR1cyA9PT0gXCJCTE9DS0VEXCJcbiAgICAgICAgICAgICAgICAgID8gXCJObyBibG9ja2VkIHRhc2tzXCJcbiAgICAgICAgICAgICAgICAgIDogc3RhdHVzID09PSBcIkRPTkVcIlxuICAgICAgICAgICAgICAgICAgICA/IFwiTm90aGluZyBjb21wbGV0ZWQgeWV0XCJcbiAgICAgICAgICAgICAgICAgICAgOiBcIkRyb3AgdGFza3MgaGVyZVwifVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvU2Nyb2xsQXJlYT5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuXG5mdW5jdGlvbiBDYXJkKHtcbiAgdGFzayxcbiAgYWdlbnRNYXAsXG4gIGFsbG93ZWRUb1N0YXR1c2VzLFxuICBvblNlbGVjdCxcbiAgb25Nb3ZlVG8sXG4gIG9uUGxhblRhc2ssXG59OiB7XG4gIHRhc2s6IFRhc2s7XG4gIGFnZW50TWFwOiBNYXA8SWQ8XCJhZ2VudHNcIj4sIHsgbmFtZTogc3RyaW5nOyBlbW9qaT86IHN0cmluZyB9PjtcbiAgYWxsb3dlZFRvU3RhdHVzZXM6IFRhc2tTdGF0dXNbXTtcbiAgb25TZWxlY3Q6ICgpID0+IHZvaWQ7XG4gIG9uTW92ZVRvOiAodG9TdGF0dXM6IFRhc2tTdGF0dXMpID0+IHZvaWQ7XG4gIG9uUGxhblRhc2s/OiAodGFza0lkOiBJZDxcInRhc2tzXCI+KSA9PiB2b2lkO1xufSkge1xuICBjb25zdCB7IGF0dHJpYnV0ZXMsIGxpc3RlbmVycywgc2V0Tm9kZVJlZiwgdHJhbnNmb3JtLCBpc0RyYWdnaW5nIH0gPSB1c2VEcmFnZ2FibGUoe1xuICAgIGlkOiB0YXNrLl9pZCxcbiAgICBkaXNhYmxlZDogYWxsb3dlZFRvU3RhdHVzZXMubGVuZ3RoID09PSAwLFxuICB9KTtcbiAgXG4gIGNvbnN0IGFzc2lnbmVlcyA9IHRhc2suYXNzaWduZWVJZHNcbiAgICAubWFwKChpZCkgPT4gYWdlbnRNYXAuZ2V0KGlkKSlcbiAgICAuZmlsdGVyKEJvb2xlYW4pO1xuXG4gIGNvbnN0IHNyYyA9IHRhc2suc291cmNlID8gKFNPVVJDRV9DT05GSUdbdGFzay5zb3VyY2VdIHx8IFNPVVJDRV9DT05GSUcuVU5LTk9XTikgOiBudWxsO1xuICBjb25zdCB3b3JrZmxvd0F0dGVtcHQgPSB0YXNrLm1ldGFkYXRhPy53b3JrZmxvd0F0dGVtcHQ7XG5cbiAgY29uc3Qgc3R5bGUgPSB0cmFuc2Zvcm0gPyB7XG4gICAgdHJhbnNmb3JtOiBgdHJhbnNsYXRlM2QoJHt0cmFuc2Zvcm0ueH1weCwgJHt0cmFuc2Zvcm0ueX1weCwgMClgLFxuICB9IDogdW5kZWZpbmVkO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgcmVmPXtzZXROb2RlUmVmfVxuICAgICAgc3R5bGU9e3N0eWxlfVxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJncm91cCByZWxhdGl2ZSByb3VuZGVkLXhsIGJvcmRlciBiZy1zdXJmYWNlLTEgcC0zIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MFwiLFxuICAgICAgICBpc0RyYWdnaW5nID8gXCJvcGFjaXR5LTUwIGJvcmRlci1saW5lLXN0cm9uZ1wiIDogXCJib3JkZXItbGluZSBob3Zlcjpib3JkZXItbGluZS1zdHJvbmcgaG92ZXI6Ymctc3VyZmFjZS0yXCIsXG4gICAgICAgIFwiY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgKX1cbiAgICA+XG4gICAgICB7YWxsb3dlZFRvU3RhdHVzZXMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIHsuLi5hdHRyaWJ1dGVzfVxuICAgICAgICAgIHsuLi5saXN0ZW5lcnN9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMiB0b3AtMiB6LTEwIHJvdW5kZWQgcC0xIHRleHQtaW5rLW11dGVkIG9wYWNpdHktMCB0cmFuc2l0aW9uLW9wYWNpdHkgaG92ZXI6Ymctc3VyZmFjZS0zIGhvdmVyOnRleHQtaW5rLXNlY29uZGFyeSBmb2N1cy12aXNpYmxlOm9wYWNpdHktMTAwIGZvY3VzLXZpc2libGU6b3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy1yaW5nIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwXCJcbiAgICAgICAgICBhcmlhLWxhYmVsPXtgRHJhZyAke3Rhc2sudGl0bGV9YH1cbiAgICAgICAgPlxuICAgICAgICAgIDxHcmlwVmVydGljYWwgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiBhcmlhLWhpZGRlbiAvPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICkgOiBudWxsfVxuICAgICAgPGRpdlxuICAgICAgICByb2xlPVwiYnV0dG9uXCJcbiAgICAgICAgdGFiSW5kZXg9ezB9XG4gICAgICAgIGFyaWEtbGFiZWw9e2BPcGVuIHRhc2sgJHt0YXNrLnRpdGxlfWB9XG4gICAgICAgIG9uQ2xpY2s9e29uU2VsZWN0fVxuICAgICAgICBvbktleURvd249eyhlKSA9PiBlLmtleSA9PT0gXCJFbnRlclwiICYmIG9uU2VsZWN0KCl9XG4gICAgICAgIGNsYXNzTmFtZT1cIm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctcmluZ1wiXG4gICAgICA+XG4gICAgICAgIHsvKiBJZGVudGlmaWVyICsgVGl0bGUgKi99XG4gICAgICAgIHt0YXNrLmlkZW50aWZpZXIgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSBmb250LW1vbm8gdGV4dC1pbmstbXV0ZWQgbWItMVwiPnt0YXNrLmlkZW50aWZpZXJ9PC9kaXY+XG4gICAgICAgICl9XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMiBsaW5lLWNsYW1wLTIgcHItNSB0ZXh0LVsxMy41cHhdIGZvbnQtbWVkaXVtIGxlYWRpbmctc251ZyB0ZXh0LWlua1wiPlxuICAgICAgICAgIHt0YXNrLnRpdGxlfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogTWV0YWRhdGEgY2hpcHMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTEgbWItMlwiPlxuICAgICAgICAgIDxTdGF0dXNCYWRnZSB0b25lPVwibmV1dHJhbFwiPnt0YXNrLnR5cGV9PC9TdGF0dXNCYWRnZT5cbiAgICAgICAgICA8UHJpb3JpdHlDaGlwIHByaW9yaXR5PXt0YXNrLnByaW9yaXR5fSAvPlxuICAgICAgICAgIHtzcmMgJiYgKFxuICAgICAgICAgICAgPFN0YXR1c0JhZGdlIHRvbmU9e3NyYy5pc1NwZWNpYWwgPyBcImluZm9cIiA6IFwibmV1dHJhbFwifT5cbiAgICAgICAgICAgICAge3NyYy5pc1NwZWNpYWwgJiYgPFNwYXJrbGVzIHNpemU9ezExfSBzdHJva2VXaWR0aD17MS43NX0gYXJpYS1oaWRkZW4gLz59XG4gICAgICAgICAgICAgIHtzcmMubGFiZWx9XG4gICAgICAgICAgICA8L1N0YXR1c0JhZGdlPlxuICAgICAgICAgICl9XG4gICAgICAgICAge3Rhc2subWV0YWRhdGE/LndvcmtmbG93UnVuSWQgJiYgd29ya2Zsb3dBdHRlbXB0Py5hdHRlbXB0TnVtYmVyID8gKFxuICAgICAgICAgICAgPFN0YXR1c0JhZGdlIHRvbmU9e3dvcmtmbG93QXR0ZW1wdC5zdXBlcnNlZGVkQXQgPyBcIndhcm5pbmdcIiA6IFwiaW5mb1wifT5cbiAgICAgICAgICAgICAgQXR0ZW1wdCB7d29ya2Zsb3dBdHRlbXB0LmF0dGVtcHROdW1iZXJ9XG4gICAgICAgICAgICAgIHt3b3JrZmxvd0F0dGVtcHQucmV0cnlOdW1iZXIgPyBgIMK3IFJldHJ5ICR7d29ya2Zsb3dBdHRlbXB0LnJldHJ5TnVtYmVyfWAgOiBcIlwifVxuICAgICAgICAgICAgPC9TdGF0dXNCYWRnZT5cbiAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIExhYmVscyAqL31cbiAgICAgICAge3Rhc2subGFiZWxzICYmIHRhc2subGFiZWxzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTEgbWItMlwiPlxuICAgICAgICAgICAge3Rhc2subGFiZWxzLnNsaWNlKDAsIDMpLm1hcCgobGFiZWwpID0+IChcbiAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICBrZXk9e2xhYmVsfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWzExLjVweF0gcHgtMS41IHB5LTAuNSBiZy1zdXJmYWNlLTIgdGV4dC1pbmstc2Vjb25kYXJ5IHJvdW5kZWQtbWRcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge2xhYmVsfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICAgIHt0YXNrLmxhYmVscy5sZW5ndGggPiAzICYmIChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICt7dGFzay5sYWJlbHMubGVuZ3RoIC0gM31cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogQmxvY2tlZCByZWFzb24gKi99XG4gICAgICAgIHt0YXNrLmJsb2NrZWRSZWFzb24gJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTIuNXB4XSBweC0yIHB5LTEuNSBiZy1lcnItc29mdCB0ZXh0LWVyciByb3VuZGVkLW1kIG1iLTIgZmxleCBpdGVtcy1zdGFydCBnYXAtMS41XCI+XG4gICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJoLTMgdy0zIG10LTAuNSBzaHJpbmstMFwiIHN0cm9rZVdpZHRoPXsxLjc1fSAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGluZS1jbGFtcC0yXCI+e3Rhc2suYmxvY2tlZFJlYXNvbn08L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIEZvb3RlcjogQ29zdCAmIEFzc2lnbmVlcyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bMTIuNXB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICA8RG9sbGFyU2lnbiBjbGFzc05hbWU9XCJoLTMgdy0zXCIgc3Ryb2tlV2lkdGg9ezEuNzV9IC8+XG4gICAgICAgICAgICB7dGFzay5hY3R1YWxDb3N0LnRvRml4ZWQoMil9XG4gICAgICAgICAgICB7dGFzay5lc3RpbWF0ZWRDb3N0ICE9IG51bGwgJiYgKFxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWluay1tdXRlZC82MFwiPiAvICR7dGFzay5lc3RpbWF0ZWRDb3N0LnRvRml4ZWQoMil9PC9zcGFuPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IC1zcGFjZS14LTEuNVwiPlxuICAgICAgICAgICAge2Fzc2lnbmVlcy5zbGljZSgwLCAzKS5tYXAoKGFnZW50LCBpKSA9PiAoXG4gICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAga2V5PXtpfVxuICAgICAgICAgICAgICAgIHRpdGxlPXthZ2VudCEubmFtZX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGgtNSB3LTUgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1zdXJmYWNlLTIgdGV4dC1bMTFweF0gdGV4dC1pbmstc2Vjb25kYXJ5IGJvcmRlciBib3JkZXItbGluZVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7YWdlbnQhLmVtb2ppIHx8IGFnZW50IS5uYW1lLmNoYXJBdCgwKX1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICB7YXNzaWduZWVzLmxlbmd0aCA+IDMgJiYgKFxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGgtNSB3LTUgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1zdXJmYWNlLTIgdGV4dC1bMTFweF0gdGV4dC1pbmstc2Vjb25kYXJ5IGJvcmRlciBib3JkZXItbGluZVwiPlxuICAgICAgICAgICAgICAgICt7YXNzaWduZWVzLmxlbmd0aCAtIDN9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBIb3ZlciBhY3Rpb25zICovfVxuICAgICAgeyhhbGxvd2VkVG9TdGF0dXNlcy5sZW5ndGggPiAwIHx8IG9uUGxhblRhc2spICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGJvcmRlci10IGJvcmRlci1saW5lIHB0LTJcIj5cbiAgICAgICAgICB7b25QbGFuVGFzayAmJiAoXG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtNiB0ZXh0LVsxMXB4XSBweC0yXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHsgZS5zdG9wUHJvcGFnYXRpb24oKTsgb25QbGFuVGFzayh0YXNrLl9pZCk7IH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJoLTMgdy0zIG1yLTFcIiBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAgICAgICAgUGxhbiB3aXRoIEFJXG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICAgIHthbGxvd2VkVG9TdGF0dXNlcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgIDxEcm9wZG93bk1lbnU+XG4gICAgICAgICAgICAgIDxEcm9wZG93bk1lbnVUcmlnZ2VyIGFzQ2hpbGQ+XG4gICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBzaXplPVwic21cIiBjbGFzc05hbWU9XCJoLTYgdGV4dC1bMTFweF0gcHgtMlwiPlxuICAgICAgICAgICAgICAgICAgPEFycm93UmlnaHQgY2xhc3NOYW1lPVwiaC0zIHctMyBtci0xXCIgc3Ryb2tlV2lkdGg9ezEuNzV9IC8+XG4gICAgICAgICAgICAgICAgICBNb3ZlXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDwvRHJvcGRvd25NZW51VHJpZ2dlcj5cbiAgICAgICAgICAgICAgPERyb3Bkb3duTWVudUNvbnRlbnQgYWxpZ249XCJzdGFydFwiIGNsYXNzTmFtZT1cInctNDRcIj5cbiAgICAgICAgICAgICAgICB7YWxsb3dlZFRvU3RhdHVzZXMubWFwKChzOiBUYXNrU3RhdHVzKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8RHJvcGRvd25NZW51SXRlbVxuICAgICAgICAgICAgICAgICAgICBrZXk9e3N9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7IGUuc3RvcFByb3BhZ2F0aW9uKCk7IG9uTW92ZVRvKHMpOyB9fVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2NuKFwiaC0xLjUgdy0xLjUgcm91bmRlZC1mdWxsIG1yLTJcIiwgQ09MVU1OX0RPVFtzXSl9IC8+XG4gICAgICAgICAgICAgICAgICAgIHtTVEFUVVNfTEFCRUxTW3NdfVxuICAgICAgICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnVJdGVtPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L0Ryb3Bkb3duTWVudUNvbnRlbnQ+XG4gICAgICAgICAgICA8L0Ryb3Bkb3duTWVudT5cbiAgICAgICAgICApfVxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC02IHRleHQtWzExcHhdIHB4LTIgbWwtYXV0b1wiXG4gICAgICAgICAgICBvbkNsaWNrPXtvblNlbGVjdH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8RXh0ZXJuYWxMaW5rIGNsYXNzTmFtZT1cImgtMyB3LTMgbXItMVwiIC8+XG4gICAgICAgICAgICBPcGVuXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2pheXdlc3QvTWlzc2lvbkNvbnRyb2wvLndvcmt0cmVlcy9jb2RleC9zb2Z0d2FyZS1mYWN0b3J5LWVuaGFuY2VtZW50LXBsYW4vLndvcmt0cmVlcy9jb2RleC9hdXRvbWF0aW9uLWNvbnRyb2wtcGxhbmUtdjEvYXBwcy9taXNzaW9uLWNvbnRyb2wtdWkvc3JjL0thbmJhbi50c3gifQ==