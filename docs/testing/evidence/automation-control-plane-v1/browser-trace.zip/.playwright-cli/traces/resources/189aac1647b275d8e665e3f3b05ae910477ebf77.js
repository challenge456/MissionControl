import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AppTopBar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8b675e85"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Button } from "/src/components/ui/button.tsx";
import { cn } from "/src/lib/utils.ts";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "/src/components/ui/dropdown-menu.tsx";
import { QuotaFuelGauge } from "/src/components/QuotaFuelGauge.tsx";
import { usePrivacy } from "/src/contexts/PrivacyContext.tsx";
import {
  Search,
  Plus,
  BarChart3,
  Settings,
  Keyboard,
  Activity,
  DollarSign,
  TrendingDown,
  HeartPulse,
  Monitor,
  LayoutDashboard,
  AlertTriangle,
  User,
  Moon,
  Sun,
  Shield,
  Bot,
  Sparkles,
  Eye,
  EyeOff
} from "/node_modules/.vite/deps/lucide-react.js?v=f8823a74";
import __vite__cjsImport9_react from "/node_modules/.vite/deps/react.js?v=8b675e85"; const useState = __vite__cjsImport9_react["useState"]; const useEffect = __vite__cjsImport9_react["useEffect"];
const AI_STATUS_STYLES = {
  active: {
    ring: "border-line bg-ok-soft text-ok",
    dot: "bg-ok",
    badge: "text-ok"
  },
  thinking: {
    ring: "border-line bg-warn-soft text-warn",
    dot: "bg-warn",
    badge: "text-warn"
  },
  idle: {
    ring: "border-line bg-info-soft text-info-accent",
    dot: "bg-info-accent",
    badge: "text-info-accent"
  },
  offline: {
    ring: "border-line bg-surface-2 text-ink-muted",
    dot: "bg-ink-muted",
    badge: "text-ink-muted"
  }
};
export function AppTopBar({
  projectSwitcher,
  searchBar,
  activeCount,
  taskCount,
  aiStatus,
  timeStr,
  dateStr,
  pendingApprovals = 0,
  projectId,
  onNewTask,
  onOpenControls,
  onOpenCommandPalette,
  onOpenCostAnalytics,
  onOpenBudgetBurnDown,
  onOpenAdvancedAnalytics,
  onOpenHealthDashboard,
  onOpenMonitoringDashboard,
  onOpenDashboardOverview,
  onOpenActivityFeed,
  onOpenKeyboardHelp,
  onOpenApprovals,
  onOpenNotifications,
  onOpenAgentsFlyout,
  onOpenAiStatus,
  onOpenMissionModal,
  onOpenSuggestionsDrawer
}) {
  _s();
  const [theme, setTheme] = useState(() => {
    if (typeof window === "undefined") return "dark";
    return window.localStorage.getItem("mc.theme") || "dark";
  });
  const { privacyMode, togglePrivacyMode } = usePrivacy();
  const aiStatusStyle = AI_STATUS_STYLES[aiStatus.tone];
  const reviewLabel = pendingApprovals > 0 ? `${pendingApprovals} review` : "review clear";
  const operatorCue = pendingApprovals > 0 && onOpenApprovals ? {
    label: "Pending approvals",
    detail: `${pendingApprovals} decision${pendingApprovals === 1 ? "" : "s"} need operator review.`,
    actionLabel: "Review now",
    icon: Shield,
    toneClass: "border-line bg-warn-soft text-warn",
    onClick: onOpenApprovals
  } : (aiStatus.tone === "offline" || activeCount === 0) && onOpenAiStatus ? {
    label: "Agent network idle",
    detail: "No live execution is reporting in. Inspect the fleet before trust degrades.",
    actionLabel: "Inspect fleet",
    icon: Bot,
    toneClass: "border-line bg-surface-2 text-ink-secondary",
    onClick: onOpenAiStatus
  } : taskCount === 0 ? {
    label: "Mission queue is empty",
    detail: "Seed the next task now so the system does not stall between cycles.",
    actionLabel: "Create task",
    icon: Plus,
    toneClass: "border-line bg-info-soft text-info-accent",
    onClick: onNewTask
  } : onOpenSuggestionsDrawer ? {
    label: "Create the next move",
    detail: "Use mission-aligned suggestions to keep the system proactive instead of reactive.",
    actionLabel: "Generate tasks",
    icon: Sparkles,
    toneClass: "border-line bg-ok-soft text-ok",
    onClick: onOpenSuggestionsDrawer
  } : null;
  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute("data-theme", theme);
    root.classList.toggle("light", theme === "light");
    window.localStorage.setItem("mc.theme", theme);
  }, [theme]);
  return /* @__PURE__ */ jsxDEV("header", { className: "relative grid min-h-[68px] grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-b border-line bg-rail px-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "relative flex min-w-0 flex-1 items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "hidden 2xl:flex items-center gap-3 rounded-xl border border-line bg-surface-1 px-3.5 py-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex h-11 w-11 items-center justify-center rounded-lg border border-line bg-surface-2 text-ink-secondary", children: /* @__PURE__ */ jsxDEV(Bot, { className: "h-5 w-5", strokeWidth: 1.6 }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
          lineNumber: 204,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
          lineNumber: 203,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-medium text-ink-muted", children: "SellerFi" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
            lineNumber: 207,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-semibold text-ink", children: "Mission Control" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
            lineNumber: 210,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
          lineNumber: 206,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
        lineNumber: 202,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "shrink-0", children: projectSwitcher }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
        lineNumber: 216,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "hidden sm:block flex-1 max-w-[320px]", children: searchBar }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
        lineNumber: 218,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "ghost",
          size: "icon",
          className: "h-9 w-9 rounded-lg sm:hidden",
          onClick: onOpenCommandPalette,
          "aria-label": "Search",
          children: /* @__PURE__ */ jsxDEV(Search, { className: "h-4 w-4" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
            lineNumber: 229,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
          lineNumber: 222,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
      lineNumber: 201,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative hidden min-w-0 2xl:flex items-center gap-2.5", children: [
      onOpenAiStatus && /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: onOpenAiStatus,
          className: "group flex min-w-[210px] max-w-[252px] items-center gap-3 rounded-xl border border-line bg-surface-1 px-3.5 py-2.5 text-left transition-colors duration-150 hover:border-line-strong hover:bg-surface-2",
          title: aiStatus.detail,
          children: [
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: cn(
                  "relative flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border",
                  aiStatusStyle.ring
                ),
                children: [
                  /* @__PURE__ */ jsxDEV(HeartPulse, { className: "h-4.5 w-4.5", strokeWidth: 1.7 }, void 0, false, {
                    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                    lineNumber: 247,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "span",
                    {
                      className: cn(
                        "absolute right-1.5 top-1.5 h-2 w-2 rounded-full",
                        aiStatusStyle.dot
                      ),
                      "aria-hidden": "true"
                    },
                    void 0,
                    false,
                    {
                      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                      lineNumber: 248,
                      columnNumber: 15
                    },
                    this
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 241,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] font-medium text-ink-muted", children: "AI status" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                  lineNumber: 258,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: cn("text-[11px] font-medium", aiStatusStyle.badge), children: aiStatus.lastSeenLabel }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                  lineNumber: 261,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 257,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-1 truncate text-sm font-semibold text-ink", children: aiStatus.label }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 265,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-0.5 truncate text-[11px] text-ink-muted", children: aiStatus.detail }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 268,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
              lineNumber: 256,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
          lineNumber: 235,
          columnNumber: 9
        },
        this
      ),
      operatorCue && /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: operatorCue.onClick,
          className: cn(
            "group flex min-w-[228px] max-w-[300px] items-center gap-3 rounded-xl border px-3.5 py-2.5 text-left transition-colors duration-150 hover:border-line-strong",
            operatorCue.toneClass
          ),
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-line bg-surface-1", children: /* @__PURE__ */ jsxDEV(operatorCue.icon, { className: "h-4 w-4", strokeWidth: 1.7 }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
              lineNumber: 285,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
              lineNumber: 284,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "text-[11.5px] font-medium", children: operatorCue.label }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 288,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-1 line-clamp-2 text-[11px] leading-relaxed text-ink-secondary", children: operatorCue.detail }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 291,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-[11px] font-medium", children: operatorCue.actionLabel }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 294,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
              lineNumber: 287,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
          lineNumber: 276,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
      lineNumber: 233,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative flex items-center gap-1.5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "hidden 2xl:flex items-center gap-1 rounded-lg border border-line bg-surface-1 p-0.5", children: [
        onOpenAiStatus && /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: onOpenAiStatus,
            className: "flex items-center gap-2 rounded-md px-3 py-1.5 text-left text-[11px] text-ink-secondary transition-colors duration-150 hover:bg-surface-2 hover:text-ink",
            title: aiStatus.detail,
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: cn("h-2 w-2 rounded-full", aiStatusStyle.dot) }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 312,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: aiStatus.label }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 313,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
            lineNumber: 306,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: onOpenAgentsFlyout ?? onOpenDashboardOverview,
            className: "rounded-md px-3 py-1.5 text-[11px] text-ink-secondary transition-colors duration-150 hover:bg-surface-2 hover:text-ink",
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-ink", children: activeCount }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 321,
                columnNumber: 13
              }, this),
              " live"
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
            lineNumber: 316,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: onOpenDashboardOverview,
            className: "rounded-md px-3 py-1.5 text-[11px] text-ink-secondary transition-colors duration-150 hover:bg-surface-2 hover:text-ink",
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-ink", children: taskCount }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 328,
                columnNumber: 13
              }, this),
              " tasks"
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
            lineNumber: 323,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: onOpenApprovals ?? onOpenDashboardOverview,
            className: "rounded-md px-3 py-1.5 text-[11px] text-ink-secondary transition-colors duration-150 hover:bg-surface-2 hover:text-ink",
            children: reviewLabel
          },
          void 0,
          false,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
            lineNumber: 330,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
        lineNumber: 304,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "hidden md:flex items-center gap-1 rounded-lg border border-line bg-surface-1 px-1.5 py-1", children: [
        onOpenApprovals && /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "ghost",
            size: "sm",
            className: "relative h-8 rounded-lg px-3 text-xs",
            onClick: onOpenApprovals,
            "aria-label": `Approvals${pendingApprovals > 0 ? ` (${pendingApprovals} pending)` : ""}`,
            children: [
              /* @__PURE__ */ jsxDEV(Shield, { className: "h-3.5 w-3.5 mr-1" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 348,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "hidden xl:inline", children: "Approvals" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 349,
                columnNumber: 15
              }, this),
              pendingApprovals > 0 && /* @__PURE__ */ jsxDEV("span", { className: "absolute -top-0.5 -right-0.5 min-w-4 h-4 flex items-center justify-center rounded-full bg-destructive text-destructive-foreground text-[9px] font-bold", children: pendingApprovals }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 351,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
            lineNumber: 341,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(DropdownMenu, { children: [
          /* @__PURE__ */ jsxDEV(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "ghost",
              size: "sm",
              className: "h-8 rounded-lg px-3 text-xs",
              title: "Insights — Cost Analytics, Provider billing, Health, Monitoring",
              children: [
                /* @__PURE__ */ jsxDEV(BarChart3, { className: "h-3.5 w-3.5 mr-1.5" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                  lineNumber: 366,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "hidden xl:inline", children: "Insights" }, void 0, false, {
                  fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                  lineNumber: 367,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
              lineNumber: 360,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
            lineNumber: 359,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DropdownMenuContent, { align: "end", className: "w-52", children: [
            /* @__PURE__ */ jsxDEV(DropdownMenuItem, { onClick: onOpenCostAnalytics, children: [
              /* @__PURE__ */ jsxDEV(DollarSign, { className: "h-4 w-4 mr-2" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 372,
                columnNumber: 17
              }, this),
              "Cost Analytics"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
              lineNumber: 371,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(DropdownMenuItem, { onClick: onOpenBudgetBurnDown, children: [
              /* @__PURE__ */ jsxDEV(TrendingDown, { className: "h-4 w-4 mr-2" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 375,
                columnNumber: 17
              }, this),
              "Budget Burn-Down"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
              lineNumber: 374,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(DropdownMenuItem, { onClick: onOpenAdvancedAnalytics, children: [
              /* @__PURE__ */ jsxDEV(BarChart3, { className: "h-4 w-4 mr-2" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 378,
                columnNumber: 17
              }, this),
              "Advanced Analytics"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
              lineNumber: 377,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(DropdownMenuSeparator, {}, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
              lineNumber: 380,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(DropdownMenuItem, { onClick: onOpenHealthDashboard, children: [
              /* @__PURE__ */ jsxDEV(HeartPulse, { className: "h-4 w-4 mr-2" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 382,
                columnNumber: 17
              }, this),
              "Health Dashboard"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
              lineNumber: 381,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(DropdownMenuItem, { onClick: onOpenMonitoringDashboard, children: [
              /* @__PURE__ */ jsxDEV(Monitor, { className: "h-4 w-4 mr-2" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 385,
                columnNumber: 17
              }, this),
              "Monitoring"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
              lineNumber: 384,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(DropdownMenuItem, { onClick: onOpenDashboardOverview, children: [
              /* @__PURE__ */ jsxDEV(LayoutDashboard, { className: "h-4 w-4 mr-2" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 388,
                columnNumber: 17
              }, this),
              "Overview Snapshot"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
              lineNumber: 387,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(DropdownMenuSeparator, {}, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
              lineNumber: 390,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(DropdownMenuItem, { onClick: onOpenActivityFeed, children: [
              /* @__PURE__ */ jsxDEV(Activity, { className: "h-4 w-4 mr-2" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 392,
                columnNumber: 17
              }, this),
              "Activity Timeline"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
              lineNumber: 391,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(DropdownMenuItem, { onClick: onOpenKeyboardHelp, children: [
              /* @__PURE__ */ jsxDEV(Keyboard, { className: "h-4 w-4 mr-2" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 395,
                columnNumber: 17
              }, this),
              "Shortcuts"
            ] }, void 0, true, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
              lineNumber: 394,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
            lineNumber: 370,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
          lineNumber: 358,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "ghost",
            size: "sm",
            className: "h-8 rounded-lg px-3 text-xs text-warn hover:text-warn",
            onClick: onOpenControls,
            children: [
              /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "h-3.5 w-3.5 mr-1" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 406,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "hidden xl:inline", children: "Controls" }, void 0, false, {
                fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
                lineNumber: 407,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
            lineNumber: 400,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
        lineNumber: 339,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { size: "sm", className: "h-9 px-3", onClick: onNewTask, children: [
        /* @__PURE__ */ jsxDEV(Plus, { className: "h-3.5 w-3.5 mr-1" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
          lineNumber: 412,
          columnNumber: 11
        }, this),
        "New Task"
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
        lineNumber: 411,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "hidden 2xl:inline whitespace-nowrap rounded-md border border-line bg-surface-1 px-3 py-1.5 text-[11px] text-ink-secondary", children: [
        timeStr,
        " ",
        dateStr
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
        lineNumber: 416,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "hidden xl:flex items-center gap-1.5 rounded-md border border-transparent bg-ok-soft px-3 py-1.5 text-[11px] font-medium text-ok", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "h-1.5 w-1.5 rounded-full bg-ok" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
          lineNumber: 420,
          columnNumber: 11
        }, this),
        "Operator online"
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
        lineNumber: 419,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(QuotaFuelGauge, { compact: true, className: "hidden xl:flex ml-1" }, void 0, false, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
        lineNumber: 424,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "ghost",
          size: "icon",
          className: "h-9 w-9 rounded-lg",
          onClick: togglePrivacyMode,
          "aria-label": privacyMode ? "Show sensitive info" : "Hide sensitive info (demo mode)",
          title: privacyMode ? "Privacy on — click to show names" : "Privacy off — click to redact for demos",
          children: privacyMode ? /* @__PURE__ */ jsxDEV(EyeOff, { className: "h-4 w-4" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
            lineNumber: 434,
            columnNumber: 26
          }, this) : /* @__PURE__ */ jsxDEV(Eye, { className: "h-4 w-4" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
            lineNumber: 434,
            columnNumber: 59
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
          lineNumber: 426,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "ghost",
          size: "icon",
          className: "h-9 w-9 rounded-lg",
          onClick: () => setTheme(theme === "dark" ? "light" : "dark"),
          "aria-label": `Switch to ${theme === "dark" ? "light" : "dark"} mode`,
          children: theme === "dark" ? /* @__PURE__ */ jsxDEV(Sun, { className: "h-4 w-4" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
            lineNumber: 445,
            columnNumber: 31
          }, this) : /* @__PURE__ */ jsxDEV(Moon, { className: "h-4 w-4" }, void 0, false, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
            lineNumber: 445,
            columnNumber: 61
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
          lineNumber: 438,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(DropdownMenu, { children: [
        /* @__PURE__ */ jsxDEV(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "icon", className: "h-9 w-9 rounded-lg", children: /* @__PURE__ */ jsxDEV(User, { className: "h-4 w-4" }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
          lineNumber: 452,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
          lineNumber: 451,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
          lineNumber: 450,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(DropdownMenuContent, { align: "end", className: "w-44", children: [
          /* @__PURE__ */ jsxDEV(DropdownMenuItem, { disabled: true, children: [
            /* @__PURE__ */ jsxDEV(Settings, { className: "h-4 w-4 mr-2" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
              lineNumber: 457,
              columnNumber: 15
            }, this),
            "Settings"
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
            lineNumber: 456,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DropdownMenuItem, { onClick: onOpenKeyboardHelp, children: [
            /* @__PURE__ */ jsxDEV(Keyboard, { className: "h-4 w-4 mr-2" }, void 0, false, {
              fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
              lineNumber: 460,
              columnNumber: 15
            }, this),
            "Shortcuts"
          ] }, void 0, true, {
            fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
            lineNumber: 459,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
          lineNumber: 455,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
        lineNumber: 449,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
      lineNumber: 303,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx",
    lineNumber: 200,
    columnNumber: 5
  }, this);
}
_s(AppTopBar, "4+S4TQ+NuKTDLmCAMqephP873hI=", false, function() {
  return [usePrivacy];
});
_c = AppTopBar;
var _c;
$RefreshReg$(_c, "AppTopBar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/jaywest/MissionControl/.worktrees/codex/software-factory-enhancement-plan/.worktrees/codex/automation-control-plane-v1/apps/mission-control-ui/src/components/AppTopBar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0xZOzs7Ozs7Ozs7Ozs7Ozs7OztBQXhMWixTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLFVBQVU7QUFDbkI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGtCQUFrQjtBQUMzQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxVQUFVQyxpQkFBaUI7QUF5Q3BDLE1BQU1DLG1CQUFzRjtBQUFBLEVBQzFGQyxRQUFRO0FBQUEsSUFDTkMsTUFBTTtBQUFBLElBQ05DLEtBQUs7QUFBQSxJQUNMQyxPQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0FDLFVBQVU7QUFBQSxJQUNSSCxNQUFNO0FBQUEsSUFDTkMsS0FBSztBQUFBLElBQ0xDLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQUUsTUFBTTtBQUFBLElBQ0pKLE1BQU07QUFBQSxJQUNOQyxLQUFLO0FBQUEsSUFDTEMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBRyxTQUFTO0FBQUEsSUFDUEwsTUFBTTtBQUFBLElBQ05DLEtBQUs7QUFBQSxJQUNMQyxPQUFPO0FBQUEsRUFDVDtBQUNGO0FBRU8sZ0JBQVNJLFVBQVU7QUFBQSxFQUN4QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsbUJBQW1CO0FBQUEsRUFDbkJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ2MsR0FBRztBQUFBQyxLQUFBO0FBQ2pCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJdkMsU0FBUyxNQUFNO0FBQ3ZDLFFBQUksT0FBT3dDLFdBQVcsWUFBYSxRQUFPO0FBQzFDLFdBQU9BLE9BQU9DLGFBQWFDLFFBQVEsVUFBVSxLQUFLO0FBQUEsRUFDcEQsQ0FBQztBQUVELFFBQU0sRUFBRUMsYUFBYUMsa0JBQWtCLElBQUlqRSxXQUFXO0FBQ3RELFFBQU1rRSxnQkFBZ0IzQyxpQkFBaUJhLFNBQVMrQixJQUFJO0FBQ3BELFFBQU1DLGNBQWM3QixtQkFBbUIsSUFBSSxHQUFHQSxnQkFBZ0IsWUFBWTtBQUMxRSxRQUFNOEIsY0FDSjlCLG1CQUFtQixLQUFLYSxrQkFDcEI7QUFBQSxJQUNFa0IsT0FBTztBQUFBLElBQ1BDLFFBQVEsR0FBR2hDLGdCQUFnQixZQUFZQSxxQkFBcUIsSUFBSSxLQUFLLEdBQUc7QUFBQSxJQUN4RWlDLGFBQWE7QUFBQSxJQUNiQyxNQUFNekQ7QUFBQUEsSUFDTjBELFdBQVc7QUFBQSxJQUNYQyxTQUFTdkI7QUFBQUEsRUFDWCxLQUNDaEIsU0FBUytCLFNBQVMsYUFBYWpDLGdCQUFnQixNQUFNcUIsaUJBQ3BEO0FBQUEsSUFDRWUsT0FBTztBQUFBLElBQ1BDLFFBQVE7QUFBQSxJQUNSQyxhQUFhO0FBQUEsSUFDYkMsTUFBTXhEO0FBQUFBLElBQ055RCxXQUFXO0FBQUEsSUFDWEMsU0FBU3BCO0FBQUFBLEVBQ1gsSUFDQXBCLGNBQWMsSUFDWjtBQUFBLElBQ0VtQyxPQUFPO0FBQUEsSUFDUEMsUUFBUTtBQUFBLElBQ1JDLGFBQWE7QUFBQSxJQUNiQyxNQUFNdkU7QUFBQUEsSUFDTndFLFdBQVc7QUFBQSxJQUNYQyxTQUFTbEM7QUFBQUEsRUFDWCxJQUNBZ0IsMEJBQ0U7QUFBQSxJQUNFYSxPQUFPO0FBQUEsSUFDUEMsUUFBUTtBQUFBLElBQ1JDLGFBQWE7QUFBQSxJQUNiQyxNQUFNdkQ7QUFBQUEsSUFDTndELFdBQVc7QUFBQSxJQUNYQyxTQUFTbEI7QUFBQUEsRUFDWCxJQUNBO0FBRVpuQyxZQUFVLE1BQU07QUFDZCxVQUFNc0QsT0FBT0MsU0FBU0M7QUFDdEJGLFNBQUtHLGFBQWEsY0FBY3BCLEtBQUs7QUFDckNpQixTQUFLSSxVQUFVQyxPQUFPLFNBQVN0QixVQUFVLE9BQU87QUFDaERFLFdBQU9DLGFBQWFvQixRQUFRLFlBQVl2QixLQUFLO0FBQUEsRUFDL0MsR0FBRyxDQUFDQSxLQUFLLENBQUM7QUFFVixTQUNFLHVCQUFDLFlBQU8sV0FBVSxrSEFDaEI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsbURBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsNkZBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsNEdBQ2IsaUNBQUMsT0FBSSxXQUFVLFdBQVUsYUFBYSxPQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBDLEtBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMENBQXdDLHdCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsa0NBQWdDLCtCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLFlBQVkzQiw2QkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQztBQUFBLE1BRTNDLHVCQUFDLFNBQUksV0FBVSx3Q0FDWkMsdUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUTtBQUFBLFVBQ1IsTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBQ1YsU0FBU1U7QUFBQUEsVUFDVCxjQUFXO0FBQUEsVUFFWCxpQ0FBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQTtBQUFBLFFBUDdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBO0FBQUEsU0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlEQUNaWTtBQUFBQSx3QkFDQztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FBU0E7QUFBQUEsVUFDVCxXQUFVO0FBQUEsVUFDVixPQUFPbkIsU0FBU21DO0FBQUFBLFVBRWhCO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXOUU7QUFBQUEsa0JBQ1Q7QUFBQSxrQkFDQXlFLGNBQWN6QztBQUFBQSxnQkFDaEI7QUFBQSxnQkFFQTtBQUFBLHlDQUFDLGNBQVcsV0FBVSxlQUFjLGFBQWEsT0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUQ7QUFBQSxrQkFDckQ7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBV2hDO0FBQUFBLHdCQUNUO0FBQUEsd0JBQ0F5RSxjQUFjeEM7QUFBQUEsc0JBQ2hCO0FBQUEsc0JBQ0EsZUFBWTtBQUFBO0FBQUEsb0JBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtvQjtBQUFBO0FBQUE7QUFBQSxjQVp0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFjQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLDRDQUEwQyx5QkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBV2pDLEdBQUcsMkJBQTJCeUUsY0FBY3ZDLEtBQUssR0FDL0RTLG1CQUFTK0MsaUJBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxnREFDWi9DLG1CQUFTa0MsU0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsOENBQ1psQyxtQkFBU21DLFVBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQTtBQUFBO0FBQUEsUUFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BcUNBO0FBQUEsTUFHREYsZUFDQztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FBU0EsWUFBWU07QUFBQUEsVUFDckIsV0FBV2xGO0FBQUFBLFlBQ1Q7QUFBQSxZQUNBNEUsWUFBWUs7QUFBQUEsVUFDZDtBQUFBLFVBRUE7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsa0dBQ2IsaUNBQUMsWUFBWSxNQUFaLEVBQWlCLFdBQVUsV0FBVSxhQUFhLE9BQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVELEtBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSw2QkFDWkwsc0JBQVlDLFNBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLG9FQUNaRCxzQkFBWUUsVUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ1pGLHNCQUFZRyxlQURmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUE7QUFBQTtBQUFBLFFBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXNCQTtBQUFBLFNBakVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvRUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxzQ0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSx1RkFDWmpCO0FBQUFBLDBCQUNDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTQTtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUNWLE9BQU9uQixTQUFTbUM7QUFBQUEsWUFFaEI7QUFBQSxxQ0FBQyxVQUFLLFdBQVc5RSxHQUFHLHdCQUF3QnlFLGNBQWN4QyxHQUFHLEtBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStEO0FBQUEsY0FDL0QsdUJBQUMsVUFBTVUsbUJBQVNrQyxTQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzQjtBQUFBO0FBQUE7QUFBQSxVQVB4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLFFBRUY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVNoQixzQkFBc0JMO0FBQUFBLFlBQy9CLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsVUFBSyxXQUFVLHdCQUF3QmYseUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9EO0FBQUEsY0FBTztBQUFBO0FBQUE7QUFBQSxVQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVNlO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsd0JBQXdCZCx1QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0Q7QUFBQSxjQUFPO0FBQUE7QUFBQTtBQUFBLFVBTDNEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBU2lCLG1CQUFtQkg7QUFBQUEsWUFDNUIsV0FBVTtBQUFBLFlBRVRtQjtBQUFBQTtBQUFBQSxVQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsV0FoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlDQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDRGQUNaaEI7QUFBQUEsMkJBQ0M7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVE7QUFBQSxZQUNSLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUNWLFNBQVNBO0FBQUFBLFlBQ1QsY0FBWSxZQUFZYixtQkFBbUIsSUFBSSxLQUFLQSxnQkFBZ0IsY0FBYyxFQUFFO0FBQUEsWUFFcEY7QUFBQSxxQ0FBQyxVQUFPLFdBQVUsc0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9DO0FBQUEsY0FDcEMsdUJBQUMsVUFBSyxXQUFVLG9CQUFtQix5QkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEM7QUFBQSxjQUMzQ0EsbUJBQW1CLEtBQ2xCLHVCQUFDLFVBQUssV0FBVSwwSkFDYkEsOEJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBO0FBQUE7QUFBQSxVQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWNBO0FBQUEsUUFHRix1QkFBQyxnQkFDQztBQUFBLGlDQUFDLHVCQUFvQixTQUFPLE1BQzFCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFRO0FBQUEsY0FDUixNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixPQUFNO0FBQUEsY0FFTjtBQUFBLHVDQUFDLGFBQVUsV0FBVSx3QkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUM7QUFBQSxnQkFDekMsdUJBQUMsVUFBSyxXQUFVLG9CQUFtQix3QkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkM7QUFBQTtBQUFBO0FBQUEsWUFQN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFDQSx1QkFBQyx1QkFBb0IsT0FBTSxPQUFNLFdBQVUsUUFDekM7QUFBQSxtQ0FBQyxvQkFBaUIsU0FBU0sscUJBQ3pCO0FBQUEscUNBQUMsY0FBVyxXQUFVLGtCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQztBQUFBLGNBQUc7QUFBQSxpQkFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsb0JBQWlCLFNBQVNDLHNCQUN6QjtBQUFBLHFDQUFDLGdCQUFhLFdBQVUsa0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNDO0FBQUEsY0FBRztBQUFBLGlCQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxvQkFBaUIsU0FBU0MseUJBQ3pCO0FBQUEscUNBQUMsYUFBVSxXQUFVLGtCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQztBQUFBLGNBQUc7QUFBQSxpQkFEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0I7QUFBQSxZQUN0Qix1QkFBQyxvQkFBaUIsU0FBU0MsdUJBQ3pCO0FBQUEscUNBQUMsY0FBVyxXQUFVLGtCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQztBQUFBLGNBQUc7QUFBQSxpQkFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsb0JBQWlCLFNBQVNDLDJCQUN6QjtBQUFBLHFDQUFDLFdBQVEsV0FBVSxrQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUM7QUFBQSxjQUFHO0FBQUEsaUJBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLG9CQUFpQixTQUFTQyx5QkFDekI7QUFBQSxxQ0FBQyxtQkFBZ0IsV0FBVSxrQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUM7QUFBQSxjQUFHO0FBQUEsaUJBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLDJCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNCO0FBQUEsWUFDdEIsdUJBQUMsb0JBQWlCLFNBQVNDLG9CQUN6QjtBQUFBLHFDQUFDLFlBQVMsV0FBVSxrQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0M7QUFBQSxjQUFHO0FBQUEsaUJBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLG9CQUFpQixTQUFTQyxvQkFDekI7QUFBQSxxQ0FBQyxZQUFTLFdBQVUsa0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtDO0FBQUEsY0FBRztBQUFBLGlCQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyQkE7QUFBQSxhQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0NBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUTtBQUFBLFlBQ1IsTUFBSztBQUFBLFlBQ0wsV0FBVTtBQUFBLFlBQ1YsU0FBU1Q7QUFBQUEsWUFFVDtBQUFBLHFDQUFDLGlCQUFjLFdBQVUsc0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJDO0FBQUEsY0FDM0MsdUJBQUMsVUFBSyxXQUFVLG9CQUFtQix3QkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkM7QUFBQTtBQUFBO0FBQUEsVUFQN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUE7QUFBQSxXQXJFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0VBO0FBQUEsTUFFQSx1QkFBQyxVQUFPLE1BQUssTUFBSyxXQUFVLFlBQVcsU0FBU0QsV0FDOUM7QUFBQSwrQkFBQyxRQUFLLFdBQVUsc0JBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0M7QUFBQTtBQUFBLFdBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUEsdUJBQUMsVUFBSyxXQUFVLDZIQUNiSjtBQUFBQTtBQUFBQSxRQUFRO0FBQUEsUUFBRUM7QUFBQUEsV0FEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQUssV0FBVSxtSUFDZDtBQUFBLCtCQUFDLFVBQUssV0FBVSxvQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRDtBQUFBO0FBQUEsV0FEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQSx1QkFBQyxrQkFBZSxTQUFPLE1BQUMsV0FBVSx5QkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RDtBQUFBLE1BRXZEO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixNQUFLO0FBQUEsVUFDTCxXQUFVO0FBQUEsVUFDVixTQUFTMkI7QUFBQUEsVUFDVCxjQUFZRCxjQUFjLHdCQUF3QjtBQUFBLFVBQ2xELE9BQU9BLGNBQWMscUNBQXFDO0FBQUEsVUFFekRBLHdCQUFjLHVCQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQixJQUFNLHVCQUFDLE9BQUksV0FBVSxhQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCO0FBQUE7QUFBQSxRQVIxRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFTQTtBQUFBLE1BR0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVE7QUFBQSxVQUNSLE1BQUs7QUFBQSxVQUNMLFdBQVU7QUFBQSxVQUNWLFNBQVMsTUFBTUosU0FBU0QsVUFBVSxTQUFTLFVBQVUsTUFBTTtBQUFBLFVBQzNELGNBQVksYUFBYUEsVUFBVSxTQUFTLFVBQVUsTUFBTTtBQUFBLFVBRTNEQSxvQkFBVSxTQUFTLHVCQUFDLE9BQUksV0FBVSxhQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCLElBQU0sdUJBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlCO0FBQUE7QUFBQSxRQVA3RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFRQTtBQUFBLE1BR0EsdUJBQUMsZ0JBQ0M7QUFBQSwrQkFBQyx1QkFBb0IsU0FBTyxNQUMxQixpQ0FBQyxVQUFPLFNBQVEsU0FBUSxNQUFLLFFBQU8sV0FBVSxzQkFDNUMsaUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUIsS0FEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFDQSx1QkFBQyx1QkFBb0IsT0FBTSxPQUFNLFdBQVUsUUFDekM7QUFBQSxpQ0FBQyxvQkFBaUIsVUFBUSxNQUN4QjtBQUFBLG1DQUFDLFlBQVMsV0FBVSxrQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0M7QUFBQSxZQUFHO0FBQUEsZUFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsb0JBQWlCLFNBQVNSLG9CQUN6QjtBQUFBLG1DQUFDLFlBQVMsV0FBVSxrQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0M7QUFBQSxZQUFHO0FBQUEsZUFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxTQWhLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUtBO0FBQUEsT0F4UUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlRQTtBQUVKO0FBQUNPLEdBOVZlM0IsV0FBUztBQUFBLFVBaUNvQi9CLFVBQVU7QUFBQTtBQUFBLEtBakN2QytCO0FBQVMsSUFBQXFEO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkJ1dHRvbiIsImNuIiwiRHJvcGRvd25NZW51IiwiRHJvcGRvd25NZW51Q29udGVudCIsIkRyb3Bkb3duTWVudUl0ZW0iLCJEcm9wZG93bk1lbnVTZXBhcmF0b3IiLCJEcm9wZG93bk1lbnVUcmlnZ2VyIiwiUXVvdGFGdWVsR2F1Z2UiLCJ1c2VQcml2YWN5IiwiU2VhcmNoIiwiUGx1cyIsIkJhckNoYXJ0MyIsIlNldHRpbmdzIiwiS2V5Ym9hcmQiLCJBY3Rpdml0eSIsIkRvbGxhclNpZ24iLCJUcmVuZGluZ0Rvd24iLCJIZWFydFB1bHNlIiwiTW9uaXRvciIsIkxheW91dERhc2hib2FyZCIsIkFsZXJ0VHJpYW5nbGUiLCJVc2VyIiwiTW9vbiIsIlN1biIsIlNoaWVsZCIsIkJvdCIsIlNwYXJrbGVzIiwiRXllIiwiRXllT2ZmIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJBSV9TVEFUVVNfU1RZTEVTIiwiYWN0aXZlIiwicmluZyIsImRvdCIsImJhZGdlIiwidGhpbmtpbmciLCJpZGxlIiwib2ZmbGluZSIsIkFwcFRvcEJhciIsInByb2plY3RTd2l0Y2hlciIsInNlYXJjaEJhciIsImFjdGl2ZUNvdW50IiwidGFza0NvdW50IiwiYWlTdGF0dXMiLCJ0aW1lU3RyIiwiZGF0ZVN0ciIsInBlbmRpbmdBcHByb3ZhbHMiLCJwcm9qZWN0SWQiLCJvbk5ld1Rhc2siLCJvbk9wZW5Db250cm9scyIsIm9uT3BlbkNvbW1hbmRQYWxldHRlIiwib25PcGVuQ29zdEFuYWx5dGljcyIsIm9uT3BlbkJ1ZGdldEJ1cm5Eb3duIiwib25PcGVuQWR2YW5jZWRBbmFseXRpY3MiLCJvbk9wZW5IZWFsdGhEYXNoYm9hcmQiLCJvbk9wZW5Nb25pdG9yaW5nRGFzaGJvYXJkIiwib25PcGVuRGFzaGJvYXJkT3ZlcnZpZXciLCJvbk9wZW5BY3Rpdml0eUZlZWQiLCJvbk9wZW5LZXlib2FyZEhlbHAiLCJvbk9wZW5BcHByb3ZhbHMiLCJvbk9wZW5Ob3RpZmljYXRpb25zIiwib25PcGVuQWdlbnRzRmx5b3V0Iiwib25PcGVuQWlTdGF0dXMiLCJvbk9wZW5NaXNzaW9uTW9kYWwiLCJvbk9wZW5TdWdnZXN0aW9uc0RyYXdlciIsIl9zIiwidGhlbWUiLCJzZXRUaGVtZSIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJwcml2YWN5TW9kZSIsInRvZ2dsZVByaXZhY3lNb2RlIiwiYWlTdGF0dXNTdHlsZSIsInRvbmUiLCJyZXZpZXdMYWJlbCIsIm9wZXJhdG9yQ3VlIiwibGFiZWwiLCJkZXRhaWwiLCJhY3Rpb25MYWJlbCIsImljb24iLCJ0b25lQ2xhc3MiLCJvbkNsaWNrIiwicm9vdCIsImRvY3VtZW50IiwiZG9jdW1lbnRFbGVtZW50Iiwic2V0QXR0cmlidXRlIiwiY2xhc3NMaXN0IiwidG9nZ2xlIiwic2V0SXRlbSIsImxhc3RTZWVuTGFiZWwiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHBUb3BCYXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiO1xuaW1wb3J0IHtcbiAgRHJvcGRvd25NZW51LFxuICBEcm9wZG93bk1lbnVDb250ZW50LFxuICBEcm9wZG93bk1lbnVJdGVtLFxuICBEcm9wZG93bk1lbnVTZXBhcmF0b3IsXG4gIERyb3Bkb3duTWVudVRyaWdnZXIsXG59IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvZHJvcGRvd24tbWVudVwiO1xuaW1wb3J0IHsgUXVvdGFGdWVsR2F1Z2UgfSBmcm9tIFwiQC9jb21wb25lbnRzL1F1b3RhRnVlbEdhdWdlXCI7XG5pbXBvcnQgeyB1c2VQcml2YWN5IH0gZnJvbSBcIkAvY29udGV4dHMvUHJpdmFjeUNvbnRleHRcIjtcbmltcG9ydCB7XG4gIFNlYXJjaCxcbiAgUGx1cyxcbiAgQmFyQ2hhcnQzLFxuICBTZXR0aW5ncyxcbiAgS2V5Ym9hcmQsXG4gIEFjdGl2aXR5LFxuICBEb2xsYXJTaWduLFxuICBUcmVuZGluZ0Rvd24sXG4gIEhlYXJ0UHVsc2UsXG4gIE1vbml0b3IsXG4gIExheW91dERhc2hib2FyZCxcbiAgQWxlcnRUcmlhbmdsZSxcbiAgVXNlcixcbiAgTW9vbixcbiAgU3VuLFxuICBTaGllbGQsXG4gIEJvdCxcbiAgU3BhcmtsZXMsXG4gIEV5ZSxcbiAgRXllT2ZmLFxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgdHlwZSB7IElkIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2NvbnZleC9fZ2VuZXJhdGVkL2RhdGFNb2RlbFwiO1xuXG50eXBlIFNoZWxsQWlUb25lID0gXCJhY3RpdmVcIiB8IFwidGhpbmtpbmdcIiB8IFwiaWRsZVwiIHwgXCJvZmZsaW5lXCI7XG5cbmludGVyZmFjZSBTaGVsbEFpU3RhdHVzIHtcbiAgdG9uZTogU2hlbGxBaVRvbmU7XG4gIGxhYmVsOiBzdHJpbmc7XG4gIGRldGFpbDogc3RyaW5nO1xuICBsYXN0U2VlbkxhYmVsOiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBBcHBUb3BCYXJQcm9wcyB7XG4gIHByb2plY3RTd2l0Y2hlcjogUmVhY3QuUmVhY3ROb2RlO1xuICBzZWFyY2hCYXI6IFJlYWN0LlJlYWN0Tm9kZTtcbiAgYWN0aXZlQ291bnQ6IG51bWJlcjtcbiAgdGFza0NvdW50OiBudW1iZXI7XG4gIGFpU3RhdHVzOiBTaGVsbEFpU3RhdHVzO1xuICB0aW1lU3RyOiBzdHJpbmc7XG4gIGRhdGVTdHI6IHN0cmluZztcbiAgcGVuZGluZ0FwcHJvdmFscz86IG51bWJlcjtcbiAgcHJvamVjdElkPzogSWQ8XCJwcm9qZWN0c1wiPiB8IG51bGw7XG4gIG9uTmV3VGFzazogKCkgPT4gdm9pZDtcbiAgb25PcGVuQ29udHJvbHM6ICgpID0+IHZvaWQ7XG4gIG9uT3BlbkNvbW1hbmRQYWxldHRlOiAoKSA9PiB2b2lkO1xuICBvbk9wZW5Db3N0QW5hbHl0aWNzOiAoKSA9PiB2b2lkO1xuICBvbk9wZW5CdWRnZXRCdXJuRG93bjogKCkgPT4gdm9pZDtcbiAgb25PcGVuQWR2YW5jZWRBbmFseXRpY3M6ICgpID0+IHZvaWQ7XG4gIG9uT3BlbkhlYWx0aERhc2hib2FyZDogKCkgPT4gdm9pZDtcbiAgb25PcGVuTW9uaXRvcmluZ0Rhc2hib2FyZDogKCkgPT4gdm9pZDtcbiAgb25PcGVuRGFzaGJvYXJkT3ZlcnZpZXc6ICgpID0+IHZvaWQ7XG4gIG9uT3BlbkFjdGl2aXR5RmVlZDogKCkgPT4gdm9pZDtcbiAgb25PcGVuS2V5Ym9hcmRIZWxwOiAoKSA9PiB2b2lkO1xuICBvbk9wZW5BcHByb3ZhbHM/OiAoKSA9PiB2b2lkO1xuICBvbk9wZW5Ob3RpZmljYXRpb25zPzogKCkgPT4gdm9pZDtcbiAgb25PcGVuQWdlbnRzRmx5b3V0PzogKCkgPT4gdm9pZDtcbiAgb25PcGVuQWlTdGF0dXM/OiAoKSA9PiB2b2lkO1xuICBvbk9wZW5NaXNzaW9uTW9kYWw/OiAoKSA9PiB2b2lkO1xuICBvbk9wZW5TdWdnZXN0aW9uc0RyYXdlcj86ICgpID0+IHZvaWQ7XG59XG5cbmNvbnN0IEFJX1NUQVRVU19TVFlMRVM6IFJlY29yZDxTaGVsbEFpVG9uZSwgeyByaW5nOiBzdHJpbmc7IGRvdDogc3RyaW5nOyBiYWRnZTogc3RyaW5nIH0+ID0ge1xuICBhY3RpdmU6IHtcbiAgICByaW5nOiBcImJvcmRlci1saW5lIGJnLW9rLXNvZnQgdGV4dC1va1wiLFxuICAgIGRvdDogXCJiZy1va1wiLFxuICAgIGJhZGdlOiBcInRleHQtb2tcIixcbiAgfSxcbiAgdGhpbmtpbmc6IHtcbiAgICByaW5nOiBcImJvcmRlci1saW5lIGJnLXdhcm4tc29mdCB0ZXh0LXdhcm5cIixcbiAgICBkb3Q6IFwiYmctd2FyblwiLFxuICAgIGJhZGdlOiBcInRleHQtd2FyblwiLFxuICB9LFxuICBpZGxlOiB7XG4gICAgcmluZzogXCJib3JkZXItbGluZSBiZy1pbmZvLXNvZnQgdGV4dC1pbmZvLWFjY2VudFwiLFxuICAgIGRvdDogXCJiZy1pbmZvLWFjY2VudFwiLFxuICAgIGJhZGdlOiBcInRleHQtaW5mby1hY2NlbnRcIixcbiAgfSxcbiAgb2ZmbGluZToge1xuICAgIHJpbmc6IFwiYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0yIHRleHQtaW5rLW11dGVkXCIsXG4gICAgZG90OiBcImJnLWluay1tdXRlZFwiLFxuICAgIGJhZGdlOiBcInRleHQtaW5rLW11dGVkXCIsXG4gIH0sXG59O1xuXG5leHBvcnQgZnVuY3Rpb24gQXBwVG9wQmFyKHtcbiAgcHJvamVjdFN3aXRjaGVyLFxuICBzZWFyY2hCYXIsXG4gIGFjdGl2ZUNvdW50LFxuICB0YXNrQ291bnQsXG4gIGFpU3RhdHVzLFxuICB0aW1lU3RyLFxuICBkYXRlU3RyLFxuICBwZW5kaW5nQXBwcm92YWxzID0gMCxcbiAgcHJvamVjdElkLFxuICBvbk5ld1Rhc2ssXG4gIG9uT3BlbkNvbnRyb2xzLFxuICBvbk9wZW5Db21tYW5kUGFsZXR0ZSxcbiAgb25PcGVuQ29zdEFuYWx5dGljcyxcbiAgb25PcGVuQnVkZ2V0QnVybkRvd24sXG4gIG9uT3BlbkFkdmFuY2VkQW5hbHl0aWNzLFxuICBvbk9wZW5IZWFsdGhEYXNoYm9hcmQsXG4gIG9uT3Blbk1vbml0b3JpbmdEYXNoYm9hcmQsXG4gIG9uT3BlbkRhc2hib2FyZE92ZXJ2aWV3LFxuICBvbk9wZW5BY3Rpdml0eUZlZWQsXG4gIG9uT3BlbktleWJvYXJkSGVscCxcbiAgb25PcGVuQXBwcm92YWxzLFxuICBvbk9wZW5Ob3RpZmljYXRpb25zLFxuICBvbk9wZW5BZ2VudHNGbHlvdXQsXG4gIG9uT3BlbkFpU3RhdHVzLFxuICBvbk9wZW5NaXNzaW9uTW9kYWwsXG4gIG9uT3BlblN1Z2dlc3Rpb25zRHJhd2VyLFxufTogQXBwVG9wQmFyUHJvcHMpIHtcbiAgY29uc3QgW3RoZW1lLCBzZXRUaGVtZV0gPSB1c2VTdGF0ZSgoKSA9PiB7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBcImRhcmtcIjtcbiAgICByZXR1cm4gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibWMudGhlbWVcIikgfHwgXCJkYXJrXCI7XG4gIH0pO1xuXG4gIGNvbnN0IHsgcHJpdmFjeU1vZGUsIHRvZ2dsZVByaXZhY3lNb2RlIH0gPSB1c2VQcml2YWN5KCk7XG4gIGNvbnN0IGFpU3RhdHVzU3R5bGUgPSBBSV9TVEFUVVNfU1RZTEVTW2FpU3RhdHVzLnRvbmVdO1xuICBjb25zdCByZXZpZXdMYWJlbCA9IHBlbmRpbmdBcHByb3ZhbHMgPiAwID8gYCR7cGVuZGluZ0FwcHJvdmFsc30gcmV2aWV3YCA6IFwicmV2aWV3IGNsZWFyXCI7XG4gIGNvbnN0IG9wZXJhdG9yQ3VlID1cbiAgICBwZW5kaW5nQXBwcm92YWxzID4gMCAmJiBvbk9wZW5BcHByb3ZhbHNcbiAgICAgID8ge1xuICAgICAgICAgIGxhYmVsOiBcIlBlbmRpbmcgYXBwcm92YWxzXCIsXG4gICAgICAgICAgZGV0YWlsOiBgJHtwZW5kaW5nQXBwcm92YWxzfSBkZWNpc2lvbiR7cGVuZGluZ0FwcHJvdmFscyA9PT0gMSA/IFwiXCIgOiBcInNcIn0gbmVlZCBvcGVyYXRvciByZXZpZXcuYCxcbiAgICAgICAgICBhY3Rpb25MYWJlbDogXCJSZXZpZXcgbm93XCIsXG4gICAgICAgICAgaWNvbjogU2hpZWxkLFxuICAgICAgICAgIHRvbmVDbGFzczogXCJib3JkZXItbGluZSBiZy13YXJuLXNvZnQgdGV4dC13YXJuXCIsXG4gICAgICAgICAgb25DbGljazogb25PcGVuQXBwcm92YWxzLFxuICAgICAgICB9XG4gICAgICA6IChhaVN0YXR1cy50b25lID09PSBcIm9mZmxpbmVcIiB8fCBhY3RpdmVDb3VudCA9PT0gMCkgJiYgb25PcGVuQWlTdGF0dXNcbiAgICAgICAgPyB7XG4gICAgICAgICAgICBsYWJlbDogXCJBZ2VudCBuZXR3b3JrIGlkbGVcIixcbiAgICAgICAgICAgIGRldGFpbDogXCJObyBsaXZlIGV4ZWN1dGlvbiBpcyByZXBvcnRpbmcgaW4uIEluc3BlY3QgdGhlIGZsZWV0IGJlZm9yZSB0cnVzdCBkZWdyYWRlcy5cIixcbiAgICAgICAgICAgIGFjdGlvbkxhYmVsOiBcIkluc3BlY3QgZmxlZXRcIixcbiAgICAgICAgICAgIGljb246IEJvdCxcbiAgICAgICAgICAgIHRvbmVDbGFzczogXCJib3JkZXItbGluZSBiZy1zdXJmYWNlLTIgdGV4dC1pbmstc2Vjb25kYXJ5XCIsXG4gICAgICAgICAgICBvbkNsaWNrOiBvbk9wZW5BaVN0YXR1cyxcbiAgICAgICAgICB9XG4gICAgICAgIDogdGFza0NvdW50ID09PSAwXG4gICAgICAgICAgPyB7XG4gICAgICAgICAgICAgIGxhYmVsOiBcIk1pc3Npb24gcXVldWUgaXMgZW1wdHlcIixcbiAgICAgICAgICAgICAgZGV0YWlsOiBcIlNlZWQgdGhlIG5leHQgdGFzayBub3cgc28gdGhlIHN5c3RlbSBkb2VzIG5vdCBzdGFsbCBiZXR3ZWVuIGN5Y2xlcy5cIixcbiAgICAgICAgICAgICAgYWN0aW9uTGFiZWw6IFwiQ3JlYXRlIHRhc2tcIixcbiAgICAgICAgICAgICAgaWNvbjogUGx1cyxcbiAgICAgICAgICAgICAgdG9uZUNsYXNzOiBcImJvcmRlci1saW5lIGJnLWluZm8tc29mdCB0ZXh0LWluZm8tYWNjZW50XCIsXG4gICAgICAgICAgICAgIG9uQ2xpY2s6IG9uTmV3VGFzayxcbiAgICAgICAgICAgIH1cbiAgICAgICAgICA6IG9uT3BlblN1Z2dlc3Rpb25zRHJhd2VyXG4gICAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgICBsYWJlbDogXCJDcmVhdGUgdGhlIG5leHQgbW92ZVwiLFxuICAgICAgICAgICAgICAgIGRldGFpbDogXCJVc2UgbWlzc2lvbi1hbGlnbmVkIHN1Z2dlc3Rpb25zIHRvIGtlZXAgdGhlIHN5c3RlbSBwcm9hY3RpdmUgaW5zdGVhZCBvZiByZWFjdGl2ZS5cIixcbiAgICAgICAgICAgICAgICBhY3Rpb25MYWJlbDogXCJHZW5lcmF0ZSB0YXNrc1wiLFxuICAgICAgICAgICAgICAgIGljb246IFNwYXJrbGVzLFxuICAgICAgICAgICAgICAgIHRvbmVDbGFzczogXCJib3JkZXItbGluZSBiZy1vay1zb2Z0IHRleHQtb2tcIixcbiAgICAgICAgICAgICAgICBvbkNsaWNrOiBvbk9wZW5TdWdnZXN0aW9uc0RyYXdlcixcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgOiBudWxsO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3Qgcm9vdCA9IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudDtcbiAgICByb290LnNldEF0dHJpYnV0ZShcImRhdGEtdGhlbWVcIiwgdGhlbWUpO1xuICAgIHJvb3QuY2xhc3NMaXN0LnRvZ2dsZShcImxpZ2h0XCIsIHRoZW1lID09PSBcImxpZ2h0XCIpO1xuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcIm1jLnRoZW1lXCIsIHRoZW1lKTtcbiAgfSwgW3RoZW1lXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cInJlbGF0aXZlIGdyaWQgbWluLWgtWzY4cHhdIGdyaWQtY29scy1bbWlubWF4KDAsMWZyKV9hdXRvXSBpdGVtcy1jZW50ZXIgZ2FwLTMgYm9yZGVyLWIgYm9yZGVyLWxpbmUgYmctcmFpbCBweC00XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggbWluLXctMCBmbGV4LTEgaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIDJ4bDpmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTEgcHgtMy41IHB5LTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC0xMSB3LTExIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTIgdGV4dC1pbmstc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICA8Qm90IGNsYXNzTmFtZT1cImgtNSB3LTVcIiBzdHJva2VXaWR0aD17MS42fSAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1lZGl1bSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICBTZWxsZXJGaVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPlxuICAgICAgICAgICAgICBNaXNzaW9uIENvbnRyb2xcbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNocmluay0wXCI+e3Byb2plY3RTd2l0Y2hlcn08L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBzbTpibG9jayBmbGV4LTEgbWF4LXctWzMyMHB4XVwiPlxuICAgICAgICAgIHtzZWFyY2hCYXJ9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxCdXR0b25cbiAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgIHNpemU9XCJpY29uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJoLTkgdy05IHJvdW5kZWQtbGcgc206aGlkZGVuXCJcbiAgICAgICAgICBvbkNsaWNrPXtvbk9wZW5Db21tYW5kUGFsZXR0ZX1cbiAgICAgICAgICBhcmlhLWxhYmVsPVwiU2VhcmNoXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgIDwvQnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgaGlkZGVuIG1pbi13LTAgMnhsOmZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAge29uT3BlbkFpU3RhdHVzICYmIChcbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9e29uT3BlbkFpU3RhdHVzfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgZmxleCBtaW4tdy1bMjEwcHhdIG1heC13LVsyNTJweF0gaXRlbXMtY2VudGVyIGdhcC0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMSBweC0zLjUgcHktMi41IHRleHQtbGVmdCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgaG92ZXI6Ym9yZGVyLWxpbmUtc3Ryb25nIGhvdmVyOmJnLXN1cmZhY2UtMlwiXG4gICAgICAgICAgICB0aXRsZT17YWlTdGF0dXMuZGV0YWlsfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICBcInJlbGF0aXZlIGZsZXggaC0xMSB3LTExIHNocmluay0wIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIGJvcmRlclwiLFxuICAgICAgICAgICAgICAgIGFpU3RhdHVzU3R5bGUucmluZyxcbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEhlYXJ0UHVsc2UgY2xhc3NOYW1lPVwiaC00LjUgdy00LjVcIiBzdHJva2VXaWR0aD17MS43fSAvPlxuICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICBcImFic29sdXRlIHJpZ2h0LTEuNSB0b3AtMS41IGgtMiB3LTIgcm91bmRlZC1mdWxsXCIsXG4gICAgICAgICAgICAgICAgICBhaVN0YXR1c1N0eWxlLmRvdCxcbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMS41cHhdIGZvbnQtbWVkaXVtIHRleHQtaW5rLW11dGVkXCI+XG4gICAgICAgICAgICAgICAgICBBSSBzdGF0dXNcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtjbihcInRleHQtWzExcHhdIGZvbnQtbWVkaXVtXCIsIGFpU3RhdHVzU3R5bGUuYmFkZ2UpfT5cbiAgICAgICAgICAgICAgICAgIHthaVN0YXR1cy5sYXN0U2VlbkxhYmVsfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0cnVuY2F0ZSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj5cbiAgICAgICAgICAgICAgICB7YWlTdGF0dXMubGFiZWx9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTAuNSB0cnVuY2F0ZSB0ZXh0LVsxMXB4XSB0ZXh0LWluay1tdXRlZFwiPlxuICAgICAgICAgICAgICAgIHthaVN0YXR1cy5kZXRhaWx9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICl9XG5cbiAgICAgICAge29wZXJhdG9yQ3VlICYmIChcbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9e29wZXJhdG9yQ3VlLm9uQ2xpY2t9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICBcImdyb3VwIGZsZXggbWluLXctWzIyOHB4XSBtYXgtdy1bMzAwcHhdIGl0ZW1zLWNlbnRlciBnYXAtMyByb3VuZGVkLXhsIGJvcmRlciBweC0zLjUgcHktMi41IHRleHQtbGVmdCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgaG92ZXI6Ym9yZGVyLWxpbmUtc3Ryb25nXCIsXG4gICAgICAgICAgICAgIG9wZXJhdG9yQ3VlLnRvbmVDbGFzc1xuICAgICAgICAgICAgKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC0xMCB3LTEwIHNocmluay0wIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItbGluZSBiZy1zdXJmYWNlLTFcIj5cbiAgICAgICAgICAgICAgPG9wZXJhdG9yQ3VlLmljb24gY2xhc3NOYW1lPVwiaC00IHctNFwiIHN0cm9rZVdpZHRoPXsxLjd9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMS41cHhdIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAge29wZXJhdG9yQ3VlLmxhYmVsfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIGxpbmUtY2xhbXAtMiB0ZXh0LVsxMXB4XSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1pbmstc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAge29wZXJhdG9yQ3VlLmRldGFpbH1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LVsxMXB4XSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgIHtvcGVyYXRvckN1ZS5hY3Rpb25MYWJlbH1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKX1cblxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiAyeGw6ZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xIHAtMC41XCI+XG4gICAgICAgICAge29uT3BlbkFpU3RhdHVzICYmIChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e29uT3BlbkFpU3RhdHVzfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLW1kIHB4LTMgcHktMS41IHRleHQtbGVmdCB0ZXh0LVsxMXB4XSB0ZXh0LWluay1zZWNvbmRhcnkgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGhvdmVyOmJnLXN1cmZhY2UtMiBob3Zlcjp0ZXh0LWlua1wiXG4gICAgICAgICAgICAgIHRpdGxlPXthaVN0YXR1cy5kZXRhaWx9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17Y24oXCJoLTIgdy0yIHJvdW5kZWQtZnVsbFwiLCBhaVN0YXR1c1N0eWxlLmRvdCl9IC8+XG4gICAgICAgICAgICAgIDxzcGFuPnthaVN0YXR1cy5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17b25PcGVuQWdlbnRzRmx5b3V0ID8/IG9uT3BlbkRhc2hib2FyZE92ZXJ2aWV3fVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBweC0zIHB5LTEuNSB0ZXh0LVsxMXB4XSB0ZXh0LWluay1zZWNvbmRhcnkgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGhvdmVyOmJnLXN1cmZhY2UtMiBob3Zlcjp0ZXh0LWlua1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1pbmtcIj57YWN0aXZlQ291bnR9PC9zcGFuPiBsaXZlXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXtvbk9wZW5EYXNoYm9hcmRPdmVydmlld31cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgcHgtMyBweS0xLjUgdGV4dC1bMTFweF0gdGV4dC1pbmstc2Vjb25kYXJ5IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTE1MCBob3ZlcjpiZy1zdXJmYWNlLTIgaG92ZXI6dGV4dC1pbmtcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtaW5rXCI+e3Rhc2tDb3VudH08L3NwYW4+IHRhc2tzXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXtvbk9wZW5BcHByb3ZhbHMgPz8gb25PcGVuRGFzaGJvYXJkT3ZlcnZpZXd9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIHB4LTMgcHktMS41IHRleHQtWzExcHhdIHRleHQtaW5rLXNlY29uZGFyeSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0xNTAgaG92ZXI6Ymctc3VyZmFjZS0yIGhvdmVyOnRleHQtaW5rXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICB7cmV2aWV3TGFiZWx9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIG1kOmZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1saW5lIGJnLXN1cmZhY2UtMSBweC0xLjUgcHktMVwiPlxuICAgICAgICAgIHtvbk9wZW5BcHByb3ZhbHMgJiYgKFxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBoLTggcm91bmRlZC1sZyBweC0zIHRleHQteHNcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXtvbk9wZW5BcHByb3ZhbHN9XG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BBcHByb3ZhbHMke3BlbmRpbmdBcHByb3ZhbHMgPiAwID8gYCAoJHtwZW5kaW5nQXBwcm92YWxzfSBwZW5kaW5nKWAgOiBcIlwifWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxTaGllbGQgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgbXItMVwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiB4bDppbmxpbmVcIj5BcHByb3ZhbHM8L3NwYW4+XG4gICAgICAgICAgICAgIHtwZW5kaW5nQXBwcm92YWxzID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC0wLjUgLXJpZ2h0LTAuNSBtaW4tdy00IGgtNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgYmctZGVzdHJ1Y3RpdmUgdGV4dC1kZXN0cnVjdGl2ZS1mb3JlZ3JvdW5kIHRleHQtWzlweF0gZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICB7cGVuZGluZ0FwcHJvdmFsc31cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgPERyb3Bkb3duTWVudT5cbiAgICAgICAgICAgIDxEcm9wZG93bk1lbnVUcmlnZ2VyIGFzQ2hpbGQ+XG4gICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHJvdW5kZWQtbGcgcHgtMyB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIkluc2lnaHRzIOKAlCBDb3N0IEFuYWx5dGljcywgUHJvdmlkZXIgYmlsbGluZywgSGVhbHRoLCBNb25pdG9yaW5nXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxCYXJDaGFydDMgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgbXItMS41XCIgLz5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4geGw6aW5saW5lXCI+SW5zaWdodHM8L3NwYW4+XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnVUcmlnZ2VyPlxuICAgICAgICAgICAgPERyb3Bkb3duTWVudUNvbnRlbnQgYWxpZ249XCJlbmRcIiBjbGFzc05hbWU9XCJ3LTUyXCI+XG4gICAgICAgICAgICAgIDxEcm9wZG93bk1lbnVJdGVtIG9uQ2xpY2s9e29uT3BlbkNvc3RBbmFseXRpY3N9PlxuICAgICAgICAgICAgICAgIDxEb2xsYXJTaWduIGNsYXNzTmFtZT1cImgtNCB3LTQgbXItMlwiIC8+Q29zdCBBbmFseXRpY3NcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnVJdGVtPlxuICAgICAgICAgICAgICA8RHJvcGRvd25NZW51SXRlbSBvbkNsaWNrPXtvbk9wZW5CdWRnZXRCdXJuRG93bn0+XG4gICAgICAgICAgICAgICAgPFRyZW5kaW5nRG93biBjbGFzc05hbWU9XCJoLTQgdy00IG1yLTJcIiAvPkJ1ZGdldCBCdXJuLURvd25cbiAgICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnVJdGVtPlxuICAgICAgICAgICAgICA8RHJvcGRvd25NZW51SXRlbSBvbkNsaWNrPXtvbk9wZW5BZHZhbmNlZEFuYWx5dGljc30+XG4gICAgICAgICAgICAgICAgPEJhckNoYXJ0MyBjbGFzc05hbWU9XCJoLTQgdy00IG1yLTJcIiAvPkFkdmFuY2VkIEFuYWx5dGljc1xuICAgICAgICAgICAgICA8L0Ryb3Bkb3duTWVudUl0ZW0+XG4gICAgICAgICAgICAgIDxEcm9wZG93bk1lbnVTZXBhcmF0b3IgLz5cbiAgICAgICAgICAgICAgPERyb3Bkb3duTWVudUl0ZW0gb25DbGljaz17b25PcGVuSGVhbHRoRGFzaGJvYXJkfT5cbiAgICAgICAgICAgICAgICA8SGVhcnRQdWxzZSBjbGFzc05hbWU9XCJoLTQgdy00IG1yLTJcIiAvPkhlYWx0aCBEYXNoYm9hcmRcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnVJdGVtPlxuICAgICAgICAgICAgICA8RHJvcGRvd25NZW51SXRlbSBvbkNsaWNrPXtvbk9wZW5Nb25pdG9yaW5nRGFzaGJvYXJkfT5cbiAgICAgICAgICAgICAgICA8TW9uaXRvciBjbGFzc05hbWU9XCJoLTQgdy00IG1yLTJcIiAvPk1vbml0b3JpbmdcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnVJdGVtPlxuICAgICAgICAgICAgICA8RHJvcGRvd25NZW51SXRlbSBvbkNsaWNrPXtvbk9wZW5EYXNoYm9hcmRPdmVydmlld30+XG4gICAgICAgICAgICAgICAgPExheW91dERhc2hib2FyZCBjbGFzc05hbWU9XCJoLTQgdy00IG1yLTJcIiAvPk92ZXJ2aWV3IFNuYXBzaG90XG4gICAgICAgICAgICAgIDwvRHJvcGRvd25NZW51SXRlbT5cbiAgICAgICAgICAgICAgPERyb3Bkb3duTWVudVNlcGFyYXRvciAvPlxuICAgICAgICAgICAgICA8RHJvcGRvd25NZW51SXRlbSBvbkNsaWNrPXtvbk9wZW5BY3Rpdml0eUZlZWR9PlxuICAgICAgICAgICAgICAgIDxBY3Rpdml0eSBjbGFzc05hbWU9XCJoLTQgdy00IG1yLTJcIiAvPkFjdGl2aXR5IFRpbWVsaW5lXG4gICAgICAgICAgICAgIDwvRHJvcGRvd25NZW51SXRlbT5cbiAgICAgICAgICAgICAgPERyb3Bkb3duTWVudUl0ZW0gb25DbGljaz17b25PcGVuS2V5Ym9hcmRIZWxwfT5cbiAgICAgICAgICAgICAgICA8S2V5Ym9hcmQgY2xhc3NOYW1lPVwiaC00IHctNCBtci0yXCIgLz5TaG9ydGN1dHNcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnVJdGVtPlxuICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnVDb250ZW50PlxuICAgICAgICAgIDwvRHJvcGRvd25NZW51PlxuXG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcbiAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggcm91bmRlZC1sZyBweC0zIHRleHQteHMgdGV4dC13YXJuIGhvdmVyOnRleHQtd2FyblwiXG4gICAgICAgICAgICBvbkNsaWNrPXtvbk9wZW5Db250cm9sc31cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSBtci0xXCIgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiB4bDppbmxpbmVcIj5Db250cm9sczwvc3Bhbj5cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiBjbGFzc05hbWU9XCJoLTkgcHgtM1wiIG9uQ2xpY2s9e29uTmV3VGFza30+XG4gICAgICAgICAgPFBsdXMgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgbXItMVwiIC8+XG4gICAgICAgICAgTmV3IFRhc2tcbiAgICAgICAgPC9CdXR0b24+XG5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIDJ4bDppbmxpbmUgd2hpdGVzcGFjZS1ub3dyYXAgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWxpbmUgYmctc3VyZmFjZS0xIHB4LTMgcHktMS41IHRleHQtWzExcHhdIHRleHQtaW5rLXNlY29uZGFyeVwiPlxuICAgICAgICAgIHt0aW1lU3RyfSB7ZGF0ZVN0cn1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4geGw6ZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgYmctb2stc29mdCBweC0zIHB5LTEuNSB0ZXh0LVsxMXB4XSBmb250LW1lZGl1bSB0ZXh0LW9rXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaC0xLjUgdy0xLjUgcm91bmRlZC1mdWxsIGJnLW9rXCIgLz5cbiAgICAgICAgICBPcGVyYXRvciBvbmxpbmVcbiAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgIDxRdW90YUZ1ZWxHYXVnZSBjb21wYWN0IGNsYXNzTmFtZT1cImhpZGRlbiB4bDpmbGV4IG1sLTFcIiAvPlxuXG4gICAgICAgIDxCdXR0b25cbiAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgIHNpemU9XCJpY29uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJoLTkgdy05IHJvdW5kZWQtbGdcIlxuICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZVByaXZhY3lNb2RlfVxuICAgICAgICAgIGFyaWEtbGFiZWw9e3ByaXZhY3lNb2RlID8gXCJTaG93IHNlbnNpdGl2ZSBpbmZvXCIgOiBcIkhpZGUgc2Vuc2l0aXZlIGluZm8gKGRlbW8gbW9kZSlcIn1cbiAgICAgICAgICB0aXRsZT17cHJpdmFjeU1vZGUgPyBcIlByaXZhY3kgb24g4oCUIGNsaWNrIHRvIHNob3cgbmFtZXNcIiA6IFwiUHJpdmFjeSBvZmYg4oCUIGNsaWNrIHRvIHJlZGFjdCBmb3IgZGVtb3NcIn1cbiAgICAgICAgPlxuICAgICAgICAgIHtwcml2YWN5TW9kZSA/IDxFeWVPZmYgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IDogPEV5ZSBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz59XG4gICAgICAgIDwvQnV0dG9uPlxuXG4gICAgICAgIHsvKiBUaGVtZSB0b2dnbGUgKi99XG4gICAgICAgIDxCdXR0b25cbiAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgIHNpemU9XCJpY29uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJoLTkgdy05IHJvdW5kZWQtbGdcIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRoZW1lKHRoZW1lID09PSBcImRhcmtcIiA/IFwibGlnaHRcIiA6IFwiZGFya1wiKX1cbiAgICAgICAgICBhcmlhLWxhYmVsPXtgU3dpdGNoIHRvICR7dGhlbWUgPT09IFwiZGFya1wiID8gXCJsaWdodFwiIDogXCJkYXJrXCJ9IG1vZGVgfVxuICAgICAgICA+XG4gICAgICAgICAge3RoZW1lID09PSBcImRhcmtcIiA/IDxTdW4gY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IDogPE1vb24gY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+fVxuICAgICAgICA8L0J1dHRvbj5cblxuICAgICAgICB7LyogVXNlciBtZW51IHBsYWNlaG9sZGVyICovfVxuICAgICAgICA8RHJvcGRvd25NZW51PlxuICAgICAgICAgIDxEcm9wZG93bk1lbnVUcmlnZ2VyIGFzQ2hpbGQ+XG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIHNpemU9XCJpY29uXCIgY2xhc3NOYW1lPVwiaC05IHctOSByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgIDxVc2VyIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9Ecm9wZG93bk1lbnVUcmlnZ2VyPlxuICAgICAgICAgIDxEcm9wZG93bk1lbnVDb250ZW50IGFsaWduPVwiZW5kXCIgY2xhc3NOYW1lPVwidy00NFwiPlxuICAgICAgICAgICAgPERyb3Bkb3duTWVudUl0ZW0gZGlzYWJsZWQ+XG4gICAgICAgICAgICAgIDxTZXR0aW5ncyBjbGFzc05hbWU9XCJoLTQgdy00IG1yLTJcIiAvPlNldHRpbmdzXG4gICAgICAgICAgICA8L0Ryb3Bkb3duTWVudUl0ZW0+XG4gICAgICAgICAgICA8RHJvcGRvd25NZW51SXRlbSBvbkNsaWNrPXtvbk9wZW5LZXlib2FyZEhlbHB9PlxuICAgICAgICAgICAgICA8S2V5Ym9hcmQgY2xhc3NOYW1lPVwiaC00IHctNCBtci0yXCIgLz5TaG9ydGN1dHNcbiAgICAgICAgICAgIDwvRHJvcGRvd25NZW51SXRlbT5cbiAgICAgICAgICA8L0Ryb3Bkb3duTWVudUNvbnRlbnQ+XG4gICAgICAgIDwvRHJvcGRvd25NZW51PlxuICAgICAgPC9kaXY+XG4gICAgPC9oZWFkZXI+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9qYXl3ZXN0L01pc3Npb25Db250cm9sLy53b3JrdHJlZXMvY29kZXgvc29mdHdhcmUtZmFjdG9yeS1lbmhhbmNlbWVudC1wbGFuLy53b3JrdHJlZXMvY29kZXgvYXV0b21hdGlvbi1jb250cm9sLXBsYW5lLXYxL2FwcHMvbWlzc2lvbi1jb250cm9sLXVpL3NyYy9jb21wb25lbnRzL0FwcFRvcEJhci50c3gifQ==